# -*- coding: utf-8 -*-
"""
Unit tests for the Refactored Scholarship Management System.

This test suite uses pytest to verify the functionality of the scholarship
system, including the Applicant data model, the core ScholarshipSystem logic,
and the main application flow. Tests cover standard scenarios, boundary
conditions, and edge cases.
"""

import sys
from io import StringIO
import pytest
from unittest.mock import patch

# Add the path to the module to be tested if it's not in the same directory
# In a real project structure, this might not be necessary.
# For this self-contained example, we import directly.
from scholarship_system import Applicant, ScholarshipSystem, main, get_sample_applicant_data

# --- Fixtures ---

@pytest.fixture
def sample_data():
    """Provides a copy of the sample applicant data for tests."""
    return [
        {'id': 101, 'name': 'Eleanor Vance', 'academic': 95, 'extracurricular': 80, 'progression': 92}, # Score: 92.45
        {'id': 102, 'name': 'Marcus Thorne', 'academic': 88, 'extracurricular': 95, 'progression': 85}, # Score: 87.90
        {'id': 103, 'name': 'Liam Chen', 'academic': 98, 'extracurricular': 70, 'progression': 95},     # Score: 92.75
        {'id': 104, 'name': 'Sophia Rossi', 'academic': 85, 'extracurricular': 88, 'progression': 82},  # Score: 84.40
        {'id': 105, 'name': 'Jamal Ahmed', 'academic': 92, 'extracurricular': 90, 'progression': 98},    # Score: 93.80
        {'id': 106, 'name': 'Chloe Davis', 'academic': 78, 'extracurricular': 85, 'progression': 75},   # Score: 78.00
        {'id': 107, 'name': 'Ben Carter', 'academic': 81, 'extracurricular': 75, 'progression': 70},    # Score: 76.25
    ]

@pytest.fixture
def applicant_all_100():
    """Provides a perfect-score applicant for testing calculations."""
    return {'id': 999, 'name': 'Perfect applicant', 'academic': 100, 'extracurricular': 100, 'progression': 100}

@pytest.fixture
def applicant_all_0():
    """Provides a zero-score applicant for testing calculations."""
    return {'id': 1, 'name': 'Zero applicant', 'academic': 0, 'extracurricular': 0, 'progression': 0}

# --- Test Applicant Data Class ---

class TestApplicant:
    """Tests for the Applicant data class."""

    def test_applicant_creation_valid(self):
        """FR1: Test successful creation of an Applicant instance with valid scores."""
        applicant = Applicant(
            applicant_id=1,
            name="Test applicant",
            academic_score=80.5,
            extracurricular_score=70,
            progression_score=90
        )
        assert applicant.applicant_id == 1
        assert applicant.name == "Test applicant"
        assert applicant.academic_score == 80.5
        assert applicant.viability_score == 0.0  # Initial default value

    @pytest.mark.parametrize("score_type, invalid_value", [
        ("academic_score", -0.1),
        ("extracurricular_score", -10),
        ("progression_score", 100.1),
        ("academic_score", 101),
    ])
    def test_applicant_creation_invalid_score_raises_error(self, score_type, invalid_value):
        """Test that scores outside the 0-100 range raise a ValueError."""
        with pytest.raises(ValueError, match="All scores must be between 0 and 100."):
            kwargs = {
                "applicant_id": 1,
                "name": "Invalid",
                "academic_score": 50,
                "extracurricular_score": 50,
                "progression_score": 50,
                score_type: invalid_value  # Override one score with an invalid value
            }
            Applicant(**kwargs)

    def test_applicant_creation_boundary_scores(self):
        """Test successful creation with boundary scores (0 and 100)."""
        try:
            Applicant(applicant_id=1, name="Boundary Low", academic_score=0, extracurricular_score=0, progression_score=0)
            Applicant(applicant_id=2, name="Boundary High", academic_score=100, extracurricular_score=100, progression_score=100)
        except ValueError:
            pytest.fail("Applicant creation failed with boundary scores 0 or 100.")

    def test_applicant_repr(self):
        """Test the __repr__ method for correct formatting."""
        applicant = Applicant(applicant_id=1, name="Test", academic_score=80, extracurricular_score=80, progression_score=80)
        applicant.viability_score = 80.00
        expected_repr = "Applicant(id=1, name='Test', score=80.00)"
        assert repr(applicant) == expected_repr

# --- Test ScholarshipSystem Core Logic ---

class TestScholarshipSystem:
    """Tests for the ScholarshipSystem class."""

    def test_init_success(self, sample_data):
        """Test successful initialization of the system."""
        system = ScholarshipSystem(sample_data, num_scholarships=3)
        assert system.num_scholarships == 3
        assert len(system._applicants) == len(sample_data)
        assert all(isinstance(app, Applicant) for app in system._applicants)

    def test_init_negative_scholarships_raises_error(self, sample_data):
        """Test that a negative number of scholarships raises a ValueError."""
        with pytest.raises(ValueError, match="Number of scholarships cannot be negative."):
            ScholarshipSystem(sample_data, num_scholarships=-1)

    def test_init_zero_scholarships(self, sample_data):
        """Test initialization with zero scholarships, a valid boundary case."""
        system = ScholarshipSystem(sample_data, num_scholarships=0)
        assert system.num_scholarships == 0

    def test_init_no_applicants(self):
        """Test initialization with an empty list of applicants."""
        system = ScholarshipSystem([], num_scholarships=5)
        assert len(system._applicants) == 0

    def test_init_malformed_data_raises_error(self):
        """Test that malformed applicant data (missing key) raises an error."""
        malformed_data = [{'id': 1, 'name': 'Missing Score'}] # Missing academic, etc.
        with pytest.raises(KeyError):
            ScholarshipSystem(malformed_data, num_scholarships=1)

    def test_compute_scores_correctness(self, applicant_all_100, applicant_all_0):
        """FR2 & FR5: Test the viability score computation logic."""
        data = [
            {'id': 123, 'name': 'Test Case', 'academic': 90, 'extracurricular': 80, 'progression': 70}, # 90*0.5 + 80*0.15 + 70*0.35 = 45+12+24.5=81.5
            applicant_all_100,
            applicant_all_0,
        ]
        system = ScholarshipSystem(data, num_scholarships=3)
        system._compute_scores()

        scores = {app.applicant_id: app.viability_score for app in system._applicants}
        assert scores[123] == 81.50
        assert scores[999] == 100.00
        assert scores[1] == 0.00

    def test_compute_scores_rounding(self):
        """Test that scores are correctly rounded to 2 decimal places."""
        data = [{'id': 1, 'name': 'Rounding Test', 'academic': 85.5, 'extracurricular': 75.5, 'progression': 90.5}]
        # 85.5*0.5 + 75.5*0.15 + 90.5*0.35 = 42.75 + 11.325 + 31.675 = 85.75
        system = ScholarshipSystem(data, num_scholarships=1)
        system._compute_scores()
        assert system._applicants[0].viability_score == 85.75

    def test_rank_applicants(self, sample_data):
        """FR3: Test that applicants are ranked correctly in descending order of score."""
        system = ScholarshipSystem(sample_data, num_scholarships=3)
        system._compute_scores()
        system._rank_applicants()

        ranked_ids = [app.applicant_id for app in system._ranked_applicants]
        expected_order = [105, 103, 101, 102, 104, 106, 107] # Based on scores calculated in fixture
        assert ranked_ids == expected_order

    def test_rank_applicants_score_tie(self):
        """Test that ranking is stable for applicants with the same score."""
        tie_data = [
            {'id': 1, 'name': 'A', 'academic': 100, 'extracurricular': 0, 'progression': 0}, # Score: 50
            {'id': 2, 'name': 'B', 'academic': 0, 'extracurricular': 0, 'progression': 100 / 0.35}, # Score: 100 (approx)
            {'id': 3, 'name': 'C', 'academic': 100, 'extracurricular': 0, 'progression': 0}, # Score: 50
        ]
        system = ScholarshipSystem(tie_data, num_scholarships=2)
        system._compute_scores()
        system._rank_applicants()

        # The ranker should place applicant B first
        assert system._ranked_applicants[0].applicant_id == 2
        # The relative order of tied applicants A and C should be preserved
        tied_ids = {system._ranked_applicants[1].applicant_id, system._ranked_applicants[2].applicant_id}
        assert tied_ids == {1, 3}

    def test_allocate_scholarships_more_applicants_than_slots(self, sample_data):
        """FR4: Test awarding scholarships when there are more applicants than awards."""
        system = ScholarshipSystem(sample_data, num_scholarships=3)
        awarded = system.allocate_scholarships()
        
        awarded_ids = [app.applicant_id for app in awarded]
        expected_top_3 = [105, 103, 101]

        assert len(awarded) == 3
        assert awarded_ids == expected_top_3

    def test_allocate_scholarships_fewer_applicants_than_slots(self):
        """FR4: Test awarding scholarships when there are fewer applicants than awards."""
        data = get_sample_applicant_data()[:2] # Only 2 applicants
        system = ScholarshipSystem(data, num_scholarships=5)
        awarded = system.allocate_scholarships()

        assert len(awarded) == 2
        assert {app.applicant_id for app in awarded} == {101, 102}

    def test_allocate_scholarships_zero_slots(self, sample_data):
        """FR4: Test allocation when zero scholarships are available."""
        system = ScholarshipSystem(sample_data, num_scholarships=0)
        awarded = system.allocate_scholarships()
        assert len(awarded) == 0

    def test_allocate_scholarships_no_applicants(self):
        """FR4: Test allocation with no applicants."""
        system = ScholarshipSystem([], num_scholarships=10)
        awarded = system.allocate_scholarships()
        assert len(awarded) == 0

# --- Test Reporting and Application Flow ---

class TestReportingAndFlow:
    """Tests for report generation and the main application entry point."""

    def test_generate_report_with_awards(self, capsys):
        """NFR2: Test report generation for a standard scenario with awarded scholarships."""
        system = ScholarshipSystem(get_sample_applicant_data(), num_scholarships=2)
        awarded = system.allocate_scholarships()
        system.generate_report(awarded)

        captured = capsys.readouterr()
        output = captured.out

        assert "SCHOLARSHIP MANAGEMENT SYSTEM - FINAL REPORT" in output
        assert "Total Scholarships Available: 2" in output
        assert f"Total Applicants Considered: {len(get_sample_applicant_data())}" in output
        assert "Scholarships Awarded: 2" in output
        assert "--- Awarded Applicant Details ---" in output
        assert "Jamal Ahmed" in output  # Top applicant
        assert "Liam Chen" in output # Second applicant
        assert "Eleanor Vance" not in output.split("--- Full Applicant Ranking ---")[0] # Not in awarded table
        assert "--- Full Applicant Ranking ---" in output
        assert "Eleanor Vance" in output # Should be in the full ranking

    def test_generate_report_no_awards(self, capsys):
        """NFR2: Test report generation when no scholarships are awarded."""
        system = ScholarshipSystem(get_sample_applicant_data(), num_scholarships=0)
        awarded = system.allocate_scholarships()
        system.generate_report(awarded)

        captured = capsys.readouterr()
        output = captured.out

        assert "Scholarships Awarded: 0" in output
        assert "No scholarships were awarded." in output
        assert "--- Awarded Applicant Details ---" in output
        assert "--- Full Applicant Ranking ---" in output # Full ranking still shown
        assert "Jamal Ahmed" in output # Top applicant still listed in full ranking

    def test_main_success_run(self, capsys):
        """Test the main function for a successful execution."""
        # Use patch to prevent sys.exit from being called
        with patch.object(sys, 'exit') as mock_exit:
            main()
            mock_exit.assert_called_once_with(0)

        captured = capsys.readouterr()
        output = captured.out
        assert "Starting the Scholarship Management System..." in output
        assert "SCHOLARSHIP MANAGEMENT SYSTEM - FINAL REPORT" in output
        assert "Report generation complete." in output

    def test_main_value_error_handling(self, capsys, monkeypatch):
        """Test that main function handles ValueErrors gracefully."""
        # Patch the ScholarshipSystem constructor to always raise a ValueError
        def mock_init(*args, **kwargs):
            raise ValueError("Simulated init failure.")

        monkeypatch.setattr(ScholarshipSystem, "__init__", mock_init)

        with patch.object(sys, 'exit') as mock_exit:
            main()
            mock_exit.assert_called_once_with(1)

        captured = capsys.readouterr()
        err_output = captured.err
        assert "Error: An invalid value was encountered: Simulated init failure." in err_output