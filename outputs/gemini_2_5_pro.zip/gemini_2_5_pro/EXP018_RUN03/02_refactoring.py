# -*- coding: utf-8 -*-
"""
Refactored Scholarship Management System

This self-contained Python application manages the scholarship allocation process.
It scores, ranks, and awards scholarships to applicants based on a weighted
assessment of their academic performance, extracurricular activities, and
professional progression.

This version has been refactored for improved modularity, clarity, and
adherence to PEP 8 standards.
"""

import sys
from dataclasses import dataclass, field
from typing import List, Dict, Any

# --- Data Model ---


@dataclass
class Applicant:
    """
    Represents a scholarship applicant using a dataclass for conciseness.

    This class stores all relevant information for an applicant. The viability
    score is computed and assigned later in the process.

    Attributes:
        applicant_id: A unique identifier for the applicant.
        name: The full name of the applicant.
        academic_score: A normalized score (0-100) for academic performance.
        extracurricular_score: A normalized score (0-100) for extracurriculars.
        progression_score: A normalized score (0-100) for progression.
        viability_score: The final computed score used for ranking.
                         Not initialized directly.
    """
    applicant_id: int
    name: str
    academic_score: float
    extracurricular_score: float
    progression_score: float
    viability_score: float = field(init=False, default=0.0)

    def __post_init__(self):
        """Validates score values after initialization."""
        scores = [
            self.academic_score,
            self.extracurricular_score,
            self.progression_score,
        ]
        if not all(0 <= score <= 100 for score in scores):
            raise ValueError("All scores must be between 0 and 100.")

    def __repr__(self) -> str:
        """Provides a developer-friendly representation of the Applicant."""
        return (
            f"Applicant(id={self.applicant_id}, name='{self.name}', "
            f"score={self.viability_score:.2f})"
        )

# --- Core Logic ---


class ScholarshipSystem:
    """
    Manages the entire scholarship allocation workflow.

    This system handles loading applicant data, calculating viability scores,
    ranking applicants, allocating scholarships, and generating a summary report.
    It operates entirely in-memory without external dependencies.
    """

    # FR5: Weights give greater importance to academic and professional
    # progression (totaling 85%) over extracurriculars (15%).
    SCORING_WEIGHTS: Dict[str, float] = {
        'academic': 0.50,
        'progression': 0.35,
        'extracurricular': 0.15,
    }

    def __init__(
        self, applicant_data: List[Dict[str, Any]], num_scholarships: int
    ):
        """
        Initializes the scholarship system.

        Args:
            applicant_data: A list of dictionaries, where each dictionary
                            contains the raw data for one applicant.
            num_scholarships: The total number of scholarships to be awarded.

        Raises:
            ValueError: If num_scholarships is negative.
        """
        if num_scholarships < 0:
            raise ValueError("Number of scholarships cannot be negative.")
        self.num_scholarships = num_scholarships
        self._applicants: List[Applicant] = self._load_applicants(applicant_data)
        self._ranked_applicants: List[Applicant] = []

    def _load_applicants(self, raw_data: List[Dict[str, Any]]) -> List[Applicant]:
        """FR1: Loads applicant data from dicts into Applicant objects."""
        return [
            Applicant(
                applicant_id=data['id'],
                name=data['name'],
                academic_score=data['academic'],
                extracurricular_score=data['extracurricular'],
                progression_score=data['progression'],
            ) for data in raw_data
        ]

    def _compute_scores(self) -> None:
        """FR2: Computes the viability score for each applicant."""
        print("Computing viability scores for all applicants...")
        for applicant in self._applicants:
            score = (
                applicant.academic_score * self.SCORING_WEIGHTS['academic'] +
                applicant.extracurricular_score * self.SCORING_WEIGHTS['extracurricular'] +
                applicant.progression_score * self.SCORING_WEIGHTS['progression']
            )
            applicant.viability_score = round(score, 2)

    def _rank_applicants(self) -> None:
        """FR3: Ranks applicants in descending order by viability score."""
        print("Ranking applicants...")
        self._ranked_applicants = sorted(
            self._applicants,
            key=lambda applicant: applicant.viability_score,
            reverse=True,
        )

    def allocate_scholarships(self) -> List[Applicant]:
        """
        FR4: Allocates scholarships to the top-ranked applicants.

        This method orchestrates the scoring and ranking process before
        selecting the awardees.

        Returns:
            A list of the applicants who have been awarded scholarships.
        """
        self._compute_scores()
        self._rank_applicants()

        num_to_award = min(self.num_scholarships, len(self._ranked_applicants))
        print(f"Allocating {num_to_award} scholarships...")
        return self._ranked_applicants[:num_to_award]

    # --- Reporting ---

    def generate_report(self, awarded_applicants: List[Applicant]) -> None:
        """NFR2: Generates and prints a summary report of the awards."""
        self._print_report_header(awarded_applicants)
        self._print_awarded_applicants_table(awarded_applicants)
        self._print_full_ranking_table()
        self._print_report_footer()

    def _print_report_header(self, awarded_applicants: List[Applicant]) -> None:
        """Prints the main header and summary stats for the report."""
        print("\n" + "=" * 50)
        print("      SCHOLARSHIP MANAGEMENT SYSTEM - FINAL REPORT")
        print("=" * 50)
        print(f"\nTotal Scholarships Available: {self.num_scholarships}")
        print(f"Total Applicants Considered: {len(self._applicants)}")
        print(f"Scholarships Awarded: {len(awarded_applicants)}")

    def _print_awarded_applicants_table(
        self, awarded_applicants: List[Applicant]
    ) -> None:
        """Prints the table of scholarship recipients."""
        print("\n--- Awarded Applicant Details ---")
        if not awarded_applicants:
            print("\nNo scholarships were awarded.")
            return

        header = f"{'Rank':<6} {'Applicant ID':<15} {'Name':<25} {'Score':<10}"
        print(header)
        print("-" * len(header))
        for i, applicant in enumerate(awarded_applicants, 1):
            row = (
                f"{i:<6} {applicant.applicant_id:<15} "
                f"{applicant.name:<25} {applicant.viability_score:<10.2f}"
            )
            print(row)

    def _print_full_ranking_table(self) -> None:
        """Prints the table of all applicants, ranked by score."""
        print("\n--- Full Applicant Ranking ---")
        header = f"{'Rank':<6} {'Name':<25} {'Score':<10}"
        print(header)
        print("-" * len(header))
        for i, applicant in enumerate(self._ranked_applicants, 1):
            row = f"{i:<6} {applicant.name:<25} {applicant.viability_score:<10.2f}"
            print(row)

    @staticmethod
    def _print_report_footer() -> None:
        """Prints the concluding lines of the report."""
        print("\n" + "=" * 50)
        print("Report generation complete.")

# --- Data and Execution ---


def get_sample_applicant_data() -> List[Dict[str, Any]]:
    """
    NFR1: Provides in-memory sample data.

    This function isolates the data source from the core logic, satisfying
    the requirement for no external databases or services.

    Returns:
        A list of dictionaries representing raw applicant data.
    """
    return [
        {'id': 101, 'name': 'Eleanor Vance', 'academic': 95,
         'extracurricular': 80, 'progression': 92},
        {'id': 102, 'name': 'Marcus Thorne', 'academic': 88,
         'extracurricular': 95, 'progression': 85},
        {'id': 103, 'name': 'Liam Chen', 'academic': 98,
         'extracurricular': 70, 'progression': 95},
        {'id': 104, 'name': 'Sophia Rossi', 'academic': 85,
         'extracurricular': 88, 'progression': 82},
        {'id': 105, 'name': 'Jamal Ahmed', 'academic': 92,
         'extracurricular': 90, 'progression': 98},
        {'id': 106, 'name': 'Chloe Davis', 'academic': 78,
         'extracurricular': 85, 'progression': 75},
        {'id': 107, 'name': 'Ben Carter', 'academic': 81,
         'extracurricular': 75, 'progression': 70},
    ]


def main() -> int:
    """
    Main entry point for the application.

    Initializes the system, runs the scholarship allocation process,
    and generates the final report.
    """
    print("Starting the Scholarship Management System...")

    # --- System Configuration ---
    TOTAL_SCHOLARSHIPS_AVAILABLE = 3
    applicant_data = get_sample_applicant_data()

    try:
        # Initialize the system with data and configuration
        system = ScholarshipSystem(
            applicant_data, TOTAL_SCHOLARSHIPS_AVAILABLE
        )

        # Run the core allocation process
        awarded_applicants = system.allocate_scholarships()

        # Generate and print the final report
        system.generate_report(awarded_applicants)

    except ValueError as e:
        print(f"Error: An invalid value was encountered: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"An unexpected error occurred: {e}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())