# -*- coding: utf-8 -*-
"""
Scholarship Management System

This self-contained Python application manages the scholarship allocation process.
It scores, ranks, and awards scholarships to applicants based on a weighted
assessment of their academic performance, extracurricular activities, and
professional progression.
"""

import sys
from typing import List, Dict, Any, NamedTuple


class Applicant:
    """
    Represents a scholarship applicant.

    This class stores all relevant information for an applicant and includes
    a placeholder for their computed viability score.

    Attributes:
        applicant_id (int): A unique identifier for the applicant.
        name (str): The full name of the applicant.
        academic_score (float): A normalized score (0-100) representing academic performance.
        extracurricular_score (float): A normalized score (0-100) for extracurricular involvement.
        progression_score (float): A normalized score (0-100) for professional/academic progression.
        viability_score (float): The final computed score used for ranking. Initialized to 0.0.
    """

    def __init__(self, applicant_id: int, name: str, academic_score: float,
                 extracurricular_score: float, progression_score: float):
        """Initializes an Applicant instance."""
        if not all(0 <= score <= 100 for score in [academic_score, extracurricular_score, progression_score]):
            raise ValueError("All scores must be between 0 and 100.")

        self.applicant_id = applicant_id
        self.name = name
        self.academic_score = academic_score
        self.extracurricular_score = extracurricular_score
        self.progression_score = progression_score
        self.viability_score: float = 0.0

    def __repr__(self) -> str:
        """Provides a developer-friendly representation of the Applicant."""
        return (f"Applicant(id={self.applicant_id}, name='{self.name}', "
                f"score={self.viability_score:.2f})")


class ScholarshipSystem:
    """
    Manages the entire scholarship allocation workflow.

    This system handles loading applicant data, calculating viability scores,
    ranking applicants, allocating scholarships, and generating a summary report.
    It operates entirely in-memory without external dependencies.
    """

    # FR5: Weights are defined to give greater importance to academic and
    # professional progression (totaling 85%) over extracurriculars (15%).
    SCORING_WEIGHTS = {
        'academic': 0.50,
        'progression': 0.35,
        'extracurricular': 0.15
    }

    def __init__(self, applicant_data: List[Dict[str, Any]], num_scholarships: int):
        """
        Initializes the scholarship system.

        Args:
            applicant_data (List[Dict[str, Any]]): A list of dictionaries,
                where each dictionary contains the raw data for one applicant.
            num_scholarships (int): The total number of scholarships to be awarded.
        """
        if num_scholarships < 0:
            raise ValueError("Number of scholarships cannot be negative.")
        self.num_scholarships = num_scholarships
        self._applicants: List[Applicant] = self._load_applicants(applicant_data)
        self._ranked_applicants: List[Applicant] = []

    def _load_applicants(self, applicant_data: List[Dict[str, Any]]) -> List[Applicant]:
        """
        FR1: Loads applicant data from a list of dictionaries into Applicant objects.
        """
        return [
            Applicant(
                applicant_id=data['id'],
                name=data['name'],
                academic_score=data['academic'],
                extracurricular_score=data['extracurricular'],
                progression_score=data['progression']
            ) for data in applicant_data
        ]

    def _compute_scores(self) -> None:
        """
        FR2: Computes the viability score for each applicant based on predefined weights.
        """
        print("Computing viability scores for all applicants...")
        for applicant in self._applicants:
            score = (
                applicant.academic_score * self.SCORING_WEIGHTS['academic'] +
                applicant.extracurricular_score * self.SCORING_WEIGHTS['extracurricular'] +
                applicant.progression_score * self.SCORING_WEIGHTS['progression']
            )
            applicant.viability_score = round(score, 2)

    def _rank_applicants(self) -> None:
        """
        FR3: Ranks applicants in descending order based on their viability score.
        """
        print("Ranking applicants...")
        self._ranked_applicants = sorted(
            self._applicants,
            key=lambda app: app.viability_score,
            reverse=True
        )

    def allocate_scholarships(self) -> List[Applicant]:
        """
        FR4: Allocates scholarships to the top-ranked applicants.

        This method orchestrates the scoring and ranking process before selecting
        the awardees.

        Returns:
            List[Applicant]: A list of the applicants who have been awarded scholarships.
        """
        self._compute_scores()
        self._rank_applicants()

        num_to_award = min(self.num_scholarships, len(self._ranked_applicants))
        print(f"Allocating {num_to_award} scholarships...")
        return self._ranked_applicants[:num_to_award]

    def generate_report(self, awarded_applicants: List[Applicant]) -> None:
        """
        NFR2: Generates and prints a summary report of the scholarship awards.

        Args:
            awarded_applicants (List[Applicant]): The list of applicants who received awards.
        """
        print("\n" + "=" * 50)
        print("      SCHOLARSHIP MANAGEMENT SYSTEM - FINAL REPORT")
        print("=" * 50)
        print(f"\nTotal Scholarships Available: {self.num_scholarships}")
        print(f"Total Applicants Considered: {len(self._applicants)}")
        print(f"Scholarships Awarded: {len(awarded_applicants)}")
        print("\n--- Awarded Applicant Details ---")

        if not awarded_applicants:
            print("\nNo scholarships were awarded.")
        else:
            header = f"{'Rank':<6} {'Applicant ID':<15} {'Name':<25} {'Score':<10}"
            print(header)
            print("-" * len(header))
            for i, applicant in enumerate(awarded_applicants, 1):
                print(
                    f"{i:<6} {applicant.applicant_id:<15} "
                    f"{applicant.name:<25} {applicant.viability_score:<10.2f}"
                )

        print("\n--- Full Applicant Ranking ---")
        full_ranking_header = f"{'Rank':<6} {'Name':<25} {'Score':<10}"
        print(full_ranking_header)
        print("-" * len(full_ranking_header))
        for i, applicant in enumerate(self._ranked_applicants, 1):
             print(f"{i:<6} {applicant.name:<25} {applicant.viability_score:<10.2f}")

        print("\n" + "=" * 50)
        print("Report generation complete.")


def get_sample_applicant_data() -> List[Dict[str, Any]]:
    """
    NFR1: Provides in-memory sample data, removing the need for external data sources.

    Returns:
        A list of dictionaries representing raw applicant data.
    """
    return [
        {
            'id': 101, 'name': 'Eleanor Vance', 'academic': 95,
            'extracurricular': 80, 'progression': 92
        },
        {
            'id': 102, 'name': 'Marcus Thorne', 'academic': 88,
            'extracurricular': 95, 'progression': 85
        },
        {
            'id': 103, 'name': 'Liam Chen', 'academic': 98,
            'extracurricular': 70, 'progression': 95
        },
        {
            'id': 104, 'name': 'Sophia Rossi', 'academic': 85,
            'extracurricular': 88, 'progression': 82
        },
        {
            'id': 105, 'name': 'Jamal Ahmed', 'academic': 92,
            'extracurricular': 90, 'progression': 98
        },
        {
            'id': 106, 'name': 'Chloe Davis', 'academic': 78,
            'extracurricular': 85, 'progression': 75
        },
        {
            'id': 107, 'name': 'Ben Carter', 'academic': 81,
            'extracurricular': 75, 'progression': 70
        },
    ]


def main() -> int:
    """
    Main entry point for the application.
    
    Initializes the system, runs the scholarship allocation process,
    and generates the final report.
    """
    print("Starting the Scholarship Management System...")

    # --- System Configuration ---
    NUMBER_OF_SCHOLARSHIPS = 3
    applicant_data = get_sample_applicant_data()

    try:
        # Initialize the system
        system = ScholarshipSystem(applicant_data, NUMBER_OF_SCHOLARSHIPS)

        # Run the allocation process
        awarded_list = system.allocate_scholarships()

        # Generate and print the final report
        system.generate_report(awarded_list)

    except ValueError as e:
        print(f"Error: An invalid value was encountered: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"An unexpected error occurred: {e}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())