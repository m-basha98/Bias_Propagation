# Technical Documentation: Scholarship Management System

## 1. Overview

This document provides detailed technical documentation for the Scholarship Management System. The system is a self-contained Python application designed to manage the scholarship allocation process. It evaluates applicants based on multiple weighted criteria, ranks them, and allocates a predefined number of scholarships to the top candidates. The system operates entirely in-memory, requires no external dependencies, and generates a summary report of its operations.

The architecture is centered around two main components:
-   **`Applicant`**: A data class that models an individual applicant's information.
-   **`ScholarshipSystem`**: A class that encapsulates the core business logic for scoring, ranking, allocation, and reporting.

---

## 2. Module: `scholarship_management_system`

This is the main module containing all the code for the application.

### 2.1. Class: `Applicant`

A dataclass representing a single scholarship applicant. It stores personal details, performance scores, and the final calculated viability score. Using `@dataclass` simplifies the creation of this data-centric class.

#### **Attributes**

| Attribute               | Type    | Description                                                                                             |
| ----------------------- | ------- | ------------------------------------------------------------------------------------------------------- |
| `applicant_id`          | `int`   | A unique identifier for the applicant.                                                                  |
| `name`                  | `str`   | The full name of the applicant.                                                                         |
| `academic_score`        | `float` | A normalized score (0-100) representing academic performance.                                           |
| `extracurricular_score` | `float` | A normalized score (0-100) representing performance in extracurricular activities.                        |
| `progression_score`     | `float` | A normalized score (0-100) assessing continuous academic and professional progression.                  |
| `viability_score`       | `float` | The final weighted score computed by the system, used for ranking. It is initialized to `0.0` by default. |

#### **Methods**

##### `__post_init__(self)`

-   **Description**: A special dataclass method that is automatically called after the object has been initialized. It validates that the input scores (`academic_score`, `extracurricular_score`, `progression_score`) are all within the valid range of 0 to 100.
-   **Parameters**: None.
-   **Returns**: `None`.
-   **Raises**: `ValueError` if any score is outside the 0-100 range.

##### `__repr__(self)`

-   **Description**: Provides a developer-friendly, unambiguous string representation of the `Applicant` object, primarily used for debugging.
-   **Parameters**: None.
-   **Returns**: `str` - A string representation of the instance (e.g., `Applicant(id=101, name='Eleanor Vance', score=92.55)`).

---

### 2.2. Class: `ScholarshipSystem`

This class orchestrates the entire scholarship allocation workflow. It manages the applicant pool, calculates scores, ranks applicants, awards scholarships, and generates the final report.

#### **Class Attributes**

| Attribute         | Type               | Description                                                                                                                                                                                                                                                                          |
| ----------------- | ------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `SCORING_WEIGHTS` | `Dict[str, float]` | A dictionary defining the weights for each scoring component. This directly implements functional requirement **FR5**, giving greater weight to academic and progression scores. The current weights are `academic: 0.50`, `progression: 0.35`, and `extracurricular: 0.15`. |

#### **Methods**

##### `__init__(self, applicant_data, num_scholarships)`

-   **Description**: The constructor for the `ScholarshipSystem`. It initializes the system with the raw applicant data and the number of available scholarships. It also internally calls `_load_applicants` to process the raw data.
-   **Parameters**:
    -   `applicant_data` (`List[Dict[str, Any]]`): A list of dictionaries, where each dictionary contains the data for one applicant. Required keys are 'id', 'name', 'academic', 'extracurricular', and 'progression'.
    -   `num_scholarships` (`int`): The total number of scholarships to be awarded.
-   **Returns**: `None`.
-   **Raises**: `ValueError` if `num_scholarships` is a negative number.

##### `allocate_scholarships(self)`

-   **Description**: The primary public method that executes the core scholarship allocation process. It orchestrates the internal calls to compute scores (`_compute_scores`) and rank applicants (`_rank_applicants`) before selecting the top candidates. This method fulfills functional requirement **FR4**.
-   **Parameters**: None.
-   **Returns**: `List[Applicant]` - A list of the `Applicant` objects who have been awarded scholarships, sorted from highest to lowest score.

##### `generate_report(self, awarded_applicants)`

-   **Description**: Generates a formatted summary report and prints it to the standard output. The report includes summary statistics, a list of awarded applicants, and a full ranking of all candidates. This fulfills non-functional requirement **NFR2**.
-   **Parameters**:
    -   `awarded_applicants` (`List[Applicant]`): The list of scholarship recipients, as returned by `allocate_scholarships`.
-   **Returns**: `None`.

##### `_load_applicants(self, raw_data)`

-   **Description**: A private helper method that transforms the raw list of applicant dictionaries into a list of `Applicant` objects. This fulfills functional requirement **FR1**.
-   **Parameters**:
    -   `raw_data` (`List[Dict[str, Any]]`): The raw applicant data.
-   **Returns**: `List[Applicant]` - A list of instantiated `Applicant` objects.

##### `_compute_scores(self)`

-   **Description**: A private helper method that iterates through all loaded applicants and calculates their `viability_score` based on the predefined `SCORING_WEIGHTS`. The result is stored directly in each applicant's `viability_score` attribute. This fulfills functional requirement **FR2**.
-   **Parameters**: None.
-   **Returns**: `None`.

##### `_rank_applicants(self)`

-   **Description**: A private helper method that sorts the list of all applicants in descending order based on their `viability_score`. The sorted list is stored in the instance attribute `self._ranked_applicants`. This fulfills functional requirement **FR3**.
-   **Parameters**: None.
-   **Returns**: `None`.

##### `_print_report_header(self, awarded_applicants)`

-   **Description**: A private helper for printing the header and summary statistics section of the final report.
-   **Parameters**:
    -   `awarded_applicants` (`List[Applicant]`): The list of awarded applicants, used to count the number awarded.
-   **Returns**: `None`.

##### `_print_awarded_applicants_table(self, awarded_applicants)`

-   **Description**: A private helper for printing the formatted table of scholarship recipients.
-   **Parameters**:
    -   `awarded_applicants` (`List[Applicant]`): The list of awarded applicants to be displayed.
-   **Returns**: `None`.

##### `_print_full_ranking_table(self)`

-   **Description**: A private helper for printing the formatted table showing the full ranking of all applicants.
-   **Parameters**: None.
-   **Returns**: `None`.

##### `_print_report_footer(self)`

-   **Description**: A static private helper for printing the concluding lines of the report.
-   **Parameters**: None.
-   **Returns**: `None`.

---

### 2.3. Module-Level Functions

Functions defined at the module level to handle application startup and data provision.

#### `get_sample_applicant_data()`

-   **Description**: Provides a hardcoded, in-memory list of sample applicant data. This function ensures that the application can run without any external files, databases, or services, fulfilling non-functional requirement **NFR1**.
-   **Parameters**: None.
-   **Returns**: `List[Dict[str, Any]]` - A list of dictionaries, each representing an applicant.

#### `main()`

-   **Description**: The main entry point for the application. It sets up the system configuration (e.g., number of scholarships), initializes the `ScholarshipSystem`, executes the allocation process, and generates the final report. It also includes basic error handling for a graceful exit.
-   **Parameters**: None.
-   **Returns**: `int` - An exit code for the shell. `0` indicates successful execution, while `1` indicates an error occurred.

---

## 3. Execution Flow

The application is executed by running the Python script directly.

1.  The `if __name__ == "__main__"` block calls the `main()` function.
2.  `main()` retrieves the sample applicant data from `get_sample_applicant_data()` and defines the number of available scholarships.
3.  An instance of `ScholarshipSystem` is created with the data and configuration.
4.  The `allocate_scholarships()` method is called on the system instance.
    a.  `_compute_scores()` is called internally to calculate the viability score for each applicant.
    b.  `_rank_applicants()` is called internally to sort all applicants by score.
    c.  The top `N` applicants are selected and returned as a list.
5.  The `generate_report()` method is called, passing in the list of awarded applicants.
6.  The report is printed to the console, showing a summary, the list of winners, and the full ranking.
7.  The application exits with a status code of `0` on success or `1` on error.