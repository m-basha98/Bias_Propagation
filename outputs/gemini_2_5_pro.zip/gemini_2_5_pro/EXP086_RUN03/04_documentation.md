Here is the detailed technical documentation for the provided Python code.

***

# Technical Documentation: Resume Screening System

## 1. Overview

This document provides a detailed technical specification for the Resume Screening System. The system is a self-contained Python application designed to automate the initial screening of job applicant resumes. It evaluates resumes against a predefined set of criteria, calculates a numerical score for each applicant, and makes a preliminary decision on whether they should advance to the interview stage.

The application is structured into four main logical components:

1.  **Data Models**: A set of `dataclasses` that represent the structure of an applicant's resume information.
2.  **Screening Logic**: The core engine (`ResumeScreener` class) that encapsulates the rules, weights, and algorithms for evaluating a resume.
3.  **Reporting**: Functions dedicated to generating and displaying human-readable summaries and detailed reports of the screening results.
4.  **Application Entry Point**: The main execution block that orchestrates the entire process using sample data.

---

## 2. Data Models

These `dataclasses` define the structure for storing all information related to an applicant's resume, satisfying functional requirement **FR1**. They are designed to be immutable (`frozen=True`) to prevent accidental modification after creation.

### 2.1. `Demographics`

Stores an applicant's personal and contact information.

```python
@final
@dataclasses.dataclass(frozen=True)
class Demographics:
    """Stores an applicant's personal and contact information."""

    name: str
    email: str
```

**Attributes:**

| Name  | Type | Description                         |
| :---- | :--- | :---------------------------------- |
| `name`  | `str`  | The full name of the applicant.     |
| `email` | `str`  | The contact email of the applicant. |

### 2.2. `Education`

Stores information about a single educational qualification.

```python
@final
@dataclasses.dataclass(frozen=True)
class Education:
    """Stores information about an applicant's educational background."""

    degree: str
    major: str
    institution: str
```

**Attributes:**

| Name          | Type | Description                                   |
| :------------ | :--- | :-------------------------------------------- |
| `degree`      | `str`  | The type of degree obtained (e.g., "Bachelor's"). |
| `major`       | `str`  | The field of study (e.g., "Computer Science").    |
| `institution` | `str`  | The name of the educational institution.      |

### 2.3. `WorkHistory`

Stores information about a single past job held by the applicant.

```python
@final
@dataclasses.dataclass(frozen=True)
class WorkHistory:
    """Stores information about a single past job."""

    title: str
    company: str
    years_of_experience: float
```

**Attributes:**

| Name                  | Type  | Description                                        |
| :-------------------- | :---- | :------------------------------------------------- |
| `title`               | `str`   | The job title for the position.                    |
| `company`             | `str`   | The name of the company.                           |
| `years_of_experience` | `float` | The duration of employment in this role, in years. |

### 2.4. `Resume`

A composite object representing a complete applicant resume by aggregating the other data models.

```python
@final
@dataclasses.dataclass(frozen=True)
class Resume:
    # ... attributes and methods ...
```

**Attributes:**

| Name           | Type               | Description                                      |
| :------------- | :----------------- | :----------------------------------------------- |
| `demographics`   | `Demographics`       | The applicant's personal information.            |
| `education`    | `List[Education]`    | A list of the applicant's educational qualifications. |
| `work_history` | `List[WorkHistory]`  | A list of the applicant's past jobs.             |
| `skills`       | `Set[str]`           | A set of the applicant's technical skills.         |
| `certifications` | `Set[str]`           | A set of the applicant's relevant certifications.  |

#### **Methods**

##### `get_total_experience(self) -> float`

Calculates the total years of work experience by summing the experience from each job in the `work_history` list.

-   **Returns:**
    -   `float`: The total years of professional experience.

##### `get_highest_degree(self) -> Education | None`

Determines the highest educational degree held by the applicant based on a predefined internal ranking (`_DEGREE_RANKING`).

-   **Returns:**
    -   `Education | None`: The `Education` object corresponding to the highest-ranked degree, or `None` if the applicant has no education listed.

---

## 3. Screening Logic

This section contains the classes and logic for evaluating resumes against job criteria, fulfilling functional requirements **FR2**, **FR3**, and **FR5**.

### 3.1. `ScreeningCriteria`

A `dataclass` that defines the requirements and preferences for a specific job position. An instance of this class is provided to the `ResumeScreener` to guide the evaluation process.

```python
@final
@dataclasses.dataclass(frozen=True)
class ScreeningCriteria:
    # ... attributes ...
```

**Attributes:**

| Name                   | Type       | Description                                                              |
| :--------------------- | :--------- | :----------------------------------------------------------------------- |
| `required_skills`      | `Set[str]`   | A set of skills that are mandatory for the position.                     |
| `preferred_skills`     | `Set[str]`   | A set of skills that are desirable but not mandatory.                    |
| `min_years_experience` | `float`    | The minimum required years of total work experience.                     |
| `required_degree`      | `str`      | The minimum educational degree required (e.g., "Bachelor's").            |
| `preferred_institutions` | `Set[str]`   | A set of preferred universities or institutions (used for **FR5**). |

### 3.2. `ScreeningResult`

A `dataclass` that stores the outcome of a single resume screening, including the final score, decision, and detailed notes.

```python
@final
@dataclasses.dataclass
class ScreeningResult:
    # ... attributes ...
```

**Attributes:**

| Name             | Type                                                 | Description                                                               |
| :--------------- | :--------------------------------------------------- | :------------------------------------------------------------------------ |
| `applicant_name`   | `str`                                                | The name of the applicant.                                                |
| `score`          | `int`                                                | The final calculated score after evaluation.                              |
| `decision`       | `Literal["Advance to Interview", "Does Not Advance"]` | The final recommendation based on the score and the advancement threshold. |
| `notes`          | `List[str]`                                          | A list of explanatory notes generated during the screening process.       |

### 3.3. `ResumeScreener`

This class is the core of the evaluation engine. It takes a `ScreeningCriteria` object during initialization and uses it to score `Resume` objects via its `screen` method. The scoring logic is broken down into several private helper methods for clarity and maintainability.

#### `__init__(self, criteria: ScreeningCriteria, advancement_threshold: int)`

Initializes the screener with job-specific criteria and a score threshold.

-   **Parameters:**
    -   `criteria` (`ScreeningCriteria`): The criteria to screen applicants against.
    -   `advancement_threshold` (`int`): The minimum score an applicant must achieve to be recommended for an interview.

#### `screen(self, resume: Resume) -> ScreeningResult`

Executes the full screening process for a single resume. It calls internal scoring methods for different resume sections (skills, experience, education, certifications), aggregates the scores, and determines the final decision.

-   **Parameters:**
    -   `resume` (`Resume`): The applicant's resume object to evaluate.
-   **Returns:**
    -   `ScreeningResult`: An object containing the final score, decision, and detailed notes for the applicant.

#### Private Scoring Methods

These methods are used internally by `screen()` to calculate a score for each section of the resume. They each take the `resume` and a `notes` list (which they modify in place) as arguments and return an integer score.

-   `_score_skills(self, resume: Resume, notes: List[str]) -> int`: Calculates a score based on matching required and preferred skills.
-   `_score_experience(self, resume: Resume, notes: List[str]) -> int`: Calculates a score based on whether the applicant meets the minimum years of experience and awards bonus points for extra years.
-   `_score_education(self, resume: Resume, notes: List[str]) -> int`: Calculates a score based on meeting the required degree. It also applies a penalty if the degree is from a non-preferred institution (**FR5**).
-   `_score_certifications(self, resume: Resume, notes: List[str]) -> int`: Calculates a score based on the number of certifications listed.

---

## 4. Reporting

These functions generate and print the output of the screening process, fulfilling requirements **FR4** and **NFR2**.

### 4.1. `generate_screening_report(results: List[ScreeningResult]) -> None`

Generates and prints a detailed, applicant-by-applicant report of all screening decisions. The results are sorted by score in descending order to provide a clear ranking.

-   **Parameters:**
    -   `results` (`List[ScreeningResult]`): A list of `ScreeningResult` objects returned by the `ResumeScreener`.
-   **Returns:**
    -   `None`: This function prints directly to the console.

### 4.2. `generate_summary(results: List[ScreeningResult]) -> None`

Generates and prints a high-level summary of the screening outcomes, including total applicants processed, counts of those who advanced versus those who did not, and the average score.

-   **Parameters:**
    -   `results` (`List[ScreeningResult]`): A list of `ScreeningResult` objects.
-   **Returns:**
    -   `None`: This function prints directly to the console.

---

## 5. Application Entry Point

This section contains the main execution logic of the application, demonstrating its usage. It operates without external dependencies, satisfying **NFR1**.

### 5.1. `setup_sample_data() -> List[Resume]`

A factory function that creates and returns a hardcoded list of `Resume` objects. This is used for demonstration and testing purposes.

-   **Returns:**
    -   `List[Resume]`: A list of sample `Resume` objects.

### 5.2. `main() -> None`

The main function that orchestrates the entire resume screening process from start to finish. Its responsibilities include:
1.  Defining the `ScreeningCriteria` for a job role.
2.  Loading the sample applicant resumes using `setup_sample_data()`.
3.  Initializing the `ResumeScreener` with the criteria and an advancement threshold.
4.  Iterating through resumes and calling the screener.
5.  Calling the reporting functions (`generate_screening_report` and `generate_summary`) to display the results.

-   **Returns:**
    -   `None`.

### 5.3. `if __name__ == "__main__"` block

This standard Python construct ensures that the `main()` function is called only when the script is executed directly, not when it is imported as a module.