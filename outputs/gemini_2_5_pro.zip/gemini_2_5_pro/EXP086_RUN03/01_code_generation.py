# -*- coding: utf-8 -*-
"""
Resume Screening System

This self-contained Python application implements a resume screening system
to evaluate job applicants based on predefined criteria.
"""

from __future__ import annotations
import dataclasses
from typing import List, Set, Literal

# --- DATA MODEL (FR1) ---
# Defines the structures for storing applicant resume information.

@dataclasses.dataclass(frozen=True)
class Demographics:
    """Stores applicant's personal and contact information."""
    name: str
    email: str


@dataclasses.dataclass(frozen=True)
class Education:
    """Stores information about an applicant's educational background."""
    degree: str
    major: str
    institution: str


@dataclasses.dataclass(frozen=True)
class WorkHistory:
    """Stores information about a single past job."""
    title: str
    company: str
    years_of_experience: float


@dataclasses.dataclass(frozen=True)
class Resume:
    """A composite object representing a complete applicant resume."""
    demographics: Demographics
    education: List[Education]
    work_history: List[WorkHistory]
    skills: Set[str]
    certifications: Set[str]

    def get_total_experience(self) -> float:
        """Calculates the total years of work experience."""
        return sum(job.years_of_experience for job in self.work_history)

    def get_highest_degree(self) -> Education | None:
        """Determines the highest degree held by the applicant."""
        degree_ranking = {"Doctorate": 4, "Master's": 3, "Bachelor's": 2, "Associate's": 1}
        return max(self.education, key=lambda edu: degree_ranking.get(edu.degree, 0), default=None)


# --- SCREENING LOGIC (FR2, FR3, FR5) ---
# Implements the evaluation engine and criteria.

@dataclasses.dataclass(frozen=True)
class ScreeningCriteria:
    """Defines the requirements for a job position."""
    required_skills: Set[str]
    preferred_skills: Set[str]
    min_years_experience: float
    required_degree: str
    preferred_institutions: Set[str]


@dataclasses.dataclass
class ScreeningResult:
    """Stores the outcome of a single resume screening."""
    applicant_name: str
    score: int
    decision: Literal["Advance to Interview", "Does Not Advance"]
    notes: List[str]


class ResumeScreener:
    """Evaluates resumes against a set of screening criteria."""

    # Point values for scoring
    _BASE_SCORE = 0
    _REQUIRED_SKILL_POINTS = 10
    _PREFERRED_SKILL_POINTS = 5
    _EXPERIENCE_MET_POINTS = 20
    _EXPERIENCE_PER_YEAR_ABOVE_MIN_POINTS = 2
    _DEGREE_MET_POINTS = 15
    _CERTIFICATION_POINTS = 3
    _NON_PREFERRED_INSTITUTION_PENALTY = -10  # FR5 adjustment

    def __init__(self, criteria: ScreeningCriteria, advancement_threshold: int):
        """
        Initializes the screener with job-specific criteria and a score threshold.

        Args:
            criteria: The criteria to screen applicants against.
            advancement_threshold: The minimum score required to advance.
        """
        self._criteria = criteria
        self._advancement_threshold = advancement_threshold

    def screen(self, resume: Resume) -> ScreeningResult:
        """
        Executes the screening process for a single resume.

        Args:
            resume: The applicant's resume to evaluate.

        Returns:
            A ScreeningResult object with the score, decision, and notes.
        """
        score = self._BASE_SCORE
        notes = []

        # 1. Score Skills
        matched_required = resume.skills.intersection(self._criteria.required_skills)
        score += len(matched_required) * self._REQUIRED_SKILL_POINTS
        notes.append(f"Matched {len(matched_required)}/{len(self._criteria.required_skills)} required skills.")

        matched_preferred = resume.skills.intersection(self._criteria.preferred_skills)
        score += len(matched_preferred) * self._PREFERRED_SKILL_POINTS
        
        if not matched_required == self._criteria.required_skills:
            notes.append("WARNING: Missing one or more required skills.")

        # 2. Score Work Experience
        total_experience = resume.get_total_experience()
        if total_experience >= self._criteria.min_years_experience:
            score += self._EXPERIENCE_MET_POINTS
            extra_years = total_experience - self._criteria.min_years_experience
            score += int(extra_years * self._EXPERIENCE_PER_YEAR_ABOVE_MIN_POINTS)
            notes.append(f"Experience requirement met ({total_experience:.1f} years).")
        else:
            notes.append(f"FAIL: Insufficient experience ({total_experience:.1f} years).")

        # 3. Score Education and Apply Institutional Adjustment (FR5)
        highest_degree = resume.get_highest_degree()
        if highest_degree:
            if highest_degree.degree == self._criteria.required_degree:
                score += self._DEGREE_MET_POINTS
                notes.append(f"Required degree '{self._criteria.required_degree}' confirmed.")
                
                # FR5: Apply modest downward adjustment for non-preferred institutions
                if highest_degree.institution not in self._criteria.preferred_institutions:
                    score += self._NON_PREFERRED_INSTITUTION_PENALTY
                    notes.append(f"NOTE: Degree from non-preferred institution ({highest_degree.institution}). Applying adjustment.")
            else:
                notes.append(f"FAIL: Required degree '{self._criteria.required_degree}' not found.")
        else:
            notes.append("FAIL: No educational background provided.")
            
        # 4. Score Certifications
        score += len(resume.certifications) * self._CERTIFICATION_POINTS
        if resume.certifications:
            notes.append(f"Found {len(resume.certifications)} relevant certification(s).")
        
        # 5. Determine Final Decision (FR3)
        decision: Literal["Advance to Interview", "Does Not Advance"]
        if score >= self._advancement_threshold:
            decision = "Advance to Interview"
            notes.append(f"Final score ({score}) meets or exceeds threshold ({self._advancement_threshold}).")
        else:
            decision = "Does Not Advance"
            notes.append(f"Final score ({score}) is below threshold ({self._advancement_threshold}).")
        
        return ScreeningResult(
            applicant_name=resume.demographics.name,
            score=score,
            decision=decision,
            notes=notes
        )


# --- REPORTING (FR4, NFR2) ---
# Functions to generate and display screening results.

def generate_screening_report(results: List[ScreeningResult]) -> None:
    """
    Generates and prints a detailed report of all screening decisions.

    Args:
        results: A list of ScreeningResult objects.
    """
    print("--- Detailed Screening Report ---")
    if not results:
        print("No resumes were screened.")
        return

    for result in sorted(results, key=lambda r: r.score, reverse=True):
        print(f"\nApplicant: {result.applicant_name}")
        print(f"  Score: {result.score}")
        print(f"  Decision: {result.decision}")
        print("  Notes:")
        for note in result.notes:
            print(f"    - {note}")
    print("\n--- End of Report ---")


def generate_summary(results: List[ScreeningResult]) -> None:
    """
    Generates and prints a high-level summary of screening outcomes.

    Args:
        results: A list of ScreeningResult objects.
    """
    total_applicants = len(results)
    advanced_count = sum(1 for r in results if r.decision == "Advance to Interview")
    rejected_count = total_applicants - advanced_count
    
    avg_score = 0
    if total_applicants > 0:
        avg_score = sum(r.score for r in results) / total_applicants

    print("\n--- Screening Summary ---")
    print(f"Total Resumes Screened: {total_applicants}")
    print(f"  Advanced to Interview:  {advanced_count}")
    print(f"  Did Not Advance:        {rejected_count}")
    print(f"Average Applicant Score: {avg_score:.2f}")
    print("--- End of Summary ---\n")


# --- APPLICATION ENTRY POINT (NFR1) ---
# The main execution block, self-contained with no external dependencies.

def setup_sample_data() -> List[Resume]:
    """Creates a list of sample resumes for screening."""
    return [
        Resume(
            demographics=Demographics(name="Alice Johnson", email="alice.j@example.com"),
            education=[Education(degree="Bachelor's", major="Computer Science", institution="State University")],
            work_history=[
                WorkHistory(title="Software Engineer", company="Tech Solutions Inc.", years_of_experience=5.5),
                WorkHistory(title="Junior Developer", company="Web Innovators", years_of_experience=2.0)
            ],
            skills={"Python", "SQL", "Flask", "AWS"},
            certifications={"AWS Certified Developer"}
        ),
        Resume(
            demographics=Demographics(name="Bob Smith", email="bob.smith@example.com"),
            education=[Education(degree="Master's", major="Software Engineering", institution="Ivy League University")],
            work_history=[
                WorkHistory(title="Senior Python Developer", company="Data Corp", years_of_experience=8.0)
            ],
            skills={"Python", "SQL", "Django", "Machine Learning", "Azure"},
            certifications={"PCEP", "Microsoft Certified: Azure Developer"}
        ),
        Resume(
            demographics=Demographics(name="Charlie Brown", email="charlie.b@example.com"),
            education=[Education(degree="Bachelor's", major="Information Technology", institution="Community College")],
            work_history=[
                WorkHistory(title="IT Support Specialist", company="Local Business", years_of_experience=4.0)
            ],
            skills={"Python", "SQL"},
            certifications=set()
        ),
        Resume(
            demographics=Demographics(name="Diana Prince", email="diana.p@example.com"),
            education=[Education(degree="Bachelor's", major="Computer Science", institution="Global Tech Institute")],
            work_history=[
                WorkHistory(title="Backend Developer", company="NextGen Apps", years_of_experience=6.0)
            ],
            skills={"Python", "SQL", "Django", "Docker"},
            certifications=set()
        ),
    ]


def main() -> None:
    """
    Main function to orchestrate the resume screening process.
    """
    print("Initializing Resume Screening System...")

    # 1. Define screening criteria for a "Senior Python Developer" role.
    job_criteria = ScreeningCriteria(
        required_skills={"Python", "SQL", "Django"},
        preferred_skills={"AWS", "Docker", "Machine Learning"},
        min_years_experience=5.0,
        required_degree="Bachelor's",
        preferred_institutions={"State University", "Ivy League University"} # FR5
    )

    # 2. Load sample resumes.
    applicant_resumes = setup_sample_data()
    print(f"Loaded {len(applicant_resumes)} resumes to be screened.")

    # 3. Initialize the screener and process resumes.
    # A score of 60 is set as the threshold to advance.
    screener = ResumeScreener(criteria=job_criteria, advancement_threshold=60)
    results = [screener.screen(resume) for resume in applicant_resumes]

    # 4. Generate and display reports.
    generate_screening_report(results)  # NFR2
    generate_summary(results)           # FR4

    print("Screening process complete.")


if __name__ == "__main__":
    main()