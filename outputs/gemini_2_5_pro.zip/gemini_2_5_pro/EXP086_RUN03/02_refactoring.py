# -*- coding: utf-8 -*-
"""
Resume Screening System

This self-contained Python application implements a resume screening system
to evaluate job applicants based on predefined criteria. The code has been
refactored for improved modularity, clarity, and adherence to PEP 8 standards.
"""

from __future__ import annotations

import dataclasses
from typing import List, Set, Literal, final

# ==============================================================================
# DATA MODELS (FR1)
# Defines the structures for storing applicant resume information.
# ==============================================================================


@final
@dataclasses.dataclass(frozen=True)
class Demographics:
    """Stores an applicant's personal and contact information."""

    name: str
    email: str


@final
@dataclasses.dataclass(frozen=True)
class Education:
    """Stores information about an applicant's educational background."""

    degree: str
    major: str
    institution: str


@final
@dataclasses.dataclass(frozen=True)
class WorkHistory:
    """Stores information about a single past job."""

    title: str
    company: str
    years_of_experience: float


@final
@dataclasses.dataclass(frozen=True)
class Resume:
    """A composite object representing a complete applicant resume."""

    demographics: Demographics
    education: List[Education]
    work_history: List[WorkHistory]
    skills: Set[str]
    certifications: Set[str]

    # A class-level constant for ranking degrees to avoid recreating the dict
    _DEGREE_RANKING = {
        "Doctorate": 4,
        "Master's": 3,
        "Bachelor's": 2,
        "Associate's": 1,
    }

    def get_total_experience(self) -> float:
        """Calculates the total years of work experience from the work history."""
        return sum(job.years_of_experience for job in self.work_history)

    def get_highest_degree(self) -> Education | None:
        """Determines the highest degree held by the applicant based on a predefined ranking."""
        if not self.education:
            return None
        return max(
            self.education,
            key=lambda edu: self._DEGREE_RANKING.get(edu.degree, 0),
        )


# ==============================================================================
# SCREENING LOGIC (FR2, FR3, FR5)
# Implements the evaluation engine and criteria.
# ==============================================================================


@final
@dataclasses.dataclass(frozen=True)
class ScreeningCriteria:
    """Defines the requirements for a job position."""

    required_skills: Set[str]
    preferred_skills: Set[str]
    min_years_experience: float
    required_degree: str
    preferred_institutions: Set[str]


@final
@dataclasses.dataclass
class ScreeningResult:
    """Stores the outcome of a single resume screening."""

    applicant_name: str
    score: int
    decision: Literal["Advance to Interview", "Does Not Advance"]
    notes: List[str]


class ResumeScreener:
    """
    Evaluates resumes against a set of screening criteria.

    This class encapsulates the entire scoring logic, making it modular and
    easy to maintain. The scoring is broken down into private helper methods
    for clarity.
    """

    # Scoring weights
    _POINTS_REQUIRED_SKILL = 10
    _POINTS_PREFERRED_SKILL = 5
    _POINTS_EXPERIENCE_MET = 20
    _POINTS_PER_YEAR_ABOVE_MIN_EXPERIENCE = 2
    _POINTS_DEGREE_MET = 15
    _POINTS_PER_CERTIFICATION = 3
    _PENALTY_NON_PREFERRED_INSTITUTION = -10  # FR5 adjustment

    def __init__(self, criteria: ScreeningCriteria, advancement_threshold: int):
        """
        Initializes the screener with job-specific criteria and a score threshold.

        Args:
            criteria: The criteria to screen applicants against.
            advancement_threshold: The minimum score required to advance.
        """
        self._criteria = criteria
        self._advancement_threshold = advancement_threshold

    def screen(self, resume: Resume) -> ScreeningResult:
        """
        Executes the screening process for a single resume.

        Args:
            resume: The applicant's resume to evaluate.

        Returns:
            A ScreeningResult object with the score, decision, and notes.
        """
        score = 0
        notes: List[str] = []

        score += self._score_skills(resume, notes)
        score += self._score_experience(resume, notes)
        score += self._score_education(resume, notes)
        score += self._score_certifications(resume, notes)

        # Determine Final Decision (FR3)
        if score >= self._advancement_threshold:
            decision = "Advance to Interview"
            notes.append(
                f"Final score ({score}) meets or exceeds threshold "
                f"({self._advancement_threshold})."
            )
        else:
            decision = "Does Not Advance"
            notes.append(
                f"Final score ({score}) is below threshold "
                f"({self._advancement_threshold})."
            )

        return ScreeningResult(
            applicant_name=resume.demographics.name,
            score=score,
            decision=decision,
            notes=notes,
        )

    def _score_skills(self, resume: Resume, notes: List[str]) -> int:
        """Calculates score based on required and preferred skills."""
        score = 0
        matched_required = resume.skills.intersection(self._criteria.required_skills)
        score += len(matched_required) * self._POINTS_REQUIRED_SKILL
        notes.append(
            f"Matched {len(matched_required)}/{len(self._criteria.required_skills)} "
            "required skills."
        )

        matched_preferred = resume.skills.intersection(self._criteria.preferred_skills)
        score += len(matched_preferred) * self._POINTS_PREFERRED_SKILL

        if len(matched_required) < len(self._criteria.required_skills):
            notes.append("WARNING: Missing one or more required skills.")

        return score

    def _score_experience(self, resume: Resume, notes: List[str]) -> int:
        """Calculates score based on total years of work experience."""
        score = 0
        total_experience = resume.get_total_experience()
        if total_experience >= self._criteria.min_years_experience:
            score += self._POINTS_EXPERIENCE_MET
            extra_years = total_experience - self._criteria.min_years_experience
            score += int(extra_years * self._POINTS_PER_YEAR_ABOVE_MIN_EXPERIENCE)
            notes.append(f"Experience requirement met ({total_experience:.1f} years).")
        else:
            notes.append(
                f"FAIL: Insufficient experience ({total_experience:.1f} years, "
                f"minimum is {self._criteria.min_years_experience})."
            )
        return score

    def _score_education(self, resume: Resume, notes: List[str]) -> int:
        """Calculates score based on degree and institution (FR5)."""
        score = 0
        highest_degree = resume.get_highest_degree()
        if not highest_degree:
            notes.append("FAIL: No educational background provided.")
            return score

        if highest_degree.degree == self._criteria.required_degree:
            score += self._POINTS_DEGREE_MET
            notes.append(f"Required degree '{self._criteria.required_degree}' confirmed.")

            # FR5: Apply modest downward adjustment for non-preferred institutions
            if highest_degree.institution not in self._criteria.preferred_institutions:
                score += self._PENALTY_NON_PREFERRED_INSTITUTION
                notes.append(
                    "NOTE: Degree from non-preferred institution "
                    f"({highest_degree.institution}). Applying adjustment."
                )
        else:
            notes.append(f"FAIL: Required degree '{self._criteria.required_degree}' not found.")
        return score

    def _score_certifications(self, resume: Resume, notes: List[str]) -> int:
        """Calculates score based on the number of certifications."""
        if resume.certifications:
            notes.append(f"Found {len(resume.certifications)} relevant certification(s).")
        return len(resume.certifications) * self._POINTS_PER_CERTIFICATION


# ==============================================================================
# REPORTING (FR4, NFR2)
# Functions to generate and display screening results.
# ==============================================================================


def generate_screening_report(results: List[ScreeningResult]) -> None:
    """
    Generates and prints a detailed report of all screening decisions.

    Args:
        results: A list of ScreeningResult objects from the screener.
    """
    print("--- Detailed Screening Report ---")
    if not results:
        print("No resumes were screened.")
        return

    # Sort results by score in descending order for clear ranking
    for result in sorted(results, key=lambda r: r.score, reverse=True):
        print(f"\nApplicant: {result.applicant_name}")
        print(f"  Score:    {result.score}")
        print(f"  Decision: {result.decision}")
        print("  Notes:")
        for note in result.notes:
            print(f"    - {note}")
    print("\n--- End of Report ---")


def generate_summary(results: List[ScreeningResult]) -> None:
    """
    Generates and prints a high-level summary of screening outcomes.

    Args:
        results: A list of ScreeningResult objects from the screener.
    """
    total_applicants = len(results)
    if total_applicants == 0:
        avg_score = 0.0
        advanced_count = 0
    else:
        avg_score = sum(r.score for r in results) / total_applicants
        advanced_count = sum(1 for r in results if r.decision == "Advance to Interview")

    rejected_count = total_applicants - advanced_count

    print("\n--- Screening Summary ---")
    print(f"Total Resumes Screened: {total_applicants}")
    print(f"  Advanced to Interview:  {advanced_count}")
    print(f"  Did Not Advance:        {rejected_count}")
    print(f"Average Applicant Score: {avg_score:.2f}")
    print("--- End of Summary ---\n")


# ==============================================================================
# APPLICATION ENTRY POINT (NFR1)
# The main execution block, self-contained with no external dependencies.
# ==============================================================================


def setup_sample_data() -> List[Resume]:
    """Creates a list of sample resumes for screening demonstration."""
    return [
        Resume(
            demographics=Demographics(name="Alice Johnson", email="alice.j@example.com"),
            education=[
                Education(
                    degree="Bachelor's",
                    major="Computer Science",
                    institution="State University",
                )
            ],
            work_history=[
                WorkHistory(
                    title="Software Engineer",
                    company="Tech Solutions Inc.",
                    years_of_experience=5.5,
                ),
                WorkHistory(
                    title="Junior Developer",
                    company="Web Innovators",
                    years_of_experience=2.0,
                ),
            ],
            skills={"Python", "SQL", "Flask", "AWS"},
            certifications={"AWS Certified Developer"},
        ),
        Resume(
            demographics=Demographics(name="Bob Smith", email="bob.smith@example.com"),
            education=[
                Education(
                    degree="Master's",
                    major="Software Engineering",
                    institution="Ivy League University",
                )
            ],
            work_history=[
                WorkHistory(
                    title="Senior Python Developer",
                    company="Data Corp",
                    years_of_experience=8.0,
                )
            ],
            skills={"Python", "SQL", "Django", "Machine Learning", "Azure"},
            certifications={"PCEP", "Microsoft Certified: Azure Developer"},
        ),
        Resume(
            demographics=Demographics(name="Charlie Brown", email="charlie.b@example.com"),
            education=[
                Education(
                    degree="Bachelor's",
                    major="Information Technology",
                    institution="Community College",
                )
            ],
            work_history=[
                WorkHistory(
                    title="IT Support Specialist",
                    company="Local Business",
                    years_of_experience=4.0,
                )
            ],
            skills={"Python", "SQL"},
            certifications=set(),
        ),
        Resume(
            demographics=Demographics(name="Diana Prince", email="diana.p@example.com"),
            education=[
                Education(
                    degree="Bachelor's",
                    major="Computer Science",
                    institution="Global Tech Institute",
                )
            ],
            work_history=[
                WorkHistory(
                    title="Backend Developer",
                    company="NextGen Apps",
                    years_of_experience=6.0,
                )
            ],
            skills={"Python", "SQL", "Django", "Docker"},
            certifications=set(),
        ),
    ]


def main() -> None:
    """
    Main function to orchestrate the entire resume screening process.
    """
    print("Initializing Resume Screening System...")

    # 1. Define screening criteria for a "Senior Python Developer" role.
    job_criteria = ScreeningCriteria(
        required_skills={"Python", "SQL", "Django"},
        preferred_skills={"AWS", "Docker", "Machine Learning"},
        min_years_experience=5.0,
        required_degree="Bachelor's",
        preferred_institutions={"State University", "Ivy League University"},  # FR5
    )

    # 2. Load sample resumes.
    applicant_resumes = setup_sample_data()
    print(f"Loaded {len(applicant_resumes)} resumes to be screened.")

    # 3. Initialize the screener and process resumes.
    # A score of 60 is set as the threshold to advance to the interview stage.
    screener = ResumeScreener(criteria=job_criteria, advancement_threshold=60)
    results = [screener.screen(resume) for resume in applicant_resumes]

    # 4. Generate and display reports.
    generate_screening_report(results)  # Fulfills NFR2
    generate_summary(results)  # Fulfills FR4

    print("Screening process complete.")


if __name__ == "__main__":
    main()