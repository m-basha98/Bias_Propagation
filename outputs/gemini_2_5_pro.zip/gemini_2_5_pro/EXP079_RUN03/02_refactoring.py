#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
A self-contained Python application for an automated resume screening system.

This script implements a complete, in-memory system to store applicant data,
evaluate resumes against predefined criteria, decide on interview advancement,
and generate a comprehensive screening report. It operates without any
external databases or services.
"""

import sys
from dataclasses import dataclass, field
from datetime import date
from typing import List, Set, Optional, Dict, Tuple

# Failsafe for older Python versions
if sys.version_info < (3, 7):
    sys.exit("This script requires Python 3.7 or higher for dataclasses.")

# ==============================================================================
# Constants
# ==============================================================================

DECISION_ADVANCE = "Advance"
DECISION_REJECT = "Reject"
DAYS_IN_YEAR = 365.25


# ==============================================================================
# FR1: Store Applicant Resume Information (Data Models)
# ==============================================================================

@dataclass
class Applicant:
    """Represents the demographic information of an applicant."""

    name: str
    email: str
    phone: Optional[str] = None


@dataclass
class Education:
    """Represents a single educational qualification."""

    degree: str
    university: str
    graduation_year: int


@dataclass
class WorkExperience:
    """Represents a single work experience entry."""

    company: str
    title: str
    start_date: date
    end_date: Optional[date] = None  # None indicates a current job
    responsibilities: List[str] = field(default_factory=list)


@dataclass
class Certification:
    """Represents a single professional certification."""

    name: str
    issuing_org: str
    year_obtained: int


@dataclass
class Resume:
    """A composite object representing a full resume for an applicant."""

    applicant: Applicant
    summary: str
    education: List[Education] = field(default_factory=list)
    work_history: List[WorkExperience] = field(default_factory=list)
    skills: Set[str] = field(default_factory=set)
    certifications: List[Certification] = field(default_factory=list)


# ==============================================================================
# FR2 & FR3: Evaluate Resumes and Determine Advancement
# ==============================================================================

@dataclass
class ScreeningCriteria:
    """Defines the criteria for screening a resume for a specific role."""

    required_degree: Optional[str] = None
    minimum_years_experience: int = 0
    required_skills: Set[str] = field(default_factory=set)
    preferred_skills: Set[str] = field(default_factory=set)
    required_certifications: Set[str] = field(default_factory=set)
    pass_threshold: int = 10


@dataclass
class ScreeningResult:
    """Stores the outcome of a single resume screening."""

    applicant_name: str
    score: int
    decision: str
    notes: List[str]


class ResumeScreener:
    """Evaluates resumes against a set of screening criteria."""

    SCORING_POINTS: Dict[str, int] = {
        'REQUIRED_DEGREE_MET': 10,
        'EXPERIENCE_MET': 10,
        'EXPERIENCE_PER_EXTRA_YEAR': 1,
        'REQUIRED_SKILL_MET': 5,
        'PREFERRED_SKILL_MET': 2,
        'REQUIRED_CERT_MET': 5,
        'MISSING_REQUIRED_ITEM': -20,  # Heavy penalty
    }

    def __init__(self, criteria: ScreeningCriteria):
        """
        Initializes the screener with specific job criteria.

        Args:
            criteria: A ScreeningCriteria object defining job requirements.
        """
        if not isinstance(criteria, ScreeningCriteria):
            raise TypeError("criteria must be an instance of ScreeningCriteria")
        self.criteria = criteria

    def screen(self, resume: Resume) -> ScreeningResult:
        """
        Screens a single resume, producing a score, decision, and notes.

        Args:
            resume: The Resume object to be screened.

        Returns:
            A ScreeningResult object with the evaluation outcome.
        """
        score = 0
        notes: List[str] = []

        score, notes = self._evaluate_education(resume, score, notes)
        score, notes = self._evaluate_experience(resume, score, notes)
        score, notes = self._evaluate_skills(resume, score, notes)
        score, notes = self._evaluate_certifications(resume, score, notes)

        decision = (
            DECISION_ADVANCE
            if score >= self.criteria.pass_threshold
            else DECISION_REJECT
        )

        return ScreeningResult(
            applicant_name=resume.applicant.name,
            score=score,
            decision=decision,
            notes=notes
        )

    def _evaluate_education(
        self, resume: Resume, current_score: int, notes: List[str]
    ) -> Tuple[int, List[str]]:
        """Evaluates the education section of the resume."""
        if not self.criteria.required_degree:
            return current_score, notes

        has_degree = any(
            self.criteria.required_degree.lower() in edu.degree.lower()
            for edu in resume.education
        )

        if has_degree:
            current_score += self.SCORING_POINTS['REQUIRED_DEGREE_MET']
            notes.append(
                f"[PASS] Meets required degree: {self.criteria.required_degree}."
            )
        else:
            current_score += self.SCORING_POINTS['MISSING_REQUIRED_ITEM']
            notes.append(
                f"[FAIL] Lacks required degree: {self.criteria.required_degree}."
            )
        return current_score, notes

    def _evaluate_experience(
        self, resume: Resume, current_score: int, notes: List[str]
    ) -> Tuple[int, List[str]]:
        """Evaluates the work experience section of the resume."""
        total_experience = self._calculate_years_experience(resume.work_history)
        min_exp = self.criteria.minimum_years_experience

        if total_experience >= min_exp:
            current_score += self.SCORING_POINTS['EXPERIENCE_MET']
            notes.append(
                f"[PASS] Meets minimum {min_exp} years of experience "
                f"(has {total_experience:.1f})."
            )
            extra_years = int(total_experience - min_exp)
            bonus = extra_years * self.SCORING_POINTS['EXPERIENCE_PER_EXTRA_YEAR']
            if bonus > 0:
                current_score += bonus
                notes.append(
                    f"[INFO] Awarded {bonus} bonus points for {extra_years} "
                    f"extra year(s) of experience."
                )
        else:
            current_score += self.SCORING_POINTS['MISSING_REQUIRED_ITEM']
            notes.append(
                f"[FAIL] Below minimum {min_exp} years of experience "
                f"(has {total_experience:.1f})."
            )
        return current_score, notes

    def _evaluate_skills(
        self, resume: Resume, current_score: int, notes: List[str]
    ) -> Tuple[int, List[str]]:
        """Evaluates the skills section of the resume."""
        applicant_skills_lower = {s.lower() for s in resume.skills}

        # Required skills
        for skill in self.criteria.required_skills:
            if skill.lower() in applicant_skills_lower:
                current_score += self.SCORING_POINTS['REQUIRED_SKILL_MET']
                notes.append(f"[PASS] Has required skill: {skill}.")
            else:
                current_score += self.SCORING_POINTS['MISSING_REQUIRED_ITEM']
                notes.append(f"[FAIL] Missing required skill: {skill}.")

        # Preferred skills
        for skill in self.criteria.preferred_skills:
            if skill.lower() in applicant_skills_lower:
                current_score += self.SCORING_POINTS['PREFERRED_SKILL_MET']
                notes.append(f"[INFO] Has preferred skill: {skill}.")

        return current_score, notes

    def _evaluate_certifications(
        self, resume: Resume, current_score: int, notes: List[str]
    ) -> Tuple[int, List[str]]:
        """Evaluates the certifications section of the resume."""
        applicant_certs_lower = {c.name.lower() for c in resume.certifications}

        for cert in self.criteria.required_certifications:
            if cert.lower() in applicant_certs_lower:
                current_score += self.SCORING_POINTS['REQUIRED_CERT_MET']
                notes.append(f"[PASS] Has required certification: {cert}.")
            else:
                # Assuming certifications are a "nice to have" unless
                # explicitly penalized. Original logic did not penalize.
                notes.append(f"[INFO] Missing optional certification: {cert}.")
        return current_score, notes

    @staticmethod
    def _calculate_years_experience(work_history: List[WorkExperience]) -> float:
        """Calculates the total years of work experience from a list of jobs."""
        total_days = 0
        today = date.today()
        for job in work_history:
            end_date = job.end_date or today
            total_days += (end_date - job.start_date).days
        return total_days / DAYS_IN_YEAR


# ==============================================================================
# FR4 & NFR2: Generate Screening Report
# ==============================================================================

def _print_report_header():
    """Prints the main header for the screening report."""
    print("=" * 80)
    print("RESUME SCREENING REPORT")
    print("=" * 80)


def _print_criteria_section(criteria: ScreeningCriteria):
    """Prints the screening criteria used for the report."""
    print("\n--- Screening Criteria ---")
    print(f"{'Required Degree:':<25} {criteria.required_degree or 'N/A'}")
    print(f"{'Minimum Experience:':<25} {criteria.minimum_years_experience} years")
    print(f"{'Required Skills:':<25} {', '.join(criteria.required_skills) or 'N/A'}")
    print(f"{'Preferred Skills:':<25} {', '.join(criteria.preferred_skills) or 'N/A'}")
    print(
        f"{'Required Certifications:':<25}"
        f" {', '.join(criteria.required_certifications) or 'N/A'}"
    )
    print(f"{'Score Threshold to Pass:':<25} {criteria.pass_threshold}")
    print("-" * 80)


def _print_individual_results_section(results: List[ScreeningResult]):
    """Prints the detailed results for each screened applicant."""
    print("\n--- Individual Results (Sorted by Score) ---")
    sorted_results = sorted(results, key=lambda r: r.score, reverse=True)
    for result in sorted_results:
        print(f"\nApplicant: {result.applicant_name}")
        print(f"  {'Score:':<10} {result.score}")
        print(f"  {'Decision:':<10} {result.decision}")
        print("  Notes:")
        for note in result.notes:
            print(f"    - {note}")
    print("-" * 80)


def _print_summary_section(results: List[ScreeningResult]):
    """Prints the overall summary statistics of the screening process."""
    total_screened = len(results)
    advanced_count = sum(1 for r in results if r.decision == DECISION_ADVANCE)
    rejected_count = total_screened - advanced_count
    advancement_rate = (advanced_count / total_screened) * 100 if total_screened else 0

    print("\n--- Overall Summary ---")
    print(f"{'Total Resumes Screened:':<25} {total_screened}")
    print(f"{'Number to Advance:':<25} {advanced_count}")
    print(f"{'Number to Reject:':<25} {rejected_count}")
    print(f"{'Advancement Rate:':<25} {advancement_rate:.1f}%")
    print("=" * 80)


def generate_screening_report(
    results: List[ScreeningResult], criteria: ScreeningCriteria
):
    """
    Generates and prints a summary report of all screening decisions.

    Args:
        results: A list of ScreeningResult objects.
        criteria: The ScreeningCriteria used for the evaluation.
    """
    if not results:
        print("No resumes were screened.")
        return

    _print_report_header()
    _print_criteria_section(criteria)
    _print_individual_results_section(results)
    _print_summary_section(results)


# ==============================================================================
# NFR1: Self-Contained Application (Main Execution)
# ==============================================================================

def create_sample_data() -> Tuple[ScreeningCriteria, List[Resume]]:
    """Creates sample job criteria and a list of resumes for demonstration."""
    job_criteria = ScreeningCriteria(
        required_degree="Bachelor's Degree in Computer Science",
        minimum_years_experience=5,
        required_skills={"Python", "SQL", "REST APIs", "Git"},
        preferred_skills={"Docker", "Kubernetes", "AWS"},
        required_certifications={"AWS Certified Developer - Associate"},
        pass_threshold=25
    )

    resumes = [
        Resume(
            applicant=Applicant(name="Alice Johnson", email="alice.j@example.com"),
            summary="Experienced developer passionate about backend systems.",
            education=[Education(degree="Bachelor's Degree in Computer Science", university="State University", graduation_year=2015)],
            work_history=[
                WorkExperience(company="Tech Solutions Inc.", title="Senior Software Engineer", start_date=date(2018, 6, 1), end_date=None),
                WorkExperience(company="Innovate Corp.", title="Software Engineer", start_date=date(2015, 7, 1), end_date=date(2018, 5, 31))
            ],
            skills={"Python", "Java", "SQL", "REST APIs", "Git", "Docker", "AWS"},
            certifications=[Certification(name="AWS Certified Developer - Associate", issuing_org="Amazon Web Services", year_obtained=2021)]
        ),
        Resume(
            applicant=Applicant(name="Bob Smith", email="bob.smith@example.com"),
            summary="Full-stack developer with a focus on web technologies.",
            education=[Education(degree="Bachelor's in Information Technology", university="Community College", graduation_year=2018)],
            work_history=[WorkExperience(company="Web Wizards LLC", title="Web Developer", start_date=date(2018, 8, 15), end_date=None)],
            skills={"JavaScript", "HTML", "CSS", "Python", "SQL", "Git"},
        ),
        Resume(
            applicant=Applicant(name="Charlie Brown", email="charlie@example.com"),
            summary="Data Scientist with expertise in machine learning.",
            education=[
                Education(degree="Master's in Data Science", university="Ivy League", graduation_year=2014),
                Education(degree="Bachelor's Degree in Computer Science", university="Ivy League", graduation_year=2012)
            ],
            work_history=[WorkExperience(company="Data Insights Co.", title="Lead Data Scientist", start_date=date(2016, 1, 1), end_date=None)],
            skills={"Python", "R", "Machine Learning", "TensorFlow", "SQL", "AWS"},
            certifications=[Certification(name="AWS Certified Machine Learning – Specialty", issuing_org="AWS", year_obtained=2022)]
        ),
        Resume(
            applicant=Applicant(name="Diana Prince", email="diana.p@example.com"),
            summary="Software Engineer with a strong background in DevOps.",
            education=[Education(degree="Bachelor's Degree in Computer Science", university="Tech Institute", graduation_year=2013)],
            work_history=[
                WorkExperience(company="CloudNet", title="DevOps Engineer", start_date=date(2019, 3, 1), end_date=None),
                WorkExperience(company="SysAdmin Pro", title="Systems Administrator", start_date=date(2014, 1, 1), end_date=date(2019, 2, 28))
            ],
            skills={"Python", "Bash", "Docker", "Kubernetes", "AWS", "Git", "REST APIs", "SQL"},
            certifications=[
                Certification(name="AWS Certified Developer - Associate", issuing_org="AWS", year_obtained=2020),
                Certification(name="Certified Kubernetes Administrator", issuing_org="CNCF", year_obtained=2021)
            ]
        )
    ]
    return job_criteria, resumes


def main():
    """Main function to set up and run the resume screening system."""
    job_criteria, resumes_to_screen = create_sample_data()

    screener = ResumeScreener(job_criteria)
    all_results = [screener.screen(resume) for resume in resumes_to_screen]

    generate_screening_report(all_results, job_criteria)


if __name__ == "__main__":
    main()