#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Comprehensive unit tests for the automated resume screening system.

This test suite uses pytest to validate the functionality of the resume screener,
covering data models, screening logic, edge cases, and report generation.
"""

import sys
import pytest
from datetime import date
from typing import List, Tuple, Set

# Failsafe to ensure the script is not run with an incompatible Python version
if sys.version_info < (3, 7):
    sys.exit("Testing requires Python 3.7 or higher.")

# --- Import the code to be tested ---
# In a real project, this would be `from resume_screener import ...`
# For a self-contained script, we include the classes directly or import from
# the provided refactored code file if it's in the same directory.
# For this example, we'll assume the refactored code is in a file named
# `resume_screener_app.py`. If not, you might need to copy the classes here.
try:
    from resume_screener_app import (
        Applicant,
        Education,
        WorkExperience,
        Certification,
        Resume,
        ScreeningCriteria,
        ScreeningResult,
        ResumeScreener,
        generate_screening_report,
        DECISION_ADVANCE,
        DECISION_REJECT,
        DAYS_IN_YEAR
    )
except ImportError:
    # If the file is not found, we'll define the classes here to make the test
    # script self-contained, as per the user's request.
    from dataclasses import dataclass, field
    from typing import List, Set, Optional, Dict, Tuple

    DECISION_ADVANCE = "Advance"
    DECISION_REJECT = "Reject"
    DAYS_IN_YEAR = 365.25

    @dataclass
    class Applicant:
        name: str
        email: str
        phone: Optional[str] = None

    @dataclass
    class Education:
        degree: str
        university: str
        graduation_year: int

    @dataclass
    class WorkExperience:
        company: str
        title: str
        start_date: date
        end_date: Optional[date] = None
        responsibilities: List[str] = field(default_factory=list)

    @dataclass
    class Certification:
        name: str
        issuing_org: str
        year_obtained: int

    @dataclass
    class Resume:
        applicant: Applicant
        summary: str
        education: List[Education] = field(default_factory=list)
        work_history: List[WorkExperience] = field(default_factory=list)
        skills: Set[str] = field(default_factory=set)
        certifications: List[Certification] = field(default_factory=list)

    @dataclass
    class ScreeningCriteria:
        required_degree: Optional[str] = None
        minimum_years_experience: int = 0
        required_skills: Set[str] = field(default_factory=set)
        preferred_skills: Set[str] = field(default_factory=set)
        required_certifications: Set[str] = field(default_factory=set)
        pass_threshold: int = 10

    @dataclass
    class ScreeningResult:
        applicant_name: str
        score: int
        decision: str
        notes: List[str]

    class ResumeScreener:
        SCORING_POINTS: Dict[str, int] = {
            'REQUIRED_DEGREE_MET': 10,
            'EXPERIENCE_MET': 10,
            'EXPERIENCE_PER_EXTRA_YEAR': 1,
            'REQUIRED_SKILL_MET': 5,
            'PREFERRED_SKILL_MET': 2,
            'REQUIRED_CERT_MET': 5,
            'MISSING_REQUIRED_ITEM': -20,
        }
        def __init__(self, criteria: ScreeningCriteria):
            if not isinstance(criteria, ScreeningCriteria):
                raise TypeError("criteria must be an instance of ScreeningCriteria")
            self.criteria = criteria

        def screen(self, resume: Resume) -> ScreeningResult:
            score, notes = 0, []
            score, notes = self._evaluate_education(resume, score, notes)
            score, notes = self._evaluate_experience(resume, score, notes)
            score, notes = self._evaluate_skills(resume, score, notes)
            score, notes = self._evaluate_certifications(resume, score, notes)
            decision = DECISION_ADVANCE if score >= self.criteria.pass_threshold else DECISION_REJECT
            return ScreeningResult(resume.applicant.name, score, decision, notes)

        def _evaluate_education(self, resume: Resume, current_score: int, notes: List[str]) -> Tuple[int, List[str]]:
            if not self.criteria.required_degree: return current_score, notes
            has_degree = any(self.criteria.required_degree.lower() in edu.degree.lower() for edu in resume.education)
            if has_degree:
                current_score += self.SCORING_POINTS['REQUIRED_DEGREE_MET']
                notes.append(f"[PASS] Meets required degree: {self.criteria.required_degree}.")
            else:
                current_score += self.SCORING_POINTS['MISSING_REQUIRED_ITEM']
                notes.append(f"[FAIL] Lacks required degree: {self.criteria.required_degree}.")
            return current_score, notes

        def _evaluate_experience(self, resume: Resume, current_score: int, notes: List[str]) -> Tuple[int, List[str]]:
            total_experience = self._calculate_years_experience(resume.work_history)
            min_exp = self.criteria.minimum_years_experience
            if total_experience >= min_exp:
                current_score += self.SCORING_POINTS['EXPERIENCE_MET']
                notes.append(f"[PASS] Meets minimum {min_exp} years of experience (has {total_experience:.1f}).")
                extra_years = int(total_experience - min_exp)
                bonus = extra_years * self.SCORING_POINTS['EXPERIENCE_PER_EXTRA_YEAR']
                if bonus > 0:
                    current_score += bonus
                    notes.append(f"[INFO] Awarded {bonus} bonus points for {extra_years} extra year(s) of experience.")
            else:
                current_score += self.SCORING_POINTS['MISSING_REQUIRED_ITEM']
                notes.append(f"[FAIL] Below minimum {min_exp} years of experience (has {total_experience:.1f}).")
            return current_score, notes

        def _evaluate_skills(self, resume: Resume, current_score: int, notes: List[str]) -> Tuple[int, List[str]]:
            applicant_skills_lower = {s.lower() for s in resume.skills}
            for skill in self.criteria.required_skills:
                if skill.lower() in applicant_skills_lower:
                    current_score += self.SCORING_POINTS['REQUIRED_SKILL_MET']
                    notes.append(f"[PASS] Has required skill: {skill}.")
                else:
                    current_score += self.SCORING_POINTS['MISSING_REQUIRED_ITEM']
                    notes.append(f"[FAIL] Missing required skill: {skill}.")
            for skill in self.criteria.preferred_skills:
                if skill.lower() in applicant_skills_lower:
                    current_score += self.SCORING_POINTS['PREFERRED_SKILL_MET']
                    notes.append(f"[INFO] Has preferred skill: {skill}.")
            return current_score, notes

        def _evaluate_certifications(self, resume: Resume, current_score: int, notes: List[str]) -> Tuple[int, List[str]]:
            applicant_certs_lower = {c.name.lower() for c in resume.certifications}
            for cert in self.criteria.required_certifications:
                if cert.lower() in applicant_certs_lower:
                    current_score += self.SCORING_POINTS['REQUIRED_CERT_MET']
                    notes.append(f"[PASS] Has required certification: {cert}.")
                else:
                    notes.append(f"[INFO] Missing optional certification: {cert}.")
            return current_score, notes

        @staticmethod
        def _calculate_years_experience(work_history: List[WorkExperience]) -> float:
            total_days = 0
            today = date.today()
            for job in work_history:
                end_date = job.end_date or today
                total_days += (end_date - job.start_date).days
            return total_days / DAYS_IN_YEAR

    def generate_screening_report(results: List[ScreeningResult], criteria: ScreeningCriteria):
        if not results:
            print("No resumes were screened.")
            return
        # Abridged version for testing self-containment
        print("RESUME SCREENING REPORT")
        print(f"--- Screening Criteria ---")
        print(f"Score Threshold to Pass: {criteria.pass_threshold}")
        print("\n--- Individual Results (Sorted by Score) ---")
        sorted_results = sorted(results, key=lambda r: r.score, reverse=True)
        for result in sorted_results:
            print(f"\nApplicant: {result.applicant_name}")
            print(f"  Score: {result.score}")
            print(f"  Decision: {result.decision}")
        print("\n--- Overall Summary ---")
        total = len(results)
        advanced = sum(1 for r in results if r.decision == DECISION_ADVANCE)
        print(f"Total Resumes Screened: {total}")
        print(f"Number to Advance: {advanced}")

# ==============================================================================
# Test Fixtures
# ==============================================================================

@pytest.fixture
def standard_criteria():
    """A standard set of screening criteria for a software engineer role."""
    return ScreeningCriteria(
        required_degree="Bachelor's Degree in Computer Science",
        minimum_years_experience=5,
        required_skills={"Python", "SQL", "Git"},
        preferred_skills={"Docker", "AWS"},
        required_certifications={"Pro Cert"},
        pass_threshold=25
    )

@pytest.fixture
def perfect_candidate_resume():
    """A resume for a candidate who meets or exceeds all standard criteria."""
    return Resume(
        applicant=Applicant(name="Ada Lovelace", email="ada@example.com"),
        summary="A perfect candidate.",
        education=[Education("Bachelor's Degree in Computer Science", "U of CS", 2012)],
        work_history=[
            WorkExperience(
                company="Tech Corp",
                title="Sr. Engineer",
                start_date=date(2015, 1, 1),
                end_date=date(2022, 12, 31)
            ) # 8 years experience
        ],
        skills={"Python", "SQL", "Git", "Docker", "AWS", "java"},
        certifications=[Certification("Pro Cert", "Cert Inc", 2020)]
    )

@pytest.fixture
def reject_candidate_resume():
    """A resume for a candidate who fails to meet critical criteria."""
    return Resume(
        applicant=Applicant(name="John Doe", email="john.d@example.com"),
        summary="An unqualified candidate.",
        education=[Education("Associate's in Arts", "Community College", 2018)],
        work_history=[
            WorkExperience(company="Startup", title="Intern", start_date=date(2020, 1, 1), end_date=date(2020, 12, 31)) # 1 year exp
        ],
        skills={"JavaScript", "HTML"},
        certifications=[]
    )

@pytest.fixture
def borderline_candidate_resume():
    """A resume for a candidate who barely meets some criteria."""
    return Resume(
        applicant=Applicant(name="Jane Smith", email="jane.s@example.com"),
        summary="A borderline candidate.",
        education=[Education("B.S. in Computer Science", "State U", 2017)],
        work_history=[
            WorkExperience(company="Old Job", title="Dev", start_date=date(2017, 6, 1), end_date=date(2022, 6, 1)) # 5 years exp
        ],
        skills={"Python", "SQL", "Git"}, # Has required, no preferred
        certifications=[] # Missing cert
    )

@pytest.fixture
def empty_resume():
    """A resume with only the mandatory applicant information."""
    return Resume(
        applicant=Applicant(name="No Info", email="no@info.com"),
        summary=""
    )

# ==============================================================================
# Test Suite
# ==============================================================================

class TestResumeScreener:
    """Tests the core logic of the ResumeScreener class."""

    def test_init_success(self, standard_criteria):
        """FR2: Test successful initialization with valid criteria."""
        screener = ResumeScreener(standard_criteria)
        assert screener.criteria == standard_criteria

    def test_init_type_error(self):
        """FR2: Test that initialization fails with incorrect criteria type."""
        with pytest.raises(TypeError, match="criteria must be an instance of ScreeningCriteria"):
            ResumeScreener({"invalid": "criteria"})

    @pytest.mark.parametrize("work_history, expected_years, today_mock", [
        # Standard case: 4 years of experience
        ([WorkExperience(company="A", title="Dev", start_date=date(2018, 1, 1), end_date=date(2022, 1, 1))], 4.0, None),
        # No work history
        ([], 0.0, None),
        # Multiple jobs
        ([
            WorkExperience(company="A", title="Dev", start_date=date(2020, 1, 1), end_date=date(2022, 1, 1)),
            WorkExperience(company="B", title="Dev", start_date=date(2018, 1, 1), end_date=date(2020, 1, 1))
        ], 4.0, None),
        # Current job (end_date is None)
        ([WorkExperience(company="A", title="Dev", start_date=date(2021, 7, 2), end_date=None)], 2.0, date(2023, 7, 2)),
        # Job spanning a leap year (2020)
        ([WorkExperience(company="A", title="Dev", start_date=date(2019, 3, 1), end_date=date(2021, 3, 1))], 2.0, None),
    ])
    def test_calculate_years_experience(self, work_history, expected_years, today_mock, mocker):
        """FR2: Test calculation of total work experience."""
        if today_mock:
            mocker.patch('resume_screener_app.date').today.return_value = today_mock
        
        years = ResumeScreener._calculate_years_experience(work_history)
        assert years == pytest.approx(expected_years, abs=0.01)

    def test_screen_perfect_candidate(self, standard_criteria, perfect_candidate_resume):
        """FR3: Test a candidate who should pass with a high score."""
        screener = ResumeScreener(standard_criteria)
        result = screener.screen(perfect_candidate_resume)
        
        # Expected score:
        # Degree: +10
        # Experience met: +10
        # Extra years bonus (7 years total - 5 required = 2 extra): 2 * 1 = +2
        # Required skills (3 * 5): +15
        # Preferred skills (2 * 2): +4
        # Required cert: +5
        # Total = 10 + 10 + 2 + 15 + 4 + 5 = 46
        assert result.score == 46
        assert result.decision == DECISION_ADVANCE
        assert "[PASS] Meets required degree" in result.notes[0]

    def test_screen_reject_candidate(self, standard_criteria, reject_candidate_resume):
        """FR3: Test a candidate who should be rejected with a low score."""
        screener = ResumeScreener(standard_criteria)
        result = screener.screen(reject_candidate_resume)
        
        # Expected score:
        # Degree miss: -20
        # Experience miss: -20
        # Required skills miss (3 * -20): -60
        # Preferred skills: 0
        # Required cert miss: 0 (no penalty)
        # Total = -20 - 20 - 60 = -100
        assert result.score == -100
        assert result.decision == DECISION_REJECT
        assert "[FAIL] Lacks required degree" in result.notes[0]

    def test_screen_borderline_candidate(self, standard_criteria, borderline_candidate_resume):
        """FR3: Test a borderline candidate who should just pass."""
        # This candidate should pass with a score of exactly 25.
        # Degree: +10
        # Experience met (5 years): +10
        # Required skills (3 * 5): +15
        # Preferred skills: 0
        # Required cert miss: 0
        # Total = 10 + 10 + 15 = 35. This is well above threshold. Let's adjust criteria.
        
        criteria = ScreeningCriteria(
            required_degree="B.S. in Computer Science",
            minimum_years_experience=5,
            required_skills={"Python", "SQL", "Git"},
            pass_threshold=35
        )
        screener = ResumeScreener(criteria)
        result = screener.screen(borderline_candidate_resume)

        assert result.score == 35
        assert result.decision == DECISION_ADVANCE
        
        # Now test the fail boundary
        criteria.pass_threshold = 36
        screener = ResumeScreener(criteria)
        result = screener.screen(borderline_candidate_resume)
        
        assert result.score == 35
        assert result.decision == DECISION_REJECT

    def test_screen_empty_resume(self, standard_criteria, empty_resume):
        """FR2: Test screening an empty resume results in rejection."""
        screener = ResumeScreener(standard_criteria)
        result = screener.screen(empty_resume)
        assert result.decision == DECISION_REJECT
        assert result.score < standard_criteria.pass_threshold

    def test_evaluation_without_requirements(self, perfect_candidate_resume):
        """FR2: Test screening when criteria has no requirements."""
        criteria = ScreeningCriteria(pass_threshold=5)
        screener = ResumeScreener(criteria)
        result = screener.screen(perfect_candidate_resume)
        
        # With no requirements, score should be 0, but experience check still runs.
        # 0 years required, candidate has 7.
        # Experience Met: +10
        # Extra years bonus (7-0=7): +7
        # Total = 17
        assert result.score == 17
        assert result.decision == DECISION_ADVANCE

    def test_case_insensitivity(self, borderline_candidate_resume):
        """FR2: Ensure evaluations are case-insensitive."""
        criteria = ScreeningCriteria(
            required_degree="b.s. in computer science", # Lowercase
            required_skills={"python", "sql"}, # Lowercase
            pass_threshold=10
        )
        screener = ResumeScreener(criteria)
        result = screener.screen(borderline_candidate_resume)

        assert "[PASS] Meets required degree" in result.notes[0]
        assert "[PASS] Has required skill: python" in result.notes
        assert "[PASS] Has required skill: sql" in result.notes
        assert result.score > 0

    def test_certification_evaluation(self, perfect_candidate_resume):
        """FR2: Test certification check (pass and fail)."""
        # Pass case (already tested in perfect candidate, but explicit here)
        criteria_pass = ScreeningCriteria(required_certifications={"Pro Cert"})
        screener_pass = ResumeScreener(criteria_pass)
        result_pass = screener_pass.screen(perfect_candidate_resume)
        assert screener_pass.SCORING_POINTS['REQUIRED_CERT_MET'] in [note.count('[PASS]') * 5 for note in result_pass.notes]
        assert "[PASS] Has required certification: Pro Cert" in result_pass.notes

        # Fail case (missing cert - should only add a note, no penalty)
        criteria_fail = ScreeningCriteria(required_certifications={"Missing Cert"})
        screener_fail = ResumeScreener(criteria_fail)
        result_fail = screener_fail.screen(perfect_candidate_resume)
        assert "[INFO] Missing optional certification: Missing Cert" in result_fail.notes
        # Score should be based on experience only as other criteria are not set
        assert result_fail.score > 0


class TestReporting:
    """Tests the report generation functionality."""

    def test_generate_report_with_data(self, capsys, standard_criteria):
        """FR4/NFR2: Test report generation with valid screening results."""
        results = [
            ScreeningResult("Alice", 40, DECISION_ADVANCE, []),
            ScreeningResult("Bob", 15, DECISION_REJECT, []),
            ScreeningResult("Charlie", 55, DECISION_ADVANCE, []),
        ]
        
        generate_screening_report(results, standard_criteria)
        captured = capsys.readouterr()
        
        # Check for key sections
        assert "RESUME SCREENING REPORT" in captured.out
        assert "Screening Criteria" in captured.out
        assert f"Score Threshold to Pass: {standard_criteria.pass_threshold}" in captured.out
        assert "Individual Results (Sorted by Score)" in captured.out
        assert "Overall Summary" in captured.out
        
        # Check summary data
        assert "Total Resumes Screened: 3" in captured.out
        assert "Number to Advance: 2" in captured.out
        
        # Check for sorting (Charlie with 55 should appear before Alice with 40)
        charlie_pos = captured.out.find("Applicant: Charlie")
        alice_pos = captured.out.find("Applicant: Alice")
        bob_pos = captured.out.find("Applicant: Bob")
        assert -1 < charlie_pos < alice_pos < bob_pos

    def test_generate_report_no_data(self, capsys, standard_criteria):
        """FR4/NFR2: Test report generation with no results."""
        generate_screening_report([], standard_criteria)
        captured = capsys.readouterr()
        assert "No resumes were screened." in captured.out
        assert "RESUME SCREENING REPORT" not in captured.out