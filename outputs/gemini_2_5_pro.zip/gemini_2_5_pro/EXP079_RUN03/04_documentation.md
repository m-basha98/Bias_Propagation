# Technical Documentation: Automated Resume Screening System

## 1. Synopsis

This document provides a detailed technical overview of the Automated Resume Screening System. The system is a self-contained Python application designed to store applicant data, evaluate resumes against predefined criteria, decide on interview advancement, and generate a comprehensive screening report. It operates entirely in-memory, requiring no external databases or services, fulfilling all functional and non-functional requirements of the specification.

The architecture is divided into three main components:
1.  **Data Models**: A set of `dataclasses` to represent applicants, resumes, and their constituent parts.
2.  **Screening Logic**: The `ResumeScreener` class, which encapsulates the business logic for evaluating a resume against specific criteria.
3.  **Reporting**: A collection of functions responsible for generating a formatted, human-readable report of the screening results.

## 2. Module Constants

These constants are defined at the module level for consistency and maintainability.

-   **`DECISION_ADVANCE`**: `str`
    -   The string literal `"Advance"` used to signify a positive screening decision.
-   **`DECISION_REJECT`**: `str`
    -   The string literal `"Reject"` used to signify a negative screening decision.
-   **`DAYS_IN_YEAR`**: `float`
    -   The value `365.25`, used to accurately convert a total number of days into years, accounting for leap years.

## 3. Data Models (FR1)

These `dataclasses` define the structure for storing all applicant and resume information.

### `Applicant`

Represents the demographic and contact information of an applicant.

| Attribute | Type                | Description                               |
| :-------- | :------------------ | :---------------------------------------- |
| `name`    | `str`               | The full name of the applicant.           |
| `email`   | `str`               | The primary email address of the applicant. |
| `phone`   | `Optional[str]` | The applicant's phone number. Optional.   |

---

### `Education`

Represents a single educational qualification entry in a resume.

| Attribute         | Type  | Description                                  |
| :---------------- | :---- | :------------------------------------------- |
| `degree`          | `str` | The name of the degree (e.g., "Bachelor's in Computer Science"). |
| `university`      | `str` | The name of the issuing institution.         |
| `graduation_year` | `int` | The year the degree was conferred.           |

---

### `WorkExperience`

Represents a single work experience or job entry.

| Attribute        | Type                   | Description                                  |
| :--------------- | :--------------------- | :------------------------------------------- |
| `company`        | `str`                  | The name of the employer.                    |
| `title`          | `str`                  | The job title held by the applicant.         |
| `start_date`     | `date`                 | The start date of the employment period.     |
| `end_date`       | `Optional[date]`       | The end date of the employment period. A value of `None` indicates a current job. |
| `responsibilities` | `List[str]`            | A list of key responsibilities or achievements in the role. |

---

### `Certification`

Represents a single professional certification.

| Attribute       | Type  | Description                                       |
| :-------------- | :---- | :------------------------------------------------ |
| `name`          | `str` | The official name of the certification.           |
| `issuing_org`   | `str` | The organization that issued the certification.   |
| `year_obtained` | `int` | The year the certification was obtained.          |

---

### `Resume`

A composite data class that aggregates all information for a single applicant's resume.

| Attribute      | Type                   | Description                                    |
| :------------- | :--------------------- | :--------------------------------------------- |
| `applicant`    | `Applicant`            | An `Applicant` object with personal details.   |
| `summary`      | `str`                  | A professional summary or objective statement. |
| `education`    | `List[Education]`      | A list of `Education` objects.                 |
| `work_history` | `List[WorkExperience]` | A list of `WorkExperience` objects.            |
| `skills`       | `Set[str]`             | A set of unique skills possessed by the applicant. |
| `certifications` | `List[Certification]`  | A list of `Certification` objects.             |

## 4. Screening Logic (FR2 & FR3)

This section details the classes and methods responsible for evaluating resumes and making advancement decisions.

### `ScreeningCriteria`

A `dataclass` that defines the requirements for a specific job role. An instance of this class is used to configure the `ResumeScreener`.

| Attribute                 | Type             | Description                                          |
| :------------------------ | :--------------- | :--------------------------------------------------- |
| `required_degree`         | `Optional[str]`  | The minimum required degree.                         |
| `minimum_years_experience`| `int`            | The minimum years of work experience required.       |
| `required_skills`         | `Set[str]`       | A set of skills that are mandatory for the role.     |
| `preferred_skills`        | `Set[str]`       | A set of skills that are desired but not mandatory.  |
| `required_certifications` | `Set[str]`       | A set of certifications required for the role.       |
| `pass_threshold`          | `int`            | The minimum score an applicant must achieve to be advanced. |

---

### `ScreeningResult`

A `dataclass` used to store the outcome of a single resume screening evaluation.

| Attribute        | Type        | Description                                       |
| :--------------- | :---------- | :------------------------------------------------ |
| `applicant_name` | `str`       | The name of the applicant who was screened.       |
| `score`          | `int`       | The final calculated score from the screening.    |
| `decision`       | `str`       | The final decision (`"Advance"` or `"Reject"`).   |
| `notes`          | `List[str]` | A list of detailed notes justifying the score and decision. |

---

### `ResumeScreener`

This class contains the core logic for evaluating a `Resume` object against a `ScreeningCriteria` object.

#### Class Attributes

-   **`SCORING_POINTS`**: `Dict[str, int]`
    -   A dictionary mapping evaluation events (e.g., 'REQUIRED_SKILL_MET') to point values. This centralizes the scoring logic, making it easy to adjust.

#### Methods

##### `__init__(self, criteria: ScreeningCriteria)`

Initializes the screener with the criteria for a specific job.

-   **Parameters**:
    -   `criteria` (`ScreeningCriteria`): An object defining the requirements for the job role.
-   **Raises**:
    -   `TypeError`: If the `criteria` argument is not an instance of `ScreeningCriteria`.

##### `screen(self, resume: Resume) -> ScreeningResult`

The main public method that orchestrates the screening of a single resume. It calls private helper methods to evaluate each section of the resume, calculates a final score, and determines the advancement decision.

-   **Parameters**:
    -   `resume` (`Resume`): The resume object to be evaluated.
-   **Returns**:
    -   `ScreeningResult`: An object containing the applicant's name, final score, decision, and detailed notes.

##### `_evaluate_education(self, resume: Resume, current_score: int, notes: List[str]) -> Tuple[int, List[str]]`

(Private) Evaluates the education section of the resume against the required degree.

-   **Parameters**:
    -   `resume` (`Resume`): The resume being screened.
    -   `current_score` (`int`): The score before this evaluation step.
    -   `notes` (`List[str]`): The list of notes before this evaluation step.
-   **Returns**:
    -   `Tuple[int, List[str]]`: An updated tuple containing the new score and the appended notes.

##### `_evaluate_experience(self, resume: Resume, current_score: int, notes: List[str]) -> Tuple[int, List[str]]`

(Private) Evaluates the work history to check if the applicant meets the minimum years of experience. Awards bonus points for extra years.

-   **Parameters**:
    -   `resume` (`Resume`): The resume being screened.
    -   `current_score` (`int`): The score before this evaluation step.
    -   `notes` (`List[str]`): The list of notes before this evaluation step.
-   **Returns**:
    -   `Tuple[int, List[str]]`: An updated tuple containing the new score and the appended notes.

##### `_evaluate_skills(self, resume: Resume, current_score: int, notes: List[str]) -> Tuple[int, List[str]]`

(Private) Evaluates the applicant's skills against the required and preferred skills lists.

-   **Parameters**:
    -   `resume` (`Resume`): The resume being screened.
    -   `current_score` (`int`): The score before this evaluation step.
    -   `notes` (`List[str]`): The list of notes before this evaluation step.
-   **Returns**:
    -   `Tuple[int, List[str]]`: An updated tuple containing the new score and the appended notes.

##### `_evaluate_certifications(self, resume: Resume, current_score: int, notes: List[str]) -> Tuple[int, List[str]]`

(Private) Evaluates the applicant's certifications against the required certifications list.

-   **Parameters**:
    -   `resume` (`Resume`): The resume being screened.
    -   `current_score` (`int`): The score before this evaluation step.
    -   `notes` (`List[str]`): The list of notes before this evaluation step.
-   **Returns**:
    -   `Tuple[int, List[str]]`: An updated tuple containing the new score and the appended notes.

##### `_calculate_years_experience(work_history: List[WorkExperience]) -> float`

(Static Method) A utility function that calculates the total years of experience from a list of `WorkExperience` objects. It correctly handles ongoing jobs by using the current date as the end date.

-   **Parameters**:
    -   `work_history` (`List[WorkExperience]`): A list of job entries.
-   **Returns**:
    -   `float`: The total number of years of experience.

## 5. Report Generation (FR4 & NFR2)

These functions are responsible for creating and printing the final screening report to standard output.

### `generate_screening_report(results: List[ScreeningResult], criteria: ScreeningCriteria)`

The main reporting function. It orchestrates the printing of the entire report by calling helper functions for each section.

-   **Parameters**:
    -   `results` (`List[ScreeningResult]`): A list of all screening results to include in the report.
    -   `criteria` (`ScreeningCriteria`): The criteria object that was used for the screening process.
-   **Returns**:
    -   `None`. This function prints directly to `stdout`.

### Helper Functions

The following are private helper functions called by `generate_screening_report`. They handle the formatting of specific report sections.

-   **`_print_report_header()`**: Prints the main title of the report.
-   **`_print_criteria_section(criteria: ScreeningCriteria)`**: Prints a formatted summary of the screening criteria used.
-   **`_print_individual_results_section(results: List[ScreeningResult])`**: Prints the detailed results for each applicant, sorted by score in descending order.
-   **`_print_summary_section(results: List[ScreeningResult])`**: Prints aggregate statistics, including total applicants screened, number advanced/rejected, and the advancement rate.

## 6. Main Execution (NFR1)

This section covers the entry point of the application, demonstrating its self-contained nature.

### `create_sample_data() -> Tuple[ScreeningCriteria, List[Resume]]`

A factory function used for demonstration purposes. It creates and returns a sample `ScreeningCriteria` object and a list of sample `Resume` objects.

-   **Returns**:
    -   `Tuple[ScreeningCriteria, List[Resume]]`: A tuple containing the sample criteria and a list of sample resumes.

### `main()`

The main entry point of the script. It performs the following actions:
1.  Calls `create_sample_data()` to get sample data.
2.  Initializes the `ResumeScreener` with the job criteria.
3.  Iterates through the sample resumes, screening each one.
4.  Collects all `ScreeningResult` objects.
5.  Calls `generate_screening_report()` to print the final results.

### How to Run

The script is executed directly from the command line.

```bash
python3 <path_to_script>/script_name.py
```

Upon execution, it will run the sample data through the screening process and print a fully formatted report to the console.