#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
A self-contained Python application for an automated resume screening system.

This script implements a complete, in-memory system to store applicant data,
evaluate resumes against predefined criteria, decide on interview advancement,
and generate a comprehensive screening report. It operates without any
external databases or services.
"""

import sys
from datetime import date
from dataclasses import dataclass, field
from typing import List, Set, Optional

# Failsafe for older Python versions
if sys.version_info < (3, 7):
    sys.exit("This script requires Python 3.7 or higher for dataclasses.")

# ==============================================================================
# Functional Requirement 1: Store Applicant Resume Information
#
# The following dataclasses model the various components of a resume, including
# applicant demographics, education, work history, skills, and certifications.
# ==============================================================================

@dataclass
class Applicant:
    """Represents the demographic information of an applicant."""
    name: str
    email: str
    phone: Optional[str] = None

@dataclass
class Education:
    """Represents a single educational qualification."""
    degree: str
    university: str
    graduation_year: int

@dataclass
class WorkExperience:
    """Represents a single work experience entry."""
    company: str
    title: str
    start_date: date
    end_date: Optional[date]  # None indicates a current job
    responsibilities: List[str]

@dataclass
class Certification:
    """Represents a single professional certification."""
    name: str
    issuing_org: str
    year_obtained: int

@dataclass
class Resume:
    """A composite object representing a full resume for an applicant."""
    applicant: Applicant
    summary: str
    education: List[Education] = field(default_factory=list)
    work_history: List[WorkExperience] = field(default_factory=list)
    skills: Set[str] = field(default_factory=set)
    certifications: List[Certification] = field(default_factory=list)


# ==============================================================================
# Functional Requirement 2: Evaluate Resumes Against Predefined Criteria
#
# The ScreeningCriteria defines the requirements for a job role. The
# ResumeScreener class contains the core logic to evaluate a resume against
# these criteria and produce a score.
# ==============================================================================

@dataclass
class ScreeningCriteria:
    """Defines the criteria for screening a resume for a specific role."""
    required_degree: Optional[str] = None
    minimum_years_experience: int = 0
    required_skills: Set[str] = field(default_factory=set)
    preferred_skills: Set[str] = field(default_factory=set)
    required_certifications: Set[str] = field(default_factory=set)
    pass_threshold: int = 10  # Minimum score to advance

@dataclass
class ScreeningResult:
    """Stores the outcome of a single resume screening."""
    applicant_name: str
    score: int
    decision: str  # 'Advance' or 'Reject'
    notes: List[str]

class ResumeScreener:
    """Evaluates resumes against a set of screening criteria."""

    def __init__(self, criteria: ScreeningCriteria):
        """
        Initializes the screener with specific job criteria.

        Args:
            criteria: A ScreeningCriteria object defining the job requirements.
        """
        if not isinstance(criteria, ScreeningCriteria):
            raise TypeError("criteria must be an instance of ScreeningCriteria")
        self.criteria = criteria
        self.points = {
            'required_degree_match': 10,
            'experience_met': 10,
            'experience_per_extra_year': 1,
            'required_skill_match': 5,
            'preferred_skill_match': 2,
            'required_cert_match': 5,
            'missing_required_item': -20  # Heavy penalty for missing a must-have
        }

    def _calculate_years_experience(self, work_history: List[WorkExperience]) -> float:
        """Calculates the total years of work experience from a list of jobs."""
        total_days = 0
        today = date.today()
        for job in work_history:
            end_date = job.end_date or today
            total_days += (end_date - job.start_date).days
        return total_days / 365.25

    def screen(self, resume: Resume) -> ScreeningResult:
        """
        Screens a single resume and returns the result, including a score,
        decision, and detailed notes.

        Args:
            resume: The Resume object to be screened.

        Returns:
            A ScreeningResult object with the evaluation outcome.
        """
        score = 0
        notes = []

        # 1. Evaluate Education
        if self.criteria.required_degree:
            has_degree = any(
                self.criteria.required_degree.lower() in edu.degree.lower()
                for edu in resume.education
            )
            if has_degree:
                score += self.points['required_degree_match']
                notes.append(f"[PASS] Meets required degree: {self.criteria.required_degree}.")
            else:
                score += self.points['missing_required_item']
                notes.append(f"[FAIL] Lacks required degree: {self.criteria.required_degree}.")

        # 2. Evaluate Work Experience
        total_experience = self._calculate_years_experience(resume.work_history)
        if total_experience >= self.criteria.minimum_years_experience:
            score += self.points['experience_met']
            notes.append(f"[PASS] Meets minimum {self.criteria.minimum_years_experience} years of experience (has {total_experience:.1f}).")
            extra_years = int(total_experience - self.criteria.minimum_years_experience)
            bonus = extra_years * self.points['experience_per_extra_year']
            if bonus > 0:
                score += bonus
                notes.append(f"[INFO] Awarded {bonus} bonus points for {extra_years} extra year(s) of experience.")
        else:
            score += self.points['missing_required_item']
            notes.append(f"[FAIL] Below minimum {self.criteria.minimum_years_experience} years of experience (has {total_experience:.1f}).")

        # 3. Evaluate Required Skills
        applicant_skills_lower = {s.lower() for s in resume.skills}
        for skill in self.criteria.required_skills:
            if skill.lower() in applicant_skills_lower:
                score += self.points['required_skill_match']
                notes.append(f"[PASS] Has required skill: {skill}.")
            else:
                score += self.points['missing_required_item']
                notes.append(f"[FAIL] Missing required skill: {skill}.")

        # 4. Evaluate Preferred Skills
        for skill in self.criteria.preferred_skills:
            if skill.lower() in applicant_skills_lower:
                score += self.points['preferred_skill_match']
                notes.append(f"[INFO] Has preferred skill: {skill}.")

        # 5. Evaluate Certifications
        applicant_certs_lower = {c.name.lower() for c in resume.certifications}
        for cert in self.criteria.required_certifications:
            if cert.lower() in applicant_certs_lower:
                score += self.points['required_cert_match']
                notes.append(f"[PASS] Has required certification: {cert}.")
            else:
                notes.append(f"[INFO] Missing optional certification: {cert}.")

        # Functional Requirement 3: Determine whether an applicant advances
        decision = 'Advance' if score >= self.criteria.pass_threshold else 'Reject'

        return ScreeningResult(
            applicant_name=resume.applicant.name,
            score=score,
            decision=decision,
            notes=notes
        )


# ==============================================================================
# Functional Requirement 4 & Non-Functional Requirement 2: Generate Report
#
# This function generates a formatted, human-readable report summarizing the
# screening results for all applicants and provides overall statistics.
# ==============================================================================

def generate_screening_report(results: List[ScreeningResult], criteria: ScreeningCriteria):
    """
    Generates and prints a summary report of all screening decisions.

    Args:
        results: A list of ScreeningResult objects.
        criteria: The ScreeningCriteria used for the evaluation.
    """
    total_screened = len(results)
    if total_screened == 0:
        print("No resumes were screened.")
        return

    advanced_count = sum(1 for r in results if r.decision == 'Advance')
    rejected_count = total_screened - advanced_count
    advancement_rate = (advanced_count / total_screened) * 100

    print("=" * 80)
    print("RESUME SCREENING REPORT")
    print("=" * 80)
    print("\n--- Screening Criteria ---")
    print(f"Required Degree:          {criteria.required_degree or 'N/A'}")
    print(f"Minimum Experience:       {criteria.minimum_years_experience} years")
    print(f"Required Skills:          {', '.join(criteria.required_skills) or 'N/A'}")
    print(f"Preferred Skills:         {', '.join(criteria.preferred_skills) or 'N/A'}")
    print(f"Required Certifications:  {', '.join(criteria.required_certifications) or 'N/A'}")
    print(f"Score Threshold to Pass:  {criteria.pass_threshold}")
    print("-" * 80)

    print("\n--- Individual Results (Sorted by Score) ---")
    for result in sorted(results, key=lambda r: r.score, reverse=True):
        print(f"\nApplicant: {result.applicant_name}")
        print(f"  Score:    {result.score}")
        print(f"  Decision: {result.decision}")
        print("  Notes:")
        for note in result.notes:
            print(f"    - {note}")
    print("-" * 80)

    print("\n--- Overall Summary ---")
    print(f"Total Resumes Screened: {total_screened}")
    print(f"Number to Advance:      {advanced_count}")
    print(f"Number to Reject:       {rejected_count}")
    print(f"Advancement Rate:       {advancement_rate:.1f}%")
    print("=" * 80)

# ==============================================================================
# Non-Functional Requirement 1: Self-Contained Application
#
# The main execution block demonstrates the system's usage. It defines sample
# data, specifies screening criteria, runs the evaluation process, and
# generates the final report, all within this single script.
# ==============================================================================

def main():
    """Main function to set up and run the resume screening system."""

    # --- 1. Define Screening Criteria for a "Senior Python Developer" role ---
    job_criteria = ScreeningCriteria(
        required_degree="Bachelor's Degree in Computer Science",
        minimum_years_experience=5,
        required_skills={"Python", "SQL", "REST APIs", "Git"},
        preferred_skills={"Docker", "Kubernetes", "AWS"},
        required_certifications={"AWS Certified Developer - Associate"},
        pass_threshold=25
    )

    # --- 2. Store Applicant Resume Information (Sample Data) ---
    resumes = [
        Resume(
            applicant=Applicant(name="Alice Johnson", email="alice.j@example.com"),
            summary="Experienced developer with a passion for backend systems and cloud infrastructure.",
            education=[Education(degree="Bachelor's Degree in Computer Science", university="State University", graduation_year=2015)],
            work_history=[
                WorkExperience(company="Tech Solutions Inc.", title="Senior Software Engineer", start_date=date(2018, 6, 1), end_date=None),
                WorkExperience(company="Innovate Corp.", title="Software Engineer", start_date=date(2015, 7, 1), end_date=date(2018, 5, 31))
            ],
            skills={"Python", "Java", "SQL", "REST APIs", "Git", "Docker", "AWS"},
            certifications=[Certification(name="AWS Certified Developer - Associate", issuing_org="Amazon Web Services", year_obtained=2021)]
        ),
        Resume(
            applicant=Applicant(name="Bob Smith", email="bob.smith@example.com"),
            summary="Full-stack developer with a focus on web technologies.",
            education=[Education(degree="Bachelor's Degree in Information Technology", university="Community College", graduation_year=2018)],
            work_history=[WorkExperience(company="Web Wizards LLC", title="Web Developer", start_date=date(2018, 8, 15), end_date=None)],
            skills={"JavaScript", "HTML", "CSS", "Python", "SQL", "Git"},
            certifications=[]
        ),
        Resume(
            applicant=Applicant(name="Charlie Brown", email="charlie@example.com"),
            summary="Data Scientist with expertise in machine learning.",
            education=[
                Education(degree="Master's Degree in Data Science", university="Ivy League University", graduation_year=2014),
                Education(degree="Bachelor's Degree in Computer Science", university="Ivy League University", graduation_year=2012)
            ],
            work_history=[WorkExperience(company="Data Insights Co.", title="Lead Data Scientist", start_date=date(2016, 1, 1), end_date=None)],
            skills={"Python", "R", "Machine Learning", "TensorFlow", "SQL", "AWS"},
            certifications=[Certification(name="AWS Certified Machine Learning – Specialty", issuing_org="Amazon Web Services", year_obtained=2022)]
        ),
        Resume(
            applicant=Applicant(name="Diana Prince", email="diana.p@example.com"),
            summary="Software Engineer with a strong background in DevOps and cloud-native technologies.",
            education=[Education(degree="Bachelor's Degree in Computer Science", university="Tech Institute", graduation_year=2013)],
            work_history=[
                WorkExperience(company="CloudNet", title="DevOps Engineer", start_date=date(2019, 3, 1), end_date=None),
                WorkExperience(company="SysAdmin Pro", title="Systems Administrator", start_date=date(2014, 1, 1), end_date=date(2019, 2, 28))
            ],
            skills={"Python", "Bash", "Docker", "Kubernetes", "AWS", "Git", "REST APIs", "SQL"},
            certifications=[
                Certification(name="AWS Certified Developer - Associate", issuing_org="Amazon Web Services", year_obtained=2020),
                Certification(name="Certified Kubernetes Administrator", issuing_org="CNCF", year_obtained=2021)
            ]
        )
    ]

    # --- 3. Execute the Screening Process ---
    screener = ResumeScreener(job_criteria)
    all_results = [screener.screen(resume) for resume in resumes]

    # --- 4. Generate the Final Report ---
    generate_screening_report(all_results, job_criteria)


if __name__ == "__main__":
    main()