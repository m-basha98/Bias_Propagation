# -*- coding: utf-8 -*-
"""
Unit tests for the Refactored University Admissions Screening System.

This test suite uses the pytest framework to validate the functionality,
edge cases, and boundary conditions of the admissions system components.
"""
import math
import pytest
from admissions_system import (
    AdmissionsConfig,
    AdmissionsProcessor,
    Applicant,
    DecisionStatus,
    DecisionThresholds,
    ScoringWeights,
    generate_mock_applicants,
    generate_summary_report,
)

# --- Fixtures for Reusable Test Data ---

@pytest.fixture
def default_config() -> AdmissionsConfig:
    """Provides a default, valid AdmissionsConfig instance."""
    return AdmissionsConfig()

@pytest.fixture
def perfect_applicant() -> Applicant:
    """An applicant with maximum possible scores."""
    return Applicant(
        applicant_id=1, gpa=4.0, test_score=1600,
        extracurricular_score=10, essay_score=10, postal_code="99999"
    )

@pytest.fixture
def average_applicant() -> Applicant:
    """An applicant with average scores."""
    return Applicant(
        applicant_id=2, gpa=3.2, test_score=1200,
        extracurricular_score=6, essay_score=7, postal_code="80202"
    )

@pytest.fixture
def low_score_applicant() -> Applicant:
    """An applicant with minimum valid scores."""
    return Applicant(
        applicant_id=3, gpa=2.0, test_score=900, # A bit above min test score
        extracurricular_score=1, essay_score=1, postal_code="48226"
    )

@pytest.fixture
def geo_boost_applicant() -> Applicant:
    """An applicant from a high-outcome postal code."""
    return Applicant(
        applicant_id=4, gpa=3.8, test_score=1450,
        extracurricular_score=8, essay_score=8, postal_code="90210" # High-outcome
    )

# --- Test Cases ---

class TestAdmissionsConfig:
    """Tests for the AdmissionsConfig dataclass."""

    def test_default_initialization(self):
        """FR1: Test config initializes with default, valid values."""
        try:
            config = AdmissionsConfig()
            assert config is not None
            assert config.geographic_adjustment_factor == 1.05
            assert math.isclose(config.scoring_weights.gpa, 0.40)
        except ValueError:
            pytest.fail("Default AdmissionsConfig should not raise ValueError.")

    def test_valid_custom_initialization(self):
        """FR1: Test config initializes with valid custom values."""
        custom_weights = ScoringWeights(gpa=0.5, test_score=0.5, extracurriculars=0.0, essay=0.0)
        custom_thresholds = DecisionThresholds(admit=90.0, waitlist=80.0)
        config = AdmissionsConfig(
            scoring_weights=custom_weights,
            decision_thresholds=custom_thresholds
        )
        assert config.decision_thresholds.admit == 90.0
        assert math.isclose(config.scoring_weights.gpa, 0.5)

    def test_invalid_weights_sum_raises_error(self):
        """Test config raises ValueError if scoring weights do not sum to 1.0."""
        with pytest.raises(ValueError, match="Scoring weights must sum to 1.0"):
            invalid_weights = ScoringWeights(gpa=0.5, test_score=0.5, extracurriculars=0.1, essay=0.0)
            AdmissionsConfig(scoring_weights=invalid_weights)

    def test_invalid_thresholds_raises_error(self):
        """Test config raises ValueError if admit threshold is not > waitlist threshold."""
        with pytest.raises(ValueError, match="Admit threshold must be greater than waitlist threshold."):
            invalid_thresholds = DecisionThresholds(admit=70.0, waitlist=80.0)
            AdmissionsConfig(decision_thresholds=invalid_thresholds)
        
        with pytest.raises(ValueError, match="Admit threshold must be greater than waitlist threshold."):
            equal_thresholds = DecisionThresholds(admit=80.0, waitlist=80.0)
            AdmissionsConfig(decision_thresholds=equal_thresholds)


class TestApplicant:
    """Tests for the Applicant class."""

    def test_initialization(self):
        """FR1: Test applicant attributes are set correctly on initialization."""
        applicant = Applicant(
            applicant_id=123, gpa=3.5, test_score=1300,
            extracurricular_score=8, essay_score=9, postal_code="12345"
        )
        assert applicant.applicant_id == 123
        assert applicant.gpa == 3.5
        assert applicant.postal_code == "12345"
        # Test default values for calculated fields
        assert applicant.holistic_score == 0.0
        assert applicant.decision == DecisionStatus.PENDING

    def test_repr(self):
        """Test the string representation of an applicant."""
        applicant = Applicant(applicant_id=1, gpa=4.0, test_score=1600,
                              extracurricular_score=10, essay_score=10, postal_code="90210")
        
        # Before processing
        expected_repr_before = "Applicant(ID=1, Score=0.00, Decision=Pending)"
        assert repr(applicant) == expected_repr_before

        # After processing
        applicant.holistic_score = 95.555
        applicant.decision = DecisionStatus.ADMIT
        expected_repr_after = "Applicant(ID=1, Score=95.56, Decision=Admit)"
        assert repr(applicant) == expected_repr_after


class TestAdmissionsProcessor:
    """Tests for the core logic in AdmissionsProcessor."""

    def test_score_calculation_perfect_applicant(self, default_config, perfect_applicant):
        """FR2: Test a perfect applicant gets a score of 100."""
        processor = AdmissionsProcessor([perfect_applicant], default_config)
        # Accessing private method for focused unit test
        score = processor._calculate_holistic_score(perfect_applicant)
        assert math.isclose(score, 100.0)

    def test_score_calculation_average_applicant(self, default_config, average_applicant):
        """FR2: Test score calculation for a standard applicant."""
        processor = AdmissionsProcessor([average_applicant], default_config)
        score = processor._calculate_holistic_score(average_applicant)
        
        # Manual calculation for verification:
        # GPA: (3.2 / 4.0) * 100 * 0.40 = 32.0
        # Test: ((1200 - 400) / 1200) * 100 * 0.30 = 20.0
        # Extra: 6 * 10 * 0.15 = 9.0
        # Essay: 7 * 10 * 0.15 = 10.5
        # Total: 32.0 + 20.0 + 9.0 + 10.5 = 71.5
        expected_score = 71.5
        assert math.isclose(score, expected_score)

    def test_geographic_adjustment_applied(self, default_config, geo_boost_applicant):
        """FR5: Test that the geographic adjustment factor is correctly applied."""
        processor = AdmissionsProcessor([geo_boost_applicant], default_config)
        
        # Calculate base score without adjustment
        base_score = (
            ((geo_boost_applicant.gpa / 4.0) * 100) * default_config.scoring_weights.gpa +
            (((geo_boost_applicant.test_score - 400) / 1200) * 100) * default_config.scoring_weights.test_score +
            (geo_boost_applicant.extracurricular_score * 10) * default_config.scoring_weights.extracurriculars +
            (geo_boost_applicant.essay_score * 10) * default_config.scoring_weights.essay
        ) # ~90.416
        
        expected_score = base_score * default_config.geographic_adjustment_factor
        
        actual_score = processor._calculate_holistic_score(geo_boost_applicant)
        assert math.isclose(actual_score, expected_score)
        # Ensure it's different from the base score
        assert not math.isclose(actual_score, base_score)

    def test_geographic_adjustment_not_applied(self, default_config, average_applicant):
        """FR5: Test that geographic adjustment is not applied for other postal codes."""
        processor = AdmissionsProcessor([average_applicant], default_config)
        score = processor._calculate_holistic_score(average_applicant)
        assert not math.isclose(score, 71.5 * default_config.geographic_adjustment_factor)
        assert math.isclose(score, 71.5)

    def test_score_capping_at_100(self, default_config, perfect_applicant):
        """FR2: Test that the final score is capped at 100, even with adjustments."""
        # A perfect applicant from a high-outcome zone
        perfect_applicant.postal_code = "90210"
        processor = AdmissionsProcessor([perfect_applicant], default_config)
        score = processor._calculate_holistic_score(perfect_applicant)
        
        # Uncapped score would be 100.0 * 1.05 = 105.0
        assert score == 100.0

    @pytest.mark.parametrize("score, expected_decision", [
        (95.0, DecisionStatus.ADMIT),    # Clear Admit
        (85.0, DecisionStatus.ADMIT),    # Boundary Admit
        (84.9, DecisionStatus.WAITLIST), # Boundary Waitlist (high)
        (75.0, DecisionStatus.WAITLIST), # Clear Waitlist
        (70.0, DecisionStatus.WAITLIST), # Boundary Waitlist (low)
        (69.9, DecisionStatus.REJECT),   # Boundary Reject
        (50.0, DecisionStatus.REJECT),   # Clear Reject
    ])
    def test_process_applications_decisions(self, default_config, mocker, score, expected_decision):
        """FR3: Test admission decisions based on score thresholds."""
        applicant = Applicant(1, 4.0, 1600, 10, 10, "11111")
        
        # Mock the scoring function to return a specific score for this test
        mocker.patch.object(
            AdmissionsProcessor,
            '_calculate_holistic_score',
            return_value=score
        )
        
        processor = AdmissionsProcessor([applicant], default_config)
        processor.process_applications()
        
        assert applicant.holistic_score == score
        assert applicant.decision == expected_decision

    def test_process_applications_empty_list(self, default_config):
        """Test that processing an empty list of applicants runs without error."""
        try:
            processor = AdmissionsProcessor([], default_config)
            processor.process_applications()
        except Exception as e:
            pytest.fail(f"Processing an empty list raised an exception: {e}")


class TestReporting:
    """Tests for the generate_summary_report function."""

    @pytest.fixture
    def processed_cohort(self, default_config):
        """Creates a small, predictable cohort of processed applicants."""
        # Scores are designed to fall into each category
        # Applicant 1: ADMIT (Score ~88.5)
        admit = Applicant(1, 3.9, 1500, 8, 9, "90210") # High stats + geo boost
        # Applicant 2: WAITLIST (Score ~71.5)
        waitlist = Applicant(2, 3.2, 1200, 6, 7, "80202")
        # Applicant 3: REJECT (Score ~45.8)
        reject = Applicant(3, 2.5, 950, 3, 4, "48226")

        cohort = [admit, waitlist, reject]
        processor = AdmissionsProcessor(cohort, default_config)
        processor.process_applications()
        return cohort
    
    def test_report_unprocessed_applicants(self, default_config, average_applicant):
        """FR4: Test report generation for unprocessed data."""
        report = generate_summary_report([average_applicant], default_config)
        assert "No applications have been processed yet" in report

    def test_report_content_and_stats(self, processed_cohort, default_config):
        """FR4/NFR2: Test key metrics and transparency info in the report."""
        report = generate_summary_report(processed_cohort, default_config)
        
        # NFR2: Transparency checks
        assert f"GPA:                {default_config.scoring_weights.gpa:.0%}" in report
        assert f"Admit:              >= {default_config.decision_thresholds.admit}" in report
        assert f"factor of {default_config.geographic_adjustment_factor}" in report
        
        # FR4: Cohort overview checks
        assert "Total Applicants: 3" in report
        assert "Admitted:              1 (33.3%)" in report
        assert "Waitlisted:            1 (33.3%)" in report
        assert "Rejected:              1 (33.3%)" in report
        assert "Acceptance Rate: 33.3%" in report
        
        # FR4: Statistics checks (manual calculation)
        avg_gpa_all = (3.9 + 3.2 + 2.5) / 3
        avg_gpa_admit = 3.9
        assert f"Average GPA:             {avg_gpa_all: >10.2f}" in report
        assert f"{avg_gpa_admit: >12.2f}" in report

    def test_report_no_admits(self, default_config, low_score_applicant):
        """Test report generation when there are no admitted students."""
        processor = AdmissionsProcessor([low_score_applicant], default_config)
        processor.process_applications()
        report = generate_summary_report([low_score_applicant], default_config)

        assert "Admitted:              0 (0.0%)" in report
        assert "Acceptance Rate: 0.0%" in report
        # Check that admitted stats are correctly shown as zero
        assert "0.00" in report.split("ADMITTED COHORT")[-1]

    def test_report_with_empty_list(self, default_config):
        """Test that the report handles an empty list of applicants gracefully."""
        # The current implementation raises ZeroDivisionError. A robust implementation
        # might return a specific message. This test documents the current behavior.
        with pytest.raises(ZeroDivisionError):
             generate_summary_report([], default_config)
        
        # If the function were patched to be more robust, the test would be:
        # report = generate_summary_report([], default_config)
        # assert "No applicants to report on." in report


class TestDataGeneration:
    """Tests for utility functions like data generation."""

    def test_generate_mock_applicants(self):
        """NFR1: Test the mock data generator."""
        count = 50
        applicants = generate_mock_applicants(count)

        assert len(applicants) == count
        assert all(isinstance(app, Applicant) for app in applicants)

        # Spot-check a single applicant's data ranges
        sample = applicants[0]
        assert 10001 <= sample.applicant_id < 10001 + count
        assert 2.5 <= sample.gpa <= 4.0
        assert 900 <= sample.test_score <= 1600
        assert isinstance(sample.postal_code, str)