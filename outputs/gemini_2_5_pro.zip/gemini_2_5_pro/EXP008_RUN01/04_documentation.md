# Technical Documentation: University Admissions Screening System

This document provides detailed technical documentation for the Refactored University Admissions Screening System. It covers the system's architecture, data models, core logic, and functions.

## 1. System Overview

The University Admissions Screening System is a self-contained Python application designed to automate the initial stages of university admissions. It fulfills the following primary objectives:

-   **Data Storage**: Manages applicant data in-memory without external dependencies (FR1, NFR1).
-   **Holistic Scoring**: Calculates a comprehensive score for each applicant based on multiple weighted criteria (FR2).
-   **Automated Decisions**: Assigns an admission decision (Admit, Waitlist, Reject) based on configurable score thresholds (FR3).
-   **Cohort Reporting**: Generates a summary report with key statistics and transparent scoring metrics for the applicant cohort (FR4, NFR2).
-   **Geographic Adjustment**: Applies a predefined positive score adjustment for applicants from specific regions (FR5).

The system is designed with a modular architecture, separating data models, core processing logic, and reporting into distinct components for clarity and maintainability.

---

## 2. Data Models

The system uses enumerations and dataclasses to create clear, immutable, and type-safe data structures.

### 2.1. `DecisionStatus(Enum)`

An enumeration that defines the possible outcomes of an admission decision.

**Members:**

-   `PENDING`: Default status before an applicant is processed.
-   `ADMIT`: The applicant has been accepted.
-   `WAITLIST`: The applicant is on the waitlist.
-   `REJECT`: The applicant has been rejected.

### 2.2. `ScoringWeights(dataclass)`

A frozen dataclass that encapsulates the weighting factors for each component of the holistic score. This ensures that scoring parameters are immutable during a processing run.

**Attributes:**

-   `gpa` (`float`): The weight for the applicant's GPA. Default: `0.40`.
-   `test_score` (`float`): The weight for the standardized test score. Default: `0.30`.
-   `extracurriculars` (`float`): The weight for the extracurricular activities score. Default: `0.15`.
-   `essay` (`float`): The weight for the application essay score. Default: `0.15`.

### 2.3. `DecisionThresholds(dataclass)`

A frozen dataclass defining the minimum holistic scores required for admission or waitlisting.

**Attributes:**

-   `admit` (`float`): The minimum score for an 'Admit' decision. Default: `85.0`.
-   `waitlist` (`float`): The minimum score for a 'Waitlist' decision. Scores below this result in a 'Reject' decision. Default: `70.0`.

### 2.4. `AdmissionsConfig(dataclass)`

A centralized, immutable configuration object that serves as a single source of truth for all system parameters. It consolidates weights, thresholds, and other business rules.

**Attributes:**

-   `scoring_weights` (`ScoringWeights`): An instance of `ScoringWeights`.
-   `decision_thresholds` (`DecisionThresholds`): An instance of `DecisionThresholds`.
-   `high_outcome_postal_codes` (`set[str]`): A set of postal codes that receive a score adjustment, fulfilling **FR5**.
-   `geographic_adjustment_factor` (`float`): The multiplicative factor applied to scores of applicants from the specified postal codes. Default: `1.05`.

**Methods:**

-   `__post_init__(self)`
    -   **Description**: A validation method called automatically after initialization. It ensures that the sum of `scoring_weights` is approximately 1.0 and that the `admit` threshold is strictly greater than the `waitlist` threshold.
    -   **Raises**: `ValueError` if the validation checks fail.

### 2.5. `Applicant`

A class representing a single applicant. It stores their personal data and the results calculated by the system (**FR1**).

**Methods:**

-   `__init__(self, applicant_id: int, gpa: float, test_score: int, extracurricular_score: int, essay_score: int, postal_code: str)`
    -   **Description**: Initializes an `Applicant` instance with their submitted information.
    -   **Parameters**:
        -   `applicant_id` (`int`): A unique identifier for the applicant.
        -   `gpa` (`float`): The applicant's Grade Point Average on a 4.0 scale.
        -   `test_score` (`int`): The applicant's standardized test score (e.g., on a 400-1600 scale).
        -   `extracurricular_score` (`int`): An evaluated score (1-10) for extracurricular involvement.
        -   `essay_score` (`int`): An evaluated score (1-10) for the application essay.
        -   `postal_code` (`str`): The applicant's residential postal code.
-   `__repr__(self) -> str`
    -   **Description**: Provides a developer-friendly string representation of the applicant's processed state.
    -   **Returns**: (`str`) A formatted string showing the applicant's ID, holistic score, and decision.

**Instance Attributes (Populated by `AdmissionsProcessor`):**

-   `holistic_score` (`float`): The calculated holistic score. Initialized to `0.0`.
-   `decision` (`DecisionStatus`): The final admission decision. Initialized to `DecisionStatus.PENDING`.

---

## 3. Core Logic

The core logic is encapsulated within the `AdmissionsProcessor` class, which is responsible for orchestrating the entire evaluation process.

### 3.1. `AdmissionsProcessor`

This class takes a list of applicants and a configuration object, then applies the admissions rules to each applicant.

**Methods:**

-   `__init__(self, applicants: list[Applicant], config: AdmissionsConfig)`
    -   **Description**: Initializes the processor with the applicant pool and system configuration.
    -   **Parameters**:
        -   `applicants` (`list[Applicant]`): A list of `Applicant` objects to be processed.
        -   `config` (`AdmissionsConfig`): The configuration object containing all scoring and decision rules.

-   `_calculate_holistic_score(self, applicant: Applicant) -> float`
    -   **Description**: Computes a holistic score for a single applicant (**FR2**). It normalizes each academic and non-academic factor to a common 100-point scale, applies the configured weights, and adds a geographic adjustment if applicable (**FR5**). The final score is capped at 100.0.
    -   **Parameters**:
        -   `applicant` (`Applicant`): The applicant to be scored.
    -   **Returns**: (`float`) The calculated holistic score, capped at 100.0.

-   `process_applications(self) -> None`
    -   **Description**: The main processing method. It iterates through every applicant in its list, calculates their holistic score using `_calculate_holistic_score`, and assigns a final `DecisionStatus` based on the thresholds defined in the configuration object (**FR3**). This method modifies the `Applicant` objects in-place.
    -   **Returns**: `None`.

---

## 4. Reporting

The reporting function is decoupled from the core logic to promote modularity.

### 4.1. `generate_summary_report(processed_applicants: list[Applicant], config: AdmissionsConfig) -> str`

**Description**:
Generates a formatted, multi-section string report summarizing the results of an admissions cycle (**FR4**). The report includes a transparency section detailing the configuration used (**NFR2**), a cohort overview with decision breakdowns, and comparative statistics for the entire and admitted applicant pools.

**Parameters**:

-   `processed_applicants` (`list[Applicant]`): The list of `Applicant` objects after `AdmissionsProcessor.process_applications()` has been run.
-   `config` (`AdmissionsConfig`): The configuration object that was used for processing.

**Returns**:

-   (`str`) A comprehensive, formatted summary report as a single string. If no applicants have been processed, it returns a message indicating so.

---

## 5. Data Generation and Execution

These functions handle the simulation setup and demonstrate the system's functionality.

### 5.1. `generate_mock_applicants(count: int) -> list[Applicant]`

**Description**:
A utility function that creates a list of randomized `Applicant` objects for demonstration and testing. This allows the application to run without any external data sources, satisfying **NFR1**.

**Parameters**:

-   `count` (`int`): The number of mock applicants to generate.

**Returns**:

-   (`list[Applicant]`) A list of newly created `Applicant` instances.

### 5.2. `main()`

**Description**:
The main entry point for the script. It orchestrates a complete simulation of the admissions process by:
1.  Instantiating the `AdmissionsConfig`.
2.  Generating a mock applicant pool using `generate_mock_applicants`.
3.  Initializing the `AdmissionsProcessor`.
4.  Executing the application processing.
5.  Generating and printing the final summary report.
6.  Printing a small sample of individual results for verification.

**Execution**:
The script is intended to be run directly. The `if __name__ == "__main__":` block ensures that the `main()` function is called when the script is executed.