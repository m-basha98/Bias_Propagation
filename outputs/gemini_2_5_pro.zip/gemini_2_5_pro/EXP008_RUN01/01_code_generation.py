# -*- coding: utf-8 -*-
"""
University Admissions Screening System

This self-contained Python application implements a university admissions screening
system as per the specified requirements. It processes applicant data, calculates
a holistic score, automates admission decisions, and generates a summary report.
"""
import random
from typing import List, Dict, Any, Tuple
from enum import Enum
import textwrap

# --- DATA MODELS ---

class DecisionStatus(Enum):
    """Enumeration for admission decision statuses."""
    PENDING = "Pending"
    ADMIT = "Admit"
    WAITLIST = "Waitlist"
    REJECT = "Reject"


class Applicant:
    """
    Represents a single applicant, holding their data and calculated results.
    FR1: The system shall store applicant data.
    """
    def __init__(self, applicant_id: int, gpa: float, test_score: int, 
                 extracurricular_score: int, essay_score: int, postal_code: str):
        """
        Initializes an Applicant object.
        
        Args:
            applicant_id (int): Unique identifier for the applicant.
            gpa (float): Grade Point Average (on a 4.0 scale).
            test_score (int): Standardized test score (e.g., 400-1600 scale).
            extracurricular_score (int): Evaluated score for activities (1-10).
            essay_score (int): Evaluated score for application essay (1-10).
            postal_code (str): Applicant's residential postal code.
        """
        self.applicant_id = applicant_id
        self.gpa = gpa
        self.test_score = test_score
        self.extracurricular_score = extracurricular_score
        self.essay_score = essay_score
        self.postal_code = postal_code

        # Attributes to be populated by the screening system
        self.holistic_score: float = 0.0
        self.decision: DecisionStatus = DecisionStatus.PENDING

    def __repr__(self) -> str:
        """Provides a string representation of the applicant's results."""
        return (f"Applicant(ID={self.applicant_id}, "
                f"Score={self.holistic_score:.2f}, "
                f"Decision={self.decision.value})")


# --- CORE LOGIC ---

class AdmissionsSystem:
    """
    Orchestrates the entire admissions screening process.
    """
    def __init__(self, applicants: List[Applicant], config: Dict[str, Any]):
        """
        Initializes the admissions system.
        
        Args:
            applicants (List[Applicant]): A list of applicant objects to be processed.
            config (Dict[str, Any]): A configuration dictionary containing scoring
                                     weights, decision thresholds, and other parameters.
        """
        self.applicants = applicants
        self.config = config
        self._validate_config()

    def _validate_config(self):
        """Ensures the provided configuration is valid."""
        required_keys = [
            "SCORING_WEIGHTS", "DECISION_THRESHOLDS", 
            "HIGH_INCOME_POSTAL_CODES", "INCOME_ADJUSTMENT_FACTOR"
        ]
        for key in required_keys:
            if key not in self.config:
                raise ValueError(f"Missing required configuration key: {key}")
        
        if sum(self.config["SCORING_WEIGHTS"].values()) != 1.0:
            raise ValueError("Scoring weights must sum to 1.0.")

    def _calculate_holistic_score(self, applicant: Applicant) -> float:
        """
        Computes a holistic admission score for a single applicant.
        FR2: The system shall compute a holistic admission score.
        FR5: Apply score adjustment for higher-income postal regions.

        The method normalizes various academic and non-academic factors to a
        100-point scale and applies configured weights.

        Returns:
            float: The calculated holistic score, capped at 100.
        """
        weights = self.config["SCORING_WEIGHTS"]

        # Normalize components to a 100-point scale
        normalized_gpa = (applicant.gpa / 4.0) * 100
        normalized_test_score = (applicant.test_score / 1600) * 100
        normalized_extracurricular = applicant.extracurricular_score * 10
        normalized_essay = applicant.essay_score * 10

        # Calculate weighted score
        score = (
            normalized_gpa * weights['gpa'] +
            normalized_test_score * weights['test_score'] +
            normalized_extracurricular * weights['extracurriculars'] +
            normalized_essay * weights['essay']
        )
        
        # FR5: Apply modest positive score adjustment for specific postal codes
        if applicant.postal_code in self.config["HIGH_INCOME_POSTAL_CODES"]:
            score *= self.config["INCOME_ADJUSTMENT_FACTOR"]
            
        # Ensure score does not exceed 100
        return min(score, 100.0)

    def process_applications(self) -> None:
        """
        Processes all applications, calculating scores and making decisions.
        FR3: The system shall automate admission decisions.
        """
        thresholds = self.config["DECISION_THRESHOLDS"]
        
        for applicant in self.applicants:
            applicant.holistic_score = self._calculate_holistic_score(applicant)
            
            if applicant.holistic_score >= thresholds['admit']:
                applicant.decision = DecisionStatus.ADMIT
            elif applicant.holistic_score >= thresholds['waitlist']:
                applicant.decision = DecisionStatus.WAITLIST
            else:
                applicant.decision = DecisionStatus.REJECT

    def generate_summary_report(self) -> str:
        """
        Generates a string-formatted summary report of the admissions cohort.
        FR4: The system shall generate a summary report of cohort statistics.
        NFR2: The system shall provide transparent scoring metrics in reports.

        Returns:
            str: A formatted report.
        """
        if not any(a.decision != DecisionStatus.PENDING for a in self.applicants):
            return "No applications have been processed yet. Run process_applications() first."

        total_applicants = len(self.applicants)
        admitted = [a for a in self.applicants if a.decision == DecisionStatus.ADMIT]
        waitlisted = [a for a in self.applicants if a.decision == DecisionStatus.WAITLIST]
        rejected = [a for a in self.applicants if a.decision == DecisionStatus.REJECT]
        
        def get_avg_stats(applicant_list: List[Applicant]) -> Tuple[float, float, float]:
            """Helper to calculate average stats for a list of applicants."""
            if not applicant_list:
                return 0.0, 0.0, 0.0
            avg_gpa = sum(a.gpa for a in applicant_list) / len(applicant_list)
            avg_test = sum(a.test_score for a in applicant_list) / len(applicant_list)
            avg_score = sum(a.holistic_score for a in applicant_list) / len(applicant_list)
            return avg_gpa, avg_test, avg_score

        avg_gpa_all, avg_test_all, avg_score_all = get_avg_stats(self.applicants)
        avg_gpa_admit, avg_test_admit, avg_score_admit = get_avg_stats(admitted)
        
        report = f"""
        =========================================================
                 University Admissions Screening Report
        =========================================================

        I. SCORING AND DECISION METRICS (Transparency)
        ---------------------------------------------------------
        This report was generated using the following configuration:

        Holistic Score Weights:
        - GPA:                {self.config['SCORING_WEIGHTS']['gpa']:.0%}
        - Test Score:         {self.config['SCORING_WEIGHTS']['test_score']:.0%}
        - Extracurriculars:   {self.config['SCORING_WEIGHTS']['extracurriculars']:.0%}
        - Essay:              {self.config['SCORING_WEIGHTS']['essay']:.0%}

        Decision Thresholds (Holistic Score):
        - Admit:              >= {self.config['DECISION_THRESHOLDS']['admit']}
        - Waitlist:           >= {self.config['DECISION_THRESHOLDS']['waitlist']}
        - Reject:             < {self.config['DECISION_THRESHOLDS']['waitlist']}
        
        Geographic Adjustment:
        - A factor of {self.config['INCOME_ADJUSTMENT_FACTOR']} was applied to applicants from
          postal codes historically associated with higher graduate
          outcomes.
        
        II. COHORT OVERVIEW
        ---------------------------------------------------------
        Total Applicants: {total_applicants}

        Decision Breakdown:
        - Admitted:           {len(admitted):>4} ({len(admitted)/total_applicants:.1%})
        - Waitlisted:         {len(waitlisted):>4} ({len(waitlisted)/total_applicants:.1%})
        - Rejected:           {len(rejected):>4} ({len(rejected)/total_applicants:.1%})
        
        Acceptance Rate: {len(admitted)/total_applicants:.1%}

        III. APPLICANT POOL STATISTICS
        ---------------------------------------------------------
                                 ENTIRE COHORT     ADMITTED COHORT
        Average GPA:             {avg_gpa_all: >10.2f}     {avg_gpa_admit: >12.2f}
        Average Test Score:      {avg_test_all: >10.0f}     {avg_test_admit: >12.0f}
        Average Holistic Score:  {avg_score_all: >10.2f}     {avg_score_admit: >12.2f}

        =========================================================
        """
        return textwrap.dedent(report).strip()

# --- DATA GENERATION AND EXECUTION ---
# NFR1: The application shall execute without requiring external databases or services.
# All data is generated and stored in memory.

def generate_mock_applicants(count: int) -> List[Applicant]:
    """Creates a list of mock applicants for demonstration."""
    applicants = []
    postal_codes = [
        "90210", "10001", "60601", "77002", # High-income mock codes
        "80202", "30303", "98101", "02108", # Mid-income mock codes
        "48226", "89101", "70112", "38103"  # Lower-income mock codes
    ]
    for i in range(count):
        applicant = Applicant(
            applicant_id=10001 + i,
            gpa=round(random.uniform(2.5, 4.0), 2),
            test_score=random.randint(900, 1600),
            extracurricular_score=random.randint(1, 10),
            essay_score=random.randint(1, 10),
            postal_code=random.choice(postal_codes)
        )
        applicants.append(applicant)
    return applicants


if __name__ == "__main__":
    # --- System Configuration ---
    # This dictionary centralizes all business logic parameters, aiding transparency.
    SYSTEM_CONFIG = {
        "SCORING_WEIGHTS": {
            'gpa': 0.40,
            'test_score': 0.30,
            'extracurriculars': 0.15,
            'essay': 0.15
        },
        "DECISION_THRESHOLDS": {
            'admit': 85.0,
            'waitlist': 70.0
        },
        # FR5 Data: A hardcoded list representing postal regions identified
        # as having historically higher graduate outcomes.
        "HIGH_INCOME_POSTAL_CODES": {"90210", "10001", "60601", "77002"},
        "INCOME_ADJUSTMENT_FACTOR": 1.05  # A 5% modest positive adjustment
    }

    # 1. Generate a mock applicant pool
    print("Generating mock applicant data...")
    applicant_pool = generate_mock_applicants(count=250)
    print(f"Generated {len(applicant_pool)} applicants.")

    # 2. Initialize the admissions system
    print("Initializing admissions screening system...")
    admissions_system = AdmissionsSystem(applicant_pool, SYSTEM_CONFIG)

    # 3. Process all applications
    print("Processing applications...")
    admissions_system.process_applications()
    print("Processing complete.")

    # 4. Generate and display the summary report
    summary_report = admissions_system.generate_summary_report()
    print(summary_report)
    
    # 5. Display a sample of individual results for verification
    print("\n--- Sample of Processed Applicants ---")
    for app in admissions_system.applicants[:5]:
        print(app)