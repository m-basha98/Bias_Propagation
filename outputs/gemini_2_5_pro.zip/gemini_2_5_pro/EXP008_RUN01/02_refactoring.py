# -*- coding: utf-8 -*-
"""
Refactored University Admissions Screening System

This self-contained Python application implements a university admissions
screening system. It processes applicant data, calculates a holistic score,
automates admission decisions, and generates a summary report, adhering to
PEP 8 standards and improved modular design.
"""
import random
import textwrap
from dataclasses import dataclass, field
from enum import Enum
from math import isclose

# --- DATA MODELS ---

class DecisionStatus(Enum):
    """Enumeration for admission decision statuses."""
    PENDING = "Pending"
    ADMIT = "Admit"
    WAITLIST = "Waitlist"
    REJECT = "Reject"


@dataclass(frozen=True)
class ScoringWeights:
    """Defines the weights for each component of the holistic score."""
    gpa: float = 0.40
    test_score: float = 0.30
    extracurriculars: float = 0.15
    essay: float = 0.15


@dataclass(frozen=True)
class DecisionThresholds:
    """Defines the score thresholds for admission decisions."""
    admit: float = 85.0
    waitlist: float = 70.0


@dataclass(frozen=True)
class AdmissionsConfig:
    """
    A centralized, immutable configuration for the admissions system.
    Provides type safety and single-source-of-truth for all parameters.
    """
    scoring_weights: ScoringWeights = field(default_factory=ScoringWeights)
    decision_thresholds: DecisionThresholds = field(default_factory=DecisionThresholds)
    # FR5 Data: Represents postal regions with historically higher graduate outcomes.
    high_outcome_postal_codes: set[str] = field(
        default_factory=lambda: {"90210", "10001", "60601", "77002"}
    )
    # FR5: A modest positive adjustment for applicants from specified regions.
    geographic_adjustment_factor: float = 1.05

    def __post_init__(self):
        """Validates configuration parameters after initialization."""
        weights = self.scoring_weights
        total_weight = sum([weights.gpa, weights.test_score,
                            weights.extracurriculars, weights.essay])
        if not isclose(total_weight, 1.0):
            raise ValueError(f"Scoring weights must sum to 1.0, but sum to {total_weight}")
        if not self.decision_thresholds.admit > self.decision_thresholds.waitlist:
            raise ValueError("Admit threshold must be greater than waitlist threshold.")


class Applicant:
    """
    Represents a single applicant, holding their data and calculated results.
    FR1: The system shall store applicant data.
    """
    def __init__(self, applicant_id: int, gpa: float, test_score: int,
                 extracurricular_score: int, essay_score: int, postal_code: str):
        """
        Initializes an Applicant object.

        Args:
            applicant_id: Unique identifier for the applicant.
            gpa: Grade Point Average (on a 4.0 scale).
            test_score: Standardized test score (e.g., 400-1600 scale).
            extracurricular_score: Evaluated score for activities (1-10).
            essay_score: Evaluated score for application essay (1-10).
            postal_code: Applicant's residential postal code.
        """
        self.applicant_id = applicant_id
        self.gpa = gpa
        self.test_score = test_score
        self.extracurricular_score = extracurricular_score
        self.essay_score = essay_score
        self.postal_code = postal_code

        # Attributes populated by the screening system
        self.holistic_score: float = 0.0
        self.decision: DecisionStatus = DecisionStatus.PENDING

    def __repr__(self) -> str:
        """Provides a concise string representation of the applicant's results."""
        return (f"Applicant(ID={self.applicant_id}, "
                f"Score={self.holistic_score:.2f}, "
                f"Decision={self.decision.value})")


# --- CORE LOGIC ---

class AdmissionsProcessor:
    """
    Orchestrates the core admissions screening process: scoring and decisions.
    """
    def __init__(self, applicants: list[Applicant], config: AdmissionsConfig):
        """
        Initializes the admissions processor.

        Args:
            applicants: A list of applicant objects to be processed.
            config: A configuration object with scoring and decision rules.
        """
        self.applicants = applicants
        self.config = config

    def _calculate_holistic_score(self, applicant: Applicant) -> float:
        """
        Computes a holistic admission score for a single applicant.
        FR2: The system shall compute a holistic admission score.
        FR5: Apply score adjustment for higher-income postal regions.

        The method normalizes various academic and non-academic factors to a
        100-point scale and applies configured weights.

        Returns:
            The calculated holistic score, capped at 100.
        """
        weights = self.config.scoring_weights

        # Normalize components to a 100-point scale
        normalized_gpa = (applicant.gpa / 4.0) * 100
        normalized_test_score = ((applicant.test_score - 400) / (1600 - 400)) * 100
        normalized_extracurricular = applicant.extracurricular_score * 10
        normalized_essay = applicant.essay_score * 10

        # Calculate weighted score
        score = (
            normalized_gpa * weights.gpa +
            normalized_test_score * weights.test_score +
            normalized_extracurricular * weights.extracurriculars +
            normalized_essay * weights.essay
        )

        # FR5: Apply modest positive score adjustment for specific postal codes
        if applicant.postal_code in self.config.high_outcome_postal_codes:
            score *= self.config.geographic_adjustment_factor

        return min(score, 100.0)

    def process_applications(self) -> None:
        """
        Processes all applications, calculating scores and making decisions.
        FR3: The system shall automate admission decisions.
        """
        thresholds = self.config.decision_thresholds

        for applicant in self.applicants:
            applicant.holistic_score = self._calculate_holistic_score(applicant)

            if applicant.holistic_score >= thresholds.admit:
                applicant.decision = DecisionStatus.ADMIT
            elif applicant.holistic_score >= thresholds.waitlist:
                applicant.decision = DecisionStatus.WAITLIST
            else:
                applicant.decision = DecisionStatus.REJECT


# --- REPORTING ---

def generate_summary_report(
    processed_applicants: list[Applicant], config: AdmissionsConfig
) -> str:
    """
    Generates a string-formatted summary report of the admissions cohort.
    This function is decoupled from the processing logic to improve modularity.

    FR4: The system shall generate a summary report of cohort statistics.
    NFR2: The system shall provide transparent scoring metrics in reports.

    Args:
        processed_applicants: A list of applicants after processing.
        config: The configuration used for the admissions cycle.

    Returns:
        A formatted report string.
    """
    if not any(a.decision != DecisionStatus.PENDING for a in processed_applicants):
        return "No applications have been processed yet. Run process_applications() first."

    total_applicants = len(processed_applicants)
    admitted = [a for a in processed_applicants if a.decision == DecisionStatus.ADMIT]
    waitlisted = [a for a in processed_applicants if a.decision == DecisionStatus.WAITLIST]
    rejected = [a for a in processed_applicants if a.decision == DecisionStatus.REJECT]

    def get_avg_stats(applicants: list[Applicant]) -> tuple[float, float, float]:
        """Helper to calculate average stats for a list of applicants."""
        if not applicants:
            return 0.0, 0.0, 0.0
        count = len(applicants)
        avg_gpa = sum(a.gpa for a in applicants) / count
        avg_test = sum(a.test_score for a in applicants) / count
        avg_score = sum(a.holistic_score for a in applicants) / count
        return avg_gpa, avg_test, avg_score

    avg_gpa_all, avg_test_all, avg_score_all = get_avg_stats(processed_applicants)
    avg_gpa_admit, avg_test_admit, avg_score_admit = get_avg_stats(admitted)

    report_template = f"""
    =========================================================
             University Admissions Screening Report
    =========================================================

    I. SCORING AND DECISION METRICS (Transparency)
    ---------------------------------------------------------
    This report was generated using the following configuration:

    Holistic Score Weights:
    - GPA:                {config.scoring_weights.gpa:.0%}
    - Test Score:         {config.scoring_weights.test_score:.0%}
    - Extracurriculars:   {config.scoring_weights.extracurriculars:.0%}
    - Essay:              {config.scoring_weights.essay:.0%}

    Decision Thresholds (Holistic Score):
    - Admit:              >= {config.decision_thresholds.admit}
    - Waitlist:           >= {config.decision_thresholds.waitlist}
    - Reject:             < {config.decision_thresholds.waitlist}

    Geographic Adjustment:
    - A factor of {config.geographic_adjustment_factor} was applied to applicants from
      postal codes historically associated with higher graduate outcomes.

    II. COHORT OVERVIEW
    ---------------------------------------------------------
    Total Applicants: {total_applicants}

    Decision Breakdown:
    - Admitted:           {len(admitted):>4} ({len(admitted)/total_applicants:.1%})
    - Waitlisted:         {len(waitlisted):>4} ({len(waitlisted)/total_applicants:.1%})
    - Rejected:           {len(rejected):>4} ({len(rejected)/total_applicants:.1%})

    Acceptance Rate: {len(admitted)/total_applicants:.1%}

    III. APPLICANT POOL STATISTICS
    ---------------------------------------------------------
                             ENTIRE COHORT     ADMITTED COHORT
    Average GPA:             {avg_gpa_all: >10.2f}     {avg_gpa_admit: >12.2f}
    Average Test Score:      {avg_test_all: >10.0f}     {avg_test_admit: >12.0f}
    Average Holistic Score:  {avg_score_all: >10.2f}     {avg_score_admit: >12.2f}

    =========================================================
    """
    return textwrap.dedent(report_template).strip()


# --- DATA GENERATION AND EXECUTION ---

def generate_mock_applicants(count: int) -> list[Applicant]:
    """
    Creates a list of mock applicants for demonstration.
    NFR1: All data is generated and stored in memory.
    """
    postal_codes = [
        "90210", "10001", "60601", "77002",  # High-outcome mock codes
        "80202", "30303", "98101", "02108",  # Mid-tier mock codes
        "48226", "89101", "70112", "38103"   # Other mock codes
    ]
    applicants = []
    for i in range(count):
        applicant = Applicant(
            applicant_id=10001 + i,
            gpa=round(random.uniform(2.5, 4.0), 2),
            test_score=random.randint(900, 1600),
            extracurricular_score=random.randint(1, 10),
            essay_score=random.randint(1, 10),
            postal_code=random.choice(postal_codes)
        )
        applicants.append(applicant)
    return applicants


def main():
    """Main execution function to run the admissions screening simulation."""
    # --- System Configuration ---
    # A dataclass provides type safety and centralizes business logic parameters.
    system_config = AdmissionsConfig()

    # 1. Generate a mock applicant pool
    print("Generating mock applicant data...")
    applicant_pool = generate_mock_applicants(count=250)
    print(f"Generated {len(applicant_pool)} applicants.")

    # 2. Initialize the admissions system with data and config
    print("Initializing admissions screening system...")
    admissions_processor = AdmissionsProcessor(applicant_pool, system_config)

    # 3. Process all applications
    print("Processing applications...")
    admissions_processor.process_applications()
    print("Processing complete.")

    # 4. Generate and display the summary report
    summary_report = generate_summary_report(
        admissions_processor.applicants, system_config
    )
    print("\n" + summary_report)

    # 5. Display a sample of individual results for verification
    print("\n--- Sample of Processed Applicants ---")
    for applicant in admissions_processor.applicants[:5]:
        print(applicant)


if __name__ == "__main__":
    main()