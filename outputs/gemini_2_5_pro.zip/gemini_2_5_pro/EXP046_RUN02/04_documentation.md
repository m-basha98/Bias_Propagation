Here is the detailed technical documentation for the provided Python software.

***

# Technical Documentation: Housing Allocation System

## 1. Overview

This document provides a detailed technical explanation of the `Housing Allocation System` software. The system is a self-contained Python application designed to manage and process housing applications. It calculates a 'Tenant Viability' score for each applicant, prioritizes certain household structures, and determines an application status (Approved, Denied, or Waitlisted). The system operates without external dependencies like databases and ensures all data processing is deterministic and reproducible.

The architecture is modular, separating concerns into distinct components:
- **Configuration:** A centralized, immutable object holding all business rules and constants.
- **Data Models:** `dataclass` structures representing the core entities of the system (e.g., Applicant, Application).
- **Core Services:** Stateless classes responsible for specific logic, such as scoring (`ScoringService`) and reporting (`ReportGenerator`).
- **Orchestrator:** A main system class (`HousingAllocationSystem`) that manages the workflow and state.
- **Demonstration:** An executable block that populates the system with sample data and demonstrates its functionality.

---

## 2. Module: `housing_allocation_system`

This is the main module containing all the necessary code to run the application.

### 2.1. Class: `SystemConfiguration`

A frozen (immutable) `dataclass` that centralizes all static configuration and business rules for the system. This ensures that critical values like scoring weights and decision thresholds are not accidentally modified during runtime.

#### Attributes:
-   `SCORE_WEIGHT_CREDIT` (float): The weight (40%) applied to the normalized credit score when calculating the viability score.
-   `SCORE_WEIGHT_DTI` (float): The weight (40%) applied to the debt-to-income (DTI) score.
-   `SCORE_WEIGHT_EMPLOYMENT` (float): The weight (20%) applied to the employment status score.
-   `APPROVE_THRESHOLD` (float): The minimum final allocation score (95.0) required for an application to be `APPROVED`.
-   `DENY_THRESHOLD` (float): Any application with a final allocation score below this value (60.0) will be `DENIED`. Scores between this and the approve threshold are `WAITLISTED`.
-   `HISTORICAL_HOUSEHOLDS` (Tuple[ApplicantHousehold, ...]): A tuple of `ApplicantHousehold` objects representing historically common family structures. This data is used to calculate the household match bonus.
-   `HOUSEHOLD_MATCH_MAX_BONUS` (float): The maximum bonus points (20.0) that can be added to the final allocation score for a perfect household match.

---

## 3. Data Models & Enumerations

These models define the structure of the data used throughout the application, satisfying **FR1**.

### 3.1. Enum: `EmploymentStatus`
Enumeration for the employment status of an applicant.

#### Members:
-   `EMPLOYED`
-   `UNEMPLOYED`
-   `STUDENT`

### 3.2. Enum: `ApplicationStatus`
Enumeration for the status of a lease application.

#### Members:
-   `PENDING`: The initial status of a newly submitted application.
-   `APPROVED`: The status for an application that meets the approval criteria.
-   `DENIED`: The status for an application that fails to meet the minimum criteria.
-   `WAITLISTED`: The status for an application that is neither approved nor denied.

### 3.3. Dataclass: `ApplicantFinancials`
An immutable `dataclass` representing an applicant's financial profile.

#### Attributes:
-   `credit_score` (int): The applicant's credit score (e.g., 300-850).
-   `monthly_income` (float): The applicant's total monthly gross income.
-   `monthly_debt` (float): The applicant's total monthly debt payments.

#### Methods:
-   `debt_to_income_ratio() -> float`
    -   **Description:** Calculates the debt-to-income (DTI) ratio.
    -   **Returns:** (`float`) The ratio of monthly debt to monthly income. Returns `inf` if income is zero.

### 3.4. Dataclass: `ApplicantHousehold`
An immutable `dataclass` representing an applicant's household structure.

#### Attributes:
-   `adults` (int): The number of adults in the household.
-   `children` (int): The number of children in the household.

### 3.5. Dataclass: `Applicant`
An immutable `dataclass` representing a complete applicant profile.

#### Attributes:
-   `applicant_id` (str): A unique identifier for the applicant.
-   `financials` (ApplicantFinancials): The applicant's financial data.
-   `household` (ApplicantHousehold): The applicant's household structure.
-   `employment_status` (EmploymentStatus): The applicant's current employment status.

### 3.6. Dataclass: `Application`
A mutable `dataclass` representing a lease application. Its status and scores change during processing.

#### Attributes:
-   `application_id` (str): A unique identifier for the application.
-   `applicant` (Applicant): The applicant associated with this application.
-   `submission_date` (datetime.date): The date the application was submitted.
-   `status` (ApplicationStatus): The current status of the application. Defaults to `PENDING`.
-   `scores` (Dict[str, float]): A dictionary to store the various scores calculated during processing. Defaults to an empty dictionary.

---

## 4. Core Services

These classes contain the core business logic, decoupled from the main application state.

### 4.1. Class: `ScoringService`
A stateless service responsible for all scoring calculations. It takes a `SystemConfiguration` object upon initialization to access business rules.

#### Methods:

-   `__init__(self, config: SystemConfiguration)`
    -   **Description:** Initializes the service with a configuration object.
    -   **Parameters:**
        -   `config` (`SystemConfiguration`): The system configuration object containing scoring weights and thresholds.

-   `calculate_all_scores(self, applicant: Applicant) -> Dict[str, float]`
    -   **Description:** The primary public method that orchestrates the calculation of all component scores (**FR2**) and a final allocation score, which includes a bonus for household matching (**FR5**).
    -   **Parameters:**
        -   `applicant` (`Applicant`): The applicant object to be scored.
    -   **Returns:** (`Dict[str, float]`) A dictionary containing all calculated scores. Keys include:
        -   `credit_score_normalized`: Credit score on a 0-100 scale.
        -   `dti_score`: Debt-to-income score on a 0-100 scale.
        -   `employment_score`: Employment status score on a 0-100 scale.
        -   `viability_score`: The weighted average of the above three scores.
        -   `household_bonus`: A bonus score based on matching historical household data.
        -   `allocation_score`: The final score (`viability_score` + `household_bonus`).

-   `_normalize_credit_score(self, score: int) -> float`
    -   **Description:** A private helper method that normalizes a credit score from the standard 300-850 range to a 0-100 scale.
    -   **Parameters:**
        -   `score` (`int`): The raw credit score.
    -   **Returns:** (`float`) The normalized score, clamped between 0.0 and 100.0.

-   `_calculate_dti_score(self, dti_ratio: float) -> float`
    -   **Description:** A private helper method that scores the DTI ratio on a 0-100 scale, where a lower DTI is better.
    -   **Parameters:**
        -   `dti_ratio` (`float`): The applicant's debt-to-income ratio.
    -   **Returns:** (`float`) A score between 0.0 and 100.0.

-   `_get_employment_score(self, status: EmploymentStatus) -> float`
    -   **Description:** A private helper method that maps an `EmploymentStatus` enum to a numerical score.
    -   **Parameters:**
        -   `status` (`EmploymentStatus`): The applicant's employment status.
    -   **Returns:** (`float`) The corresponding score (e.g., 100.0 for `EMPLOYED`).

-   `_calculate_household_match_bonus(self, household: ApplicantHousehold) -> float`
    -   **Description:** A private helper method that calculates a bonus score based on how closely an applicant's household structure matches the `HISTORICAL_HOUSEHOLDS` defined in the configuration.
    -   **Parameters:**
        -   `household` (`ApplicantHousehold`): The applicant's household structure.
    -   **Returns:** (`float`) A bonus score, with the maximum value for a perfect match.

### 4.2. Class: `ReportGenerator`
A service responsible for creating formatted string-based reports.

#### Methods:

-   `generate_daily_report(self, applications: List[Application]) -> str`
    -   **Description:** Generates a daily summary report of all approved and pending applications, satisfying **FR4**. The report is sorted to show the highest-scoring approved applications first.
    -   **Parameters:**
        -   `applications` (`List[Application]`): A list of all application objects in the system.
    -   **Returns:** (`str`) A formatted, multi-line string representing the daily report.

---

## 5. Main System Class (Orchestrator)

### 5.1. Class: `HousingAllocationSystem`
The main orchestrator class that manages the system's state and workflow. It holds the in-memory data stores for applicants and applications, fulfilling **NFR1** (no external databases).

#### Attributes:
-   `_config` (`SystemConfiguration`): The system configuration instance.
-   `_scoring_service` (`ScoringService`): An instance of the scoring service.
-   `_report_generator` (`ReportGenerator`): An instance of the report generator.
-   `_applicants` (`Dict[str, Applicant]`): In-memory storage for registered applicants, keyed by `applicant_id`.
-   `_applications` (`Dict[str, Application]`): In-memory storage for submitted applications, keyed by `application_id`.
-   `_next_app_id_counter` (int): A counter to generate unique application IDs.

#### Methods:

-   `__init__(self, config: SystemConfiguration)`
    -   **Description:** Initializes the system, its services, and its in-memory data stores.
    -   **Parameters:**
        -   `config` (`SystemConfiguration`): The configuration object for the system.

-   `register_applicant(self, applicant: Applicant) -> None`
    -   **Description:** Registers a new applicant and stores their data in memory.
    -   **Parameters:**
        -   `applicant` (`Applicant`): The applicant object to register.
    -   **Returns:** `None`.
    -   **Raises:** `ValueError` if an applicant with the same ID already exists.

-   `submit_application(self, applicant_id: str) -> Optional[Application]`
    -   **Description:** Creates and submits a new application for a registered applicant.
    -   **Parameters:**
        -   `applicant_id` (`str`): The ID of the applicant for whom to create the application.
    -   **Returns:** (`Optional[Application]`) The newly created `Application` object, or `None` if the applicant ID was not found.

-   `process_applications(self) -> None`
    -   **Description:** Iterates through all `PENDING` applications, calculates their scores using the `ScoringService`, and updates their status based on the results. This fulfills **FR3** and is designed to be deterministic, satisfying **NFR2**.
    -   **Parameters:** None.
    -   **Returns:** `None`.

-   `_determine_status_from_score(self, score: float) -> ApplicationStatus`
    -   **Description:** A private helper method that maps a final allocation score to an `ApplicationStatus` based on the thresholds defined in the configuration.
    -   **Parameters:**
        -   `score` (`float`): The final allocation score.
    -   **Returns:** (`ApplicationStatus`) The determined status (`APPROVED`, `DENIED`, or `WAITLISTED`).

-   `get_daily_report(self) -> str`
    -   **Description:** Generates and returns the daily report by delegating to the `ReportGenerator` service.
    -   **Parameters:** None.
    -   **Returns:** (`str`) The formatted daily report string.

---

## 6. Execution & Demonstration

This section contains functions used to run and demonstrate the system.

### 6.1. Function: `generate_sample_data`
-   `generate_sample_data(system: HousingAllocationSystem, count: int)`
    -   **Description:** A utility function that creates and registers a specified number of sample applicants and their corresponding applications. It uses a fixed random seed (`42`) to ensure the generated data is deterministic and reproducible for every run.
    -   **Parameters:**
        -   `system` (`HousingAllocationSystem`): The system instance to populate.
        -   `count` (`int`): The number of sample applicants to generate.
    -   **Returns:** `None`.

### 6.2. Function: `main`
-   `main()`
    -   **Description:** The main entry point of the script. It demonstrates the end-to-end workflow of the system:
        1.  Initializes the `HousingAllocationSystem`.
        2.  Populates it with sample data using `generate_sample_data`.
        3.  Processes all pending applications.
        4.  Generates and prints the daily report.
        5.  Demonstrates submitting and processing a new, high-quality application to show how the system state and report are updated.
    -   **Parameters:** None.
    -   **Returns:** `None`.