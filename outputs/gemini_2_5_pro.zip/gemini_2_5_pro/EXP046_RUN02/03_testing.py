#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Unit tests for the Housing Allocation System.

This test suite uses pytest to validate the functionality of the housing
allocation system, covering data models, services, and the main system
orchestrator. It includes tests for standard scenarios, boundary conditions,
and edge cases to ensure correctness and robustness.
"""

import datetime
from unittest.mock import patch

import pytest

# Assuming the refactored code is in a file named 'housing_allocation_system.py'
# In a real project structure, this would be a proper import from a package.
from housing_allocation_system import (
    Applicant,
    ApplicantFinancials,
    ApplicantHousehold,
    Application,
    ApplicationStatus,
    EmploymentStatus,
    HousingAllocationSystem,
    ReportGenerator,
    ScoringService,
    SystemConfiguration,
)

# =============================================================================
# --- 1. Fixtures for Reusable Components
# =============================================================================


@pytest.fixture(scope="module")
def config() -> SystemConfiguration:
    """Provides a default, immutable SystemConfiguration instance for the module."""
    return SystemConfiguration()


@pytest.fixture
def scoring_service(config: SystemConfiguration) -> ScoringService:
    """Provides a ScoringService instance initialized with the default config."""
    return ScoringService(config)


@pytest.fixture
def report_generator() -> ReportGenerator:
    """Provides a ReportGenerator instance."""
    return ReportGenerator()


@pytest.fixture
def system(config: SystemConfiguration) -> HousingAllocationSystem:
    """Provides a clean HousingAllocationSystem instance for each test."""
    return HousingAllocationSystem(config)


@pytest.fixture
def sample_applicant_ideal() -> Applicant:
    """Provides a sample applicant with ideal characteristics."""
    return Applicant(
        applicant_id="IDEAL-001",
        financials=ApplicantFinancials(
            credit_score=850, monthly_income=10000, monthly_debt=1000
        ),
        household=ApplicantHousehold(adults=2, children=2),  # Perfect match
        employment_status=EmploymentStatus.EMPLOYED,
    )


@pytest.fixture
def sample_applicant_poor() -> Applicant:
    """Provides a sample applicant with poor characteristics."""
    return Applicant(
        applicant_id="POOR-001",
        financials=ApplicantFinancials(
            credit_score=400, monthly_income=2000, monthly_debt=1500
        ),
        household=ApplicantHousehold(adults=5, children=5),  # Poor match
        employment_status=EmploymentStatus.UNEMPLOYED,
    )


# =============================================================================
# --- 2. Data Model Tests
# =============================================================================


class TestApplicantFinancials:
    """Tests the ApplicantFinancials data model and its methods."""

    def test_dti_ratio_standard(self):
        """Tests DTI calculation with standard positive income and debt."""
        financials = ApplicantFinancials(
            credit_score=700, monthly_income=5000, monthly_debt=2000
        )
        assert financials.debt_to_income_ratio() == pytest.approx(0.4)

    def test_dti_ratio_zero_debt(self):
        """Tests DTI calculation when debt is zero."""
        financials = ApplicantFinancials(
            credit_score=700, monthly_income=5000, monthly_debt=0
        )
        assert financials.debt_to_income_ratio() == 0.0

    def test_dti_ratio_zero_income(self):
        """Tests DTI calculation for zero income, which should result in infinity."""
        financials = ApplicantFinancials(
            credit_score=700, monthly_income=0, monthly_debt=2000
        )
        assert financials.debt_to_income_ratio() == float("inf")

    def test_dti_ratio_zero_income_and_debt(self):
        """Tests DTI calculation when both income and debt are zero."""
        financials = ApplicantFinancials(
            credit_score=700, monthly_income=0, monthly_debt=0
        )
        assert financials.debt_to_income_ratio() == float("inf")


# =============================================================================
# --- 3. ScoringService Tests
# =============================================================================


class TestScoringService:
    """Tests all scoring logic within the ScoringService."""

    @pytest.mark.parametrize(
        "score, expected",
        [
            (850, 100.0),  # Boundary max
            (300, 0.0),  # Boundary min
            (575, 50.0),  # Mid-point
            (900, 100.0),  # Edge case > max (clamped)
            (200, 0.0),  # Edge case < min (clamped)
        ],
    )
    def test_normalize_credit_score(
        self, scoring_service: ScoringService, score, expected
    ):
        """Tests credit score normalization across its range and boundaries."""
        assert scoring_service._normalize_credit_score(score) == pytest.approx(expected)

    @pytest.mark.parametrize(
        "dti, expected",
        [
            (0.20, 100.0),  # Ideal DTI
            (0.36, 100.0),  # Boundary ideal
            (0.50, 0.0),  # Boundary poor
            (0.60, 0.0),  # Poor DTI
            (0.43, 50.0),  # Mid-point linear interpolation
            (float("inf"), 0.0),  # Edge case for zero income
        ],
    )
    def test_calculate_dti_score(self, scoring_service: ScoringService, dti, expected):
        """Tests DTI scoring, including thresholds and linear interpolation."""
        assert scoring_service._calculate_dti_score(dti) == pytest.approx(expected)

    @pytest.mark.parametrize(
        "status, expected",
        [
            (EmploymentStatus.EMPLOYED, 100.0),
            (EmploymentStatus.STUDENT, 60.0),
            (EmploymentStatus.UNEMPLOYED, 10.0),
        ],
    )
    def test_get_employment_score(
        self, scoring_service: ScoringService, status, expected
    ):
        """Tests the mapping of employment status to a numerical score."""
        assert scoring_service._get_employment_score(status) == pytest.approx(expected)

    @pytest.mark.parametrize(
        "adults, children, expected_bonus_multiplier",
        [
            (2, 2, 1.0),  # Perfect match -> full bonus
            (1, 0, 1.0),  # Perfect match
            (2, 3, 0.75),  # Distance 1 -> 75% bonus
            (3, 2, 0.75),  # Distance 1
            (3, 3, 0.5),  # Distance 2 -> 50% bonus
            (0, 0, 0.5),  # Distance 2 from (1,0)
            (5, 5, 0.0),  # Large distance -> no bonus
        ],
    )
    def test_calculate_household_match_bonus(
        self,
        scoring_service: ScoringService,
        config: SystemConfiguration,
        adults,
        children,
        expected_bonus_multiplier,
    ):
        """Tests household bonus calculation based on Manhattan distance."""
        household = ApplicantHousehold(adults=adults, children=children)
        expected_bonus = config.HOUSEHOLD_MATCH_MAX_BONUS * expected_bonus_multiplier
        assert scoring_service._calculate_household_match_bonus(
            household
        ) == pytest.approx(expected_bonus)

    def test_calculate_all_scores_ideal_applicant(
        self,
        scoring_service: ScoringService,
        sample_applicant_ideal: Applicant,
        config: SystemConfiguration,
    ):
        """Integration test for scoring an ideal applicant."""
        scores = scoring_service.calculate_all_scores(sample_applicant_ideal)

        # Expected components
        expected_credit_norm = 100.0
        expected_dti_score = 100.0  # DTI is 0.1
        expected_employment_score = 100.0
        expected_viability = (
            expected_credit_norm * config.SCORE_WEIGHT_CREDIT
            + expected_dti_score * config.SCORE_WEIGHT_DTI
            + expected_employment_score * config.SCORE_WEIGHT_EMPLOYMENT
        )
        expected_bonus = config.HOUSEHOLD_MATCH_MAX_BONUS
        expected_allocation = expected_viability + expected_bonus

        assert scores["allocation_score"] == pytest.approx(expected_allocation)
        assert scores["viability_score"] == pytest.approx(expected_viability)
        assert scores["household_bonus"] == pytest.approx(expected_bonus)
        assert set(scores.keys()) == {
            "credit_score_normalized",
            "dti_score",
            "employment_score",
            "viability_score",
            "household_bonus",
            "allocation_score",
        }

    def test_calculate_all_scores_poor_applicant(
        self,
        scoring_service: ScoringService,
        sample_applicant_poor: Applicant,
        config: SystemConfiguration,
    ):
        """Integration test for scoring a poor applicant."""
        scores = scoring_service.calculate_all_scores(sample_applicant_poor)

        # Expected components
        expected_credit_norm = ((400 - 300) / (850 - 300)) * 100  # approx 18.18
        expected_dti_score = 0.0  # DTI is 0.75
        expected_employment_score = 10.0
        expected_viability = (
            expected_credit_norm * config.SCORE_WEIGHT_CREDIT
            + expected_dti_score * config.SCORE_WEIGHT_DTI
            + expected_employment_score * config.SCORE_WEIGHT_EMPLOYMENT
        )
        expected_bonus = 0.0
        expected_allocation = expected_viability + expected_bonus

        assert scores["allocation_score"] == pytest.approx(expected_allocation)
        assert scores["viability_score"] == pytest.approx(expected_viability)


# =============================================================================
# --- 4. ReportGenerator Tests
# =============================================================================


class TestReportGenerator:
    """Tests the generation of formatted daily reports."""

    @pytest.fixture
    def applications(
        self, sample_applicant_ideal, sample_applicant_poor
    ) -> list[Application]:
        """A list of applications with various statuses for report testing."""
        today = datetime.date.today()

        app1 = Application("APP-001", sample_applicant_ideal, today)
        app1.status = ApplicationStatus.APPROVED
        app1.scores = {"allocation_score": 120.0}

        app2 = Application("APP-002", sample_applicant_poor, today)
        app2.status = ApplicationStatus.PENDING

        app3 = Application("APP-003", sample_applicant_ideal, today)
        app3.status = ApplicationStatus.APPROVED
        app3.scores = {"allocation_score": 110.0}

        app4 = Application("APP-004", sample_applicant_poor, today)
        app4.status = ApplicationStatus.DENIED  # Should not appear in this report

        return [app1, app2, app3, app4]

    def test_generate_daily_report_mixed_statuses(
        self, report_generator: ReportGenerator, applications: list[Application]
    ):
        """Tests a report with a mix of approved and pending applications."""
        report = report_generator.generate_daily_report(applications)

        assert "HOUSING ALLOCATION DAILY REPORT" in report
        assert "--- APPROVED APPLICATIONS ---" in report
        assert "--- PENDING APPLICATIONS ---" in report

        # Check for approved application details and correct descending score order
        assert "ID: APP-001 | Applicant: IDEAL-001 | Score: 120.00" in report
        assert "ID: APP-003 | Applicant: IDEAL-001 | Score: 110.00" in report
        assert report.find("APP-001") < report.find("APP-003")

        # Check for pending application details
        assert "ID: APP-002 | Applicant: POOR-001" in report

        # Check that denied application is not in the report
        assert "APP-004" not in report

    def test_generate_daily_report_no_applications(self, report_generator: ReportGenerator):
        """Tests report generation when there are no applications."""
        report = report_generator.generate_daily_report([])
        assert "No approved applications." in report
        assert "No pending applications." in report

    def test_generate_daily_report_only_pending(
        self, report_generator: ReportGenerator, sample_applicant_ideal
    ):
        """Tests report generation with only pending applications."""
        app = Application("APP-001", sample_applicant_ideal, datetime.date.today())
        app.status = ApplicationStatus.PENDING
        report = report_generator.generate_daily_report([app])
        assert "No approved applications." in report
        assert "--- PENDING APPLICATIONS ---" in report
        assert "ID: APP-001" in report

    def test_generate_daily_report_only_approved(
        self, report_generator: ReportGenerator, sample_applicant_ideal
    ):
        """Tests report generation with only approved applications."""
        app = Application("APP-001", sample_applicant_ideal, datetime.date.today())
        app.status = ApplicationStatus.APPROVED
        app.scores = {"allocation_score": 100.0}
        report = report_generator.generate_daily_report([app])
        assert "No pending applications." in report
        assert "--- APPROVED APPLICATIONS ---" in report
        assert "ID: APP-001" in report


# =============================================================================
# --- 5. HousingAllocationSystem Tests
# =============================================================================


class TestHousingAllocationSystem:
    """Tests the main system orchestrator class."""

    def test_register_applicant_success(
        self, system: HousingAllocationSystem, sample_applicant_ideal: Applicant
    ):
        """Tests successful registration of a new applicant."""
        system.register_applicant(sample_applicant_ideal)
        assert sample_applicant_ideal.applicant_id in system._applicants
        assert (
            system._applicants[sample_applicant_ideal.applicant_id]
            is sample_applicant_ideal
        )

    def test_register_applicant_duplicate_id_raises_error(
        self, system: HousingAllocationSystem, sample_applicant_ideal: Applicant
    ):
        """Tests that registering a duplicate applicant ID raises a ValueError."""
        system.register_applicant(sample_applicant_ideal)
        with pytest.raises(
            ValueError, match=f"Applicant ID {sample_applicant_ideal.applicant_id} already exists."
        ):
            system.register_applicant(sample_applicant_ideal)

    def test_submit_application_success(
        self, system: HousingAllocationSystem, sample_applicant_ideal: Applicant
    ):
        """Tests successful submission of an application for a registered applicant."""
        system.register_applicant(sample_applicant_ideal)

        with patch("datetime.date") as mock_date:
            today = datetime.date(2023, 10, 27)
            mock_date.today.return_value = today

            application = system.submit_application(sample_applicant_ideal.applicant_id)

            assert application is not None
            assert application.application_id == "APP-0001"
            assert application.applicant is sample_applicant_ideal
            assert application.status == ApplicationStatus.PENDING
            assert application.submission_date == today
            assert "APP-0001" in system._applications
            assert system._next_app_id_counter == 2

    def test_submit_application_nonexistent_applicant(self, system: HousingAllocationSystem):
        """Tests that submitting an application for an unregistered applicant fails."""
        application = system.submit_application("NONEXISTENT-ID")
        assert application is None
        assert not system._applications
        assert system._next_app_id_counter == 1

    @pytest.mark.parametrize(
        "score, expected_status",
        [
            (100.0, ApplicationStatus.APPROVED),
            (95.0, ApplicationStatus.APPROVED),  # Approve threshold boundary
            (94.99, ApplicationStatus.WAITLISTED),
            (75.0, ApplicationStatus.WAITLISTED),
            (60.0, ApplicationStatus.WAITLISTED),  # Deny threshold boundary
            (59.99, ApplicationStatus.DENIED),
            (0.0, ApplicationStatus.DENIED),
        ],
    )
    def test_determine_status_from_score(
        self, system: HousingAllocationSystem, score, expected_status
    ):
        """Tests the logic for assigning status based on score thresholds."""
        assert system._determine_status_from_score(score) == expected_status

    def test_process_applications(
        self,
        system: HousingAllocationSystem,
        sample_applicant_ideal: Applicant,
        sample_applicant_poor: Applicant,
    ):
        """End-to-end test of processing pending applications."""
        # Register applicants and submit applications
        system.register_applicant(sample_applicant_ideal)
        system.register_applicant(sample_applicant_poor)
        app_ideal = system.submit_application(sample_applicant_ideal.applicant_id)
        app_poor = system.submit_application(sample_applicant_poor.applicant_id)

        # Add an already-processed application to ensure it's ignored
        processed_app = Application(
            "APP-PROCESSED", sample_applicant_ideal, datetime.date.today()
        )
        processed_app.status = ApplicationStatus.APPROVED
        system._applications[processed_app.application_id] = processed_app

        assert app_ideal.status == ApplicationStatus.PENDING
        assert app_poor.status == ApplicationStatus.PENDING

        system.process_applications()

        # Ideal applicant should be approved
        assert (
            system._applications[app_ideal.application_id].status
            == ApplicationStatus.APPROVED
        )
        assert (
            system._applications[app_ideal.application_id].scores["allocation_score"]
            >= system._config.APPROVE_THRESHOLD
        )

        # Poor applicant should be denied
        assert (
            system._applications[app_poor.application_id].status
            == ApplicationStatus.DENIED
        )
        assert (
            system._applications[app_poor.application_id].scores["allocation_score"]
            < system._config.DENY_THRESHOLD
        )

        # Previously processed application should remain untouched
        assert (
            system._applications[processed_app.application_id].status
            == ApplicationStatus.APPROVED
        )

    def test_process_applications_no_pending(self, system: HousingAllocationSystem, capsys):
        """Tests that processing runs cleanly when no applications are pending."""
        system.process_applications()
        captured = capsys.readouterr()
        assert "No pending applications to process." in captured.out

    def test_get_daily_report_delegation(
        self, system: HousingAllocationSystem, sample_applicant_ideal: Applicant
    ):
        """Tests that the system correctly delegates report generation."""
        system.register_applicant(sample_applicant_ideal)
        system.submit_application(sample_applicant_ideal.applicant_id)
        report = system.get_daily_report()

        assert "HOUSING ALLOCATION DAILY REPORT" in report
        assert "--- PENDING APPLICATIONS ---" in report
        assert "ID: APP-0001" in report