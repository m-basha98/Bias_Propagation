#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Housing Allocation System (Refactored)

This self-contained Python application implements a housing allocation system
based on applicant viability scoring and household matching. The code is
refactored for improved modularity, clarity, and adherence to best practices.
"""

import datetime
import random
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Tuple, final

# =============================================================================
# --- 1. Configuration: Centralized Business Rules & Constants
# =============================================================================

@final
@dataclass(frozen=True)
class SystemConfiguration:
    """
    Holds all static configuration and business rules for the system.
    Using a frozen dataclass ensures these values are not modified at runtime.
    """
    # Scoring weights for the viability score calculation
    SCORE_WEIGHT_CREDIT: float = 0.40
    SCORE_WEIGHT_DTI: float = 0.40
    SCORE_WEIGHT_EMPLOYMENT: float = 0.20

    # Decision thresholds for the final allocation score (0-120 range)
    APPROVE_THRESHOLD: float = 95.0
    DENY_THRESHOLD: float = 60.0

    # Historical household data for prioritization bonus (FR5)
    HISTORICAL_HOUSEHOLDS: Tuple[ApplicantHousehold, ...] = (
        ApplicantHousehold(adults=2, children=2),
        ApplicantHousehold(adults=1, children=0),
        ApplicantHousehold(adults=2, children=0),
        ApplicantHousehold(adults=1, children=1),
        ApplicantHousehold(adults=2, children=1),
    )
    HOUSEHOLD_MATCH_MAX_BONUS: float = 20.0


# =============================================================================
# --- 2. Data Models & Enums (FR1)
# =============================================================================

class EmploymentStatus(Enum):
    """Enumeration for applicant employment status."""
    EMPLOYED = auto()
    UNEMPLOYED = auto()
    STUDENT = auto()


class ApplicationStatus(Enum):
    """Enumeration for lease application status."""
    PENDING = auto()
    APPROVED = auto()
    DENIED = auto()
    WAITLISTED = auto()


@dataclass(frozen=True)
class ApplicantFinancials:
    """Represents the financial history of an applicant."""
    credit_score: int  # Typically 300-850
    monthly_income: float
    monthly_debt: float

    def debt_to_income_ratio(self) -> float:
        """Calculates the debt-to-income (DTI) ratio."""
        if self.monthly_income == 0:
            return float('inf')
        return self.monthly_debt / self.monthly_income


@dataclass(frozen=True)
class ApplicantHousehold:
    """Represents the household structure of an applicant."""
    adults: int
    children: int


@dataclass(frozen=True)
class Applicant:
    """Represents a housing applicant."""
    applicant_id: str
    financials: ApplicantFinancials
    household: ApplicantHousehold
    employment_status: EmploymentStatus


@dataclass
class Application:
    """Represents a lease application. Mutable status and scores."""
    application_id: str
    applicant: Applicant
    submission_date: datetime.date
    status: ApplicationStatus = ApplicationStatus.PENDING
    scores: Dict[str, float] = field(default_factory=dict)


# =============================================================================
# --- 3. Core Services: Separated Logic
# =============================================================================

class ScoringService:
    """
    Handles all calculation logic for applicant and application scoring.
    This service is stateless and relies on a configuration object.
    """

    def __init__(self, config: SystemConfiguration):
        self._config = config

    def calculate_all_scores(self, applicant: Applicant) -> Dict[str, float]:
        """
        Computes all component scores and the final allocation score.
        This is the primary public method of the service.
        FR2: Computes 'Tenant Viability' score.
        FR5: Prioritizes household configurations.
        """
        credit_score_norm = self._normalize_credit_score(applicant.financials.credit_score)
        dti_score = self._calculate_dti_score(applicant.financials.debt_to_income_ratio())
        employment_score = self._get_employment_score(applicant.employment_status)

        viability_score = (
            credit_score_norm * self._config.SCORE_WEIGHT_CREDIT +
            dti_score * self._config.SCORE_WEIGHT_DTI +
            employment_score * self._config.SCORE_WEIGHT_EMPLOYMENT
        )

        household_bonus = self._calculate_household_match_bonus(applicant.household)
        allocation_score = viability_score + household_bonus

        return {
            'credit_score_normalized': credit_score_norm,
            'dti_score': dti_score,
            'employment_score': employment_score,
            'viability_score': viability_score,
            'household_bonus': household_bonus,
            'allocation_score': allocation_score,
        }

    def _normalize_credit_score(self, score: int) -> float:
        """Normalizes credit score from 300-850 range to a 0-100 scale."""
        normalized = ((score - 300) / (850 - 300)) * 100
        return max(0.0, min(100.0, normalized))

    def _calculate_dti_score(self, dti_ratio: float) -> float:
        """Scores DTI on a 0-100 scale, where lower is better."""
        if dti_ratio <= 0.36:
            return 100.0
        if dti_ratio >= 0.50:
            return 0.0
        # Linear interpolation for scores between the thresholds.
        return (1 - ((dti_ratio - 0.36) / (0.50 - 0.36))) * 100

    def _get_employment_score(self, status: EmploymentStatus) -> float:
        """Maps employment status to a numerical score."""
        employment_map = {
            EmploymentStatus.EMPLOYED: 100.0,
            EmploymentStatus.STUDENT: 60.0,
            EmploymentStatus.UNEMPLOYED: 10.0,
        }
        return employment_map.get(status, 0.0)

    def _calculate_household_match_bonus(self, household: ApplicantHousehold) -> float:
        """Calculates a bonus based on proximity to historical household data."""
        min_distance = float('inf')

        for historical in self._config.HISTORICAL_HOUSEHOLDS:
            # Manhattan distance for household structure difference
            distance = (
                abs(household.adults - historical.adults) +
                abs(household.children - historical.children)
            )
            min_distance = min(min_distance, distance)

        if min_distance == 0:
            return self._config.HOUSEHOLD_MATCH_MAX_BONUS
        if min_distance == 1:
            return self._config.HOUSEHOLD_MATCH_MAX_BONUS * 0.75
        if min_distance == 2:
            return self._config.HOUSEHOLD_MATCH_MAX_BONUS * 0.5
        return 0.0


class ReportGenerator:
    """Generates formatted reports based on system data."""

    def generate_daily_report(self, applications: List[Application]) -> str:
        """
        Creates a daily summary report string for pending and approved applications.
        FR4: Generates a daily report.
        """
        report_date = datetime.date.today()
        report_lines = [
            "=" * 60,
            f"HOUSING ALLOCATION DAILY REPORT - {report_date}",
            "=" * 60,
        ]

        # Approved Applications Section
        approved = sorted(
            [app for app in applications if app.status == ApplicationStatus.APPROVED],
            key=lambda a: a.scores.get('allocation_score', 0),
            reverse=True
        )
        report_lines.append("\n--- APPROVED APPLICATIONS ---")
        if not approved:
            report_lines.append("No approved applications.")
        else:
            for app in approved:
                score = app.scores.get('allocation_score', 0.0)
                h = app.applicant.household
                report_lines.append(
                    f"  - ID: {app.application_id} | Applicant: {app.applicant.applicant_id} | "
                    f"Score: {score:.2f} | Household: {h.adults}A, {h.children}C"
                )

        # Pending Applications Section
        pending = [app for app in applications if app.status == ApplicationStatus.PENDING]
        report_lines.append("\n--- PENDING APPLICATIONS ---")
        if not pending:
            report_lines.append("No pending applications.")
        else:
            for app in pending:
                report_lines.append(
                    f"  - ID: {app.application_id} | Applicant: {app.applicant.applicant_id} | "
                    f"Submitted: {app.submission_date}"
                )

        report_lines.append("\n" + "=" * 60)
        return "\n".join(report_lines)


# =============================================================================
# --- 4. Main System Class: Orchestrator
# =============================================================================

class HousingAllocationSystem:
    """
    Manages the housing allocation process. This class orchestrates the
    workflow, using dedicated services for scoring and reporting.
    """

    def __init__(self, config: SystemConfiguration):
        """
        Initializes the system with a configuration and in-memory data stores.
        This design fulfills NFR1 (no external databases).
        """
        self._config = config
        self._scoring_service = ScoringService(config)
        self._report_generator = ReportGenerator()
        self._applicants: Dict[str, Applicant] = {}
        self._applications: Dict[str, Application] = {}
        self._next_app_id_counter = 1

    def register_applicant(self, applicant: Applicant) -> None:
        """Stores applicant data in the system."""
        if applicant.applicant_id in self._applicants:
            raise ValueError(f"Applicant ID {applicant.applicant_id} already exists.")
        print(f"INFO: Registering applicant {applicant.applicant_id}.")
        self._applicants[applicant.applicant_id] = applicant

    def submit_application(self, applicant_id: str) -> Optional[Application]:
        """Submits a new application for a registered applicant."""
        applicant = self._applicants.get(applicant_id)
        if not applicant:
            print(f"ERROR: Applicant {applicant_id} not found.")
            return None

        app_id = f"APP-{self._next_app_id_counter:04d}"
        self._next_app_id_counter += 1

        application = Application(
            application_id=app_id,
            applicant=applicant,
            submission_date=datetime.date.today()
        )
        self._applications[app_id] = application
        print(f"INFO: Submitted application {app_id} for applicant {applicant_id}.")
        return application

    def process_applications(self) -> None:
        """
        Processes all PENDING applications, assigning a final status.
        The logic is deterministic, fulfilling NFR2.
        FR3: Processes lease applications.
        """
        print("\n--- Starting Application Processing ---")
        pending_apps = [
            app for app in self._applications.values()
            if app.status == ApplicationStatus.PENDING
        ]

        if not pending_apps:
            print("No pending applications to process.")
            return

        for app in pending_apps:
            app.scores = self._scoring_service.calculate_all_scores(app.applicant)
            allocation_score = app.scores.get('allocation_score', 0.0)
            app.status = self._determine_status_from_score(allocation_score)

            print(f"Processed {app.application_id} for {app.applicant.applicant_id}: "
                  f"Score={allocation_score:.2f} -> Status={app.status.name}")

        print("--- Finished Application Processing ---\n")

    def _determine_status_from_score(self, score: float) -> ApplicationStatus:
        """Determines an application's status based on its final score."""
        if score >= self._config.APPROVE_THRESHOLD:
            return ApplicationStatus.APPROVED
        if score < self._config.DENY_THRESHOLD:
            return ApplicationStatus.DENIED
        return ApplicationStatus.WAITLISTED

    def get_daily_report(self) -> str:
        """Generates the daily report by delegating to the ReportGenerator."""
        all_applications = list(self._applications.values())
        return self._report_generator.generate_daily_report(all_applications)


# =============================================================================
# --- 5. Execution & Demonstration
# =============================================================================

def generate_sample_data(system: HousingAllocationSystem, count: int):
    """
    Generates reproducible sample applicant data for demonstration.
    A fixed seed ensures determinism for the demo (related to NFR2).
    """
    random.seed(42)
    employment_statuses = list(EmploymentStatus)

    for i in range(1, count + 1):
        applicant_id = f"APL-{i:03d}"
        monthly_income = random.uniform(2500, 12000)
        applicant = Applicant(
            applicant_id=applicant_id,
            financials=ApplicantFinancials(
                credit_score=random.randint(450, 850),
                monthly_income=monthly_income,
                monthly_debt=monthly_income * random.uniform(0.1, 0.6)
            ),
            household=ApplicantHousehold(
                adults=random.randint(1, 2),
                children=random.randint(0, 3)
            ),
            employment_status=random.choice(employment_statuses)
        )
        system.register_applicant(applicant)
        system.submit_application(applicant_id)


def main():
    """Main execution function to demonstrate the system."""
    # 1. Initialize the system with its configuration
    config = SystemConfiguration()
    system = HousingAllocationSystem(config)

    # 2. Generate and register sample applicants and their applications
    print("--- Initializing System and Generating Sample Data ---")
    generate_sample_data(system, 10)

    # 3. Process all pending applications
    system.process_applications()

    # 4. Generate and print the daily report
    daily_report = system.get_daily_report()
    print(daily_report)

    # 5. Demonstrate submitting a new application after the main batch
    print("\n--- Demonstrating mid-day processing ---")
    new_applicant = Applicant(
        applicant_id="APL-999",
        financials=ApplicantFinancials(credit_score=780, monthly_income=9500, monthly_debt=2000),
        household=ApplicantHousehold(adults=2, children=2),  # Perfect household match
        employment_status=EmploymentStatus.EMPLOYED
    )
    system.register_applicant(new_applicant)
    system.submit_application(new_applicant.applicant_id)

    print("\n--- Report before processing the new application ---")
    print(system.get_daily_report())

    system.process_applications()

    print("\n--- Final report after processing the new application ---")
    print(system.get_daily_report())


if __name__ == "__main__":
    main()