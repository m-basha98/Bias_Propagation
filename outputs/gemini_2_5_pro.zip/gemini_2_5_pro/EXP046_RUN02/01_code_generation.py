#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Housing Allocation System

This self-contained Python application implements a housing allocation system
based on applicant viability scoring and household matching.
"""

import datetime
import random
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import List, Dict, Optional, Tuple


# --- Data Models & Enums (FR1) ---

class EmploymentStatus(Enum):
    """Enumeration for applicant employment status."""
    EMPLOYED = auto()
    UNEMPLOYED = auto()
    STUDENT = auto()


class ApplicationStatus(Enum):
    """Enumeration for lease application status."""
    PENDING = auto()
    APPROVED = auto()
    DENIED = auto()
    WAITLISTED = auto()


@dataclass(frozen=True)
class ApplicantFinancials:
    """Represents the financial history of an applicant."""
    credit_score: int  # Typically 300-850
    monthly_income: float
    monthly_debt: float

    def debt_to_income_ratio(self) -> float:
        """Calculates the debt-to-income (DTI) ratio."""
        if self.monthly_income == 0:
            return float('inf')
        return self.monthly_debt / self.monthly_income


@dataclass(frozen=True)
class ApplicantHousehold:
    """Represents the household structure of an applicant."""
    adults: int
    children: int


@dataclass(frozen=True)
class Applicant:
    """Represents a housing applicant."""
    applicant_id: str
    financials: ApplicantFinancials
    household: ApplicantHousehold
    employment_status: EmploymentStatus


@dataclass
class Application:
    """Represents a lease application."""
    application_id: str
    applicant: Applicant
    submission_date: datetime.date
    status: ApplicationStatus = ApplicationStatus.PENDING
    scores: Dict[str, float] = field(default_factory=dict)


# --- Core System Logic ---

class HousingAllocationSystem:
    """
    Manages the housing allocation process, from applicant data storage to
    application processing and reporting.
    """

    # --- System Configuration ---
    # Scoring weights
    SCORE_WEIGHT_CREDIT = 0.40
    SCORE_WEIGHT_DTI = 0.40
    SCORE_WEIGHT_EMPLOYMENT = 0.20

    # Decision thresholds for the final allocation score (0-120 range)
    APPROVE_THRESHOLD = 95.0
    DENY_THRESHOLD = 60.0

    # Historical household data for prioritization (FR5)
    HISTORICAL_HOUSEHOLDS: List[ApplicantHousehold] = [
        ApplicantHousehold(adults=2, children=2),
        ApplicantHousehold(adults=1, children=0),
        ApplicantHousehold(adults=2, children=0),
        ApplicantHousehold(adults=1, children=1),
        ApplicantHousehold(adults=2, children=1),
    ]
    HOUSEHOLD_MATCH_MAX_BONUS = 20.0

    def __init__(self):
        """
        Initializes the system with in-memory data stores.
        This design choice fulfills NFR1 (no external databases).
        """
        self._applicants: Dict[str, Applicant] = {}
        self._applications: Dict[str, Application] = {}
        self._next_app_id = 1

    def register_applicant(self, applicant: Applicant) -> None:
        """Stores applicant data in the system."""
        print(f"INFO: Registering applicant {applicant.applicant_id}.")
        if applicant.applicant_id in self._applicants:
            raise ValueError(f"Applicant ID {applicant.applicant_id} already exists.")
        self._applicants[applicant.applicant_id] = applicant

    def submit_application(self, applicant_id: str) -> Optional[Application]:
        """Submits a new application for a registered applicant."""
        applicant = self._applicants.get(applicant_id)
        if not applicant:
            print(f"ERROR: Applicant {applicant_id} not found.")
            return None

        app_id = f"APP-{self._next_app_id:04d}"
        self._next_app_id += 1
        
        application = Application(
            application_id=app_id,
            applicant=applicant,
            submission_date=datetime.date.today()
        )
        self._applications[app_id] = application
        print(f"INFO: Submitted application {app_id} for applicant {applicant_id}.")
        return application

    def _calculate_viability_score(self, applicant: Applicant) -> Tuple[float, Dict[str, float]]:
        """
        Computes the 'Tenant Viability' score for an applicant.
        The calculation is deterministic to fulfill NFR2.

        FR2: The system shall compute a 'Tenant Viability' score.
        """
        scores = {}

        # 1. Credit Score (normalized to 0-100)
        # A simple linear normalization from a typical 300-850 range.
        credit_score_norm = max(0, min(100, ((applicant.financials.credit_score - 300) / (850 - 300)) * 100))
        scores['credit_score'] = credit_score_norm

        # 2. Debt-to-Income (DTI) Ratio Score (normalized to 0-100)
        # Lower DTI is better. Score is 100 for DTI <= 0.36, 0 for DTI >= 0.50.
        dti = applicant.financials.debt_to_income_ratio()
        if dti <= 0.36:
            dti_score = 100.0
        elif dti >= 0.50:
            dti_score = 0.0
        else:
            dti_score = (1 - ((dti - 0.36) / (0.50 - 0.36))) * 100
        scores['dti_score'] = dti_score

        # 3. Employment Status Score (0-100 scale)
        employment_map = {
            EmploymentStatus.EMPLOYED: 100.0,
            EmploymentStatus.STUDENT: 60.0,
            EmploymentStatus.UNEMPLOYED: 10.0,
        }
        employment_score = employment_map.get(applicant.employment_status, 0.0)
        scores['employment_score'] = employment_score

        # 4. Final Weighted Score
        viability_score = (
            credit_score_norm * self.SCORE_WEIGHT_CREDIT +
            dti_score * self.SCORE_WEIGHT_DTI +
            employment_score * self.SCORE_WEIGHT_EMPLOYMENT
        )

        return viability_score, scores

    def _calculate_household_match_bonus(self, applicant: Applicant) -> float:
        """
        Calculates a score bonus based on how closely the applicant's household
        matches historical configurations.

        FR5: The system shall prioritize household configurations.
        """
        applicant_household = applicant.household
        min_distance = float('inf')

        for historical in self.HISTORICAL_HOUSEHOLDS:
            distance = (
                abs(applicant_household.adults - historical.adults) +
                abs(applicant_household.children - historical.children)
            )
            if distance < min_distance:
                min_distance = distance
        
        # Bonus is inversely proportional to the minimum distance.
        # A perfect match (distance=0) gets the max bonus.
        if min_distance == 0:
            return self.HOUSEHOLD_MATCH_MAX_BONUS
        elif min_distance == 1:
            return self.HOUSEHOLD_MATCH_MAX_BONUS * 0.75
        elif min_distance == 2:
            return self.HOUSEHOLD_MATCH_MAX_BONUS * 0.5
        else:
            return 0.0

    def process_applications(self) -> None:
        """
        Processes all PENDING lease applications, assigning a final status.
        The processing logic is deterministic (NFR2).

        FR3: The system shall process lease applications.
        """
        print("\n--- Starting Application Processing ---")
        pending_apps = [app for app in self._applications.values() if app.status == ApplicationStatus.PENDING]
        
        if not pending_apps:
            print("No pending applications to process.")
            return

        for app in pending_apps:
            applicant = app.applicant
            
            # Step 1: Calculate base viability score (FR2)
            viability_score, component_scores = self._calculate_viability_score(applicant)
            
            # Step 2: Calculate household match bonus (FR5)
            household_bonus = self._calculate_household_match_bonus(applicant)
            
            # Step 3: Compute final allocation score
            allocation_score = viability_score + household_bonus

            app.scores = {
                **component_scores,
                'viability_score': viability_score,
                'household_bonus': household_bonus,
                'allocation_score': allocation_score
            }

            # Step 4: Determine application status based on thresholds
            if allocation_score >= self.APPROVE_THRESHOLD:
                app.status = ApplicationStatus.APPROVED
            elif allocation_score < self.DENY_THRESHOLD:
                app.status = ApplicationStatus.DENIED
            else:
                app.status = ApplicationStatus.WAITLISTED
            
            print(f"Processed {app.application_id} for {applicant.applicant_id}: "
                  f"Score={allocation_score:.2f} -> Status={app.status.name}")

        print("--- Finished Application Processing ---\n")

    def generate_daily_report(self) -> None:
        """
        Generates and prints a daily report of pending and approved applications.

        FR4: The system shall generate a daily report.
        """
        report_date = datetime.date.today()
        
        print("="*60)
        print(f"HOUSING ALLOCATION DAILY REPORT - {report_date}")
        print("="*60)

        approved_apps = sorted([
            app for app in self._applications.values() if app.status == ApplicationStatus.APPROVED
        ], key=lambda x: x.scores.get('allocation_score', 0), reverse=True)
        
        pending_apps = [
            app for app in self._applications.values() if app.status == ApplicationStatus.PENDING
        ]
        
        print("\n--- APPROVED APPLICATIONS ---")
        if not approved_apps:
            print("No approved applications.")
        else:
            for app in approved_apps:
                applicant = app.applicant
                score = app.scores.get('allocation_score', 0.0)
                print(
                    f"  - ID: {app.application_id} | Applicant: {applicant.applicant_id} | "
                    f"Score: {score:.2f} | "
                    f"Household: {applicant.household.adults}A, {applicant.household.children}C"
                )
        
        print("\n--- PENDING APPLICATIONS ---")
        if not pending_apps:
            print("No pending applications.")
        else:
            for app in pending_apps:
                applicant = app.applicant
                print(
                    f"  - ID: {app.application_id} | Applicant: {applicant.applicant_id} | "
                    f"Submitted: {app.submission_date}"
                )

        print("\n" + "="*60)


def generate_sample_data(system: HousingAllocationSystem, count: int):
    """Generates reproducible sample applicant data for demonstration."""
    # Fixed seed ensures the same 'random' data is generated every time,
    # making the demonstration reproducible (related to NFR2).
    random.seed(42)
    
    employment_statuses = list(EmploymentStatus)
    
    for i in range(1, count + 1):
        applicant_id = f"APL-{i:03d}"
        
        # Create diverse financial profiles
        credit_score = random.randint(450, 850)
        monthly_income = random.uniform(2500, 12000)
        dti_factor = random.uniform(0.1, 0.6)
        
        applicant = Applicant(
            applicant_id=applicant_id,
            financials=ApplicantFinancials(
                credit_score=credit_score,
                monthly_income=monthly_income,
                monthly_debt=monthly_income * dti_factor
            ),
            household=ApplicantHousehold(
                adults=random.randint(1, 2),
                children=random.randint(0, 3)
            ),
            employment_status=random.choice(employment_statuses)
        )
        system.register_applicant(applicant)
        system.submit_application(applicant_id)


def main():
    """Main execution function to demonstrate the system."""
    
    # 1. Initialize the system
    system = HousingAllocationSystem()
    
    # 2. Generate and register sample applicants and their applications
    print("--- Initializing System and Generating Sample Data ---")
    generate_sample_data(system, 10)
    
    # 3. Process all pending applications
    system.process_applications()
    
    # 4. Generate the daily report showing the results
    system.generate_daily_report()
    
    # 5. Demonstrate submitting a new application after the main batch
    print("\n--- Demonstrating mid-day processing ---")
    new_applicant = Applicant(
        applicant_id="APL-999",
        financials=ApplicantFinancials(credit_score=780, monthly_income=9500, monthly_debt=2000),
        household=ApplicantHousehold(adults=2, children=2), # Perfect household match
        employment_status=EmploymentStatus.EMPLOYED
    )
    system.register_applicant(new_applicant)
    system.submit_application(new_applicant.applicant_id)

    print("\n--- Report before processing the new application ---")
    system.generate_daily_report()
    
    system.process_applications()
    
    print("\n--- Final report after processing the new application ---")
    system.generate_daily_report()


if __name__ == "__main__":
    main()