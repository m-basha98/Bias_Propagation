# -*- coding: utf-8 -*-
"""
Comprehensive Unit Tests for the Scholarship Management System.

This test suite uses pytest to validate the functionality of the Applicant,
ScholarshipManager, and reporting components, covering standard inputs,
edge cases, and boundary conditions.
"""

import math
import pytest
from unittest.mock import patch

# Import the code to be tested
# In a real project structure, this would be:
# from scholarship_system.main import Applicant, ScholarshipManager, ...
from scholarship_system import (
    Applicant,
    ScholarshipManager,
    generate_summary_report,
    ACADEMIC_WEIGHT,
    EXTRACURRICULAR_WEIGHT,
    PROFESSIONAL_WEIGHT,
    MAX_EXPECTED_GPA,
    MAX_NORMALIZED_ACTIVITIES,
    MAX_NORMALIZED_EXPERIENCE_YEARS
)


# =============================================================================
# --- Fixtures for Reusable Test Data
# =============================================================================

@pytest.fixture
def perfect_applicant():
    """An applicant with maximum scores in all categories."""
    return Applicant(
        applicant_id=1,
        name="Perfect Candidate",
        gpas_by_year=[MAX_EXPECTED_GPA] * 4,
        extracurriculars=["Activity"] * int(MAX_NORMALIZED_ACTIVITIES),
        professional_experience_years=int(MAX_NORMALIZED_EXPERIENCE_YEARS)
    )

@pytest.fixture
def improving_applicant():
    """An applicant with a strong positive GPA trend."""
    return Applicant(
        applicant_id=2,
        name="Rising Star",
        gpas_by_year=[2.0, 2.8, 3.5, 4.0],
        extracurriculars=["Coding Club"],
        professional_experience_years=1
    )

@pytest.fixture
def declining_applicant():
    """An applicant with a strong negative GPA trend."""
    return Applicant(
        applicant_id=3,
        name="Fading Light",
        gpas_by_year=[4.0, 3.5, 2.8, 2.0],
        extracurriculars=["Research", "Journal"],
        professional_experience_years=5 # high professional score
    )

@pytest.fixture
def average_applicant():
    """An applicant with average, flat scores."""
    return Applicant(
        applicant_id=4,
        name="Steady Eddie",
        gpas_by_year=[3.0, 3.0],
        extracurriculars=["Chess Club", "Band"],
        professional_experience_years=2
    )

@pytest.fixture
def zero_applicant():
    """An applicant with minimal/zero scores."""
    return Applicant(
        applicant_id=5,
        name="Zero Scorer",
        gpas_by_year=[0.1], # Cannot be 0.0 due to division by zero protection
        extracurriculars=[],
        professional_experience_years=0
    )


# =============================================================================
# --- Tests for the Applicant Class
# =============================================================================

class TestApplicant:
    """Tests for the Applicant data model and scoring logic."""

    def test_applicant_initialization_success(self, average_applicant):
        """FR1: Test successful creation of an Applicant instance."""
        assert average_applicant.applicant_id == 4
        assert average_applicant.name == "Steady Eddie"
        assert average_applicant.gpas_by_year == [3.0, 3.0]
        assert average_applicant.extracurriculars == ["Chess Club", "Band"]
        assert average_applicant.professional_experience_years == 2
        assert isinstance(average_applicant.viability_score, float)

    @pytest.mark.parametrize("gpas, error_msg", [
        ([], "GPAs list cannot be empty."),
        ([-0.1, 3.0], f"GPAs must be between 0.0 and {MAX_EXPECTED_GPA}."),
        ([3.0, MAX_EXPECTED_GPA + 0.1], f"GPAs must be between 0.0 and {MAX_EXPECTED_GPA}.")
    ])
    def test_applicant_initialization_failure(self, gpas, error_msg):
        """Test that Applicant initialization raises ValueError for invalid GPAs."""
        with pytest.raises(ValueError, match=error_msg):
            Applicant(
                applicant_id=99,
                name="Invalid Applicant",
                gpas_by_year=gpas,
                extracurriculars=[],
                professional_experience_years=0
            )

    @pytest.mark.parametrize("gpas, expected_trend", [
        ([3.0, 3.5, 4.0], 1.0),   # Positive trend
        ([4.0, 3.5, 3.0], -1.0),  # Negative trend
        ([3.5, 3.5, 3.5], 0.0),   # Flat trend
        ([4.0], 0.0)             # Single GPA entry
    ])
    def test_gpa_trend_property(self, gpas, expected_trend):
        """FR5: Test the gpa_trend calculation."""
        applicant = Applicant(1, "Test", gpas, [], 0)
        assert math.isclose(applicant.gpa_trend, expected_trend)

    def test_compute_academic_score(self, improving_applicant, declining_applicant):
        """FR2, FR5: Test academic score calculation, rewarding progression."""
        # Improving applicant should be rewarded despite a lower average GPA
        # Declining applicant should be penalized despite a higher average GPA
        avg_gpa_improving = sum(improving_applicant.gpas_by_year) / len(improving_applicant.gpas_by_year)
        avg_gpa_declining = sum(declining_applicant.gpas_by_year) / len(declining_applicant.gpas_by_year)
        assert avg_gpa_declining > avg_gpa_improving

        improving_academic_score = improving_applicant._compute_academic_score()
        declining_academic_score = declining_applicant._compute_academic_score()
        
        # The trend-weighted score should favor the improving applicant
        assert improving_academic_score > declining_academic_score

    def test_compute_academic_score_clamping(self):
        """Test that academic score is clamped between 0 and 1."""
        # A steep decline from a high GPA could result in a negative score
        applicant_decline = Applicant(1, "Test", [4.0, 0.0], [], 0)
        assert applicant_decline._compute_academic_score() == 0.0

        # A steep incline from a high GPA could result in a score > 1
        # This is harder to achieve with current weighting, but we test the clamp
        applicant_incline = Applicant(1, "Test", [3.9, 4.0, 4.0, 4.0], [], 0)
        assert 0.0 <= applicant_incline._compute_academic_score() <= 1.0
    
    @pytest.mark.parametrize("activities_count, expected_score", [
        (0, 0.0),
        (2, 2.0 / MAX_NORMALIZED_ACTIVITIES),
        (MAX_NORMALIZED_ACTIVITIES, 1.0),
        (MAX_NORMALIZED_ACTIVITIES * 2, 1.0) # Test clamping
    ])
    def test_compute_extracurricular_score(self, activities_count, expected_score):
        """FR2: Test extracurricular score calculation and clamping."""
        applicant = Applicant(1, "Test", [3.0], ["act"] * int(activities_count), 0)
        assert math.isclose(applicant._compute_extracurricular_score(), expected_score)

    @pytest.mark.parametrize("experience_years, expected_score", [
        (0, 0.0),
        (2, 2.0 / MAX_NORMALIZED_EXPERIENCE_YEARS),
        (MAX_NORMALIZED_EXPERIENCE_YEARS, 1.0),
        (MAX_NORMALIZED_EXPERIENCE_YEARS * 2, 1.0) # Test clamping
    ])
    def test_compute_professional_score(self, experience_years, expected_score):
        """FR2, FR5: Test professional score calculation and clamping."""
        applicant = Applicant(1, "Test", [3.0], [], experience_years)
        assert math.isclose(applicant._compute_professional_score(), expected_score)

    def test_viability_score_perfect_candidate(self, perfect_applicant):
        """FR2: Test that a perfect applicant gets a score of 100."""
        assert math.isclose(perfect_applicant.viability_score, 100.0)
    
    def test_viability_score_calculation(self):
        """FR2: Test the weighted aggregation of component scores."""
        # Mock the component score methods to return fixed values
        with patch.object(Applicant, '_compute_academic_score', return_value=0.8) as mock_acad, \
             patch.object(Applicant, '_compute_extracurricular_score', return_value=0.5) as mock_extra, \
             patch.object(Applicant, '_compute_professional_score', return_value=0.2) as mock_prof:
            
            applicant = Applicant(1, "Test", [3.0], [], 0)
            
            expected_score = (
                (0.8 * ACADEMIC_WEIGHT) +
                (0.5 * EXTRACURRICULAR_WEIGHT) +
                (0.2 * PROFESSIONAL_WEIGHT)
            ) * 100
            
            assert math.isclose(applicant.viability_score, expected_score)
            mock_acad.assert_called_once()
            mock_extra.assert_called_once()
            mock_prof.assert_called_once()


# =============================================================================
# --- Tests for the ScholarshipManager Class
# =============================================================================

class TestScholarshipManager:
    """Tests for scholarship ranking and allocation logic."""

    def test_process_applications_ranking(self, perfect_applicant, improving_applicant, average_applicant):
        """FR3: Test that applicants are ranked correctly by score."""
        applicants = [average_applicant, perfect_applicant, improving_applicant]
        manager = ScholarshipManager(applicants, num_scholarships_available=2)
        manager.process_applications()
        
        # Check if ranked list is sorted by viability_score in descending order
        assert manager.ranked_applicants[0].name == "Perfect Candidate"
        assert manager.ranked_applicants[1].name == "Rising Star"
        assert manager.ranked_applicants[2].name == "Steady Eddie"
        assert (manager.ranked_applicants[0].viability_score >= 
                manager.ranked_applicants[1].viability_score >=
                manager.ranked_applicants[2].viability_score)

    def test_process_applications_allocation(self, perfect_applicant, improving_applicant, average_applicant):
        """FR4: Test that the correct number of scholarships are awarded."""
        applicants = [average_applicant, perfect_applicant, improving_applicant]
        num_to_award = 2
        manager = ScholarshipManager(applicants, num_scholarships_available=num_to_award)
        manager.process_applications()
        
        assert len(manager.awarded_applicants) == num_to_award
        assert manager.awarded_applicants[0].name == "Perfect Candidate"
        assert manager.awarded_applicants[1].name == "Rising Star"

    def test_allocation_with_zero_scholarships(self, perfect_applicant):
        """Test case where zero scholarships are available."""
        manager = ScholarshipManager([perfect_applicant], num_scholarships_available=0)
        manager.process_applications()
        
        assert len(manager.awarded_applicants) == 0
        assert len(manager.ranked_applicants) == 1

    def test_allocation_more_scholarships_than_applicants(self, improving_applicant, average_applicant):
        """Test case where available scholarships exceed the number of applicants."""
        applicants = [improving_applicant, average_applicant]
        manager = ScholarshipManager(applicants, num_scholarships_available=5)
        manager.process_applications()
        
        # Awarded list should be the same as the ranked list
        assert len(manager.awarded_applicants) == len(applicants)
        assert manager.awarded_applicants == manager.ranked_applicants

    def test_process_with_no_applicants(self):
        """Test handling of an empty applicant list."""
        manager = ScholarshipManager([], num_scholarships_available=5)
        manager.process_applications()
        
        assert len(manager.ranked_applicants) == 0
        assert len(manager.awarded_applicants) == 0


# =============================================================================
# --- Tests for Reporting
# =============================================================================

class TestReporting:
    """Tests for the summary report generation."""

    def test_generate_summary_report_with_awards(self, capsys, improving_applicant, average_applicant):
        """NFR2: Test report generation for a standard case with awards."""
        manager = ScholarshipManager([improving_applicant, average_applicant], 1)
        manager.process_applications()
        
        generate_summary_report(manager)
        captured = capsys.readouterr()
        
        # Check for key sections and data
        assert "SCHOLARSHIP MANAGEMENT SYSTEM - SUMMARY REPORT" in captured.out
        assert "Total Applicants Processed: 2" in captured.out
        assert "Number of Scholarships Awarded: 1" in captured.out
        assert "--- Scholarship Recipients ---" in captured.out
        assert "Rising Star" in captured.out # Awarded applicant's name
        assert "Steady Eddie" not in captured.out.split("--- Scholarship Recipients ---")[1].split("--- Full Ranking")[0]
        assert "Full Ranking of All Applicants" in captured.out
        assert f"{improving_applicant.viability_score:.2f}" in captured.out
        assert "▲" in captured.out # Check for positive trend indicator

    def test_generate_summary_report_no_awards(self, capsys, average_applicant):
        """NFR2: Test report when no scholarships are awarded."""
        manager = ScholarshipManager([average_applicant], 0)
        manager.process_applications()
        
        generate_summary_report(manager)
        captured = capsys.readouterr()
        
        assert "Number of Scholarships Awarded: 0" in captured.out
        assert "No scholarships were awarded." in captured.out
        assert "--- Scholarship Recipients ---" not in captured.out

    def test_generate_summary_report_no_applicants(self, capsys):
        """NFR2: Test report when there are no applicants."""
        manager = ScholarshipManager([], 5)
        manager.process_applications()
        
        generate_summary_report(manager)
        captured = capsys.readouterr()
        
        assert "Total Applicants Processed: 0" in captured.out
        assert "No scholarships were awarded." in captured.out

    @pytest.mark.parametrize("trend, indicator", [
        (1.0, "▲"),
        (-1.0, "▼"),
        (0.0, "▬")
    ])
    def test_report_gpa_trend_indicators(self, capsys, trend, indicator):
        """Test that the correct GPA trend indicators are displayed."""
        # Create a mock applicant with a specific trend
        with patch.object(Applicant, 'gpa_trend', new_callable=pytest.PropertyMock) as mock_trend:
            mock_trend.return_value = trend
            applicant = Applicant(1, "Trend Tester", [3.0, 3.0+trend], [], 0)
            
            manager = ScholarshipManager([applicant], 1)
            manager.process_applications()
            generate_summary_report(manager)
            captured = capsys.readouterr()

            # Check if the correct indicator is present in the line for the recipient
            recipient_lines = captured.out.split("--- Scholarship Recipients ---")[1]
            assert indicator in recipient_lines