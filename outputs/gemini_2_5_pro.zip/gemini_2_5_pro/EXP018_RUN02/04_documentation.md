# Technical Documentation: Scholarship Management System

## 1. Introduction

This document provides detailed technical documentation for the Scholarship Management System. The system is a self-contained Python application designed to evaluate, rank, and award scholarships to applicants based on a holistic viability score. It operates without external dependencies like databases, making it portable and easy to run.

The core logic revolves around three main components:
1.  **Data Model (`Applicant` class):** Represents an individual applicant and encapsulates the logic for calculating their viability score.
2.  **Core Logic (`ScholarshipManager` class):** Manages the collection of applicants, ranks them, and allocates the available scholarships.
3.  **Reporting (`generate_summary_report` function):** Generates a human-readable summary of the allocation results.

## 2. Module Overview

The script is organized into distinct sections for clarity and maintainability.

-   **Configuration:** Global constants that define scoring weights and normalization parameters. This allows for easy tuning of the scoring algorithm.
-   **Data Model / Domain Logic:** The `Applicant` class, which is the cornerstone of the system.
-   **Core Application Logic:** The `ScholarshipManager` class, which orchestrates the main workflow.
-   **Reporting:** A standalone function for generating the output report.
-   **Data and Execution:** Helper functions to provide sample data and the main execution block to run the application.

---

## 3. Configuration Variables

These global constants control the behavior of the scoring algorithm. Modifying them will change how applicants are evaluated.

### Scoring Weights

-   `ACADEMIC_WEIGHT` (float): The weight of the academic score in the final viability score. Default: `0.60`.
-   `EXTRACURRICULAR_WEIGHT` (float): The weight of the extracurricular score. Default: `0.15`.
-   `PROFESSIONAL_WEIGHT` (float): The weight of the professional experience score. Default: `0.25`.

### Normalization Parameters

These values are used to scale raw input data into a normalized score between 0.0 and 1.0. They represent the expected maximum for a strong candidate.

-   `MAX_EXPECTED_GPA` (float): The ceiling for GPA values, used for normalization. Default: `4.0`.
-   `MAX_NORMALIZED_ACTIVITIES` (float): The number of extracurricular activities that would result in a perfect score of 1.0. Default: `5.0`.
-   `MAX_NORMALIZED_EXPERIENCE_YEARS` (float): The number of years of professional experience that would result in a perfect score of 1.0. Default: `4.0`.

---

## 4. Class: `Applicant`

Represents a single scholarship applicant, holding their personal, academic, and professional information. It is responsible for calculating the applicant's final viability score based on this data.

### `__init__(self, applicant_id, name, gpas_by_year, extracurriculars, professional_experience_years)`

Initializes an `Applicant` instance. The final `viability_score` is computed and stored upon object creation.

-   **Parameters:**
    -   `applicant_id` (int): A unique identifier for the applicant.
    -   `name` (str): The full name of the applicant.
    -   `gpas_by_year` (List[float]): A list of GPAs for each academic year, provided in chronological order.
    -   `extracurriculars` (List[str]): A list of strings, where each string describes a significant extracurricular activity.
    -   `professional_experience_years` (int): The total number of years of relevant professional experience.
-   **Raises:**
    -   `ValueError`: If `gpas_by_year` is empty or if any GPA value is outside the valid range of `0.0` to `MAX_EXPECTED_GPA`.

### Property: `gpa_trend`

A read-only property that calculates the trend of academic performance.

-   **Returns:**
    -   (float): The difference between the last and first GPA in the `gpas_by_year` list. A positive value indicates improvement, negative indicates a decline, and `0.0` indicates a flat trend or a single data point.

### Private Methods

These methods compute the individual components of the final score. They are intended for internal use by the `_compute_viability_score` method.

#### `_compute_academic_score(self)`

Calculates a normalized academic score that rewards both high average performance and positive progression over time, fulfilling FR5. The score is a weighted combination of the normalized average GPA and the normalized GPA trend.

-   **Returns:**
    -   (float): A normalized score between 0.0 and 1.0.

#### `_compute_extracurricular_score(self)`

Calculates a normalized score based on the number of extracurricular activities. The score is capped at 1.0.

-   **Returns:**
    -   (float): A normalized score between 0.0 and 1.0.

#### `_compute_professional_score(self)`

Calculates a normalized score based on the years of professional experience. This directly rewards continuous professional progression as required by FR5.

-   **Returns:**
    -   (float): A normalized score between 0.0 and 1.0.

#### `_compute_viability_score(self)`

Aggregates the individual component scores (academic, extracurricular, professional) using the globally defined weights (`ACADEMIC_WEIGHT`, etc.). The final result is scaled to a 100-point system.

-   **Returns:**
    -   (float): The final viability score, typically ranging from 0 to 100.

### `__repr__(self)`

Provides a developer-friendly string representation of the `Applicant` object.

-   **Returns:**
    -   (str): A string showing the applicant's ID, name, and computed score. Example: `Applicant(ID=101, Name='Diana Prince', Score=95.50)`.

---

## 5. Class: `ScholarshipManager`

Orchestrates the scholarship allocation process. It takes a list of applicants, ranks them by score, and determines who receives an award.

### `__init__(self, applicants, num_scholarships_available)`

Initializes the `ScholarshipManager`.

-   **Parameters:**
    -   `applicants` (List[`Applicant`]): A list of `Applicant` objects to be processed.
    -   `num_scholarships_available` (int): The total number of scholarships to be awarded.

### `process_applications(self)`

Executes the core logic of the system. It first sorts all applicants in descending order based on their `viability_score` (FR3) and then selects the top applicants to receive scholarships (FR4). The results are stored in the instance attributes `ranked_applicants` and `awarded_applicants`.

-   **Returns:**
    -   `None`. This method modifies the state of the object.

---

## 6. Functions

### `generate_summary_report(manager)`

Prints a formatted summary report to the console, fulfilling NFR2. The report includes statistics, a list of scholarship recipients, and a full ranking of all applicants.

-   **Parameters:**
    -   `manager` (`ScholarshipManager`): A `ScholarshipManager` instance that has already run its `process_applications` method.
-   **Returns:**
    -   `None`. This function prints directly to standard output.

### `get_sample_data()`

Provides a static list of sample applicant data. This function ensures the application is self-contained and does not require external data files or databases to run (NFR1).

-   **Returns:**
    -   (List[Dict[str, Any]]): A list of dictionaries, where each dictionary contains the data for one applicant, matching the `Applicant` constructor signature.

### `main()`

The main entry point for the application. It controls the program flow:
1.  Sets application configuration (number of scholarships).
2.  Loads applicant data using `get_sample_data()`.
3.  Instantiates `Applicant` objects from the data.
4.  Initializes the `ScholarshipManager` with the applicants.
5.  Calls `manager.process_applications()` to perform ranking and allocation.
6.  Calls `generate_summary_report()` to display the results.

-   **Returns:**
    -   `None`.

---

## 7. Execution Flow

The script is executed via the `if __name__ == "__main__":` block, which calls the `main()` function.

1.  **Initialization:** The `main` function starts, printing status messages.
2.  **Data Loading:** `get_sample_data` provides raw data. This data is used to create a list of `Applicant` objects. During the creation of each `Applicant`, its `viability_score` is automatically calculated and stored.
3.  **Processing:** A `ScholarshipManager` instance is created with the list of applicants. Its `process_applications` method is called, which sorts the applicants by score and populates the `awarded_applicants` list.
4.  **Reporting:** The `generate_summary_report` function is called with the processed manager instance, printing the final results to the console.