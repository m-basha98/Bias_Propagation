# -*- coding: utf-8 -*-
"""
Scholarship Management System

This self-contained Python application manages the process of awarding scholarships
to applicants based on a holistic viability score.
"""

import math
from typing import List, Dict, Any

# --- Configuration for Scoring Weights ---
# These constants define the importance of each category in the final score.
# They must sum to 1.0.
ACADEMIC_WEIGHT = 0.60
EXTRACURRICULAR_WEIGHT = 0.15
PROFESSIONAL_WEIGHT = 0.25

# --- Configuration for Normalization ---
# These values help scale raw numbers into a normalized 0-1 score.
MAX_EXPECTED_GPA = 4.0
MAX_NORMALIZED_ACTIVITIES = 5.0
MAX_NORMALIZED_EXPERIENCE_YEARS = 4.0


class Applicant:
    """
    Represents a single scholarship applicant and their associated data.

    This class stores all information required by FR1 and contains the logic
    for computing the viability score as required by FR2 and FR5.
    """
    def __init__(self, applicant_id: int, name: str, gpas_by_year: List[float],
                 extracurriculars: List[str], professional_experience_years: int):
        """
        Initializes an Applicant object.

        Args:
            applicant_id (int): A unique identifier for the applicant.
            name (str): The full name of the applicant.
            gpas_by_year (List[float]): A list of GPAs for each academic year,
                                        in chronological order.
            extracurriculars (List[str]): A list of significant extracurricular activities.
            professional_experience_years (int): Total years of relevant professional experience.
        """
        if not gpas_by_year:
            raise ValueError("GPAs list cannot be empty.")
        if not all(0.0 <= gpa <= MAX_EXPECTED_GPA for gpa in gpas_by_year):
            raise ValueError(f"GPAs must be between 0.0 and {MAX_EXPECTED_GPA}.")

        self.applicant_id = applicant_id
        self.name = name
        self.gpas_by_year = gpas_by_year
        self.extracurriculars = extracurriculars
        self.professional_experience_years = professional_experience_years

        self.viability_score = self._compute_viability_score()

    def _compute_academic_score(self) -> float:
        """
        Calculates a normalized academic score (0 to 1).

        This score heavily incorporates continuous progression (FR5) by
        weighting the trend of GPAs over time alongside the average GPA.
        An upward trend is rewarded significantly.
        """
        avg_gpa = sum(self.gpas_by_year) / len(self.gpas_by_year)
        normalized_avg_gpa = avg_gpa / MAX_EXPECTED_GPA

        # Calculate progression trend
        if len(self.gpas_by_year) > 1:
            trend = self.gpas_by_year[-1] - self.gpas_by_year[0]
        else:
            trend = 0.0  # No trend for a single data point

        # Normalize trend from a range of [-4.0, 4.0] to [-1.0, 1.0]
        normalized_trend = trend / MAX_EXPECTED_GPA

        # Combine average and trend, giving trend significant weight
        # 60% weight on average performance, 40% on progression
        academic_score = (normalized_avg_gpa * 0.6) + (normalized_trend * 0.4)

        return max(0, min(1, academic_score)) # Clamp score between 0 and 1

    def _compute_extracurricular_score(self) -> float:
        """Calculates a normalized extracurricular score (0 to 1)."""
        score = len(self.extracurriculars) / MAX_NORMALIZED_ACTIVITIES
        return max(0, min(1, score)) # Clamp score between 0 and 1

    def _compute_professional_score(self) -> float:
        """
        Calculates a normalized professional experience score (0 to 1).

        This inherently rewards professional progression (FR5) as more years
        of experience result in a higher score.
        """
        score = self.professional_experience_years / MAX_NORMALIZED_EXPERIENCE_YEARS
        return max(0, min(1, score)) # Clamp score between 0 and 1

    def _compute_viability_score(self) -> float:
        """
        Computes the final viability score based on weighted components.

        This function aggregates the scores from academics, extracurriculars,
        and professional experience using the globally defined weights.
        The final score is presented on a 100-point scale.
        """
        academic = self._compute_academic_score()
        extracurricular = self._compute_extracurricular_score()
        professional = self._compute_professional_score()

        total_score = (
            (academic * ACADEMIC_WEIGHT) +
            (extracurricular * EXTRACURRICULAR_WEIGHT) +
            (professional * PROFESSIONAL_WEIGHT)
        ) * 100

        return total_score

    def __repr__(self) -> str:
        return (f"Applicant(ID={self.applicant_id}, Name='{self.name}', "
                f"Score={self.viability_score:.2f})")


class ScholarshipManager:
    """
    Manages the scholarship allocation process from ranking to reporting.

    This class handles ranking applicants (FR3), allocating scholarships (FR4),
    and generating the final summary report (NFR2).
    """
    def __init__(self, applicants: List[Applicant], num_scholarships_available: int):
        """
        Initializes the ScholarshipManager.

        Args:
            applicants (List[Applicant]): A list of Applicant objects to be processed.
            num_scholarships_available (int): The number of scholarships to award.
        """
        self.applicants = applicants
        self.num_scholarships = num_scholarships_available
        self.ranked_applicants: List[Applicant] = []
        self.awarded_applicants: List[Applicant] = []

    def process_applications(self):
        """
        Ranks applicants by viability score and allocates scholarships.
        """
        # FR3: Rank applicants from highest to lowest score
        self.ranked_applicants = sorted(
            self.applicants,
            key=lambda app: app.viability_score,
            reverse=True
        )

        # FR4: Allocate scholarships based on applicant rankings
        self.awarded_applicants = self.ranked_applicants[:self.num_scholarships]

    def generate_summary_report(self):
        """
        Prints a formatted summary report of the scholarship allocation results.
        """
        print("=" * 60)
        print("      SCHOLARSHIP MANAGEMENT SYSTEM - SUMMARY REPORT")
        print("=" * 60)
        print(f"\nTotal Applicants Processed: {len(self.applicants)}")
        print(f"Number of Scholarships Awarded: {len(self.awarded_applicants)}\n")

        if not self.awarded_applicants:
            print("No scholarships were awarded.")
            print("-" * 60)
            return

        print("--- Recipients of the Scholarship ---")
        header = f"{'Rank':<5} {'ID':<5} {'Name':<20} {'Final Score':<15} {'GPA Trend'}"
        print(header)
        print("-" * len(header))

        for i, applicant in enumerate(self.awarded_applicants):
            rank = i + 1
            trend_char = "▲" if applicant.gpas_by_year[-1] > applicant.gpas_by_year[0] else \
                         "▼" if applicant.gpas_by_year[-1] < applicant.gpas_by_year[0] else "▬"
            gpa_trend_str = f"{applicant.gpas_by_year[0]:.2f} -> {applicant.gpas_by_year[-1]:.2f} ({trend_char})"
            
            print(
                f"{rank:<5} {applicant.applicant_id:<5} {applicant.name:<20} "
                f"{applicant.viability_score:<15.2f} {gpa_trend_str}"
            )
        
        print("\n--- Full Ranking of All Applicants ---")
        full_header = f"{'Rank':<5} {'Name':<20} {'Score':<10}"
        print(full_header)
        print("-" * len(full_header))
        for i, applicant in enumerate(self.ranked_applicants):
            print(f"{i+1:<5} {applicant.name:<20} {applicant.viability_score:<10.2f}")


        print("\n" + "=" * 60)
        print("Report Generation Complete.")
        print("=" * 60)

def get_sample_data() -> List[Dict[str, Any]]:
    """
    Provides a list of sample applicant data for demonstration.
    This fulfills NFR1 by keeping the application self-contained.
    """
    return [
        {
            "applicant_id": 101,
            "name": "Diana Prince",
            "gpas_by_year": [3.8, 3.9, 3.9, 4.0],
            "extracurriculars": ["Debate Club Lead", "Volleyball Team", "Student Government"],
            "professional_experience_years": 2,
        },
        {
            "applicant_id": 102,
            "name": "Bob Smith",
            "gpas_by_year": [2.8, 3.2, 3.5, 3.8],
            "extracurriculars": ["Coding Club"],
            "professional_experience_years": 1,
        },
        {
            "applicant_id": 103,
            "name": "Alice Johnson",
            "gpas_by_year": [4.0, 3.9, 3.8, 3.7],
            "extracurriculars": ["Research Assistant", "Literary Journal Editor"],
            "professional_experience_years": 3,
        },
        {
            "applicant_id": 104,
            "name": "Charlie Brown",
            "gpas_by_year": [3.5, 3.5, 3.5, 3.5],
            "extracurriculars": ["Music Band", "Chess Club", "Drama Society", "Tech Blog Writer"],
            "professional_experience_years": 0,
        },
        {
            "applicant_id": 105,
            "name": "Eve Adams",
            "gpas_by_year": [3.2, 3.0, 2.8, 2.5],
            "extracurriculars": ["Soccer Team"],
            "professional_experience_years": 4,
        }
    ]


if __name__ == "__main__":
    # --- System Execution ---

    # 1. Configuration
    NUM_SCHOLARSHIPS_TO_AWARD = 3

    # 2. Load Data (FR1 & NFR1)
    # The system is self-contained; data is loaded from an internal function.
    print("Loading applicant data...")
    sample_data = get_sample_data()
    all_applicants = [Applicant(**data) for data in sample_data]
    print(f"Successfully loaded {len(all_applicants)} applicants.")

    # 3. Initialize and Process
    print("\nProcessing applications and calculating scores...")
    manager = ScholarshipManager(all_applicants, NUM_SCHOLARSHIPS_TO_AWARD)
    manager.process_applications() # Performs scoring (FR2), ranking (FR3), and allocation (FR4)
    print("Processing complete.")

    # 4. Generate Report (NFR2)
    print("\nGenerating final report...")
    manager.generate_summary_report()