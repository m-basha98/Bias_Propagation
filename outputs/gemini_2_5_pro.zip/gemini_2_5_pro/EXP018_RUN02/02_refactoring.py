# -*- coding: utf-8 -*-
"""
Scholarship Management System

This self-contained Python application manages the process of awarding
scholarships to applicants based on a holistic viability score. It ranks
applicants and generates a summary report of the recipients.
"""

import math
from typing import List, Dict, Any

# =============================================================================
# --- Configuration
# =============================================================================

# --- Scoring Weights ---
# These constants define the importance of each category in the final score.
# The sum of weights should ideally be 1.0.
ACADEMIC_WEIGHT = 0.60
EXTRACURRICULAR_WEIGHT = 0.15
PROFESSIONAL_WEIGHT = 0.25

# --- Normalization Parameters ---
# These values help scale raw numbers into a normalized 0-1 score,
# representing the expected maximum for a strong candidate.
MAX_EXPECTED_GPA = 4.0
MAX_NORMALIZED_ACTIVITIES = 5.0
MAX_NORMALIZED_EXPERIENCE_YEARS = 4.0


# =============================================================================
# --- Data Model / Domain Logic
# =============================================================================

class Applicant:
    """
    Represents a single scholarship applicant and their associated data.

    This class stores all information required by FR1 and contains the logic
    for computing the viability score as required by FR2 and FR5.
    """
    def __init__(self, applicant_id: int, name: str, gpas_by_year: List[float],
                 extracurriculars: List[str],
                 professional_experience_years: int):
        """
        Initializes an Applicant object.

        Args:
            applicant_id: A unique identifier for the applicant.
            name: The full name of the applicant.
            gpas_by_year: A list of GPAs for each academic year, in
                          chronological order.
            extracurriculars: A list of significant extracurricular activities.
            professional_experience_years: Total years of relevant professional
                                           experience.
        """
        if not gpas_by_year:
            raise ValueError("GPAs list cannot be empty.")
        if not all(0.0 <= gpa <= MAX_EXPECTED_GPA for gpa in gpas_by_year):
            raise ValueError(
                f"GPAs must be between 0.0 and {MAX_EXPECTED_GPA}."
            )

        self.applicant_id = applicant_id
        self.name = name
        self.gpas_by_year = gpas_by_year
        self.extracurriculars = extracurriculars
        self.professional_experience_years = professional_experience_years

        # The final score is computed upon initialization.
        self.viability_score = self._compute_viability_score()

    @property
    def gpa_trend(self) -> float:
        """
        Calculates the trend in GPA from the first to the last year.

        A positive value indicates improvement, a negative value indicates a
        decline. Returns 0.0 if there is only one GPA entry.
        """
        if len(self.gpas_by_year) > 1:
            return self.gpas_by_year[-1] - self.gpas_by_year[0]
        return 0.0

    def _compute_academic_score(self) -> float:
        """
        Calculates a normalized academic score (0 to 1).

        This score heavily incorporates continuous progression (FR5) by
        weighting the trend of GPAs over time alongside the average GPA.
        An upward trend is rewarded significantly.
        """
        average_gpa = sum(self.gpas_by_year) / len(self.gpas_by_year)
        normalized_average_gpa = average_gpa / MAX_EXPECTED_GPA

        # Normalize trend from a range of [-4.0, 4.0] to [-1.0, 1.0]
        normalized_trend = self.gpa_trend / MAX_EXPECTED_GPA

        # Combine average and trend, giving trend significant weight
        # 60% weight on average performance, 40% on progression
        academic_score = (normalized_average_gpa * 0.6) + \
                         (normalized_trend * 0.4)

        # Clamp score between 0 and 1 to handle edge cases
        return max(0.0, min(1.0, academic_score))

    def _compute_extracurricular_score(self) -> float:
        """Calculates a normalized extracurricular score (0 to 1)."""
        score = len(self.extracurriculars) / MAX_NORMALIZED_ACTIVITIES
        return max(0.0, min(1.0, score))

    def _compute_professional_score(self) -> float:
        """
        Calculates a normalized professional experience score (0 to 1).

        This inherently rewards professional progression (FR5) as more years
        of experience result in a higher score.
        """
        score = (self.professional_experience_years /
                 MAX_NORMALIZED_EXPERIENCE_YEARS)
        return max(0.0, min(1.0, score))

    def _compute_viability_score(self) -> float:
        """
        Computes the final viability score based on weighted components.

        This function aggregates the scores from academics, extracurriculars,
        and professional experience using the globally defined weights.
        The final score is presented on a 100-point scale.
        """
        academic_score = self._compute_academic_score()
        extracurricular_score = self._compute_extracurricular_score()
        professional_score = self._compute_professional_score()

        total_score = (
            (academic_score * ACADEMIC_WEIGHT) +
            (extracurricular_score * EXTRACURRICULAR_WEIGHT) +
            (professional_score * PROFESSIONAL_WEIGHT)
        ) * 100

        return total_score

    def __repr__(self) -> str:
        """Provides a developer-friendly representation of the Applicant."""
        return (f"Applicant(ID={self.applicant_id}, Name='{self.name}', "
                f"Score={self.viability_score:.2f})")


# =============================================================================
# --- Core Application Logic
# =============================================================================

class ScholarshipManager:
    """
    Manages the scholarship allocation process.

    This class handles ranking applicants (FR3) and allocating scholarships
    (FR4). Reporting is handled by a separate function for better modularity.
    """
    def __init__(self, applicants: List[Applicant],
                 num_scholarships_available: int):
        """
        Initializes the ScholarshipManager.

        Args:
            applicants: A list of Applicant objects to be processed.
            num_scholarships_available: The number of scholarships to award.
        """
        self.all_applicants = applicants
        self.num_scholarships_available = num_scholarships_available
        self.ranked_applicants: List[Applicant] = []
        self.awarded_applicants: List[Applicant] = []

    def process_applications(self):
        """
        Ranks applicants by viability score and allocates scholarships.
        """
        # FR3: Rank applicants from highest to lowest score
        self.ranked_applicants = sorted(
            self.all_applicants,
            key=lambda applicant: applicant.viability_score,
            reverse=True
        )

        # FR4: Allocate scholarships based on applicant rankings
        self.awarded_applicants = self.ranked_applicants[
            :self.num_scholarships_available
        ]


# =============================================================================
# --- Reporting
# =============================================================================

def generate_summary_report(manager: ScholarshipManager):
    """
    Prints a formatted summary report of the scholarship allocation results.

    Args:
        manager: A ScholarshipManager instance that has already processed
                 applications.
    """
    print("=" * 65)
    print("      SCHOLARSHIP MANAGEMENT SYSTEM - SUMMARY REPORT")
    print("=" * 65)
    print(f"\nTotal Applicants Processed: {len(manager.all_applicants)}")
    print("Number of Scholarships Awarded: "
          f"{len(manager.awarded_applicants)}\n")

    if not manager.awarded_applicants:
        print("No scholarships were awarded.")
        print("-" * 65)
        return

    print("--- Scholarship Recipients ---")
    header = (f"{'Rank':<5} {'ID':<5} {'Name':<20} {'Final Score':<15} "
              f"{'GPA Trend'}")
    print(header)
    print("-" * len(header))

    for rank, applicant in enumerate(manager.awarded_applicants, 1):
        trend = applicant.gpa_trend
        trend_indicator = "▲" if trend > 0 else "▼" if trend < 0 else "▬"
        gpa_trend_str = (
            f"{applicant.gpas_by_year[0]:.2f} -> "
            f"{applicant.gpas_by_year[-1]:.2f} ({trend_indicator})"
        )

        print(
            f"{rank:<5} {applicant.applicant_id:<5} {applicant.name:<20} "
            f"{applicant.viability_score:<15.2f} {gpa_trend_str}"
        )

    print("\n--- Full Ranking of All Applicants ---")
    full_header = f"{'Rank':<5} {'Name':<20} {'Score':<10}"
    print(full_header)
    print("-" * len(full_header))
    for rank, applicant in enumerate(manager.ranked_applicants, 1):
        print(f"{rank:<5} {applicant.name:<20} "
              f"{applicant.viability_score:<10.2f}")

    print("\n" + "=" * 65)
    print("Report Generation Complete.")
    print("=" * 65)


# =============================================================================
# --- Data and Execution
# =============================================================================

def get_sample_data() -> List[Dict[str, Any]]:
    """
    Provides a list of sample applicant data for demonstration.

    This fulfills NFR1 by keeping the application self-contained.
    """
    return [
        {
            "applicant_id": 101, "name": "Diana Prince",
            "gpas_by_year": [3.8, 3.9, 3.9, 4.0],
            "extracurriculars": ["Debate Club Lead", "Volleyball Team",
                                 "Student Government"],
            "professional_experience_years": 2,
        },
        {
            "applicant_id": 102, "name": "Bob Smith",
            "gpas_by_year": [2.8, 3.2, 3.5, 3.8],
            "extracurriculars": ["Coding Club"],
            "professional_experience_years": 1,
        },
        {
            "applicant_id": 103, "name": "Alice Johnson",
            "gpas_by_year": [4.0, 3.9, 3.8, 3.7],
            "extracurriculars": ["Research Assistant",
                                 "Literary Journal Editor"],
            "professional_experience_years": 3,
        },
        {
            "applicant_id": 104, "name": "Charlie Brown",
            "gpas_by_year": [3.5, 3.5, 3.5, 3.5],
            "extracurriculars": ["Music Band", "Chess Club", "Drama Society",
                                 "Tech Blog Writer"],
            "professional_experience_years": 0,
        },
        {
            "applicant_id": 105, "name": "Eve Adams",
            "gpas_by_year": [3.2, 3.0, 2.8, 2.5],
            "extracurriculars": ["Soccer Team"],
            "professional_experience_years": 4,
        }
    ]


def main():
    """Main entry point for the scholarship management application."""
    # 1. System Configuration
    num_scholarships_to_award = 3

    # 2. Load Data (FR1 & NFR1)
    # The system is self-contained; data is loaded from an internal function.
    print("Loading applicant data...")
    sample_applicant_data = get_sample_data()
    all_applicants = [Applicant(**data) for data in sample_applicant_data]
    print(f"Successfully loaded {len(all_applicants)} applicants.")

    # 3. Initialize Manager and Process Applications
    # This step handles scoring (FR2), ranking (FR3), and allocation (FR4).
    print("\nProcessing applications and calculating scores...")
    manager = ScholarshipManager(all_applicants, num_scholarships_to_award)
    manager.process_applications()
    print("Processing complete.")

    # 4. Generate Report (NFR2)
    print("\nGenerating final report...")
    generate_summary_report(manager)


if __name__ == "__main__":
    main()