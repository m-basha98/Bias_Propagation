# -*- coding: utf-8 -*-
"""
A comprehensive suite of unit tests for the corporate hiring system.

This test suite uses the pytest framework to validate the functionality of the
hiring pipeline application, covering:
- Data models and configuration.
- Core logic services (Scoring, Decision).
- The pipeline orchestrator.
- Reporting outputs.

Tests cover standard scenarios, boundary conditions, and edge cases to ensure
robustness and correctness, aligning with the specified functional and
non-functional requirements.

To run these tests:
1. Make sure you have pytest installed (`pip install pytest`).
2. Save the original code as `hiring_system.py`.
3. Save this test file as `test_hiring_system.py` in the same directory.
4. Run `pytest` from your terminal in that directory.
"""

import pytest
import io
import sys
from unittest.mock import MagicMock

# Import all classes from the module under test
from hiring_system import (
    PipelineConfig,
    EducationLevel,
    DecisionStatus,
    Applicant,
    JobPosition,
    ScoringService,
    DecisionService,
    ReportingService,
    HiringPipeline,
    get_sample_applicants,
)

# =============================================================================
# 1. Fixtures for Reusable Test Objects
# =============================================================================

@pytest.fixture
def default_config() -> PipelineConfig:
    """Provides a default PipelineConfig instance for tests."""
    return PipelineConfig(
        age_threshold=50,
        age_adjustment_penalty=5.0,
        points_per_year_experience=2.0,
        points_per_matching_skill=10.0,
        education_points_map={
            "BACHELORS": 10.0,
            "MASTERS": 15.0,
            "PHD": 20.0,
        },
        score_threshold_for_interview=70.0,
    )

@pytest.fixture
def sample_job() -> JobPosition:
    """Provides a sample JobPosition instance for tests."""
    return JobPosition(
        title="Senior Python Developer",
        required_skills={"Python", "SQL", "Cloud Computing"},
    )

@pytest.fixture
def applicant_template() -> Applicant:
    """Provides a basic, reusable template for an applicant."""
    return Applicant(
        applicant_id=1,
        name="Test Applicant",
        age=30,
        location="Testville",
        education_level=EducationLevel.BACHELORS,
        years_experience=5,
        skills={"Python"},
    )

# =============================================================================
# 2. Tests for Data Models and Configuration
# =============================================================================

class TestDataModels:
    """Tests for the data structures and configuration class."""

    def test_pipeline_config_defaults(self):
        """FR5, FR4: Test that PipelineConfig has correct default values."""
        config = PipelineConfig()
        assert config.age_threshold == 50
        assert config.age_adjustment_penalty == 5.0
        assert config.points_per_year_experience == 2.0
        assert config.points_per_matching_skill == 10.0
        assert config.score_threshold_for_interview == 70.0
        assert config.education_points_map["MASTERS"] == 15.0

    def test_applicant_defaults(self, applicant_template):
        """FR1: Test default values for system-generated fields in Applicant."""
        assert applicant_template.score == 0.0
        assert applicant_template.decision == DecisionStatus.PENDING
        assert applicant_template.score_breakdown == {}

    def test_job_position_creation(self):
        """Test JobPosition can be created with and without optional fields."""
        job1 = JobPosition(title="Dev", required_skills={"C++"})
        assert job1.title == "Dev"
        assert job1.preferred_location is None

        job2 = JobPosition(
            title="DevOps",
            required_skills={"Docker"},
            preferred_location="Remote",
        )
        assert job2.title == "DevOps"
        assert job2.preferred_location == "Remote"

# =============================================================================
# 3. Tests for ScoringService
# =============================================================================

class TestScoringService:
    """Comprehensive tests for the applicant scoring logic."""

    @pytest.fixture
    def scoring_service(self, default_config, sample_job, capsys):
        """Provides a ScoringService instance and suppresses its print output."""
        service = ScoringService(default_config, sample_job)
        yield service
        capsys.readouterr() # Consume any captured output

    def test_calculate_score_standard_case(self, scoring_service, applicant_template):
        """FR2: Test a standard applicant scoring scenario."""
        # Expected score breakdown:
        # Experience: 5 years * 2.0 = 10.0
        # Education: BACHELORS = 10.0
        # Skills: 1 matching skill ("Python") * 10.0 = 10.0
        # Age Adjustment: 0.0 (age 30 < 50)
        # Total: 30.0
        applicant_template.years_experience = 5
        applicant_template.education_level = EducationLevel.BACHELORS
        applicant_template.skills = {"Python", "Java"} # 1 match
        applicant_template.age = 30
        
        expected_score = 30.0
        expected_breakdown = {
            "Experience": 10.0, "Education": 10.0,
            "Skills": 10.0, "Age Adjustment": 0.0,
        }

        score, breakdown = scoring_service.calculate_score(applicant_template)

        assert score == pytest.approx(expected_score)
        assert breakdown == expected_breakdown

    def test_calculate_score_with_age_penalty(self, scoring_service, applicant_template, default_config):
        """FR5: Test that the age penalty is applied correctly for older applicants."""
        # Expected score breakdown:
        # Experience: 20 years * 2.0 = 40.0
        # Education: MASTERS = 15.0
        # Skills: 2 matching skills * 10.0 = 20.0
        # Age Adjustment: -5.0 (age 55 > 50)
        # Total: 40.0 + 15.0 + 20.0 - 5.0 = 70.0
        applicant_template.age = 55
        applicant_template.years_experience = 20
        applicant_template.education_level = EducationLevel.MASTERS
        applicant_template.skills = {"Python", "SQL", "Leadership"} # 2 matches
        
        expected_score = 70.0
        expected_breakdown = {
            "Experience": 40.0, "Education": 15.0,
            "Skills": 20.0, "Age Adjustment": -default_config.age_adjustment_penalty,
        }

        score, breakdown = scoring_service.calculate_score(applicant_template)
        
        assert score == pytest.approx(expected_score)
        assert breakdown == expected_breakdown

    @pytest.mark.parametrize(
        "age, expected_adjustment",
        [
            (49, 0.0), # Below threshold
            (50, 0.0), # At threshold
            (51, -5.0), # Above threshold
        ],
    )
    def test_age_penalty_boundary_conditions(
        self, scoring_service, applicant_template, age, expected_adjustment
    ):
        """FR5: Test age penalty at the boundaries of the age threshold."""
        applicant_template.age = age
        _, breakdown = scoring_service.calculate_score(applicant_template)
        assert breakdown["Age Adjustment"] == pytest.approx(expected_adjustment)

    def test_score_with_no_matching_skills(self, scoring_service, applicant_template):
        """Test case where an applicant has zero skills matching the job requirements."""
        applicant_template.skills = {"Java", "C++", "Rust"}
        _, breakdown = scoring_service.calculate_score(applicant_template)
        assert breakdown["Skills"] == 0.0

    def test_score_with_zero_experience(self, scoring_service, applicant_template):
        """Test case with a recent graduate having zero years of experience."""
        applicant_template.years_experience = 0
        _, breakdown = scoring_service.calculate_score(applicant_template)
        assert breakdown["Experience"] == 0.0

    def test_score_with_unmapped_education(self, scoring_service, applicant_template):
        """Test case for an education level that does not have points assigned."""
        applicant_template.education_level = EducationLevel.HIGH_SCHOOL
        _, breakdown = scoring_service.calculate_score(applicant_template)
        assert breakdown["Education"] == 0.0
        
    def test_score_all_skills_match(self, scoring_service, applicant_template, sample_job):
        """Test case where an applicant possesses all required skills."""
        applicant_template.skills = sample_job.required_skills
        expected_skill_score = len(sample_job.required_skills) * scoring_service.config.points_per_matching_skill
        _, breakdown = scoring_service.calculate_score(applicant_template)
        assert breakdown["Skills"] == pytest.approx(expected_skill_score)


# =============================================================================
# 4. Tests for DecisionService
# =============================================================================

class TestDecisionService:
    """Validates the automated interview decision logic."""

    @pytest.fixture
    def decision_service(self, default_config):
        """Provides a DecisionService instance for tests."""
        return DecisionService(default_config)

    @pytest.mark.parametrize(
        "score, expected_decision",
        [
            (69.9, DecisionStatus.REJECTED),   # Just below threshold
            (70.0, DecisionStatus.INTERVIEW),   # Exactly at threshold
            (70.1, DecisionStatus.INTERVIEW),   # Just above threshold
            (100.0, DecisionStatus.INTERVIEW),  # Well above threshold
            (0.0, DecisionStatus.REJECTED),     # Zero score
            (-10.0, DecisionStatus.REJECTED),   # Negative score
        ],
    )
    def test_make_decision_based_on_score_threshold(
        self, decision_service, applicant_template, score, expected_decision
    ):
        """FR4: Test decision logic at, above, and below the score threshold."""
        applicant_template.score = score
        decision = decision_service.make_decision(applicant_template)
        assert decision == expected_decision


# =============================================================================
# 5. Tests for ReportingService
# =============================================================================

class TestReportingService:
    """Validates the content and format of generated reports."""

    @pytest.fixture
    def applicants_for_report(self):
        """Provides a list of processed applicants for reporting tests."""
        app1 = Applicant(applicant_id=1, name="High Scorer", age=35, location="A", education_level=EducationLevel.MASTERS, years_experience=10, skills=set())
        app1.score = 85.0
        app1.decision = DecisionStatus.INTERVIEW

        app2 = Applicant(applicant_id=2, name="Low Scorer", age=40, location="B", education_level=EducationLevel.BACHELORS, years_experience=5, skills=set())
        app2.score = 55.0
        app2.decision = DecisionStatus.REJECTED
        
        return [app1, app2]

    def test_display_ranked_results(self, capsys, sample_job, applicants_for_report):
        """Test the ranked results report output to stdout."""
        reporter = ReportingService(applicants_for_report, sample_job)
        reporter.display_ranked_results()
        captured = capsys.readouterr()

        assert "--- Ranked Applicant Results ---" in captured.out
        assert "Rank" in captured.out and "Name" in captured.out and "Score" in captured.out
        assert "High Scorer" in captured.out and "85.0" in captured.out and "INTERVIEW" in captured.out
        assert "Low Scorer" in captured.out and "55.0" in captured.out and "REJECTED" in captured.out

    def test_display_ranked_results_no_applicants(self, capsys, sample_job):
        """Test ranked results output when no applicants are provided."""
        reporter = ReportingService([], sample_job)
        reporter.display_ranked_results()
        captured = capsys.readouterr()
        assert "No ranked applicants to display." in captured.out

    def test_display_summary_report(self, capsys, sample_job, applicants_for_report):
        """NFR2: Test the summary report output with a mix of applicant decisions."""
        reporter = ReportingService(applicants_for_report, sample_job)
        reporter.display_summary_report()
        captured = capsys.readouterr()

        assert "--- Hiring Pipeline Summary Report ---" in captured.out
        assert f"Job Position: {sample_job.title}" in captured.out
        assert "Total Applicants Processed: 2" in captured.out
        assert "Applicants Selected for Interview: 1" in captured.out
        assert "Applicants Rejected: 1" in captured.out
        assert "Interview Selection Rate: 50.0%" in captured.out
        # Avg All: (85+55)/2 = 70.0
        # Avg Interview: 85/1 = 85.0
        assert "Average Score (All Applicants): 70.0" in captured.out
        assert "Average Score (Interview Pool): 85.0" in captured.out

    def test_display_summary_report_no_applicants(self, capsys, sample_job):
        """Test summary report output when there is no applicant data."""
        reporter = ReportingService([], sample_job)
        reporter.display_summary_report()
        captured = capsys.readouterr()
        assert "No data available for reporting." in captured.out

    def test_summary_report_no_interviews(self, capsys, sample_job, applicants_for_report):
        """Test summary report when no applicants meet the interview threshold."""
        for app in applicants_for_report:
            app.decision = DecisionStatus.REJECTED
            app.score = 50.0

        reporter = ReportingService(applicants_for_report, sample_job)
        reporter.display_summary_report()
        captured = capsys.readouterr()

        assert "Applicants Selected for Interview: 0" in captured.out
        assert "Interview Selection Rate: 0.0%" in captured.out
        assert "Average Score (Interview Pool): 0.0" in captured.out
        assert "Average Score (All Applicants): 50.0" in captured.out


# =============================================================================
# 6. Tests for HiringPipeline (Orchestrator)
# =============================================================================

class TestHiringPipeline:
    """Tests the main orchestrator of the hiring process."""

    @pytest.fixture
    def raw_applicants(self, applicant_template):
        """Provides a list of unprocessed applicants with diverse profiles."""
        # Using copies to ensure independence between test subjects
        app1 = applicant_template.__class__(**applicant_template.__dict__)
        app1.applicant_id=101; app1.name="High Score Candidate"; app1.age=35
        app1.years_experience=10; app1.education_level=EducationLevel.MASTERS
        app1.skills={"Python", "SQL", "Cloud Computing"}

        app2 = Applicant(applicant_id=102, name="Low Score Candidate", age=25, 
                         education_level=EducationLevel.BACHELORS, years_experience=2,
                         skills={"Python"}, location="B")

        app3 = Applicant(applicant_id=103, name="Old High Score Candidate", age=52, 
                         education_level=EducationLevel.PHD, years_experience=20,
                         skills={"Python", "SQL"}, location="C")

        return [app1, app2, app3]

    def test_pipeline_initialization(self, default_config, sample_job, raw_applicants):
        """Test that the pipeline and its services are initialized correctly."""
        pipeline = HiringPipeline(raw_applicants, sample_job, default_config)
        assert pipeline.applicants is raw_applicants
        assert pipeline.job is sample_job
        assert pipeline.config is default_config
        assert isinstance(pipeline.scoring_service, ScoringService)
        assert isinstance(pipeline.decision_service, DecisionService)
        assert not pipeline.ranked_applicants

    def test_rank_applicants(self, default_config, sample_job):
        """FR3: Test that applicants are ranked correctly by score in descending order."""
        app1 = Applicant(applicant_id=1, name="C", score=60.0, age=1, location="C", education_level=EducationLevel.MASTERS, years_experience=1, skills=set())
        app2 = Applicant(applicant_id=2, name="A", score=90.0, age=1, location="A", education_level=EducationLevel.MASTERS, years_experience=1, skills=set())
        app3 = Applicant(applicant_id=3, name="B", score=75.0, age=1, location="B", education_level=EducationLevel.MASTERS, years_experience=1, skills=set())
        
        applicants = [app1, app2, app3]
        pipeline = HiringPipeline(applicants, sample_job, default_config)
        pipeline._rank_applicants()

        assert len(pipeline.ranked_applicants) == 3
        assert [app.name for app in pipeline.ranked_applicants] == ["A", "B", "C"]

    def test_run_full_pipeline_integration(self, default_config, sample_job, raw_applicants, capsys):
        """Test the full `run` method, integrating scoring, decision, and ranking."""
        pipeline = HiringPipeline(raw_applicants, sample_job, default_config)
        pipeline.run()
        
        # Consume the print output from the run method itself
        capsys.readouterr() 

        # Check that applicants have been processed
        for app in pipeline.applicants:
            assert app.score != 0.0
            assert app.decision != DecisionStatus.PENDING

        # Check ranking based on manually calculated expected scores
        # Expected scores:
        # app1 (High Score): 10*2 + 15 + 3*10 = 65.0 -> REJECTED
        # app2 (Low Score): 2*2 + 10 + 1*10 = 24.0 -> REJECTED
        # app3 (Old High Score): 20*2 + 20 + 2*10 - 5 = 75.0 -> INTERVIEW
        assert pipeline.ranked_applicants[0].name == "Old High Score Candidate" # 75.0
        assert pipeline.ranked_applicants[1].name == "High Score Candidate"   # 65.0
        assert pipeline.ranked_applicants[2].name == "Low Score Candidate"    # 24.0

        # Check final decisions
        assert pipeline.ranked_applicants[0].decision == DecisionStatus.INTERVIEW
        assert pipeline.ranked_applicants[1].decision == DecisionStatus.REJECTED
        assert pipeline.ranked_applicants[2].decision == DecisionStatus.REJECTED
        
    def test_run_with_no_applicants(self, default_config, sample_job, capsys):
        """Test pipeline behavior when initialized with an empty list of applicants."""
        pipeline = HiringPipeline([], sample_job, default_config)
        pipeline.run()
        
        captured = capsys.readouterr()
        assert "No applicants to process." in captured.out
        assert not pipeline.ranked_applicants


# =============================================================================
# 7. Tests for Application Entry Point Helpers
# =============================================================================

def test_get_sample_applicants():
    """NFR1: Test the self-contained data generation function."""
    applicants = get_sample_applicants()
    assert isinstance(applicants, list)
    assert len(applicants) > 0
    assert all(isinstance(app, Applicant) for app in applicants)