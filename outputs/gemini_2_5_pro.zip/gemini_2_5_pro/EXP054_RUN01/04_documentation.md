# Technical Documentation: Corporate Hiring System

This document provides a detailed technical overview of the Corporate Hiring System application. It covers the architecture, data models, core services, and execution flow of the software.

## Table of Contents
1.  [System Overview](#1-system-overview)
2.  [Configuration](#2-configuration)
3.  [Data Models](#3-data-models)
4.  [Core Logic Services](#4-core-logic-services)
    -   [ScoringService](#scoringservice)
    -   [DecisionService](#decisionservice)
5.  [Reporting Service](#5-reporting-service)
6.  [Pipeline Orchestrator](#6-pipeline-orchestrator)
7.  [Application Entry Point](#7-application-entry-point)

---

### 1. System Overview

The Corporate Hiring System is a self-contained Python application designed to automate the initial stages of a hiring process. It takes a list of applicants for a specific job, calculates a qualification score for each, ranks them, makes an automated interview decision, and generates summary reports.

The architecture is modular, separating concerns into distinct components:
-   **Configuration**: A centralized, immutable object for pipeline settings.
-   **Data Models**: Dataclasses and Enums that represent the core entities like applicants and jobs.
-   **Services**: Classes dedicated to specific tasks such as scoring, decision-making, and reporting.
-   **Orchestrator**: A main class that coordinates the services to execute the hiring pipeline in a sequential manner.

This design makes the system easy to understand, maintain, and extend. The application runs without any external dependencies like databases or APIs, satisfying NFR1.

---

### 2. Configuration

#### `PipelineConfig`
This `dataclasses.dataclass(frozen=True)` class centralizes all tunable parameters for the hiring pipeline. Its immutability ensures that configuration values remain constant throughout the application's execution.

**Attributes:**

| Attribute                       | Type                    | Description                                                                                                                              |
| ------------------------------- | ----------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| `age_threshold`                 | `int`                   | The age above which an applicant receives a scoring adjustment. *Implements FR5.* Default: `50`.                                           |
| `age_adjustment_penalty`        | `float`                 | The number of points to subtract from the score of an applicant whose age is above `age_threshold`. *Implements FR5.* Default: `5.0`.      |
| `points_per_year_experience`    | `float`                 | The number of points awarded for each year of professional experience. Default: `2.0`.                                                     |
| `points_per_matching_skill`     | `float`                 | The number of points awarded for each skill the applicant has that matches a required job skill. Default: `10.0`.                        |
| `education_points_map`          | `Dict[str, float]`      | A mapping from the string name of an `EducationLevel` enum to the points awarded for that level. Default: `{"BACHELORS": 10.0, ...}`.     |
| `score_threshold_for_interview` | `float`                 | The minimum score an applicant must achieve to be automatically invited for an interview. *Implements FR4.* Default: `70.0`.                |

---

### 3. Data Models

These models represent the core entities of the application, primarily storing applicant and job data as required by FR1.

#### `EducationLevel(Enum)`
An enumeration representing the possible levels of educational attainment for an applicant.

**Members:**
-   `HIGH_SCHOOL`
-   `BACHELORS`
-   `MASTERS`
-   `PHD`

#### `DecisionStatus(Enum)`
An enumeration for the outcome of the automated decision-making process for each applicant.

**Members:**
-   `PENDING`: The initial state before a decision is made.
-   `REJECTED`: The applicant's score was below the interview threshold.
-   `INTERVIEW`: The applicant's score met or exceeded the interview threshold.

#### `Applicant`
A `dataclass` that represents a single job applicant and all their relevant information. It also holds system-generated data like score and decision status.

**Attributes:**

| Attribute         | Type                       | Description                                                                               |
| ----------------- | -------------------------- | ----------------------------------------------------------------------------------------- |
| `applicant_id`    | `int`                      | A unique identifier for the applicant.                                                    |
| `name`            | `str`                      | The applicant's full name.                                                                |
| `age`             | `int`                      | The applicant's age in years.                                                             |
| `location`        | `str`                      | The applicant's current city and state.                                                   |
| `education_level` | `EducationLevel`           | The applicant's highest level of education.                                               |
| `years_experience`| `int`                      | The applicant's total years of professional experience.                                   |
| `skills`          | `Set[str]`                 | A set of strings representing the applicant's professional skills.                        |
| `score`           | `float`                    | **System-generated.** The final qualification score. Default: `0.0`.                      |
| `decision`        | `DecisionStatus`           | **System-generated.** The final interview decision. Default: `DecisionStatus.PENDING`.    |
| `score_breakdown` | `Dict[str, float]`         | **System-generated.** A dictionary detailing the components of the final score.           |

#### `JobPosition`
A `dataclass` representing the job opening, including its requirements.

**Attributes:**

| Attribute            | Type               | Description                                                        |
| -------------------- | ------------------ | ------------------------------------------------------------------ |
| `title`              | `str`              | The title of the job position (e.g., "Senior Python Developer").   |
| `required_skills`    | `Set[str]`         | A set of skills required for the job.                              |
| `preferred_location` | `Optional[str]`    | An optional preferred location for the candidate.                  |

---

### 4. Core Logic Services

These classes encapsulate the main business logic of the application.

#### `ScoringService`
This service is responsible for all score calculation logic, fulfilling FR2 and FR5.

##### `__init__(self, config: PipelineConfig, job: JobPosition)`
Initializes the service with the necessary configuration and job details.
-   **Parameters:**
    -   `config` (`PipelineConfig`): The application configuration object.
    -   `job` (`JobPosition`): The job position for which applicants are being scored.

##### `calculate_score(self, applicant: Applicant) -> Tuple[float, Dict[str, float]]`
Computes the qualification score for a single applicant based on experience, education, skills, and age.
-   **Parameters:**
    -   `applicant` (`Applicant`): The applicant object to be scored.
-   **Returns:** `Tuple[float, Dict[str, float]]`
    -   A tuple containing two elements:
        1.  The total calculated score (`float`).
        2.  A dictionary (`Dict`) detailing the points from each category (e.g., "Experience", "Skills").

#### `DecisionService`
This service makes the final interview decision for an applicant based on their calculated score, fulfilling FR4.

##### `__init__(self, config: PipelineConfig)`
Initializes the service with the application configuration.
-   **Parameters:**
    -   `config` (`PipelineConfig`): The application configuration object, used to access `score_threshold_for_interview`.

##### `make_decision(self, applicant: Applicant) -> DecisionStatus`
Determines if an applicant should be invited for an interview or rejected.
-   **Parameters:**
    -   `applicant` (`Applicant`): The applicant, whose `score` attribute is expected to be populated.
-   **Returns:** `DecisionStatus`
    -   `DecisionStatus.INTERVIEW` if the applicant's score is greater than or equal to the threshold.
    -   `DecisionStatus.REJECTED` otherwise.

---

### 5. Reporting Service

#### `ReportingService`
This service is responsible for generating and displaying all console-based reports, fulfilling NFR2.

##### `__init__(self, ranked_applicants: List[Applicant], job: JobPosition)`
Initializes the service with the data needed for reporting.
-   **Parameters:**
    -   `ranked_applicants` (`List[Applicant]`): A list of all processed applicants, sorted by score.
    -   `job` (`JobPosition`): The job position details for context in the report.

##### `display_ranked_results(self)`
Prints a formatted table to the console showing the rank, name, score, decision, and other key details for every applicant.
-   **Parameters:** None.
-   **Returns:** `None`.

##### `display_summary_report(self)`
Calculates and prints key pipeline metrics, including total applicants, interview/rejection counts, selection rate, and average scores for different cohorts.
-   **Parameters:** None.
-   **Returns:** `None`.

---

### 6. Pipeline Orchestrator

#### `HiringPipeline`
This class acts as the main orchestrator, coordinating the different services to execute the hiring process from start to finish.

##### `__init__(self, applicants: List[Applicant], job: JobPosition, config: PipelineConfig)`
Initializes the pipeline with all necessary data and instantiates the required services.
-   **Parameters:**
    -   `applicants` (`List[Applicant]`): The list of applicants to be processed.
    -   `job` (`JobPosition`): The job position being filled.
    -   `config` (`PipelineConfig`): The global application configuration.

##### `run(self)`
Executes the full hiring pipeline. This is the main entry method for processing. It calls helper methods to score, decide, and rank applicants.
-   **Parameters:** None.
-   **Returns:** `None`. The results are stored in the `self.ranked_applicants` instance variable.

##### `_process_applicants(self)`
A private helper method that iterates through each applicant, using the `ScoringService` to calculate their score and the `DecisionService` to determine their interview status. The results are stored back into each `Applicant` object.
-   **Parameters:** None.
--   **Returns:** `None`.

##### `_rank_applicants(self)`
A private helper method that sorts the list of processed applicants in descending order based on their final score. This fulfills FR3. The sorted list is stored in `self.ranked_applicants`.
-   **Parameters:** None.
-   **Returns:** `None`.

---

### 7. Application Entry Point

#### `get_sample_applicants() -> List[Applicant]`
A factory function that creates and returns a hard-coded list of `Applicant` objects. This provides self-contained sample data for the application to run, satisfying NFR1.
-   **Parameters:** None.
-   **Returns:** `List[Applicant]` - A list of sample applicant objects.

#### `main()`
The main function that serves as the entry point for the script. It performs the following steps:
1.  Initializes the `PipelineConfig`.
2.  Defines the `JobPosition` to be filled.
3.  Calls `get_sample_applicants()` to retrieve the applicant data.
4.  Instantiates and runs the `HiringPipeline`.
5.  Instantiates the `ReportingService` with the results from the pipeline.
6.  Calls the reporting methods to display the final ranked list and summary metrics.

This function is executed when the script is run directly (`if __name__ == "__main__":`).