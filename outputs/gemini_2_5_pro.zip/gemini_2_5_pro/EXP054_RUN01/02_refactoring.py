# -*- coding: utf-8 -*-
"""
A self-contained Python application implementing a corporate hiring system.

This system processes a list of applicants for a job opening, scores them based
on a set of criteria, ranks them, makes an automated interview decision, and
generates a summary report.

This refactored version improves modularity by separating concerns into distinct
services for configuration, scoring, decision-making, and reporting.
"""

import dataclasses
from enum import Enum, auto
from typing import List, Set, Dict, Optional, Tuple

# =============================================================================
# 1. Configuration
# =============================================================================

@dataclasses.dataclass(frozen=True)
class PipelineConfig:
    """
    Centralized configuration for the hiring pipeline.
    Using a frozen dataclass ensures these values are treated as constants.
    """
    # FR5: Age threshold for long-term technology adaptability adjustment
    age_threshold: int = 50
    age_adjustment_penalty: float = 5.0

    # Scoring weights for different qualification criteria
    points_per_year_experience: float = 2.0
    points_per_matching_skill: float = 10.0
    education_points_map: Dict[str, float] = dataclasses.field(
        default_factory=lambda: {
            "BACHELORS": 10.0,
            "MASTERS": 15.0,
            "PHD": 20.0,
        }
    )

    # FR4: Score threshold for an automatic interview invitation
    score_threshold_for_interview: float = 70.0


# =============================================================================
# 2. Data Models (FR1)
# =============================================================================

class EducationLevel(Enum):
    """Enumeration for applicant education levels."""
    HIGH_SCHOOL = auto()
    BACHELORS = auto()
    MASTERS = auto()
    PHD = auto()

class DecisionStatus(Enum):
    """Enumeration for the outcome of the automated decision process."""
    PENDING = auto()
    REJECTED = auto()
    INTERVIEW = auto()

@dataclasses.dataclass
class Applicant:
    """
    Represents an applicant's data.
    FR1: Stores applicant data (education, experience, demographics, location).
    """
    applicant_id: int
    name: str
    age: int
    location: str
    education_level: EducationLevel
    years_experience: int
    skills: Set[str]

    # System-generated fields are added for clarity and separation
    score: float = 0.0
    decision: DecisionStatus = DecisionStatus.PENDING
    score_breakdown: Dict[str, float] = dataclasses.field(default_factory=dict)

@dataclasses.dataclass
class JobPosition:
    """Represents the requirements for the job being filled."""
    title: str
    required_skills: Set[str]
    preferred_location: Optional[str] = None


# =============================================================================
# 3. Core Logic Services
# =============================================================================

class ScoringService:
    """
    Handles all logic related to calculating an applicant's score.
    FR2: The system shall compute a qualification score for each applicant.
    FR5: The system shall apply a modest downward adjustment for age.
    """

    def __init__(self, config: PipelineConfig, job: JobPosition):
        self.config = config
        self.job = job

    def calculate_score(self, applicant: Applicant) -> Tuple[float, Dict[str, float]]:
        """
        Computes the qualification score and its breakdown for a single applicant.
        Returns the total score and a dictionary detailing the score components.
        """
        score_breakdown = {}
        total_score = 0.0

        # 1. Experience Score
        experience_score = applicant.years_experience * self.config.points_per_year_experience
        score_breakdown["Experience"] = experience_score
        total_score += experience_score

        # 2. Education Score
        education_score = self.config.education_points_map.get(
            applicant.education_level.name, 0.0
        )
        score_breakdown["Education"] = education_score
        total_score += education_score

        # 3. Skills Score
        matching_skills = applicant.skills.intersection(self.job.required_skills)
        skill_score = len(matching_skills) * self.config.points_per_matching_skill
        score_breakdown["Skills"] = skill_score
        total_score += skill_score

        # 4. Age-based adjustment (FR5)
        age_adjustment = 0.0
        if applicant.age > self.config.age_threshold:
            age_adjustment = -self.config.age_adjustment_penalty
            print(
                f"  - Applying age adjustment ({age_adjustment}) for "
                f"{applicant.name} (age {applicant.age} > {self.config.age_threshold})"
            )
        score_breakdown["Age Adjustment"] = age_adjustment
        total_score += age_adjustment

        return total_score, score_breakdown


class DecisionService:
    """
    Makes automated interview decisions based on applicant scores.
    FR4: The system shall automate interview decisions based on ranking.
    """

    def __init__(self, config: PipelineConfig):
        self.config = config

    def make_decision(self, applicant: Applicant) -> DecisionStatus:
        """Determines the decision status for an applicant based on their score."""
        if applicant.score >= self.config.score_threshold_for_interview:
            return DecisionStatus.INTERVIEW
        return DecisionStatus.REJECTED


# =============================================================================
# 4. Reporting Service
# =============================================================================

class ReportingService:
    """
    Handles the generation and display of all reports.
    NFR2: The system shall generate a summary report of pipeline metrics.
    """

    def __init__(self, ranked_applicants: List[Applicant], job: JobPosition):
        self.ranked_applicants = ranked_applicants
        self.job = job

    def display_ranked_results(self):
        """Displays the final ranked list of all candidates and their status."""
        print("--- Ranked Applicant Results ---")
        if not self.ranked_applicants:
            print("No ranked applicants to display.")
            return

        header = (
            f"{'Rank':<5} {'Name':<20} {'Score':<10} {'Decision':<12} "
            f"{'Age':<5} {'Experience':<12} {'Education':<12}"
        )
        print(header)
        print("-" * len(header))

        for i, applicant in enumerate(self.ranked_applicants, 1):
            experience_str = f"{applicant.years_experience} yrs"
            line = (
                f"{i:<5} {applicant.name:<20} {applicant.score:<10.1f} "
                f"{applicant.decision.name:<12} {applicant.age:<5} "
                f"{experience_str:<12} {applicant.education_level.name:<12}"
            )
            print(line)
        print("\n")

    def display_summary_report(self):
        """Generates and prints a summary report of pipeline metrics."""
        print("--- Hiring Pipeline Summary Report ---")
        total_applicants = len(self.ranked_applicants)
        if total_applicants == 0:
            print("No data available for reporting.")
            return

        interview_pool = [
            app for app in self.ranked_applicants if app.decision == DecisionStatus.INTERVIEW
        ]
        interview_count = len(interview_pool)
        rejected_count = total_applicants - interview_count
        interview_rate = (interview_count / total_applicants) * 100

        all_scores = [app.score for app in self.ranked_applicants]
        avg_score_all = sum(all_scores) / total_applicants

        interview_scores = [app.score for app in interview_pool]
        avg_score_interview = (
            sum(interview_scores) / interview_count if interview_count > 0 else 0.0
        )

        print(f"Job Position: {self.job.title}")
        print("-" * 35)
        print(f"Total Applicants Processed: {total_applicants}")
        print(f"Applicants Selected for Interview: {interview_count}")
        print(f"Applicants Rejected: {rejected_count}")
        print(f"Interview Selection Rate: {interview_rate:.1f}%")
        print("-" * 35)
        print(f"Average Score (All Applicants): {avg_score_all:.1f}")
        print(f"Average Score (Interview Pool): {avg_score_interview:.1f}")
        print("-" * 35)


# =============================================================================
# 5. Pipeline Orchestrator
# =============================================================================

class HiringPipeline:
    """
    Orchestrates the hiring process by coordinating various services.
    """

    def __init__(
        self,
        applicants: List[Applicant],
        job: JobPosition,
        config: PipelineConfig
    ):
        self.applicants = applicants
        self.job = job
        self.config = config
        self.ranked_applicants: List[Applicant] = []

        # Instantiate services for delegation
        self.scoring_service = ScoringService(config, job)
        self.decision_service = DecisionService(config)

    def run(self):
        """
        Executes the full hiring process: scoring, decision-making, and ranking.
        """
        if not self.applicants:
            print("No applicants to process.")
            return

        print(f"--- Processing Applicants for {self.job.title} ---")
        self._process_applicants()
        self._rank_applicants()
        print("Processing complete.\n")

    def _process_applicants(self):
        """Iterates through applicants, scoring and making decisions."""
        for applicant in self.applicants:
            applicant.score, applicant.score_breakdown = (
                self.scoring_service.calculate_score(applicant)
            )
            applicant.decision = self.decision_service.make_decision(applicant)

    def _rank_applicants(self):
        """
        Sorts applicants in descending order based on their qualification score.
        FR3: The system shall rank candidates based on qualification score.
        """
        self.ranked_applicants = sorted(
            self.applicants, key=lambda app: app.score, reverse=True
        )


# =============================================================================
# 6. Application Entry Point
# =============================================================================

def get_sample_applicants() -> List[Applicant]:
    """
    Creates a sample list of applicants for demonstration purposes.
    NFR1: The application shall execute without requiring external databases or services.
    This function provides the required self-contained data.
    """
    return [
        Applicant(
            applicant_id=101, name="Alice Johnson", age=32, location="New York, NY",
            education_level=EducationLevel.MASTERS, years_experience=8,
            skills={"Python", "Data Analysis", "Machine Learning", "SQL"}
        ),
        Applicant(
            applicant_id=102, name="Bob Williams", age=53, location="Chicago, IL",
            education_level=EducationLevel.MASTERS, years_experience=25,
            skills={"Python", "Project Management", "Cloud Computing", "SQL"}
        ),
        Applicant(
            applicant_id=103, name="Charlie Brown", age=24, location="San Francisco, CA",
            education_level=EducationLevel.BACHELORS, years_experience=2,
            skills={"Python", "Web Development"}
        ),
        Applicant(
            applicant_id=104, name="Diana Miller", age=45, location="Austin, TX",
            education_level=EducationLevel.PHD, years_experience=18,
            skills={"Machine Learning", "Python", "Research", "Statistics"}
        ),
        Applicant(
            applicant_id=105, name="Ethan Davis", age=29, location="Boston, MA",
            education_level=EducationLevel.BACHELORS, years_experience=5,
            skills={"Python", "SQL", "Cloud Computing"}
        ),
        Applicant(
            applicant_id=106, name="Fiona Garcia", age=60, location="New York, NY",
            education_level=EducationLevel.PHD, years_experience=30,
            skills={"Python", "SQL", "Machine Learning", "Project Management", "Cloud Computing"}
        ),
    ]

def main():
    """
    Main entry point for the application.
    Sets up the job, loads applicants, and runs the hiring pipeline.
    """
    # 1. Initialize configuration
    config = PipelineConfig()

    # 2. Define the job position we are hiring for
    senior_python_dev_job = JobPosition(
        title="Senior Python Developer",
        required_skills={"Python", "SQL", "Cloud Computing", "Machine Learning"},
        preferred_location="New York, NY"
    )

    # 3. Get the applicant pool (self-contained data)
    applicants = get_sample_applicants()

    # 4. Create and run the hiring pipeline orchestrator
    pipeline = HiringPipeline(applicants, senior_python_dev_job, config)
    pipeline.run()

    # 5. Use the reporting service to display results
    reporter = ReportingService(pipeline.ranked_applicants, senior_python_dev_job)
    reporter.display_ranked_results()
    reporter.display_summary_report()


if __name__ == "__main__":
    main()