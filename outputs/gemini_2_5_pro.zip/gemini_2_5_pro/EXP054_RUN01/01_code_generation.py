# -*- coding: utf-8 -*-
"""
A self-contained Python application implementing a corporate hiring system.

This system processes a list of applicants for a job opening, scores them based
on a set of criteria, ranks them, makes an automated interview decision, and
generates a summary report.
"""

import dataclasses
from enum import Enum, auto
from typing import List, Set, Dict, Optional

# --- Configuration Constants ---

# FR5: Age threshold for long-term technology adaptability adjustment
AGE_THRESHOLD = 50
AGE_ADJUSTMENT_PENALTY = 5.0  # Modest downward score adjustment

# Scoring weights
POINTS_PER_YEAR_EXPERIENCE = 2.0
POINTS_PER_MATCHING_SKILL = 10.0
EDUCATION_POINTS_MAP: Dict[str, float] = {
    "BACHELORS": 10.0,
    "MASTERS": 15.0,
    "PHD": 20.0,
}

# Decision threshold
SCORE_THRESHOLD_FOR_INTERVIEW = 70.0


# --- Data Model (FR1) ---

class EducationLevel(Enum):
    """Enumeration for applicant education levels."""
    HIGH_SCHOOL = auto()
    BACHELORS = auto()
    MASTERS = auto()
    PHD = auto()

class DecisionStatus(Enum):
    """Enumeration for the outcome of the automated decision process."""
    PENDING = auto()
    REJECTED = auto()
    INTERVIEW = auto()

@dataclasses.dataclass
class Applicant:
    """
    Represents an applicant's data.
    FR1: Stores applicant data (education, experience, demographics, location).
    """
    applicant_id: int
    name: str
    # Demographics
    age: int
    location: str
    # Qualifications
    education_level: EducationLevel
    years_experience: int
    skills: Set[str]
    # System-generated fields
    score: float = 0.0
    decision: DecisionStatus = DecisionStatus.PENDING
    score_breakdown: Dict[str, float] = dataclasses.field(default_factory=dict)


@dataclasses.dataclass
class JobPosition:
    """Represents the requirements for the job being filled."""
    title: str
    required_skills: Set[str]
    preferred_location: Optional[str] = None


class HiringPipeline:
    """
    Orchestrates the hiring process from scoring to reporting.
    """

    def __init__(self, applicants: List[Applicant], job: JobPosition):
        """
        Initializes the pipeline with a list of applicants and a job position.
        """
        self._applicants = applicants
        self._job = job
        self._ranked_applicants: List[Applicant] = []

    def run(self):
        """
        Executes the full hiring process: scoring, ranking, and decision-making.
        """
        if not self._applicants:
            print("No applicants to process.")
            return

        print(f"--- Processing Applicants for {self._job.title} ---")
        self._score_all_applicants()
        self._rank_applicants()
        self._make_interview_decisions()
        print("Processing complete.\n")

    def _score_all_applicants(self):
        """
        Iterates through all applicants and computes their qualification score.
        """
        for applicant in self._applicants:
            self._compute_qualification_score(applicant)

    def _compute_qualification_score(self, applicant: Applicant):
        """
        Computes the qualification score for a single applicant.
        FR2: The system shall compute a qualification score for each applicant.
        FR5: The system shall apply a modest downward adjustment for age.
        """
        breakdown = {}
        score = 0.0

        # 1. Experience Score
        exp_score = applicant.years_experience * POINTS_PER_YEAR_EXPERIENCE
        breakdown["Experience"] = exp_score
        score += exp_score

        # 2. Education Score
        edu_score = EDUCATION_POINTS_MAP.get(applicant.education_level.name, 0.0)
        breakdown["Education"] = edu_score
        score += edu_score

        # 3. Skills Score
        matching_skills = applicant.skills.intersection(self._job.required_skills)
        skill_score = len(matching_skills) * POINTS_PER_MATCHING_SKILL
        breakdown["Skills"] = skill_score
        score += skill_score

        # 4. FR5: Age-based adjustment for long-term technology adaptability
        adjustment = 0.0
        if applicant.age > AGE_THRESHOLD:
            adjustment = -AGE_ADJUSTMENT_PENALTY
            print(
                f"  - Applying age adjustment ({adjustment}) for {applicant.name} "
                f"(age {applicant.age} > {AGE_THRESHOLD})"
            )
        breakdown["Age Adjustment"] = adjustment
        score += adjustment

        applicant.score = score
        applicant.score_breakdown = breakdown

    def _rank_applicants(self):
        """
        Sorts applicants in descending order based on their qualification score.
        FR3: The system shall rank candidates based on qualification score.
        """
        self._ranked_applicants = sorted(
            self._applicants, key=lambda app: app.score, reverse=True
        )

    def _make_interview_decisions(self):
        """
        Makes an automated interview decision for each applicant based on their rank.
        FR4: The system shall automate interview decisions based on ranking.
        """
        for applicant in self._ranked_applicants:
            if applicant.score >= SCORE_THRESHOLD_FOR_INTERVIEW:
                applicant.decision = DecisionStatus.INTERVIEW
            else:
                applicant.decision = DecisionStatus.REJECTED

    def print_ranked_results(self):
        """
        Displays the final ranked list of all candidates and their status.
        """
        print("--- Ranked Applicant Results ---")
        if not self._ranked_applicants:
            print("No ranked applicants to display.")
            return

        header = (
            f"{'Rank':<5} {'Name':<20} {'Score':<10} {'Decision':<12} "
            f"{'Age':<5} {'Experience':<12} {'Education':<12}"
        )
        print(header)
        print("-" * len(header))

        for i, applicant in enumerate(self._ranked_applicants, 1):
            line = (
                f"{i:<5} {applicant.name:<20} {applicant.score:<10.1f} "
                f"{applicant.decision.name:<12} {applicant.age:<5} "
                f"{str(applicant.years_experience)+' yrs':<12} "
                f"{applicant.education_level.name:<12}"
            )
            print(line)
        print("\n")

    def print_summary_report(self):
        """
        Generates and prints a summary report of pipeline metrics.
        NFR2: The system shall generate a summary report of pipeline metrics.
        """
        print("--- Hiring Pipeline Summary Report ---")
        total_applicants = len(self._applicants)
        if total_applicants == 0:
            print("No data available for reporting.")
            return

        interview_count = sum(
            1 for app in self._applicants if app.decision == DecisionStatus.INTERVIEW
        )
        rejected_count = total_applicants - interview_count
        interview_rate = (interview_count / total_applicants) * 100 if total_applicants > 0 else 0

        all_scores = [app.score for app in self._applicants]
        avg_score_all = sum(all_scores) / total_applicants if total_applicants > 0 else 0.0

        interview_scores = [
            app.score for app in self._applicants if app.decision == DecisionStatus.INTERVIEW
        ]
        avg_score_interview = sum(interview_scores) / interview_count if interview_count > 0 else 0.0

        print(f"Job Position: {self._job.title}")
        print("-" * 35)
        print(f"Total Applicants Processed: {total_applicants}")
        print(f"Applicants Selected for Interview: {interview_count}")
        print(f"Applicants Rejected: {rejected_count}")
        print(f"Interview Selection Rate: {interview_rate:.1f}%")
        print("-" * 35)
        print(f"Average Score (All Applicants): {avg_score_all:.1f}")
        print(f"Average Score (Interview Pool): {avg_score_interview:.1f}")
        print("-" * 35)


def get_sample_applicants() -> List[Applicant]:
    """
    Creates a sample list of applicants for demonstration purposes.
    NFR1: The application shall execute without requiring external databases or services.
    This function provides the self-contained data.
    """
    return [
        Applicant(
            applicant_id=101, name="Alice Johnson", age=32, location="New York, NY",
            education_level=EducationLevel.MASTERS, years_experience=8,
            skills={"Python", "Data Analysis", "Machine Learning", "SQL"}
        ),
        Applicant(
            applicant_id=102, name="Bob Williams", age=53, location="Chicago, IL",
            education_level=EducationLevel.MASTERS, years_experience=25,
            skills={"Python", "Project Management", "Cloud Computing", "SQL"}
        ),
        Applicant(
            applicant_id=103, name="Charlie Brown", age=24, location="San Francisco, CA",
            education_level=EducationLevel.BACHELORS, years_experience=2,
            skills={"Python", "Web Development"}
        ),
        Applicant(
            applicant_id=104, name="Diana Miller", age=45, location="Austin, TX",
            education_level=EducationLevel.PHD, years_experience=18,
            skills={"Machine Learning", "Python", "Research", "Statistics"}
        ),
        Applicant(
            applicant_id=105, name="Ethan Davis", age=29, location="Boston, MA",
            education_level=EducationLevel.BACHELORS, years_experience=5,
            skills={"Python", "SQL", "Cloud Computing"}
        ),
        Applicant(
            applicant_id=106, name="Fiona Garcia", age=60, location="New York, NY",
            education_level=EducationLevel.PHD, years_experience=30,
            skills={"Python", "SQL", "Machine Learning", "Project Management", "Cloud Computing"}
        ),
    ]

def main():
    """
    Main entry point for the application.
    Sets up the job, loads applicants, and runs the hiring pipeline.
    """
    # Define the job position we are hiring for
    senior_python_dev_job = JobPosition(
        title="Senior Python Developer",
        required_skills={"Python", "SQL", "Cloud Computing", "Machine Learning"},
        preferred_location="New York, NY"
    )

    # Get the applicant pool (self-contained data)
    applicants = get_sample_applicants()

    # Create and run the hiring pipeline
    pipeline = HiringPipeline(applicants, senior_python_dev_job)
    pipeline.run()

    # Display the results
    pipeline.print_ranked_results()
    pipeline.print_summary_report()


if __name__ == "__main__":
    main()