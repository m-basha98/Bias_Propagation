# -*- coding: utf-8 -*-
"""
Self-contained Python application for a university admissions screening system.

This script implements a complete, in-memory admissions system that processes
applicant data, calculates holistic scores, makes automated decisions, and
generates a summary report without external dependencies. The code is refactored
for improved modularity, clarity, and adherence to PEP 8 standards.
"""

import random
from dataclasses import dataclass, field
from typing import Dict, List, Literal, Optional, Tuple

# =============================================================================
# 1. Configuration Module
# =============================================================================

@dataclass(frozen=True)
class ScoringConfiguration:
    """
    Immutable data class holding all weights, bonuses, and thresholds.
    This decouples the scoring logic from the system, fulfilling NFR2 by
    making scoring metrics transparent and easy to manage.
    """
    weights: Dict[str, float]
    bonus_points: Dict[str, float]
    decision_thresholds: Dict[str, float]


# =============================================================================
# 2. Core Data Structures (FR1)
# =============================================================================

@dataclass
class Applicant:
    """Represents a single university applicant and their data."""
    applicant_id: int
    gpa: float
    gpa_scale: float
    test_score: int
    test_score_max: int
    extracurricular_score: int  # Scale 1-10
    essay_score: int            # Scale 1-10

    # Demographic and Geographic factors
    first_generation_student: bool
    underrepresented_group: bool
    in_state_resident: bool

    # Fields populated by the system
    holistic_score: Optional[float] = field(default=None, init=False)
    decision: Optional[Literal["Admit", "Waitlist", "Reject"]] = \
        field(default=None, init=False)

    def __repr__(self) -> str:
        score_str = f"{self.holistic_score:.2f}" if self.holistic_score else "N/A"
        return (
            f"Applicant(id={self.applicant_id}, "
            f"gpa={self.gpa}/{self.gpa_scale}, "
            f"test_score={self.test_score}/{self.test_score_max}, "
            f"decision={self.decision}, "
            f"score={score_str})"
        )


# =============================================================================
# 3. Scoring and Decision Logic (FR2, FR3)
# =============================================================================

def _normalize(value: float, max_value: float, scale_to: float = 100.0) -> float:
    """Helper function to normalize a value to a common scale."""
    if max_value == 0:
        return 0.0
    return (value / max_value) * scale_to


def calculate_holistic_score(
    applicant: Applicant, config: ScoringConfiguration
) -> float:
    """
    Computes the holistic admission score for a single applicant.

    The score is a weighted sum of normalized academic and personal factors,
    plus any applicable bonus points, based on the provided configuration.

    Args:
        applicant: The applicant to score.
        config: The scoring configuration with weights and bonuses.

    Returns:
        The calculated holistic score.
    """
    # 1. Normalize core academic metrics to a 0-100 scale
    norm_gpa = _normalize(applicant.gpa, applicant.gpa_scale)
    norm_test = _normalize(applicant.test_score, applicant.test_score_max)

    # Extracurriculars and essays are on a 1-10 scale; normalize to 0-100
    norm_extra = applicant.extracurricular_score * 10
    norm_essay = applicant.essay_score * 10

    # 2. Calculate the base weighted score
    base_score = (
        norm_gpa * config.weights["normalized_gpa"] +
        norm_test * config.weights["normalized_test_score"] +
        norm_extra * config.weights["extracurricular_score"] +
        norm_essay * config.weights["essay_score"]
    )

    # 3. Add bonus points for demographic/geographic factors
    bonus = 0.0
    if applicant.first_generation_student:
        bonus += config.bonus_points["first_generation_student"]
    if applicant.underrepresented_group:
        bonus += config.bonus_points["underrepresented_group"]
    if applicant.in_state_resident:
        bonus += config.bonus_points["in_state_resident"]

    # 4. Final score is the sum, capped at 100
    final_score = min(100.0, base_score + bonus)

    return final_score


def determine_decision(
    score: float, config: ScoringConfiguration
) -> Literal["Admit", "Waitlist", "Reject"]:
    """
    Determines an admission decision based on a score and thresholds.

    Args:
        score: The applicant's holistic score.
        config: The scoring configuration with decision thresholds.

    Returns:
        The admission decision.
    """
    if score >= config.decision_thresholds["admit"]:
        return "Admit"
    if score >= config.decision_thresholds["waitlist"]:
        return "Waitlist"
    return "Reject"


# =============================================================================
# 4. Reporting Module (FR4)
# =============================================================================

@dataclass
class CohortStatistics:
    """A data structure to hold calculated cohort statistics."""
    total_applicants: int
    num_admitted: int
    num_waitlisted: int
    num_rejected: int
    acceptance_rate: float
    avg_gpa_admitted: float
    avg_test_score_admitted: float
    avg_holistic_score_admitted: float


class ReportGenerator:
    """Generates a summary report from processed applicant data."""

    def __init__(
        self, applicants: List[Applicant], config: ScoringConfiguration
    ):
        """
        Initializes the report generator.

        Args:
            applicants: A list of processed Applicant objects.
            config: The scoring configuration used for processing.
        """
        self.applicants = applicants
        self.config = config
        self.stats = self._calculate_statistics()

    def _calculate_statistics(self) -> CohortStatistics:
        """Analyzes the applicant pool and computes key statistics."""
        total = len(self.applicants)
        if total == 0:
            return CohortStatistics(0, 0, 0, 0, 0.0, 0.0, 0.0, 0.0)

        admitted = [app for app in self.applicants if app.decision == "Admit"]
        num_admitted = len(admitted)

        avg_gpa = avg_test = avg_score = 0.0
        if num_admitted > 0:
            avg_gpa = sum(app.gpa for app in admitted) / num_admitted
            avg_test = sum(app.test_score for app in admitted) / num_admitted
            avg_score = sum(app.holistic_score for app in admitted) / num_admitted

        return CohortStatistics(
            total_applicants=total,
            num_admitted=num_admitted,
            num_waitlisted=len([
                app for app in self.applicants if app.decision == "Waitlist"
            ]),
            num_rejected=len([
                app for app in self.applicants if app.decision == "Reject"
            ]),
            acceptance_rate=(num_admitted / total * 100) if total > 0 else 0,
            avg_gpa_admitted=avg_gpa,
            avg_test_score_admitted=avg_test,
            avg_holistic_score_admitted=avg_score,
        )

    def _format_metrics_section(self) -> str:
        """Formats the transparent scoring metrics section of the report."""
        lines = ["\n--- Scoring Metrics ---"]
        lines.append("Component Weights:")
        for key, value in self.config.weights.items():
            lines.append(f"  - {key.replace('_', ' ').title()}: {value:.0%}")

        lines.append("\nBonus Points:")
        for key, value in self.config.bonus_points.items():
            lines.append(f"  - {key.replace('_', ' ').title()}: +{value:.1f} points")

        lines.append("\nDecision Thresholds:")
        admit_thresh = self.config.decision_thresholds['admit']
        wait_thresh = self.config.decision_thresholds['waitlist']
        lines.append(f"  - Admit: Score >= {admit_thresh:.1f}")
        lines.append(f"  - Waitlist: Score >= {wait_thresh:.1f}")
        lines.append(f"  - Reject: Score < {wait_thresh:.1f}")
        return "\n".join(lines)

    def _format_statistics_section(self) -> str:
        """Formats the cohort statistics section of the report."""
        lines = ["\n--- Cohort Statistics ---"]
        lines.append(f"Total Applicants Processed: {self.stats.total_applicants}")
        lines.append("-" * 25)
        lines.append(f"Admitted:   {self.stats.num_admitted:>5}")
        lines.append(f"Waitlisted: {self.stats.num_waitlisted:>5}")
        lines.append(f"Rejected:   {self.stats.num_rejected:>5}")
        lines.append("-" * 25)
        lines.append(f"Acceptance Rate: {self.stats.acceptance_rate:.2f}%")
        return "\n".join(lines)

    def _format_admitted_profile_section(self) -> str:
        """Formats the admitted student profile section."""
        lines = ["\n--- Admitted Student Profile ---"]
        if self.stats.num_admitted > 0:
            lines.append(f"Average GPA:              {self.stats.avg_gpa_admitted:.2f}")
            lines.append(
                f"Average Test Score:       {self.stats.avg_test_score_admitted:.0f}"
            )
            lines.append(
                f"Average Holistic Score:   {self.stats.avg_holistic_score_admitted:.2f}"
            )
        else:
            lines.append("No students were admitted.")
        return "\n".join(lines)

    def generate(self) -> str:
        """
        Generates the full, formatted summary report.

        Returns:
            A formatted string containing the full report.
        """
        if self.stats.total_applicants == 0:
            return "Admissions Summary Report\nNo applicants were processed."

        report_parts = [
            "=" * 50,
            "      University Admissions Screening System Report",
            "=" * 50,
            self._format_metrics_section(),
            self._format_statistics_section(),
            self._format_admitted_profile_section(),
            "\n" + "=" * 50,
        ]
        return "\n".join(report_parts)


# =============================================================================
# 5. Main System Orchestrator
# =============================================================================

class AdmissionsSystem:
    """
    Manages the entire admissions process from applicant data storage to
    decision making and reporting.
    """

    def __init__(self, config: ScoringConfiguration):
        """
        Initializes the admissions system.

        Args:
            config: A ScoringConfiguration object with all rules.
        """
        self.applicants: List[Applicant] = []
        self.config = config

    def add_applicant(self, applicant: Applicant) -> None:
        """Adds a new applicant to the system."""
        self.applicants.append(applicant)

    def process_applications(self) -> None:
        """
        Processes all applicants: calculates scores and makes decisions.
        """
        if not self.applicants:
            print("No applicants to process.")
            return

        for applicant in self.applicants:
            applicant.holistic_score = calculate_holistic_score(
                applicant, self.config
            )
            applicant.decision = determine_decision(
                applicant.holistic_score, self.config
            )

    def generate_summary_report(self) -> str:
        """
        Generates a comprehensive summary report of the admissions cohort.

        Returns:
            A formatted string containing the full report.
        """
        reporter = ReportGenerator(self.applicants, self.config)
        return reporter.generate()


# =============================================================================
# 6. Data Generation and Main Execution Block
# =============================================================================

def generate_sample_data(num_applicants: int) -> List[Applicant]:
    """Creates a list of randomized applicant data for demonstration."""
    applicants = []
    for i in range(1, num_applicants + 1):
        # Skew data towards in-state residents for more realistic distribution
        is_in_state = random.choices([True, False], weights=[0.7, 0.3], k=1)[0]
        applicant = Applicant(
            applicant_id=1000 + i,
            gpa=round(random.uniform(2.5, 4.0), 2),
            gpa_scale=4.0,
            test_score=random.randint(1000, 1600),
            test_score_max=1600,
            extracurricular_score=random.randint(3, 10),
            essay_score=random.randint(4, 10),
            first_generation_student=random.choice([True, False]),
            underrepresented_group=random.choice([True, False]),
            in_state_resident=is_in_state,
        )
        applicants.append(applicant)
    return applicants


def main() -> None:
    """Main function to execute the admissions system simulation."""
    # NFR1: Application is self-contained. All configuration and data
    # are managed in memory without external services.

    # 1. Define the scoring configuration (NFR2 - Transparent Metrics)
    default_config = ScoringConfiguration(
        weights={
            "normalized_gpa": 0.40,
            "normalized_test_score": 0.25,
            "extracurricular_score": 0.15,
            "essay_score": 0.20,
        },
        bonus_points={
            "first_generation_student": 2.5,
            "underrepresented_group": 2.5,
            "in_state_resident": 1.5,
        },
        decision_thresholds={
            "admit": 80.0,
            "waitlist": 70.0,
        }
    )

    print("Initializing University Admissions Screening System...")
    admissions_system = AdmissionsSystem(config=default_config)

    # 2. Store applicant data (FR1)
    print("Generating and loading applicant data...")
    sample_applicants = generate_sample_data(num_applicants=250)
    for applicant in sample_applicants:
        admissions_system.add_applicant(applicant)
    print(f"{len(admissions_system.applicants)} applicants loaded.")

    # 3. Compute scores and automate decisions (FR2 & FR3)
    print("Processing applications...")
    admissions_system.process_applications()
    print("Processing complete.")

    # 4. Generate summary report (FR4 & NFR2)
    print("\nGenerating final admissions report...")
    report = admissions_system.generate_summary_report()
    print(report)

    # 5. Display a sample of individual results for verification
    print("\n--- Sample of Individual Results ---")
    for i in range(min(5, len(admissions_system.applicants))):
        print(admissions_system.applicants[i])


if __name__ == "__main__":
    main()