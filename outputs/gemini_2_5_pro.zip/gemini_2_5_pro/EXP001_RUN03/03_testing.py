# test_admissions_system.py

"""
Comprehensive unit tests for the university admissions screening system.

This test suite uses pytest to verify the functionality of all components,
including data structures, scoring logic, decision-making, reporting, and
the main system orchestrator. It covers standard scenarios, boundary
conditions, and edge cases to ensure the system's reliability and correctness.
"""

import math
import pytest
from dataclasses import FrozenInstanceError
from typing import List, Dict

# Assuming the refactored code is in a file named 'admissions_system.py'
from admissions_system import (
    ScoringConfiguration,
    Applicant,
    _normalize,
    calculate_holistic_score,
    determine_decision,
    CohortStatistics,
    ReportGenerator,
    AdmissionsSystem,
    generate_sample_data,
)


# =============================================================================
# 1. Pytest Fixtures for Reusable Test Data
# =============================================================================

@pytest.fixture(scope="module")
def default_config() -> ScoringConfiguration:
    """Provides a standard, reusable ScoringConfiguration instance for tests."""
    return ScoringConfiguration(
        weights={
            "normalized_gpa": 0.40,
            "normalized_test_score": 0.25,
            "extracurricular_score": 0.15,
            "essay_score": 0.20,
        },
        bonus_points={
            "first_generation_student": 2.5,
            "underrepresented_group": 2.5,
            "in_state_resident": 1.5,
        },
        decision_thresholds={
            "admit": 80.0,
            "waitlist": 70.0,
        }
    )

@pytest.fixture
def perfect_applicant() -> Applicant:
    """An applicant with maximum scores and all bonus-eligible traits."""
    return Applicant(
        applicant_id=1, gpa=4.0, gpa_scale=4.0, test_score=1600,
        test_score_max=1600, extracurricular_score=10, essay_score=10,
        first_generation_student=True, underrepresented_group=True,
        in_state_resident=True
    )

@pytest.fixture
def average_applicant() -> Applicant:
    """An applicant with average scores and no bonus-eligible traits."""
    return Applicant(
        applicant_id=2, gpa=3.2, gpa_scale=4.0, test_score=1200,
        test_score_max=1600, extracurricular_score=7, essay_score=7,
        first_generation_student=False, underrepresented_group=False,
        in_state_resident=False
    )

@pytest.fixture
def borderline_waitlist_applicant() -> Applicant:
    """An applicant designed to score exactly on the waitlist threshold."""
    # (3.0/4.0 * 100 * 0.4) + (1120/1600 * 100 * 0.25) + (7*10*0.15) + (8*10*0.2)
    # 30 + 17.5 + 10.5 + 16 = 74
    return Applicant(
        applicant_id=3, gpa=3.0, gpa_scale=4.0, test_score=1120,
        test_score_max=1600, extracurricular_score=7, essay_score=8,
        first_generation_student=False, underrepresented_group=False,
        in_state_resident=False
    )

@pytest.fixture
def processed_applicant_pool(default_config) -> List[Applicant]:
    """Provides a list of applicants that have already been processed."""
    app1 = Applicant(applicant_id=101, gpa=3.8, gpa_scale=4.0, test_score=1500, test_score_max=1600,
                     extracurricular_score=9, essay_score=9, first_generation_student=True,
                     underrepresented_group=False, in_state_resident=True)
    app2 = Applicant(applicant_id=102, gpa=3.5, gpa_scale=4.0, test_score=1300, test_score_max=1600,
                     extracurricular_score=8, essay_score=7, first_generation_student=False,
                     underrepresented_group=True, in_state_resident=False)
    app3 = Applicant(applicant_id=103, gpa=2.9, gpa_scale=4.0, test_score=1100, test_score_max=1600,
                     extracurricular_score=6, essay_score=6, first_generation_student=False,
                     underrepresented_group=False, in_state_resident=True)

    pool = [app1, app2, app3]
    for app in pool:
        app.holistic_score = calculate_holistic_score(app, default_config)
        app.decision = determine_decision(app.holistic_score, default_config)
    return pool

# =============================================================================
# 2. Test Suites for Each Module
# =============================================================================

class TestCoreDataStructures:
    """Tests for the core data classes: ScoringConfiguration and Applicant."""

    def test_scoring_configuration_is_immutable(self, default_config):
        """FR1, NFR2: Verify that ScoringConfiguration is a frozen dataclass."""
        with pytest.raises(FrozenInstanceError):
            default_config.weights["normalized_gpa"] = 0.5

    def test_applicant_initialization(self):
        """FR1: Test basic applicant creation and default initial values."""
        applicant = Applicant(
            applicant_id=99, gpa=3.5, gpa_scale=4.0, test_score=1300,
            test_score_max=1600, extracurricular_score=8, essay_score=8,
            first_generation_student=False, underrepresented_group=False,
            in_state_resident=True
        )
        assert applicant.applicant_id == 99
        assert applicant.gpa == 3.5
        assert applicant.in_state_resident is True
        assert applicant.holistic_score is None
        assert applicant.decision is None

    def test_applicant_repr(self, average_applicant):
        """FR1: Test the __repr__ method for unprocessed and processed applicants."""
        # Unprocessed
        expected_unprocessed = (
            "Applicant(id=2, gpa=3.2/4.0, test_score=1200/1600, "
            "decision=None, score=N/A)"
        )
        assert repr(average_applicant) == expected_unprocessed

        # Processed
        average_applicant.holistic_score = 77.50
        average_applicant.decision = "Waitlist"
        expected_processed = (
            "Applicant(id=2, gpa=3.2/4.0, test_score=1200/1600, "
            "decision=Waitlist, score=77.50)"
        )
        assert repr(average_applicant) == expected_processed


class TestScoringAndDecisionLogic:
    """Tests for scoring helpers, score calculation, and decision logic."""

    @pytest.mark.parametrize("value, max_value, scale_to, expected", [
        (50, 100, 100.0, 50.0),      # Standard case
        (3.0, 4.0, 100.0, 75.0),     # GPA normalization
        (1200, 1600, 100.0, 75.0),   # Test score normalization
        (0, 100, 100.0, 0.0),        # Boundary: zero value
        (100, 100, 100.0, 100.0),    # Boundary: max value
        (50, 0, 100.0, 0.0),         # Edge case: zero max_value to prevent division error
    ])
    def test_normalize(self, value, max_value, scale_to, expected):
        """FR2: Test the _normalize helper function with various inputs."""
        assert math.isclose(_normalize(value, max_value, scale_to), expected)

    def test_calculate_holistic_score_average(self, average_applicant, default_config):
        """FR2: Test score calculation for a standard applicant with no bonuses."""
        # Manual calculation:
        # norm_gpa = (3.2 / 4.0) * 100 = 80
        # norm_test = (1200 / 1600) * 100 = 75
        # norm_extra = 7 * 10 = 70
        # norm_essay = 7 * 10 = 70
        # base_score = (80 * 0.4) + (75 * 0.25) + (70 * 0.15) + (70 * 0.2)
        #            = 32 + 18.75 + 10.5 + 14 = 75.25
        # bonus = 0
        # final_score = 75.25
        expected_score = 75.25
        score = calculate_holistic_score(average_applicant, default_config)
        assert math.isclose(score, expected_score)

    def test_calculate_holistic_score_with_all_bonuses(self, default_config):
        """FR2: Test that all bonuses are correctly applied."""
        applicant = Applicant(
            applicant_id=4, gpa=3.2, gpa_scale=4.0, test_score=1200,
            test_score_max=1600, extracurricular_score=7, essay_score=7,
            first_generation_student=True, underrepresented_group=True,
            in_state_resident=True
        )
        base_score = 75.25
        total_bonus = 2.5 + 2.5 + 1.5
        expected_score = base_score + total_bonus
        score = calculate_holistic_score(applicant, default_config)
        assert math.isclose(score, expected_score)

    def test_calculate_holistic_score_is_capped_at_100(self, perfect_applicant, default_config):
        """FR2: Test that the final score cannot exceed 100."""
        # Base score is 100. With bonuses (2.5+2.5+1.5=6.5), it would be 106.5.
        # It should be capped at 100.0.
        score = calculate_holistic_score(perfect_applicant, default_config)
        assert math.isclose(score, 100.0)

    @pytest.mark.parametrize("score, expected_decision", [
        (95.0, "Admit"),
        (80.0, "Admit"),      # Boundary: exactly admit threshold
        (79.9, "Waitlist"),   # Boundary: just below admit
        (75.0, "Waitlist"),
        (70.0, "Waitlist"),   # Boundary: exactly waitlist threshold
        (69.9, "Reject"),     # Boundary: just below waitlist
        (50.0, "Reject"),
    ])
    def test_determine_decision(self, score, expected_decision, default_config):
        """FR3: Test decision logic across all thresholds."""
        decision = determine_decision(score, default_config)
        assert decision == expected_decision


class TestReportGenerator:
    """Tests for the ReportGenerator class and its helper methods."""

    def test_generate_report_with_no_applicants(self, default_config):
        """FR4: Test report generation for an empty cohort."""
        reporter = ReportGenerator([], default_config)
        report = reporter.generate()
        assert "No applicants were processed" in report

    def test_calculate_statistics_empty_cohort(self):
        """FR4: Test statistics calculation for an empty cohort."""
        stats = ReportGenerator([], default_config)._calculate_statistics()
        assert stats.total_applicants == 0
        assert stats.num_admitted == 0
        assert stats.acceptance_rate == 0.0
        assert stats.avg_gpa_admitted == 0.0

    def test_calculate_statistics_with_data(self, processed_applicant_pool):
        """FR4: Test statistics calculation for a processed cohort."""
        # Manually verify decisions in the pool based on default_config
        # app1 score: 87.75 -> Admit
        # app2 score: 78.75 -> Waitlist
        # app3 score: 66.375 -> Reject
        stats = ReportGenerator(processed_applicant_pool, default_config)._calculate_statistics()
        assert stats.total_applicants == 3
        assert stats.num_admitted == 1
        assert stats.num_waitlisted == 1
        assert stats.num_rejected == 1
        assert math.isclose(stats.acceptance_rate, (1/3) * 100)
        assert math.isclose(stats.avg_gpa_admitted, 3.8) # Only app1 admitted
        assert math.isclose(stats.avg_test_score_admitted, 1500)
        assert math.isclose(stats.avg_holistic_score_admitted, 87.75)

    def test_calculate_statistics_with_no_admits(self, default_config):
        """FR4: Test stats calculation when no applicants are admitted."""
        applicant = Applicant(
            applicant_id=201, gpa=2.0, gpa_scale=4.0, test_score=900,
            test_score_max=1600, extracurricular_score=5, essay_score=5,
            first_generation_student=False, underrepresented_group=False,
            in_state_resident=False)
        applicant.holistic_score = calculate_holistic_score(applicant, default_config)
        applicant.decision = "Reject"
        
        stats = ReportGenerator([applicant], default_config)._calculate_statistics()
        assert stats.num_admitted == 0
        assert stats.avg_gpa_admitted == 0.0
        assert stats.avg_test_score_admitted == 0.0
        assert stats.avg_holistic_score_admitted == 0.0

    def test_generate_full_report(self, processed_applicant_pool, default_config):
        """FR4, NFR2: Test end-to-end generation of a formatted report."""
        reporter = ReportGenerator(processed_applicant_pool, default_config)
        report = reporter.generate()
        
        # Check for key sections and data points
        assert "University Admissions Screening System Report" in report
        assert "--- Scoring Metrics ---" in report
        assert "Normalized Gpa: 40%" in report
        assert "First Generation Student: +2.5 points" in report
        assert "Admit: Score >= 80.0" in report
        assert "--- Cohort Statistics ---" in report
        assert "Total Applicants Processed: 3" in report
        assert "Acceptance Rate: 33.33%" in report
        assert "--- Admitted Student Profile ---" in report
        assert "Average GPA:              3.80" in report


class TestAdmissionsSystem:
    """Tests for the main AdmissionsSystem orchestrator class."""

    def test_system_initialization(self, default_config):
        """Test that the system initializes correctly."""
        system = AdmissionsSystem(config=default_config)
        assert system.config == default_config
        assert system.applicants == []

    def test_add_applicant(self, average_applicant, default_config):
        """FR1: Test adding an applicant to the system."""
        system = AdmissionsSystem(config=default_config)
        system.add_applicant(average_applicant)
        assert len(system.applicants) == 1
        assert system.applicants[0].applicant_id == 2

    def test_process_applications_empty(self, default_config, capsys):
        """Test processing with no applicants."""
        system = AdmissionsSystem(config=default_config)
        system.process_applications()
        captured = capsys.readouterr()
        assert "No applicants to process" in captured.out
        assert len(system.applicants) == 0

    def test_process_applications_populates_fields(self, average_applicant, borderline_waitlist_applicant, default_config):
        """FR2, FR3: Test that processing calculates scores and decisions."""
        system = AdmissionsSystem(config=default_config)
        system.add_applicant(average_applicant)
        system.add_applicant(borderline_waitlist_applicant)
        
        # Before processing
        assert system.applicants[0].holistic_score is None
        assert system.applicants[1].decision is None

        system.process_applications()

        # After processing
        assert system.applicants[0].holistic_score is not None
        assert system.applicants[0].decision is not None
        assert math.isclose(system.applicants[0].holistic_score, 75.25)
        assert system.applicants[0].decision == "Waitlist"
        
        assert math.isclose(system.applicants[1].holistic_score, 74.0)
        assert system.applicants[1].decision == "Waitlist"

    def test_generate_summary_report_integration(self, default_config, processed_applicant_pool):
        """FR4: Test that the system correctly integrates with the ReportGenerator."""
        system = AdmissionsSystem(config=default_config)
        system.applicants = processed_applicant_pool
        report = system.generate_summary_report()

        # Check if the report is consistent with direct ReportGenerator output
        direct_reporter = ReportGenerator(processed_applicant_pool, default_config)
        direct_report = direct_reporter.generate()
        assert report == direct_report


class TestDataGeneration:
    """Tests for the sample data generation utility."""

    def test_generate_sample_data_count(self):
        """Test if the function generates the correct number of applicants."""
        num_to_generate = 50
        applicants = generate_sample_data(num_applicants=num_to_generate)
        assert len(applicants) == num_to_generate
        assert all(isinstance(app, Applicant) for app in applicants)

    def test_generate_sample_data_values_are_in_range(self):
        """Perform a sanity check on the generated applicant data."""
        applicants = generate_sample_data(num_applicants=10)
        sample_app = applicants[0]
        
        assert 1001 <= sample_app.applicant_id <= 1010
        assert 2.5 <= sample_app.gpa <= 4.0
        assert sample_app.gpa_scale == 4.0
        assert 1000 <= sample_app.test_score <= 1600
        assert sample_app.test_score_max == 1600
        assert 3 <= sample_app.extracurricular_score <= 10
        assert 4 <= sample_app.essay_score <= 10
        assert isinstance(sample_app.first_generation_student, bool)
        assert isinstance(sample_app.underrepresented_group, bool)
        assert isinstance(sample_app.in_state_resident, bool)