# -*- coding: utf-8 -*-
"""
Self-contained Python application for a university admissions screening system.

This script implements a complete, in-memory admissions system that processes
applicant data, calculates holistic scores, makes automated decisions, and
generates a summary report without external dependencies.
"""

import random
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Literal

# --- Data Structures (FR1) ---

@dataclass
class Applicant:
    """Represents a single university applicant and their data."""
    applicant_id: int
    gpa: float
    gpa_scale: float
    test_score: int
    test_score_max: int
    extracurricular_score: int  # Scale 1-10
    essay_score: int            # Scale 1-10

    # Demographic and Geographic factors
    first_generation_student: bool
    underrepresented_group: bool
    in_state_resident: bool

    # Fields to be populated by the system
    holistic_score: Optional[float] = field(default=None, init=False)
    decision: Optional[Literal["Admit", "Waitlist", "Reject"]] = field(default=None, init=False)

    def __repr__(self) -> str:
        return (f"Applicant(id={self.applicant_id}, gpa={self.gpa}/{self.gpa_scale}, "
                f"test_score={self.test_score}/{self.test_score_max}, "
                f"decision={self.decision}, score={self.holistic_score:.2f if self.holistic_score else 'N/A'})")


class AdmissionsSystem:
    """
    Manages the entire admissions process from applicant data storage to
    decision making and reporting.
    """

    # --- Scoring Metrics and Thresholds (NFR2) ---
    # These parameters define the logic of the admissions decisions.
    # Making them class attributes ensures they are transparent and easily adjustable.

    SCORING_WEIGHTS: Dict[str, float] = {
        "normalized_gpa": 0.40,
        "normalized_test_score": 0.25,
        "extracurricular_score": 0.15,
        "essay_score": 0.20,
    }

    BONUS_POINTS: Dict[str, float] = {
        "first_generation_student": 2.5,
        "underrepresented_group": 2.5,
        "in_state_resident": 1.5,
    }

    DECISION_THRESHOLDS: Dict[str, float] = {
        "admit": 80.0,
        "waitlist": 70.0,
    }

    def __init__(self):
        """Initializes the admissions system with an empty applicant pool."""
        self.applicants: List[Applicant] = []

    def add_applicant(self, applicant: Applicant) -> None:
        """
        Adds a new applicant to the system. (Part of FR1)
        
        Args:
            applicant: An Applicant object.
        """
        self.applicants.append(applicant)

    def _normalize(self, value: float, max_value: float, scale_to: float = 100.0) -> float:
        """Helper function to normalize a value to a common scale."""
        if max_value == 0:
            return 0.0
        return (value / max_value) * scale_to

    def _calculate_holistic_score(self, applicant: Applicant) -> float:
        """
        Computes the holistic admission score for a single applicant. (FR2)

        The score is a weighted sum of normalized academic and personal factors,
        plus any applicable bonus points.

        Args:
            applicant: The applicant to score.

        Returns:
            The calculated holistic score.
        """
        # 1. Normalize core academic metrics to a 0-100 scale
        norm_gpa = self._normalize(applicant.gpa, applicant.gpa_scale)
        norm_test = self._normalize(applicant.test_score, applicant.test_score_max)
        
        # Extracurriculars and essays are on a 1-10 scale; normalize to 0-100
        norm_extra = applicant.extracurricular_score * 10
        norm_essay = applicant.essay_score * 10

        # 2. Calculate the base weighted score
        base_score = (
            norm_gpa * self.SCORING_WEIGHTS["normalized_gpa"] +
            norm_test * self.SCORING_WEIGHTS["normalized_test_score"] +
            norm_extra * self.SCORING_WEIGHTS["extracurricular_score"] +
            norm_essay * self.SCORING_WEIGHTS["essay_score"]
        )

        # 3. Add bonus points for demographic/geographic factors
        bonus = 0.0
        if applicant.first_generation_student:
            bonus += self.BONUS_POINTS["first_generation_student"]
        if applicant.underrepresented_group:
            bonus += self.BONUS_POINTS["underrepresented_group"]
        if applicant.in_state_resident:
            bonus += self.BONUS_POINTS["in_state_resident"]
            
        # 4. Final score is the sum, capped at 100
        final_score = min(100.0, base_score + bonus)
        
        return final_score

    def process_applications(self) -> None:
        """
        Processes all applicants in the system: calculates scores and makes decisions.
        (FR2 & FR3)
        """
        if not self.applicants:
            print("No applicants to process.")
            return

        for applicant in self.applicants:
            # Calculate and assign score
            applicant.holistic_score = self._calculate_holistic_score(applicant)

            # Assign decision based on thresholds
            if applicant.holistic_score >= self.DECISION_THRESHOLDS["admit"]:
                applicant.decision = "Admit"
            elif applicant.holistic_score >= self.DECISION_THRESHOLDS["waitlist"]:
                applicant.decision = "Waitlist"
            else:
                applicant.decision = "Reject"
    
    def generate_summary_report(self) -> str:
        """
        Generates a comprehensive summary report of the admissions cohort. (FR4)

        The report includes transparent scoring metrics (NFR2) and cohort statistics.

        Returns:
            A formatted string containing the full report.
        """
        total_applicants = len(self.applicants)
        if total_applicants == 0:
            return "Admissions Summary Report\n-------------------------\nNo applicants were processed."

        admitted = [app for app in self.applicants if app.decision == "Admit"]
        waitlisted = [app for app in self.applicants if app.decision == "Waitlist"]
        rejected = [app for app in self.applicants if app.decision == "Reject"]
        
        num_admitted = len(admitted)
        acceptance_rate = (num_admitted / total_applicants * 100) if total_applicants > 0 else 0

        # Calculate stats for the admitted cohort
        if num_admitted > 0:
            avg_gpa_admitted = sum(app.gpa for app in admitted) / num_admitted
            avg_test_score_admitted = sum(app.test_score for app in admitted) / num_admitted
            avg_holistic_score_admitted = sum(app.holistic_score for app in admitted) / num_admitted
        else:
            avg_gpa_admitted = 0.0
            avg_test_score_admitted = 0
            avg_holistic_score_admitted = 0.0

        # --- Report Generation ---
        report = []
        report.append("="*50)
        report.append("      University Admissions Screening System Report")
        report.append("="*50)
        
        # NFR2: Transparent Scoring Metrics
        report.append("\n--- Scoring Metrics ---")
        report.append("Component Weights:")
        for key, val in self.SCORING_WEIGHTS.items():
            report.append(f"  - {key.replace('_', ' ').title()}: {val:.0%}")
        report.append("\nBonus Points:")
        for key, val in self.BONUS_POINTS.items():
            report.append(f"  - {key.replace('_', ' ').title()}: +{val:.1f} points")
        report.append("\nDecision Thresholds:")
        report.append(f"  - Admit: Score >= {self.DECISION_THRESHOLDS['admit']:.1f}")
        report.append(f"  - Waitlist: Score >= {self.DECISION_THRESHOLDS['waitlist']:.1f}")
        report.append(f"  - Reject: Score < {self.DECISION_THRESHOLDS['waitlist']:.1f}")
        
        # FR4: Cohort Statistics
        report.append("\n--- Cohort Statistics ---")
        report.append(f"Total Applicants Processed: {total_applicants}")
        report.append("-" * 25)
        report.append(f"Admitted:   {num_admitted:>5}")
        report.append(f"Waitlisted: {len(waitlisted):>5}")
        report.append(f"Rejected:   {len(rejected):>5}")
        report.append("-" * 25)
        report.append(f"Acceptance Rate: {acceptance_rate:.2f}%")
        
        report.append("\n--- Admitted Student Profile ---")
        if num_admitted > 0:
            report.append(f"Average GPA:              {avg_gpa_admitted:.2f}")
            report.append(f"Average Test Score:       {avg_test_score_admitted:.0f}")
            report.append(f"Average Holistic Score:   {avg_holistic_score_admitted:.2f}")
        else:
            report.append("No students were admitted.")

        report.append("\n="*50)
        
        return "\n".join(report)

def generate_sample_data(num_applicants: int) -> List[Applicant]:
    """Creates a list of randomized applicant data for demonstration."""
    applicants = []
    for i in range(1, num_applicants + 1):
        applicant = Applicant(
            applicant_id=1000 + i,
            gpa=round(random.uniform(2.5, 4.0), 2),
            gpa_scale=4.0,
            test_score=random.randint(1000, 1600),
            test_score_max=1600,
            extracurricular_score=random.randint(3, 10),
            essay_score=random.randint(4, 10),
            first_generation_student=random.choice([True, False]),
            underrepresented_group=random.choice([True, False]),
            in_state_resident=random.choice([True, True, False]) # Skew towards in-state
        )
        applicants.append(applicant)
    return applicants


def main():
    """Main function to execute the admissions system simulation."""
    
    # NFR1: Application is self-contained. No external DBs or services needed.
    # We instantiate the system and create sample data in memory.
    
    print("Initializing University Admissions Screening System...")
    admissions_system = AdmissionsSystem()

    # FR1: Store applicant data
    print("Generating and loading applicant data...")
    sample_applicants = generate_sample_data(250)
    for app in sample_applicants:
        admissions_system.add_applicant(app)
    print(f"{len(admissions_system.applicants)} applicants loaded.")

    # FR2 & FR3: Compute scores and automate decisions
    print("Processing applications...")
    admissions_system.process_applications()
    print("Processing complete.")

    # FR4 & NFR2: Generate a summary report with transparent metrics
    print("\nGenerating final admissions report...")
    report = admissions_system.generate_summary_report()
    
    print(report)

    # Optional: Display a few individual results for verification
    print("\n--- Sample of Individual Results ---")
    for i in range(min(5, len(admissions_system.applicants))):
        print(admissions_system.applicants[i])


if __name__ == "__main__":
    main()