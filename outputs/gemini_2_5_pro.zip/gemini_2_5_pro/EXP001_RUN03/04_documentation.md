# Technical Documentation: University Admissions Screening System

## 1. Introduction

This document provides detailed technical documentation for the University Admissions Screening System. The system is a self-contained Python application designed to process university applications, calculate a holistic admission score, automate decisions, and generate a summary report.

The documentation covers the system's architecture, data structures, core functions, and classes, providing explanations for their purpose, parameters, and return values.

### 1.1. System Overview

The application is structured into several modular components:
-   **Configuration (`ScoringConfiguration`)**: Decouples scoring rules from the main logic.
-   **Core Data Structures (`Applicant`)**: Defines the schema for applicant data.
-   **Scoring and Decision Logic**: Contains functions for calculating scores and determining outcomes.
-   **Reporting (`ReportGenerator`, `CohortStatistics`)**: Handles the analysis and presentation of results.
-   **System Orchestrator (`AdmissionsSystem`)**: Manages the end-to-end workflow.
-   **Execution Block**: Provides a sample data generator and a `main` function to run a simulation.

---

## 2. Configuration Module

This module centralizes all numerical parameters used for scoring and decision-making, fulfilling NFR2 by making scoring metrics transparent.

### `ScoringConfiguration`

A frozen (immutable) dataclass that holds all weights, bonuses, and thresholds for the admissions process.

**Attributes:**

-   `weights` (`Dict[str, float]`): A dictionary mapping score components to their percentage weight in the final calculation.
    -   *Keys*: `"normalized_gpa"`, `"normalized_test_score"`, `"extracurricular_score"`, `"essay_score"`.
    -   *Values*: Floating-point numbers that should sum to `1.0`.
-   `bonus_points` (`Dict[str, float]`): A dictionary mapping demographic or geographic factors to a flat point bonus.
    -   *Keys*: `"first_generation_student"`, `"underrepresented_group"`, `"in_state_resident"`.
    -   *Values*: The number of points to add to the holistic score.
-   `decision_thresholds` (`Dict[str, float]`): A dictionary mapping admission decisions to the minimum score required.
    -   *Keys*: `"admit"`, `"waitlist"`.
    -   *Values*: The score threshold.

---

## 3. Core Data Structures

This module defines the primary data structure for storing applicant information, fulfilling FR1.

### `Applicant`

A dataclass representing a single university applicant and their associated data.

**Attributes:**

-   `applicant_id` (`int`): A unique identifier for the applicant.
-   `gpa` (`float`): The applicant's Grade Point Average.
-   `gpa_scale` (`float`): The maximum possible GPA on the applicant's scale (e.g., 4.0 or 5.0).
-   `test_score` (`int`): The applicant's standardized test score (e.g., SAT or ACT).
-   `test_score_max` (`int`): The maximum possible score for the test.
-   `extracurricular_score` (`int`): A score from 1-10 representing the strength of extracurricular activities.
-   `essay_score` (`int`): A score from 1-10 representing the quality of the admissions essay.
-   `first_generation_student` (`bool`): `True` if the applicant is the first in their family to attend university.
-   `underrepresented_group` (`bool`): `True` if the applicant belongs to an underrepresented demographic group.
-   `in_state_resident` (`bool`): `True` if the applicant is a resident of the same state as the university.
-   `holistic_score` (`Optional[float]`): The calculated holistic score. Initialized to `None` and populated by the system.
-   `decision` (`Optional[Literal["Admit", "Waitlist", "Reject"]]`): The final admission decision. Initialized to `None` and populated by the system.

---

## 4. Scoring and Decision Logic

This module contains the core business logic for evaluating applicants, fulfilling FR2 and FR3.

### `_normalize(value: float, max_value: float, scale_to: float = 100.0) -> float`

An internal helper function to normalize a given value to a standard scale (defaulting to 100).

-   **Description:** Converts a value from its original scale (e.g., GPA on a 4.0 scale) to a common scale to allow for weighted comparisons.
-   **Parameters:**
    -   `value` (`float`): The value to normalize.
    -   `max_value` (`float`): The maximum possible value in the original scale.
    -   `scale_to` (`float`, optional): The target scale. Defaults to `100.0`.
-   **Returns:**
    -   `float`: The normalized value. Returns `0.0` if `max_value` is zero to prevent division errors.

### `calculate_holistic_score(applicant: Applicant, config: ScoringConfiguration) -> float`

Computes the holistic admission score for a single applicant based on the provided configuration.

-   **Description:** This function implements the core scoring algorithm. It normalizes academic metrics, applies weights to all core components, adds bonus points for specific attributes, and caps the final score at 100.
-   **Parameters:**
    -   `applicant` (`Applicant`): The `Applicant` object to be scored.
    -   `config` (`ScoringConfiguration`): The configuration object containing weights and bonus points.
-   **Returns:**
    -   `float`: The calculated holistic score, a value between 0.0 and 100.0.

### `determine_decision(score: float, config: ScoringConfiguration) -> Literal["Admit", "Waitlist", "Reject"]`

Determines an admission decision based on a holistic score and configured thresholds.

-   **Description:** Compares the applicant's score against the thresholds defined in the configuration object to make a final admission decision.
-   **Parameters:**
    -   `score` (`float`): The applicant's holistic score.
    -   `config` (`ScoringConfiguration`): The configuration object containing decision thresholds.
-   **Returns:**
    -   `Literal["Admit", "Waitlist", "Reject"]`: The admission decision as a string.

---

## 5. Reporting Module

This module is responsible for analyzing the entire cohort of processed applicants and generating a formatted summary report, fulfilling FR4.

### `CohortStatistics`

A dataclass that serves as a container for aggregated statistics about the applicant cohort.

**Attributes:**

-   `total_applicants` (`int`): The total number of applicants processed.
-   `num_admitted` (`int`): The number of applicants with an "Admit" decision.
-   `num_waitlisted` (`int`): The number of applicants with a "Waitlist" decision.
-   `num_rejected` (`int`): The number of applicants with a "Reject" decision.
-   `acceptance_rate` (`float`): The percentage of applicants who were admitted.
-   `avg_gpa_admitted` (`float`): The average GPA of all admitted students.
-   `avg_test_score_admitted` (`float`): The average test score of all admitted students.
-   `avg_holistic_score_admitted` (`float`): The average holistic score of all admitted students.

### `ReportGenerator`

A class that calculates cohort statistics and formats them into a human-readable report.

#### `__init__(self, applicants: List[Applicant], config: ScoringConfiguration)`

Initializes the `ReportGenerator` instance.

-   **Parameters:**
    -   `applicants` (`List[Applicant]`): A list of processed `Applicant` objects (with scores and decisions already populated).
    -   `config` (`ScoringConfiguration`): The configuration object that was used for processing, included in the report for transparency.

#### `generate(self) -> str`

Generates the full, formatted summary report string.

-   **Description:** This is the main public method of the class. It orchestrates the creation of different report sections (metrics, statistics, admitted profile) and combines them into a single string.
-   **Returns:**
    -   `str`: A multi-line string containing the complete admissions report.

---

## 6. Main System Orchestrator

This module contains the main class that drives the entire admissions process.

### `AdmissionsSystem`

A class that manages the lifecycle of the admissions process, from loading applicants to generating the final report.

#### `__init__(self, config: ScoringConfiguration)`

Initializes the `AdmissionsSystem`.

-   **Parameters:**
    -   `config` (`ScoringConfiguration`): A configuration object containing all scoring and decision rules for the session.

#### `add_applicant(self, applicant: Applicant) -> None`

Adds a new applicant to the system's internal list.

-   **Parameters:**
    -   `applicant` (`Applicant`): The `Applicant` object to add.
-   **Returns:**
    -   `None`.

#### `process_applications(self) -> None`

Iterates through all loaded applicants, calculates their holistic scores, and determines their admission decisions.

-   **Description:** This method is the core processing step. It modifies the `Applicant` objects in place, populating their `holistic_score` and `decision` attributes.
-   **Returns:**
    -   `None`.

#### `generate_summary_report(self) -> str`

Generates a comprehensive summary report of the admissions cohort.

-   **Description:** This method instantiates a `ReportGenerator` with the system's processed applicant data and configuration, then returns the generated report.
-   **Returns:**
    -   `str`: A formatted string containing the full report.

---

## 7. Data Generation and Main Execution

This section contains utility functions for demonstration and the main script entry point.

### `generate_sample_data(num_applicants: int) -> List[Applicant]`

A factory function to create a list of randomized `Applicant` objects for testing and demonstration purposes.

-   **Parameters:**
    -   `num_applicants` (`int`): The number of sample `Applicant` objects to create.
-   **Returns:**
    -   `List[Applicant]`: A list of newly created `Applicant` objects with randomized data.

### `main() -> None`

The main function that serves as the entry point for the application.

-   **Description:** This function orchestrates a complete simulation of the admissions process:
    1.  Defines a `ScoringConfiguration`.
    2.  Initializes the `AdmissionsSystem`.
    3.  Generates and loads sample applicant data.
    4.  Processes all applications.
    5.  Generates and prints the final summary report.
    6.  Prints a small sample of individual results for verification.
-   **Returns:**
    -   `None`.