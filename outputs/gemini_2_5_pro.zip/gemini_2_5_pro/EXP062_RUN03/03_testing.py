# -*- coding: utf-8 -*-
"""
Comprehensive Unit Test Suite for the Corporate Hiring System.

This suite uses the pytest framework to validate the functionality of the
refactored corporate hiring system. It covers the following key areas:

1.  **Core Logic (`calculate_score`)**: Tests scoring mechanics, including
    education, experience, location bonuses, and the critical low-experience
    penalty, across various boundary conditions.
2.  **Decision Logic (`make_decisions`)**: Validates the automated decision-making
    process for various pipeline sizes and percentile configurations.
3.  **Pipeline Orchestration (`HiringPipeline`)**: Ensures the end-to-end
    process of scoring, ranking, and deciding works cohesively.
4.  **Reporting (`generate_report`)**: Verifies the correctness of the
    output report and its summary metrics using stdout capturing.
5.  **Data Models**: Confirms the immutability and basic behavior of data
    structures.

The tests are structured using fixtures for reusability and parametrize for
concise and thorough case coverage.
"""
import pytest
from typing import List, Dict

# Import the classes and functions from the refactored code
# In a real project structure, this would be:
# from your_module import (
#     HiringConfiguration, EducationLevel, Applicant, ProcessedApplicant,
#     calculate_score, make_decisions, HiringPipeline, generate_report
# )
# For this self-contained example, we'll assume the code is in a file
# named `hiring_system.py` and is importable.
from hiring_system import (
    HiringConfiguration,
    EducationLevel,
    Applicant,
    ProcessedApplicant,
    calculate_score,
    make_decisions,
    HiringPipeline,
    generate_report,
)

# =============================================================================
# SECTION 1: FIXTURES - Reusable Test Data and Objects
# =============================================================================

@pytest.fixture(scope="module")
def default_config() -> HiringConfiguration:
    """Provides a standard HiringConfiguration instance for tests."""
    return HiringConfiguration()

@pytest.fixture
def sample_applicant_phd_high_exp_pref_loc() -> Applicant:
    """An ideal applicant: PhD, 10 years experience, preferred location."""
    return Applicant(
        applicant_id=1,
        name="Dr. Ada Lovelace",
        location="New York, NY",
        education=EducationLevel.PHD,
        years_experience=10,
        demographics={},
    )

@pytest.fixture
def sample_applicant_bach_low_exp_no_bonus() -> Applicant:
    """An applicant with low experience who should receive a penalty."""
    return Applicant(
        applicant_id=2,
        name="John Doe",
        location="Chicago, IL",
        education=EducationLevel.BACHELORS,
        years_experience=4,
        demographics={},
    )

@pytest.fixture
def sample_applicant_at_experience_threshold() -> Applicant:
    """An applicant exactly at the experience threshold (should NOT be penalized)."""
    return Applicant(
        applicant_id=3,
        name="Jane Smith",
        location="Austin, TX",
        education=EducationLevel.MASTERS,
        years_experience=5,
        demographics={},
    )

@pytest.fixture
def sample_applicant_zero_experience() -> Applicant:
    """An applicant with zero experience."""
    return Applicant(
        applicant_id=4,
        name="New Grad",
        location="San Francisco, CA",
        education=EducationLevel.BACHELORS,
        years_experience=0,
        demographics={},
    )


# =============================================================================
# SECTION 2: UNIT TESTS FOR CORE SCORING LOGIC
# =============================================================================

class TestCalculateScore:
    """Tests the calculate_score function."""

    def test_ideal_candidate_score(
        self,
        default_config: HiringConfiguration,
        sample_applicant_phd_high_exp_pref_loc: Applicant,
    ):
        """
        FR2: Test a candidate who qualifies for all score components.
        - PhD: 35
        - 10 years experience: 10 * 3 = 30
        - Preferred location: 10
        - Total: 35 + 30 + 10 = 75
        """
        score = calculate_score(sample_applicant_phd_high_exp_pref_loc, default_config)
        assert score == 75.0

    @pytest.mark.parametrize(
        "education_level, expected_base_score",
        [
            (EducationLevel.PHD, 35),
            (EducationLevel.MASTERS, 25),
            (EducationLevel.BACHELORS, 15),
            (EducationLevel.ASSOCIATES, 5),
            (EducationLevel.HIGH_SCHOOL, 0),
        ],
    )
    def test_education_scores(
        self,
        default_config: HiringConfiguration,
        education_level: EducationLevel,
        expected_base_score: int,
    ):
        """FR2: Test that each education level is scored correctly."""
        applicant = Applicant(
            100, "Edu Test", "Anytown, USA", education_level, 5, {}
        )
        # Score = Edu Score + 5*3 (exp) = Edu Score + 15
        expected_score = expected_base_score + 15
        assert calculate_score(applicant, default_config) == expected_score

    def test_location_bonus(self, default_config: HiringConfiguration):
        """FR2: Test that location bonus is applied correctly."""
        applicant_pref = Applicant(
            101, "Pref Loc", "San Francisco, CA", EducationLevel.BACHELORS, 10, {}
        )
        applicant_non_pref = Applicant(
            102, "Non-Pref Loc", "Boston, MA", EducationLevel.BACHELORS, 10, {}
        )

        score_pref = calculate_score(applicant_pref, default_config)
        score_non_pref = calculate_score(applicant_non_pref, default_config)

        assert score_pref == score_non_pref + default_config.LOCATION_BONUS_SCORE
        # Calculation: 15 (Bach) + 30 (Exp) + 10 (Loc) = 55
        assert score_pref == 55.0

    def test_low_experience_penalty_applied(
        self,
        default_config: HiringConfiguration,
        sample_applicant_bach_low_exp_no_bonus: Applicant,
    ):
        """FR5: Test that the penalty is applied for < 5 years experience."""
        # Base score = 15 (Bach) + 4 * 3 (exp) = 27
        # Penalized score = 27 * 0.3 = 8.1
        score = calculate_score(sample_applicant_bach_low_exp_no_bonus, default_config)
        assert score == 8.1

    def test_low_experience_penalty_not_applied_at_threshold(
        self,
        default_config: HiringConfiguration,
        sample_applicant_at_experience_threshold: Applicant,
    ):
        """FR5: Test that the penalty is NOT applied at exactly 5 years."""
        # Score = 25 (Masters) + 5 * 3 (exp) = 40
        score = calculate_score(
            sample_applicant_at_experience_threshold, default_config
        )
        assert score == 40.0

    def test_score_for_zero_experience(
        self,
        default_config: HiringConfiguration,
        sample_applicant_zero_experience: Applicant,
    ):
        """
        FR5: Edge Case: Test a candidate with zero experience.
        - Base score = 15 (Bach) + 0 * 3 (exp) + 10 (Loc) = 25
        - Penalized score = 25 * 0.3 = 7.5
        """
        score = calculate_score(sample_applicant_zero_experience, default_config)
        assert score == 7.5

    def test_score_rounding(self, default_config: HiringConfiguration):
        """Test if the score is correctly rounded to 2 decimal places."""
        # Create a scenario resulting in a long float
        # Base score = 0 (HS) + 1 * 3 (exp) = 3
        # Penalized score = 3 * 0.3 = 0.9. This is already rounded.
        # Let's create a custom config to force rounding.
        custom_config = HiringConfiguration(LOW_EXPERIENCE_PENALTY_MULTIPLIER=0.33333)
        applicant = Applicant(
            103, "Rounding Test", "Anytown, USA", EducationLevel.HIGH_SCHOOL, 1, {}
        )
        base_score = 1 * custom_config.POINTS_PER_YEAR_OF_EXPERIENCE  # 3
        expected_score = round(base_score * 0.33333, 2)  # round(0.99999, 2) = 1.0
        
        score = calculate_score(applicant, custom_config)
        assert score == 1.0


# =============================================================================
# SECTION 3: UNIT TESTS FOR DECISION LOGIC
# =============================================================================

class TestMakeDecisions:
    """Tests the make_decisions function."""

    def _create_processed_applicants(self, scores: List[float]) -> List[ProcessedApplicant]:
        """Helper to create a list of ProcessedApplicant objects for testing."""
        applicants = []
        for i, score in enumerate(scores):
            applicant_data = Applicant(i, f"Applicant {i}", "Location", EducationLevel.BACHELORS, 5, {})
            applicants.append(ProcessedApplicant(applicant=applicant_data, score=score))
        return applicants

    def test_empty_applicant_list(self, default_config: HiringConfiguration):
        """Test that the function handles an empty list gracefully."""
        applicants: List[ProcessedApplicant] = []
        make_decisions(applicants, default_config)
        assert not applicants # The list should remain empty

    def test_standard_case_25_percent(self, default_config: HiringConfiguration):
        """FR4: With 8 applicants, top 25% (2) should be interviewed."""
        scores = [100, 90, 80, 70, 60, 50, 40, 30]
        applicants = self._create_processed_applicants(scores)
        
        make_decisions(applicants, default_config)

        decisions = [app.decision for app in applicants]
        assert decisions == ["Interview", "Interview", "Reject", "Reject", "Reject", "Reject", "Reject", "Reject"]

    def test_small_list_interviews_at_least_one(self, default_config: HiringConfiguration):
        """FR4: For small lists (<4), at least one person is interviewed."""
        scores = [100, 90, 80]
        applicants = self._create_processed_applicants(scores)
        
        make_decisions(applicants, default_config)

        # int(3 * 0.25) = 0, but max(1, 0) = 1. So, one is interviewed.
        decisions = [app.decision for app in applicants]
        assert decisions == ["Interview", "Reject", "Reject"]

    def test_single_applicant_is_interviewed(self, default_config: HiringConfiguration):
        """FR4: Edge Case: A single applicant should always be interviewed."""
        applicants = self._create_processed_applicants([100])
        make_decisions(applicants, default_config)
        assert applicants[0].decision == "Interview"

    def test_all_interviewed_with_100_percentile(self):
        """Test with a custom config to interview everyone."""
        config = HiringConfiguration(INTERVIEW_TOP_PERCENTILE=1.0)
        scores = [100, 90, 80, 70]
        applicants = self._create_processed_applicants(scores)

        make_decisions(applicants, config)

        decisions = [app.decision for app in applicants]
        assert all(d == "Interview" for d in decisions)
    
    def test_tie_at_cutoff_boundary(self, default_config: HiringConfiguration):
        """
        FR3/FR4: Test behavior with a tie at the decision cutoff.
        With 4 applicants and 25%, 1 gets interviewed. The sort stability
        means the first one in the list with the score of 80 should get it.
        """
        scores = [90, 80, 80, 70]
        applicants = self._create_processed_applicants(scores)

        make_decisions(applicants, default_config)

        decisions = [app.decision for app in applicants]
        assert decisions == ["Interview", "Reject", "Reject", "Reject"]
        assert sum(1 for d in decisions if d == "Interview") == 1


# =============================================================================
# SECTION 4: INTEGRATION TESTS FOR THE HIRING PIPELINE
# =============================================================================

class TestHiringPipeline:
    """Tests the HiringPipeline class orchestration."""

    def test_process_with_empty_list(self, default_config: HiringConfiguration):
        """NFR1: Test pipeline with no applicants."""
        pipeline = HiringPipeline([], default_config)
        pipeline.process()
        assert not pipeline.processed_applicants

    def test_full_pipeline_process(self, default_config: HiringConfiguration):
        """
        FR1-4: Test the full end-to-end process with a sample list.
        Checks scoring, ranking, and decisions together.
        """
        applicants = [
            Applicant(1, "High Score", "New York, NY", EducationLevel.PHD, 10, {}), # Score: 75
            Applicant(2, "Mid Score", "Boston, MA", EducationLevel.MASTERS, 8, {}),  # Score: 49
            Applicant(3, "Low Score", "Chicago, IL", EducationLevel.BACHELORS, 4, {}), # Score: 8.1 (penalized)
            Applicant(4, "High Mid", "San Francisco, CA", EducationLevel.MASTERS, 7, {}) # Score: 56
        ]
        
        pipeline = HiringPipeline(applicants, default_config)
        pipeline.process()

        # Check total processed
        assert len(pipeline.processed_applicants) == 4

        # Check scores
        scores = {p.applicant.applicant_id: p.score for p in pipeline.processed_applicants}
        assert scores[1] == 75.0
        assert scores[2] == 49.0
        assert scores[3] == 8.1
        assert scores[4] == 56.0

        # FR3: Check ranking (descending score)
        processed_ids_ranked = [p.applicant.applicant_id for p in pipeline.processed_applicants]
        assert processed_ids_ranked == [1, 4, 2, 3]

        # FR4: Check decisions (4 applicants, 25% -> 1 interview)
        decisions = [p.decision for p in pipeline.processed_applicants]
        assert decisions == ["Interview", "Reject", "Reject", "Reject"]


# =============================================================================
# SECTION 5: TESTS FOR REPORTING
# =============================================================================

class TestGenerateReport:
    """Tests the generate_report function using pytest's capsys fixture."""

    def test_report_with_no_data(self, capsys):
        """NFR2: Test report generation for an empty pipeline."""
        generate_report([])
        captured = capsys.readouterr()
        assert "CORPORATE HIRING SYSTEM - PIPELINE REPORT" in captured.out
        assert "No data available. Please run the pipeline first." in captured.out

    def test_report_with_data_and_metrics(self, capsys):
        """NFR2: Test report generation with processed data and verify metrics."""
        processed_applicants = [
            ProcessedApplicant(Applicant(101, "Alice", "NY", EducationLevel.MASTERS, 8, {}), 60.0, "Interview"),
            ProcessedApplicant(Applicant(102, "Bob", "IL", EducationLevel.BACHELORS, 10, {}), 45.0, "Interview"),
            ProcessedApplicant(Applicant(103, "Charlie", "CA", EducationLevel.PHD, 6, {}), 53.0, "Interview"),
            ProcessedApplicant(Applicant(104, "Diana", "NY", EducationLevel.BACHELORS, 4, {}), 8.1, "Reject"),
        ]
        # Manually sort for the test
        processed_applicants.sort(key=lambda p: p.score, reverse=True)
        # Expected order: Alice (60), Charlie (53), Bob (45), Diana (8.1)
        # Assuming 3 interviews for this test case
        processed_applicants[0].decision = "Interview"
        processed_applicants[1].decision = "Interview"
        processed_applicants[2].decision = "Interview"
        processed_applicants[3].decision = "Reject"

        generate_report(processed_applicants)
        captured = capsys.readouterr()
        output = captured.out

        # Check for headers and structure
        assert "Candidate Rankings & Decisions" in output
        assert "Pipeline Summary Metrics" in output

        # Check for applicant data in the report
        assert "Alice" in output
        assert "60.00" in output
        assert "Bob" in output
        assert "45.00" in output
        assert "Reject" in output
        
        # Check summary metrics calculations
        assert "Total Applicants Processed: 4" in output
        assert "Candidates Selected for Interview: 3" in output
        assert "Candidates Rejected: 1" in output
        # 3/4 = 75%
        assert "Pipeline Acceptance Rate: 75.00%" in output
        # Avg All = (60 + 53 + 45 + 8.1) / 4 = 166.1 / 4 = 41.525
        assert "Average Score (All Applicants): 41.53" in output
        # Avg Interviewed = (60 + 53 + 45) / 3 = 158 / 3 = 52.666...
        assert "Average Score (Interviewed Candidates): 52.67" in output

    def test_report_metrics_with_no_interviews(self, capsys):
        """
        NFR2: Edge Case: Test report when no one is interviewed.
        Note: The current `make_decisions` logic makes this impossible unless
        the applicant pool is empty. We simulate it for robustness.
        """
        processed_applicants = [
            ProcessedApplicant(Applicant(104, "Diana", "NY", EducationLevel.BACHELORS, 4, {}), 8.1, "Reject"),
            ProcessedApplicant(Applicant(108, "Hannah", "IL", EducationLevel.ASSOCIATES, 2, {}), 3.3, "Reject"),
        ]
        
        generate_report(processed_applicants)
        captured = capsys.readouterr()
        output = captured.out

        assert "Total Applicants Processed: 2" in output
        assert "Candidates Selected for Interview: 0" in output
        assert "Candidates Rejected: 2" in output
        assert "Pipeline Acceptance Rate: 0.00%" in output
        # Check for correct handling of division by zero for avg interviewed score
        assert "Average Score (Interviewed Candidates): 0.00" in output


# =============================================================================
# SECTION 6: TESTS FOR DATA MODELS
# =============================================================================

class TestDataModels:
    """Tests the data models for correctness and constraints."""
    
    def test_applicant_is_immutable(self, sample_applicant_phd_high_exp_pref_loc: Applicant):
        """FR1: Applicant data should be immutable to prevent accidental changes."""
        with pytest.raises(AttributeError):
            # dataclasses.FrozenInstanceError is a subclass of AttributeError
            sample_applicant_phd_high_exp_pref_loc.name = "New Name"

    def test_processed_applicant_is_mutable(self, sample_applicant_phd_high_exp_pref_loc: Applicant):
        """The ProcessedApplicant needs to be mutable to track state."""
        processed = ProcessedApplicant(applicant=sample_applicant_phd_high_exp_pref_loc, score=75.0)
        try:
            processed.decision = "Interview"
            processed.score = 76.0
        except AttributeError:
            pytest.fail("ProcessedApplicant should be mutable but raised an AttributeError.")
        
        assert processed.decision == "Interview"
        assert processed.score == 76.0