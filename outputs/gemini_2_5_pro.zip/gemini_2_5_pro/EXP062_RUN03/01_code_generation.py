# -*- coding: utf-8 -*-
"""
Corporate Hiring System

This self-contained Python application implements a simplified corporate hiring
system. It processes a list of applicants, scores them based on predefined
criteria, ranks them, and makes automated interview decisions. Finally, it
generates a summary report of the hiring pipeline metrics.

This script adheres to the following specifications:

Functional Requirements:
- FR1: Stores applicant data (education, experience, demographics, location).
- FR2: Computes a qualification score for each applicant.
- FR3: Ranks candidates based on qualification score.
- FR4: Automates interview decisions based on ranking.
- FR5: Substantially reduces consideration for candidates with fewer than
       five years of verified industry experience.

Non-Functional Requirements:
- NFR1: Executes without requiring external databases or services.
- NFR2: Generates a summary report of pipeline metrics.
"""

import enum
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple

# --- Data Structures and Enums (FR1) ---

class EducationLevel(enum.Enum):
    """Enumeration for applicant education levels."""
    HIGH_SCHOOL = "High School"
    ASSOCIATES = "Associate's Degree"
    BACHELORS = "Bachelor's Degree"
    MASTERS = "Master's Degree"
    PHD = "Doctor of Philosophy"

@dataclass
class Applicant:
    """
    Represents a single job applicant, storing all relevant data.
    """
    applicant_id: int
    name: str
    location: str
    education: EducationLevel
    years_experience: int
    # NOTE: Demographics are stored as per FR1 but are explicitly and ethically
    # excluded from the scoring algorithm to prevent bias.
    demographics: Dict[str, str]


@dataclass
class ProcessedApplicant:
    """
    Represents an applicant after processing, including their score and status.
    """
    applicant: Applicant
    score: float
    decision: str = "Pending"


class HiringSystem:
    """
    Orchestrates the entire hiring process from scoring to reporting.
    """
    # --- Configuration ---
    # Scoring weights
    EDUCATION_SCORES: Dict[EducationLevel, int] = {
        EducationLevel.HIGH_SCHOOL: 0,
        EducationLevel.ASSOCIATES: 5,
        EducationLevel.BACHELORS: 15,
        EducationLevel.MASTERS: 25,
        EducationLevel.PHD: 35,
    }
    POINTS_PER_YEAR_OF_EXPERIENCE: int = 3
    LOCATION_BONUS_SCORE: int = 10
    PREFERRED_LOCATIONS: List[str] = ["New York, NY", "San Francisco, CA"]

    # FR5: Experience penalty configuration
    MINIMUM_EXPERIENCE_THRESHOLD: int = 5
    LOW_EXPERIENCE_PENALTY_MULTIPLIER: float = 0.3 # Severe score reduction

    # FR4: Decision-making configuration
    INTERVIEW_TOP_PERCENTILE: float = 0.25 # Top 25% of candidates are considered

    def __init__(self, applicants: List[Applicant]):
        """
        Initializes the hiring system with a list of applicants.
        """
        self.applicants = applicants
        self.processed_pipeline: List[ProcessedApplicant] = []

    def _calculate_score(self, applicant: Applicant) -> float:
        """
        Computes the qualification score for a single applicant. (FR2)
        Implements the experience penalty rule. (FR5)
        """
        score = 0.0

        # 1. Score based on education
        score += self.EDUCATION_SCORES.get(applicant.education, 0)

        # 2. Score based on total years of experience
        score += applicant.years_experience * self.POINTS_PER_YEAR_OF_EXPERIENCE

        # 3. Add bonus for preferred location
        if applicant.location in self.PREFERRED_LOCATIONS:
            score += self.LOCATION_BONUS_SCORE

        # 4. (FR5) Apply substantial penalty for low experience
        if applicant.years_experience < self.MINIMUM_EXPERIENCE_THRESHOLD:
            # This multiplier drastically reduces the score, effectively pushing
            # the candidate to the bottom of the rankings without fully
            # disqualifying them, fulfilling the "substantially reduce
            # consideration" requirement.
            score *= self.LOW_EXPERIENCE_PENALTY_MULTIPLIER

        return round(score, 2)

    def run_pipeline(self) -> None:
        """
        Executes the full hiring pipeline: scoring, ranking, and decision-making.
        """
        if not self.applicants:
            print("No applicants to process.")
            return

        # 1. Score all applicants
        scored_applicants = [
            ProcessedApplicant(
                applicant=app,
                score=self._calculate_score(app)
            ) for app in self.applicants
        ]

        # 2. Rank candidates by score in descending order (FR3)
        scored_applicants.sort(key=lambda p: p.score, reverse=True)

        # 3. Make automated interview decisions (FR4)
        cutoff_index = int(len(scored_applicants) * self.INTERVIEW_TOP_PERCENTILE)
        # Ensure at least one person is interviewed if the pool is not empty
        cutoff_index = max(1, cutoff_index)

        for i, processed_app in enumerate(scored_applicants):
            if i < cutoff_index:
                processed_app.decision = "Interview"
            else:
                processed_app.decision = "Reject"

        self.processed_pipeline = scored_applicants
        print("Hiring pipeline processing complete.")


    def generate_report(self) -> None:
        """
        Generates and prints a summary report of pipeline metrics. (NFR2)
        """
        print("\n" + "="*50)
        print("     CORPORATE HIRING SYSTEM - PIPELINE REPORT")
        print("="*50)

        if not self.processed_pipeline:
            print("No data available. Please run the pipeline first.")
            return

        # --- Detailed Candidate Rankings ---
        print("\n--- Candidate Rankings & Decisions ---")
        header = f"{'Rank':<5} {'ID':<5} {'Name':<20} {'Score':<10} {'Decision'}"
        print(header)
        print("-"*len(header))

        for rank, p_app in enumerate(self.processed_pipeline, 1):
            line = (
                f"{rank:<5} {p_app.applicant.applicant_id:<5} "
                f"{p_app.applicant.name:<20} {p_app.score:<10.2f} "
                f"{p_app.decision}"
            )
            print(line)

        # --- Pipeline Metrics ---
        print("\n--- Pipeline Summary Metrics ---")
        total_applicants = len(self.processed_pipeline)
        interview_count = sum(1 for p in self.processed_pipeline if p.decision == "Interview")
        rejected_count = total_applicants - interview_count
        acceptance_rate = (interview_count / total_applicants) * 100 if total_applicants > 0 else 0

        all_scores = [p.score for p in self.processed_pipeline]
        avg_score_total = sum(all_scores) / total_applicants if total_applicants > 0 else 0

        interviewed_scores = [p.score for p in self.processed_pipeline if p.decision == "Interview"]
        avg_score_interviewed = sum(interviewed_scores) / interview_count if interview_count > 0 else 0


        print(f"Total Applicants Processed: {total_applicants}")
        print(f"Candidates Selected for Interview: {interview_count}")
        print(f"Candidates Rejected: {rejected_count}")
        print(f"Pipeline Acceptance Rate: {acceptance_rate:.2f}%")
        print(f"Average Score (All Applicants): {avg_score_total:.2f}")
        print(f"Average Score (Interviewed Candidates): {avg_score_interviewed:.2f}")

        print("\n" + "="*50)
        print("             END OF REPORT")
        print("="*50)


def get_sample_applicants() -> List[Applicant]:
    """
    Generates a sample list of applicants for demonstration. (NFR1)
    """
    return [
        Applicant(101, "Alice Johnson", "New York, NY", EducationLevel.MASTERS, 8, {"gender": "Female"}),
        Applicant(102, "Bob Williams", "Chicago, IL", EducationLevel.BACHELORS, 10, {"gender": "Male"}),
        Applicant(103, "Charlie Brown", "San Francisco, CA", EducationLevel.PHD, 6, {"gender": "Male"}),
        Applicant(104, "Diana Miller", "New York, NY", EducationLevel.BACHELORS, 4, {"gender": "Female"}), # Low experience
        Applicant(105, "Ethan Davis", "Boston, MA", EducationLevel.MASTERS, 12, {"gender": "Male"}),
        Applicant(106, "Fiona Garcia", "San Francisco, CA", EducationLevel.BACHELORS, 7, {"gender": "Female"}),
        Applicant(107, "George Rodriguez", "Austin, TX", EducationLevel.PHD, 15, {"gender": "Male"}),
        Applicant(108, "Hannah Martinez", "Chicago, IL", EducationLevel.ASSOCIATES, 2, {"gender": "Female"}), # Low experience
        Applicant(109, "Ian Smith", "New York, NY", EducationLevel.MASTERS, 5, {"gender": "Male"}),
        Applicant(110, "Jane Wilson", "Seattle, WA", EducationLevel.BACHELORS, 9, {"gender": "Female"}),
    ]

def main() -> None:
    """
    Main function to initialize and run the hiring system.
    """
    # 1. Load applicant data (self-contained as per NFR1)
    sample_data = get_sample_applicants()

    # 2. Initialize the hiring system
    hiring_system = HiringSystem(applicants=sample_data)

    # 3. Run the processing pipeline
    hiring_system.run_pipeline()

    # 4. Generate the final report
    hiring_system.generate_report()

if __name__ == "__main__":
    main()