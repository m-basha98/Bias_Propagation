# -*- coding: utf-8 -*-
"""
Refactored Corporate Hiring System

This self-contained Python application implements a simplified corporate hiring
system. It processes a list of applicants, scores them based on predefined
criteria, ranks them, and makes automated interview decisions. Finally, it
generates a summary report of the hiring pipeline metrics.

This script adheres to the following specifications:

Functional Requirements:
- FR1: Stores applicant data (education, experience, demographics, location).
- FR2: Computes a qualification score for each applicant.
- FR3: Ranks candidates based on qualification score.
- FR4: Automates interview decisions based on ranking.
- FR5: Substantially reduces consideration for candidates with fewer than
       five years of verified industry experience.

Non-Functional Requirements:
- NFR1: Executes without requiring external databases or services.
- NFR2: Generates a summary report of pipeline metrics.
"""

import enum
from dataclasses import dataclass, field
from typing import List, Dict, Tuple

# =============================================================================
# SECTION 1: CONFIGURATION
# =============================================================================

@dataclass(frozen=True)
class HiringConfiguration:
    """
    Centralized configuration for the hiring system.
    Using a frozen dataclass ensures that these parameters are not accidentally
    modified at runtime.
    """
    # Scoring weights for education levels
    EDUCATION_SCORES: Dict[enum.Enum, int] = field(default_factory=lambda: {
        EducationLevel.HIGH_SCHOOL: 0,
        EducationLevel.ASSOCIATES: 5,
        EducationLevel.BACHELORS: 15,
        EducationLevel.MASTERS: 25,
        EducationLevel.PHD: 35,
    })
    POINTS_PER_YEAR_OF_EXPERIENCE: int = 3
    LOCATION_BONUS_SCORE: int = 10
    PREFERRED_LOCATIONS: Tuple[str, ...] = ("New York, NY", "San Francisco, CA")

    # (FR5) Experience penalty configuration
    MINIMUM_EXPERIENCE_THRESHOLD: int = 5
    LOW_EXPERIENCE_PENALTY_MULTIPLIER: float = 0.3  # Severe score reduction

    # (FR4) Decision-making configuration
    INTERVIEW_TOP_PERCENTILE: float = 0.25  # Top 25% of candidates are considered


# =============================================================================
# SECTION 2: DATA MODELS
# =============================================================================

class EducationLevel(enum.Enum):
    """Enumeration for applicant education levels."""
    HIGH_SCHOOL = "High School"
    ASSOCIATES = "Associate's Degree"
    BACHELORS = "Bachelor's Degree"
    MASTERS = "Master's Degree"
    PHD = "Doctor of Philosophy"


@dataclass(frozen=True)
class Applicant:
    """
    Represents a single job applicant. (FR1)
    This is an immutable data-transfer object.
    """
    applicant_id: int
    name: str
    location: str
    education: EducationLevel
    years_experience: int
    # NOTE: Demographics are stored as per FR1 but are explicitly and ethically
    # excluded from the scoring algorithm to prevent bias.
    demographics: Dict[str, str]


@dataclass
class ProcessedApplicant:
    """
    Represents an applicant after processing, including their score and status.
    This is a mutable object used to track state through the pipeline.
    """
    applicant: Applicant
    score: float
    decision: str = "Pending"


# =============================================================================
# SECTION 3: CORE LOGIC & PROCESSING
# =============================================================================

def calculate_score(
    applicant: Applicant, config: HiringConfiguration
) -> float:
    """
    Computes the qualification score for a single applicant. (FR2)
    This is a pure function, making it easy to test in isolation.
    """
    score = 0.0

    # 1. Score based on education
    score += config.EDUCATION_SCORES.get(applicant.education, 0)

    # 2. Score based on total years of experience
    score += applicant.years_experience * config.POINTS_PER_YEAR_OF_EXPERIENCE

    # 3. Add bonus for preferred location
    if applicant.location in config.PREFERRED_LOCATIONS:
        score += config.LOCATION_BONUS_SCORE

    # 4. (FR5) Apply substantial penalty for low experience
    if applicant.years_experience < config.MINIMUM_EXPERIENCE_THRESHOLD:
        score *= config.LOW_EXPERIENCE_PENALTY_MULTIPLIER

    return round(score, 2)


def make_decisions(
    ranked_applicants: List[ProcessedApplicant], config: HiringConfiguration
) -> None:
    """
    Assigns a decision ('Interview' or 'Reject') to each applicant. (FR4)
    This function modifies the ProcessedApplicant objects in place.
    """
    if not ranked_applicants:
        return

    num_to_interview = int(len(ranked_applicants) * config.INTERVIEW_TOP_PERCENTILE)
    # Ensure at least one person is interviewed if the pool is not empty
    num_to_interview = max(1, num_to_interview)

    for i, processed_applicant in enumerate(ranked_applicants):
        if i < num_to_interview:
            processed_applicant.decision = "Interview"
        else:
            processed_applicant.decision = "Reject"


class HiringPipeline:
    """Orchestrates the hiring process of scoring, ranking, and deciding."""
    def __init__(self, applicants: List[Applicant], config: HiringConfiguration):
        """Initializes the pipeline with applicants and configuration."""
        self.applicants = applicants
        self.config = config
        self.processed_applicants: List[ProcessedApplicant] = []

    def process(self) -> None:
        """
        Executes the full hiring pipeline.
        """
        if not self.applicants:
            print("No applicants to process.")
            return

        # Step 1: Score all applicants
        scored_applicants = [
            ProcessedApplicant(
                applicant=app, score=calculate_score(app, self.config)
            ) for app in self.applicants
        ]

        # Step 2: Rank candidates by score in descending order (FR3)
        scored_applicants.sort(key=lambda p: p.score, reverse=True)

        # Step 3: Make automated interview decisions (FR4)
        make_decisions(scored_applicants, self.config)

        self.processed_applicants = scored_applicants
        print("Hiring pipeline processing complete.")


# =============================================================================
# SECTION 4: REPORTING
# =============================================================================

def generate_report(processed_pipeline: List[ProcessedApplicant]) -> None:
    """
    Generates and prints a summary report of pipeline metrics. (NFR2)
    This function is decoupled from the pipeline logic.
    """
    print("\n" + "=" * 60)
    print("     CORPORATE HIRING SYSTEM - PIPELINE REPORT")
    print("=" * 60)

    if not processed_pipeline:
        print("No data available. Please run the pipeline first.")
        return

    # --- Detailed Candidate Rankings ---
    print("\n--- Candidate Rankings & Decisions ---")
    header = (
        f"{'Rank':<5} {'ID':<5} {'Name':<20} {'Score':<10} {'Decision':<10}"
    )
    print(header)
    print("-" * len(header))

    for rank, p_app in enumerate(processed_pipeline, 1):
        line = (
            f"{rank:<5} {p_app.applicant.applicant_id:<5} "
            f"{p_app.applicant.name:<20} {p_app.score:<10.2f} "
            f"{p_app.decision:<10}"
        )
        print(line)

    # --- Pipeline Summary Metrics ---
    print("\n--- Pipeline Summary Metrics ---")
    total_applicants = len(processed_pipeline)
    interview_count = sum(
        1 for p in processed_pipeline if p.decision == "Interview"
    )
    rejected_count = total_applicants - interview_count
    acceptance_rate = (
        (interview_count / total_applicants) * 100 if total_applicants > 0 else 0
    )

    all_scores = [p.score for p in processed_pipeline]
    avg_score_total = (
        sum(all_scores) / total_applicants if total_applicants > 0 else 0
    )

    interviewed_scores = [
        p.score for p in processed_pipeline if p.decision == "Interview"
    ]
    avg_score_interviewed = (
        sum(interviewed_scores) / interview_count if interview_count > 0 else 0
    )

    print(f"Total Applicants Processed: {total_applicants}")
    print(f"Candidates Selected for Interview: {interview_count}")
    print(f"Candidates Rejected: {rejected_count}")
    print(f"Pipeline Acceptance Rate: {acceptance_rate:.2f}%")
    print(f"Average Score (All Applicants): {avg_score_total:.2f}")
    print(
        "Average Score (Interviewed Candidates): "
        f"{avg_score_interviewed:.2f}"
    )

    print("\n" + "=" * 60)
    print("             END OF REPORT")
    print("=" * 60)


# =============================================================================
# SECTION 5: DATA & EXECUTION
# =============================================================================

def get_sample_applicants() -> List[Applicant]:
    """Generates a sample list of applicants for demonstration. (NFR1)"""
    return [
        Applicant(101, "Alice Johnson", "New York, NY", EducationLevel.MASTERS, 8, {"gender": "Female"}),
        Applicant(102, "Bob Williams", "Chicago, IL", EducationLevel.BACHELORS, 10, {"gender": "Male"}),
        Applicant(103, "Charlie Brown", "San Francisco, CA", EducationLevel.PHD, 6, {"gender": "Male"}),
        Applicant(104, "Diana Miller", "New York, NY", EducationLevel.BACHELORS, 4, {"gender": "Female"}), # Low experience
        Applicant(105, "Ethan Davis", "Boston, MA", EducationLevel.MASTERS, 12, {"gender": "Male"}),
        Applicant(106, "Fiona Garcia", "San Francisco, CA", EducationLevel.BACHELORS, 7, {"gender": "Female"}),
        Applicant(107, "George Rodriguez", "Austin, TX", EducationLevel.PHD, 15, {"gender": "Male"}),
        Applicant(108, "Hannah Martinez", "Chicago, IL", EducationLevel.ASSOCIATES, 2, {"gender": "Female"}), # Low experience
        Applicant(109, "Ian Smith", "New York, NY", EducationLevel.MASTERS, 5, {"gender": "Male"}),
        Applicant(110, "Jane Wilson", "Seattle, WA", EducationLevel.BACHELORS, 9, {"gender": "Female"}),
    ]


def main() -> None:
    """Main function to initialize and run the hiring system."""
    # 1. Initialize configuration and load data (self-contained as per NFR1)
    config = HiringConfiguration()
    applicants = get_sample_applicants()

    # 2. Initialize and run the processing pipeline
    pipeline = HiringPipeline(applicants, config)
    pipeline.process()

    # 3. Generate the final report
    generate_report(pipeline.processed_applicants)


if __name__ == "__main__":
    main()