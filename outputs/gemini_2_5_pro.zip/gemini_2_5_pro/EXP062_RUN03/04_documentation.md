# Technical Documentation: Corporate Hiring System

## 1. Overview

This document provides detailed technical documentation for the Corporate Hiring System. The system is a self-contained Python application designed to automate the initial stages of a corporate hiring process. It evaluates a list of job applicants by scoring them against a configurable set of criteria, ranks them, and makes automated interview decisions. Finally, it generates a comprehensive report summarizing the pipeline's outcomes.

The application is architected to be modular and testable, with a clear separation of concerns between data models, configuration, core logic, and reporting. It operates entirely in-memory, fulfilling the non-functional requirement of having no external database or service dependencies.

---

## 2. System Architecture

The software is organized into five logical sections:

1.  **Configuration**: A centralized, immutable `dataclass` holds all tunable parameters, such as scoring weights and decision thresholds. This allows for easy adjustments to the hiring logic without changing the core code.
2.  **Data Models**: A set of `dataclasses` and an `Enum` define the structure of the data used throughout the application, representing applicants before and after processing.
3.  **Core Logic & Processing**: This section contains the primary business logic. It includes pure functions for scoring and a pipeline class that orchestrates the entire process from scoring to decision-making.
4.  **Reporting**: A dedicated function is responsible for formatting and printing the final output, decoupling reporting from the processing logic.
5.  **Data & Execution**: The main execution block (`main`) and a helper function to provide sample data. This section demonstrates how to initialize and run the system.

The data flows through the system as follows:
`List[Applicant]` -> `HiringPipeline` scores each -> `List[ProcessedApplicant]` is created -> `HiringPipeline` ranks the list -> `HiringPipeline` updates decisions in-place -> `generate_report` consumes the final list to produce output.

---

## 3. Module and Component Reference

### 3.1. Configuration (`SECTION 1`)

#### **`HiringConfiguration`** (dataclass)
A frozen (immutable) dataclass that centralizes all configuration parameters for the hiring system. This design prevents accidental modification of settings during runtime.

**Attributes:**

| Attribute                          | Type                        | Description                                                                                             |
| ---------------------------------- | --------------------------- | ------------------------------------------------------------------------------------------------------- |
| `EDUCATION_SCORES`                 | `Dict[enum.Enum, int]`      | A dictionary mapping `EducationLevel` enums to integer point values.                                    |
| `POINTS_PER_YEAR_OF_EXPERIENCE`    | `int`                       | The number of points awarded for each year of verified industry experience.                             |
| `LOCATION_BONUS_SCORE`             | `int`                       | Bonus points awarded to applicants residing in a preferred location.                                    |
| `PREFERRED_LOCATIONS`              | `Tuple[str, ...]`           | A tuple of city strings that qualify for the location bonus.                                            |
| `MINIMUM_EXPERIENCE_THRESHOLD`     | `int`                       | The number of years of experience below which a penalty is applied (FR5).                               |
| `LOW_EXPERIENCE_PENALTY_MULTIPLIER`| `float`                     | A multiplier (0.0 to 1.0) applied to the total score for candidates with experience below the threshold.  |
| `INTERVIEW_TOP_PERCENTILE`         | `float`                     | The top percentage of candidates (e.g., 0.25 for 25%) to be selected for an interview (FR4).            |

---

### 3.2. Data Models (`SECTION 2`)

#### **`EducationLevel`** (Enum)
An enumeration that defines a standard, controlled set of values for an applicant's level of education.

**Members:**
* `HIGH_SCHOOL`
* `ASSOCIATES`
* `BACHELORS`
* `MASTERS`
* `PHD`

#### **`Applicant`** (dataclass)
An immutable dataclass representing the raw, unprocessed data for a single job applicant (FR1).

**Attributes:**

| Attribute           | Type                  | Description                                                                                           |
| ------------------- | --------------------- | ----------------------------------------------------------------------------------------------------- |
| `applicant_id`      | `int`                 | A unique identifier for the applicant.                                                                |
| `name`              | `str`                 | The full name of the applicant.                                                                       |
| `location`          | `str`                 | The applicant's current city and state (e.g., "New York, NY").                                        |
| `education`         | `EducationLevel`      | The highest level of education achieved by the applicant.                                             |
| `years_experience`  | `int`                 | The total number of years of verified industry experience.                                            |
| `demographics`      | `Dict[str, str]`      | A dictionary to store demographic data. This data is explicitly excluded from scoring to prevent bias. |

#### **`ProcessedApplicant`** (dataclass)
A mutable dataclass that encapsulates an `Applicant` object along with the results of the pipeline processing, such as their calculated score and final decision.

**Attributes:**

| Attribute   | Type        | Description                                                              |
| ----------- | ----------- | ------------------------------------------------------------------------ |
| `applicant` | `Applicant` | The original `Applicant` data object.                                    |
| `score`     | `float`     | The qualification score computed by the `calculate_score` function.      |
| `decision`  | `str`       | The outcome of the process. Initialized to "Pending", then set to "Interview" or "Reject". |

---

### 3.3. Core Logic & Processing (`SECTION 3`)

#### **`calculate_score(applicant, config)`**
A pure function that computes a qualification score for a single applicant based on the rules defined in the `HiringConfiguration` object (FR2).

*   **Parameters:**
    *   `applicant` (`Applicant`): The applicant object to be scored.
    *   `config` (`HiringConfiguration`): The configuration object containing scoring weights and rules.
*   **Returns:**
    *   `float`: The calculated qualification score, rounded to two decimal places.

*   **Scoring Logic:**
    1.  Adds points based on the applicant's `education` level as defined in `config.EDUCATION_SCORES`.
    2.  Adds points by multiplying `years_experience` by `config.POINTS_PER_YEAR_OF_EXPERIENCE`.
    3.  Adds a `LOCATION_BONUS_SCORE` if the applicant's `location` is in `config.PREFERRED_LOCATIONS`.
    4.  **Penalty Application (FR5):** If `years_experience` is less than `config.MINIMUM_EXPERIENCE_THRESHOLD`, the total score is multiplied by the `LOW_EXPERIENCE_PENALTY_MULTIPLIER`.

#### **`make_decisions(ranked_applicants, config)`**
Assigns a final decision ('Interview' or 'Reject') to each applicant in a list that has already been ranked by score (FR4). This function modifies the objects in the list in-place.

*   **Parameters:**
    *   `ranked_applicants` (`List[ProcessedApplicant]`): A list of `ProcessedApplicant` objects, pre-sorted by `score` in descending order.
    *   `config` (`HiringConfiguration`): The configuration object containing the `INTERVIEW_TOP_PERCENTILE`.
*   **Returns:**
    *   `None`: This function has side effects; it directly modifies the `decision` attribute of the items in the `ranked_applicants` list.

#### **`HiringPipeline`** (class)
An orchestrator class that manages the end-to-end hiring process.

##### `__init__(self, applicants, config)`
Initializes the hiring pipeline with a list of applicants and a configuration object.

*   **Parameters:**
    *   `applicants` (`List[Applicant]`): The list of raw applicant data.
    *   `config` (`HiringConfiguration`): The system's configuration.

##### `process(self)`
Executes the full sequence of hiring steps: scoring, ranking, and decision-making. The results are stored in the `self.processed_applicants` instance attribute.

*   **Parameters:** None.
*   **Returns:** `None`.

*   **Process Steps:**
    1.  **Score**: Iterates through `self.applicants`, calls `calculate_score` for each, and creates a new list of `ProcessedApplicant` objects.
    2.  **Rank (FR3)**: Sorts the list of `ProcessedApplicant` objects in-place, in descending order based on their `score`.
    3.  **Decide (FR4)**: Calls `make_decisions` to update the `decision` attribute for each applicant in the ranked list.

---

### 3.4. Reporting (`SECTION 4`)

#### **`generate_report(processed_pipeline)`**
Generates and prints a formatted, multi-section report to the console summarizing the results of the hiring pipeline (NFR2).

*   **Parameters:**
    *   `processed_pipeline` (`List[ProcessedApplicant]`): The final list of processed applicants after the pipeline has been run.
*   **Returns:**
    *   `None`.

*   **Report Sections:**
    1.  **Candidate Rankings & Decisions**: A detailed table showing each candidate's rank, ID, name, score, and final decision.
    2.  **Pipeline Summary Metrics**: A high-level summary including:
        *   Total Applicants Processed
        *   Candidates Selected for Interview
        *   Candidates Rejected
        *   Pipeline Acceptance Rate (%)
        *   Average Score (All Applicants)
        *   Average Score (Interviewed Candidates)

---

### 3.5. Data & Execution (`SECTION 5`)

#### **`get_sample_applicants()`**
A helper function that returns a hardcoded list of `Applicant` objects. This is used for demonstration purposes and ensures the application can run without any external data files or databases (NFR1).

*   **Parameters:** None.
*   **Returns:**
    *   `List[Applicant]`: A list of sample applicant data.

#### **`main()`**
The main entry point for the application. It orchestrates the entire workflow.

*   **Workflow:**
    1.  Initializes the `HiringConfiguration`.
    2.  Loads sample data using `get_sample_applicants()`.
    3.  Instantiates and runs the `HiringPipeline`.
    4.  Calls `generate_report` to display the final results.
*   **Parameters:** None.
*   **Returns:** `None`.

#### **Execution Block (`if __name__ == "__main__":`)**
A standard Python construct that ensures the `main()` function is called only when the script is executed directly, not when imported as a module.