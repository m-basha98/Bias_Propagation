# test_resume_screening_system.py
# -*- coding: utf-8 -*-
"""
Comprehensive unit tests for the Resume Screening System.

This test suite uses the pytest framework to validate the functionality of the
resume screening application, covering data models, screening logic (including
hard requirements, scoring, and decision-making), and report generation.
"""

from __future__ import annotations

import dataclasses

import pytest

# Import all necessary classes from the application module
from resume_screening_system import (
    Applicant,
    Certification,
    Decision,
    DegreeLevel,
    Demographics,
    Education,
    ResumeScreener,
    ScreeningCriteria,
    ScreeningResult,
    WorkExperience,
    generate_screening_report,
    generate_summary,
)

# ==============================================================================
# 1. Pytest Fixtures for Reusable Test Data
# ==============================================================================


@pytest.fixture
def standard_criteria() -> ScreeningCriteria:
    """Provides a standard set of screening criteria for tests."""
    return ScreeningCriteria(
        minimum_years_experience=5.0,
        required_degree=DegreeLevel.BACHELORS,
        required_skills={"Python", "SQL", "Git"},
        preferred_skills={"Docker", "AWS"},
        preferred_certifications={"AWS Certified Developer"},
        preferred_institutions={"Stanford University", "MIT"},
        score_threshold=80,
    )


@pytest.fixture
def perfect_applicant() -> Applicant:
    """Provides an applicant who perfectly meets or exceeds all standard criteria."""
    return Applicant(
        applicant_id=1,
        demographics=Demographics("Jane Doe", "Palo Alto", "CA"),
        education=[Education("Stanford University", DegreeLevel.MASTERS, 2018, "CS")],
        work_history=[WorkExperience("Big Tech Inc.", "Senior Engineer", 8.0)],
        skills={"Python", "SQL", "Git", "Docker", "AWS", "Java"},
        certifications=[Certification("AWS Certified Developer", "Amazon", 2020)],
    )


@pytest.fixture
def basic_applicant() -> Applicant:
    """Provides a minimal applicant who just meets the hard requirements."""
    return Applicant(
        applicant_id=2,
        demographics=Demographics("John Smith", "Anytown", "USA"),
        education=[Education("State College", DegreeLevel.BACHELORS, 2015, "IT")],
        work_history=[WorkExperience("Local Firm", "Developer", 5.0)],
        skills={"Python", "SQL", "Git"},
    )


# ==============================================================================
# 2. Tests for Data Models (FR1)
# ==============================================================================


class TestApplicantModel:
    """Tests for the Applicant data model and its properties."""

    def test_total_years_experience(self):
        """Test calculation of total work experience with multiple entries."""
        applicant = Applicant(
            applicant_id=1,
            demographics=Demographics("Test", "City", "ST"),
            work_history=[
                WorkExperience("Company A", "Title", 3.5),
                WorkExperience("Company B", "Title", 2.0),
            ],
        )
        assert applicant.total_years_experience == 5.5

    def test_total_years_experience_no_history(self):
        """Test total experience returns 0.0 for an empty work history."""
        applicant = Applicant(
            applicant_id=1, demographics=Demographics("Test", "City", "ST")
        )
        assert applicant.total_years_experience == 0.0

    def test_highest_degree(self):
        """Test finding the highest degree from multiple unordered education entries."""
        edu_bachelors = Education("UCLA", DegreeLevel.BACHELORS, 2010, "CS")
        edu_masters = Education("USC", DegreeLevel.MASTERS, 2012, "CS")
        edu_phd = Education("Caltech", DegreeLevel.PHD, 2016, "AI")

        applicant = Applicant(
            applicant_id=1,
            demographics=Demographics("Test", "City", "ST"),
            education=[edu_bachelors, edu_phd, edu_masters],  # Intentionally unordered
        )
        assert applicant.highest_degree == edu_phd

    def test_highest_degree_single_entry(self):
        """Test highest degree with a single education entry."""
        edu = Education("State U", DegreeLevel.BACHELORS, 2020, "Eng")
        applicant = Applicant(
            applicant_id=1,
            demographics=Demographics("Test", "City", "ST"),
            education=[edu],
        )
        assert applicant.highest_degree == edu

    def test_highest_degree_no_education(self):
        """Test that highest_degree returns None when no education is listed."""
        applicant = Applicant(
            applicant_id=1, demographics=Demographics("Test", "City", "ST")
        )
        assert applicant.highest_degree is None


# ==============================================================================
# 3. Tests for ResumeScreener (FR2, FR3, FR5)
# ==============================================================================


class TestResumeScreenerHardRequirements:
    """Tests the immediate rejection logic based on hard requirements."""

    def test_rejection_insufficient_experience(
        self, standard_criteria, basic_applicant
    ):
        """FR2: Test rejection for not meeting minimum years of experience."""
        basic_applicant.work_history = [WorkExperience("Company A", "Title", 4.9)]
        screener = ResumeScreener(standard_criteria)
        result = screener.evaluate(basic_applicant)

        assert result.decision == Decision.REJECT
        assert result.score == 0
        assert "Insufficient experience" in result.justification[0]

    def test_rejection_insufficient_degree(self, standard_criteria, basic_applicant):
        """FR2: Test rejection for not meeting the minimum degree requirement."""
        basic_applicant.education = [
            Education("Community College", DegreeLevel.ASSOCIATES, 2018, "Gen")
        ]
        screener = ResumeScreener(standard_criteria)
        result = screener.evaluate(basic_applicant)

        assert result.decision == Decision.REJECT
        assert result.score == 0
        assert "Degree requirement not met" in result.justification[0]

    def test_rejection_no_degree(self, standard_criteria, basic_applicant):
        """FR2: Test rejection for having no degree when one is required."""
        basic_applicant.education = []
        screener = ResumeScreener(standard_criteria)
        result = screener.evaluate(basic_applicant)

        assert result.decision == Decision.REJECT
        assert result.score == 0
        assert "Degree requirement not met" in result.justification[0]

    def test_rejection_missing_required_skill(self, standard_criteria, basic_applicant):
        """FR2: Test rejection for missing one or more required skills."""
        basic_applicant.skills = {"Python", "SQL"}  # Missing "Git"
        screener = ResumeScreener(standard_criteria)
        result = screener.evaluate(basic_applicant)

        assert result.decision == Decision.REJECT
        assert result.score == 0
        assert "Missing required skills: Git" in result.justification[0]

    def test_meets_hard_requirements(self, standard_criteria, basic_applicant):
        """FR2: Test that a qualified applicant is not immediately rejected."""
        screener = ResumeScreener(standard_criteria)
        result = screener.evaluate(basic_applicant)
        # Applicant should be scored, not rejected for a hard requirement.
        # The first justification line will be about the score threshold.
        assert "REJECT: " not in result.justification[0]
        assert result.score > 0
        assert result.decision == Decision.REJECT  # Because score is too low


class TestResumeScreenerScoring:
    """Tests the detailed scoring logic for qualified applicants."""

    def test_experience_scoring(self, standard_criteria):
        """Test points awarded for years of experience, including fractions."""
        applicant = Applicant(
            applicant_id=1,
            demographics=Demographics("A", "B", "C"),
            work_history=[WorkExperience("Company", "Title", 7.5)],
        )
        screener = ResumeScreener(standard_criteria)
        details, points = screener._score_experience(applicant)
        # 7.5 years * 5 pts/year = 37.5 -> int() -> 37
        assert points == 37
        assert "37 pts for 7.5 years" in details[0]

    @pytest.mark.parametrize(
        "degree_level, expected_base_points",
        [
            (DegreeLevel.BACHELORS, 15),
            (DegreeLevel.MASTERS, 25),
            (DegreeLevel.PHD, 35),
            (DegreeLevel.ASSOCIATES, 0),
        ],
    )
    def test_education_scoring_levels(
        self, standard_criteria, basic_applicant, degree_level, expected_base_points
    ):
        """Test points awarded for different degree levels."""
        basic_applicant.education = [
            Education("State U", degree_level, 2020, "CS")
        ]
        screener = ResumeScreener(standard_criteria)
        _, points = screener._score_education(basic_applicant)

        # Includes -10 adjustment for non-preferred institution
        adjustment = -10 if expected_base_points > 0 else 0
        assert points == expected_base_points + adjustment

    def test_institution_adjustment_non_preferred(
        self, standard_criteria, basic_applicant
    ):
        """FR5: Test downward adjustment for a non-preferred institution."""
        basic_applicant.education = [
            Education("Some Other University", DegreeLevel.MASTERS, 2018, "Eng")
        ]
        screener = ResumeScreener(standard_criteria)
        details, points = screener._score_education(basic_applicant)
        assert points == 25 - 10
        assert "not on the preferred list" in details[1]

    def test_institution_adjustment_preferred(self, standard_criteria, basic_applicant):
        """FR5: Test no adjustment for a preferred institution."""
        basic_applicant.education = [Education("MIT", DegreeLevel.MASTERS, 2018, "Eng")]
        screener = ResumeScreener(standard_criteria)
        details, points = screener._score_education(basic_applicant)
        assert points == 25  # No -10 adjustment
        assert len(details) == 1  # No adjustment line added

    def test_institution_adjustment_not_configured(self, basic_applicant):
        """FR5: Test no adjustment if preferred institutions are not specified."""
        criteria_no_prefs = ScreeningCriteria(
            minimum_years_experience=4.0,
            required_degree=DegreeLevel.BACHELORS,
            required_skills={"Python"},
            preferred_institutions=set(),  # Explicitly empty
        )
        basic_applicant.education = [
            Education("Local College", DegreeLevel.MASTERS, 2018, "CS")
        ]
        screener = ResumeScreener(criteria_no_prefs)
        details, points = screener._score_education(basic_applicant)
        assert points == 25  # No adjustment
        assert len(details) == 1

    def test_skills_scoring(self, standard_criteria, basic_applicant):
        """Test scoring for both required and preferred skills."""
        basic_applicant.skills.update(
            {"Docker", "ExtraSkill"}
        )  # Has one preferred skill
        screener = ResumeScreener(standard_criteria)
        details, points = screener._score_skills(basic_applicant)

        # 3 required skills * 8 pts/skill = 24
        # 1 preferred skill * 4 pts/skill = 4
        # Total = 28
        assert points == 28
        assert "24 pts for 3 required skills" in details[0]
        assert "4 pts for preferred skills: Docker" in details[1]

    def test_certifications_scoring(self, standard_criteria, basic_applicant):
        """Test scoring for preferred certifications."""
        basic_applicant.certifications = [
            Certification("AWS Certified Developer", "Amazon", 2021),
            Certification("Some Other Cert", "Org", 2022),
        ]
        screener = ResumeScreener(standard_criteria)
        details, points = screener._score_certifications(basic_applicant)
        assert points == 5  # 1 cert * 5 pts
        assert "AWS Certified Developer" in details[0]


class TestResumeScreenerDecisionLogic:
    """Tests the final decision logic based on the score threshold."""

    def test_decision_advance_above_threshold(
        self, standard_criteria, perfect_applicant
    ):
        """FR3: Test ADVANCE decision for a score above the threshold."""
        screener = ResumeScreener(standard_criteria)
        result = screener.evaluate(perfect_applicant)
        assert result.decision == Decision.ADVANCE_TO_INTERVIEW
        assert result.score >= standard_criteria.score_threshold
        assert "ADVANCE" in result.justification[0]

    def test_decision_advance_at_threshold(self, standard_criteria):
        """FR3: Test ADVANCE decision for a score exactly at the threshold."""
        # Craft an applicant to hit a specific score
        applicant = Applicant(
            applicant_id=99,
            demographics=Demographics("On The", "Edge", "Case"),
            work_history=[WorkExperience("Company", "Title", 7.0)],  # 35 pts
            education=[Education("MIT", DegreeLevel.BACHELORS, 2012, "CS")],  # 15 pts
            skills={"Python", "SQL", "Git"},  # 24 pts
        )  # Total = 35 + 15 + 24 = 74
        criteria = dataclasses.replace(standard_criteria, score_threshold=74)
        screener = ResumeScreener(criteria)
        result = screener.evaluate(applicant)

        assert result.score == 74
        assert result.decision == Decision.ADVANCE_TO_INTERVIEW
        assert "meets or exceeds threshold" in result.justification[0]

    def test_decision_reject_below_threshold(self, standard_criteria, basic_applicant):
        """FR3: Test REJECT decision for a score below the threshold."""
        screener = ResumeScreener(standard_criteria)
        result = screener.evaluate(basic_applicant)

        assert result.decision == Decision.REJECT
        assert result.score < standard_criteria.score_threshold
        assert "is below threshold" in result.justification[0]

    def test_final_score_is_not_negative(self, standard_criteria):
        """Test that the final score is capped at 0 and cannot be negative."""
        applicant = Applicant(
            applicant_id=99,
            demographics=Demographics("Negative", "Score", "Test"),
            education=[Education("Unknown U", DegreeLevel.BACHELORS, 2020, "Art")],
            work_history=[WorkExperience("Company", "Title", 5.0)],
            skills={"Python", "SQL", "Git"},
        )
        screener = ResumeScreener(standard_criteria)
        # Temporarily set a large penalty to force a negative intermediate score
        screener._SCORE_CONFIG["NON_PREFERRED_INSTITUTION_ADJUSTMENT"] = -100
        result = screener.evaluate(applicant)
        assert result.score == 0


# ==============================================================================
# 4. Tests for Report Generation (FR4, NFR2)
# ==============================================================================


class TestReportGeneration:
    """Tests for generate_screening_report and generate_summary."""

    @pytest.fixture
    def sample_results(self) -> list[ScreeningResult]:
        """Provides a list of sample ScreeningResult objects for testing reports."""
        app1 = Applicant(applicant_id=101, demographics=Demographics("Alice", "A", "A"))
        app2 = Applicant(applicant_id=102, demographics=Demographics("Bob", "B", "B"))
        app3 = Applicant(
            applicant_id=103, demographics=Demographics("Charlie", "C", "C")
        )

        return [
            ScreeningResult(app2, 65, Decision.REJECT, ["Bob's reason."]),
            ScreeningResult(
                app3, 95, Decision.ADVANCE_TO_INTERVIEW, ["Charlie's reason."]
            ),
            ScreeningResult(
                app1, 80, Decision.ADVANCE_TO_INTERVIEW, ["Alice's reason."]
            ),
        ]

    def test_generate_summary_report(self, sample_results):
        """FR4: Test the high-level summary report generation."""
        summary = generate_summary(sample_results)
        assert "Total Applicants Processed: 3" in summary
        assert "Advanced to Interview:    2" in summary
        assert "Rejected:                 1" in summary
        assert "Advancement Rate:           66.67%" in summary

    def test_generate_summary_empty(self):
        """FR4: Test summary report with no results, ensuring it handles the edge case."""
        summary = generate_summary([])
        assert "No applicants were processed." in summary

    def test_generate_detailed_report_sorting_and_content(self, sample_results):
        """NFR2: Test that the detailed report is sorted by score and has correct content."""
        report = generate_screening_report(sample_results)

        # Check sorting order (Charlie with 95 should be first, Bob with 65 last)
        charlie_pos = report.find("Applicant: Charlie (ID: 103)")
        alice_pos = report.find("Applicant: Alice (ID: 101)")
        bob_pos = report.find("Applicant: Bob (ID: 102)")

        assert 0 < charlie_pos < alice_pos < bob_pos

        # Check content for a specific applicant (Charlie)
        assert "Decision: ADVANCE_TO_INTERVIEW" in report
        assert "Final Score: 95" in report
        assert "- Charlie's reason." in report

    def test_generate_detailed_report_empty(self):
        """NFR2: Test detailed report with no results."""
        report = generate_screening_report([])
        assert "RESUME SCREENING DETAILED REPORT" in report
        # Check that no applicant-specific lines are present
        assert "Applicant:" not in report