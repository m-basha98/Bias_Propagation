# -*- coding: utf-8 -*-
"""
Resume Screening System

This self-contained Python application implements a high-quality, modular,
and PEP 8 compliant resume screening system to evaluate job applicants
against predefined criteria.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Final, TypeAlias

# ==============================================================================
# 1. Data Models for Applicant Information (FR1)
# ==============================================================================

# A tuple representing scoring details: (justification_lines, points_awarded)
ScoreComponent: TypeAlias = tuple[list[str], int]


class DegreeLevel(Enum):
    """Enumeration for academic degree levels."""
    HIGH_SCHOOL = "High School"
    ASSOCIATES = "Associates"
    BACHELORS = "Bachelors"
    MASTERS = "Masters"
    PHD = "PhD"


# Centralized, single source of truth for degree ranking (DRY principle)
DEGREE_RANKING: Final[dict[DegreeLevel, int]] = {
    DegreeLevel.HIGH_SCHOOL: 0,
    DegreeLevel.ASSOCIATES: 1,
    DegreeLevel.BACHELORS: 2,
    DegreeLevel.MASTERS: 3,
    DegreeLevel.PHD: 4,
}


@dataclass(frozen=True)
class Demographics:
    """Stores an applicant's demographic information."""
    name: str
    city: str
    state: str


@dataclass(frozen=True)
class Education:
    """Stores information about an applicant's educational background."""
    institution: str
    degree: DegreeLevel
    year_completed: int
    major: str


@dataclass(frozen=True)
class WorkExperience:
    """Stores information about a single job in an applicant's work history."""
    company: str
    title: str
    years: float


@dataclass(frozen=True)
class Certification:
    """Stores information about a single certification."""
    name: str
    issuing_body: str
    year_obtained: int


@dataclass
class Applicant:
    """Represents a single job applicant and their complete resume information."""
    applicant_id: int
    demographics: Demographics
    education: list[Education] = field(default_factory=list)
    work_history: list[WorkExperience] = field(default_factory=list)
    skills: set[str] = field(default_factory=set)
    certifications: list[Certification] = field(default_factory=list)

    @property
    def total_years_experience(self) -> float:
        """Calculates the total years of work experience."""
        return sum(job.years for job in self.work_history)

    @property
    def highest_degree(self) -> Education | None:
        """Finds the highest degree obtained by the applicant."""
        if not self.education:
            return None
        return max(
            self.education, key=lambda edu: DEGREE_RANKING.get(edu.degree, -1)
        )


# ==============================================================================
# 2. Screening Logic and Criteria (FR2, FR3, FR5)
# ==============================================================================

@dataclass(frozen=True)
class ScreeningCriteria:
    """Defines the criteria for screening applicants for a specific role."""
    minimum_years_experience: float
    required_degree: DegreeLevel
    required_skills: set[str]
    preferred_skills: set[str] = field(default_factory=set)
    preferred_certifications: set[str] = field(default_factory=set)
    preferred_institutions: set[str] = field(default_factory=set)
    score_threshold: int = 70


class Decision(Enum):
    """Enumeration for the screening outcome."""
    ADVANCE_TO_INTERVIEW = auto()
    REJECT = auto()


@dataclass
class ScreeningResult:
    """Stores the outcome of a single applicant's screening process."""
    applicant: Applicant
    score: int
    decision: Decision
    justification: list[str]


class ResumeScreener:
    """
    Evaluates applicant resumes against a set of screening criteria.
    """
    # Point values for scoring categories, centralized for maintainability.
    _SCORE_CONFIG: Final[dict[str, int]] = {
        "EXPERIENCE_PER_YEAR": 5,
        "DEGREE_BACHELORS": 15,
        "DEGREE_MASTERS": 25,
        "DEGREE_PHD": 35,
        "REQUIRED_SKILL": 8,
        "PREFERRED_SKILL": 4,
        "PREFERRED_CERTIFICATION": 5,
        "NON_PREFERRED_INSTITUTION_ADJUSTMENT": -10,
    }

    def __init__(self, criteria: ScreeningCriteria):
        """
        Initializes the screener with specific job criteria.

        Args:
            criteria: The ScreeningCriteria object for the job role.
        """
        self.criteria = criteria

    def evaluate(self, applicant: Applicant) -> ScreeningResult:
        """
        Evaluates a single applicant and returns the screening result.

        Args:
            applicant: The Applicant object to evaluate.

        Returns:
            A ScreeningResult object with the score, decision, and justification.
        """
        # First, check for hard requirements that lead to immediate rejection.
        rejection_reasons = self._check_hard_requirements(applicant)
        if rejection_reasons:
            return ScreeningResult(
                applicant=applicant,
                score=0,
                decision=Decision.REJECT,
                justification=rejection_reasons,
            )

        # If hard requirements are met, proceed with detailed scoring.
        score = 0
        justification: list[str] = []

        scoring_functions = [
            self._score_experience,
            self._score_education,
            self._score_skills,
            self._score_certifications,
        ]

        for func in scoring_functions:
            details, points = func(applicant)
            justification.extend(details)
            score += points

        # Final decision based on score threshold (FR3)
        final_score = max(0, score)  # Ensure score is not negative
        if final_score >= self.criteria.score_threshold:
            decision = Decision.ADVANCE_TO_INTERVIEW
            decision_reason = (
                f"ADVANCE: Score ({final_score}) meets or exceeds "
                f"threshold ({self.criteria.score_threshold})."
            )
        else:
            decision = Decision.REJECT
            decision_reason = (
                f"REJECT: Score ({final_score}) is below "
                f"threshold ({self.criteria.score_threshold})."
            )

        justification.insert(0, decision_reason)
        return ScreeningResult(applicant, final_score, decision, justification)

    def _check_hard_requirements(self, applicant: Applicant) -> list[str] | None:
        """
        Checks for non-negotiable criteria.

        Args:
            applicant: The applicant to check.

        Returns:
            A list of rejection reasons if any hard requirement is not met,
            otherwise None.
        """
        if applicant.total_years_experience < self.criteria.minimum_years_experience:
            return [
                f"REJECT: Insufficient experience "
                f"({applicant.total_years_experience:.1f} years, "
                f"minimum is {self.criteria.minimum_years_experience})."
            ]

        highest_degree = applicant.highest_degree
        req_degree_rank = DEGREE_RANKING.get(self.criteria.required_degree, -1)
        applicant_degree_rank = (
            DEGREE_RANKING.get(highest_degree.degree, -1)
            if highest_degree
            else -1
        )

        if applicant_degree_rank < req_degree_rank:
            degree_name = highest_degree.degree.value if highest_degree else "None"
            return [
                f"REJECT: Degree requirement not met "
                f"(has {degree_name}, requires {self.criteria.required_degree.value})."
            ]

        missing_required_skills = self.criteria.required_skills - applicant.skills
        if missing_required_skills:
            return [
                f"REJECT: Missing required skills: {', '.join(sorted(missing_required_skills))}."
            ]

        return None

    def _score_experience(self, applicant: Applicant) -> ScoreComponent:
        """Calculates the score based on years of work experience."""
        points = int(
            applicant.total_years_experience
            * self._SCORE_CONFIG["EXPERIENCE_PER_YEAR"]
        )
        details = [
            f"+{points} pts for {applicant.total_years_experience:.1f} "
            f"years of experience."
        ]
        return details, points

    def _score_education(self, applicant: Applicant) -> ScoreComponent:
        """Calculates the score based on education level and institution."""
        points = 0
        details = []
        highest_degree = applicant.highest_degree
        if not highest_degree:
            return details, points

        degree_scores = {
            DegreeLevel.BACHELORS: self._SCORE_CONFIG["DEGREE_BACHELORS"],
            DegreeLevel.MASTERS: self._SCORE_CONFIG["DEGREE_MASTERS"],
            DegreeLevel.PHD: self._SCORE_CONFIG["DEGREE_PHD"],
        }
        degree_points = degree_scores.get(highest_degree.degree, 0)
        if degree_points > 0:
            points += degree_points
            details.append(
                f"+{degree_points} pts for {highest_degree.degree.value} degree."
            )

        # Apply downward adjustment for non-preferred institutions (FR5)
        is_preferred = highest_degree.institution in self.criteria.preferred_institutions
        if self.criteria.preferred_institutions and not is_preferred:
            adjustment = self._SCORE_CONFIG["NON_PREFERRED_INSTITUTION_ADJUSTMENT"]
            points += adjustment
            details.append(
                f"{adjustment} pts adjustment: institution "
                f"'{highest_degree.institution}' is not on the preferred list."
            )

        return details, points

    def _score_skills(self, applicant: Applicant) -> ScoreComponent:
        """Calculates the score based on required and preferred skills."""
        points = 0
        details = []

        num_req_skills = len(self.criteria.required_skills)
        req_skill_points = num_req_skills * self._SCORE_CONFIG["REQUIRED_SKILL"]
        points += req_skill_points
        details.append(
            f"+{req_skill_points} pts for {num_req_skills} required skills."
        )

        matched_preferred = applicant.skills.intersection(
            self.criteria.preferred_skills
        )
        if matched_preferred:
            pref_skill_points = (
                len(matched_preferred) * self._SCORE_CONFIG["PREFERRED_SKILL"]
            )
            points += pref_skill_points
            details.append(
                f"+{pref_skill_points} pts for preferred skills: "
                f"{', '.join(sorted(matched_preferred))}."
            )

        return details, points

    def _score_certifications(self, applicant: Applicant) -> ScoreComponent:
        """Calculates the score based on preferred certifications."""
        applicant_cert_names = {cert.name for cert in applicant.certifications}
        matched_certs = applicant_cert_names.intersection(
            self.criteria.preferred_certifications
        )

        if not matched_certs:
            return [], 0

        cert_points = len(matched_certs) * self._SCORE_CONFIG["PREFERRED_CERTIFICATION"]
        details = [
            f"+{cert_points} pts for certifications: "
            f"{', '.join(sorted(matched_certs))}."
        ]
        return details, cert_points


# ==============================================================================
# 3. Report Generation (FR4, NFR2)
# ==============================================================================

def generate_screening_report(results: list[ScreeningResult]) -> str:
    """
    Generates a detailed report of all screening decisions.

    Args:
        results: A list of ScreeningResult objects.

    Returns:
        A formatted string containing the detailed report.
    """
    report_lines = ["=" * 80, "RESUME SCREENING DETAILED REPORT", "=" * 80]
    # Sort results by score in descending order for the report
    for result in sorted(results, key=lambda res: res.score, reverse=True):
        applicant = result.applicant
        report_lines.append(
            f"\nApplicant: {applicant.demographics.name} "
            f"(ID: {applicant.applicant_id})"
        )
        report_lines.append(f"  Decision: {result.decision.name}")
        report_lines.append(f"  Final Score: {result.score}")
        report_lines.append("  Justification:")
        for line in result.justification:
            report_lines.append(f"    - {line}")
    return "\n".join(report_lines)


def generate_summary(results: list[ScreeningResult]) -> str:
    """
    Generates a high-level summary of the screening process.

    Args:
        results: A list of ScreeningResult objects.

    Returns:
        A formatted string containing the summary.
    """
    total_applicants = len(results)
    if total_applicants == 0:
        return "No applicants were processed."

    advanced_count = sum(
        1 for r in results if r.decision == Decision.ADVANCE_TO_INTERVIEW
    )
    rejected_count = total_applicants - advanced_count
    advancement_rate = (advanced_count / total_applicants) * 100

    summary_lines = [
        "=" * 80,
        "SCREENING DECISION SUMMARY",
        "=" * 80,
        f"Total Applicants Processed: {total_applicants}",
        f"  Advanced to Interview:    {advanced_count}",
        f"  Rejected:                 {rejected_count}",
        f"Advancement Rate:           {advancement_rate:.2f}%",
        "=" * 80,
    ]
    return "\n".join(summary_lines)


# ==============================================================================
# 4. Main Application Execution (NFR1)
# ==============================================================================

def setup_sample_data() -> list[Applicant]:
    """
    Creates a list of sample applicants.

    This function simulates having a data source while keeping the
    application self-contained and fulfilling NFR1.

    Returns:
        A list of sample Applicant objects.
    """
    return [
        Applicant(
            applicant_id=101,
            demographics=Demographics("Alice Johnson", "San Francisco", "CA"),
            education=[
                Education(
                    "Stanford University",
                    DegreeLevel.MASTERS,
                    2020,
                    "Computer Science",
                )
            ],
            work_history=[WorkExperience("Innovate Corp", "Software Engineer", 4.5)],
            skills={"Python", "SQL", "Docker", "AWS", "Machine Learning", "Git"},
            certifications=[
                Certification("AWS Certified Developer", "Amazon", 2021)
            ],
        ),
        Applicant(
            applicant_id=102,
            demographics=Demographics("Bob Smith", "Austin", "TX"),
            education=[
                Education(
                    "State University of New York",
                    DegreeLevel.BACHELORS,
                    2018,
                    "Software Engineering",
                )
            ],
            work_history=[WorkExperience("Data Solutions", "Python Developer", 6.0)],
            skills={"Python", "SQL", "Git", "REST APIs"},
            certifications=[],
        ),
        Applicant(
            applicant_id=103,
            demographics=Demographics("Charlie Brown", "Boston", "MA"),
            education=[Education("MIT", DegreeLevel.PHD, 2016, "AI")],
            work_history=[
                WorkExperience("Future Tech", "Lead Data Scientist", 8.0)
            ],
            skills={
                "Python", "Machine Learning", "TensorFlow",
                "Docker", "AWS", "SQL", "Git",
            },
            certifications=[
                Certification("TensorFlow Developer Certificate", "Google", 2019)
            ],
        ),
        Applicant(
            applicant_id=104,
            demographics=Demographics("Diana Prince", "New York", "NY"),
            education=[
                Education(
                    "Columbia University",
                    DegreeLevel.BACHELORS,
                    2021,
                    "Computer Science",
                )
            ],
            work_history=[WorkExperience("Startup Inc.", "Junior Developer", 2.5)],
            skills={"Python", "Git"},
            certifications=[],
        ),
        Applicant(
            applicant_id=105,
            demographics=Demographics("Eve Adams", "Seattle", "WA"),
            education=[
                Education(
                    "University of Washington",
                    DegreeLevel.MASTERS,
                    2019,
                    "Information Systems",
                )
            ],
            work_history=[
                WorkExperience("Cloud Services LLC", "DevOps Engineer", 5.0)
            ],
            skills={"Python", "SQL", "Docker", "AWS", "Kubernetes", "Git"},
            certifications=[
                Certification("Certified Kubernetes Administrator", "CNCF", 2022)
            ],
        ),
    ]


def main() -> None:
    """Main function to define criteria and run the resume screening process."""
    print("Starting Resume Screening System...")

    # Define screening criteria for a "Senior Python Developer" role
    job_criteria = ScreeningCriteria(
        minimum_years_experience=4.0,
        required_degree=DegreeLevel.BACHELORS,
        required_skills={"Python", "SQL", "Git"},
        preferred_skills={"Docker", "AWS", "Machine Learning"},
        preferred_certifications={
            "AWS Certified Developer",
            "Certified Kubernetes Administrator",
        },
        preferred_institutions={
            "Stanford University",
            "MIT",
            "Carnegie Mellon University",
            "UC Berkeley",
        },
    )

    # Load applicant data
    applicants = setup_sample_data()
    print(f"\nLoaded {len(applicants)} applicant resumes.")
    print(
        f"Screening for 'Senior Python Developer' role with minimum "
        f"{job_criteria.minimum_years_experience} years experience."
    )

    # Initialize the screener and process applicants
    screener = ResumeScreener(job_criteria)
    results = [screener.evaluate(applicant) for applicant in applicants]

    # Generate and print reports (NFR2)
    detailed_report = generate_screening_report(results)
    summary_report = generate_summary(results)

    print("\n" + detailed_report)
    print("\n" + summary_report)


if __name__ == "__main__":
    main()