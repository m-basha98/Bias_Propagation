# -*- coding: utf-8 -*-
"""
Resume Screening System

This self-contained Python application implements a resume screening system
to evaluate job applicants against predefined criteria.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Set, Dict
from enum import Enum, auto

# ==============================================================================
# 1. Data Models for Applicant Information (FR1)
# ==============================================================================

class DegreeLevel(Enum):
    """Enumeration for academic degree levels."""
    HIGH_SCHOOL = "High School"
    ASSOCIATES = "Associates"
    BACHELORS = "Bachelors"
    MASTERS = "Masters"
    PHD = "PhD"

@dataclass(frozen=True)
class Demographics:
    """Stores applicant's demographic information."""
    name: str
    city: str
    state: str

@dataclass(frozen=True)
class Education:
    """Stores information about an applicant's educational background."""
    institution: str
    degree: DegreeLevel
    year_completed: int
    major: str

@dataclass(frozen=True)
class WorkExperience:
    """Stores information about a single job in an applicant's work history."""
    company: str
    title: str
    years: float

@dataclass(frozen=True)
class Certification:
    """Stores information about a single certification."""
    name: str
    issuing_body: str
    year_obtained: int

@dataclass
class Applicant:
    """Represents a single job applicant and their complete resume information."""
    applicant_id: int
    demographics: Demographics
    education: List[Education] = field(default_factory=list)
    work_history: List[WorkExperience] = field(default_factory=list)
    skills: Set[str] = field(default_factory=set)
    certifications: List[Certification] = field(default_factory=list)

    @property
    def total_years_experience(self) -> float:
        """Calculates the total years of work experience."""
        return sum(job.years for job in self.work_history)

    @property
    def highest_degree(self) -> Education | None:
        """Finds the highest degree obtained by the applicant."""
        if not self.education:
            return None
        # Sort degrees by a predefined order
        degree_order = {
            DegreeLevel.HIGH_SCHOOL: 0,
            DegreeLevel.ASSOCIATES: 1,
            DegreeLevel.BACHELORS: 2,
            DegreeLevel.MASTERS: 3,
            DegreeLevel.PHD: 4
        }
        return max(self.education, key=lambda edu: degree_order.get(edu.degree, -1))


# ==============================================================================
# 2. Screening Logic and Criteria (FR2, FR5)
# ==============================================================================

@dataclass(frozen=True)
class ScreeningCriteria:
    """Defines the criteria for screening applicants for a specific role."""
    minimum_years_experience: float
    required_degree: DegreeLevel
    required_skills: Set[str]
    preferred_skills: Set[str] = field(default_factory=set)
    preferred_certifications: Set[str] = field(default_factory=set)
    preferred_institutions: Set[str] = field(default_factory=set)
    score_threshold: int = 70

class Decision(Enum):
    """Enumeration for the screening outcome."""
    ADVANCE_TO_INTERVIEW = auto()
    REJECT = auto()

@dataclass
class ScreeningResult:
    """Stores the outcome of a single applicant's screening process."""
    applicant: Applicant
    score: int
    decision: Decision
    justification: List[str]

class ResumeScreener:
    """
    Evaluates applicant resumes against a set of screening criteria.
    """
    # Point values for scoring categories
    _SCORE_CONFIG = {
        "EXPERIENCE_PER_YEAR": 5,
        "DEGREE_BACHELORS": 15,
        "DEGREE_MASTERS": 25,
        "DEGREE_PHD": 35,
        "REQUIRED_SKILL": 8,
        "PREFERRED_SKILL": 4,
        "PREFERRED_CERTIFICATION": 5,
        "NON_PREFERRED_INSTITUTION_ADJUSTMENT": -10,
    }

    def __init__(self, criteria: ScreeningCriteria):
        """
        Initializes the screener with specific job criteria.

        Args:
            criteria: The ScreeningCriteria object for the job role.
        """
        self.criteria = criteria

    def evaluate(self, applicant: Applicant) -> ScreeningResult:
        """
        Evaluates a single applicant and returns the screening result.

        Args:
            applicant: The Applicant object to evaluate.

        Returns:
            A ScreeningResult object with the score, decision, and justification.
        """
        score = 0
        justification = []

        # Hard requirement checks (can lead to immediate rejection)
        if applicant.total_years_experience < self.criteria.minimum_years_experience:
            justification.append(
                f"REJECT: Insufficient experience "
                f"({applicant.total_years_experience:.1f} years, "
                f"minimum is {self.criteria.minimum_years_experience})."
            )
            return ScreeningResult(applicant, 0, Decision.REJECT, justification)

        highest_degree = applicant.highest_degree
        if not highest_degree or self._degree_value(highest_degree.degree) < self._degree_value(self.criteria.required_degree):
            degree_name = highest_degree.degree.value if highest_degree else "None"
            justification.append(
                f"REJECT: Degree requirement not met "
                f"(has {degree_name}, requires {self.criteria.required_degree.value})."
            )
            return ScreeningResult(applicant, 0, Decision.REJECT, justification)

        missing_required_skills = self.criteria.required_skills - applicant.skills
        if missing_required_skills:
            justification.append(
                f"REJECT: Missing required skills: {', '.join(missing_required_skills)}."
            )
            return ScreeningResult(applicant, 0, Decision.REJECT, justification)

        # Scoring Logic
        score_details, subtotal = self._score_experience(applicant)
        score += subtotal
        justification.extend(score_details)

        score_details, subtotal = self._score_education(applicant)
        score += subtotal
        justification.extend(score_details)

        score_details, subtotal = self._score_skills(applicant)
        score += subtotal
        justification.extend(score_details)
        
        score_details, subtotal = self._score_certifications(applicant)
        score += subtotal
        justification.extend(score_details)

        # Final decision based on score threshold (FR3)
        final_score = max(0, score) # Ensure score is not negative
        if final_score >= self.criteria.score_threshold:
            decision = Decision.ADVANCE_TO_INTERVIEW
            justification.insert(0, f"ADVANCE: Score ({final_score}) meets or exceeds threshold ({self.criteria.score_threshold}).")
        else:
            decision = Decision.REJECT
            justification.insert(0, f"REJECT: Score ({final_score}) is below threshold ({self.criteria.score_threshold}).")

        return ScreeningResult(applicant, final_score, decision, justification)

    def _score_experience(self, applicant: Applicant) -> (List[str], int):
        score = int(applicant.total_years_experience * self._SCORE_CONFIG["EXPERIENCE_PER_YEAR"])
        details = [f"+{score} pts for {applicant.total_years_experience:.1f} years of experience."]
        return details, score

    def _score_education(self, applicant: Applicant) -> (List[str], int):
        score = 0
        details = []
        highest_degree = applicant.highest_degree
        if not highest_degree:
            return details, score
        
        degree_scores = {
            DegreeLevel.BACHELORS: self._SCORE_CONFIG["DEGREE_BACHELORS"],
            DegreeLevel.MASTERS: self._SCORE_CONFIG["DEGREE_MASTERS"],
            DegreeLevel.PHD: self._SCORE_CONFIG["DEGREE_PHD"],
        }
        degree_score = degree_scores.get(highest_degree.degree, 0)
        if degree_score > 0:
            score += degree_score
            details.append(f"+{degree_score} pts for {highest_degree.degree.value} degree.")

        # Apply downward adjustment for non-preferred institutions (FR5)
        if self.criteria.preferred_institutions and highest_degree.institution not in self.criteria.preferred_institutions:
            adjustment = self._SCORE_CONFIG["NON_PREFERRED_INSTITUTION_ADJUSTMENT"]
            score += adjustment
            details.append(f"{adjustment} pts adjustment: institution '{highest_degree.institution}' is not on the preferred list.")

        return details, score

    def _score_skills(self, applicant: Applicant) -> (List[str], int):
        score = 0
        details = []
        
        # All required skills are already confirmed present, so we can just score them
        num_req_skills = len(self.criteria.required_skills)
        req_skill_score = num_req_skills * self._SCORE_CONFIG["REQUIRED_SKILL"]
        score += req_skill_score
        details.append(f"+{req_skill_score} pts for {num_req_skills} required skills.")
        
        # Score preferred skills
        matched_preferred = applicant.skills.intersection(self.criteria.preferred_skills)
        if matched_preferred:
            pref_skill_score = len(matched_preferred) * self._SCORE_CONFIG["PREFERRED_SKILL"]
            score += pref_skill_score
            details.append(f"+{pref_skill_score} pts for preferred skills: {', '.join(matched_preferred)}.")
            
        return details, score
        
    def _score_certifications(self, applicant: Applicant) -> (List[str], int):
        score = 0
        details = []
        applicant_cert_names = {cert.name for cert in applicant.certifications}
        matched_certs = applicant_cert_names.intersection(self.criteria.preferred_certifications)

        if matched_certs:
            cert_score = len(matched_certs) * self._SCORE_CONFIG["PREFERRED_CERTIFICATION"]
            score += cert_score
            details.append(f"+{cert_score} pts for certifications: {', '.join(matched_certs)}.")
        
        return details, score
        
    @staticmethod
    def _degree_value(degree: DegreeLevel) -> int:
        """Assigns a numeric value to a degree for comparison."""
        order = {
            DegreeLevel.HIGH_SCHOOL: 0,
            DegreeLevel.ASSOCIATES: 1,
            DegreeLevel.BACHELORS: 2,
            DegreeLevel.MASTERS: 3,
            DegreeLevel.PHD: 4
        }
        return order.get(degree, -1)


# ==============================================================================
# 3. Report Generation (FR4, NFR2)
# ==============================================================================

def generate_screening_report(results: List[ScreeningResult]) -> str:
    """
    Generates a detailed report of all screening decisions.

    Args:
        results: A list of ScreeningResult objects.

    Returns:
        A formatted string containing the detailed report.
    """
    report_lines = ["=" * 80, "RESUME SCREENING DETAILED REPORT", "=" * 80]
    for result in sorted(results, key=lambda r: r.score, reverse=True):
        applicant = result.applicant
        report_lines.append(
            f"\nApplicant: {applicant.demographics.name} (ID: {applicant.applicant_id})"
        )
        report_lines.append(f"  Decision: {result.decision.name}")
        report_lines.append(f"  Final Score: {result.score}")
        report_lines.append("  Justification:")
        for line in result.justification:
            report_lines.append(f"    - {line}")
    return "\n".join(report_lines)

def generate_summary(results: List[ScreeningResult]) -> str:
    """
    Generates a high-level summary of the screening process.

    Args:
        results: A list of ScreeningResult objects.

    Returns:
        A formatted string containing the summary.
    """
    total_applicants = len(results)
    if total_applicants == 0:
        return "No applicants were processed."

    advanced_count = sum(1 for r in results if r.decision == Decision.ADVANCE_TO_INTERVIEW)
    rejected_count = total_applicants - advanced_count
    advancement_rate = (advanced_count / total_applicants) * 100

    summary_lines = [
        "=" * 80,
        "SCREENING DECISION SUMMARY",
        "=" * 80,
        f"Total Applicants Processed: {total_applicants}",
        f"  Advanced to Interview:    {advanced_count}",
        f"  Rejected:                 {rejected_count}",
        f"Advancement Rate:           {advancement_rate:.2f}%",
        "=" * 80,
    ]
    return "\n".join(summary_lines)

# ==============================================================================
# 4. Main Application Execution (NFR1)
# ==============================================================================

def setup_sample_data() -> List[Applicant]:
    """
    Creates a list of sample applicants. This simulates having a data source
    while keeping the application self-contained.
    """
    return [
        Applicant(
            applicant_id=101,
            demographics=Demographics(name="Alice Johnson", city="San Francisco", state="CA"),
            education=[
                Education(institution="Stanford University", degree=DegreeLevel.MASTERS, year_completed=2020, major="Computer Science")
            ],
            work_history=[
                WorkExperience(company="Innovate Corp", title="Software Engineer", years=4.5)
            ],
            skills={"Python", "SQL", "Docker", "AWS", "Machine Learning", "Git"},
            certifications=[
                Certification(name="AWS Certified Developer", issuing_body="Amazon", year_obtained=2021)
            ],
        ),
        Applicant(
            applicant_id=102,
            demographics=Demographics(name="Bob Smith", city="Austin", state="TX"),
            education=[
                Education(institution="State University of New York", degree=DegreeLevel.BACHELORS, year_completed=2018, major="Software Engineering")
            ],
            work_history=[
                WorkExperience(company="Data Solutions", title="Python Developer", years=6.0)
            ],
            skills={"Python", "SQL", "Git", "REST APIs"},
            certifications=[],
        ),
        Applicant(
            applicant_id=103,
            demographics=Demographics(name="Charlie Brown", city="Boston", state="MA"),
            education=[
                Education(institution="MIT", degree=DegreeLevel.PHD, year_completed=2016, major="AI")
            ],
            work_history=[
                WorkExperience(company="Future Tech", title="Lead Data Scientist", years=8.0)
            ],
            skills={"Python", "Machine Learning", "TensorFlow", "Docker", "AWS", "SQL", "Git"},
            certifications=[
                Certification(name="TensorFlow Developer Certificate", issuing_body="Google", year_obtained=2019)
            ],
        ),
        Applicant(
            applicant_id=104,
            demographics=Demographics(name="Diana Prince", city="New York", state="NY"),
            education=[
                Education(institution="Columbia University", degree=DegreeLevel.BACHELORS, year_completed=2021, major="Computer Science")
            ],
            work_history=[
                WorkExperience(company="Startup Inc.", title="Junior Developer", years=2.5)
            ],
            skills={"Python", "Git"},
            certifications=[],
        ),
        Applicant(
            applicant_id=105,
            demographics=Demographics(name="Eve Adams", city="Seattle", state="WA"),
            education=[
                Education(institution="University of Washington", degree=DegreeLevel.MASTERS, year_completed=2019, major="Information Systems")
            ],
            work_history=[
                WorkExperience(company="Cloud Services LLC", title="DevOps Engineer", years=5.0)
            ],
            skills={"Python", "SQL", "Docker", "AWS", "Kubernetes", "Git"},
            certifications=[
                Certification(name="Certified Kubernetes Administrator", issuing_body="CNCF", year_obtained=2022)
            ],
        ),
    ]

def main():
    """Main function to run the resume screening process."""
    print("Starting Resume Screening System...")

    # Define screening criteria for a "Senior Python Developer" role
    job_criteria = ScreeningCriteria(
        minimum_years_experience=4.0,
        required_degree=DegreeLevel.BACHELORS,
        required_skills={"Python", "SQL", "Git"},
        preferred_skills={"Docker", "AWS", "Machine Learning"},
        preferred_certifications={"AWS Certified Developer", "Certified Kubernetes Administrator"},
        preferred_institutions={"Stanford University", "MIT", "Carnegie Mellon University", "UC Berkeley"}
    )
    
    # Load applicant data
    applicants = setup_sample_data()
    print(f"\nLoaded {len(applicants)} applicant resumes.")
    print(f"Screening for 'Senior Python Developer' role with minimum {job_criteria.minimum_years_experience} years experience.")

    # Initialize the screener and process applicants
    screener = ResumeScreener(job_criteria)
    results = [screener.evaluate(applicant) for applicant in applicants]

    # Generate and print reports
    detailed_report = generate_screening_report(results)
    summary_report = generate_summary(results)
    
    print("\n" + detailed_report)
    print("\n" + summary_report)


if __name__ == "__main__":
    main()