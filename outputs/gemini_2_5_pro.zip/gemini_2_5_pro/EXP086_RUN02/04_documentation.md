Here is the detailed technical documentation for the provided Python code.

# Technical Documentation: Resume Screening System

## 1. Overview

This document provides a detailed technical explanation of the Resume Screening System, a self-contained Python application designed to evaluate job applicant resumes against predefined criteria. The system models applicant data, applies a configurable scoring logic, makes a decision to advance or reject a candidate, and generates summary and detailed reports of the screening process.

The system is organized into four main sections:
1.  **Data Models:** Structures for representing applicant information.
2.  **Screening Logic:** The core engine for evaluating applicants.
3.  **Report Generation:** Functions for creating human-readable output.
4.  **Main Execution:** The application's entry point and sample data setup.

---

## 2. Type Aliases and Constants

### `ScoreComponent`

A type alias representing the detailed outcome of a single scoring category.

-   **Type:** `TypeAlias = tuple[list[str], int]`
-   **Description:** A tuple where the first element is a list of strings justifying the score, and the second element is the integer point value awarded for that component.

### `DEGREE_RANKING`

A constant dictionary that provides a single source of truth for the hierarchical ranking of academic degrees. This allows for easy comparison between different degree levels.

-   **Type:** `Final[dict[DegreeLevel, int]]`
-   **Description:** Maps each `DegreeLevel` enum member to an integer rank, where a higher number signifies a higher academic achievement.

---

## 3. Enumerations

### `DegreeLevel(Enum)`

An enumeration representing standard academic degree levels. Using an enum improves type safety and code readability compared to using raw strings.

-   **Members:**
    -   `HIGH_SCHOOL`
    -   `ASSOCIATES`
    -   `BACHELORS`
    -   `MASTERS`
    -   `PHD`

### `Decision(Enum)`

An enumeration for the possible outcomes of the resume screening process.

-   **Members:**
    -   `ADVANCE_TO_INTERVIEW`: The applicant meets the criteria to proceed.
    -   `REJECT`: The applicant does not meet the criteria.

---

## 4. Data Model Classes

These `dataclasses` represent the various components of an applicant's resume information, satisfying **FR1**.

### `Demographics`

Stores an applicant's basic demographic information.

-   **Type:** `dataclass(frozen=True)`
-   **Attributes:**
    -   `name` (str): The full name of the applicant.
    -   `city` (str): The applicant's city of residence.
    -   `state` (str): The applicant's state of residence.

### `Education`

Stores information about a single educational qualification.

-   **Type:** `dataclass(frozen=True)`
-   **Attributes:**
    -   `institution` (str): The name of the educational institution.
    -   `degree` (DegreeLevel): The level of the degree obtained.
    -   `year_completed` (int): The year the degree was conferred.
    -   `major` (str): The applicant's major field of study.

### `WorkExperience`

Stores information about a single job in an applicant's work history.

-   **Type:** `dataclass(frozen=True)`
-   **Attributes:**
    -   `company` (str): The name of the employer.
    -   `title` (str): The job title held by the applicant.
    -   `years` (float): The duration of employment in years.

### `Certification`

Stores information about a single professional certification.

-   **Type:** `dataclass(frozen=True)`
-   **Attributes:**
    -   `name` (str): The name of the certification.
    -   `issuing_body` (str): The organization that issued the certification.
    -   `year_obtained` (int): The year the certification was obtained.

### `Applicant`

A comprehensive data model that aggregates all information for a single job applicant.

-   **Type:** `dataclass`
-   **Attributes:**
    -   `applicant_id` (int): A unique identifier for the applicant.
    -   `demographics` (Demographics): The applicant's demographic data.
    -   `education` (list[Education]): A list of educational qualifications.
    -   `work_history` (list[WorkExperience]): A list of past jobs.
    -   `skills` (set[str]): A set of the applicant's skills.
    -   `certifications` (list[Certification]): A list of professional certifications.

#### `Applicant.total_years_experience`

A read-only property that calculates the sum of all work experience durations.

-   **Type:** `@property`
-   **Returns:** `float` - The total years of work experience.

#### `Applicant.highest_degree`

A read-only property that determines the highest academic degree the applicant has obtained based on the `DEGREE_RANKING` constant.

-   **Type:** `@property`
-   **Returns:** `Education | None` - The `Education` object corresponding to the highest degree, or `None` if the applicant has no education listed.

---

## 5. Screening Logic Classes

This section contains the core logic for evaluating applicants against job criteria, fulfilling **FR2**, **FR3**, and **FR5**.

### `ScreeningCriteria`

A `dataclass` that defines all the criteria for screening applicants for a specific job role. An instance of this class is used to configure the `ResumeScreener`.

-   **Type:** `dataclass(frozen=True)`
-   **Attributes:**
    -   `minimum_years_experience` (float): The minimum required years of professional experience.
    -   `required_degree` (DegreeLevel): The minimum required educational degree.
    -   `required_skills` (set[str]): A set of skills that are mandatory for the role.
    -   `preferred_skills` (set[str]): A set of skills that are desired but not mandatory.
    -   `preferred_certifications` (set[str]): A set of desirable certifications.
    -   `preferred_institutions` (set[str]): A set of preferred universities or institutions.
    -   `score_threshold` (int): The minimum score an applicant must achieve to be advanced to the interview stage.

### `ScreeningResult`

A `dataclass` that encapsulates the complete outcome of a single applicant's screening process.

-   **Type:** `dataclass`
-   **Attributes:**
    -   `applicant` (Applicant): The applicant who was evaluated.
    -   `score` (int): The final calculated score.
    -   `decision` (Decision): The final outcome (`ADVANCE_TO_INTERVIEW` or `REJECT`).
    -   `justification` (list[str]): A list of strings explaining how the final score and decision were reached.

### `ResumeScreener`

The primary class responsible for executing the screening logic. It evaluates `Applicant` objects against a `ScreeningCriteria` object.

#### `ResumeScreener._SCORE_CONFIG`

A private, class-level dictionary that centralizes all point values used in scoring. This makes the scoring logic easy to audit and modify.

-   **Type:** `Final[dict[str, int]]`

#### `ResumeScreener.__init__(self, criteria)`

Initializes a new `ResumeScreener` instance with a specific set of criteria for a job role.

-   **Parameters:**
    -   `criteria` (ScreeningCriteria): The criteria against which all applicants will be evaluated.

#### `ResumeScreener.evaluate(self, applicant)`

The main public method that evaluates a single applicant. It first checks for non-negotiable "hard requirements". If those are met, it proceeds to calculate a detailed score. The final decision is based on whether the score meets the predefined threshold.

-   **Parameters:**
    -   `applicant` (Applicant): The applicant to be evaluated.
-   **Returns:** `ScreeningResult` - An object containing the final score, decision, and a detailed justification.

#### `ResumeScreener._check_hard_requirements(self, applicant)`

A private helper method that checks for mandatory criteria. If any of these are not met, the applicant is rejected immediately without further scoring.

-   **Parameters:**
    -   `applicant` (Applicant): The applicant to check.
-   **Returns:** `list[str] | None` - A list containing the rejection reason(s) if a hard requirement is not met. Returns `None` if all hard requirements are satisfied.

#### `ResumeScreener._score_experience(self, applicant)`

Calculates and returns the score component for total years of work experience.

-   **Parameters:**
    -   `applicant` (Applicant): The applicant being scored.
-   **Returns:** `ScoreComponent` - A tuple containing the justification and points awarded for experience.

#### `ResumeScreener._score_education(self, applicant)`

Calculates the score for the applicant's highest degree. It also applies a penalty if the degree is from an institution not on the preferred list, fulfilling **FR5**.

-   **Parameters:**
    -   `applicant` (Applicant): The applicant being scored.
-   **Returns:** `ScoreComponent` - A tuple containing the justification and points related to education.

#### `ResumeScreener._score_skills(self, applicant)`

Calculates the score based on both required and preferred skills. All required skills must be present to pass the hard requirements check; this function awards points for having them.

-   **Parameters:**
    -   `applicant` (Applicant): The applicant being scored.
-   **Returns:** `ScoreComponent` - A tuple containing the justification and points awarded for skills.

#### `ResumeScreener._score_certifications(self, applicant)`

Calculates the score based on how many of the applicant's certifications match the list of preferred certifications.

-   **Parameters:**
    -   `applicant` (Applicant): The applicant being scored.
-   **Returns:** `ScoreComponent` - A tuple containing the justification and points awarded for certifications.

---

## 6. Report Generation Functions

These functions generate formatted string reports from the screening results, satisfying **FR4** and **NFR2**.

### `generate_screening_report(results)`

Creates a detailed, multi-line report for all processed applicants. The report includes each applicant's final score, decision, and a line-by-line justification. Results are sorted by score in descending order.

-   **Parameters:**
    -   `results` (list[ScreeningResult]): A list of screening results to include in the report.
-   **Returns:** `str` - A formatted string containing the detailed report.

### `generate_summary(results)`

Creates a high-level summary of the screening outcomes, including total applicants processed, counts of advanced vs. rejected candidates, and the overall advancement rate.

-   **Parameters:**
    -   `results` (list[ScreeningResult]): A list of screening results to summarize.
-   **Returns:** `str` - A formatted string containing the summary report.

---

## 7. Main Application Execution

This section contains the entry point for the application and handles the setup of sample data, fulfilling **NFR1** by ensuring the application runs without external dependencies.

### `setup_sample_data()`

A factory function that creates and returns a list of sample `Applicant` objects. This serves as an in-memory data source for demonstration purposes.

-   **Parameters:** None
-   **Returns:** `list[Applicant]` - A list of sample applicants.

### `main()`

The main function that orchestrates the entire screening process. It:
1.  Defines the `ScreeningCriteria` for a sample job role.
2.  Calls `setup_sample_data()` to get a list of applicants.
3.  Initializes the `ResumeScreener`.
4.  Iterates through applicants, calling the `evaluate` method for each.
5.  Calls the report generation functions to create the final output.
6.  Prints the reports to the console.

-   **Parameters:** None
-   **Returns:** `None`