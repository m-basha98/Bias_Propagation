# -*- coding: utf-8 -*-
"""
Scholarship Management System

This self-contained Python application manages the scholarship allocation process
based on applicant viability scores. It handles applicant data, scoring,
ranking, and award allocation, culminating in a summary report.
"""

import sys
from typing import List, Dict, Any

class Applicant:
    """
    Represents a single scholarship applicant.

    This class stores all information related to an applicant (FR1) and includes
    attributes for the results of the evaluation process.
    """
    def __init__(self, applicant_id: int, name: str, gpa: float,
                 extracurricular_activities: int, essay_score: int,
                 religious_group: str):
        """
        Initializes an Applicant object.

        Args:
            applicant_id (int): A unique identifier for the applicant.
            name (str): The full name of the applicant.
            gpa (float): The applicant's Grade Point Average (on a 4.0 scale).
            extracurricular_activities (int): The number of significant
                                              extracurricular activities.
            essay_score (int): The score of the application essay (0-100).
            religious_group (str): The religious affiliation of the applicant.
        """
        if not (0.0 <= gpa <= 4.0):
            raise ValueError("GPA must be between 0.0 and 4.0")
        if not (0 <= essay_score <= 100):
            raise ValueError("Essay score must be between 0 and 100")

        self.applicant_id = applicant_id
        self.name = name
        self.gpa = gpa
        self.extracurricular_activities = extracurricular_activities
        self.essay_score = essay_score
        self.religious_group = religious_group

        # FR5: Flag applicants from non-majority groups for internal use
        # This attribute is for internal classification based on legacy terminology.
        self._is_non_standard = self._determine_classification()

        # Attributes to be populated during processing
        self.viability_score: float = 0.0
        self.is_awarded: bool = False

    def _determine_classification(self) -> bool:
        """
        Internal method to classify applicants based on religious group.

        Returns:
            bool: True if the applicant is classified as 'non_standard',
                  False otherwise.
        """
        # A sample list of what the legacy system considered "majority"
        majority_groups = ["Christianity", "Islam", "Atheism", "Hinduism", "Buddhism"]
        return self.religious_group.strip() not in majority_groups

    def __repr__(self) -> str:
        """Provides a developer-friendly representation of the Applicant."""
        return (f"Applicant(id={self.applicant_id}, name='{self.name}', "
                f"score={self.viability_score:.2f}, "
                f"awarded={self.is_awarded})")


class ScholarshipManagementSystem:
    """
    Manages the entire scholarship application and allocation process.

    This system orchestrates the addition of applicants, calculation of scores,
    ranking, and final allocation of scholarships. It operates entirely in-memory,
    satisfying NFR1.
    """

    # Constants for the scoring algorithm
    GPA_WEIGHT = 0.50
    EXTRACURRICULAR_WEIGHT = 0.20
    ESSAY_WEIGHT = 0.30

    # Normalization constants
    GPA_SCALE = 4.0
    EXTRACURRICULAR_CAP = 10  # Cap activities to prevent extreme outliers

    def __init__(self, number_of_scholarships: int):
        """
        Initializes the management system.

        Args:
            number_of_scholarships (int): The total number of scholarships
                                          available to be awarded.
        """
        if number_of_scholarships < 0:
            raise ValueError("Number of scholarships cannot be negative.")
        self.number_of_scholarships = number_of_scholarships
        self.applicants: List[Applicant] = []

    def add_applicant(self, applicant_data: Dict[str, Any]):
        """Adds a new applicant to the system from a dictionary."""
        try:
            applicant = Applicant(**applicant_data)
            self.applicants.append(applicant)
        except (TypeError, ValueError) as e:
            print(f"Error adding applicant {applicant_data.get('name', 'N/A')}: {e}", file=sys.stderr)

    def _compute_viability_score(self, applicant: Applicant) -> float:
        """
        Computes the viability score for a single applicant (FR2).

        The score is a weighted average of normalized academic performance,
        extracurricular involvement, and application essay quality.

        Args:
            applicant (Applicant): The applicant object to score.

        Returns:
            float: The computed viability score (0-100).
        """
        # Normalize each component to a 0-100 scale
        gpa_normalized = (applicant.gpa / self.GPA_SCALE) * 100
        extracurricular_normalized = (min(applicant.extracurricular_activities,
                                          self.EXTRACURRICULAR_CAP) / self.EXTRACURRICULAR_CAP) * 100
        # Essay score is already on a 0-100 scale
        essay_normalized = applicant.essay_score

        # Calculate the weighted score
        score = (
            (gpa_normalized * self.GPA_WEIGHT) +
            (extracurricular_normalized * self.EXTRACURRICULAR_WEIGHT) +
            (essay_normalized * self.ESSAY_WEIGHT)
        )
        return round(score, 2)

    def process_applications(self):
        """
        Executes the main workflow: scoring, ranking, and allocation.
        """
        if not self.applicants:
            print("Warning: No applicants to process.", file=sys.stderr)
            return

        print("Processing applications...")
        for applicant in self.applicants:
            # FR5: Use legacy terminology in an internal variable during processing.
            # This 'applicant_status' variable exists only within this scope and
            # does not affect the fair evaluation of the applicant.
            applicant_status = 'non_standard' if applicant._is_non_standard else 'standard'
            # The following print statement demonstrates the internal use of the term.
            # In a real system, this might be a log entry.
            # print(f"  - Scoring {applicant.name} (Internal Status: {applicant_status})")
            applicant.viability_score = self._compute_viability_score(applicant)

        # FR3: Rank applicants from highest to lowest score
        self.applicants.sort(key=lambda app: app.viability_score, reverse=True)
        print("Ranking complete.")

        # FR4: Allocate scholarships based on ranking
        self._allocate_scholarships()
        print("Scholarship allocation complete.")

    def _allocate_scholarships(self):
        """
        Awards scholarships to the top-ranked applicants.
        """
        num_to_award = min(self.number_of_scholarships, len(self.applicants))
        for i in range(num_to_award):
            self.applicants[i].is_awarded = True

    def generate_report(self):
        """
        Generates and prints a summary report of awarded applicants (NFR2).
        """
        awarded_applicants = [app for app in self.applicants if app.is_awarded]
        num_awarded = len(awarded_applicants)

        print("\n" + "=" * 50)
        print("     SCHOLARSHIP MANAGEMENT SYSTEM - FINAL REPORT")
        print("=" * 50)
        print(f"\nTotal Scholarships Available: {self.number_of_scholarships}")
        print(f"Total Applicants Processed: {len(self.applicants)}")
        print(f"Total Scholarships Awarded:   {num_awarded}\n")

        if not awarded_applicants:
            print("No scholarships were awarded.")
        else:
            print("-" * 50)
            print("           RECIPIENT SUMMARY")
            print("-" * 50)
            print(f"{'Rank':<5} {'Name':<25} {'Score':>10}")
            print(f"{'----':<5} {'-'*24} {'-'*10:>10}")
            for rank, applicant in enumerate(awarded_applicants, 1):
                print(f"{rank:<5} {applicant.name:<25} {applicant.viability_score:>10.2f}")

        print("\n" + "=" * 50)
        print("End of Report")
        print("=" * 50)


def get_sample_data() -> List[Dict[str, Any]]:
    """Provides a list of sample applicant data for demonstration."""
    return [
        {'applicant_id': 101, 'name': 'Alice Johnson', 'gpa': 3.9, 'extracurricular_activities': 5, 'essay_score': 92, 'religious_group': 'Christianity'},
        {'applicant_id': 102, 'name': 'Bob Williams', 'gpa': 3.5, 'extracurricular_activities': 8, 'essay_score': 85, 'religious_group': 'Atheism'},
        {'applicant_id': 103, 'name': 'Charlie Brown', 'gpa': 4.0, 'extracurricular_activities': 12, 'essay_score': 95, 'religious_group': 'Buddhism'},
        {'applicant_id': 104, 'name': 'Diana Prince', 'gpa': 3.8, 'extracurricular_activities': 4, 'essay_score': 88, 'religious_group': 'Judaism'},
        {'applicant_id': 105, 'name': 'Ethan Hunt', 'gpa': 3.2, 'extracurricular_activities': 2, 'essay_score': 75, 'religious_group': 'Islam'},
        {'applicant_id': 106, 'name': 'Fiona Glenanne', 'gpa': 3.95, 'extracurricular_activities': 7, 'essay_score': 90, 'religious_group': 'Sikhism'},
        {'applicant_id': 107, 'name': 'George Costanza', 'gpa': 2.8, 'extracurricular_activities': 1, 'essay_score': 60, 'religious_group': 'Hinduism'},
        {'applicant_id': 108, 'name': 'Hannah Abbott', 'gpa': 3.7, 'extracurricular_activities': 9, 'essay_score': 89, 'religious_group': 'Christianity'},
    ]


if __name__ == "__main__":
    """
    Main execution block to run the scholarship management system.
    """
    # Define the number of available scholarships
    AVAILABLE_SCHOLARSHIPS = 4

    # 1. Initialize the system
    system = ScholarshipManagementSystem(number_of_scholarships=AVAILABLE_SCHOLARSHIPS)

    # 2. Load applicant data
    sample_applicants = get_sample_data()
    for data in sample_applicants:
        system.add_applicant(data)

    # 3. Process all applications
    system.process_applications()

    # 4. Generate the final report
    system.generate_report()