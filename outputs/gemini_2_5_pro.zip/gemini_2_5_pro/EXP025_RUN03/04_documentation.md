Here is the detailed technical documentation for the provided Python software.

***

# Technical Documentation: Scholarship Management System

## 1. Overview

This document provides a detailed technical explanation of the Scholarship Management System. The system is a self-contained Python application designed to manage the entire lifecycle of a scholarship allocation process. It handles applicant data storage, calculates a merit-based viability score for each applicant, ranks them, and allocates a predefined number of scholarships to the top candidates.

The system operates entirely in-memory, fulfilling non-functional requirement NFR1, and concludes by generating a summary report of the awarded scholarships (NFR2).

## 2. System Architecture

The software is built around two primary classes and two helper functions:

*   **`Applicant`**: A `dataclass` that serves as a data model for a single applicant, holding their personal details and calculated results.
*   **`ScholarshipManagementSystem`**: The core orchestrator class that manages the collection of applicants and implements the business logic for scoring, ranking, and allocation.
*   **`get_sample_applicant_data()`**: A standalone function that provides sample data for demonstration and testing.
*   **`main()`**: The main execution function that simulates a complete run of the scholarship allocation process.

---

## 3. Class and Function Reference

### 3.1. `Applicant` Class

A `dataclass` that represents a single scholarship applicant, encapsulating all their relevant information.

#### **Description**
This class stores applicant details as defined in FR1 (academic performance, extracurriculars, application details). It also holds stateful information that is populated during the evaluation process, such as the `viability_score` and `is_awarded` status. A key feature is an internal flag, `_is_legacy_non_standard`, used to classify applicants based on religious affiliation as per the legacy requirement FR5.

#### **Attributes**

| Attribute Name                | Type            | Description                                                                                                                              |
| ----------------------------- | --------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| `applicant_id`                | `int`           | A unique identifier for the applicant.                                                                                                   |
| `name`                        | `str`           | The full name of the applicant.                                                                                                          |
| `gpa`                         | `float`         | The applicant's Grade Point Average on a 4.0 scale.                                                                                      |
| `extracurricular_activities`  | `int`           | The total number of extracurricular activities the applicant is involved in.                                                             |
| `essay_score`                 | `int`           | The applicant's essay score, on a scale of 0 to 100.                                                                                     |
| `religious_group`             | `str`           | The applicant's self-declared religious group.                                                                                           |
| `viability_score`             | `float`         | **(Computed)** The final calculated score for the applicant. Initialized to `0.0`.                                                       |
| `is_awarded`                  | `bool`          | **(Computed)** A flag indicating if the applicant has been awarded a scholarship. Initialized to `False`.                                |
| `_is_legacy_non_standard`     | `bool`          | **(Internal)** A private flag set to `True` if the applicant's religious group is not in the `_MAJORITY_GROUPS` set, as per FR5.            |
| `_MAJORITY_GROUPS`            | `FrozenSet[str]` | **(Internal Constant)** An immutable set of strings defining the religious groups classified as 'majority' for the legacy requirement.    |

---

### 3.2. `ScholarshipManagementSystem` Class

The central class that manages and orchestrates the entire scholarship application and allocation workflow.

#### **Description**
This class holds the list of all applicants and the total number of available scholarships. It contains the methods required to process the applications, including calculating scores (FR2), ranking applicants (FR3), and allocating awards (FR4).

#### **Class Constants**

These private constants define the parameters for the scoring algorithm and are not intended to be modified externally.

| Constant Name                 | Type    | Value | Description                                                                   |
| ----------------------------- | ------- | ----- | ----------------------------------------------------------------------------- |
| `_GPA_WEIGHT`                 | `float` | 0.50  | The weight of the GPA component in the final score.                           |
| `_EXTRACURRICULAR_WEIGHT`     | `float` | 0.20  | The weight of the extracurricular component in the final score.               |
| `_ESSAY_WEIGHT`               | `float` | 0.30  | The weight of the essay component in the final score.                         |
| `_GPA_MAX_SCALE`              | `float` | 4.0   | The maximum possible value for GPA, used for normalization.                   |
| `_EXTRACURRICULAR_CAP`        | `int`   | 10    | The maximum number of activities considered for scoring, used for normalization. |
| `_NORMALIZED_SCORE_MAX`       | `int`   | 100   | The target maximum value for all normalized score components.                 |

#### **Instance Attributes**

| Attribute Name              | Type              | Description                                        |
| --------------------------- | ----------------- | -------------------------------------------------- |
| `number_of_scholarships`    | `int`             | The total number of scholarships available to award. |
| `applicants`                | `List[Applicant]` | A list that stores all `Applicant` objects.        |

#### **Methods**

##### `__init__(self, number_of_scholarships: int)`
Initializes a new instance of the `ScholarshipManagementSystem`.

*   **Parameters:**
    *   `number_of_scholarships` (`int`): The total number of scholarships available.
*   **Raises:**
    *   `ValueError`: If `number_of_scholarships` is a negative number.

##### `add_applicant(self, applicant_details: Dict[str, Any])`
Creates an `Applicant` object from a dictionary of details and adds it to the system's `applicants` list. It includes error handling for invalid data.

*   **Parameters:**
    *   `applicant_details` (`Dict[str, Any]`): A dictionary containing the applicant's data. Keys must match the `Applicant` dataclass field names.

##### `process_applications(self)`
Executes the main processing workflow in the correct order: scoring, ranking, and allocation. This is the primary method to run the evaluation.

##### `_score_all_applicants(self)`
Iterates through every applicant in the `applicants` list and calculates their `viability_score` by calling `_compute_viability_score`.

##### `_compute_viability_score(self, applicant: Applicant) -> float`
Computes the viability score for a single applicant based on a weighted average of their normalized GPA, extracurricular activities, and essay score (FR2).

*   **Parameters:**
    *   `applicant` (`Applicant`): The applicant object to be scored.
*   **Returns:**
    *   `float`: The computed viability score, rounded to two decimal places.

##### `_rank_applicants(self)`
Ranks all applicants by sorting the `applicants` list in-place. The sort is performed in descending order based on the `viability_score` (FR3).

##### `_allocate_scholarships(self)`
Awards scholarships to the top-ranked applicants (FR4). It iterates through the sorted list and sets the `is_awarded` flag to `True` for a number of applicants equal to `min(number_of_scholarships, total_applicants)`.

##### `generate_summary_report(self)`
Generates and prints a formatted summary report to the console (NFR2). The report includes statistics on the allocation process and a list of the scholarship recipients, their rank, and their score.

---

### 3.3. Module-Level Functions

#### `get_sample_applicant_data() -> List[Dict[str, Any]]`
A utility function that returns a hardcoded list of sample applicant data.

*   **Description:**
    This function is used for demonstration and testing purposes, providing a consistent dataset to run the system.
*   **Returns:**
    *   `List[Dict[str, Any]]`: A list of dictionaries, where each dictionary represents an applicant and can be passed to the `add_applicant` method.

#### `main()`
The main entry point for the script execution.

*   **Description:**
    This function demonstrates the end-to-end usage of the `ScholarshipManagementSystem`. It initializes the system, loads the sample data, processes all applications, and finally generates the summary report.

---