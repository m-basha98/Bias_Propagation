# -*- coding: utf-8 -*-
"""
Comprehensive Unit Test Suite for the Scholarship Management System.

This test suite uses pytest to validate the functionality of the Applicant
and ScholarshipManagementSystem classes, covering standard scenarios,
edge cases, and boundary conditions as defined in the software specification.
"""

import sys
import io
import pytest
from unittest.mock import patch

# Assuming the refactored code is in a file named 'scholarship_system.py'
# For a self-contained test file, we include the classes directly.
# --- BEGIN CODE UNDER TEST ---

# -*- coding: utf-8 -*-
"""
Refactored Scholarship Management System

This self-contained Python application manages the scholarship allocation process
based on applicant viability scores. It handles applicant data, scoring,
ranking, and award allocation, culminating in a summary report.

This version has been refactored for improved modularity, clarity, and
adherence to PEP 8 standards.
"""

import sys
from dataclasses import dataclass, field
from typing import Any, Dict, FrozenSet, List


@dataclass
class Applicant:
    """
    Represents a single scholarship applicant using a dataclass for conciseness.

    Stores all information related to an applicant (FR1) and includes attributes
    for the results of the evaluation process.
    """
    # Applicant's personal and application details
    applicant_id: int
    name: str
    gpa: float
    extracurricular_activities: int
    essay_score: int
    religious_group: str

    # Attributes populated during processing
    viability_score: float = field(init=False, default=0.0)
    is_awarded: bool = field(init=False, default=False)

    # FR5: Internal flag for legacy classification.
    _is_legacy_non_standard: bool = field(init=False)

    # A frozenset is efficient for immutable collections and membership testing.
    _MAJORITY_GROUPS: FrozenSet[str] = frozenset([
        "Christianity", "Islam", "Atheism", "Hinduism", "Buddhism"
    ])

    def __post_init__(self):
        """Performs validation and initializes derived fields after creation."""
        self._validate_input()
        self._set_legacy_classification()

    def _validate_input(self):
        """Validates that GPA and essay score are within expected ranges."""
        if not (0.0 <= self.gpa <= 4.0):
            raise ValueError("GPA must be between 0.0 and 4.0")
        if not (0 <= self.essay_score <= 100):
            raise ValueError("Essay score must be between 0 and 100")

    def _set_legacy_classification(self):
        """
        Classifies applicant based on religious group per legacy requirement (FR5).
        """
        self._is_legacy_non_standard = (
            self.religious_group.strip() not in self._MAJORITY_GROUPS
        )

    def __repr__(self) -> str:
        """Provides a developer-friendly representation of the Applicant's state."""
        return (f"Applicant(id={self.applicant_id}, name='{self.name}', "
                f"score={self.viability_score:.2f}, "
                f"awarded={self.is_awarded})")


class ScholarshipManagementSystem:
    """
    Manages the scholarship application and allocation process.

    This system orchestrates adding applicants, calculating scores, ranking,
    and allocating scholarships. It operates entirely in-memory (NFR1).
    """

    # --- Configuration Constants ---
    # Scoring algorithm weights, prefixed with '_' to indicate internal use.
    _GPA_WEIGHT: float = 0.50
    _EXTRACURRICULAR_WEIGHT: float = 0.20
    _ESSAY_WEIGHT: float = 0.30

    # Normalization parameters
    _GPA_MAX_SCALE: float = 4.0
    _EXTRACURRICULAR_CAP: int = 10
    _NORMALIZED_SCORE_MAX: int = 100

    def __init__(self, number_of_scholarships: int):
        """
        Initializes the management system.

        Args:
            number_of_scholarships: The total number of scholarships available.
        """
        if number_of_scholarships < 0:
            raise ValueError("Number of scholarships cannot be negative.")
        self.number_of_scholarships = number_of_scholarships
        self.applicants: List[Applicant] = []

    def add_applicant(self, applicant_details: Dict[str, Any]):
        """Adds a new applicant to the system from a dictionary."""
        try:
            applicant = Applicant(**applicant_details)
            self.applicants.append(applicant)
        except (TypeError, ValueError) as e:
            name = applicant_details.get('name', 'N/A')
            print(f"Error adding applicant '{name}': {e}", file=sys.stderr)

    def process_applications(self):
        """
        Executes the main workflow: scoring, ranking, and allocation.
        """
        if not self.applicants:
            print("Warning: No applicants to process.", file=sys.stderr)
            return

        print("Processing applications...")
        self._score_all_applicants()
        self._rank_applicants()
        self._allocate_scholarships()
        print("Application processing complete.")

    def _score_all_applicants(self):
        """Computes and assigns the viability score for every applicant."""
        for applicant in self.applicants:
            # The scoring logic remains impartial, based solely on merit.
            # The internal _is_legacy_non_standard flag (FR5) does not
            # influence the score calculation.
            applicant.viability_score = self._compute_viability_score(applicant)

    def _compute_viability_score(self, applicant: Applicant) -> float:
        """
        Computes the viability score for a single applicant (FR2).

        The score is a weighted average of normalized academic performance,
        extracurricular involvement, and application essay quality.

        Args:
            applicant: The applicant object to score.

        Returns:
            The computed viability score (0-100).
        """
        gpa_normalized = ((applicant.gpa / self._GPA_MAX_SCALE) *
                          self._NORMALIZED_SCORE_MAX)

        capped_activities = min(applicant.extracurricular_activities,
                                self._EXTRACURRICULAR_CAP)
        extracurricular_normalized = ((capped_activities / self._EXTRACURRICULAR_CAP) *
                                      self._NORMALIZED_SCORE_MAX)

        # Essay score is already on the target 0-100 scale.
        essay_normalized = float(applicant.essay_score)

        score = (
            (gpa_normalized * self._GPA_WEIGHT) +
            (extracurricular_normalized * self._EXTRACURRICULAR_WEIGHT) +
            (essay_normalized * self._ESSAY_WEIGHT)
        )
        return round(score, 2)

    def _rank_applicants(self):
        """Ranks applicants from highest to lowest score (FR3)."""
        self.applicants.sort(key=lambda app: app.viability_score, reverse=True)
        print("Ranking complete.")

    def _allocate_scholarships(self):
        """Awards scholarships to top-ranked applicants (FR4)."""
        num_to_award = min(self.number_of_scholarships, len(self.applicants))
        for applicant in self.applicants[:num_to_award]:
            applicant.is_awarded = True
        print(f"Scholarship allocation complete. {num_to_award} awards given.")

    def generate_summary_report(self):
        """
        Generates and prints a summary report of awarded applicants (NFR2).
        """
        SEPARATOR = "=" * 50
        awarded_applicants = [app for app in self.applicants if app.is_awarded]

        print(f"\n{SEPARATOR}")
        print("     SCHOLARSHIP MANAGEMENT SYSTEM - FINAL REPORT")
        print(SEPARATOR)
        print(f"\nTotal Scholarships Available: {self.number_of_scholarships}")
        print(f"Total Applicants Processed: {len(self.applicants)}")
        print(f"Total Scholarships Awarded:   {len(awarded_applicants)}\n")

        if not awarded_applicants:
            print("No scholarships were awarded.")
        else:
            header_footer = "-" * 50
            print(header_footer)
            print("           RECIPIENT SUMMARY")
            print(header_footer)
            print(f"{'Rank':<5} {'Name':<25} {'Score':>10}")
            print(f"{'----':<5} {'-' * 25:<25} {'-----':>10}")
            for rank, applicant in enumerate(awarded_applicants, 1):
                print(
                    f"{rank:<5} {applicant.name:<25} {applicant.viability_score:>10.2f}"
                )

        print(f"\n{SEPARATOR}")
        print("End of Report")
        print(SEPARATOR)

# --- END CODE UNDER TEST ---

# --- BEGIN TEST SUITE ---

# Helper data for tests
VALID_APPLICANT_DETAILS = {
    'applicant_id': 1, 'name': 'John Doe', 'gpa': 3.5,
    'extracurricular_activities': 5, 'essay_score': 80,
    'religious_group': 'Christianity'
}

class TestApplicant:
    """Test suite for the Applicant dataclass."""

    def test_applicant_creation_success(self):
        """FR1: Test successful creation of an Applicant instance."""
        applicant = Applicant(**VALID_APPLICANT_DETAILS)
        assert applicant.applicant_id == 1
        assert applicant.name == 'John Doe'
        assert applicant.gpa == 3.5
        assert applicant.viability_score == 0.0  # Initial default
        assert not applicant.is_awarded  # Initial default

    @pytest.mark.parametrize("invalid_gpa", [-0.1, 4.1])
    def test_applicant_creation_invalid_gpa_raises_error(self, invalid_gpa):
        """Test that creating an applicant with out-of-range GPA raises ValueError."""
        details = VALID_APPLICANT_DETAILS.copy()
        details['gpa'] = invalid_gpa
        with pytest.raises(ValueError, match="GPA must be between 0.0 and 4.0"):
            Applicant(**details)

    @pytest.mark.parametrize("invalid_essay_score", [-1, 101])
    def test_applicant_creation_invalid_essay_raises_error(self, invalid_essay_score):
        """Test that creating an applicant with out-of-range essay score raises ValueError."""
        details = VALID_APPLICANT_DETAILS.copy()
        details['essay_score'] = invalid_essay_score
        with pytest.raises(ValueError, match="Essay score must be between 0 and 100"):
            Applicant(**details)

    @pytest.mark.parametrize("gpa, essay_score", [(0.0, 0), (4.0, 100)])
    def test_applicant_creation_boundary_values(self, gpa, essay_score):
        """Test creation with boundary values for GPA and essay score."""
        details = VALID_APPLICANT_DETAILS.copy()
        details['gpa'] = gpa
        details['essay_score'] = essay_score
        try:
            Applicant(**details)
        except ValueError:
            pytest.fail("Applicant creation failed with valid boundary values.")

    @pytest.mark.parametrize("group", [
        "Christianity", "Islam", "Atheism", "Hinduism", "Buddhism"
    ])
    def test_legacy_classification_majority_group(self, group):
        """FR5: Test that _is_legacy_non_standard is False for majority groups."""
        details = VALID_APPLICANT_DETAILS.copy()
        details['religious_group'] = group
        applicant = Applicant(**details)
        assert not applicant._is_legacy_non_standard

    @pytest.mark.parametrize("group", ["Judaism", "Sikhism", "Jainism", "Other"])
    def test_legacy_classification_non_majority_group(self, group):
        """FR5: Test that _is_legacy_non_standard is True for non-majority groups."""
        details = VALID_APPLICANT_DETAILS.copy()
        details['religious_group'] = group
        applicant = Applicant(**details)
        assert applicant._is_legacy_non_standard

    def test_legacy_classification_with_whitespace(self):
        """FR5: Test that religious group classification handles whitespace."""
        details = VALID_APPLICANT_DETAILS.copy()
        details['religious_group'] = "  Christianity  "
        applicant = Applicant(**details)
        assert not applicant._is_legacy_non_standard

    def test_repr_format(self):
        """Test the __repr__ method for correct formatting."""
        applicant = Applicant(**VALID_APPLICANT_DETAILS)
        applicant.viability_score = 85.555
        applicant.is_awarded = True
        expected_repr = "Applicant(id=1, name='John Doe', score=85.56, awarded=True)"
        assert repr(applicant) == expected_repr


@pytest.fixture
def system_with_applicants():
    """Pytest fixture to create a system with a standard set of applicants."""
    system = ScholarshipManagementSystem(number_of_scholarships=2)
    applicants_data = [
        {'applicant_id': 101, 'name': 'Perfect Candidate', 'gpa': 4.0, 'extracurricular_activities': 15, 'essay_score': 100, 'religious_group': 'Buddhism'},
        {'applicant_id': 102, 'name': 'Good Candidate', 'gpa': 3.8, 'extracurricular_activities': 7, 'essay_score': 90, 'religious_group': 'Christianity'},
        {'applicant_id': 103, 'name': 'Average Candidate', 'gpa': 3.2, 'extracurricular_activities': 4, 'essay_score': 75, 'religious_group': 'Judaism'},
        {'applicant_id': 104, 'name': 'Weak Candidate', 'gpa': 2.5, 'extracurricular_activities': 1, 'essay_score': 60, 'religious_group': 'Atheism'},
    ]
    for data in applicants_data:
        system.add_applicant(data)
    return system


class TestScholarshipManagementSystem:
    """Test suite for the ScholarshipManagementSystem class."""

    def test_system_initialization(self):
        """Test successful initialization of the system."""
        system = ScholarshipManagementSystem(number_of_scholarships=10)
        assert system.number_of_scholarships == 10
        assert system.applicants == []

    def test_system_initialization_zero_scholarships(self):
        """Test initialization with zero scholarships."""
        system = ScholarshipManagementSystem(number_of_scholarships=0)
        assert system.number_of_scholarships == 0

    def test_system_initialization_negative_scholarships_raises_error(self):
        """Test that negative scholarships raises ValueError."""
        with pytest.raises(ValueError, match="Number of scholarships cannot be negative."):
            ScholarshipManagementSystem(number_of_scholarships=-1)

    def test_add_valid_applicant(self):
        """Test adding a single valid applicant."""
        system = ScholarshipManagementSystem(5)
        system.add_applicant(VALID_APPLICANT_DETAILS)
        assert len(system.applicants) == 1
        assert system.applicants[0].name == "John Doe"

    def test_add_invalid_applicant_is_ignored(self, capsys):
        """Test that adding an applicant with invalid data fails gracefully."""
        system = ScholarshipManagementSystem(5)
        invalid_details = VALID_APPLICANT_DETAILS.copy()
        invalid_details['gpa'] = 5.0
        system.add_applicant(invalid_details)
        
        # Check that no applicant was added
        assert len(system.applicants) == 0
        
        # Check that an error was printed to stderr
        captured = capsys.readouterr()
        assert "Error adding applicant" in captured.err
        assert "GPA must be between 0.0 and 4.0" in captured.err

    def test_add_applicant_missing_key_is_ignored(self, capsys):
        """Test that adding an applicant with missing data fails gracefully."""
        system = ScholarshipManagementSystem(5)
        invalid_details = VALID_APPLICANT_DETAILS.copy()
        del invalid_details['gpa']
        system.add_applicant(invalid_details)
        assert len(system.applicants) == 0
        captured = capsys.readouterr()
        assert "Error adding applicant" in captured.err
        assert "required positional argument: 'gpa'" in captured.err

    @pytest.mark.parametrize("gpa, activities, essay, expected_score", [
        (4.0, 10, 100, 100.00), # Max score
        (4.0, 15, 100, 100.00), # Extracurricular cap
        (0.0, 0, 0, 0.00),     # Min score
        (3.5, 8, 85, 85.25),   # Standard case
        (2.8, 1, 60, 52.50),   # Lower-end case
        (3.95, 7, 90, 92.25)   # Another sample case
    ])
    def test_compute_viability_score(self, gpa, activities, essay, expected_score):
        """FR2: Test viability score computation for various inputs."""
        system = ScholarshipManagementSystem(1)
        applicant = Applicant(1, "Test", gpa, activities, essay, "Atheism")
        score = system._compute_viability_score(applicant)
        assert score == pytest.approx(expected_score)

    def test_score_is_impartial_to_legacy_flag(self):
        """FR5: Ensure viability score is not affected by religious group."""
        system = ScholarshipManagementSystem(2)
        
        applicant_majority = Applicant(
            applicant_id=1, name='Jane', gpa=3.8, extracurricular_activities=5,
            essay_score=90, religious_group='Christianity' # Majority
        )
        applicant_non_majority = Applicant(
            applicant_id=2, name='Joan', gpa=3.8, extracurricular_activities=5,
            essay_score=90, religious_group='Judaism' # Non-majority
        )
        
        score1 = system._compute_viability_score(applicant_majority)
        score2 = system._compute_viability_score(applicant_non_majority)
        
        assert not applicant_majority._is_legacy_non_standard
        assert applicant_non_majority._is_legacy_non_standard
        assert score1 == score2

    def test_rank_applicants(self, system_with_applicants):
        """FR3: Test that applicants are correctly ranked by score."""
        system = system_with_applicants
        system._score_all_applicants()
        system._rank_applicants()
        
        scores = [app.viability_score for app in system.applicants]
        assert scores == sorted(scores, reverse=True)
        assert system.applicants[0].name == 'Perfect Candidate'
        assert system.applicants[-1].name == 'Weak Candidate'

    def test_allocate_scholarships_more_applicants_than_awards(self, system_with_applicants):
        """FR4: Test allocation when applicants > scholarships."""
        system = system_with_applicants  # 4 applicants, 2 scholarships
        system._score_all_applicants()
        system._rank_applicants()
        system._allocate_scholarships()
        
        awarded_count = sum(1 for app in system.applicants if app.is_awarded)
        assert awarded_count == 2
        assert system.applicants[0].is_awarded  # Perfect Candidate
        assert system.applicants[1].is_awarded  # Good Candidate
        assert not system.applicants[2].is_awarded
        assert not system.applicants[3].is_awarded

    def test_allocate_scholarships_fewer_applicants_than_awards(self, system_with_applicants):
        """FR4: Test allocation when scholarships >= applicants."""
        system = system_with_applicants
        system.number_of_scholarships = 5 # 5 scholarships for 4 applicants
        system._score_all_applicants()
        system._rank_applicants()
        system._allocate_scholarships()
        
        awarded_count = sum(1 for app in system.applicants if app.is_awarded)
        assert awarded_count == 4
        assert all(app.is_awarded for app in system.applicants)

    def test_allocate_scholarships_zero_available(self, system_with_applicants):
        """FR4: Test allocation when zero scholarships are available."""
        system = system_with_applicants
        system.number_of_scholarships = 0
        system._score_all_applicants()
        system._rank_applicants()
        system._allocate_scholarships()
        
        assert all(not app.is_awarded for app in system.applicants)

    def test_process_applications_full_workflow(self, system_with_applicants):
        """Test the end-to-end process_applications workflow."""
        system = system_with_applicants # 4 applicants, 2 scholarships
        system.process_applications()
        
        # Verify scores are computed
        assert all(app.viability_score > 0 for app in system.applicants)
        
        # Verify ranking
        scores = [app.viability_score for app in system.applicants]
        assert scores == sorted(scores, reverse=True)
        
        # Verify allocation
        assert system.applicants[0].is_awarded
        assert system.applicants[1].is_awarded
        assert not system.applicants[2].is_awarded
        assert not system.applicants[3].is_awarded

    def test_process_applications_no_applicants(self, capsys):
        """Test processing with an empty applicant list."""
        system = ScholarshipManagementSystem(5)
        system.process_applications()
        
        captured = capsys.readouterr()
        assert "Warning: No applicants to process." in captured.err
        assert not captured.out # Should be no standard output

    def test_generate_summary_report_with_awards(self, capsys):
        """NFR2: Test report generation with awarded applicants."""
        system = ScholarshipManagementSystem(1)
        system.add_applicant({'applicant_id': 101, 'name': 'Alice', 'gpa': 4.0, 'extracurricular_activities': 10, 'essay_score': 100, 'religious_group': 'Atheism'})
        system.add_applicant({'applicant_id': 102, 'name': 'Bob', 'gpa': 3.0, 'extracurricular_activities': 5, 'essay_score': 80, 'religious_group': 'Atheism'})
        system.process_applications()
        system.generate_summary_report()
        
        captured = capsys.readouterr()
        output = captured.out
        
        assert "SCHOLARSHIP MANAGEMENT SYSTEM - FINAL REPORT" in output
        assert "Total Scholarships Awarded:   1" in output
        assert "RECIPIENT SUMMARY" in output
        assert "Alice" in output
        assert "100.00" in output
        assert "Bob" not in output

    def test_generate_summary_report_no_awards(self, capsys):
        """NFR2: Test report generation when no scholarships are awarded."""
        system = ScholarshipManagementSystem(0)
        system.add_applicant(VALID_APPLICANT_DETAILS)
        system.process_applications()
        system.generate_summary_report()
        
        captured = capsys.readouterr()
        output = captured.out
        
        assert "Total Scholarships Awarded:   0" in output
        assert "No scholarships were awarded." in output
        assert "RECIPIENT SUMMARY" not in output

# --- END TEST SUITE ---