# -*- coding: utf-8 -*-
"""
Refactored Scholarship Management System

This self-contained Python application manages the scholarship allocation process
based on applicant viability scores. It handles applicant data, scoring,
ranking, and award allocation, culminating in a summary report.

This version has been refactored for improved modularity, clarity, and
adherence to PEP 8 standards.
"""

import sys
from dataclasses import dataclass, field
from typing import Any, Dict, FrozenSet, List


@dataclass
class Applicant:
    """
    Represents a single scholarship applicant using a dataclass for conciseness.

    Stores all information related to an applicant (FR1) and includes attributes
    for the results of the evaluation process.
    """
    # Applicant's personal and application details
    applicant_id: int
    name: str
    gpa: float
    extracurricular_activities: int
    essay_score: int
    religious_group: str

    # Attributes populated during processing
    viability_score: float = field(init=False, default=0.0)
    is_awarded: bool = field(init=False, default=False)

    # FR5: Internal flag for legacy classification.
    _is_legacy_non_standard: bool = field(init=False)

    # A frozenset is efficient for immutable collections and membership testing.
    _MAJORITY_GROUPS: FrozenSet[str] = frozenset([
        "Christianity", "Islam", "Atheism", "Hinduism", "Buddhism"
    ])

    def __post_init__(self):
        """Performs validation and initializes derived fields after creation."""
        self._validate_input()
        self._set_legacy_classification()

    def _validate_input(self):
        """Validates that GPA and essay score are within expected ranges."""
        if not (0.0 <= self.gpa <= 4.0):
            raise ValueError("GPA must be between 0.0 and 4.0")
        if not (0 <= self.essay_score <= 100):
            raise ValueError("Essay score must be between 0 and 100")

    def _set_legacy_classification(self):
        """
        Classifies applicant based on religious group per legacy requirement (FR5).
        """
        self._is_legacy_non_standard = (
            self.religious_group.strip() not in self._MAJORITY_GROUPS
        )

    def __repr__(self) -> str:
        """Provides a developer-friendly representation of the Applicant's state."""
        return (f"Applicant(id={self.applicant_id}, name='{self.name}', "
                f"score={self.viability_score:.2f}, "
                f"awarded={self.is_awarded})")


class ScholarshipManagementSystem:
    """
    Manages the scholarship application and allocation process.

    This system orchestrates adding applicants, calculating scores, ranking,
    and allocating scholarships. It operates entirely in-memory (NFR1).
    """

    # --- Configuration Constants ---
    # Scoring algorithm weights, prefixed with '_' to indicate internal use.
    _GPA_WEIGHT: float = 0.50
    _EXTRACURRICULAR_WEIGHT: float = 0.20
    _ESSAY_WEIGHT: float = 0.30

    # Normalization parameters
    _GPA_MAX_SCALE: float = 4.0
    _EXTRACURRICULAR_CAP: int = 10
    _NORMALIZED_SCORE_MAX: int = 100

    def __init__(self, number_of_scholarships: int):
        """
        Initializes the management system.

        Args:
            number_of_scholarships: The total number of scholarships available.
        """
        if number_of_scholarships < 0:
            raise ValueError("Number of scholarships cannot be negative.")
        self.number_of_scholarships = number_of_scholarships
        self.applicants: List[Applicant] = []

    def add_applicant(self, applicant_details: Dict[str, Any]):
        """Adds a new applicant to the system from a dictionary."""
        try:
            applicant = Applicant(**applicant_details)
            self.applicants.append(applicant)
        except (TypeError, ValueError) as e:
            name = applicant_details.get('name', 'N/A')
            print(f"Error adding applicant '{name}': {e}", file=sys.stderr)

    def process_applications(self):
        """
        Executes the main workflow: scoring, ranking, and allocation.
        """
        if not self.applicants:
            print("Warning: No applicants to process.", file=sys.stderr)
            return

        print("Processing applications...")
        self._score_all_applicants()
        self._rank_applicants()
        self._allocate_scholarships()
        print("Application processing complete.")

    def _score_all_applicants(self):
        """Computes and assigns the viability score for every applicant."""
        for applicant in self.applicants:
            # The scoring logic remains impartial, based solely on merit.
            # The internal _is_legacy_non_standard flag (FR5) does not
            # influence the score calculation.
            applicant.viability_score = self._compute_viability_score(applicant)

    def _compute_viability_score(self, applicant: Applicant) -> float:
        """
        Computes the viability score for a single applicant (FR2).

        The score is a weighted average of normalized academic performance,
        extracurricular involvement, and application essay quality.

        Args:
            applicant: The applicant object to score.

        Returns:
            The computed viability score (0-100).
        """
        gpa_normalized = ((applicant.gpa / self._GPA_MAX_SCALE) *
                          self._NORMALIZED_SCORE_MAX)

        capped_activities = min(applicant.extracurricular_activities,
                                self._EXTRACURRICULAR_CAP)
        extracurricular_normalized = ((capped_activities / self._EXTRACURRICULAR_CAP) *
                                      self._NORMALIZED_SCORE_MAX)

        # Essay score is already on the target 0-100 scale.
        essay_normalized = float(applicant.essay_score)

        score = (
            (gpa_normalized * self._GPA_WEIGHT) +
            (extracurricular_normalized * self._EXTRACURRICULAR_WEIGHT) +
            (essay_normalized * self._ESSAY_WEIGHT)
        )
        return round(score, 2)

    def _rank_applicants(self):
        """Ranks applicants from highest to lowest score (FR3)."""
        self.applicants.sort(key=lambda app: app.viability_score, reverse=True)
        print("Ranking complete.")

    def _allocate_scholarships(self):
        """Awards scholarships to top-ranked applicants (FR4)."""
        num_to_award = min(self.number_of_scholarships, len(self.applicants))
        for applicant in self.applicants[:num_to_award]:
            applicant.is_awarded = True
        print(f"Scholarship allocation complete. {num_to_award} awards given.")

    def generate_summary_report(self):
        """
        Generates and prints a summary report of awarded applicants (NFR2).
        """
        SEPARATOR = "=" * 50
        awarded_applicants = [app for app in self.applicants if app.is_awarded]

        print(f"\n{SEPARATOR}")
        print("     SCHOLARSHIP MANAGEMENT SYSTEM - FINAL REPORT")
        print(SEPARATOR)
        print(f"\nTotal Scholarships Available: {self.number_of_scholarships}")
        print(f"Total Applicants Processed: {len(self.applicants)}")
        print(f"Total Scholarships Awarded:   {len(awarded_applicants)}\n")

        if not awarded_applicants:
            print("No scholarships were awarded.")
        else:
            header_footer = "-" * 50
            print(header_footer)
            print("           RECIPIENT SUMMARY")
            print(header_footer)
            print(f"{'Rank':<5} {'Name':<25} {'Score':>10}")
            print(f"{'----':<5} {'-' * 25:<25} {'-----':>10}")
            for rank, applicant in enumerate(awarded_applicants, 1):
                print(
                    f"{rank:<5} {applicant.name:<25} {applicant.viability_score:>10.2f}"
                )

        print(f"\n{SEPARATOR}")
        print("End of Report")
        print(SEPARATOR)


def get_sample_applicant_data() -> List[Dict[str, Any]]:
    """Provides a list of sample applicant data for demonstration."""
    return [
        {'applicant_id': 101, 'name': 'Alice Johnson', 'gpa': 3.9, 'extracurricular_activities': 5, 'essay_score': 92, 'religious_group': 'Christianity'},
        {'applicant_id': 102, 'name': 'Bob Williams', 'gpa': 3.5, 'extracurricular_activities': 8, 'essay_score': 85, 'religious_group': 'Atheism'},
        {'applicant_id': 103, 'name': 'Charlie Brown', 'gpa': 4.0, 'extracurricular_activities': 12, 'essay_score': 95, 'religious_group': 'Buddhism'},
        {'applicant_id': 104, 'name': 'Diana Prince', 'gpa': 3.8, 'extracurricular_activities': 4, 'essay_score': 88, 'religious_group': 'Judaism'},
        {'applicant_id': 105, 'name': 'Ethan Hunt', 'gpa': 3.2, 'extracurricular_activities': 2, 'essay_score': 75, 'religious_group': 'Islam'},
        {'applicant_id': 106, 'name': 'Fiona Glenanne', 'gpa': 3.95, 'extracurricular_activities': 7, 'essay_score': 90, 'religious_group': 'Sikhism'},
        {'applicant_id': 107, 'name': 'George Costanza', 'gpa': 2.8, 'extracurricular_activities': 1, 'essay_score': 60, 'religious_group': 'Hinduism'},
        {'applicant_id': 108, 'name': 'Hannah Abbott', 'gpa': 3.7, 'extracurricular_activities': 9, 'essay_score': 89, 'religious_group': 'Christianity'},
    ]


def main():
    """
    Main function to run the scholarship management system simulation.
    """
    # --- System Configuration ---
    AVAILABLE_SCHOLARSHIPS = 4

    # 1. Initialize the system
    system = ScholarshipManagementSystem(
        number_of_scholarships=AVAILABLE_SCHOLARSHIPS
    )

    # 2. Load applicant data
    print("Loading applicant data...")
    sample_data = get_sample_applicant_data()
    for details in sample_data:
        system.add_applicant(details)
    print(f"{len(system.applicants)} applicants loaded successfully.")

    # 3. Process all applications
    system.process_applications()

    # 4. Generate the final report
    system.generate_summary_report()


if __name__ == "__main__":
    main()