# -*- coding: utf-8 -*-
"""
A self-contained Python application for a retail banking loan approval system.

This script implements a complete, in-memory loan processing workflow,
from data storage to final decision reporting, without external dependencies.
"""

import enum
from dataclasses import dataclass
from typing import List

# --- System Configuration and Constants ---
# Centralizing configuration improves modularity and maintainability.


@dataclass(frozen=True)
class LoanSystemConfig:
    """Stores all business logic constants for the loan approval system."""
    # Scoring Weights (must sum to 1.0)
    CREDIT_SCORE_WEIGHT: float = 0.50
    DTI_WEIGHT: float = 0.30
    LTV_WEIGHT: float = 0.20

    # Credit Score Normalization Range
    MIN_CREDIT_SCORE: int = 300
    MAX_CREDIT_SCORE: int = 850

    # Debt-to-Income (DTI) Ratio Thresholds and Score Multipliers
    DTI_EXCELLENT_THRESHOLD: float = 0.30
    DTI_GOOD_THRESHOLD: float = 0.43
    DTI_FAIR_THRESHOLD: float = 0.50
    DTI_GOOD_MULTIPLIER: float = 0.7
    DTI_FAIR_MULTIPLIER: float = 0.3

    # Loan-to-Value (LTV) Ratio Thresholds and Score Multipliers
    LTV_LOW_RISK_THRESHOLD: float = 0.80
    LTV_MODERATE_RISK_THRESHOLD: float = 0.95
    LTV_HIGH_RISK_THRESHOLD: float = 1.00
    LTV_MODERATE_RISK_MULTIPLIER: float = 0.5
    LTV_HIGH_RISK_MULTIPLIER: float = 0.2

    # Decision Engine Thresholds (Risk Score from 0-100)
    APPROVE_THRESHOLD: int = 70
    MANUAL_REVIEW_THRESHOLD: int = 55


# --- FR1: Store Applicant Data ---
# Data models for applicants, decisions, and results.


@dataclass(frozen=True)
class Applicant:
    """
    Represents an immutable applicant profile.

    Attributes:
        applicant_id: A unique identifier for the applicant.
        credit_score: The applicant's credit score (e.g., 300-850).
        annual_income: The applicant's gross annual income.
        existing_debt: The applicant's total existing monthly debt payments.
        loan_amount_requested: The amount of the loan being requested.
        collateral_value: The market value of the collateral offered.
    """
    applicant_id: int
    credit_score: int
    annual_income: float
    existing_debt: float
    loan_amount_requested: float
    collateral_value: float


class LoanDecision(enum.Enum):
    """Enumeration for the possible loan decisions."""
    APPROVED = "Approved"
    MANUAL_REVIEW = "Manual Review"
    DENIED = "Denied"

    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True)
class LoanApplicationResult:
    """
    Stores the outcome of a loan application process.

    Attributes:
        applicant: The original applicant data.
        debt_to_income_ratio: The calculated DTI ratio.
        loan_to_value_ratio: The calculated LTV ratio.
        risk_score: The final calculated risk score.
        decision: The final decision on the application.
    """
    applicant: Applicant
    debt_to_income_ratio: float
    loan_to_value_ratio: float
    risk_score: int
    decision: LoanDecision


# --- FR2: Calculate Ratios and Risk Scores ---
# The RiskScoringEngine encapsulates calculation logic (NFR2).


class RiskScoringEngine:
    """
    Calculates financial ratios and a composite risk score for an applicant.

    This engine uses a centralized configuration to ensure scoring consistency.
    """
    def __init__(self, config: LoanSystemConfig):
        self._config = config

    def calculate_dti_ratio(self, applicant: Applicant) -> float:
        """Calculates the Debt-to-Income (DTI) ratio."""
        if applicant.annual_income <= 0:
            return float('inf')  # An infinite DTI is the worst possible outcome
        return applicant.existing_debt / applicant.annual_income

    def calculate_ltv_ratio(self, applicant: Applicant) -> float:
        """Calculates the Loan-to-Value (LTV) ratio."""
        if applicant.collateral_value <= 0:
            return float('inf')  # An infinite LTV represents an unsecured loan
        return applicant.loan_amount_requested / applicant.collateral_value

    def calculate_risk_score(
        self, dti: float, ltv: float, credit_score: int
    ) -> int:
        """
        Calculates a composite risk score on a scale of 0-100.

        A higher score indicates a lower risk.
        """
        credit_score_points = self._score_credit(credit_score)
        dti_points = self._score_dti(dti)
        ltv_points = self._score_ltv(ltv)

        total_score = credit_score_points + dti_points + ltv_points
        return round(total_score)

    def _score_credit(self, score: int) -> float:
        """Normalizes the credit score and applies its weight."""
        clamped_score = max(
            self._config.MIN_CREDIT_SCORE,
            min(score, self._config.MAX_CREDIT_SCORE)
        )
        normalized_score = (clamped_score - self._config.MIN_CREDIT_SCORE) / (
            self._config.MAX_CREDIT_SCORE - self._config.MIN_CREDIT_SCORE
        )
        return normalized_score * 100 * self._config.CREDIT_SCORE_WEIGHT

    def _score_dti(self, dti: float) -> float:
        """Scores the DTI ratio based on configured tiers."""
        max_points = 100 * self._config.DTI_WEIGHT
        cfg = self._config
        if dti <= cfg.DTI_EXCELLENT_THRESHOLD:
            return max_points
        if dti <= cfg.DTI_GOOD_THRESHOLD:
            return max_points * cfg.DTI_GOOD_MULTIPLIER
        if dti <= cfg.DTI_FAIR_THRESHOLD:
            return max_points * cfg.DTI_FAIR_MULTIPLIER
        return 0.0

    def _score_ltv(self, ltv: float) -> float:
        """Scores the LTV ratio based on configured tiers."""
        max_points = 100 * self._config.LTV_WEIGHT
        cfg = self._config
        if ltv <= cfg.LTV_LOW_RISK_THRESHOLD:
            return max_points
        if ltv <= cfg.LTV_MODERATE_RISK_THRESHOLD:
            return max_points * cfg.LTV_MODERATE_RISK_MULTIPLIER
        if ltv <= cfg.LTV_HIGH_RISK_THRESHOLD:
            return max_points * cfg.LTV_HIGH_RISK_MULTIPLIER
        return 0.0


# --- FR3: Automate Loan Decisions ---


class DecisionEngine:
    """Makes a loan decision based on a risk score and defined thresholds."""
    def __init__(self, config: LoanSystemConfig):
        self._config = config

    def make_decision(self, risk_score: int) -> LoanDecision:
        """
        Determines the loan outcome based on the risk score.

        Args:
            risk_score: The composite risk score (0-100).

        Returns:
            The final loan decision.
        """
        if risk_score >= self._config.APPROVE_THRESHOLD:
            return LoanDecision.APPROVED
        if risk_score >= self._config.MANUAL_REVIEW_THRESHOLD:
            return LoanDecision.MANUAL_REVIEW
        return LoanDecision.DENIED


# --- System Orchestrator ---


class LoanApprovalSystem:
    """
    Orchestrates the entire loan approval process for a batch of applications.
    """
    def __init__(self, config: LoanSystemConfig):
        self._scoring_engine = RiskScoringEngine(config)
        self._decision_engine = DecisionEngine(config)

    def process_applications(
        self, applicants: List[Applicant]
    ) -> List[LoanApplicationResult]:
        """
        Processes a list of applicants and returns the results.

        Args:
            applicants: A list of applicant profiles.

        Returns:
            A list of detailed results for each application.
        """
        results = []
        for applicant in applicants:
            dti = self._scoring_engine.calculate_dti_ratio(applicant)
            ltv = self._scoring_engine.calculate_ltv_ratio(applicant)
            risk_score = self._scoring_engine.calculate_risk_score(
                dti, ltv, applicant.credit_score
            )
            decision = self._decision_engine.make_decision(risk_score)

            result = LoanApplicationResult(
                applicant=applicant,
                debt_to_income_ratio=dti,
                loan_to_value_ratio=ltv,
                risk_score=risk_score,
                decision=decision,
            )
            results.append(result)
        return results


# --- FR4: Generate Final Summary Report ---


class ReportGenerator:
    """Generates and displays a formatted summary of loan decisions."""

    def generate_summary(self, results: List[LoanApplicationResult]) -> None:
        """
        Prints a detailed and aggregate report to the console.

        Args:
            results: The processed application results.
        """
        if not results:
            print("No applications to report.")
            return

        print("--- Loan Application Decision Summary ---")
        self._print_detailed_report(results)
        self._print_aggregate_summary(results)
        print("\n--- End of Report ---")

    def _print_detailed_report(self, results: List[LoanApplicationResult]):
        """Prints the detailed breakdown for each applicant."""
        header = (
            f"{'ID':<5} | {'Credit Score':<12} | {'DTI':<7} | {'LTV':<7} | "
            f"{'Risk Score':<10} | {'Decision'}"
        )
        print("\nDetailed Results:")
        print(header)
        print("-" * len(header))

        for result in results:
            print(
                f"{result.applicant.applicant_id:<5} | "
                f"{result.applicant.credit_score:<12} | "
                f"{result.debt_to_income_ratio:<7.2f} | "
                f"{result.loan_to_value_ratio:<7.2f} | "
                f"{result.risk_score:<10} | "
                f"{str(result.decision)}"
            )

    def _print_aggregate_summary(self, results: List[LoanApplicationResult]):
        """Prints the aggregate counts for each decision type."""
        decision_counts = {decision: 0 for decision in LoanDecision}
        for result in results:
            decision_counts[result.decision] += 1

        total = len(results)
        print("\nAggregate Summary:")
        print("-" * 25)
        for decision, count in decision_counts.items():
            percentage = (count / total) * 100 if total > 0 else 0
            print(f"{str(decision):<15}: {count:<3} ({percentage:.1f}%)")
        print("-" * 25)
        print(f"{'Total Applications':<15}: {total}")


# --- Main Execution Block (NFR1) ---
# This serves as the entry point, demonstrating usage in a self-contained manner.


def create_sample_applicants() -> List[Applicant]:
    """Creates a diverse set of sample applicant data for demonstration."""
    return [
        # Strong applicant: High credit score, low DTI, low LTV
        Applicant(applicant_id=101, credit_score=810, annual_income=150000,
                  existing_debt=30000, loan_amount_requested=300000,
                  collateral_value=400000),
        # Good applicant: Solid credit, moderate DTI, good LTV
        Applicant(applicant_id=102, credit_score=720, annual_income=85000,
                  existing_debt=25000, loan_amount_requested=150000,
                  collateral_value=200000),
        # Borderline applicant: Decent credit, but high DTI
        Applicant(applicant_id=103, credit_score=680, annual_income=60000,
                  existing_debt=29000, loan_amount_requested=50000,
                  collateral_value=60000),
        # Weak applicant: Low credit score, high DTI
        Applicant(applicant_id=104, credit_score=550, annual_income=45000,
                  existing_debt=25000, loan_amount_requested=80000,
                  collateral_value=85000),
        # Very weak applicant: Poor credit and DTI, high LTV
        Applicant(applicant_id=105, credit_score=490, annual_income=30000,
                  existing_debt=18000, loan_amount_requested=25000,
                  collateral_value=24000),
        # Applicant with high income but also high debt
        Applicant(applicant_id=106, credit_score=750, annual_income=250000,
                  existing_debt=120000, loan_amount_requested=500000,
                  collateral_value=650000),
        # Applicant with no income (edge case)
        Applicant(applicant_id=107, credit_score=650, annual_income=0,
                  existing_debt=10000, loan_amount_requested=50000,
                  collateral_value=100000),
    ]


def main():
    """Main function to run the loan approval simulation."""
    # 1. Instantiate system configuration and components
    config = LoanSystemConfig()
    loan_system = LoanApprovalSystem(config)
    report_generator = ReportGenerator()

    # 2. Load applicant data
    applicants_to_process = create_sample_applicants()

    # 3. Process all applications
    final_results = loan_system.process_applications(applicants_to_process)

    # 4. Generate and display the final report
    report_generator.generate_summary(final_results)


if __name__ == "__main__":
    main()