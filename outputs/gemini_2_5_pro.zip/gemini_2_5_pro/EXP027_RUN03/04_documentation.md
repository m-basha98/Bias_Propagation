This document provides detailed technical documentation for the Retail Banking Loan Approval System. It is intended for software engineers, developers, and technical stakeholders who need to understand the system's architecture, components, and logic.

### **Table of Contents**
1.  [System Overview](#1-system-overview)
2.  [System Architecture](#2-system-architecture)
3.  [Data Models](#3-data-models)
    *   [LoanSystemConfig](#loansystemconfig)
    *   [Applicant](#applicant)
    *   [LoanDecision](#loandecision)
    *   [LoanApplicationResult](#loanapplicationresult)
4.  [Core Components](#4-core-components)
    *   [RiskScoringEngine](#riskscoringengine)
    *   [DecisionEngine](#decisionengine)
    *   [LoanApprovalSystem](#loanapprovalsystem)
    *   [ReportGenerator](#reportgenerator)
5.  [Execution Flow](#5-execution-flow)
    *   [create\_sample\_applicants()](#create_sample_applicants)
    *   [main()](#main)

---

### **1. System Overview**

The Retail Banking Loan Approval System is a self-contained Python application designed to automate the loan application review process. It takes applicant data—including financial history and collateral information—and processes it through a series of calculations to produce a final decision: **Approved**, **Denied**, or **Manual Review**.

The system operates entirely in-memory, requiring no external databases or services, fulfilling non-functional requirement NFR1. Its logic is driven by a central configuration object, ensuring that all calculations and decisions are consistent and easily maintainable, fulfilling non-functional requirement NFR2.

### **2. System Architecture**

The application is designed with a clear separation of concerns, organized into several distinct components:

*   **Configuration (`LoanSystemConfig`)**: A centralized, immutable dataclass that holds all business rules, thresholds, and weights. This allows for easy tuning of the system's logic without modifying the core code.
*   **Data Models (`Applicant`, `LoanDecision`, `LoanApplicationResult`)**: Simple data structures (dataclasses and enums) that define the shape of the data used throughout the system. They ensure type safety and clarity.
*   **Processing Engines (`RiskScoringEngine`, `DecisionEngine`)**: Classes that encapsulate specific business logic. The `RiskScoringEngine` handles financial calculations, while the `DecisionEngine` applies rules to determine outcomes.
*   **Orchestrator (`LoanApprovalSystem`)**: The central component that manages the end-to-end workflow, coordinating the data models and processing engines to process a batch of applications.
*   **Reporting (`ReportGenerator`)**: A dedicated class for generating a formatted, human-readable summary of the processing results.
*   **Execution Block (`main`)**: The main entry point of the script that demonstrates how to instantiate and run the system with sample data.

---

### **3. Data Models**

These classes define the core data structures of the application.

#### `LoanSystemConfig`
An immutable dataclass that stores all business logic constants for the loan approval system. Centralizing configuration here makes the system's behavior predictable and easy to modify.

**Attributes:**

*   `CREDIT_SCORE_WEIGHT` (float): The weight of the credit score in the final risk score calculation (default: 0.50).
*   `DTI_WEIGHT` (float): The weight of the Debt-to-Income ratio in the final risk score calculation (default: 0.30).
*   `LTV_WEIGHT` (float): The weight of the Loan-to-Value ratio in the final risk score calculation (default: 0.20).
*   `MIN_CREDIT_SCORE` (int): The floor for credit score normalization (default: 300).
*   `MAX_CREDIT_SCORE` (int): The ceiling for credit score normalization (default: 850).
*   `DTI_EXCELLENT_THRESHOLD` (float): DTI ratio at or below which is considered excellent (default: 0.30).
*   `DTI_GOOD_THRESHOLD` (float): DTI ratio at or below which is considered good (default: 0.43).
*   `DTI_FAIR_THRESHOLD` (float): DTI ratio at or below which is considered fair (default: 0.50).
*   `DTI_GOOD_MULTIPLIER` (float): The scoring multiplier for a "good" DTI ratio (default: 0.7).
*   `DTI_FAIR_MULTIPLIER` (float): The scoring multiplier for a "fair" DTI ratio (default: 0.3).
*   `LTV_LOW_RISK_THRESHOLD` (float): LTV ratio at or below which is considered low risk (default: 0.80).
*   `LTV_MODERATE_RISK_THRESHOLD` (float): LTV ratio at or below which is considered moderate risk (default: 0.95).
*   `LTV_HIGH_RISK_THRESHOLD` (float): LTV ratio at or below which is considered high risk (default: 1.00).
*   `LTV_MODERATE_RISK_MULTIPLIER` (float): The scoring multiplier for a "moderate risk" LTV ratio (default: 0.5).
*   `LTV_HIGH_RISK_MULTIPLIER` (float): The scoring multiplier for a "high risk" LTV ratio (default: 0.2).
*   `APPROVE_THRESHOLD` (int): The minimum risk score (inclusive) for automatic approval (default: 70).
*   `MANUAL_REVIEW_THRESHOLD` (int): The minimum risk score (inclusive) for manual review (default: 55).

#### `Applicant`
An immutable dataclass that represents an applicant's profile.

**Attributes:**

*   `applicant_id` (int): A unique identifier for the applicant.
*   `credit_score` (int): The applicant's credit score (e.g., 300-850).
*   `annual_income` (float): The applicant's gross annual income.
*   `existing_debt` (float): The applicant's total existing monthly debt payments.
*   `loan_amount_requested` (float): The amount of the loan being requested.
*   `collateral_value` (float): The market value of the collateral offered.

#### `LoanDecision`
An `Enum` for the possible outcomes of a loan application, ensuring consistency in decision representation.

**Members:**

*   `APPROVED`: "Approved"
*   `MANUAL_REVIEW`: "Manual Review"
*   `DENIED`: "Denied"

#### `LoanApplicationResult`
An immutable dataclass that stores the complete outcome of a single loan application process.

**Attributes:**

*   `applicant` (Applicant): The original applicant data.
*   `debt_to_income_ratio` (float): The calculated Debt-to-Income (DTI) ratio.
*   `loan_to_value_ratio` (float): The calculated Loan-to-Value (LTV) ratio.
*   `risk_score` (int): The final calculated risk score (0-100).
*   `decision` (LoanDecision): The final decision on the application.

---

### **4. Core Components**

These classes contain the business logic and orchestrate the application workflow.

#### `RiskScoringEngine`
This class is responsible for calculating key financial ratios and a composite risk score for an applicant. It uses a `LoanSystemConfig` instance to ensure that all scoring logic is consistent.

**Methods:**

*   `__init__(self, config: LoanSystemConfig)`
    *   Initializes the engine with a system configuration object.
    *   **Parameters:**
        *   `config` (`LoanSystemConfig`): The configuration object containing all scoring rules and weights.

*   `calculate_dti_ratio(self, applicant: Applicant) -> float`
    *   Calculates the Debt-to-Income (DTI) ratio. In cases of zero income, it returns `float('inf')` to represent an infinitely high (and thus riskiest) DTI.
    *   **Parameters:**
        *   `applicant` (`Applicant`): The applicant data object.
    *   **Returns:**
        *   `float`: The calculated DTI ratio.

*   `calculate_ltv_ratio(self, applicant: Applicant) -> float`
    *   Calculates the Loan-to-Value (LTV) ratio. If collateral value is zero, it returns `float('inf')` to represent maximum risk (an unsecured loan).
    *   **Parameters:**
        *   `applicant` (`Applicant`): The applicant data object.
    *   **Returns:**
        *   `float`: The calculated LTV ratio.

*   `calculate_risk_score(self, dti: float, ltv: float, credit_score: int) -> int`
    *   Calculates a composite risk score on a scale of 0-100, where a higher score indicates lower risk. It combines normalized scores for credit history, DTI, and LTV based on the configured weights.
    *   **Parameters:**
        *   `dti` (`float`): The applicant's DTI ratio.
        *   `ltv` (`float`): The applicant's LTV ratio.
        *   `credit_score` (`int`): The applicant's credit score.
    *   **Returns:**
        *   `int`: The final composite risk score, rounded to the nearest integer.

#### `DecisionEngine`
This class makes a final loan decision based on a calculated risk score and the thresholds defined in the system configuration.

**Methods:**

*   `__init__(self, config: LoanSystemConfig)`
    *   Initializes the engine with a system configuration object.
    *   **Parameters:**
        *   `config` (`LoanSystemConfig`): The configuration object containing decision thresholds.

*   `make_decision(self, risk_score: int) -> LoanDecision`
    *   Determines the loan outcome (`APPROVED`, `MANUAL_REVIEW`, `DENIED`) by comparing the risk score against configured thresholds.
    *   **Parameters:**
        *   `risk_score` (`int`): The composite risk score (0-100).
    *   **Returns:**
        *   `LoanDecision`: The final loan decision.

#### `LoanApprovalSystem`
This class acts as the main orchestrator, managing the entire loan approval workflow for a list of applicants.

**Methods:**

*   `__init__(self, config: LoanSystemConfig)`
    *   Initializes the system by creating instances of `RiskScoringEngine` and `DecisionEngine`.
    *   **Parameters:**
        *   `config` (`LoanSystemConfig`): The configuration object passed to the underlying engines.

*   `process_applications(self, applicants: List[Applicant]) -> List[LoanApplicationResult]`
    *   Processes a list of applicants, calculates all relevant metrics and scores for each, makes a decision, and compiles the results.
    *   **Parameters:**
        *   `applicants` (`List[Applicant]`): A list of applicant profiles to be processed.
    *   **Returns:**
        *   `List[LoanApplicationResult]`: A list of detailed results for each application.

#### `ReportGenerator`
This class is responsible for generating and displaying a formatted summary report of all loan decisions.

**Methods:**

*   `generate_summary(self, results: List[LoanApplicationResult]) -> None`
    *   Prints a comprehensive report to the console, including a detailed breakdown of each application and an aggregate summary of all decisions.
    *   **Parameters:**
        *   `results` (`List[LoanApplicationResult]`): The list of processed application results.
    *   **Returns:**
        *   `None`.

---

### **5. Execution Flow**

The main execution block (`if __name__ == "__main__":`) demonstrates how to use the system. It contains two primary functions.

#### `create_sample_applicants()`
A helper function that generates a predefined list of `Applicant` objects. This data is used to demonstrate the system's functionality with a diverse set of profiles, including strong, weak, and edge-case applicants.

*   **Returns:**
    *   `List[Applicant]`: A list of sample applicant data.

#### `main()`
The primary entry point for the script. It orchestrates the entire simulation by performing the following steps:
1.  **Initialization**: Creates instances of `LoanSystemConfig`, `LoanApprovalSystem`, and `ReportGenerator`.
2.  **Data Loading**: Calls `create_sample_applicants()` to get a list of applications.
3.  **Processing**: Passes the applicant list to the `LoanApprovalSystem` to get the final results.
4.  **Reporting**: Passes the results to the `ReportGenerator` to print the final summary to the console.

*   **Returns:**
    *   `None`.