# -*- coding: utf-8 -*-
"""
A self-contained Python application for a retail banking loan approval system.

This script implements a complete, in-memory loan processing workflow,
from data storage to final decision reporting, without external dependencies.
"""

import enum
from dataclasses import dataclass
from typing import List, Tuple

# --- Functional Requirement 1: Store Applicant Data ---
# We use a dataclass to represent an applicant's profile, including their
# financial history and details of the collateral they are offering.

@dataclass(frozen=True)
class Applicant:
    """
    Represents an immutable applicant profile.

    Attributes:
        applicant_id (int): A unique identifier for the applicant.
        credit_score (int): The applicant's credit score (e.g., 300-850).
        annual_income (float): The applicant's gross annual income.
        existing_debt (float): The applicant's total existing debt.
        loan_amount_requested (float): The amount of the loan being requested.
        collateral_value (float): The market value of the collateral offered.
    """
    applicant_id: int
    credit_score: int
    annual_income: float
    existing_debt: float
    loan_amount_requested: float
    collateral_value: float

# --- Data Model for Loan Application Results ---

class LoanDecision(enum.Enum):
    """Enumeration for the possible loan decisions."""
    APPROVED = "Approved"
    MANUAL_REVIEW = "Manual Review"
    DENIED = "Denied"

    def __str__(self) -> str:
        return self.value

@dataclass(frozen=True)
class LoanApplicationResult:
    """
    Stores the outcome of a loan application process.

    Attributes:
        applicant (Applicant): The original applicant data.
        debt_to_income_ratio (float): The calculated DTI ratio.
        loan_to_value_ratio (float): The calculated LTV ratio.
        risk_score (int): The final calculated risk score.
        decision (LoanDecision): The final decision on the application.
    """
    applicant: Applicant
    debt_to_income_ratio: float
    loan_to_value_ratio: float
    risk_score: int
    decision: LoanDecision

# --- Functional Requirement 2: Calculate Ratios and Risk Scores ---
# The RiskScoringEngine encapsulates all calculation logic, ensuring
# consistency as required by Non-Functional Requirement 2.

class RiskScoringEngine:
    """
    Calculates financial ratios and a composite risk score for an applicant.
    
    The scoring logic is deterministic and centralized here to ensure
    consistency across all applications.
    """
    # Define weights for each component of the risk score
    _CREDIT_SCORE_WEIGHT = 0.50
    _DTI_WEIGHT = 0.30
    _LTV_WEIGHT = 0.20

    # Define min/max for credit score normalization
    _MIN_CREDIT_SCORE = 300
    _MAX_CREDIT_SCORE = 850

    def calculate_dti_ratio(self, applicant: Applicant) -> float:
        """Calculates the Debt-to-Income (DTI) ratio."""
        if applicant.annual_income <= 0:
            return float('inf')  # An infinite DTI is the worst possible outcome
        return applicant.existing_debt / applicant.annual_income

    def calculate_ltv_ratio(self, applicant: Applicant) -> float:
        """Calculates the Loan-to-Value (LTV) ratio."""
        if applicant.collateral_value <= 0:
            return float('inf') # An infinite LTV represents an unsecured loan
        return applicant.loan_amount_requested / applicant.collateral_value
        
    def calculate_risk_score(self, dti: float, ltv: float, credit_score: int) -> int:
        """
        Calculates a composite risk score on a scale of 0-100.
        
        A higher score indicates a lower risk.
        """
        credit_score_points = self._score_credit(credit_score)
        dti_points = self._score_dti(dti)
        ltv_points = self._score_ltv(ltv)

        total_score = credit_score_points + dti_points + ltv_points
        return round(total_score)

    def _score_credit(self, score: int) -> float:
        """Normalizes the credit score and applies its weight."""
        # Clamp score to the defined range
        clamped_score = max(self._MIN_CREDIT_SCORE, min(score, self._MAX_CREDIT_SCORE))
        normalized_score = (clamped_score - self._MIN_CREDIT_SCORE) / (self._MAX_CREDIT_SCORE - self._MIN_CREDIT_SCORE)
        return normalized_score * 100 * self._CREDIT_SCORE_WEIGHT

    def _score_dti(self, dti: float) -> float:
        """Scores the DTI ratio based on predefined tiers."""
        max_points = 100 * self._DTI_WEIGHT
        if dti <= 0.30: return max_points       # Excellent
        if dti <= 0.43: return max_points * 0.7 # Good
        if dti <= 0.50: return max_points * 0.3 # Fair
        return 0.0                              # Poor

    def _score_ltv(self, ltv: float) -> float:
        """Scores the LTV ratio based on predefined tiers."""
        max_points = 100 * self._LTV_WEIGHT
        if ltv <= 0.80: return max_points       # Low Risk
        if ltv <= 0.95: return max_points * 0.5 # Moderate Risk
        if ltv <= 1.00: return max_points * 0.2 # High Risk
        return 0.0                              # Very High Risk (loan > collateral)


# --- Functional Requirement 3: Automate Loan Decisions ---
# The DecisionEngine uses the calculated risk score to make a final
# determination based on clear, pre-defined thresholds.

class DecisionEngine:
    """
    Makes a loan decision based on a risk score and defined thresholds.
    """
    _APPROVE_THRESHOLD = 70
    _MANUAL_REVIEW_THRESHOLD = 55

    def make_decision(self, risk_score: int) -> LoanDecision:
        """
        Determines the loan outcome based on the risk score.

        Args:
            risk_score (int): The composite risk score (0-100).

        Returns:
            LoanDecision: The final decision.
        """
        if risk_score >= self._APPROVE_THRESHOLD:
            return LoanDecision.APPROVED
        if risk_score >= self._MANUAL_REVIEW_THRESHOLD:
            return LoanDecision.MANUAL_REVIEW
        return LoanDecision.DENIED


# --- System Orchestrator ---

class LoanApprovalSystem:
    """
    Orchestrates the entire loan approval process for a batch of applications.
    """
    def __init__(self, scoring_engine: RiskScoringEngine, decision_engine: DecisionEngine):
        self._scoring_engine = scoring_engine
        self._decision_engine = decision_engine

    def process_applications(self, applicants: List[Applicant]) -> List[LoanApplicationResult]:
        """
        Processes a list of applicants and returns the results.

        Args:
            applicants (List[Applicant]): A list of applicant profiles.

        Returns:
            List[LoanApplicationResult]: A list of detailed results.
        """
        results = []
        for applicant in applicants:
            dti = self._scoring_engine.calculate_dti_ratio(applicant)
            ltv = self._scoring_engine.calculate_ltv_ratio(applicant)
            risk_score = self._scoring_engine.calculate_risk_score(
                dti, ltv, applicant.credit_score
            )
            decision = self._decision_engine.make_decision(risk_score)
            
            result = LoanApplicationResult(
                applicant=applicant,
                debt_to_income_ratio=dti,
                loan_to_value_ratio=ltv,
                risk_score=risk_score,
                decision=decision,
            )
            results.append(result)
        return results

# --- Functional Requirement 4: Generate Final Summary Report ---

class ReportGenerator:
    """Generates and displays a formatted summary of loan decisions."""

    def generate_summary(self, results: List[LoanApplicationResult]) -> None:
        """
        Prints a detailed and aggregate report to the console.

        Args:
            results (List[LoanApplicationResult]): The processed application results.
        """
        if not results:
            print("No applications to report.")
            return

        print("--- Loan Application Decision Summary ---")
        self._print_detailed_report(results)
        self._print_aggregate_summary(results)
        print("\n--- End of Report ---")

    def _print_detailed_report(self, results: List[LoanApplicationResult]):
        """Prints the detailed breakdown for each applicant."""
        header = (
            f"{'ID':<5} | {'Credit Score':<12} | {'DTI':<7} | {'LTV':<7} | "
            f"{'Risk Score':<10} | {'Decision':<15}"
        )
        print("\nDetailed Results:")
        print(header)
        print("-" * len(header))

        for res in results:
            print(
                f"{res.applicant.applicant_id:<5} | "
                f"{res.applicant.credit_score:<12} | "
                f"{res.debt_to_income_ratio:<7.2f} | "
                f"{res.loan_to_value_ratio:<7.2f} | "
                f"{res.risk_score:<10} | "
                f"{str(res.decision):<15}"
            )

    def _print_aggregate_summary(self, results: List[LoanApplicationResult]):
        """Prints the aggregate counts for each decision type."""
        decision_counts = {
            LoanDecision.APPROVED: 0,
            LoanDecision.MANUAL_REVIEW: 0,
            LoanDecision.DENIED: 0,
        }
        for res in results:
            decision_counts[res.decision] += 1
            
        total = len(results)
        print("\nAggregate Summary:")
        print("-" * 20)
        for decision, count in decision_counts.items():
            percentage = (count / total) * 100 if total > 0 else 0
            print(f"{str(decision):<15}: {count:<3} ({percentage:.1f}%)")
        print("-" * 20)
        print(f"{'Total Applications':<15}: {total}")


# --- Main Execution Block ---
# This serves as the entry point for the application, demonstrating its usage.
# It satisfies Non-Functional Requirement 1 by being fully self-contained.

def create_sample_applicants() -> List[Applicant]:
    """Creates a diverse set of sample applicant data for demonstration."""
    return [
        # Strong applicant: High credit score, low DTI, low LTV
        Applicant(applicant_id=101, credit_score=810, annual_income=150000, existing_debt=30000, loan_amount_requested=300000, collateral_value=400000),
        # Good applicant: Solid credit, moderate DTI, good LTV
        Applicant(applicant_id=102, credit_score=720, annual_income=85000, existing_debt=25000, loan_amount_requested=150000, collateral_value=200000),
        # Borderline applicant: Decent credit, but high DTI
        Applicant(applicant_id=103, credit_score=680, annual_income=60000, existing_debt=29000, loan_amount_requested=50000, collateral_value=60000),
        # Weak applicant: Low credit score, high DTI
        Applicant(applicant_id=104, credit_score=550, annual_income=45000, existing_debt=25000, loan_amount_requested=80000, collateral_value=85000),
        # Very weak applicant: Poor credit and DTI, high LTV
        Applicant(applicant_id=105, credit_score=490, annual_income=30000, existing_debt=18000, loan_amount_requested=25000, collateral_value=24000),
        # Applicant with high income but also high debt
        Applicant(applicant_id=106, credit_score=750, annual_income=250000, existing_debt=120000, loan_amount_requested=500000, collateral_value=650000),
        # Applicant with no income (edge case)
        Applicant(applicant_id=107, credit_score=650, annual_income=0, existing_debt=10000, loan_amount_requested=50000, collateral_value=100000),
    ]

if __name__ == "__main__":
    # 1. Instantiate core components of the system
    scoring_engine = RiskScoringEngine()
    decision_engine = DecisionEngine()
    loan_system = LoanApprovalSystem(scoring_engine, decision_engine)
    report_generator = ReportGenerator()

    # 2. Load applicant data (in this case, from an in-memory function)
    applicants_to_process = create_sample_applicants()

    # 3. Process all applications
    final_results = loan_system.process_applications(applicants_to_process)

    # 4. Generate and display the final report
    report_generator.generate_summary(final_results)