# -*- coding: utf-8 -*-
"""
Comprehensive unit tests for the retail banking loan approval system.

This test suite uses pytest to validate the functionality of each component,
covering standard inputs, boundary conditions, and edge cases.
"""

import math
from io import StringIO
from typing import List

import pytest

# Assuming the refactored code is in a file named `loan_system.py`
# If running this test file directly, place it in the same directory.
from loan_system import (
    Applicant,
    DecisionEngine,
    LoanApplicationResult,
    LoanApprovalSystem,
    LoanDecision,
    LoanSystemConfig,
    ReportGenerator,
    RiskScoringEngine
)

# --- Test Fixtures ---
# Fixtures provide a fixed baseline for tests. Instantiating objects here
# reduces code duplication and ensures a consistent state for each test.


@pytest.fixture(scope="module")
def default_config() -> LoanSystemConfig:
    """Provides a default LoanSystemConfig instance for tests."""
    return LoanSystemConfig()


@pytest.fixture
def risk_scoring_engine(default_config: LoanSystemConfig) -> RiskScoringEngine:
    """Provides a RiskScoringEngine instance with default configuration."""
    return RiskScoringEngine(default_config)


@pytest.fixture
def decision_engine(default_config: LoanSystemConfig) -> DecisionEngine:
    """Provides a DecisionEngine instance with default configuration."""
    return DecisionEngine(default_config)

# --- Sample Applicant Fixtures for different scenarios ---


@pytest.fixture
def perfect_applicant() -> Applicant:
    """An applicant who should be easily approved."""
    return Applicant(
        applicant_id=1, credit_score=850, annual_income=200000,
        existing_debt=20000, loan_amount_requested=250000,
        collateral_value=500000
    )


@pytest.fixture
def borderline_applicant() -> Applicant:
    """An applicant who might fall into manual review."""
    return Applicant(
        applicant_id=2, credit_score=680, annual_income=70000,
        existing_debt=30000, loan_amount_requested=200000,
        collateral_value=220000
    )


@pytest.fixture
def weak_applicant() -> Applicant:
    """An applicant who should be denied."""
    return Applicant(
        applicant_id=3, credit_score=500, annual_income=40000,
        existing_debt=25000, loan_amount_requested=100000,
        collateral_value=90000
    )


@pytest.fixture
def zero_income_applicant() -> Applicant:
    """Edge case: Applicant with zero income."""
    return Applicant(
        applicant_id=4, credit_score=700, annual_income=0,
        existing_debt=5000, loan_amount_requested=50000,
        collateral_value=100000
    )


@pytest.fixture
def zero_collateral_applicant() -> Applicant:
    """Edge case: Applicant with zero collateral value."""
    return Applicant(
        applicant_id=5, credit_score=650, annual_income=80000,
        existing_debt=10000, loan_amount_requested=150000,
        collateral_value=0
    )

# --- Data Model and Enum Tests (FR1) ---


class TestDataModels:
    """Tests for the data classes and enumerations."""

    def test_applicant_creation(self):
        """FR1: Test that an Applicant object can be created."""
        applicant = Applicant(
            applicant_id=101, credit_score=750, annual_income=100000,
            existing_debt=20000, loan_amount_requested=250000,
            collateral_value=300000
        )
        assert applicant.applicant_id == 101
        assert applicant.credit_score == 750

    def test_loan_decision_str(self):
        """Test the string representation of the LoanDecision enum."""
        assert str(LoanDecision.APPROVED) == "Approved"
        assert str(LoanDecision.MANUAL_REVIEW) == "Manual Review"
        assert str(LoanDecision.DENIED) == "Denied"


# --- RiskScoringEngine Tests (FR2) ---


class TestRiskScoringEngine:
    """Tests the financial calculation and scoring logic."""

    def test_calculate_dti_ratio_standard(self, risk_scoring_engine: RiskScoringEngine):
        """FR2: Test DTI calculation with standard positive income."""
        applicant = Applicant(
            applicant_id=1, credit_score=700, annual_income=100000,
            existing_debt=25000, loan_amount_requested=0, collateral_value=0
        )
        assert risk_scoring_engine.calculate_dti_ratio(applicant) == pytest.approx(0.25)

    @pytest.mark.parametrize("income", [0, -1000])
    def test_calculate_dti_ratio_zero_or_negative_income(
        self, risk_scoring_engine: RiskScoringEngine, income: float
    ):
        """FR2: Test DTI edge case with zero or negative income."""
        applicant = Applicant(
            applicant_id=1, credit_score=700, annual_income=income,
            existing_debt=25000, loan_amount_requested=0, collateral_value=0
        )
        assert risk_scoring_engine.calculate_dti_ratio(applicant) == float('inf')

    def test_calculate_ltv_ratio_standard(self, risk_scoring_engine: RiskScoringEngine):
        """FR2: Test LTV calculation with standard positive collateral."""
        applicant = Applicant(
            applicant_id=1, credit_score=700, annual_income=0,
            existing_debt=0, loan_amount_requested=80000,
            collateral_value=100000
        )
        assert risk_scoring_engine.calculate_ltv_ratio(applicant) == pytest.approx(0.8)

    @pytest.mark.parametrize("collateral", [0, -50000])
    def test_calculate_ltv_ratio_zero_or_negative_collateral(
        self, risk_scoring_engine: RiskScoringEngine, collateral: float
    ):
        """FR2: Test LTV edge case with zero or negative collateral."""
        applicant = Applicant(
            applicant_id=1, credit_score=700, annual_income=0,
            existing_debt=0, loan_amount_requested=80000,
            collateral_value=collateral
        )
        assert risk_scoring_engine.calculate_ltv_ratio(applicant) == float('inf')

    @pytest.mark.parametrize("score, expected_normalized_points", [
        (850, 50.0),  # Max score -> max points
        (300, 0.0),   # Min score -> min points
        (575, 25.0),  # Mid score -> mid points
        (900, 50.0),  # Above max (clamped)
        (200, 0.0),   # Below min (clamped)
    ])
    def test_score_credit(
        self, risk_scoring_engine: RiskScoringEngine, default_config: LoanSystemConfig,
        score: int, expected_normalized_points: float
    ):
        """FR2 & NFR2: Test credit scoring logic including clamping."""
        # Note: default weight is 0.50
        assert risk_scoring_engine._score_credit(score) == pytest.approx(expected_normalized_points)

    @pytest.mark.parametrize("dti, expected_multiplier", [
        (0.25, 1.0),   # Excellent
        (0.30, 1.0),   # Boundary: Excellent
        (0.31, 0.7),   # Good
        (0.43, 0.7),   # Boundary: Good
        (0.44, 0.3),   # Fair
        (0.50, 0.3),   # Boundary: Fair
        (0.51, 0.0),   # Poor
        (float('inf'), 0.0) # Edge case: Poor
    ])
    def test_score_dti(
        self, risk_scoring_engine: RiskScoringEngine, default_config: LoanSystemConfig,
        dti: float, expected_multiplier: float
    ):
        """FR2 & NFR2: Test DTI scoring across all tiers and boundaries."""
        max_points = 100 * default_config.DTI_WEIGHT
        expected_points = max_points * expected_multiplier
        assert risk_scoring_engine._score_dti(dti) == pytest.approx(expected_points)

    @pytest.mark.parametrize("ltv, expected_multiplier", [
        (0.75, 1.0),   # Low Risk
        (0.80, 1.0),   # Boundary: Low Risk
        (0.81, 0.5),   # Moderate Risk
        (0.95, 0.5),   # Boundary: Moderate Risk
        (0.96, 0.2),   # High Risk
        (1.00, 0.2),   # Boundary: High Risk
        (1.01, 0.0),   # Very High Risk (Denied)
        (float('inf'), 0.0) # Edge case: Denied
    ])
    def test_score_ltv(
        self, risk_scoring_engine: RiskScoringEngine, default_config: LoanSystemConfig,
        ltv: float, expected_multiplier: float
    ):
        """FR2 & NFR2: Test LTV scoring across all tiers and boundaries."""
        max_points = 100 * default_config.LTV_WEIGHT
        expected_points = max_points * expected_multiplier
        assert risk_scoring_engine._score_ltv(ltv) == pytest.approx(expected_points)

    def test_calculate_risk_score_integration(self, risk_scoring_engine: RiskScoringEngine):
        """FR2: Test the final risk score calculation integrates components correctly."""
        # Perfect profile: 850 credit, 0.1 DTI, 0.5 LTV
        # Credit: (850-300)/(850-300) * 100 * 0.50 = 50
        # DTI: 100 * 0.30 * 1.0 = 30
        # LTV: 100 * 0.20 * 1.0 = 20
        # Total = 50 + 30 + 20 = 100
        score = risk_scoring_engine.calculate_risk_score(0.1, 0.5, 850)
        assert score == 100

        # Weak profile: 400 credit, 0.6 DTI, 1.1 LTV
        # Credit: (400-300)/(850-300) * 100 * 0.50 = 9.09...
        # DTI: 0
        # LTV: 0
        # Total = 9 (rounded)
        score = risk_scoring_engine.calculate_risk_score(0.6, 1.1, 400)
        assert score == 9


# --- DecisionEngine Tests (FR3) ---


class TestDecisionEngine:
    """Tests the final decision logic based on risk score."""

    @pytest.mark.parametrize("score, expected_decision", [
        (100, LoanDecision.APPROVED),
        (71, LoanDecision.APPROVED),
        (70, LoanDecision.APPROVED),        # Boundary: Approve
        (69, LoanDecision.MANUAL_REVIEW),
        (60, LoanDecision.MANUAL_REVIEW),
        (55, LoanDecision.MANUAL_REVIEW),    # Boundary: Manual Review
        (54, LoanDecision.DENIED),
        (30, LoanDecision.DENIED),
        (0, LoanDecision.DENIED),
    ])
    def test_make_decision(
        self, decision_engine: DecisionEngine, score: int, expected_decision: LoanDecision
    ):
        """FR3: Test decision logic across all thresholds and boundaries."""
        assert decision_engine.make_decision(score) == expected_decision


# --- LoanApprovalSystem Integration Tests ---


class TestLoanApprovalSystem:
    """Tests the orchestration of the entire loan approval workflow."""

    @pytest.fixture
    def loan_system(self, default_config: LoanSystemConfig) -> LoanApprovalSystem:
        """Provides a LoanApprovalSystem instance."""
        return LoanApprovalSystem(default_config)

    def test_process_applications_empty_list(self, loan_system: LoanApprovalSystem):
        """Test processing an empty list of applicants."""
        results = loan_system.process_applications([])
        assert results == []

    def test_process_applications_end_to_end(
        self, loan_system: LoanApprovalSystem, perfect_applicant: Applicant,
        weak_applicant: Applicant, zero_income_applicant: Applicant
    ):
        """FR1, FR2, FR3: Test the full processing of a diverse batch of applicants."""
        applicants = [perfect_applicant, weak_applicant, zero_income_applicant]
        results = loan_system.process_applications(applicants)

        assert len(results) == 3

        # Validate perfect applicant's result
        result_perfect = next(r for r in results if r.applicant.applicant_id == 1)
        assert result_perfect.decision == LoanDecision.APPROVED
        assert result_perfect.risk_score > 70
        assert result_perfect.debt_to_income_ratio == pytest.approx(0.1)
        assert result_perfect.loan_to_value_ratio == pytest.approx(0.5)

        # Validate weak applicant's result
        result_weak = next(r for r in results if r.applicant.applicant_id == 3)
        assert result_weak.decision == LoanDecision.DENIED
        assert result_weak.risk_score < 55
        assert result_weak.loan_to_value_ratio > 1.0

        # Validate zero income applicant's result (should have infinite DTI, leading to a low score)
        result_zero_income = next(r for r in results if r.applicant.applicant_id == 4)
        assert result_zero_income.decision == LoanDecision.MANUAL_REVIEW # or Denied depending on other factors
        assert result_zero_income.debt_to_income_ratio == float('inf')


# --- ReportGenerator Tests (FR4) ---


class TestReportGenerator:
    """Tests the console output generation."""

    @pytest.fixture
    def report_generator(self) -> ReportGenerator:
        """Provides a ReportGenerator instance."""
        return ReportGenerator()

    def test_generate_summary_no_results(
        self, report_generator: ReportGenerator, capsys
    ):
        """FR4: Test report generation for an empty result set."""
        report_generator.generate_summary([])
        captured = capsys.readouterr()
        assert "No applications to report." in captured.out

    def test_generate_summary_with_results(
        self, report_generator: ReportGenerator, perfect_applicant: Applicant,
        weak_applicant: Applicant, capsys
    ):
        """FR4: Test report generation with a standard set of results."""
        results = [
            LoanApplicationResult(
                applicant=perfect_applicant, debt_to_income_ratio=0.1,
                loan_to_value_ratio=0.5, risk_score=95, decision=LoanDecision.APPROVED
            ),
            LoanApplicationResult(
                applicant=weak_applicant, debt_to_income_ratio=0.625,
                loan_to_value_ratio=1.11, risk_score=25, decision=LoanDecision.DENIED
            )
        ]
        report_generator.generate_summary(results)
        captured = capsys.readouterr()
        output = captured.out

        # Check for key sections
        assert "--- Loan Application Decision Summary ---" in output
        assert "Detailed Results:" in output
        assert "Aggregate Summary:" in output
        assert "--- End of Report ---" in output

        # Check for detailed content
        assert str(perfect_applicant.applicant_id) in output
        assert "95" in output
        assert "Approved" in output
        assert str(weak_applicant.applicant_id) in output
        assert "25" in output
        assert "Denied" in output

        # Check for aggregate content
        assert "Approved         : 1   (50.0%)" in output
        assert "Manual Review    : 0   (0.0%)" in output
        assert "Denied           : 1   (50.0%)" in output
        assert "Total Applications: 2" in output