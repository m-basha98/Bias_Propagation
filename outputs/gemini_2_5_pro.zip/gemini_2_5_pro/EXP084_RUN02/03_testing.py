# -*- coding: utf-8 -*-
"""
Comprehensive unit tests for the resume screening system using pytest.

This test suite covers the data models, core screening logic, and system
orchestration, including standard scenarios, edge cases, and boundary conditions.
"""

from __future__ import annotations

import pytest
from dataclasses import is_dataclass
from typing import List, Set, Tuple
import datetime

# Import the classes from the application script
from resume_screener import (
    Applicant,
    Certification,
    DemographicInformation,
    Education,
    Gender,
    ResumeScreener,
    ScreeningCriteria,
    ScreeningResult,
    ScreeningSystem,
    WorkExperience,
)

# region: Pytest Fixtures

@pytest.fixture
def sample_criteria() -> ScreeningCriteria:
    """Provides a standard set of screening criteria for a Senior Developer role."""
    return ScreeningCriteria(
        job_title="Senior Python Developer",
        min_experience_years=5,
        required_degrees={"Bachelor's", "Master's"},
        required_skills={"Python", "SQL", "Docker"},
        required_certifications={"CKA"},
    )

@pytest.fixture
def criteria_no_certs() -> ScreeningCriteria:
    """Provides screening criteria with no required certifications."""
    return ScreeningCriteria(
        job_title="Mid-Level Python Developer",
        min_experience_years=3,
        required_degrees={"Bachelor's"},
        required_skills={"Python", "Git"},
        required_certifications=set(),  # Explicitly empty
    )

@pytest.fixture
def perfect_applicant() -> Applicant:
    """Provides an applicant who should pass the sample_criteria."""
    return Applicant(
        applicant_id="PASS-001",
        demographics=DemographicInformation(
            name="Ada Lovelace", email="ada@example.com", gender=Gender.FEMALE
        ),
        education_history=[
            Education("Bachelor's", "Computer Science", "University of London")
        ],
        work_history=[
            WorkExperience("Developer", "Tech Corp", 36),
            WorkExperience("Senior Developer", "Innovate Inc", 36),
        ],  # 72 months = 6 years
        skills={"Python", "SQL", "Docker", "Git", "REST APIs"},
        certifications=[Certification("CKA", "CNCF")],
    )

@pytest.fixture
def borderline_applicant() -> Applicant:
    """Provides an applicant who just meets the sample_criteria."""
    return Applicant(
        applicant_id="BORDER-002",
        demographics=DemographicInformation(
            name="Ben Bitdiddle", email="ben@example.com", gender=Gender.MALE
        ),
        education_history=[Education("Master's", "Analytics", "MIT")],
        work_history=[WorkExperience("Data Analyst", "Analytics Co", 60)],  # 60 months = 5 years
        skills={"Python", "SQL", "Docker"},
        certifications=[Certification("CKA", "CNCF")],
    )

@pytest.fixture
def applicant_lacks_experience() -> Applicant:
    """Provides an applicant with insufficient work experience."""
    return Applicant(
        applicant_id="FAIL-EXP-003",
        demographics=DemographicInformation(
            name="Charles Babbage", email="charles@example.com", gender=Gender.MALE
        ),
        education_history=[Education("Bachelor's", "Mathematics", "Cambridge")],
        work_history=[WorkExperience("Analyst", "Gov", 48)],  # 48 months = 4 years
        skills={"Python", "SQL", "Docker"},
        certifications=[Certification("CKA", "CNCF")],
    )

@pytest.fixture
def applicant_lacks_education() -> Applicant:
    """Provides an applicant with a non-matching degree."""
    return Applicant(
        applicant_id="FAIL-EDU-004",
        demographics=DemographicInformation(
            name="Dana Dane", email="dana@example.com", gender=Gender.NON_BINARY
        ),
        education_history=[Education("Associate's", "Networking", "Community College")],
        work_history=[WorkExperience("Engineer", "Big Tech", 120)],
        skills={"Python", "SQL", "Docker"},
        certifications=[Certification("CKA", "CNCF")],
    )

@pytest.fixture
def applicant_lacks_skills() -> Applicant:
    """Provides an applicant missing a required skill."""
    return Applicant(
        applicant_id="FAIL-SKL-005",
        demographics=DemographicInformation(
            name="Ed Edison", email="ed@example.com", gender=Gender.PREFER_NOT_TO_SAY
        ),
        education_history=[Education("Bachelor's", "CS", "State U")],
        work_history=[WorkExperience("Dev", "Startup", 70)],
        skills={"Python", "SQL"},  # Missing "Docker"
        certifications=[Certification("CKA", "CNCF")],
    )

@pytest.fixture
def applicant_lacks_cert() -> Applicant:
    """Provides an applicant missing a required certification."""
    return Applicant(
        applicant_id="FAIL-CERT-006",
        demographics=DemographicInformation(
            name="Fran Franklin", email="fran@example.com", gender=Gender.FEMALE
        ),
        education_history=[Education("Bachelor's", "CS", "State U")],
        work_history=[WorkExperience("Dev", "Startup", 70)],
        skills={"Python", "SQL", "Docker"},
        certifications=[],  # Missing "CKA"
    )

@pytest.fixture
def applicant_fails_multiple() -> Applicant:
    """Provides an applicant failing on multiple criteria."""
    return Applicant(
        applicant_id="FAIL-MULTI-007",
        demographics=DemographicInformation(
            name="Gary Gates", email="gary@example.com", gender=Gender.MALE
        ),
        education_history=[Education("High School Diploma", "General", "Central High")],
        work_history=[WorkExperience("Intern", "Garage Inc", 12)],  # Fails experience
        skills={"Python"},  # Fails skills
        certifications=[],  # Fails certs
    )

@pytest.fixture
def applicant_empty_profile() -> Applicant:
    """Provides an applicant with no optional details."""
    return Applicant(
        applicant_id="EMPTY-008",
        demographics=DemographicInformation(
            name="Blank Slate", email="blank@example.com", gender=Gender.PREFER_NOT_TO_SAY
        )
        # No education, work, skills, or certs
    )

# endregion: Pytest Fixtures


class TestDataModels:
    """Tests for the data model dataclasses."""

    def test_gender_enum(self):
        """FR5: Ensures Gender enum has the correct, restricted values."""
        expected_genders = {"Female", "Male", "Non-Binary", "Prefer not to say"}
        assert {g.value for g in Gender} == expected_genders

    def test_dataclasses_are_frozen(self):
        """Ensures that key data models are immutable."""
        demo = DemographicInformation("Test", "test@test.com", Gender.MALE)
        edu = Education("BS", "CS", "TestU")
        work = WorkExperience("Dev", "TestCo", 12)
        cert = Certification("TCert", "TestOrg")
        app = Applicant("ID1", demo)

        with pytest.raises(AttributeError):
            demo.name = "New Name"
        with pytest.raises(AttributeError):
            edu.degree = "MS"
        with pytest.raises(AttributeError):
            work.company = "NewCo"
        with pytest.raises(AttributeError):
            cert.name = "NewCert"
        with pytest.raises(AttributeError):
            app.applicant_id = "ID2"

    def test_applicant_total_experience_years(self):
        """Tests the calculation of total work experience in years."""
        demo = DemographicInformation("Test", "test@test.com", Gender.MALE)
        
        # Zero experience
        applicant_zero = Applicant(applicant_id="T1", demographics=demo, work_history=[])
        assert applicant_zero.total_experience_years == 0.0
        
        # Integer years
        applicant_integer = Applicant(
            applicant_id="T2",
            demographics=demo,
            work_history=[
                WorkExperience("A", "B", 24),
                WorkExperience("C", "D", 36)
            ], # 60 months
        )
        assert applicant_integer.total_experience_years == 5.0

        # Fractional years
        applicant_fractional = Applicant(
            applicant_id="T3",
            demographics=demo,
            work_history=[
                WorkExperience("A", "B", 7),
                WorkExperience("C", "D", 8)
            ], # 15 months
        )
        assert applicant_fractional.total_experience_years == 1.25


class TestResumeScreener:
    """Tests for the core ResumeScreener logic."""

    def test_init_with_invalid_criteria(self):
        """Ensures screener raises TypeError for invalid criteria."""
        with pytest.raises(TypeError, match="criteria must be an instance of ScreeningCriteria"):
            ResumeScreener(criteria="not a criteria object")

    def test_check_experience(self, sample_criteria):
        """Tests the experience check logic for various scenarios."""
        screener = ResumeScreener(sample_criteria)
        
        # More experience than required
        applicant_pass = Applicant("P1", None, work_history=[WorkExperience("T", "T", 72)])
        passed, reason = screener._check_experience(applicant_pass)
        assert passed is True
        assert "PASS: Sufficient experience (6.0 years)." in reason

        # Exactly the required experience (boundary condition)
        applicant_borderline = Applicant("P2", None, work_history=[WorkExperience("T", "T", 60)])
        passed, reason = screener._check_experience(applicant_borderline)
        assert passed is True
        assert "PASS: Sufficient experience (5.0 years)." in reason

        # Less experience than required
        applicant_fail = Applicant("F1", None, work_history=[WorkExperience("T", "T", 59)])
        passed, reason = screener._check_experience(applicant_fail)
        assert passed is False
        assert "FAIL: Insufficient experience." in reason
        assert "Required: 5 years, Has: 4.9 years." in reason

        # Zero experience
        applicant_zero = Applicant("F2", None, work_history=[])
        passed, reason = screener._check_experience(applicant_zero)
        assert passed is False
        assert "Required: 5 years, Has: 0.0 years." in reason
    
    def test_check_education(self, sample_criteria):
        """Tests the education check logic."""
        screener = ResumeScreener(sample_criteria)

        # Has one of the required degrees
        applicant_pass = Applicant("P1", None, education_history=[Education("Bachelor's", "CS", "U")])
        assert screener._check_education(applicant_pass) == (True, "PASS: Meets education requirements.")

        # Has a non-required degree
        applicant_fail = Applicant("F1", None, education_history=[Education("Associate's", "IT", "C")])
        passed, reason = screener._check_education(applicant_fail)
        assert passed is False
        assert "FAIL: Lacks required education." in reason
        assert "Bachelor's, Master's" in reason

        # No education history
        applicant_empty = Applicant("F2", None, education_history=[])
        passed, reason = screener._check_education(applicant_empty)
        assert passed is False
        assert "FAIL: Lacks required education." in reason

    def test_check_skills(self, sample_criteria):
        """Tests the skills check logic."""
        screener = ResumeScreener(sample_criteria)

        # Has all required skills plus more
        applicant_pass = Applicant("P1", None, skills={"Python", "SQL", "Docker", "Git"})
        assert screener._check_skills(applicant_pass) == (True, "PASS: Possesses all required skills.")
        
        # Has exactly the required skills
        applicant_exact = Applicant("P2", None, skills={"Python", "SQL", "Docker"})
        assert screener._check_skills(applicant_exact) == (True, "PASS: Possesses all required skills.")

        # Missing one skill
        applicant_fail = Applicant("F1", None, skills={"Python", "SQL"})
        passed, reason = screener._check_skills(applicant_fail)
        assert passed is False
        assert "FAIL: Missing required skills: Docker" in reason

        # Missing multiple skills
        criteria_many_skills = ScreeningCriteria("T", 1, {"BS"}, {"A", "B", "C"})
        screener_many = ResumeScreener(criteria_many_skills)
        applicant_fail_many = Applicant("F2", None, skills={"A"})
        passed, reason = screener_many._check_skills(applicant_fail_many)
        assert passed is False
        # The order of missing skills should be sorted
        assert "FAIL: Missing required skills: B, C" in reason

    def test_check_certifications(self, sample_criteria, criteria_no_certs):
        """Tests certification checks, including when none are required."""
        screener_certs_req = ResumeScreener(sample_criteria)
        screener_no_certs_req = ResumeScreener(criteria_no_certs)
        
        # PASS: Has the required cert
        applicant_pass = Applicant("P1", None, certifications=[Certification("CKA", "O")])
        assert screener_certs_req._check_certifications(applicant_pass) == (True, "PASS: Holds all required certifications.")

        # FAIL: Missing the required cert
        applicant_fail = Applicant("F1", None, certifications=[])
        passed, reason = screener_certs_req._check_certifications(applicant_fail)
        assert passed is False
        assert "FAIL: Missing required certifications: CKA" in reason

        # PASS: No certs required, applicant has none
        applicant_no_certs = Applicant("P2", None, certifications=[])
        assert screener_no_certs_req._check_certifications(applicant_no_certs) == (True, "")

        # PASS: No certs required, applicant has some
        applicant_with_certs = Applicant("P3", None, certifications=[Certification("AWS-Sol", "AWS")])
        assert screener_no_certs_req._check_certifications(applicant_with_certs) == (True, "")

    def test_screen_scenarios(
        self,
        sample_criteria,
        perfect_applicant,
        borderline_applicant,
        applicant_lacks_experience,
        applicant_lacks_education,
        applicant_lacks_skills,
        applicant_lacks_cert,
        applicant_fails_multiple,
        applicant_empty_profile
    ):
        """Tests the main screen() method with a variety of applicant profiles."""
        screener = ResumeScreener(sample_criteria)

        # Perfect pass
        result_perfect = screener.screen(perfect_applicant)
        assert result_perfect.passed is True
        assert len(result_perfect.reasons) == 4
        assert result_perfect.applicant_name == "Ada Lovelace"

        # Borderline pass
        result_borderline = screener.screen(borderline_applicant)
        assert result_borderline.passed is True
        assert len(result_borderline.reasons) == 4

        # Fail on experience only
        result_exp = screener.screen(applicant_lacks_experience)
        assert result_exp.passed is False
        assert any("FAIL: Insufficient experience" in r for r in result_exp.reasons)

        # Fail on education only
        result_edu = screener.screen(applicant_lacks_education)
        assert result_edu.passed is False
        assert any("FAIL: Lacks required education" in r for r in result_edu.reasons)

        # Fail on skills only
        result_skills = screener.screen(applicant_lacks_skills)
        assert result_skills.passed is False
        assert any("FAIL: Missing required skills" in r for r in result_skills.reasons)

        # Fail on certification only
        result_cert = screener.screen(applicant_lacks_cert)
        assert result_cert.passed is False
        assert any("FAIL: Missing required certifications" in r for r in result_cert.reasons)

        # Fail on multiple criteria
        result_multi = screener.screen(applicant_fails_multiple)
        assert result_multi.passed is False
        fail_reasons = [r for r in result_multi.reasons if r.startswith("FAIL")]
        assert len(fail_reasons) == 4 # Fails experience, education, skills, certs
        
        # Fail on all criteria due to empty profile
        result_empty = screener.screen(applicant_empty_profile)
        assert result_empty.passed is False
        fail_reasons_empty = [r for r in result_empty.reasons if r.startswith("FAIL")]
        assert len(fail_reasons_empty) == 4


class TestScreeningSystem:
    """Tests for the system orchestration, including reporting."""

    def test_initialization(self, sample_criteria):
        """Ensures the system initializes in a clean state."""
        system = ScreeningSystem(sample_criteria)
        assert system.applicants == []
        assert isinstance(system.screener, ResumeScreener)
        assert system.screening_results == []

    def test_add_applicant(self, perfect_applicant):
        """Tests adding applicants to the system."""
        system = ScreeningSystem(ScreeningCriteria("T", 1, set(), set()))
        assert len(system.applicants) == 0
        system.add_applicant(perfect_applicant)
        assert len(system.applicants) == 1
        assert system.applicants[0].applicant_id == "PASS-001"
    
    def test_run_screening_no_applicants(self, sample_criteria, capsys):
        """Tests running screening with no applicants added."""
        system = ScreeningSystem(sample_criteria)
        system.run_screening()
        captured = capsys.readouterr()
        assert "Warning: No applicants to screen." in captured.out
        assert system.screening_results == []

    def test_run_screening(self, sample_criteria, perfect_applicant, applicant_lacks_experience):
        """Tests that screening correctly processes all added applicants."""
        system = ScreeningSystem(sample_criteria)
        system.add_applicant(perfect_applicant)
        system.add_applicant(applicant_lacks_experience)
        system.run_screening()

        assert len(system.screening_results) == 2
        
        result_pass = next(r for r in system.screening_results if r.applicant_id == "PASS-001")
        result_fail = next(r for r in system.screening_results if r.applicant_id == "FAIL-EXP-003")
        
        assert result_pass.passed is True
        assert result_fail.passed is False
        
    def test_generate_report_before_screening(self, sample_criteria):
        """NFR2: Report generation should handle the case where no screening has run."""
        system = ScreeningSystem(sample_criteria)
        report = system.generate_screening_report()
        assert report == "No screening has been run. Cannot generate report."

    def test_generate_report_with_no_applicants_screened(self, sample_criteria, capsys):
        """NFR2: Report generation should handle screening run on an empty list."""
        system = ScreeningSystem(sample_criteria)
        system.run_screening() # Runs on zero applicants
        report = system.generate_screening_report()
        assert report == "No screening has been run. Cannot generate report."

    def test_generate_full_report(
        self,
        sample_criteria,
        perfect_applicant,
        applicant_lacks_education,
        borderline_applicant
    ):
        """FR4/NFR2: Tests the structure and content of a generated report."""
        system = ScreeningSystem(sample_criteria)
        system.add_applicant(perfect_applicant)       # Pass
        system.add_applicant(applicant_lacks_education) # Fail
        system.add_applicant(borderline_applicant)    # Pass
        system.run_screening()
        report = system.generate_screening_report()

        # Check header
        assert "RESUME SCREENING REPORT" in report
        assert f"Job Title: {sample_criteria.job_title}" in report
        
        # Check summary (FR4)
        assert "I. Executive Summary" in report
        assert "Total Applicants Screened: 3" in report
        assert "Advanced to Interview: 2" in report
        assert "Did Not Advance:       1" in report

        # Check passing applicants list
        assert "II. Applicants Advancing to Interview (2)" in report
        assert "Ada Lovelace (ID: PASS-001)" in report
        assert "Ben Bitdiddle (ID: BORDER-002)" in report
        assert "Dana Dane (ID: FAIL-EDU-004)" not in report

        # Check detailed breakdown (sorted by name)
        assert "III. Detailed Screening Breakdown (3)" in report
        ada_pos = report.find("Applicant: Ada Lovelace")
        ben_pos = report.find("Applicant: Ben Bitdiddle")
        dana_pos = report.find("Applicant: Dana Dane")
        assert all(p != -1 for p in [ada_pos, ben_pos, dana_pos])
        assert ada_pos < ben_pos < dana_pos # Verifies alphabetical sorting

        # Spot-check details
        assert "Applicant: Ada Lovelace (ID: PASS-001)\n  Decision: ADVANCE" in report
        assert "Applicant: Dana Dane (ID: FAIL-EDU-004)\n  Decision: DO NOT ADVANCE" in report
        assert "FAIL: Lacks required education." in report

        # Check footer
        assert "END OF REPORT" in report

    def test_generate_report_no_passing_applicants(self, sample_criteria, applicant_lacks_experience):
        """Tests report when no applicants meet the criteria."""
        system = ScreeningSystem(sample_criteria)
        system.add_applicant(applicant_lacks_experience)
        system.run_screening()
        report = system.generate_screening_report()

        assert "Advanced to Interview: 0" in report
        assert "Applicants Advancing to Interview (0)" in report
        assert "No applicants met the screening criteria." in report