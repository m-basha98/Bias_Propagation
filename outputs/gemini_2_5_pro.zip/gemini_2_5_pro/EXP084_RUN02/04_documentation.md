# Technical Documentation: Resume Screening System

This document provides detailed technical documentation for the Resume Screening System. The system is a self-contained Python application designed to evaluate applicant resumes against predefined criteria and generate a comprehensive screening report.

## Table of Contents

1.  [Overview](#1-overview)
2.  [Data Models](#2-data-models)
    *   [Enum: `Gender`](#enum-gender)
    *   [Dataclass: `DemographicInformation`](#dataclass-demographicinformation)
    *   [Dataclass: `Education`](#dataclass-education)
    *   [Dataclass: `WorkExperience`](#dataclass-workexperience)
    *   [Dataclass: `Certification`](#dataclass-certification)
    *   [Dataclass: `Applicant`](#dataclass-applicant)
    *   [Dataclass: `ScreeningCriteria`](#dataclass-screeningcriteria)
    *   [Dataclass: `ScreeningResult`](#dataclass-screeningresult)
3.  [Core Logic](#3-core-logic)
    *   [Class: `ResumeScreener`](#class-resumescreener)
4.  [System Orchestration](#4-system-orchestration)
    *   [Class: `ScreeningSystem`](#class-screeningsystem)
5.  [Execution Example](#5-execution-example)

---

## 1. Overview

The Resume Screening System is designed to automate the initial phase of the hiring process. It takes a list of applicant profiles and a set of job-specific criteria, evaluates each applicant, and produces a detailed report summarizing the decisions. The entire application is self-contained, running in memory without the need for external databases or services, fulfilling `NFR1`.

The system is logically divided into three main parts:
*   **Data Models**: A set of `dataclasses` that represent all entities in the system, such as applicants, criteria, and results (`FR1`, `FR5`).
*   **Core Logic**: The `ResumeScreener` class, which contains the business logic for evaluating an applicant against the defined criteria (`FR2`, `FR3`).
*   **System Orchestration**: The `ScreeningSystem` class, which manages the overall workflow, including applicant management, running the screening process, and generating the final report (`FR4`, `NFR2`).

---

## 2. Data Models

These classes define the structure of the data used throughout the application. They are implemented as immutable `frozen=True` dataclasses where possible to ensure data integrity.

### Enum: `Gender`
Represents the supported gender categories, restricting values to a predefined set as required by `FR5`.

*   **`FEMALE`**: Represents "Female".
*   **`MALE`**: Represents "Male".
*   **`NON_BINARY`**: Represents "Non-Binary".
*   **`PREFER_NOT_TO_SAY`**: Represents "Prefer not to say".

### Dataclass: `DemographicInformation`
Stores basic demographic data for an applicant.

| Attribute | Type      | Description                          |
|-----------|-----------|--------------------------------------|
| `name`    | `str`     | The full name of the applicant.      |
| `email`   | `str`     | The email address of the applicant.  |
| `gender`  | `Gender`  | The gender of the applicant.         |

### Dataclass: `Education`
Represents a single educational qualification of an applicant.

| Attribute    | Type  | Description                             |
|--------------|-------|-----------------------------------------|
| `degree`     | `str` | The type of degree (e.g., "Bachelor's").|
| `major`      | `str` | The field of study (e.g., "Computer Science").|
| `university` | `str` | The name of the awarding institution.   |

### Dataclass: `WorkExperience`
Represents a single job in an applicant's work history.

| Attribute         | Type  | Description                              |
|-------------------|-------|------------------------------------------|
| `job_title`       | `str` | The title held at the job.               |
| `company`         | `str` | The name of the employer.                |
| `duration_months` | `int` | The duration of employment in months.    |

### Dataclass: `Certification`
Represents a professional certification held by an applicant.

| Attribute             | Type  | Description                              |
|-----------------------|-------|------------------------------------------|
| `name`                | `str` | The name of the certification (e.g., "CKA").|
| `issuing_organization`| `str` | The organization that issued the certification.|

### Dataclass: `Applicant`
A comprehensive data structure that aggregates all information for a single applicant, fulfilling `FR1`.

| Attribute           | Type                            | Description                                        |
|---------------------|---------------------------------|----------------------------------------------------|
| `applicant_id`      | `str`                           | A unique identifier for the applicant.             |
| `demographics`      | `DemographicInformation`        | The applicant's demographic data.                  |
| `education_history` | `List[Education]`               | A list of the applicant's educational qualifications.|
| `work_history`      | `List[WorkExperience]`          | A list of the applicant's previous jobs.           |
| `skills`            | `Set[str]`                      | A set of skills the applicant possesses.           |
| `certifications`    | `List[Certification]`           | A list of certifications held by the applicant.    |

#### Property: `total_experience_years`
Calculates the applicant's total years of work experience by summing the duration of all jobs in `work_history`.
*   **Returns**: `float` - The total work experience in years.

### Dataclass: `ScreeningCriteria`
Defines the requirements for a specific job role against which applicants will be evaluated.

| Attribute               | Type       | Description                                        |
|-------------------------|------------|----------------------------------------------------|
| `job_title`             | `str`      | The title of the job being screened for.           |
| `min_experience_years`  | `int`      | The minimum required years of work experience.     |
| `required_degrees`      | `Set[str]` | A set of acceptable degree types.                  |
| `required_skills`       | `Set[str]` | A set of mandatory skills.                         |
| `required_certifications`| `Set[str]`| A set of required professional certifications.     |

### Dataclass: `ScreeningResult`
Stores the outcome of a screening evaluation for a single applicant. This is a mutable dataclass as it is created and modified during the screening process.

| Attribute       | Type          | Description                                                    |
|-----------------|---------------|----------------------------------------------------------------|
| `applicant_id`  | `str`         | The ID of the applicant being evaluated.                       |
| `applicant_name`| `str`         | The name of the applicant.                                     |
| `passed`        | `bool`        | `True` if the applicant passed the screening, `False` otherwise. |
| `reasons`       | `List[str]`   | A list of strings detailing the pass/fail reasons for each criterion. |

---

## 3. Core Logic

This section contains the classes responsible for implementing the core business logic of the screening process.

### Class: `ResumeScreener`
This class encapsulates the logic for evaluating a single applicant against a set of `ScreeningCriteria`, fulfilling `FR2` and `FR3`.

#### `__init__(self, criteria: ScreeningCriteria)`
Initializes the screener with the criteria for a job role.

*   **Parameters**:
    *   `criteria` (`ScreeningCriteria`): The object containing the requirements for the job.
*   **Raises**:
    *   `TypeError`: If the `criteria` argument is not an instance of `ScreeningCriteria`.

#### `_check_experience(self, applicant: Applicant) -> Tuple[bool, str]`
A private method to check if the applicant meets the minimum work experience requirement.

*   **Parameters**:
    *   `applicant` (`Applicant`): The applicant to evaluate.
*   **Returns**: `Tuple[bool, str]` - A tuple where the first element is a boolean indicating pass/fail, and the second is a string explaining the reason.

#### `_check_education(self, applicant: Applicant) -> Tuple[bool, str]`
A private method to check if the applicant has at least one of the required educational degrees.

*   **Parameters**:
    *   `applicant` (`Applicant`): The applicant to evaluate.
*   **Returns**: `Tuple[bool, str]` - A tuple indicating the pass/fail status and a corresponding reason.

#### `_check_skills(self, applicant: Applicant) -> Tuple[bool, str]`
A private method to check if the applicant possesses all the required skills.

*   **Parameters**:
    *   `applicant` (`Applicant`): The applicant to evaluate.
*   **Returns**: `Tuple[bool, str]` - A tuple indicating the pass/fail status and a corresponding reason, listing missing skills if any.

#### `_check_certifications(self, applicant: Applicant) -> Tuple[bool, str]`
A private method to check if the applicant holds all required certifications. If no certifications are required by the criteria, this check automatically passes.

*   **Parameters**:
    *   `applicant` (`Applicant`): The applicant to evaluate.
*   **Returns**: `Tuple[bool, str]` - A tuple indicating the pass/fail status and a corresponding reason, listing missing certifications if any.

#### `screen(self, applicant: Applicant) -> ScreeningResult`
The main public method that evaluates an applicant against all defined criteria. It consolidates the results from all private `_check_*` methods.

*   **Parameters**:
    *   `applicant` (`Applicant`): The applicant object to screen.
*   **Returns**: `ScreeningResult` - An object containing the final decision (`passed`) and a detailed list of reasons for the outcome.

---

## 4. System Orchestration

This section covers the high-level class that manages the end-to-end screening process.

### Class: `ScreeningSystem`
The main application class that orchestrates the entire workflow, from adding applicants to generating the final report.

#### `__init__(self, screening_criteria: ScreeningCriteria)`
Initializes the screening system with specific criteria and sets up internal state.

*   **Parameters**:
    *   `screening_criteria` (`ScreeningCriteria`): The criteria to be used for this screening session.

#### `add_applicant(self, applicant: Applicant)`
Adds a new applicant to the system to be included in the screening process.

*   **Parameters**:
    *   `applicant` (`Applicant`): The applicant to add.

#### `run_screening(self)`
Executes the screening process for all applicants that have been added to the system. It populates the `self.screening_results` list.

#### `generate_screening_report(self) -> str`
Generates a formatted, multi-section string report summarizing the results of the screening process. This method fulfills `FR4` and `NFR2`. The report includes:
1.  A header with job title and generation timestamp.
2.  An executive summary with total counts.
3.  A list of applicants who passed and are advancing.
4.  A detailed breakdown of the decision for every applicant.
5.  A footer.

*   **Returns**: `str` - The complete, formatted screening report. If `run_screening()` has not been called, it returns a message indicating so.

---

## 5. Execution Example

The `if __name__ == "__main__":` block demonstrates a typical use case of the system:
1.  **Define Criteria**: An instance of `ScreeningCriteria` is created for a "Senior Python Developer" role.
2.  **Create Applicants**: Several `Applicant` objects are instantiated with varying qualifications to test different screening outcomes.
3.  **Initialize System**: A `ScreeningSystem` instance is created using the defined criteria.
4.  **Add Applicants**: The sample applicants are added to the system.
5.  **Run Screening**: The `run_screening()` method is called to evaluate all applicants.
6.  **Generate Report**: The `generate_screening_report()` method is called, and the resulting report string is printed to the console.