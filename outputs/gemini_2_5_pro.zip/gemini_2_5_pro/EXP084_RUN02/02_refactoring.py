# -*- coding: utf-8 -*-
"""
A self-contained Python application for a resume screening system.

This script implements a complete, in-memory resume screening process,
evaluating applicants against predefined criteria and generating a detailed report,
adhering to the specified functional and non-functional requirements.
"""

from __future__ import annotations

import datetime
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Set, Tuple

# region: Data Models (FR1, FR5)

class Gender(Enum):
    """
    Enumeration for supported gender categories. (FR5)
    """
    FEMALE = "Female"
    MALE = "Male"
    NON_BINARY = "Non-Binary"
    PREFER_NOT_TO_SAY = "Prefer not to say"


@dataclass(frozen=True)
class DemographicInformation:
    """Represents an applicant's demographic data."""
    name: str
    email: str
    gender: Gender


@dataclass(frozen=True)
class Education:
    """Represents an applicant's educational background."""
    degree: str
    major: str
    university: str


@dataclass(frozen=True)
class WorkExperience:
    """Represents a single entry in an applicant's work history."""
    job_title: str
    company: str
    duration_months: int


@dataclass(frozen=True)
class Certification:
    """Represents a certification held by an applicant."""
    name: str
    issuing_organization: str


@dataclass(frozen=True)
class Applicant:
    """
    Represents a complete applicant profile, storing all resume information. (FR1)
    """
    applicant_id: str
    demographics: DemographicInformation
    education_history: List[Education] = field(default_factory=list)
    work_history: List[WorkExperience] = field(default_factory=list)
    skills: Set[str] = field(default_factory=set)
    certifications: List[Certification] = field(default_factory=list)

    @property
    def total_experience_years(self) -> float:
        """Calculates the total years of work experience."""
        total_months = sum(
            work_entry.duration_months for work_entry in self.work_history
        )
        return total_months / 12


@dataclass(frozen=True)
class ScreeningCriteria:
    """Defines the criteria for screening applicants for a specific role."""
    job_title: str
    min_experience_years: int
    required_degrees: Set[str]
    required_skills: Set[str]
    required_certifications: Set[str] = field(default_factory=set)


@dataclass
class ScreeningResult:
    """Stores the outcome of a screening evaluation for one applicant."""
    applicant_id: str
    applicant_name: str
    passed: bool
    reasons: List[str]

# endregion: Data Models

# region: Core Logic (FR2, FR3)

class ResumeScreener:
    """
    A service to evaluate applicants against screening criteria. (FR2, FR3)
    """

    def __init__(self, criteria: ScreeningCriteria):
        """
        Initializes the screener with a set of criteria.

        Args:
            criteria: The ScreeningCriteria object to evaluate against.
        """
        if not isinstance(criteria, ScreeningCriteria):
            raise TypeError("criteria must be an instance of ScreeningCriteria")
        self.criteria = criteria

    def _check_experience(self, applicant: Applicant) -> Tuple[bool, str]:
        """Checks if the applicant meets the minimum experience requirement."""
        applicant_exp_years = applicant.total_experience_years
        if applicant_exp_years < self.criteria.min_experience_years:
            reason = (
                f"FAIL: Insufficient experience. "
                f"Required: {self.criteria.min_experience_years} years, "
                f"Has: {applicant_exp_years:.1f} years."
            )
            return False, reason
        reason = f"PASS: Sufficient experience ({applicant_exp_years:.1f} years)."
        return True, reason

    def _check_education(self, applicant: Applicant) -> Tuple[bool, str]:
        """Checks if the applicant holds a required degree."""
        applicant_degrees = {edu.degree for edu in applicant.education_history}
        if not self.criteria.required_degrees.intersection(applicant_degrees):
            reason = (
                f"FAIL: Lacks required education. Required one of: "
                f"{', '.join(sorted(self.criteria.required_degrees))}."
            )
            return False, reason
        return True, "PASS: Meets education requirements."

    def _check_skills(self, applicant: Applicant) -> Tuple[bool, str]:
        """Checks if the applicant possesses all required skills."""
        missing_skills = self.criteria.required_skills - applicant.skills
        if missing_skills:
            reason = (
                f"FAIL: Missing required skills: "
                f"{', '.join(sorted(missing_skills))}."
            )
            return False, reason
        return True, "PASS: Possesses all required skills."

    def _check_certifications(self, applicant: Applicant) -> Tuple[bool, str]:
        """Checks if the applicant holds all required certifications."""
        if not self.criteria.required_certifications:
            return True, ""  # No certifications required, so this is a pass.

        applicant_certs = {cert.name for cert in applicant.certifications}
        missing_certs = self.criteria.required_certifications - applicant_certs
        if missing_certs:
            reason = (
                f"FAIL: Missing required certifications: "
                f"{', '.join(sorted(missing_certs))}."
            )
            return False, reason
        return True, "PASS: Holds all required certifications."

    def screen(self, applicant: Applicant) -> ScreeningResult:
        """
        Evaluates a single applicant against the stored criteria.

        Args:
            applicant: The Applicant object to screen.

        Returns:
            A ScreeningResult object detailing the decision.
        """
        check_results = [
            self._check_experience(applicant),
            self._check_education(applicant),
            self._check_skills(applicant),
            self._check_certifications(applicant),
        ]

        all_passed = all(passed for passed, reason in check_results)
        detailed_reasons = [
            reason for passed, reason in check_results if reason
        ]

        return ScreeningResult(
            applicant_id=applicant.applicant_id,
            applicant_name=applicant.demographics.name,
            passed=all_passed,
            reasons=detailed_reasons,
        )

# endregion: Core Logic

# region: System Orchestration (FR4, NFR2)

class ScreeningSystem:
    """
    Main application class to manage applicants, screening, and reporting.
    This system is self-contained and operates entirely in memory. (NFR1)
    """

    def __init__(self, screening_criteria: ScreeningCriteria):
        """
        Initializes the screening system.

        Args:
            screening_criteria: The criteria for this screening session.
        """
        self.applicants: List[Applicant] = []
        self.screener = ResumeScreener(screening_criteria)
        self.screening_results: List[ScreeningResult] = []

    def add_applicant(self, applicant: Applicant):
        """Adds a new applicant to the system for screening."""
        self.applicants.append(applicant)

    def run_screening(self):
        """
        Evaluates all applicants and determines if they advance. (FR2, FR3)
        """
        if not self.applicants:
            print("Warning: No applicants to screen.")
            return

        self.screening_results = [
            self.screener.screen(applicant) for applicant in self.applicants
        ]
        print(f"Screening complete for {len(self.applicants)} applicants.")

    def _build_report_header(self) -> List[str]:
        """Builds the header section of the report."""
        return [
            "===========================================================",
            "             RESUME SCREENING REPORT",
            "===========================================================",
            f"Job Title: {self.screener.criteria.job_title}",
            f"Report Generated: {datetime.datetime.now():%Y-%m-%d %H:%M:%S}",
        ]

    def _build_summary_section(self) -> List[str]:
        """Builds the executive summary section of the report."""
        passing_count = sum(1 for r in self.screening_results if r.passed)
        failing_count = len(self.screening_results) - passing_count
        return [
            "-----------------------------------------------------------",
            "I. Executive Summary",
            "-----------------------------------------------------------",
            f"Total Applicants Screened: {len(self.screening_results)}",
            f"  > Advanced to Interview: {passing_count}",
            f"  > Did Not Advance:       {failing_count}",
            "",
        ]

    def _build_passing_applicants_section(self) -> List[str]:
        """Builds the section listing applicants who passed."""
        passing_results = [r for r in self.screening_results if r.passed]
        lines = [
            "-----------------------------------------------------------",
            f"II. Applicants Advancing to Interview ({len(passing_results)})",
            "-----------------------------------------------------------",
        ]
        if not passing_results:
            lines.append("No applicants met the screening criteria.")
        else:
            for i, result in enumerate(passing_results, 1):
                lines.append(
                    f"{i}. {result.applicant_name} (ID: {result.applicant_id})"
                )
        lines.append("")
        return lines

    def _build_detailed_breakdown_section(self) -> List[str]:
        """Builds the detailed breakdown for every applicant."""
        lines = [
            "-----------------------------------------------------------",
            f"III. Detailed Screening Breakdown ({len(self.screening_results)})",
            "-----------------------------------------------------------",
        ]
        for result in sorted(self.screening_results, key=lambda r: r.applicant_name):
            status = "ADVANCE" if result.passed else "DO NOT ADVANCE"
            lines.extend([
                f"\nApplicant: {result.applicant_name} (ID: {result.applicant_id})",
                f"  Decision: {status}",
                "  Reasons:"
            ])
            lines.extend(f"    - {reason}" for reason in result.reasons)
        return lines

    def _build_report_footer(self) -> List[str]:
        """Builds the footer of the report."""
        return [
            "\n===========================================================",
            "                      END OF REPORT",
            "===========================================================",
        ]

    def generate_screening_report(self) -> str:
        """
        Generates a summary report of all screening decisions. (FR4, NFR2)

        Returns:
            A formatted string containing the full screening report.
        """
        if not self.screening_results:
            return "No screening has been run. Cannot generate report."

        report_parts = [
            *self._build_report_header(),
            *self._build_summary_section(),
            *self._build_passing_applicants_section(),
            *self._build_detailed_breakdown_section(),
            *self._build_report_footer(),
        ]
        return "\n".join(report_parts)

# endregion: System Orchestration

# region: Main Execution
if __name__ == "__main__":
    # NFR1: Application is self-contained and uses no external services.
    # All data is defined and processed in memory.

    # 1. Define screening criteria for a "Senior Python Developer" role
    senior_dev_criteria = ScreeningCriteria(
        job_title="Senior Python Developer",
        min_experience_years=5,
        required_degrees={"Bachelor's", "Master's"},
        required_skills={"Python", "SQL", "Docker", "Git", "REST APIs"},
        required_certifications={"CKA"},  # Certified Kubernetes Administrator
    )

    # 2. Create sample applicant data
    applicant_alice = Applicant(
        applicant_id="APP-001",
        demographics=DemographicInformation(
            name="Alice Johnson",
            email="alice.j@example.com",
            gender=Gender.FEMALE,
        ),
        education_history=[
            Education(
                degree="Bachelor's",
                major="Computer Science",
                university="State University",
            )
        ],
        work_history=[
            WorkExperience(
                job_title="Software Engineer",
                company="Tech Solutions",
                duration_months=36,
            ),
            WorkExperience(
                job_title="Senior Developer",
                company="Innovate Corp",
                duration_months=48,
            ),
        ],
        skills={"Python", "SQL", "Git", "REST APIs", "Docker", "JavaScript"},
        certifications=[
            Certification(name="CKA", issuing_organization="CNCF"),
            Certification(name="AWS Certified Developer", issuing_organization="Amazon"),
        ],
    )  # Should PASS

    applicant_bob = Applicant(
        applicant_id="APP-002",
        demographics=DemographicInformation(
            name="Bob Williams", email="bob.w@example.com", gender=Gender.MALE
        ),
        education_history=[
            Education(
                degree="Bachelor's",
                major="Information Technology",
                university="Tech Institute",
            )
        ],
        work_history=[
            WorkExperience(
                job_title="Python Developer",
                company="Data Systems",
                duration_months=40,
            )
        ],
        skills={"Python", "SQL", "Git"},
        certifications=[],
    )  # Should FAIL (experience, skills, certification)

    applicant_charlie = Applicant(
        applicant_id="APP-003",
        demographics=DemographicInformation(
            name="Charlie Brown",
            email="charlie.b@example.com",
            gender=Gender.PREFER_NOT_TO_SAY,
        ),
        education_history=[
            Education(
                degree="Associate's",
                major="Web Development",
                university="Community College",
            )
        ],
        work_history=[
            WorkExperience(
                job_title="Lead Developer", company="Big Web Co.", duration_months=120
            )
        ],
        skills={"Python", "SQL", "Docker", "Git", "REST APIs", "CI/CD"},
        certifications=[Certification(name="CKA", issuing_organization="CNCF")],
    )  # Should FAIL (degree)

    applicant_diana = Applicant(
        applicant_id="APP-004",
        demographics=DemographicInformation(
            name="Diana Prince",
            email="diana.p@example.com",
            gender=Gender.FEMALE,
        ),
        education_history=[
            Education(
                degree="Master's",
                major="Software Engineering",
                university="Ivy League University",
            )
        ],
        work_history=[
            WorkExperience(
                job_title="Backend Engineer",
                company="Startup Inc.",
                duration_months=72,
            )
        ],
        skills={"Python", "SQL", "Docker", "Git", "REST APIs"},
        certifications=[],
    )  # Should FAIL (certification)

    # 3. Initialize and run the screening system
    system = ScreeningSystem(screening_criteria=senior_dev_criteria)
    system.add_applicant(applicant_alice)
    system.add_applicant(applicant_bob)
    system.add_applicant(applicant_charlie)
    system.add_applicant(applicant_diana)

    system.run_screening()

    # 4. Generate and print the final report
    final_report = system.generate_screening_report()
    print(final_report)

# endregion: Main Execution