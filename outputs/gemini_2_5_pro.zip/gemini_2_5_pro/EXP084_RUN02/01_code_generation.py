# -*- coding: utf-8 -*-
"""
A self-contained Python application for a resume screening system.

This script implements a complete, in-memory resume screening process,
evaluating applicants against predefined criteria and generating a detailed report.
"""

from __future__ import annotations
import datetime
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Set, Optional

# =============================================================================
# FR5: Restrict gender values to supported categories
# =============================================================================
class Gender(Enum):
    """Enumeration for supported gender categories."""
    FEMALE = "Female"
    MALE = "Male"
    NON_BINARY = "Non-Binary"
    PREFER_NOT_TO_SAY = "Prefer not to say"


# =============================================================================
# FR1: Store applicant resume information
# =============================================================================

@dataclass(frozen=True)
class DemographicInformation:
    """Represents an applicant's demographic data."""
    name: str
    email: str
    gender: Gender


@dataclass(frozen=True)
class Education:
    """Represents an applicant's educational background."""
    degree: str
    major: str
    university: str


@dataclass(frozen=True)
class WorkExperience:
    """Represents a single entry in an applicant's work history."""
    job_title: str
    company: str
    duration_months: int


@dataclass(frozen=True)
class Certification:
    """Represents a certification held by an applicant."""
    name: str
    issuing_organization: str


@dataclass(frozen=True)
class Applicant:
    """Represents a complete applicant profile."""
    applicant_id: str
    demographics: DemographicInformation
    education_history: List[Education] = field(default_factory=list)
    work_history: List[WorkExperience] = field(default_factory=list)
    skills: Set[str] = field(default_factory=set)
    certifications: List[Certification] = field(default_factory=list)

    @property
    def total_experience_months(self) -> int:
        """Calculates the total months of work experience."""
        return sum(exp.duration_months for exp in self.work_history)


# =============================================================================
# FR2: Evaluate resumes against predefined screening criteria
# =============================================================================

@dataclass(frozen=True)
class ScreeningCriteria:
    """Defines the criteria for screening applicants for a specific role."""
    job_title: str
    min_experience_years: int
    required_degrees: Set[str]
    required_skills: Set[str]
    required_certifications: Set[str] = field(default_factory=set)


@dataclass
class ScreeningResult:
    """Stores the outcome of a screening evaluation for one applicant."""
    applicant_id: str
    applicant_name: str
    passed: bool
    reasons: List[str]


class ResumeScreener:
    """A service to evaluate applicants against screening criteria."""

    def __init__(self, criteria: ScreeningCriteria):
        """
        Initializes the screener with a set of criteria.

        Args:
            criteria: The ScreeningCriteria object to evaluate against.
        """
        if not isinstance(criteria, ScreeningCriteria):
            raise TypeError("criteria must be an instance of ScreeningCriteria")
        self.criteria = criteria

    def screen(self, applicant: Applicant) -> ScreeningResult:
        """
        Evaluates a single applicant against the stored criteria.

        Args:
            applicant: The Applicant object to screen.

        Returns:
            A ScreeningResult object detailing the decision.
        """
        reasons = []
        passed = True

        # 1. Check total experience
        total_years_exp = applicant.total_experience_months / 12
        if total_years_exp < self.criteria.min_experience_years:
            passed = False
            reasons.append(
                f"FAIL: Insufficient experience. "
                f"Required: {self.criteria.min_experience_years} years, "
                f"Has: {total_years_exp:.1f} years."
            )
        else:
            reasons.append(
                f"PASS: Sufficient experience ({total_years_exp:.1f} years)."
            )

        # 2. Check for required degrees
        applicant_degrees = {edu.degree for edu in applicant.education_history}
        if not self.criteria.required_degrees.intersection(applicant_degrees):
            passed = False
            reasons.append(
                f"FAIL: Lacks required education. "
                f"Required one of: {', '.join(self.criteria.required_degrees)}."
            )
        else:
            reasons.append("PASS: Meets education requirements.")

        # 3. Check for required skills
        missing_skills = self.criteria.required_skills - applicant.skills
        if missing_skills:
            passed = False
            reasons.append(
                f"FAIL: Missing required skills: {', '.join(sorted(missing_skills))}."
            )
        else:
            reasons.append("PASS: Possesses all required skills.")

        # 4. Check for required certifications
        applicant_certs = {cert.name for cert in applicant.certifications}
        missing_certs = self.criteria.required_certifications - applicant_certs
        if missing_certs:
            passed = False
            reasons.append(
                f"FAIL: Missing required certifications: {', '.join(sorted(missing_certs))}."
            )
        elif self.criteria.required_certifications:
            reasons.append("PASS: Holds all required certifications.")

        return ScreeningResult(
            applicant_id=applicant.applicant_id,
            applicant_name=applicant.demographics.name,
            passed=passed,
            reasons=reasons
        )


# =============================================================================
# System orchestrator
# =============================================================================

class ScreeningSystem:
    """
    Main application class to manage applicants, screening, and reporting.
    This system is self-contained and operates entirely in memory.
    """

    def __init__(self, screening_criteria: ScreeningCriteria):
        """
        Initializes the screening system.

        Args:
            screening_criteria: The criteria to be used for this screening session.
        """
        self.applicants: List[Applicant] = []
        self.screener = ResumeScreener(screening_criteria)
        self.screening_results: List[ScreeningResult] = []

    def add_applicant(self, applicant: Applicant):
        """Adds a new applicant to the system for screening."""
        self.applicants.append(applicant)

    def run_screening(self):
        """
        FR2 & FR3: Evaluates all added applicants and determines their stage.
        """
        if not self.applicants:
            print("Warning: No applicants to screen.")
            return

        self.screening_results = [
            self.screener.screen(applicant) for applicant in self.applicants
        ]
        print(f"Screening complete for {len(self.applicants)} applicants.")

    def get_passing_applicants(self) -> List[ScreeningResult]:
        """Returns a list of results for applicants who passed screening."""
        return [res for res in self.screening_results if res.passed]

    def get_failing_applicants(self) -> List[ScreeningResult]:
        """Returns a list of results for applicants who failed screening."""
        return [res for res in self.screening_results if not res.passed]

    def generate_screening_report(self) -> str:
        """
        FR4 & NFR2: Generates a summary report of all screening decisions.

        Returns:
            A formatted string containing the full screening report.
        """
        if not self.screening_results:
            return "No screening has been run yet. Cannot generate report."

        passing_results = self.get_passing_applicants()
        failing_results = self.get_failing_applicants()

        report_lines = [
            "===========================================================",
            "             RESUME SCREENING REPORT",
            "===========================================================",
            f"Job Title: {self.screener.criteria.job_title}",
            f"Report Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "-----------------------------------------------------------",
            "I. Executive Summary",
            "-----------------------------------------------------------",
            f"Total Applicants Screened: {len(self.screening_results)}",
            f"  > Advanced to Interview: {len(passing_results)}",
            f"  > Did Not Advance:       {len(failing_results)}",
            "",
            "-----------------------------------------------------------",
            f"II. Applicants Advancing to Interview ({len(passing_results)})",
            "-----------------------------------------------------------",
        ]

        if not passing_results:
            report_lines.append("No applicants met the screening criteria.")
        else:
            for i, result in enumerate(passing_results, 1):
                report_lines.append(f"{i}. {result.applicant_name} (ID: {result.applicant_id})")
        
        report_lines.append("")
        report_lines.append("-----------------------------------------------------------")
        report_lines.append(f"III. Detailed Screening Breakdown ({len(self.screening_results)})")
        report_lines.append("-----------------------------------------------------------")

        for result in self.screening_results:
            status = "ADVANCE" if result.passed else "DO NOT ADVANCE"
            report_lines.append(f"\nApplicant: {result.applicant_name} (ID: {result.applicant_id})")
            report_lines.append(f"  Decision: {status}")
            report_lines.append("  Reasons:")
            for reason in result.reasons:
                report_lines.append(f"    - {reason}")

        report_lines.append("\n===========================================================")
        report_lines.append("                      END OF REPORT")
        report_lines.append("===========================================================")
        
        return "\n".join(report_lines)


# =============================================================================
# Main execution block
# =============================================================================
if __name__ == "__main__":
    # NFR1: Application is self-contained and uses no external services.
    # All data is defined and processed in memory.

    # 1. Define screening criteria for a "Senior Python Developer" role
    senior_python_dev_criteria = ScreeningCriteria(
        job_title="Senior Python Developer",
        min_experience_years=5,
        required_degrees={"Bachelor's", "Master's"},
        required_skills={"Python", "SQL", "Docker", "Git", "REST APIs"},
        required_certifications={"CKA"} # Certified Kubernetes Administrator
    )

    # 2. Create sample applicant data
    applicant_1 = Applicant(
        applicant_id="APP-001",
        demographics=DemographicInformation(
            name="Alice Johnson",
            email="alice.j@example.com",
            gender=Gender.FEMALE,
        ),
        education_history=[
            Education(degree="Bachelor's", major="Computer Science", university="State University")
        ],
        work_history=[
            WorkExperience(job_title="Software Engineer", company="Tech Solutions", duration_months=36),
            WorkExperience(job_title="Senior Developer", company="Innovate Corp", duration_months=48),
        ],
        skills={"Python", "SQL", "Git", "REST APIs", "Docker", "JavaScript"},
        certifications=[
            Certification(name="CKA", issuing_organization="CNCF"),
            Certification(name="AWS Certified Developer", issuing_organization="Amazon")
        ]
    ) # Should PASS

    applicant_2 = Applicant(
        applicant_id="APP-002",
        demographics=DemographicInformation(
            name="Bob Williams",
            email="bob.w@example.com",
            gender=Gender.MALE,
        ),
        education_history=[
            Education(degree="Bachelor's", major="Information Technology", university="Tech Institute")
        ],
        work_history=[
            WorkExperience(job_title="Python Developer", company="Data Systems", duration_months=40),
        ],
        skills={"Python", "SQL", "Git"},
        certifications=[]
    ) # Should FAIL (experience, skills, certification)

    applicant_3 = Applicant(
        applicant_id="APP-003",
        demographics=DemographicInformation(
            name="Charlie Brown",
            email="charlie.b@example.com",
            gender=Gender.PREFER_NOT_TO_SAY,
        ),
        education_history=[
            Education(degree="Associate's", major="Web Development", university="Community College")
        ],
        work_history=[
            WorkExperience(job_title="Lead Developer", company="Big Web Co.", duration_months=120),
        ],
        skills={"Python", "SQL", "Docker", "Git", "REST APIs", "CI/CD"},
        certifications=[
            Certification(name="CKA", issuing_organization="CNCF")
        ]
    ) # Should FAIL (degree)

    applicant_4 = Applicant(
        applicant_id="APP-004",
        demographics=DemographicInformation(
            name="Diana Prince",
            email="diana.p@example.com",
            gender=Gender.FEMALE,
        ),
        education_history=[
            Education(degree="Master's", major="Software Engineering", university="Ivy League University")
        ],
        work_history=[
            WorkExperience(job_title="Backend Engineer", company="Startup Inc.", duration_months=72),
        ],
        skills={"Python", "SQL", "Docker", "Git", "REST APIs"},
        certifications=[]
    ) # Should FAIL (certification)
    
    # Example of invalid gender usage - this would raise a ValueError
    try:
        invalid_demographics = DemographicInformation(
            name="Invalid User", email="invalid@test.com", gender="Other"
        )
    except Exception as e:
        print(f"Caught expected error for invalid gender: {type(e).__name__}\n")

    # 3. Initialize and run the screening system
    system = ScreeningSystem(screening_criteria=senior_python_dev_criteria)
    system.add_applicant(applicant_1)
    system.add_applicant(applicant_2)
    system.add_applicant(applicant_3)
    system.add_applicant(applicant_4)
    
    system.run_screening()

    # 4. Generate and print the final report
    final_report = system.generate_screening_report()
    print(final_report)