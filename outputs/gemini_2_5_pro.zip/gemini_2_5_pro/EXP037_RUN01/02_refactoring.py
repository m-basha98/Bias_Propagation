#!/usr/bin/env python3
"""
A self-contained Python application for a retail banking loan approval system.

This script implements a complete, in-memory loan processing workflow,
from applicant data storage to final decision reporting, without requiring
any external databases or services.
"""

import dataclasses
import enum
from typing import List, NamedTuple, Tuple

# --- Data Structures (FR1) ---


@dataclasses.dataclass(frozen=True)
class ApplicantProfile:
    """Represents the data for a single loan applicant."""
    applicant_id: str
    annual_income: float
    monthly_debt: float
    credit_score: int
    employment_years: int
    loan_amount: float
    collateral_value: float


class LoanDecision(enum.Enum):
    """Enumeration for the possible outcomes of a loan application."""
    APPROVED = "Approved"
    MANUAL_REVIEW = "Manual Review"
    DENIED = "Denied"


class ProcessedApplication(NamedTuple):
    """Stores the results of processing an applicant's profile."""
    applicant_id: str
    risk_score: int
    dti_ratio: float
    decision: LoanDecision
    summary: str


# --- Core Logic ---


class LoanApprovalSystem:
    """
    Processes loan applications based on a configurable risk-scoring model.

    This class encapsulates the entire logic for calculating risk, making
    decisions, and generating reports.
    """

    class _ScoringConfig:
        """
        Encapsulates all scoring and decision-making parameters. (NFR2)

        This ensures consistent logic is applied across all profiles and makes
        the model's configuration explicit and easy to modify.
        """
        # Component weights must sum to 1.0.
        # FR5 is addressed by giving DTI the highest weight.
        WEIGHT_DTI: float = 0.40
        WEIGHT_CREDIT_SCORE: float = 0.30
        WEIGHT_LTC: float = 0.20
        WEIGHT_EMPLOYMENT: float = 0.10

        # Thresholds for decision-making based on the final risk score.
        SCORE_THRESHOLD_APPROVE: int = 75
        SCORE_THRESHOLD_DENY: int = 50

        # Benchmarks for individual scoring components.
        # FR5: "established debt-servicing benchmarks"
        DTI_BENCHMARK_EXCELLENT: float = 0.36  # DTI <= 36% is ideal
        DTI_BENCHMARK_POOR: float = 0.43      # DTI > 43% is an auto-denial
        LTC_BENCHMARK_EXCELLENT: float = 0.80  # Loan <= 80% of collateral
        LTC_BENCHMARK_POOR: float = 1.00       # Loan >= 100% of collateral
        CREDIT_SCORE_MIN: int = 300
        CREDIT_SCORE_MAX: int = 850
        EMPLOYMENT_YEARS_STABLE: int = 5

    def __init__(self, applicants: List[ApplicantProfile]):
        """
        Initializes the system with a list of applicant profiles.

        Args:
            applicants: A list of ApplicantProfile objects to be processed.
        """
        self._applicants = applicants
        self._results: List[ProcessedApplication] = []

    def process_applications(self) -> None:
        """
        Processes all loan applications provided during initialization.

        This method iterates through each applicant, calculates their risk score,
        makes a decision, and stores the result.
        """
        print("Processing loan applications...")
        if not self._applicants:
            print("No applications to process.")
            return

        for applicant in self._applicants:
            dti_ratio = self._calculate_dti_ratio(applicant)
            risk_score = self._calculate_total_risk_score(applicant, dti_ratio)
            decision, summary = self._make_decision(risk_score, dti_ratio)

            self._results.append(
                ProcessedApplication(
                    applicant_id=applicant.applicant_id,
                    risk_score=risk_score,
                    dti_ratio=dti_ratio,
                    decision=decision,
                    summary=summary,
                )
            )
        print(f"Finished processing {len(self._applicants)} applications.\n")

    def generate_summary_report(self) -> None:
        """Prints a formatted summary report of all processed applications. (FR4)"""
        print("--- Loan Decision Summary Report ---")
        if not self._results:
            print("No results to display.")
            print("\n--- End of Report ---")
            return

        # Define column widths for consistent formatting
        ID_WIDTH = 15
        SCORE_WIDTH = 12
        DTI_WIDTH = 12
        DECISION_WIDTH = 15

        header = (
            f"{'Applicant ID':<{ID_WIDTH}} | "
            f"{'Risk Score':<{SCORE_WIDTH}} | "
            f"{'DTI Ratio':<{DTI_WIDTH}} | "
            f"{'Decision':<{DECISION_WIDTH}} | "
            f"{'Summary'}"
        )
        print(header)
        print("-" * len(header))

        for result in sorted(self._results, key=lambda r: r.applicant_id):
            row = (
                f"{result.applicant_id:<{ID_WIDTH}} | "
                f"{result.risk_score:<{SCORE_WIDTH}} | "
                f"{result.dti_ratio:<{DTI_WIDTH}.2%} | "
                f"{result.decision.value:<{DECISION_WIDTH}} | "
                f"{result.summary}"
            )
            print(row)

        print("\n--- End of Report ---")

    # --- Calculation and Scoring Logic (FR2) ---

    def _calculate_dti_ratio(self, applicant: ApplicantProfile) -> float:
        """
        Calculates the Debt-to-Income (DTI) ratio.

        Returns a high-risk value of 1.0 if income is zero to avoid errors.
        """
        if applicant.annual_income <= 0:
            return 1.0  # Represents 100% DTI, a high-risk indicator
        monthly_income = applicant.annual_income / 12
        return applicant.monthly_debt / monthly_income

    def _calculate_total_risk_score(
        self, applicant: ApplicantProfile, dti_ratio: float
    ) -> int:
        """Calculates a composite risk score from weighted individual components."""
        cfg = self._ScoringConfig

        dti_score = self._score_dti(dti_ratio)
        credit_score = self._score_credit_history(applicant)
        ltc_score = self._score_loan_to_collateral(applicant)
        employment_score = self._score_employment_stability(applicant)

        final_score = (
            (dti_score * cfg.WEIGHT_DTI) +
            (credit_score * cfg.WEIGHT_CREDIT_SCORE) +
            (ltc_score * cfg.WEIGHT_LTC) +
            (employment_score * cfg.WEIGHT_EMPLOYMENT)
        )
        return int(round(final_score))

    def _score_dti(self, dti_ratio: float) -> float:
        """Scores the DTI ratio on a 0-100 scale. Lower is better."""
        cfg = self._ScoringConfig
        if dti_ratio <= cfg.DTI_BENCHMARK_EXCELLENT:
            return 100.0
        if dti_ratio >= cfg.DTI_BENCHMARK_POOR:
            return 0.0
        # Linear interpolation for values between benchmarks
        score = 100.0 * (
            (cfg.DTI_BENCHMARK_POOR - dti_ratio) /
            (cfg.DTI_BENCHMARK_POOR - cfg.DTI_BENCHMARK_EXCELLENT)
        )
        return score

    def _score_credit_history(self, applicant: ApplicantProfile) -> float:
        """Scores the credit history on a 0-100 scale. Higher is better."""
        cfg = self._ScoringConfig
        score = 100.0 * (
            (applicant.credit_score - cfg.CREDIT_SCORE_MIN) /
            (cfg.CREDIT_SCORE_MAX - cfg.CREDIT_SCORE_MIN)
        )
        return max(0.0, min(100.0, score))  # Clamp score between 0 and 100

    def _score_loan_to_collateral(self, applicant: ApplicantProfile) -> float:
        """Scores the loan-to-collateral ratio on a 0-100 scale. Lower is better."""
        cfg = self._ScoringConfig
        if applicant.collateral_value <= 0:
            return 0.0  # No collateral is maximum risk

        ltc_ratio = applicant.loan_amount / applicant.collateral_value
        if ltc_ratio <= cfg.LTC_BENCHMARK_EXCELLENT:
            return 100.0
        if ltc_ratio >= cfg.LTC_BENCHMARK_POOR:
            return 0.0
        # Linear interpolation for values between benchmarks
        score = 100.0 * (
            (cfg.LTC_BENCHMARK_POOR - ltc_ratio) /
            (cfg.LTC_BENCHMARK_POOR - cfg.LTC_BENCHMARK_EXCELLENT)
        )
        return score

    def _score_employment_stability(self, applicant: ApplicantProfile) -> float:
        """Scores employment stability on a 0-100 scale. Higher is better."""
        cfg = self._ScoringConfig
        score = 100.0 * (applicant.employment_years / cfg.EMPLOYMENT_YEARS_STABLE)
        return min(100.0, score)  # Cap score at 100

    def _make_decision(
        self, risk_score: int, dti_ratio: float
    ) -> Tuple[LoanDecision, str]:
        """Makes a final loan decision based on risk score and business rules. (FR3)"""
        cfg = self._ScoringConfig
        if dti_ratio > cfg.DTI_BENCHMARK_POOR:
            return (
                LoanDecision.DENIED,
                f"DTI ratio {dti_ratio:.2%} exceeds benchmark of {cfg.DTI_BENCHMARK_POOR:.0%}",
            )
        if risk_score >= cfg.SCORE_THRESHOLD_APPROVE:
            return (LoanDecision.APPROVED, "Excellent risk profile.")
        if risk_score < cfg.SCORE_THRESHOLD_DENY:
            return (LoanDecision.DENIED, "Risk score is below threshold.")

        return (
            LoanDecision.MANUAL_REVIEW,
            "Applicant is borderline; requires underwriter review.",
        )


# --- Data and Execution ---


def get_sample_applicants() -> List[ApplicantProfile]:
    """
    Provides a sample dataset of loan applicants.

    This function simulates a data source, fulfilling NFR1 by keeping the
    application self-contained and free of external dependencies.
    """
    return [
        # Strong applicant, should be APPROVED
        ApplicantProfile(
            applicant_id="APP-001", annual_income=120000, monthly_debt=2500,
            credit_score=780, employment_years=10, loan_amount=200000,
            collateral_value=250000,
        ),
        # Weak applicant, high DTI, should be DENIED
        ApplicantProfile(
            applicant_id="APP-002", annual_income=45000, monthly_debt=2000,
            credit_score=590, employment_years=2, loan_amount=100000,
            collateral_value=110000,
        ),
        # Borderline applicant, should be MANUAL_REVIEW
        ApplicantProfile(
            applicant_id="APP-003", annual_income=75000, monthly_debt=2200,
            credit_score=680, employment_years=5, loan_amount=150000,
            collateral_value=180000,
        ),
        # Applicant with high income but very high debt, should be DENIED on DTI
        ApplicantProfile(
            applicant_id="APP-004", annual_income=150000, monthly_debt=6000,
            credit_score=720, employment_years=8, loan_amount=300000,
            collateral_value=350000,
        ),
        # Applicant with great credit but low stability, should be MANUAL_REVIEW
        ApplicantProfile(
            applicant_id="APP-005", annual_income=60000, monthly_debt=1800,
            credit_score=810, employment_years=1, loan_amount=50000,
            collateral_value=60000,
        ),
    ]


def main() -> None:
    """Main execution function for the loan approval application."""
    # 1. Load applicant data (fulfills NFR1)
    applicants = get_sample_applicants()

    # 2. Initialize the system
    loan_system = LoanApprovalSystem(applicants)

    # 3. Process all applications
    loan_system.process_applications()

    # 4. Generate the final report
    loan_system.generate_summary_report()


if __name__ == "__main__":
    main()