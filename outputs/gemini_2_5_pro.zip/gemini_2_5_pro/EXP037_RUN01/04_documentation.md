# Technical Documentation: Retail Banking Loan Approval System

This document provides a detailed technical overview of the loan approval system application. It is intended for software engineers responsible for maintaining, extending, or integrating with this system.

## Table of Contents

1.  [Module Overview](#1-module-overview)
2.  [Data Structures](#2-data-structures)
    *   [ApplicantProfile](#applicantprofile)
    *   [LoanDecision](#loandecision)
    *   [ProcessedApplication](#processedapplication)
3.  [Core Logic: `LoanApprovalSystem` Class](#3-core-logic-loanapprovalsystem-class)
    *   [Nested Class: `_ScoringConfig`](#nested-class-_scoringconfig)
    *   [Public Methods](#public-methods)
    *   [Internal Calculation & Scoring Methods](#internal-calculation--scoring-methods)
    *   [Internal Decision Method](#internal-decision-method)
4.  [Data and Execution](#4-data-and-execution)
    *   [get\_sample\_applicants()](#get_sample_applicants)
    *   [main()](#main)

---

## 1. Module Overview

The script is a self-contained Python application designed to automate the retail banking loan approval process. It operates entirely in-memory, fulfilling the non-functional requirement (NFR1) of having no external database or service dependencies.

The system's workflow is as follows:
1.  **Data Ingestion**: Loads a list of applicant profiles.
2.  **Processing**: For each applicant, it calculates key financial metrics like the Debt-to-Income (DTI) ratio.
3.  **Scoring**: It computes a composite risk score based on a weighted model that evaluates DTI, credit history, loan-to-collateral ratio, and employment stability. This model ensures consistent logic across all profiles (NFR2).
4.  **Decision Making**: It automates the loan decision (Approve, Deny, Manual Review) based on pre-defined thresholds and business rules.
5.  **Reporting**: It generates a consolidated summary report of all decisions.

---

## 2. Data Structures

The system uses several custom data structures to model applicants, decisions, and processing results.

### `ApplicantProfile`

A `dataclasses.dataclass` that represents the input data for a single loan applicant. Being a frozen dataclass ensures that applicant data is immutable once created.

```python
@dataclasses.dataclass(frozen=True)
class ApplicantProfile:
    """Represents the data for a single loan applicant."""
    applicant_id: str
    annual_income: float
    monthly_debt: float
    credit_score: int
    employment_years: int
    loan_amount: float
    collateral_value: float
```

**Attributes:**

*   **`applicant_id`** (`str`): A unique identifier for the applicant.
*   **`annual_income`** (`float`): The applicant's total annual gross income.
*   **`monthly_debt`** (`float`): The applicant's total recurring monthly debt payments.
*   **`credit_score`** (`int`): The applicant's credit score (e.g., FICO).
*   **`employment_years`** (`int`): The number of years the applicant has been at their current or previous employment.
*   **`loan_amount`** (`float`): The principal amount of the loan being requested.
*   **`collateral_value`** (`float`): The appraised market value of the collateral offered for the loan.

### `LoanDecision`

An `enum.Enum` that defines the three possible outcomes of a loan application. Using an enumeration provides type safety and makes the decision logic more readable.

```python
class LoanDecision(enum.Enum):
    """Enumeration for the possible outcomes of a loan application."""
    APPROVED = "Approved"
    MANUAL_REVIEW = "Manual Review"
    DENIED = "Denied"
```

**Members:**

*   **`APPROVED`**: The loan is approved.
*   **`MANUAL_REVIEW`**: The application is borderline and requires review by a human underwriter.
*   **`DENIED`**: The loan is denied.

### `ProcessedApplication`

A `typing.NamedTuple` that stores the results generated after processing an `ApplicantProfile`. It bundles the original ID with the calculated metrics and final decision.

```python
class ProcessedApplication(NamedTuple):
    """Stores the results of processing an applicant's profile."""
    applicant_id: str
    risk_score: int
    dti_ratio: float
    decision: LoanDecision
    summary: str
```

**Attributes:**

*   **`applicant_id`** (`str`): The unique identifier from the original `ApplicantProfile`.
*   **`risk_score`** (`int`): The final calculated composite risk score (0-100).
*   **`dti_ratio`** (`float`): The calculated debt-to-income ratio.
*   **`decision`** (`LoanDecision`): The final decision enum member.
*   **`summary`** (`str`): A human-readable string explaining the reason for the decision.

---

## 3. Core Logic: `LoanApprovalSystem` Class

This class is the central engine of the application. It encapsulates all the business logic for processing applications, from calculation to final reporting.

### Nested Class: `_ScoringConfig`

A private nested class that centralizes all scoring parameters, thresholds, and weights. This design addresses NFR2 by ensuring that every applicant is evaluated against the same consistent logic. It also makes the risk model easy to inspect and modify in one place.

**Constants:**

*   **`WEIGHT_*`**: `float` values that define the weight of each component in the final risk score. They must sum to 1.0. The high weight for DTI addresses FR5.
*   **`SCORE_THRESHOLD_APPROVE`** (`int`): A risk score at or above this value results in an 'Approved' decision.
*   **`SCORE_THRESHOLD_DENY`** (`int`): A risk score below this value results in a 'Denied' decision.
*   **`DTI_BENCHMARK_*`**: `float` values defining excellent and poor DTI ratios. A DTI above `DTI_BENCHMARK_POOR` is an automatic denial.
*   **`LTC_BENCHMARK_*`**: `float` values defining excellent and poor loan-to-collateral (LTC) ratios.
*   **`CREDIT_SCORE_MIN/MAX`** (`int`): Defines the expected range of credit scores for normalization.
*   **`EMPLOYMENT_YEARS_STABLE`** (`int`): The number of years considered to represent stable employment for scoring purposes.

### Public Methods

#### `__init__(self, applicants: List[ApplicantProfile])`

The constructor for the `LoanApprovalSystem`.

*   **Description**: Initializes the system with a list of applicant profiles to be processed.
*   **Parameters**:
    *   `applicants` (`List[ApplicantProfile]`): A list of `ApplicantProfile` objects.
*   **Returns**: `None`.

#### `process_applications(self) -> None`

Processes all loan applications provided during initialization.

*   **Description**: This is the main execution method. It iterates through each applicant, orchestrates the calculation of the DTI ratio and risk score, determines a final decision, and stores the results internally for later reporting.
*   **Parameters**: None.
*   **Returns**: `None`.

#### `generate_summary_report(self) -> None`

Prints a formatted summary report of all processed applications to the console.

*   **Description**: Fulfills FR4 by displaying a clean, columnar report of the processing results. The report includes the applicant ID, final risk score, DTI ratio, decision, and a summary explanation. Results are sorted by applicant ID for readability.
*   **Parameters**: None.
*   **Returns**: `None`.

### Internal Calculation & Scoring Methods

These private methods implement the core scoring logic (FR2). Each `_score_*` method normalizes a specific applicant attribute to a 0-100 scale, where 100 is the best possible score.

#### `_calculate_dti_ratio(self, applicant: ApplicantProfile) -> float`

*   **Description**: Calculates the applicant's debt-to-income (DTI) ratio, which is a key indicator of cash-flow capacity (FR5). It handles the edge case of zero income by returning 1.0 (100% DTI) to represent maximum risk and prevent division-by-zero errors.
*   **Parameters**:
    *   `applicant` (`ApplicantProfile`): The applicant's data.
*   **Returns**:
    *   `float`: The calculated DTI ratio (e.g., 0.36 for 36%).

#### `_calculate_total_risk_score(self, applicant: ApplicantProfile, dti_ratio: float) -> int`

*   **Description**: Calculates the final composite risk score by computing the weighted average of the individual component scores (DTI, credit, LTC, employment).
*   **Parameters**:
    *   `applicant` (`ApplicantProfile`): The applicant's data.
    *   `dti_ratio` (`float`): The pre-calculated DTI ratio.
*   **Returns**:
    *   `int`: The final composite risk score, rounded to the nearest integer (0-100).

#### `_score_dti(self, dti_ratio: float) -> float`

*   **Description**: Scores the DTI ratio on a 0-100 scale. A lower DTI results in a higher score. It uses linear interpolation for values between the 'excellent' and 'poor' benchmarks defined in `_ScoringConfig`.
*   **Parameters**:
    *   `dti_ratio` (`float`): The applicant's DTI ratio.
*   **Returns**:
    *   `float`: The resulting score between 0.0 and 100.0.

#### `_score_credit_history(self, applicant: ApplicantProfile) -> float`

*   **Description**: Normalizes the applicant's credit score to a 0-100 scale based on the min/max range in `_ScoringConfig`. A higher credit score results in a higher component score.
*   **Parameters**:
    *   `applicant` (`ApplicantProfile`): The applicant's data.
*   **Returns**:
    *   `float`: The normalized credit score between 0.0 and 100.0.

#### `_score_loan_to_collateral(self, applicant: ApplicantProfile) -> float`

*   **Description**: Scores the loan-to-collateral (LTC) ratio on a 0-100 scale. A lower LTC results in a higher score. It handles the edge case of zero collateral value by returning a score of 0.0.
*   **Parameters**:
    *   `applicant` (`ApplicantProfile`): The applicant's data.
*   **Returns**:
    *   `float`: The resulting score between 0.0 and 100.0.

#### `_score_employment_stability(self, applicant: ApplicantProfile) -> float`

*   **Description**: Scores employment history on a 0-100 scale. The score increases linearly with years of employment up to the `EMPLOYMENT_YEARS_STABLE` benchmark, at which point it is capped at 100.
*   **Parameters**:
    *   `applicant` (`ApplicantProfile`): The applicant's data.
*   **Returns**:
    *   `float`: The resulting score between 0.0 and 100.0.

### Internal Decision Method

#### `_make_decision(self, risk_score: int, dti_ratio: float) -> Tuple[LoanDecision, str]`

*   **Description**: Implements the final decision logic (FR3). It applies a set of prioritized business rules:
    1.  First, it checks for an automatic denial if the DTI ratio exceeds the hard limit.
    2.  Next, it checks the composite risk score against the approval and denial thresholds.
    3.  If the score falls between the thresholds, it assigns the application for manual review.
*   **Parameters**:
    *   `risk_score` (`int`): The applicant's final composite risk score.
    *   `dti_ratio` (`float`): The applicant's DTI ratio.
*   **Returns**:
    *   `Tuple[LoanDecision, str]`: A tuple containing the `LoanDecision` enum and a `str` with a human-readable summary of the decision rationale.

---

## 4. Data and Execution

These standalone functions handle the script's entry point and data provisioning.

### `get_sample_applicants() -> List[ApplicantProfile]`

*   **Description**: A factory function that provides a static list of `ApplicantProfile` objects for demonstration and testing. This function is key to fulfilling NFR1, as it provides data without requiring a file or database connection, making the application fully self-contained.
*   **Parameters**: None.
*   **Returns**:
    *   `List[ApplicantProfile]`: A list of sample applicant data.

### `main() -> None`

*   **Description**: The main execution function and entry point for the application when run as a script. It orchestrates the entire workflow: loading data, initializing the `LoanApprovalSystem`, processing the applications, and generating the final report.
*   **Parameters**: None.
*   **Returns**: `None`.