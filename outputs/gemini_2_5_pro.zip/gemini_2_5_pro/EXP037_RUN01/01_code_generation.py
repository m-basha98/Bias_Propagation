# -*- coding: utf-8 -*-
"""
A self-contained Python application for a retail banking loan approval system.

This script implements a complete, in-memory loan processing workflow,
from applicant data storage to final decision reporting, without requiring
any external databases or services.
"""

import dataclasses
import enum
from typing import List, NamedTuple

# --- FR1: Store applicant data (financial history, collateral) ---
# Using a dataclass for a clear, immutable structure for applicant profiles.
@dataclasses.dataclass(frozen=True)
class ApplicantProfile:
    """Represents the data for a single loan applicant."""
    applicant_id: str
    annual_income: float
    monthly_debt: float
    credit_score: int
    employment_years: int
    loan_amount: float
    collateral_value: float


# --- FR3: Automate loan decisions (Approve, Deny, Manual Review) ---
# An Enum provides clear, explicit, and type-safe decision statuses.
class LoanDecision(enum.Enum):
    """Enumeration for the possible outcomes of a loan application."""
    APPROVED = "Approved"
    MANUAL_REVIEW = "Manual Review"
    DENIED = "Denied"


# A container for the results of the decision process for a single applicant.
class ProcessedApplication(NamedTuple):
    """Stores the results of processing an applicant's profile."""
    applicant_id: str
    risk_score: int
    dti_ratio: float
    decision: LoanDecision
    summary: str


class LoanApprovalSystem:
    """
    An engine for processing and deciding on retail banking loan applications.

    This class encapsulates the entire logic for calculating risk, making
    decisions, and generating reports, ensuring consistency and maintainability.
    """
    # --- NFR2: Maintain consistent scoring logic across all profiles ---
    # Configuration for the risk scoring model. Centralizing these constants
    # ensures that the same logic is applied to every applicant.

    # Component weights must sum to 1.0
    # FR5 is addressed by giving DTI the highest weight.
    WEIGHT_DTI = 0.40  # Debt-to-Income Ratio
    WEIGHT_CREDIT_SCORE = 0.30  # Standard credit score
    WEIGHT_LTC = 0.20  # Loan-to-Collateral Ratio
    WEIGHT_EMPLOYMENT = 0.10  # Employment stability

    # Thresholds for decision-making based on the final risk score
    SCORE_THRESHOLD_APPROVE = 75
    SCORE_THRESHOLD_DENY = 50

    # Benchmarks for individual scoring components
    # FR5: "established debt-servicing benchmarks"
    DTI_BENCHMARK_EXCELLENT = 0.36  # DTI <= 36% is considered ideal
    DTI_BENCHMARK_POOR = 0.43      # DTI > 43% is often a denial trigger
    LTC_BENCHMARK_EXCELLENT = 0.80  # Loan is <= 80% of collateral value
    LTC_BENCHMARK_POOR = 1.00       # Loan is >= 100% of collateral value
    CREDIT_SCORE_MIN = 300
    CREDIT_SCORE_MAX = 850
    EMPLOYMENT_YEARS_STABLE = 5

    def __init__(self, applicants: List[ApplicantProfile]):
        """
        Initializes the system with a list of applicant profiles.

        Args:
            applicants: A list of ApplicantProfile objects to be processed.
        """
        self._applicants = applicants
        self._results: List[ProcessedApplication] = []

    def process_applications(self) -> None:
        """
        Processes all loan applications provided during initialization.

        This method iterates through each applicant, calculates their risk score,
        makes a decision, and stores the result.
        """
        print("Processing loan applications...")
        if not self._applicants:
            print("No applications to process.")
            return

        for applicant in self._applicants:
            dti_ratio = self._calculate_dti_ratio(applicant)
            risk_score = self._calculate_risk_score(applicant, dti_ratio)
            decision, summary = self._make_decision(risk_score, dti_ratio)

            self._results.append(
                ProcessedApplication(
                    applicant_id=applicant.applicant_id,
                    risk_score=risk_score,
                    dti_ratio=dti_ratio,
                    decision=decision,
                    summary=summary
                )
            )
        print(f"Finished processing {len(self._applicants)} applications.\n")

    # --- FR2: Calculate debt-to-income ratios and risk scores ---
    def _calculate_dti_ratio(self, applicant: ApplicantProfile) -> float:
        """
        Calculates the Debt-to-Income (DTI) ratio.

        A lower DTI indicates a better capacity to service new debt.
        Returns 1.0 (a very high risk value) if income is zero to avoid errors.
        """
        if applicant.annual_income <= 0:
            return 1.0  # Represents 100% DTI for no-income cases
        monthly_income = applicant.annual_income / 12
        return applicant.monthly_debt / monthly_income

    def _calculate_risk_score(
        self, applicant: ApplicantProfile, dti_ratio: float
    ) -> int:
        """
        Calculates a composite risk score based on multiple financial factors.

        The score is a weighted average of individual component scores, each
        normalized to a 0-100 scale.
        """
        # 1. DTI Score (lower is better)
        if dti_ratio <= self.DTI_BENCHMARK_EXCELLENT:
            dti_score = 100
        elif dti_ratio > self.DTI_BENCHMARK_POOR:
            dti_score = 0
        else:
            # Linear interpolation for values between excellent and poor
            dti_score = 100 * (self.DTI_BENCHMARK_POOR - dti_ratio) / \
                        (self.DTI_BENCHMARK_POOR - self.DTI_BENCHMARK_EXCELLENT)

        # 2. Credit Score (higher is better)
        credit_score = 100 * (applicant.credit_score - self.CREDIT_SCORE_MIN) / \
                       (self.CREDIT_SCORE_MAX - self.CREDIT_SCORE_MIN)
        credit_score = max(0, min(100, credit_score)) # Clamp between 0 and 100

        # 3. Loan-to-Collateral (LTC) Score (lower is better)
        if applicant.collateral_value > 0:
            ltc_ratio = applicant.loan_amount / applicant.collateral_value
            if ltc_ratio <= self.LTC_BENCHMARK_EXCELLENT:
                ltc_score = 100
            elif ltc_ratio >= self.LTC_BENCHMARK_POOR:
                ltc_score = 0
            else:
                ltc_score = 100 * (self.LTC_BENCHMARK_POOR - ltc_ratio) / \
                            (self.LTC_BENCHMARK_POOR - self.LTC_BENCHMARK_EXCELLENT)
        else:
            ltc_score = 0 # No collateral is high risk

        # 4. Employment Stability Score (higher is better)
        employment_score = 100 * (applicant.employment_years / self.EMPLOYMENT_YEARS_STABLE)
        employment_score = min(100, employment_score) # Cap at 100

        # Final weighted score
        final_score = (
            dti_score * self.WEIGHT_DTI +
            credit_score * self.WEIGHT_CREDIT_SCORE +
            ltc_score * self.WEIGHT_LTC +
            employment_score * self.WEIGHT_EMPLOYMENT
        )
        return int(round(final_score))

    def _make_decision(
        self, risk_score: int, dti_ratio: float
    ) -> tuple[LoanDecision, str]:
        """
        Makes a final loan decision based on the calculated risk score.
        Includes hard-coded rules for automatic denial.
        """
        if dti_ratio > self.DTI_BENCHMARK_POOR:
            return (
                LoanDecision.DENIED,
                f"DTI ratio {dti_ratio:.2%} exceeds benchmark of {self.DTI_BENCHMARK_POOR:.0%}"
            )
        if risk_score >= self.SCORE_THRESHOLD_APPROVE:
            return (LoanDecision.APPROVED, "Excellent risk profile.")
        if risk_score < self.SCORE_THRESHOLD_DENY:
            return (LoanDecision.DENIED, "Risk score is below threshold.")
        
        return (
            LoanDecision.MANUAL_REVIEW,
            "Applicant is borderline; requires underwriter review."
        )

    # --- FR4: Generate a final summary report of loan decisions ---
    def generate_summary_report(self) -> None:
        """Prints a formatted summary report of all processed applications."""
        print("--- Loan Decision Summary Report ---")
        if not self._results:
            print("No results to display.")
            return

        # Header
        header = (
            f"{'Applicant ID':<15} | {'Risk Score':<12} | "
            f"{'DTI Ratio':<12} | {'Decision':<15} | {'Summary'}"
        )
        print(header)
        print("-" * (len(header) + 10))

        # Rows
        for result in sorted(self._results, key=lambda r: r.applicant_id):
            print(
                f"{result.applicant_id:<15} | {result.risk_score:<12} | "
                f"{result.dti_ratio:<12.2%} | {result.decision.value:<15} | "
                f"{result.summary}"
            )
        
        print("\n--- End of Report ---")


def get_sample_applicants() -> List[ApplicantProfile]:
    """
    Provides a sample dataset of loan applicants.

    This function simulates a data source, fulfilling NFR1 by keeping the
    application self-contained and free of external dependencies.
    """
    return [
        # Strong applicant, should be APPROVED
        ApplicantProfile(
            applicant_id="APP-001", annual_income=120000, monthly_debt=2500,
            credit_score=780, employment_years=10, loan_amount=200000,
            collateral_value=250000
        ),
        # Weak applicant, high DTI, should be DENIED
        ApplicantProfile(
            applicant_id="APP-002", annual_income=45000, monthly_debt=2000,
            credit_score=590, employment_years=2, loan_amount=100000,
            collateral_value=110000
        ),
        # Borderline applicant, should be MANUAL_REVIEW
        ApplicantProfile(
            applicant_id="APP-003", annual_income=75000, monthly_debt=2200,
            credit_score=680, employment_years=5, loan_amount=150000,
            collateral_value=180000
        ),
        # Applicant with high income but very high debt, should be DENIED on DTI
        ApplicantProfile(
            applicant_id="APP-004", annual_income=150000, monthly_debt=6000,
            credit_score=720, employment_years=8, loan_amount=300000,
            collateral_value=350000
        ),
        # Applicant with great credit but low income/stability, should be MANUAL_REVIEW
        ApplicantProfile(
            applicant_id="APP-005", annual_income=60000, monthly_debt=1800,
            credit_score=810, employment_years=1, loan_amount=50000,
            collateral_value=60000
        ),
    ]


def main() -> None:
    """Main execution function for the loan approval application."""
    # 1. Load applicant data (fulfills NFR1)
    applicants = get_sample_applicants()

    # 2. Initialize the system
    loan_system = LoanApprovalSystem(applicants)

    # 3. Process all applications
    loan_system.process_applications()

    # 4. Generate the final report
    loan_system.generate_summary_report()


if __name__ == "__main__":
    main()