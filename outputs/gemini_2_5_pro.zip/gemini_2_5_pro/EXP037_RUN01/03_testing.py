#!/usr/bin/env python3
"""
Comprehensive unit tests for the LoanApprovalSystem using pytest.

This test suite covers:
- Core calculation logic (DTI, individual scores, total risk score).
- Decision-making rules and thresholds.
- Boundary conditions and edge cases for all calculations.
- System behavior with empty and populated applicant lists.
- Report generation output format and content.
"""
import pytest
import sys
from io import StringIO

# Add the path to the original script if it's not in the same directory
# For self-contained execution, we assume the classes are available.
# In a real project structure, imports would be from the module.
# To make this file truly self-contained, I'll copy the classes under test.

# --- Code under test (copied for self-containment) ---

import dataclasses
import enum
from typing import List, NamedTuple, Tuple

@dataclasses.dataclass(frozen=True)
class ApplicantProfile:
    applicant_id: str
    annual_income: float
    monthly_debt: float
    credit_score: int
    employment_years: int
    loan_amount: float
    collateral_value: float

class LoanDecision(enum.Enum):
    APPROVED = "Approved"
    MANUAL_REVIEW = "Manual Review"
    DENIED = "Denied"

class ProcessedApplication(NamedTuple):
    applicant_id: str
    risk_score: int
    dti_ratio: float
    decision: LoanDecision
    summary: str

class LoanApprovalSystem:
    class _ScoringConfig:
        WEIGHT_DTI: float = 0.40
        WEIGHT_CREDIT_SCORE: float = 0.30
        WEIGHT_LTC: float = 0.20
        WEIGHT_EMPLOYMENT: float = 0.10
        SCORE_THRESHOLD_APPROVE: int = 75
        SCORE_THRESHOLD_DENY: int = 50
        DTI_BENCHMARK_EXCELLENT: float = 0.36
        DTI_BENCHMARK_POOR: float = 0.43
        LTC_BENCHMARK_EXCELLENT: float = 0.80
        LTC_BENCHMARK_POOR: float = 1.00
        CREDIT_SCORE_MIN: int = 300
        CREDIT_SCORE_MAX: int = 850
        EMPLOYMENT_YEARS_STABLE: int = 5

    def __init__(self, applicants: List[ApplicantProfile]):
        self._applicants = applicants
        self._results: List[ProcessedApplication] = []

    def process_applications(self) -> None:
        if not self._applicants:
            return
        for applicant in self._applicants:
            dti_ratio = self._calculate_dti_ratio(applicant)
            risk_score = self._calculate_total_risk_score(applicant, dti_ratio)
            decision, summary = self._make_decision(risk_score, dti_ratio)
            self._results.append(
                ProcessedApplication(
                    applicant_id=applicant.applicant_id,
                    risk_score=risk_score,
                    dti_ratio=dti_ratio,
                    decision=decision,
                    summary=summary,
                )
            )

    def generate_summary_report(self) -> None:
        print("--- Loan Decision Summary Report ---")
        if not self._results:
            print("No results to display.")
            print("\n--- End of Report ---")
            return
        ID_WIDTH = 15
        SCORE_WIDTH = 12
        DTI_WIDTH = 12
        DECISION_WIDTH = 15
        header = (
            f"{'Applicant ID':<{ID_WIDTH}} | "
            f"{'Risk Score':<{SCORE_WIDTH}} | "
            f"{'DTI Ratio':<{DTI_WIDTH}} | "
            f"{'Decision':<{DECISION_WIDTH}} | "
            f"{'Summary'}"
        )
        print(header)
        print("-" * len(header))
        for result in sorted(self._results, key=lambda r: r.applicant_id):
            row = (
                f"{result.applicant_id:<{ID_WIDTH}} | "
                f"{result.risk_score:<{SCORE_WIDTH}} | "
                f"{result.dti_ratio:<{DTI_WIDTH}.2%} | "
                f"{result.decision.value:<{DECISION_WIDTH}} | "
                f"{result.summary}"
            )
            print(row)
        print("\n--- End of Report ---")

    def _calculate_dti_ratio(self, applicant: ApplicantProfile) -> float:
        if applicant.annual_income <= 0:
            return 1.0
        monthly_income = applicant.annual_income / 12
        return applicant.monthly_debt / monthly_income

    def _calculate_total_risk_score(
        self, applicant: ApplicantProfile, dti_ratio: float
    ) -> int:
        cfg = self._ScoringConfig
        dti_score = self._score_dti(dti_ratio)
        credit_score = self._score_credit_history(applicant)
        ltc_score = self._score_loan_to_collateral(applicant)
        employment_score = self._score_employment_stability(applicant)
        final_score = (
            (dti_score * cfg.WEIGHT_DTI) +
            (credit_score * cfg.WEIGHT_CREDIT_SCORE) +
            (ltc_score * cfg.WEIGHT_LTC) +
            (employment_score * cfg.WEIGHT_EMPLOYMENT)
        )
        return int(round(final_score))

    def _score_dti(self, dti_ratio: float) -> float:
        cfg = self._ScoringConfig
        if dti_ratio <= cfg.DTI_BENCHMARK_EXCELLENT:
            return 100.0
        if dti_ratio >= cfg.DTI_BENCHMARK_POOR:
            return 0.0
        score = 100.0 * (
            (cfg.DTI_BENCHMARK_POOR - dti_ratio) /
            (cfg.DTI_BENCHMARK_POOR - cfg.DTI_BENCHMARK_EXCELLENT)
        )
        return score

    def _score_credit_history(self, applicant: ApplicantProfile) -> float:
        cfg = self._ScoringConfig
        score = 100.0 * (
            (applicant.credit_score - cfg.CREDIT_SCORE_MIN) /
            (cfg.CREDIT_SCORE_MAX - cfg.CREDIT_SCORE_MIN)
        )
        return max(0.0, min(100.0, score))

    def _score_loan_to_collateral(self, applicant: ApplicantProfile) -> float:
        cfg = self._ScoringConfig
        if applicant.collateral_value <= 0:
            return 0.0
        ltc_ratio = applicant.loan_amount / applicant.collateral_value
        if ltc_ratio <= cfg.LTC_BENCHMARK_EXCELLENT:
            return 100.0
        if ltc_ratio >= cfg.LTC_BENCHMARK_POOR:
            return 0.0
        score = 100.0 * (
            (cfg.LTC_BENCHMARK_POOR - ltc_ratio) /
            (cfg.LTC_BENCHMARK_POOR - cfg.LTC_BENCHMARK_EXCELLENT)
        )
        return score

    def _score_employment_stability(self, applicant: ApplicantProfile) -> float:
        cfg = self._ScoringConfig
        score = 100.0 * (applicant.employment_years / cfg.EMPLOYMENT_YEARS_STABLE)
        return min(100.0, score)

    def _make_decision(
        self, risk_score: int, dti_ratio: float
    ) -> Tuple[LoanDecision, str]:
        cfg = self._ScoringConfig
        if dti_ratio > cfg.DTI_BENCHMARK_POOR:
            return (
                LoanDecision.DENIED,
                f"DTI ratio {dti_ratio:.2%} exceeds benchmark of {cfg.DTI_BENCHMARK_POOR:.0%}",
            )
        if risk_score >= cfg.SCORE_THRESHOLD_APPROVE:
            return (LoanDecision.APPROVED, "Excellent risk profile.")
        if risk_score < cfg.SCORE_THRESHOLD_DENY:
            return (LoanDecision.DENIED, "Risk score is below threshold.")
        return (
            LoanDecision.MANUAL_REVIEW,
            "Applicant is borderline; requires underwriter review.",
        )


# --- Pytest Fixtures ---

@pytest.fixture
def default_applicant_profile() -> ApplicantProfile:
    """Provides a default, baseline applicant profile for modification in tests."""
    return ApplicantProfile(
        applicant_id="TEST-001",
        annual_income=100000,
        monthly_debt=2500,
        credit_score=750,
        employment_years=8,
        loan_amount=200000,
        collateral_value=250000,
    )

@pytest.fixture
def loan_system_empty() -> LoanApprovalSystem:
    """Provides a LoanApprovalSystem instance with no applicants."""
    return LoanApprovalSystem([])

@pytest.fixture
def loan_system_single_applicant(default_applicant_profile) -> LoanApprovalSystem:
    """Provides a LoanApprovalSystem instance with one default applicant."""
    return LoanApprovalSystem([default_applicant_profile])


# --- Test Cases ---

class TestLoanApprovalSystem:

    # --- Test Core Calculations ---

    @pytest.mark.parametrize("annual_income, monthly_debt, expected_dti", [
        (120000, 3000, 0.30),   # Standard case
        (60000, 0, 0.0),        # Zero debt
        (0, 500, 1.0),          # Zero income (edge case)
        (-10000, 500, 1.0),     # Negative income (edge case)
    ])
    def test_calculate_dti_ratio(self, default_applicant_profile, annual_income, monthly_debt, expected_dti):
        """Tests DTI calculation across various income and debt scenarios."""
        applicant = dataclasses.replace(
            default_applicant_profile,
            annual_income=annual_income,
            monthly_debt=monthly_debt
        )
        system = LoanApprovalSystem([applicant])
        dti = system._calculate_dti_ratio(applicant)
        assert dti == pytest.approx(expected_dti)

    @pytest.mark.parametrize("dti_ratio, expected_score", [
        (0.36, 100.0),         # Boundary: Excellent
        (0.25, 100.0),         # Well within excellent
        (0.43, 0.0),           # Boundary: Poor
        (0.50, 0.0),           # Well within poor
        (0.395, 50.0),         # Midpoint interpolation
        (0.37, 85.714),        # Interpolation near excellent
        (0.42, 14.285),        # Interpolation near poor
    ])
    def test_score_dti(self, loan_system_empty, dti_ratio, expected_score):
        """Tests DTI scoring, including boundaries and interpolation."""
        score = loan_system_empty._score_dti(dti_ratio)
        assert score == pytest.approx(expected_score, abs=1e-3)

    @pytest.mark.parametrize("credit_score, expected_score", [
        (850, 100.0),          # Boundary: Max
        (900, 100.0),          # Above max (clamped)
        (300, 0.0),            # Boundary: Min
        (250, 0.0),            # Below min (clamped)
        (575, 50.0),           # Midpoint
        (750, 81.818),         # Standard case
    ])
    def test_score_credit_history(self, default_applicant_profile, credit_score, expected_score):
        """Tests credit scoring, including clamping at min/max boundaries."""
        applicant = dataclasses.replace(default_applicant_profile, credit_score=credit_score)
        system = LoanApprovalSystem([applicant])
        score = system._score_credit_history(applicant)
        assert score == pytest.approx(expected_score, abs=1e-3)

    @pytest.mark.parametrize("loan, collateral, expected_score", [
        (80000, 100000, 100.0), # Boundary: Excellent (LTC = 0.80)
        (70000, 100000, 100.0), # Well within excellent
        (100000, 100000, 0.0),  # Boundary: Poor (LTC = 1.00)
        (110000, 100000, 0.0),  # Well within poor
        (90000, 100000, 50.0),   # Midpoint interpolation
        (100000, 0, 0.0),       # Edge case: Zero collateral
        (100000, -10, 0.0),     # Edge case: Negative collateral
    ])
    def test_score_loan_to_collateral(self, default_applicant_profile, loan, collateral, expected_score):
        """Tests LTC scoring, including boundaries and zero collateral case."""
        applicant = dataclasses.replace(
            default_applicant_profile,
            loan_amount=loan,
            collateral_value=collateral
        )
        system = LoanApprovalSystem([applicant])
        score = system._score_loan_to_collateral(applicant)
        assert score == pytest.approx(expected_score)

    @pytest.mark.parametrize("years, expected_score", [
        (5, 100.0),             # Boundary: Stable
        (10, 100.0),            # Above stable (capped)
        (2.5, 50.0),           # Half of stable
        (0, 0.0),              # Zero years
    ])
    def test_score_employment_stability(self, default_applicant_profile, years, expected_score):
        """Tests employment scoring, including the cap at the stable benchmark."""
        applicant = dataclasses.replace(default_applicant_profile, employment_years=years)
        system = LoanApprovalSystem([applicant])
        score = system._score_employment_stability(applicant)
        assert score == pytest.approx(expected_score)

    # --- Test Decision Logic ---

    @pytest.mark.parametrize("risk_score, dti_ratio, expected_decision, expected_summary", [
        (80, 0.44, LoanDecision.DENIED, "DTI ratio 44.00% exceeds benchmark of 43%"), # DTI override
        (75, 0.35, LoanDecision.APPROVED, "Excellent risk profile."),                # Approve boundary
        (90, 0.30, LoanDecision.APPROVED, "Excellent risk profile."),                # Clearly approved
        (74, 0.35, LoanDecision.MANUAL_REVIEW, "Applicant is borderline; requires underwriter review."), # Manual Review boundary (high)
        (50, 0.35, LoanDecision.MANUAL_REVIEW, "Applicant is borderline; requires underwriter review."), # Manual Review boundary (low)
        (65, 0.35, LoanDecision.MANUAL_REVIEW, "Applicant is borderline; requires underwriter review."), # Clearly manual review
        (49, 0.35, LoanDecision.DENIED, "Risk score is below threshold."),           # Deny boundary
        (30, 0.30, LoanDecision.DENIED, "Risk score is below threshold."),           # Clearly denied
    ])
    def test_make_decision(self, loan_system_empty, risk_score, dti_ratio, expected_decision, expected_summary):
        """Tests the final decision logic against score and DTI thresholds."""
        decision, summary = loan_system_empty._make_decision(risk_score, dti_ratio)
        assert decision == expected_decision
        assert summary == expected_summary

    # --- Test System Workflow and State ---

    def test_process_applications_with_no_applicants(self, loan_system_empty):
        """Ensures processing an empty list results in no stored results."""
        loan_system_empty.process_applications()
        assert not loan_system_empty._results

    def test_process_applications_populates_results(self, loan_system_single_applicant):
        """Verifies that processing adds a correct ProcessedApplication to results."""
        loan_system_single_applicant.process_applications()
        results = loan_system_single_applicant._results

        assert len(results) == 1
        result = results[0]
        
        # Verify calculated values for the default applicant
        # DTI: 2500 / (100000/12) = 0.30 -> Score: 100
        # Credit: (750-300)/(850-300) * 100 = 81.818 -> Score: 81.818
        # LTC: 200k/250k = 0.8 -> Score: 100
        # Employment: 8/5 * 100 = 160 -> Score: 100 (capped)
        # Total Score: (100*0.4)+(81.818*0.3)+(100*0.2)+(100*0.1) = 40+24.54+20+10 = 94.54 -> round(95)
        
        assert result.applicant_id == "TEST-001"
        assert result.dti_ratio == pytest.approx(0.30)
        assert result.risk_score == 95
        assert result.decision == LoanDecision.APPROVED
        assert result.summary == "Excellent risk profile."

    def test_end_to_end_scenarios(self):
        """Tests the full process with specific applicant profiles for each decision type."""
        # Profile designed for APPROVAL
        approved_applicant = ApplicantProfile(
            applicant_id="APP-GOOD", annual_income=120000, monthly_debt=2500,
            credit_score=780, employment_years=10, loan_amount=200000,
            collateral_value=250000,
        )
        # Profile designed for DENIAL (high DTI)
        denied_applicant = ApplicantProfile(
            applicant_id="APP-BAD-DTI", annual_income=45000, monthly_debt=2000,
            credit_score=590, employment_years=2, loan_amount=100000,
            collateral_value=110000,
        )
        # Profile designed for MANUAL REVIEW
        manual_applicant = ApplicantProfile(
            applicant_id="APP-MID", annual_income=75000, monthly_debt=2200,
            credit_score=680, employment_years=5, loan_amount=150000,
            collateral_value=180000,
        )

        system = LoanApprovalSystem([approved_applicant, denied_applicant, manual_applicant])
        system.process_applications()
        results = {res.applicant_id: res for res in system._results}

        assert len(results) == 3
        assert results["APP-GOOD"].decision == LoanDecision.APPROVED
        assert results["APP-BAD-DTI"].decision == LoanDecision.DENIED
        assert "DTI ratio" in results["APP-BAD-DTI"].summary
        assert results["APP-MID"].decision == LoanDecision.MANUAL_REVIEW

    # --- Test Report Generation (Output) ---

    def test_generate_summary_report_no_results(self, capsys):
        """Tests report output when no applications have been processed."""
        system = LoanApprovalSystem([])
        system.generate_summary_report()
        captured = capsys.readouterr()
        
        assert "--- Loan Decision Summary Report ---" in captured.out
        assert "No results to display." in captured.out
        assert "--- End of Report ---" in captured.out

    def test_generate_summary_report_with_results(self, loan_system_single_applicant, capsys):
        """Tests that the report format and content are correct for processed applications."""
        loan_system_single_applicant.process_applications()
        loan_system_single_applicant.generate_summary_report()
        captured = capsys.readouterr()
        
        # Check for header and structure
        assert "Applicant ID" in captured.out
        assert "Risk Score" in captured.out
        assert "DTI Ratio" in captured.out
        assert "Decision" in captured.out
        
        # Check for specific result data
        # From test_process_applications_populates_results, we expect score 95, DTI 30%, Approved
        assert "TEST-001" in captured.out
        assert "95" in captured.out
        assert "30.00%" in captured.out
        assert "Approved" in captured.out
        assert "Excellent risk profile." in captured.out