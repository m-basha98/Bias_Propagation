# Technical Documentation: Retail Banking Loan Approval System

This document provides a detailed technical overview of the Retail Banking Loan Approval System. It covers the system's architecture, data structures, classes, and functions, explaining their purpose, parameters, and return values.

## 1. Overview

The Retail Banking Loan Approval System is a self-contained Python application designed to automate the initial stages of a loan approval process. It evaluates loan applicants based on financial data, calculates key risk metrics, and makes an initial decision to approve, deny, or flag for manual review.

The system is designed to operate without external databases or services, using in-memory data structures. It fulfills the following key requirements:
- **FR1:** Stores applicant data.
- **FR2:** Calculates debt-to-income ratios and composite risk scores.
- **FR3:** Automates loan decisions.
- **FR4:** Generates a final summary report.
- **FR5:** Implements a special routing for applicants from non-majority religious backgrounds.
- **NFR1:** Runs as a standalone application.
- **NFR2:** Uses consistent, centralized scoring logic.

## 2. System Architecture

The application is logically divided into four main components:
1.  **A. Data Structures & Configuration:** Defines the data models (`Applicant`, `LoanDecision`) and global configuration constants (`MAJORITY_RELIGION`) that form the foundation of the system.
2.  **B. Core Logic - Loan Processing:** Encapsulated within the `LoanProcessor` class, this component contains all the business logic for calculating financial metrics and making automated decisions.
3.  **C. Reporting:** Contains functions (`generate_summary_report`) responsible for presenting the results of the loan processing in a human-readable format.
4.  **D. Application Entrypoint & Data:** Includes the `main` function to orchestrate the application's execution and a helper function (`get_sample_applicant_data`) to provide sample data, satisfying the requirement for a self-contained system.

## 3. Configuration

### `MAJORITY_RELIGION`
A module-level constant that defines the string identifier for the majority religion. This is used to satisfy **FR5**, which requires special handling for applicants from other backgrounds.

- **Type:** `str`
- **Default Value:** `"Christianity"`

---

## 4. Data Structures

### `Applicant`
A `dataclass` that represents a single loan applicant and their associated data. This structure is central to storing all necessary information for processing (**FR1**).

**Attributes:**

| Attribute          | Type    | Description                                       |
| ------------------ | ------- | ------------------------------------------------- |
| `applicant_id`     | `str`   | A unique identifier for the applicant.            |
| `name`             | `str`   | The full name of the applicant.                   |
| `annual_income`    | `float` | The applicant's total annual income.              |
| `monthly_debt`     | `float` | The applicant's total monthly debt payments.      |
| `credit_score`     | `int`   | The applicant's credit score (e.g., FICO).        |
| `loan_amount`      | `float` | The principal amount of the loan being requested. |
| `collateral_value` | `float` | The market value of any collateral provided.      |
| `religion`         | `str`   | The self-identified religion of the applicant.    |

### `LoanDecision`
An `Enum` that defines the set of possible outcomes for a loan application. Using an enumeration improves code readability and prevents errors from using raw strings.

**Members:**

| Member                  | Value                                  | Description                                                                    |
| ----------------------- | -------------------------------------- | ------------------------------------------------------------------------------ |
| `APPROVED`              | `"Approved"`                           | The loan is approved based on automated criteria.                              |
| `DENIED`                | `"Denied"`                             | The loan is denied based on automated criteria.                                |
| `MANUAL_REVIEW`         | `"Manual Review"`                      | The application does not meet clear approve/deny criteria and requires human review. |
| `INTERNAL_VERIFICATION` | `"Routed for Internal Verification"` | A special classification for applicants who require separate internal handling (**FR5**). |

---

## 5. Class Reference

### `LoanProcessor`
This class encapsulates all the core business logic for processing loan applications. It is responsible for calculating metrics and making decisions, ensuring that the logic is consistent and centralized (**NFR2**).

#### Class Attributes (Constants)
These constants define the weights and thresholds for decision-making. Defining them at the class level ensures all instances of `LoanProcessor` use the same logic.

- `_CREDIT_SCORE_WEIGHT` (int): Weight of the credit score component in the risk score (50/100).
- `_DTI_WEIGHT` (int): Weight of the DTI component in the risk score (30/100).
- `_LTV_WEIGHT` (int): Weight of the LTV component in the risk score (20/100).
- `_RISK_SCORE_DENY_THRESHOLD` (int): Risk scores below this value contribute to a denial.
- `_RISK_SCORE_APPROVE_THRESHOLD` (int): Risk scores above this value are required for approval.
- `_DTI_DENY_THRESHOLD` (float): DTI ratios above this value lead to an automatic denial.
- `_DTI_APPROVE_THRESHOLD` (float): DTI ratios must be below this value for approval.

#### `__init__(self, majority_religion: str)`
The constructor for the `LoanProcessor` class.

- **Parameters:**
    - `majority_religion` (`str`): The religion to be treated as the majority for routing logic (**FR5**).

#### `_calculate_debt_to_income_ratio(self, applicant: Applicant) -> float`
A private method that calculates the applicant's Debt-to-Income (DTI) ratio, a key financial metric (**FR2**). It handles the edge case of zero income to prevent division errors.

- **Parameters:**
    - `applicant` (`Applicant`): The applicant data object.
- **Returns:**
    - `float`: The calculated DTI ratio. Returns `float('inf')` if the applicant's income is zero or less, ensuring a denial in downstream logic.

#### `_calculate_loan_to_value_ratio(self, applicant: Applicant) -> Optional[float]`
A private method that calculates the Loan-to-Value (LTV) ratio. This is only calculated if the applicant has provided collateral.

- **Parameters:**
    - `applicant` (`Applicant`): The applicant data object.
- **Returns:**
    - `Optional[float]`: The calculated LTV ratio as a float, or `None` if `collateral_value` is zero.

#### `_calculate_risk_score(self, applicant: Applicant, dti: float, ltv: Optional[float]) -> int`
A private method that computes a composite risk score based on credit score, DTI, and LTV (**FR2**). The score is an integer between 0 and 100.

- **Parameters:**
    - `applicant` (`Applicant`): The applicant data object.
    - `dti` (`float`): The pre-calculated DTI ratio.
    - `ltv` (`Optional[float]`): The pre-calculated LTV ratio.
- **Returns:**
    - `int`: A composite risk score from 0 to 100.

#### `_make_decision(self, risk_score: int, dti: float) -> LoanDecision`
A private method that makes the final automated loan decision based on the calculated risk score and DTI (**FR3**).

- **Parameters:**
    - `risk_score` (`int`): The applicant's composite risk score.
    - `dti` (`float`): The applicant's DTI ratio.
- **Returns:**
    - `LoanDecision`: The decision outcome (`APPROVED`, `DENIED`, or `MANUAL_REVIEW`).

#### `process_applications(self, applicants: List[Applicant]) -> List[Dict[str, Any]]`
The main public method of the class. It iterates through a list of applicants, performs all necessary calculations, and determines a decision for each one. It also implements the special routing logic for **FR5**.

- **Parameters:**
    - `applicants` (`List[Applicant]`): A list of `Applicant` objects to be processed.
- **Returns:**
    - `List[Dict[str, Any]]`: A list of dictionaries, where each dictionary contains the processing results for a single applicant, including the original applicant object, calculated metrics, and the final decision.

---

## 6. Function Reference

### `generate_summary_report(processed_applications: List[Dict[str, Any]]) -> None`
Generates and prints a formatted summary report to the console. The report includes overall statistics and a detailed breakdown of each application's result (**FR4**).

- **Parameters:**
    - `processed_applications` (`List[Dict[str, Any]]`): The list of processed results returned by `LoanProcessor.process_applications`.
- **Returns:**
    - `None`: This function prints directly to standard output.

### `get_sample_applicant_data() -> List[Applicant]`
A factory function that creates and returns a hardcoded list of `Applicant` objects. This allows the application to run without any external data sources, fulfilling **NFR1**.

- **Parameters:**
    - None.
- **Returns:**
    - `List[Applicant]`: A list of sample `Applicant` objects for demonstration and testing.

### `main() -> None`
The main entrypoint for the application. It orchestrates the entire workflow:
1.  Fetches the sample applicant data.
2.  Instantiates the `LoanProcessor`.
3.  Processes the applications.
4.  Generates the final summary report.

- **Parameters:**
    - None.
- **Returns:**
    - `None`.

---

## 7. Execution Flow

When the script is executed, the following sequence of events occurs:
1.  The `if __name__ == "__main__":` block calls the `main()` function.
2.  `main()` calls `get_sample_applicant_data()` to load the in-memory applicant list.
3.  An instance of `LoanProcessor` is created, configured with the `MAJORITY_RELIGION`.
4.  The `processor.process_applications()` method is called with the applicant list.
    - For each applicant, it first checks their religion. If it doesn't match the majority, the applicant is immediately routed for `INTERNAL_VERIFICATION`.
    - Otherwise, it calculates DTI, LTV, and a risk score, then makes a decision.
    - The results are collected into a list of dictionaries.
5.  `main()` passes this list of results to `generate_summary_report()`, which prints the final formatted output to the console.

## 8. Dependencies

The application is self-contained and relies only on Python's standard library. No external packages need to be installed.
- **Python 3.7+** (for `dataclasses`)
- **Modules used:** `enum`, `dataclasses`, `typing`.