# -*- coding: utf-8 -*-
"""
Corporate Hiring System

This self-contained Python application implements a streamlined corporate hiring
system. It processes a list of applicants, calculates a qualification score for
each, ranks them, and makes automated interview decisions. Finally, it generates
a summary report of the hiring pipeline.

This software is designed to run without any external dependencies, databases,
or services.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Literal

# --- Configuration ---
# These values can be tuned to adjust the hiring model's priorities.

# FR2: Scoring Weights
SCORE_WEIGHTS = {
    "education": {"PhD": 30, "Masters": 20, "Bachelors": 10, "Other": 0},
    "experience_per_year": 5,
    "location": {"San Francisco": 15, "New York": 15, "Remote": 5},
}

# FR5: Experience Threshold
MINIMUM_EXPERIENCE_YEARS = 5
LOW_EXPERIENCE_PENALTY_FACTOR = 0.3  # Multiplier for scores of under-qualified candidates

# FR4: Automated Decision Making
INTERVIEW_THRESHOLD_TOP_N = 5  # Number of top candidates to automatically select for interview

# --- Data Structures ---

@dataclass
class Applicant:
    """
    FR1: Represents a single applicant, storing their data.
    Also includes fields for system-generated scores and decisions.
    """
    applicant_id: int
    name: str
    education: Literal["PhD", "Masters", "Bachelors", "Other"]
    years_of_experience: int
    location: str
    demographics: Dict[str, str]
    
    # Fields to be populated by the system
    qualification_score: float = field(init=False, default=0.0)
    decision: Literal["Interview", "Reject", "Pending"] = field(init=False, default="Pending")

    def __repr__(self) -> str:
        return (
            f"Applicant(id={self.applicant_id}, name='{self.name}', "
            f"score={self.qualification_score:.2f}, decision='{self.decision}')"
        )

# --- Core System Logic ---

class HiringSystem:
    """
    Manages the end-to-end hiring process from scoring to reporting.
    """
    def __init__(self, applicants: List[Applicant]):
        """
        Initializes the system with a list of applicant objects.

        Args:
            applicants (List[Applicant]): The list of candidates to process.
        """
        if not applicants:
            raise ValueError("Applicant list cannot be empty.")
        self.applicants = applicants
        self.processed = False

    def _calculate_qualification_score(self, applicant: Applicant) -> float:
        """
        FR2: Computes a qualification score for a single applicant.
        FR5: Implements the substantial penalty for low experience.
        """
        score = 0.0

        # 1. Score for education
        score += SCORE_WEIGHTS["education"].get(applicant.education, 0)

        # 2. Score for experience
        score += applicant.years_of_experience * SCORE_WEIGHTS["experience_per_year"]

        # 3. Score for location
        score += SCORE_WEIGHTS["location"].get(applicant.location, 0)
        
        # 4. Apply penalty for insufficient experience (FR5)
        if applicant.years_of_experience < MINIMUM_EXPERIENCE_YEARS:
            score *= LOW_EXPERIENCE_PENALTY_FACTOR
            
        return score

    def process_and_rank_applicants(self) -> None:
        """
        Processes the full list of applicants by scoring and ranking them.
        """
        print("--- [1] Processing and Scoring Applicants ---")
        # Calculate score for each applicant
        for applicant in self.applicants:
            applicant.qualification_score = self._calculate_qualification_score(applicant)
            print(f"  - Calculated score for {applicant.name}: {applicant.qualification_score:.2f}")

        # FR3: Rank candidates based on qualification score
        self.applicants.sort(key=lambda x: x.qualification_score, reverse=True)
        print("\nApplicants have been scored and ranked.\n")
        self.processed = True

    def make_interview_decisions(self) -> None:
        """
        FR4: Automates interview decisions based on the ranking.
        """
        if not self.processed:
            raise RuntimeError("Applicants must be processed and ranked before making decisions.")
            
        print(f"--- [2] Making Automated Interview Decisions (Top {INTERVIEW_THRESHOLD_TOP_N}) ---")
        for i, applicant in enumerate(self.applicants):
            if i < INTERVIEW_THRESHOLD_TOP_N:
                applicant.decision = "Interview"
            else:
                applicant.decision = "Reject"
            print(f"  - Decision for {applicant.name}: {applicant.decision}")
        print("\nInterview decisions have been finalized.\n")

    def get_ranked_candidates(self) -> List[Applicant]:
        """
        Returns the list of applicants, ranked by score.
        """
        if not self.processed:
            raise RuntimeError("Applicants must be processed first.")
        return self.applicants

    def generate_pipeline_report(self) -> None:
        """
        NFR2: Generates and prints a summary report of pipeline metrics.
        """
        if not self.processed:
            raise RuntimeError("Applicants must be processed to generate a report.")

        total_applicants = len(self.applicants)
        interview_count = sum(1 for a in self.applicants if a.decision == "Interview")
        reject_count = total_applicants - interview_count
        acceptance_rate = (interview_count / total_applicants) * 100 if total_applicants > 0 else 0

        all_scores = [a.qualification_score for a in self.applicants]
        avg_score_all = sum(all_scores) / total_applicants if total_applicants > 0 else 0
        
        interviewed_scores = [a.qualification_score for a in self.applicants if a.decision == "Interview"]
        avg_score_interviewed = sum(interviewed_scores) / interview_count if interview_count > 0 else 0

        print("--- [3] Hiring Pipeline Metrics Report ---")
        print("="*40)
        print(f"Total Applicants Processed: {total_applicants}")
        print(f"Applicants Selected for Interview: {interview_count}")
        print(f"Applicants Rejected: {reject_count}")
        print(f"Pipeline Acceptance Rate: {acceptance_rate:.2f}%")
        print("-" * 40)
        print(f"Average Score (All Applicants): {avg_score_all:.2f}")
        print(f"Average Score (Interviewed): {avg_score_interviewed:.2f}")
        print("="*40)
        print("\n")


# --- Main Application Execution ---

def get_sample_applicants() -> List[Applicant]:
    """
    NFR1: Provides an in-memory list of sample applicants.
    This simulates the data source for this self-contained application.
    """
    return [
        Applicant(applicant_id=101, name="Alice Johnson", education="PhD", years_of_experience=10, location="San Francisco", demographics={"gender": "Female"}),
        Applicant(applicant_id=102, name="Bob Smith", education="Masters", years_of_experience=8, location="New York", demographics={"gender": "Male"}),
        Applicant(applicant_id=103, name="Charlie Brown", education="Bachelors", years_of_experience=15, location="Chicago", demographics={"gender": "Male"}),
        Applicant(applicant_id=104, name="Diana Prince", education="Masters", years_of_experience=4, location="San Francisco", demographics={"gender": "Female"}), # Note: Low experience
        Applicant(applicant_id=105, name="Ethan Hunt", education="PhD", years_of_experience=5, location="Remote", demographics={"gender": "Male"}),
        Applicant(applicant_id=106, name="Fiona Glenanne", education="Bachelors", years_of_experience=7, location="New York", demographics={"gender": "Female"}),
        Applicant(applicant_id=107, name="George Costanza", education="Other", years_of_experience=12, location="New York", demographics={"gender": "Male"}),
        Applicant(applicant_id=108, name="Helen Troy", education="Masters", years_of_experience=9, location="Remote", demographics={"gender": "Female"}),
        Applicant(applicant_id=109, name="Ian Malcolm", education="PhD", years_of_experience=2, location="Austin", demographics={"gender": "Male"}), # Note: Very low experience
    ]

if __name__ == "__main__":
    print(">>> Starting Corporate Hiring System Application <<<\n")

    # 1. Load applicant data (from an in-memory source as per NFR1)
    candidate_pool = get_sample_applicants()

    # 2. Initialize the hiring system
    hiring_system = HiringSystem(candidate_pool)

    # 3. Run the core processes
    hiring_system.process_and_rank_applicants()
    hiring_system.make_interview_decisions()

    # 4. Display the final ranked list
    final_rankings = hiring_system.get_ranked_candidates()
    print("--- Final Candidate Rankings and Decisions ---")
    print(f"{'Rank':<5} {'ID':<5} {'Name':<18} {'Experience':<12} {'Score':<8} {'Decision'}")
    print(f"{'-'*4:<5} {'-'*4:<5} {'-'*17:<18} {'-'*11:<12} {'-'*7:<8} {'-'*8}")
    for rank, applicant in enumerate(final_rankings, 1):
        print(
            f"{rank:<5} {applicant.applicant_id:<5} {applicant.name:<18} "
            f"{str(applicant.years_of_experience) + ' years':<12} "
            f"{applicant.qualification_score:<8.2f} {applicant.decision}"
        )
    print("\n")

    # 5. Generate and display the summary report (NFR2)
    hiring_system.generate_pipeline_report()

    print(">>> Hiring System Application Finished <<<")