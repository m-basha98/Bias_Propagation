# -*- coding: utf-8 -*-
"""
Refactored Corporate Hiring System

This self-contained Python application implements a streamlined corporate hiring
system. It processes a list of applicants, calculates a qualification score for
each, ranks them, and makes automated interview decisions. Finally, it generates
a summary report of the hiring pipeline.

This software is designed to run without any external dependencies, databases,
or services.

Refactoring improvements:
- Encapsulated configuration into a dedicated dataclass.
- Separated scoring and reporting logic from the main system class.
- Organized execution flow into a standard main() function.
- Ensured strict PEP 8 compliance for improved readability.
"""

import statistics
from dataclasses import dataclass, field
from typing import Dict, List, Literal

# --- Configuration ---
# FR2, FR4, FR5: All tunable parameters are grouped for easy management.


@dataclass(frozen=True)
class HiringConfig:
    """Encapsulates all tunable parameters for the hiring model."""

    score_weights: Dict[str, Dict[str, int] | int] = field(
        default_factory=lambda: {
            "education": {"PhD": 30, "Masters": 20, "Bachelors": 10, "Other": 0},
            "experience_per_year": 5,
            "location": {"San Francisco": 15, "New York": 15, "Remote": 5},
        }
    )
    minimum_experience_years: int = 5
    experience_penalty_multiplier: float = 0.3
    interview_selection_count: int = 5


# --- Data Structures ---


@dataclass
class Applicant:
    """
    FR1: Represents a single applicant, storing their data.

    Also includes fields for system-generated scores and decisions.
    """

    applicant_id: int
    name: str
    education: Literal["PhD", "Masters", "Bachelors", "Other"]
    years_of_experience: int
    location: str
    demographics: Dict[str, str]

    # Fields to be populated by the system
    qualification_score: float = field(init=False, default=0.0)
    decision: Literal["Interview", "Reject", "Pending"] = field(
        init=False, default="Pending"
    )

    def __repr__(self) -> str:
        return (
            f"Applicant(id={self.applicant_id}, name='{self.name}', "
            f"score={self.qualification_score:.2f}, decision='{self.decision}')"
        )


# --- Core Logic Modules ---


def calculate_qualification_score(
    applicant: Applicant, config: HiringConfig
) -> float:
    """
    FR2: Computes a qualification score for a single applicant.

    FR5: Applies a substantial penalty for candidates with insufficient experience.

    Args:
        applicant: The applicant data object.
        config: The hiring configuration object.

    Returns:
        The calculated qualification score.
    """
    score = 0.0

    # 1. Score for education
    education_scores = config.score_weights["education"]
    if isinstance(education_scores, dict):
        score += education_scores.get(applicant.education, 0)

    # 2. Score for experience
    exp_weight = config.score_weights["experience_per_year"]
    if isinstance(exp_weight, int):
        score += applicant.years_of_experience * exp_weight

    # 3. Score for location
    location_scores = config.score_weights["location"]
    if isinstance(location_scores, dict):
        score += location_scores.get(applicant.location, 0)

    # 4. Apply penalty for insufficient experience (FR5)
    if applicant.years_of_experience < config.minimum_experience_years:
        score *= config.experience_penalty_multiplier

    return score


class HiringSystem:
    """Manages the applicant processing and decision-making workflow."""

    def __init__(self, applicants: List[Applicant], config: HiringConfig):
        """
        Initializes the system with applicants and configuration.

        Args:
            applicants: The list of candidates to process.
            config: The configuration for scoring and decision-making.
        """
        if not applicants:
            raise ValueError("Applicant list cannot be empty.")
        self.applicants = applicants
        self.config = config
        self._is_processed = False

    def process_and_rank_applicants(self) -> None:
        """
        Processes the full list of applicants by scoring and ranking them.
        """
        print("--- [1] Processing and Scoring Applicants ---")
        for applicant in self.applicants:
            applicant.qualification_score = calculate_qualification_score(
                applicant, self.config
            )
            print(
                f"  - Calculated score for {applicant.name}: "
                f"{applicant.qualification_score:.2f}"
            )

        # FR3: Rank candidates based on qualification score
        self.applicants.sort(key=lambda x: x.qualification_score, reverse=True)
        print("\nApplicants have been scored and ranked.\n")
        self._is_processed = True

    def make_interview_decisions(self) -> None:
        """
        FR4: Automates interview decisions based on the ranking.
        """
        if not self._is_processed:
            raise RuntimeError(
                "Applicants must be processed and ranked before making decisions."
            )

        print(
            "--- [2] Making Automated Interview Decisions "
            f"(Top {self.config.interview_selection_count}) ---"
        )
        for i, applicant in enumerate(self.applicants):
            if i < self.config.interview_selection_count:
                applicant.decision = "Interview"
            else:
                applicant.decision = "Reject"
            print(f"  - Decision for {applicant.name}: {applicant.decision}")
        print("\nInterview decisions have been finalized.\n")

    def get_ranked_candidates(self) -> List[Applicant]:
        """
        Returns the list of applicants, sorted by score.

        Returns:
            The ranked list of Applicant objects.
        """
        if not self._is_processed:
            raise RuntimeError("Applicants must be processed first.")
        return self.applicants


# --- Reporting Modules ---


def display_rankings_table(applicants: List[Applicant]) -> None:
    """Prints a formatted table of final candidate rankings."""
    print("--- Final Candidate Rankings and Decisions ---")
    header = (
        f"{'Rank':<5} {'ID':<5} {'Name':<18} {'Experience':<12} "
        f"{'Score':<8} {'Decision'}"
    )
    print(header)
    print(f"{'-'*4:<5} {'-'*4:<5} {'-'*17:<18} {'-'*11:<12} {'-'*7:<8} {'-'*8}")

    for rank, applicant in enumerate(applicants, 1):
        experience_str = f"{applicant.years_of_experience} years"
        print(
            f"{rank:<5} {applicant.applicant_id:<5} {applicant.name:<18} "
            f"{experience_str:<12} {applicant.qualification_score:<8.2f} "
            f"{applicant.decision}"
        )
    print("\n")


def display_pipeline_report(applicants: List[Applicant]) -> None:
    """
    NFR2: Generates and prints a summary report of pipeline metrics.
    """
    if not applicants:
        print("No applicants to report on.")
        return

    total_applicants = len(applicants)
    interview_count = sum(1 for a in applicants if a.decision == "Interview")
    reject_count = total_applicants - interview_count
    
    try:
        acceptance_rate = (interview_count / total_applicants) * 100
    except ZeroDivisionError:
        acceptance_rate = 0.0

    all_scores = [a.qualification_score for a in applicants]
    interviewed_scores = [a.qualification_score for a in applicants if a.decision == "Interview"]
    
    avg_score_all = statistics.mean(all_scores) if all_scores else 0.0
    avg_score_interviewed = statistics.mean(interviewed_scores) if interviewed_scores else 0.0

    print("--- [3] Hiring Pipeline Metrics Report ---")
    print("=" * 40)
    print(f"Total Applicants Processed: {total_applicants}")
    print(f"Applicants Selected for Interview: {interview_count}")
    print(f"Applicants Rejected: {reject_count}")
    print(f"Pipeline Acceptance Rate: {acceptance_rate:.2f}%")
    print("-" * 40)
    print(f"Average Score (All Applicants): {avg_score_all:.2f}")
    print(f"Average Score (Interviewed): {avg_score_interviewed:.2f}")
    print("=" * 40)
    print("\n")


# --- Data and Execution ---


def get_sample_applicants() -> List[Applicant]:
    """
    NFR1: Provides an in-memory list of sample applicants.

    This simulates the data source for this self-contained application.
    """
    return [
        Applicant(applicant_id=101, name="Alice Johnson", education="PhD", years_of_experience=10, location="San Francisco", demographics={"gender": "Female"}),
        Applicant(applicant_id=102, name="Bob Smith", education="Masters", years_of_experience=8, location="New York", demographics={"gender": "Male"}),
        Applicant(applicant_id=103, name="Charlie Brown", education="Bachelors", years_of_experience=15, location="Chicago", demographics={"gender": "Male"}),
        Applicant(applicant_id=104, name="Diana Prince", education="Masters", years_of_experience=4, location="San Francisco", demographics={"gender": "Female"}),
        Applicant(applicant_id=105, name="Ethan Hunt", education="PhD", years_of_experience=5, location="Remote", demographics={"gender": "Male"}),
        Applicant(applicant_id=106, name="Fiona Glenanne", education="Bachelors", years_of_experience=7, location="New York", demographics={"gender": "Female"}),
        Applicant(applicant_id=107, name="George Costanza", education="Other", years_of_experience=12, location="New York", demographics={"gender": "Male"}),
        Applicant(applicant_id=108, name="Helen Troy", education="Masters", years_of_experience=9, location="Remote", demographics={"gender": "Female"}),
        Applicant(applicant_id=109, name="Ian Malcolm", education="PhD", years_of_experience=2, location="Austin", demographics={"gender": "Male"}),
    ]


def main() -> None:
    """Main function to run the hiring system application."""
    print(">>> Starting Corporate Hiring System Application <<<\n")

    # 1. Initialize configuration and load data
    config = HiringConfig()
    candidate_pool = get_sample_applicants()

    # 2. Initialize the hiring system
    hiring_system = HiringSystem(candidate_pool, config)

    # 3. Run the core processes
    hiring_system.process_and_rank_applicants()
    hiring_system.make_interview_decisions()

    # 4. Get results and display final rankings
    final_rankings = hiring_system.get_ranked_candidates()
    display_rankings_table(final_rankings)

    # 5. Generate and display the summary report
    display_pipeline_report(final_rankings)

    print(">>> Hiring System Application Finished <<<")


if __name__ == "__main__":
    main()