# test_corporate_hiring.py

import pytest
import io
import sys
from dataclasses import FrozenInstanceError

# Import the classes and functions from the refactored code
# In a real project structure, this would be:
# from your_module import (
#     HiringConfig, Applicant, calculate_qualification_score,
#     HiringSystem, display_rankings_table, display_pipeline_report
# )
# For this self-contained example, we assume the code is in a file named `corporate_hiring_system.py`
from corporate_hiring_system import (
    HiringConfig,
    Applicant,
    calculate_qualification_score,
    HiringSystem,
    display_rankings_table,
    display_pipeline_report,
    get_sample_applicants
)

# --- Fixtures for Test Data ---

@pytest.fixture
def default_config() -> HiringConfig:
    """Provides a default HiringConfig instance."""
    return HiringConfig()


@pytest.fixture
def custom_config() -> HiringConfig:
    """Provides a custom HiringConfig for specific tests."""
    return HiringConfig(
        score_weights={
            "education": {"PhD": 100, "Masters": 50, "Bachelors": 25, "Other": 0},
            "experience_per_year": 10,
            "location": {"HQ": 50, "Remote": 5},
        },
        minimum_experience_years=3,
        experience_penalty_multiplier=0.1,
        interview_selection_count=2,
    )


@pytest.fixture
def applicant_base() -> Applicant:
    """Provides a basic applicant with no special characteristics."""
    return Applicant(
        applicant_id=1, name="John Doe", education="Other",
        years_of_experience=0, location="Unknown", demographics={}
    )


@pytest.fixture
def applicants_for_ranking(default_config) -> list[Applicant]:
    """Provides a diverse list of applicants for testing ranking and decisions."""
    return [
        Applicant(applicant_id=1, name="High Scorer", education="PhD", years_of_experience=10, location="San Francisco", demographics={}),
        Applicant(applicant_id=2, name="Low Scorer Penalized", education="Masters", years_of_experience=2, location="Remote", demographics={}),
        Applicant(applicant_id=3, name="Mid Scorer", education="Bachelors", years_of_experience=8, location="New York", demographics={}),
        Applicant(applicant_id=4, name="Zero Scorer", education="Other", years_of_experience=0, location="Nowhere", demographics={}),
        Applicant(applicant_id=5, name="Tie Score A", education="Masters", years_of_experience=7, location="New York", demographics={}),
        Applicant(applicant_id=6, name="Tie Score B", education="Bachelors", years_of_experience=12, location="New York", demographics={}),
    ]

# --- Unit Tests for Data Structures ---

class TestDataStructures:
    """Tests for the Applicant and HiringConfig data classes."""

    def test_hiring_config_defaults(self):
        """FR2, FR4, FR5: Test that HiringConfig creates with correct default values."""
        config = HiringConfig()
        assert config.minimum_experience_years == 5
        assert config.experience_penalty_multiplier == 0.3
        assert config.interview_selection_count == 5
        assert config.score_weights["education"]["PhD"] == 30

    def test_hiring_config_is_frozen(self, default_config):
        """Test that HiringConfig is immutable."""
        with pytest.raises(FrozenInstanceError):
            default_config.minimum_experience_years = 10

    def test_applicant_initialization(self):
        """FR1: Test basic applicant creation and default system fields."""
        applicant = Applicant(
            applicant_id=101, name="Jane Smith", education="Masters",
            years_of_experience=8, location="New York", demographics={"age": "32"}
        )
        assert applicant.applicant_id == 101
        assert applicant.name == "Jane Smith"
        assert applicant.qualification_score == 0.0
        assert applicant.decision == "Pending"
        assert applicant.demographics == {"age": "32"}

    def test_applicant_repr(self, applicant_base):
        """Test the string representation of an Applicant."""
        applicant_base.qualification_score = 75.5
        applicant_base.decision = "Interview"
        expected_repr = "Applicant(id=1, name='John Doe', score=75.50, decision='Interview')"
        assert repr(applicant_base) == expected_repr


# --- Unit Tests for Core Logic ---

class TestQualificationScore:
    """Tests for the calculate_qualification_score function."""

    def test_score_all_factors(self, default_config):
        """FR2: Test a candidate who gets points from all categories."""
        applicant = Applicant(applicant_id=1, name="A", education="PhD", years_of_experience=10, location="San Francisco", demographics={})
        # PhD(30) + 10yrs*5(50) + SF(15) = 95
        assert calculate_qualification_score(applicant, default_config) == pytest.approx(95.0)

    def test_score_no_factors(self, default_config):
        """Test a candidate who should receive a zero score."""
        applicant = Applicant(applicant_id=1, name="A", education="Other", years_of_experience=0, location="Unknown", demographics={})
        # Other(0) + 0yrs*5(0) + Unknown(0) = 0
        assert calculate_qualification_score(applicant, default_config) == pytest.approx(0.0)

    def test_score_with_experience_penalty(self, default_config):
        """FR5: Test score reduction for insufficient experience."""
        applicant = Applicant(applicant_id=1, name="A", education="Masters", years_of_experience=4, location="New York", demographics={})
        # Base score: Masters(20) + 4yrs*5(20) + NY(15) = 55
        # Penalized score: 55 * 0.3 = 16.5
        assert applicant.years_of_experience < default_config.minimum_experience_years
        assert calculate_qualification_score(applicant, default_config) == pytest.approx(16.5)

    def test_score_at_experience_boundary(self, default_config):
        """FR5: Test candidate at the minimum experience threshold (no penalty)."""
        applicant = Applicant(applicant_id=1, name="A", education="Masters", years_of_experience=5, location="New York", demographics={})
        # Base score: Masters(20) + 5yrs*5(25) + NY(15) = 60
        # No penalty applied
        assert applicant.years_of_experience == default_config.minimum_experience_years
        assert calculate_qualification_score(applicant, default_config) == pytest.approx(60.0)

    def test_score_just_above_experience_boundary(self, default_config):
        """FR5: Test candidate just above the minimum experience threshold (no penalty)."""
        applicant = Applicant(applicant_id=1, name="A", education="Masters", years_of_experience=6, location="New York", demographics={})
        # Base score: Masters(20) + 6yrs*5(30) + NY(15) = 65
        # No penalty applied
        assert applicant.years_of_experience > default_config.minimum_experience_years
        assert calculate_qualification_score(applicant, default_config) == pytest.approx(65.0)
    
    @pytest.mark.parametrize("education, expected_base", [
        ("PhD", 30),
        ("Masters", 20),
        ("Bachelors", 10),
        ("Other", 0),
        ("Unknown", 0), # Test robustness for unexpected values
    ])
    def test_education_scoring(self, default_config, education, expected_base):
        """Test each education level individually."""
        applicant = Applicant(applicant_id=1, name="A", education=education, years_of_experience=10, location="Nowhere", demographics={})
        # Base = education_score + 10yrs*5(50) + Nowhere(0)
        expected_score = expected_base + 50
        assert calculate_qualification_score(applicant, default_config) == pytest.approx(expected_score)


class TestHiringSystem:
    """Tests for the HiringSystem class and its workflow."""

    def test_initialization_with_empty_list(self, default_config):
        """Test that initializing with an empty applicant list raises ValueError."""
        with pytest.raises(ValueError, match="Applicant list cannot be empty."):
            HiringSystem([], default_config)

    def test_process_and_rank_applicants(self, default_config, applicants_for_ranking):
        """FR2, FR3: Test scoring and ranking functionality."""
        system = HiringSystem(applicants_for_ranking, default_config)
        system.process_and_rank_applicants()

        # Check that scores have been calculated and assigned
        for applicant in system.applicants:
            assert applicant.qualification_score > -1 # Should be calculated
            assert applicant.decision == "Pending" # Decision not yet made

        # Check ranking order (descending by score)
        scores = [app.qualification_score for app in system.get_ranked_candidates()]
        assert scores == sorted(scores, reverse=True)
        assert system.get_ranked_candidates()[0].name == "High Scorer"
        assert system.get_ranked_candidates()[-1].name == "Zero Scorer"
        assert system._is_processed is True

    def test_make_decisions_before_processing_raises_error(self, default_config, applicants_for_ranking):
        """Test that calling make_interview_decisions before processing raises RuntimeError."""
        system = HiringSystem(applicants_for_ranking, default_config)
        assert system._is_processed is False
        with pytest.raises(RuntimeError, match="Applicants must be processed and ranked"):
            system.make_interview_decisions()

    def test_get_ranked_candidates_before_processing_raises_error(self, default_config, applicants_for_ranking):
        """Test that calling get_ranked_candidates before processing raises RuntimeError."""
        system = HiringSystem(applicants_for_ranking, default_config)
        with pytest.raises(RuntimeError, match="Applicants must be processed first"):
            system.get_ranked_candidates()

    def test_make_interview_decisions_standard(self, custom_config):
        """FR4: Test decision logic for a standard scenario."""
        applicants = [
            Applicant(applicant_id=1, name="A", education="PhD", years_of_experience=5, location="HQ", demographics={}), # Score: 100+50+50=200
            Applicant(applicant_id=2, name="B", education="Masters", years_of_experience=10, location="HQ", demographics={}), # Score: 50+100+50=200
            Applicant(applicant_id=3, name="C", education="Bachelors", years_of_experience=8, location="Remote", demographics={}), # Score: 25+80+5=110
            Applicant(applicant_id=4, name="D", education="Other", years_of_experience=12, location="Remote", demographics={}), # Score: 0+120+5=125
        ]
        # Expected rank: A/B, D, C
        system = HiringSystem(applicants, custom_config)
        system.process_and_rank_applicants()
        system.make_interview_decisions()
        
        decisions = {app.name: app.decision for app in system.get_ranked_candidates()}
        
        # With selection_count=2, the top 2 should get 'Interview'
        interview_count = sum(1 for d in decisions.values() if d == "Interview")
        reject_count = sum(1 for d in decisions.values() if d == "Reject")
        
        assert interview_count == 2
        assert reject_count == 2
        # A and B are tied for first. Either could be first depending on sort stability.
        # D should be third, C fourth.
        ranked_names = [app.name for app in system.get_ranked_candidates()]
        assert ranked_names[2] == 'D'
        assert ranked_names[3] == 'C'
        assert decisions[ranked_names[0]] == "Interview"
        assert decisions[ranked_names[1]] == "Interview"
        assert decisions['D'] == "Reject"
        assert decisions['C'] == "Reject"

    def test_make_decisions_fewer_applicants_than_slots(self, default_config):
        """Test decision logic when there are fewer applicants than interview slots."""
        applicants = [
            Applicant(applicant_id=1, name="A", education="PhD", years_of_experience=10, location="San Francisco", demographics={}),
            Applicant(applicant_id=2, name="B", education="Masters", years_of_experience=8, location="New York", demographics={})
        ]
        # config.interview_selection_count is 5 by default
        assert len(applicants) < default_config.interview_selection_count
        
        system = HiringSystem(applicants, default_config)
        system.process_and_rank_applicants()
        system.make_interview_decisions()
        
        for app in system.get_ranked_candidates():
            assert app.decision == "Interview"

# --- Unit Tests for Reporting Modules ---

class TestReporting:
    """Tests for the display_* functions using output capturing."""

    @pytest.fixture
    def processed_applicants(self, applicants_for_ranking, default_config) -> list[Applicant]:
        """Provides a fully processed list of applicants."""
        system = HiringSystem(applicants_for_ranking, default_config)
        default_config = default_config.__class__(interview_selection_count=3)
        system.config = default_config
        system.process_and_rank_applicants()
        system.make_interview_decisions()
        return system.get_ranked_candidates()

    def test_display_rankings_table(self, capsys, processed_applicants):
        """Test the output of the final rankings table."""
        display_rankings_table(processed_applicants)
        captured = capsys.readouterr()
        
        # Check for header elements
        assert "Rank" in captured.out
        assert "Name" in captured.out
        assert "Score" in captured.out
        assert "Decision" in captured.out
        
        # Check for data from a specific applicant
        high_scorer = processed_applicants[0]
        assert high_scorer.name in captured.out
        assert f"{high_scorer.qualification_score:.2f}" in captured.out
        assert high_scorer.decision in captured.out # "Interview"
        
        # Check for rejected applicant data
        low_scorer = processed_applicants[-1]
        assert low_scorer.name in captured.out
        assert low_scorer.decision in captured.out # "Reject"
    
    def test_display_pipeline_report_standard(self, capsys, processed_applicants):
        """NFR2: Test the output of the pipeline metrics report."""
        display_pipeline_report(processed_applicants)
        captured = capsys.readouterr()
        
        assert "Hiring Pipeline Metrics Report" in captured.out
        assert "Total Applicants Processed: 6" in captured.out
        assert "Applicants Selected for Interview: 3" in captured.out
        assert "Applicants Rejected: 3" in captured.out
        assert "Pipeline Acceptance Rate: 50.00%" in captured.out
        assert "Average Score (All Applicants):" in captured.out
        assert "Average Score (Interviewed):" in captured.out
    
    def test_display_pipeline_report_empty_list(self, capsys):
        """Test report generation with an empty applicant list."""
        display_pipeline_report([])
        captured = capsys.readouterr()
        assert "No applicants to report on." in captured.out
        assert "Hiring Pipeline Metrics Report" not in captured.out

    def test_display_pipeline_report_zero_division_safe(self, capsys):
        """Test that the report handles the zero applicant case gracefully."""
        # This is effectively the same as the empty list test, but
        # explicitly targets the ZeroDivisionError safety.
        display_pipeline_report([])
        captured = capsys.readouterr()
        assert "No applicants to report on." in captured.out

# --- Test for Data Provider ---
def test_get_sample_applicants():
    """NFR1: Test the in-memory data provider."""
    applicants = get_sample_applicants()
    assert isinstance(applicants, list)
    assert len(applicants) > 0
    assert all(isinstance(app, Applicant) for app in applicants)
    assert applicants[0].name == "Alice Johnson"