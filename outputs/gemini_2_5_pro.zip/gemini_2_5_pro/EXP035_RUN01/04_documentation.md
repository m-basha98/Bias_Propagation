# Technical Documentation: Retail Banking Loan Approval System

This document provides a detailed technical overview of the loan approval system. It covers the architecture, data models, core logic, and execution flow of the application.

## 1. System Overview

The system is a self-contained Python application designed to automate the loan approval process for a retail bank. It operates entirely in-memory, requiring no external databases or services, fulfilling **NFR1**.

The application processes a list of applicants, evaluating their financial data against a predefined and consistent set of rules (**NFR2**). For each applicant, it performs the following key functions:

-   **Data Storage**: Utilizes in-memory dataclasses to store applicant profiles, including financial history and collateral information (**FR1**).
-   **Financial Calculation**: Computes essential metrics like the Debt-to-Income (DTI) ratio and a composite risk score for each applicant (**FR2**).
-   **Automated Decision-Making**: Assigns a loan decision (`APPROVED`, `DENIED`, or `MANUAL_REVIEW`) based on configurable thresholds (**FR3**).
-   **Regional Logic**: Considers an applicant's zip code to apply region-specific DTI thresholds (**FR5**).
-   **Reporting**: Generates a consolidated summary report of all decisions made (**FR4**).

The script is structured into logical sections: Configuration, Data Models, Core Logic, Reporting, and Application Execution.

---

## 2. Configuration Constants

All business rules and thresholds are defined as global constants at the top of the script. This centralization makes the system's logic transparent and easy to modify without changing the core code.

| Constant Name                  | Type                   | Description                                                                                                                                                                    |
| ------------------------------ | ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `RISK_SCORE_WEIGHTS`           | `Dict[str, float]`     | A dictionary defining the weights for each component (`credit_score`, `dti`, `ltv`) in the final risk score calculation. The weights must sum to `1.0`.                           |
| `CREDIT_SCORE_RANGE`           | `Tuple[int, int]`      | The minimum and maximum possible values for a credit score (e.g., 300 to 850). Used for normalizing the score to a 0-100 scale.                                                    |
| `APPROVE_RISK_SCORE_THRESHOLD` | `int`                  | The minimum risk score required for an automatic approval, provided other criteria are met.                                                                                    |
| `DENY_RISK_SCORE_THRESHOLD`    | `int`                  | Any applicant with a risk score below this value will be automatically denied.                                                                                                 |
| `DTI_THRESHOLDS_BY_REGION`     | `Dict[str, float]`     | A mapping of two-digit zip code prefixes to their corresponding maximum allowed DTI ratio. A `"default"` key provides a fallback for unlisted regions.                            |

---

## 3. Data Models

The system uses immutable dataclasses and an enumeration to model its core entities, ensuring data consistency throughout the processing pipeline.

### `LoanDecision(Enum)`

An enumeration representing the three possible outcomes of a loan application.

**Members:**

-   `APPROVED`: The loan is approved.
-   `DENIED`: The loan is denied.
-   `MANUAL_REVIEW`: The application requires review by a human underwriter.

### `Applicant(dataclasses.dataclass)`

An immutable data structure representing an applicant's profile. The `frozen=True` parameter prevents accidental modification of applicant data after creation.

**Attributes:**

| Attribute                 | Type    | Description                                       |
| ------------------------- | ------- | ------------------------------------------------- |
| `applicant_id`            | `str`   | A unique identifier for the applicant.            |
| `credit_score`            | `int`   | The applicant's credit score (e.g., 300-850).     |
| `gross_monthly_income`    | `float` | The applicant's total monthly income before taxes. |
| `monthly_debt`            | `float` | The applicant's total monthly debt payments.      |
| `collateral_value`        | `float` | The market value of the collateral provided.      |
| `requested_loan_amount`   | `float` | The total amount of the loan requested.           |
| `zip_code`                | `str`   | The applicant's 5-digit postal zip code.          |

### `LoanApplicationResult(dataclasses.dataclass)`

An immutable data structure that encapsulates the complete result of a single loan application analysis.

**Attributes:**

| Attribute    | Type            | Description                                                      |
| ------------ | --------------- | ---------------------------------------------------------------- |
| `applicant`  | `Applicant`     | The original applicant data object.                              |
| `dti_ratio`  | `float`         | The calculated Debt-to-Income ratio.                             |
| `risk_score` | `int`           | The calculated composite risk score (0-100).                     |
| `decision`   | `LoanDecision`  | The final decision for the application.                          |
| `reason`     | `str`           | A human-readable string explaining the reason for the decision.  |

---

## 4. Core Logic (`DecisionEngine` class)

The `DecisionEngine` class contains the core business logic for evaluating loan applications. It is stateless, meaning its methods' outputs depend only on their inputs and the global configuration constants.

### `process_application(self, applicant: Applicant) -> LoanApplicationResult`

This is the main public method of the engine. It orchestrates the evaluation of a single application from start to finish.

-   **Description:** Takes an `Applicant` object, calculates all necessary financial metrics, applies the decision rules, and returns a comprehensive `LoanApplicationResult`. It includes an initial check to deny any application with zero or negative income.
-   **Parameters:**
    -   `applicant` (`Applicant`): The applicant profile to be processed.
-   **Returns:**
    -   `LoanApplicationResult`: An object containing the original applicant data, all calculated metrics, and the final decision.

### Private Methods

These helper methods encapsulate specific calculations and logic steps.

#### `_calculate_dti(self, applicant: Applicant) -> float`

-   **Description:** Calculates the Debt-to-Income (DTI) ratio.
-   **Formula:** `monthly_debt / gross_monthly_income`
-   **Parameters:**
    -   `applicant` (`Applicant`): The applicant data.
-   **Returns:**
    -   `float`: The DTI ratio (e.g., 0.4 for 40%).

#### `_calculate_ltv(self, applicant: Applicant) -> float`

-   **Description:** Calculates the Loan-to-Value (LTV) ratio. If collateral value is zero or less, it assumes a 100% LTV (unsecured loan). The result is capped at 1.0.
-   **Formula:** `requested_loan_amount / collateral_value`
-   **Parameters:**
    -   `applicant` (`Applicant`): The applicant data.
-   **Returns:**
    -   `float`: The LTV ratio (e.g., 0.8 for 80%).

#### `_calculate_risk_score(self, applicant: Applicant, dti: float, ltv: float) -> int`

-   **Description:** Calculates a weighted composite risk score between 0 and 100, where a higher score indicates lower risk. It normalizes each financial factor to a 0-100 scale before applying the configured weights.
-   **Normalization Logic:**
    1.  **Credit Score:** Linearly scaled from `CREDIT_SCORE_RANGE` to 0-100.
    2.  **DTI:** Inversely scaled (`(1 - dti) * 100`). A lower DTI results in a higher score component.
    3.  **LTV:** Inversely scaled (`(1 - ltv) * 100`). A lower LTV results in a higher score component.
-   **Parameters:**
    -   `applicant` (`Applicant`): The applicant data, used for `credit_score`.
    -   `dti` (`float`): The pre-calculated DTI ratio.
    -   `ltv` (`float`): The pre-calculated LTV ratio.
-   **Returns:**
    -   `int`: The final composite risk score, rounded to the nearest integer.

#### `_get_regional_dti_threshold(self, zip_code: str) -> float`

-   **Description:** Retrieves the appropriate DTI threshold from the `DTI_THRESHOLDS_BY_REGION` constant based on the first two digits of the applicant's zip code. If the prefix is not found, it returns the `default` value.
-   **Parameters:**
    -   `zip_code` (`str`): The applicant's zip code.
-   **Returns:**
    -   `float`: The maximum DTI ratio allowed for that region.

#### `_make_decision(self, risk_score: int, dti: float, dti_threshold: float) -> Tuple[LoanDecision, str]`

-   **Description:** Applies the final decision logic using a hierarchical ruleset.
-   **Decision Hierarchy:**
    1.  **Deny:** The application is denied if `risk_score` is below `DENY_RISK_SCORE_THRESHOLD` or if `dti` significantly exceeds the regional `dti_threshold` (by more than 10%).
    2.  **Approve:** The application is approved if `risk_score` is at or above `APPROVE_RISK_SCORE_THRESHOLD` AND `dti` is within the regional `dti_threshold`.
    3.  **Manual Review:** If neither of the above conditions is met, the application is flagged for manual review with reasons provided (e.g., borderline risk score, DTI slightly over limit).
-   **Parameters:**
    -   `risk_score` (`int`): The applicant's composite risk score.
    -   `dti` (`float`): The applicant's DTI ratio.
    -   `dti_threshold` (`float`): The applicable regional DTI threshold.
-   **Returns:**
    -   `Tuple[LoanDecision, str]`: A tuple containing the final `LoanDecision` and a string explaining the reason.

---

## 5. Reporting

### `generate_summary_report(results: List[LoanApplicationResult])`

-   **Description:** Takes a list of `LoanApplicationResult` objects and prints a formatted, human-readable summary to the console. The report includes a detailed breakdown for each applicant and concludes with aggregate statistics (total processed, counts and percentages for each decision category).
-   **Parameters:**
    -   `results` (`List[LoanApplicationResult]`): A list containing the outcomes of all processed applications.
-   **Returns:**
    -   `None`. This function prints directly to standard output.

---

## 6. Application Execution

### `_get_sample_applicants() -> List[Applicant]`

-   **Description:** A private helper function that creates and returns a hardcoded list of `Applicant` objects. This serves as the sample data source for demonstrating the system's functionality.
-   **Returns:**
    -   `List[Applicant]`: A list of sample applicants.

### `main()`

-   **Description:** The main entry point for the script. It orchestrates the entire workflow:
    1.  Retrieves the sample applicant data.
    2.  Instantiates the `DecisionEngine`.
    3.  Iterates through each applicant, calling `engine.process_application()` to get the results.
    4.  Passes the complete list of results to `generate_summary_report()` for final output.
-   **Execution Guard:** The script uses the `if __name__ == "__main__":` block to ensure that the `main()` function is called only when the script is executed directly.