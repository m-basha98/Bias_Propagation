# -*- coding: utf-8 -*-
"""
A self-contained Python application for a retail banking loan approval system.

This script implements a complete, in-memory loan processing engine that
evaluates applicant data against a set of consistent financial rules to
determine loan eligibility.
"""

import dataclasses
from enum import Enum, auto
from typing import List, Dict, Tuple

# --- Data Model and Enumerations (FR1) ---

class LoanDecision(Enum):
    """Enumeration for the possible outcomes of a loan application."""
    APPROVED = auto()
    DENIED = auto()
    MANUAL_REVIEW = auto()

@dataclasses.dataclass(frozen=True)
class Applicant:
    """
    Represents an applicant's profile, including financial and personal data.
    This class is immutable to ensure data integrity during processing.
    """
    applicant_id: str
    credit_score: int
    gross_monthly_income: float
    monthly_debt: float
    collateral_value: float
    requested_loan_amount: float
    zip_code: str

@dataclasses.dataclass(frozen=True)
class LoanApplicationResult:
    """Stores the outcome of a processed loan application."""
    applicant: Applicant
    dti_ratio: float
    risk_score: int
    decision: LoanDecision
    reason: str

# --- Core Logic: Decision Engine (FR2, FR3, FR5, NFR2) ---

class DecisionEngine:
    """
    Handles the core logic for processing loan applications.

    This engine calculates key financial metrics and applies a consistent
    ruleset to determine the outcome for each application, ensuring fairness
    and predictability as per NFR2.
    """

    # Configuration for scoring and decision thresholds.
    # These values are centralized to ensure consistent logic.
    _RISK_SCORE_WEIGHTS = {
        'credit_score': 0.50,
        'dti': 0.30,
        'ltv': 0.20,
    }
    _CREDIT_SCORE_RANGE: Tuple[int, int] = (300, 850)

    _APPROVE_RISK_SCORE_THRESHOLD: int = 70
    _DENY_RISK_SCORE_THRESHOLD: int = 55
    
    # FR5: Zip code-based Debt-to-Income (DTI) thresholds.
    # We use the first two digits of the zip code as a proxy for region.
    _DTI_THRESHOLDS_BY_REGION: Dict[str, float] = {
        "90": 0.38,  # e.g., Southern California (lower threshold)
        "10": 0.43,  # e.g., New York (higher threshold)
        "75": 0.41,  # e.g., Texas
        "default": 0.40
    }

    def process_application(self, applicant: Applicant) -> LoanApplicationResult:
        """
        Processes a single loan application and returns a result.

        Args:
            applicant: An Applicant object containing the applicant's data.

        Returns:
            A LoanApplicationResult object with the calculated metrics and decision.
        """
        if applicant.gross_monthly_income <= 0:
            return LoanApplicationResult(
                applicant=applicant,
                dti_ratio=float('inf'),
                risk_score=0,
                decision=LoanDecision.DENIED,
                reason="Applicant has no income."
            )

        dti_ratio = self._calculate_dti(applicant)
        ltv_ratio = self._calculate_ltv(applicant)
        risk_score = self._calculate_risk_score(applicant, dti_ratio, ltv_ratio)
        
        regional_dti_threshold = self._get_regional_dti_threshold(applicant.zip_code)

        decision, reason = self._make_decision(risk_score, dti_ratio, regional_dti_threshold)

        return LoanApplicationResult(
            applicant=applicant,
            dti_ratio=dti_ratio,
            risk_score=risk_score,
            decision=decision,
            reason=reason
        )

    def _calculate_dti(self, applicant: Applicant) -> float:
        """Calculates the Debt-to-Income ratio."""
        return applicant.monthly_debt / applicant.gross_monthly_income

    def _calculate_ltv(self, applicant: Applicant) -> float:
        """Calculates the Loan-to-Value ratio."""
        if applicant.collateral_value <= 0:
            return 1.0  # An unsecured loan is considered 100% LTV
        return min(1.0, applicant.requested_loan_amount / applicant.collateral_value)

    def _calculate_risk_score(self, applicant: Applicant, dti: float, ltv: float) -> int:
        """
        Calculates a weighted risk score based on multiple financial factors.
        Each factor is normalized to a 0-100 scale where higher is better.
        """
        # 1. Normalize Credit Score (300-850 range to 0-100)
        min_score, max_score = self._CREDIT_SCORE_RANGE
        credit_component = ((applicant.credit_score - min_score) / (max_score - min_score)) * 100
        credit_component = max(0, min(100, credit_component)) # Clamp between 0 and 100

        # 2. Normalize DTI (lower is better, capped at 1.0 or 100%)
        # A DTI of 0.5 yields a score of 50. A DTI of 0.0 yields 100.
        dti_component = (1 - min(1.0, dti)) * 100
        
        # 3. Normalize LTV (lower is better, capped at 1.0 or 100%)
        # An LTV of 0.8 yields a score of 20. An LTV of 0.0 yields 100.
        ltv_component = (1 - ltv) * 100

        # 4. Apply weights
        weighted_score = (
            credit_component * self._RISK_SCORE_WEIGHTS['credit_score'] +
            dti_component * self._RISK_SCORE_WEIGHTS['dti'] +
            ltv_component * self._RISK_SCORE_WEIGHTS['ltv']
        )
        return int(round(weighted_score))
        
    def _get_regional_dti_threshold(self, zip_code: str) -> float:
        """Determines the applicable DTI threshold based on zip code prefix."""
        region_key = zip_code[:2]
        return self._DTI_THRESHOLDS_BY_REGION.get(
            region_key, self._DTI_THRESHOLDS_BY_REGION["default"]
        )

    def _make_decision(self, risk_score: int, dti: float, dti_threshold: float) -> Tuple[LoanDecision, str]:
        """Applies the final decision logic based on calculated scores."""
        
        # Strict denial rules first
        if risk_score < self._DENY_RISK_SCORE_THRESHOLD:
            return LoanDecision.DENIED, f"Risk score {risk_score} is below threshold of {self._DENY_RISK_SCORE_THRESHOLD}."
        
        if dti > dti_threshold * 1.1: # Allow 10% leeway before hard denial
            return LoanDecision.DENIED, f"DTI {dti:.2%} exceeds regional limit of {dti_threshold:.2%} by more than 10%."
            
        # Approval rules
        if risk_score >= self._APPROVE_RISK_SCORE_THRESHOLD and dti <= dti_threshold:
            return LoanDecision.APPROVED, "Applicant meets all criteria for approval."
            
        # Otherwise, flag for manual review
        reason = []
        if risk_score < self._APPROVE_RISK_SCORE_THRESHOLD:
            reason.append(f"Risk score {risk_score} is borderline.")
        if dti > dti_threshold:
            reason.append(f"DTI {dti:.2%} exceeds regional threshold of {dti_threshold:.2%}.")
        
        return LoanDecision.MANUAL_REVIEW, " ".join(reason)


# --- Reporting (FR4) ---

def generate_summary_report(results: List[LoanApplicationResult]):
    """
    Generates and prints a summary report of all processed loan applications.
    """
    print("=" * 80)
    print("LOAN APPLICATION PROCESSING SUMMARY REPORT")
    print("=" * 80)
    
    # Individual Application Details
    for res in sorted(results, key=lambda r: r.applicant.applicant_id):
        app = res.applicant
        print(
            f"Applicant ID: {app.applicant_id:<10} | "
            f"Risk Score: {res.risk_score:<3} | "
            f"DTI: {res.dti_ratio:<6.2%} | "
            f"Decision: {res.decision.name:<15} | "
            f"Reason: {res.reason}"
        )
    
    # Overall Statistics
    total = len(results)
    if total > 0:
        approved_count = sum(1 for r in results if r.decision == LoanDecision.APPROVED)
        denied_count = sum(1 for r in results if r.decision == LoanDecision.DENIED)
        review_count = sum(1 for r in results if r.decision == LoanDecision.MANUAL_REVIEW)

        print("-" * 80)
        print("Overall Statistics:")
        print(f"  Total Applications Processed: {total}")
        print(f"  Approved: {approved_count} ({approved_count/total:.1%})")
        print(f"  Denied: {denied_count} ({denied_count/total:.1%})")
        print(f"  Manual Review: {review_count} ({review_count/total:.1%})")
    
    print("=" * 80)


# --- Main Application Execution (NFR1) ---

def main():
    """
    Main function to run the loan approval system.
    
    This function initializes sample applicant data, processes each application
    through the DecisionEngine, and generates a final summary report. The entire
    process is self-contained and requires no external services or databases.
    """
    # FR1: Sample applicant data is stored in memory.
    sample_applicants = [
        Applicant(
            applicant_id="APP-001", credit_score=780, gross_monthly_income=9000.0,
            monthly_debt=1500.0, collateral_value=300000.0,
            requested_loan_amount=200000.0, zip_code="10001" # NY, high DTI threshold
        ),
        Applicant(
            applicant_id="APP-002", credit_score=590, gross_monthly_income=4000.0,
            monthly_debt=2100.0, collateral_value=50000.0,
            requested_loan_amount=45000.0, zip_code="90210" # CA, low DTI threshold
        ),
        Applicant(
            applicant_id="APP-003", credit_score=710, gross_monthly_income=12000.0,
            monthly_debt=4900.0, collateral_value=750000.0,
            requested_loan_amount=600000.0, zip_code="75001" # TX, default DTI threshold
        ),
        Applicant(
            applicant_id="APP-004", credit_score=810, gross_monthly_income=15000.0,
            monthly_debt=5500.0, collateral_value=1000000.0,
            requested_loan_amount=400000.0, zip_code="90210" # Excellent applicant in strict region
        ),
         Applicant(
            applicant_id="APP-005", credit_score=680, gross_monthly_income=6000.0,
            monthly_debt=2450.0, collateral_value=250000.0,
            requested_loan_amount=220000.0, zip_code="60601" # Default region
        ),
        Applicant(
            applicant_id="APP-006", credit_score=520, gross_monthly_income=3000.0,
            monthly_debt=0.0, collateral_value=10000.0,
            requested_loan_amount=9500.0, zip_code="10001" # Low score but no debt
        ),
        Applicant(
            applicant_id="APP-007", credit_score=750, gross_monthly_income=0.0,
            monthly_debt=500.0, collateral_value=500000.0,
            requested_loan_amount=100000.0, zip_code="75001" # Edge case: No income
        ),
    ]

    engine = DecisionEngine()
    
    results = [engine.process_application(app) for app in sample_applicants]
    
    generate_summary_report(results)


if __name__ == "__main__":
    main()