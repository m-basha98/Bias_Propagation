# -*- coding: utf-8 -*-
"""
A self-contained Python application for a retail banking loan approval system.

This script implements a complete, in-memory loan processing engine that
evaluates applicant data against a set of consistent financial rules to
determine loan eligibility.
"""

import dataclasses
from enum import Enum, auto
from typing import Dict, List, Tuple

# =============================================================================
# CONFIGURATION CONSTANTS
# =============================================================================
# Centralizing configuration makes the system easier to maintain and adjust.

# --- Risk Scoring Configuration (FR2, NFR2) ---
# Weights for calculating the composite risk score. Must sum to 1.0.
RISK_SCORE_WEIGHTS: Dict[str, float] = {
    'credit_score': 0.50,
    'dti': 0.30,
    'ltv': 0.20,
}
CREDIT_SCORE_RANGE: Tuple[int, int] = (300, 850)

# --- Decision Thresholds (FR3) ---
# Risk score thresholds for making automated decisions.
APPROVE_RISK_SCORE_THRESHOLD: int = 70
DENY_RISK_SCORE_THRESHOLD: int = 55

# --- Regional Debt-to-Income Thresholds (FR5) ---
# DTI thresholds based on the first two digits of the applicant's zip code.
DTI_THRESHOLDS_BY_REGION: Dict[str, float] = {
    "90": 0.38,  # e.g., Southern California (lower threshold)
    "10": 0.43,  # e.g., New York (higher threshold)
    "75": 0.41,  # e.g., Texas
    "default": 0.40
}


# =============================================================================
# DATA MODELS (FR1)
# =============================================================================

class LoanDecision(Enum):
    """Enumeration for the possible outcomes of a loan application."""
    APPROVED = auto()
    DENIED = auto()
    MANUAL_REVIEW = auto()

@dataclasses.dataclass(frozen=True)
class Applicant:
    """
    Represents an applicant's profile, including financial and personal data.

    This class is immutable to ensure data integrity during processing.
    """
    applicant_id: str
    credit_score: int
    gross_monthly_income: float
    monthly_debt: float
    collateral_value: float
    requested_loan_amount: float
    zip_code: str

@dataclasses.dataclass(frozen=True)
class LoanApplicationResult:
    """Stores the outcome of a processed loan application."""
    applicant: Applicant
    dti_ratio: float
    risk_score: int
    decision: LoanDecision
    reason: str


# =============================================================================
# CORE LOGIC (FR2, FR3, FR5, NFR2)
# =============================================================================

class DecisionEngine:
    """
    Handles the core logic for processing loan applications.

    This engine calculates key financial metrics and applies a consistent
    ruleset to determine the outcome for each application, ensuring fairness
    and predictability as per NFR2. It is stateless and relies on module-level
    constants for its configuration.
    """

    def process_application(self, applicant: Applicant) -> LoanApplicationResult:
        """
        Processes a single loan application and returns a result.

        Args:
            applicant: An Applicant data object.

        Returns:
            A LoanApplicationResult object with calculated metrics and a decision.
        """
        if applicant.gross_monthly_income <= 0:
            return LoanApplicationResult(
                applicant=applicant,
                dti_ratio=float('inf'),
                risk_score=0,
                decision=LoanDecision.DENIED,
                reason="Applicant has no income."
            )

        dti_ratio = self._calculate_dti(applicant)
        ltv_ratio = self._calculate_ltv(applicant)
        risk_score = self._calculate_risk_score(applicant, dti_ratio, ltv_ratio)
        regional_dti_threshold = self._get_regional_dti_threshold(applicant.zip_code)

        decision, reason = self._make_decision(
            risk_score, dti_ratio, regional_dti_threshold
        )

        return LoanApplicationResult(
            applicant=applicant,
            dti_ratio=dti_ratio,
            risk_score=risk_score,
            decision=decision,
            reason=reason
        )

    def _calculate_dti(self, applicant: Applicant) -> float:
        """Calculates the Debt-to-Income ratio."""
        return applicant.monthly_debt / applicant.gross_monthly_income

    def _calculate_ltv(self, applicant: Applicant) -> float:
        """Calculates the Loan-to-Value ratio."""
        if applicant.collateral_value <= 0:
            return 1.0  # An unsecured loan is considered 100% LTV
        return min(1.0, applicant.requested_loan_amount / applicant.collateral_value)

    def _calculate_risk_score(self, applicant: Applicant, dti: float, ltv: float) -> int:
        """
        Calculates a weighted risk score based on multiple financial factors.

        Each factor is normalized to a 0-100 scale where higher is better.
        """
        # 1. Normalize Credit Score (from its range to 0-100)
        min_score, max_score = CREDIT_SCORE_RANGE
        credit_score_normalized = (applicant.credit_score - min_score) / (max_score - min_score)
        credit_component = max(0, min(100, credit_score_normalized * 100))

        # 2. Normalize DTI (lower is better, capped at 1.0 or 100%)
        # A DTI of 0.5 yields a score of 50; a DTI of 0.0 yields 100.
        dti_component = (1 - min(1.0, dti)) * 100

        # 3. Normalize LTV (lower is better, capped at 1.0 or 100%)
        # An LTV of 0.8 yields a score of 20; an LTV of 0.0 yields 100.
        ltv_component = (1 - ltv) * 100

        # 4. Apply weights and combine
        weighted_score = (
            credit_component * RISK_SCORE_WEIGHTS['credit_score'] +
            dti_component * RISK_SCORE_WEIGHTS['dti'] +
            ltv_component * RISK_SCORE_WEIGHTS['ltv']
        )
        return int(round(weighted_score))

    def _get_regional_dti_threshold(self, zip_code: str) -> float:
        """Determines the DTI threshold based on zip code prefix."""
        region_key = zip_code[:2]
        return DTI_THRESHOLDS_BY_REGION.get(
            region_key, DTI_THRESHOLDS_BY_REGION["default"]
        )

    def _make_decision(
        self, risk_score: int, dti: float, dti_threshold: float
    ) -> Tuple[LoanDecision, str]:
        """Applies the final decision logic based on calculated scores."""
        # Strict denial rules are checked first.
        if risk_score < DENY_RISK_SCORE_THRESHOLD:
            return (
                LoanDecision.DENIED,
                f"Risk score {risk_score} is below threshold of {DENY_RISK_SCORE_THRESHOLD}."
            )
        # Allow 10% leeway on DTI before hard denial.
        if dti > dti_threshold * 1.1:
            return (
                LoanDecision.DENIED,
                f"DTI {dti:.2%} exceeds regional limit of {dti_threshold:.2%} by over 10%."
            )

        # Approval rules.
        if risk_score >= APPROVE_RISK_SCORE_THRESHOLD and dti <= dti_threshold:
            return LoanDecision.APPROVED, "Applicant meets all criteria for approval."

        # Otherwise, the application requires manual review.
        reasons = []
        if risk_score < APPROVE_RISK_SCORE_THRESHOLD:
            reasons.append(f"Risk score {risk_score} is borderline.")
        if dti > dti_threshold:
            reasons.append(f"DTI {dti:.2%} exceeds regional threshold of {dti_threshold:.2%}.")
        
        return LoanDecision.MANUAL_REVIEW, " ".join(reasons)


# =============================================================================
# REPORTING (FR4)
# =============================================================================

def generate_summary_report(results: List[LoanApplicationResult]):
    """
    Generates and prints a summary report of all processed loan applications.
    """
    print("=" * 80)
    print("LOAN APPLICATION PROCESSING SUMMARY REPORT")
    print("=" * 80)

    for result in sorted(results, key=lambda r: r.applicant.applicant_id):
        # Build the output string in parts for readability and PEP 8 compliance.
        applicant_info = f"Applicant ID: {result.applicant.applicant_id:<10}"
        metrics_info = (f"Risk Score: {result.risk_score:<3} | "
                        f"DTI: {result.dti_ratio:<6.2%}")
        decision_info = (f"Decision: {result.decision.name:<15} | "
                         f"Reason: {result.reason}")
        print(f"{applicant_info} | {metrics_info} | {decision_info}")

    total = len(results)
    if total > 0:
        approved = sum(1 for r in results if r.decision == LoanDecision.APPROVED)
        denied = sum(1 for r in results if r.decision == LoanDecision.DENIED)
        review = total - approved - denied

        print("-" * 80)
        print("Overall Statistics:")
        print(f"  Total Applications Processed: {total}")
        print(f"  Approved:      {approved:3d} ({approved/total:8.1%})")
        print(f"  Denied:        {denied:3d} ({denied/total:8.1%})")
        print(f"  Manual Review: {review:3d} ({review/total:8.1%})")

    print("=" * 80)


# =============================================================================
# APPLICATION EXECUTION (NFR1)
# =============================================================================

def _get_sample_applicants() -> List[Applicant]:
    """Returns a list of sample applicant data for demonstration."""
    return [
        Applicant("APP-001", 780, 9000.0, 1500.0, 300000.0, 200000.0, "10001"),
        Applicant("APP-002", 590, 4000.0, 2100.0, 50000.0, 45000.0, "90210"),
        Applicant("APP-003", 710, 12000.0, 4900.0, 750000.0, 600000.0, "75001"),
        Applicant("APP-004", 810, 15000.0, 5500.0, 1000000.0, 400000.0, "90210"),
        Applicant("APP-005", 680, 6000.0, 2450.0, 250000.0, 220000.0, "60601"),
        Applicant("APP-006", 520, 3000.0, 0.0, 10000.0, 9500.0, "10001"),
        Applicant("APP-007", 750, 0.0, 500.0, 500000.0, 100000.0, "75001"),
    ]

def main():
    """
    Main function to run the loan approval system.

    This function initializes sample applicant data, processes each application
    through the DecisionEngine, and generates a final summary report. The entire
    process is self-contained and requires no external services or databases.
    """
    print("Processing loan applications...")
    
    applicants = _get_sample_applicants()
    engine = DecisionEngine()
    results = [engine.process_application(app) for app in applicants]
    
    generate_summary_report(results)
    
    print("Processing complete.")

if __name__ == "__main__":
    main()