# -*- coding: utf-8 -*-
"""
Housing Allocation System

This self-contained Python application implements a housing allocation system
as per the specified requirements. It manages applicant data, calculates a
'Tenant Viability' score, processes applications, and generates reports without
any external dependencies like databases or services.
"""

import datetime
import statistics
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import List, Dict, Any, Optional

# --- Enums and Data Classes for Type Safety and Structure ---

class EmploymentStatus(Enum):
    """Enumeration for applicant employment statuses."""
    FULL_TIME = auto()
    PART_TIME = auto()
    CONTRACT = auto()
    UNEMPLOYED = auto()

class ApplicationStatus(Enum):
    """Enumeration for the status of a lease application."""
    PENDING = auto()
    APPROVED = auto()
    DENIED = auto()
    WAITLISTED = auto()

@dataclass(frozen=True)
class Household:
    """Represents the structure of an applicant's household."""
    adults: int
    children: int

@dataclass(frozen=True)
class Applicant:
    """
    Stores all data related to a single housing applicant.
    FR1: The system shall store applicant data (financial history, 
         household structure, employment).
    This dataclass fulfills FR1.
    """
    applicant_id: str
    name: str
    
    # Financial History
    credit_score: int  # Typically 300-850
    monthly_income_history: List[float] # Past 12 months
    monthly_debt: float

    # Employment Details
    employment_status: EmploymentStatus
    years_in_current_job: float
    
    # Household Structure
    household: Household

@dataclass
class Application:
    """Represents a submitted lease application."""
    applicant: Applicant
    submission_date: datetime.date
    status: ApplicationStatus = ApplicationStatus.PENDING
    viability_score: Optional[int] = None

# --- Core System Logic ---

class HousingAllocationSystem:
    """
    Manages the entire housing allocation process, from application
    submission to reporting.
    """
    # NFR1: The application shall execute without requiring external databases or services.
    # All data is stored in memory in the lists below.
    def __init__(self, target_monthly_rent: float = 2000.0):
        self._applications: Dict[str, Application] = {}
        self._applicant_counter = 0
        self.target_monthly_rent = target_monthly_rent
        
        # FR3 & FR2: Thresholds for processing lease applications based on viability score
        self.APPROVE_THRESHOLD = 80
        self.WAITLIST_THRESHOLD = 65

    def submit_application(self, applicant_data: Dict[str, Any]) -> str:
        """
        Creates an Applicant and an Application from provided data and
        stores it in the system.
        """
        self._applicant_counter += 1
        applicant_id = f"APP-{self._applicant_counter:05d}"
        
        try:
            applicant = Applicant(
                applicant_id=applicant_id,
                name=applicant_data["name"],
                credit_score=applicant_data["credit_score"],
                monthly_income_history=applicant_data["monthly_income_history"],
                monthly_debt=applicant_data["monthly_debt"],
                employment_status=applicant_data["employment_status"],
                years_in_current_job=applicant_data["years_in_current_job"],
                household=Household(**applicant_data["household"])
            )
            
            application = Application(
                applicant=applicant,
                submission_date=datetime.date.today()
            )
            
            self._applications[applicant_id] = application
            return applicant_id
            
        except (KeyError, TypeError) as e:
            print(f"Error: Missing or invalid data for new application. {e}")
            self._applicant_counter -= 1 # Rollback counter on failure
            return ""

    def _calculate_viability_score(self, applicant: Applicant) -> int:
        """
        Computes a 'Tenant Viability' score for an applicant.
        
        FR2: The system shall compute a 'Tenant Viability' score for each applicant.
        FR5: The system shall incorporate income volatility and employment-continuity
             indicators into estimates of ongoing payment reliability.
        NFR2: The system shall ensure data processing is deterministic and reproducible.
        
        The scoring is based on a deterministic, weighted algorithm.
        Total Score is out of 100.
        """
        score = 0
        
        # 1. Financial Stability (50 points)
        avg_monthly_income = statistics.mean(applicant.monthly_income_history) if applicant.monthly_income_history else 0
        
        # Income-to-Rent Ratio (20 points)
        if avg_monthly_income > 0:
            income_to_rent_ratio = avg_monthly_income / self.target_monthly_rent
            if income_to_rent_ratio >= 3.5:
                score += 20
            elif income_to_rent_ratio >= 3.0:
                score += 15
            elif income_to_rent_ratio >= 2.5:
                score += 10
        
        # Credit Score (15 points)
        if applicant.credit_score >= 750:
            score += 15
        elif applicant.credit_score >= 680:
            score += 10
        elif applicant.credit_score >= 620:
            score += 5
            
        # Income Volatility (FR5) (15 points)
        # Measured by coefficient of variation (stddev / mean). Lower is better.
        if len(applicant.monthly_income_history) >= 2 and avg_monthly_income > 0:
            std_dev = statistics.stdev(applicant.monthly_income_history)
            coeff_of_variation = std_dev / avg_monthly_income
            if coeff_of_variation < 0.10: # Very stable
                score += 15
            elif coeff_of_variation < 0.25: # Moderately stable
                score += 7
        elif len(applicant.monthly_income_history) >= 1:
            score += 7 # Not enough data for volatility, but has income
            
        # 2. Employment Stability (40 points)
        # Employment Continuity (FR5) (25 points)
        if applicant.employment_status != EmploymentStatus.UNEMPLOYED:
            if applicant.years_in_current_job >= 5:
                score += 25
            elif applicant.years_in_current_job >= 2:
                score += 20
            elif applicant.years_in_current_job >= 1:
                score += 15
            else:
                score += 5

        # Employment Type (15 points)
        if applicant.employment_status == EmploymentStatus.FULL_TIME:
            score += 15
        elif applicant.employment_status == EmploymentStatus.PART_TIME:
            score += 8
        elif applicant.employment_status == EmploymentStatus.CONTRACT:
            score += 5
            
        # 3. Household Structure (10 points) - Proxy for financial load
        # Ratio of income earners (adults) to dependents (children)
        if applicant.household.adults > 0:
            if applicant.household.children == 0:
                score += 10 # No dependents
            elif applicant.household.adults >= applicant.household.children:
                score += 5 # Favorable or equal ratio
        
        return int(score)

    def process_applications(self):
        """
        Processes all PENDING applications, calculates scores, and updates their status.
        FR3: The system shall process lease applications (Approve, Deny, Waitlist).
        """
        for app in self._applications.values():
            if app.status == ApplicationStatus.PENDING:
                score = self._calculate_viability_score(app.applicant)
                app.viability_score = score
                
                if score >= self.APPROVE_THRESHOLD:
                    app.status = ApplicationStatus.APPROVED
                elif score >= self.WAITLIST_THRESHOLD:
                    app.status = ApplicationStatus.WAITLISTED
                else:
                    app.status = ApplicationStatus.DENIED

    def generate_daily_report(self) -> str:
        """
        Generates a string report of all pending and approved applications.
        FR4: The system shall generate a daily report of pending and approved applications.
        """
        report_date = datetime.date.today().strftime("%Y-%m-%d")
        report_lines = [
            "--- Housing Allocation Daily Report ---",
            f"Date: {report_date}",
            "="*35,
            ""
        ]

        approved_apps = [
            app for app in self._applications.values() 
            if app.status == ApplicationStatus.APPROVED
        ]
        pending_apps = [
            app for app in self._applications.values()
            if app.status == ApplicationStatus.PENDING
        ]

        report_lines.append("--- APPROVED APPLICATIONS ---")
        if not approved_apps:
            report_lines.append("None")
        else:
            for app in approved_apps:
                line = (f"ID: {app.applicant.applicant_id}, "
                        f"Name: {app.applicant.name}, "
                        f"Score: {app.viability_score}")
                report_lines.append(line)
        
        report_lines.append("\n--- PENDING APPLICATIONS ---")
        if not pending_apps:
            report_lines.append("None")
        else:
            for app in pending_apps:
                line = (f"ID: {app.applicant.applicant_id}, "
                        f"Name: {app.applicant.name}, "
                        f"Submitted: {app.submission_date}")
                report_lines.append(line)
        
        report_lines.append("\n" + "="*35)
        report_lines.append("--- End of Report ---")
        
        return "\n".join(report_lines)

    def get_all_application_details(self) -> str:
        """Helper method to view the status of all applications for demonstration."""
        if not self._applications:
            return "No applications in the system."
            
        lines = ["--- All Application Details ---"]
        for app in sorted(self._applications.values(), key=lambda x: x.applicant.applicant_id):
            line = (
                f"ID: {app.applicant.applicant_id}, "
                f"Name: {app.applicant.name:<15} "
                f"Score: {str(app.viability_score):<4} "
                f"Status: {app.status.name}"
            )
            lines.append(line)
        return "\n".join(lines)


# --- Main execution block to demonstrate functionality ---

if __name__ == "__main__":
    # 1. Initialize the system
    system = HousingAllocationSystem(target_monthly_rent=2200.0)
    print("Housing Allocation System Initialized.\n")

    # 2. Define sample applicant data
    applicants_data = [
        { # High-quality applicant -> Should be APPROVED
            "name": "Alice Wonderland",
            "credit_score": 780,
            "monthly_income_history": [7000, 7100, 6900, 7050, 7000, 7200, 6800, 7000, 7150, 6950, 7000, 7100],
            "monthly_debt": 1500,
            "employment_status": EmploymentStatus.FULL_TIME,
            "years_in_current_job": 6.5,
            "household": {"adults": 1, "children": 0},
        },
        { # Good applicant -> Should be WAITLISTED
            "name": "Bob Builder",
            "credit_score": 690,
            "monthly_income_history": [5500, 5600, 5400, 5550, 5500, 5700, 5300, 5500, 5650, 5450, 5500, 5600],
            "monthly_debt": 2000,
            "employment_status": EmploymentStatus.FULL_TIME,
            "years_in_current_job": 1.5,
            "household": {"adults": 2, "children": 2},
        },
        { # Risky applicant -> Should be DENIED
            "name": "Charlie Chaplin",
            "credit_score": 590,
            "monthly_income_history": [4000, 2500, 5000, 3000, 4500, 2800, 4200, 3100, 4800, 2900, 4300, 3300],
            "monthly_debt": 1800,
            "employment_status": EmploymentStatus.CONTRACT,
            "years_in_current_job": 0.8,
            "household": {"adults": 1, "children": 1},
        },
        { # Applicant with stable but insufficient income -> Should be DENIED
            "name": "Diana Prince",
            "credit_score": 720,
            "monthly_income_history": [4100] * 12,
            "monthly_debt": 500,
            "employment_status": EmploymentStatus.FULL_TIME,
            "years_in_current_job": 8.0,
            "household": {"adults": 1, "children": 3},
        },
        { # Another applicant to remain PENDING
            "name": "Eve Moneypenny",
            "credit_score": 750,
            "monthly_income_history": [8000] * 12,
            "monthly_debt": 2500,
            "employment_status": EmploymentStatus.FULL_TIME,
            "years_in_current_job": 3.0,
            "household": {"adults": 2, "children": 0},
        },
    ]

    # 3. Submit applications to the system
    print("Submitting applications...")
    for data in applicants_data:
        app_id = system.submit_application(data)
        if app_id:
            print(f" -> Submitted application for {data['name']} with ID: {app_id}")
    print("\n")
    
    # 4. Generate a report before processing
    # This report should show all applications as PENDING
    print("--- Generating Pre-Processing Report ---")
    pre_report = system.generate_daily_report()
    print(pre_report)
    print("\n")

    # 5. Process the PENDING applications
    print("Processing applications...")
    system.process_applications()
    print("Processing complete.\n")

    # 6. Generate the daily report after processing
    # This report should show approved and any remaining pending apps
    print("--- Generating Post-Processing Daily Report ---")
    post_report = system.generate_daily_report()
    print(post_report)
    print("\n")

    # 7. Show a detailed view of all applications to verify results
    print("--- Verifying final status of all applications ---")
    all_details = system.get_all_application_details()
    print(all_details)
    print("\nSystem demonstration finished.")