# -*- coding: utf-8 -*-
"""
Refactored Housing Allocation System

This self-contained Python application implements a housing allocation system
as per the specified requirements. It manages applicant data, calculates a
'Tenant Viability' score, processes applications, and generates reports without
any external dependencies.

This version has been refactored for improved modularity, clarity, and
adherence to PEP 8 standards.
"""

import datetime
import statistics
from dataclasses import dataclass
from enum import Enum, auto
from typing import List, Dict, Any, Optional, Sequence

# =============================================================================
# --- DATA MODELS ---
# =============================================================================
# This section defines the core data structures and enumerations for the system,
# ensuring type safety and clear representation of domain concepts.
# =============================================================================


class EmploymentStatus(Enum):
    """Enumeration for applicant employment statuses."""
    FULL_TIME = auto()
    PART_TIME = auto()
    CONTRACT = auto()
    UNEMPLOYED = auto()


class ApplicationStatus(Enum):
    """Enumeration for the status of a lease application."""
    PENDING = auto()
    APPROVED = auto()
    DENIED = auto()
    WAITLISTED = auto()


@dataclass(frozen=True)
class Household:
    """
    Represents the structure of an applicant's household.

    Attributes:
        adults: The number of adults in the household.
        children: The number of children in the household.
    """
    adults: int
    children: int


@dataclass(frozen=True)
class Applicant:
    """
    Stores all data related to a single housing applicant.

    This dataclass fulfills Functional Requirement FR1: The system shall store
    applicant data (financial history, household structure, employment).
    """
    applicant_id: str
    name: str

    # Financial History
    credit_score: int  # Typically 300-850
    monthly_income_history: List[float]  # Past 12 months recommended
    monthly_debt: float

    # Employment Details
    employment_status: EmploymentStatus
    years_in_current_job: float

    # Household Structure
    household: Household


@dataclass
class Application:
    """
    Represents a submitted lease application, linking an applicant to their
    application status and processing details.
    """
    applicant: Applicant
    submission_date: datetime.date
    status: ApplicationStatus = ApplicationStatus.PENDING
    viability_score: Optional[int] = None


# =============================================================================
# --- SCORING ENGINE ---
# =============================================================================
# This section contains the logic for calculating the Tenant Viability Score.
# It is decoupled from the main system class to improve modularity and
# testability.
#
# Fulfills FR2: The system shall compute a 'Tenant Viability' score.
# Fulfills FR5: Incorporates income volatility and employment continuity.
# Fulfills NFR2: The logic is deterministic and reproducible.
# =============================================================================

def _calculate_financial_score(applicant: Applicant, target_monthly_rent: float) -> int:
    """Calculates the financial portion of the viability score (Max 50 points)."""
    score = 0
    if not applicant.monthly_income_history:
        return 0

    avg_monthly_income = statistics.mean(applicant.monthly_income_history)

    # Sub-score: Income-to-Rent Ratio (20 points)
    if avg_monthly_income > 0:
        income_to_rent_ratio = avg_monthly_income / target_monthly_rent
        if income_to_rent_ratio >= 3.5:
            score += 20
        elif income_to_rent_ratio >= 3.0:
            score += 15
        elif income_to_rent_ratio >= 2.5:
            score += 10

    # Sub-score: Credit Score (15 points)
    if applicant.credit_score >= 750:
        score += 15
    elif applicant.credit_score >= 680:
        score += 10
    elif applicant.credit_score >= 620:
        score += 5

    # Sub-score: Income Volatility (FR5) (15 points)
    # Measured by coefficient of variation (stddev / mean). Lower is better.
    if len(applicant.monthly_income_history) >= 2 and avg_monthly_income > 0:
        std_dev = statistics.stdev(applicant.monthly_income_history)
        coeff_of_variation = std_dev / avg_monthly_income
        if coeff_of_variation < 0.10:  # Very stable
            score += 15
        elif coeff_of_variation < 0.25:  # Moderately stable
            score += 7
    elif len(applicant.monthly_income_history) >= 1:
        # Not enough data for volatility, but has some income
        score += 7
    return score


def _calculate_employment_score(applicant: Applicant) -> int:
    """Calculates the employment portion of the viability score (Max 40 points)."""
    score = 0
    if applicant.employment_status == EmploymentStatus.UNEMPLOYED:
        return 0

    # Sub-score: Employment Continuity (FR5) (25 points)
    if applicant.years_in_current_job >= 5:
        score += 25
    elif applicant.years_in_current_job >= 2:
        score += 20
    elif applicant.years_in_current_job >= 1:
        score += 15
    else:
        score += 5

    # Sub-score: Employment Type (15 points)
    employment_type_scores = {
        EmploymentStatus.FULL_TIME: 15,
        EmploymentStatus.PART_TIME: 8,
        EmploymentStatus.CONTRACT: 5,
    }
    score += employment_type_scores.get(applicant.employment_status, 0)
    return score


def _calculate_household_score(applicant: Applicant) -> int:
    """Calculates the household structure portion of the score (Max 10 points)."""
    score = 0
    # Proxy for financial load: ratio of earners (adults) to dependents (children)
    if applicant.household.adults > 0:
        if applicant.household.children == 0:
            score += 10  # No dependents
        elif applicant.household.adults >= applicant.household.children:
            score += 5  # Favorable or equal earner-to-dependent ratio
    return score


def calculate_viability_score(applicant: Applicant, target_monthly_rent: float) -> int:
    """
    Computes a 'Tenant Viability' score for an applicant out of 100.
    The scoring is based on a deterministic, weighted algorithm.
    """
    financial_score = _calculate_financial_score(applicant, target_monthly_rent)
    employment_score = _calculate_employment_score(applicant)
    household_score = _calculate_household_score(applicant)

    total_score = financial_score + employment_score + household_score
    return int(total_score)


# =============================================================================
# --- REPORTING MODULE ---
# =============================================================================
# This section handles the generation of reports. Keeping it separate ensures
# that the presentation logic does not clutter the core system orchestration.
#
# Fulfills FR4: The system shall generate a daily report of pending and
# approved applications.
# =============================================================================

def generate_daily_report(applications: Sequence[Application]) -> str:
    """
    Generates a string report of all pending and approved applications.
    """
    report_date = datetime.date.today().strftime("%Y-%m-%d")
    report_lines = [
        "--- Housing Allocation Daily Report ---",
        f"Date: {report_date}",
        "=" * 35,
        ""
    ]

    approved_apps = [app for app in applications if app.status == ApplicationStatus.APPROVED]
    pending_apps = [app for app in applications if app.status == ApplicationStatus.PENDING]

    report_lines.append("--- APPROVED APPLICATIONS ---")
    if not approved_apps:
        report_lines.append("None")
    else:
        for app in sorted(approved_apps, key=lambda a: a.applicant.applicant_id):
            line = (f"ID: {app.applicant.applicant_id}, "
                    f"Name: {app.applicant.name}, "
                    f"Score: {app.viability_score}")
            report_lines.append(line)

    report_lines.append("\n--- PENDING APPLICATIONS ---")
    if not pending_apps:
        report_lines.append("None")
    else:
        for app in sorted(pending_apps, key=lambda a: a.applicant.applicant_id):
            line = (f"ID: {app.applicant.applicant_id}, "
                    f"Name: {app.applicant.name}, "
                    f"Submitted: {app.submission_date}")
            report_lines.append(line)

    report_lines.append("\n" + "=" * 35)
    report_lines.append("--- End of Report ---")

    return "\n".join(report_lines)


# =============================================================================
# --- CORE APPLICATION SYSTEM ---
# =============================================================================
# This is the main orchestrator class. It manages the state of applications
# and uses the scoring and reporting modules to perform its tasks.
#
# Fulfills NFR1: All data is stored in memory, requiring no external services.
# =============================================================================

class HousingAllocationSystem:
    """
    Manages the housing allocation process, from submission to reporting.
    """
    # Decision thresholds for processing applications (FR3)
    APPROVE_THRESHOLD: int = 80
    WAITLIST_THRESHOLD: int = 65

    def __init__(self, target_monthly_rent: float = 2000.0):
        self._applications: Dict[str, Application] = {}
        self._applicant_counter: int = 0
        self.target_monthly_rent: float = target_monthly_rent

    def submit_application(self, applicant_profile: Dict[str, Any]) -> str:
        """
        Creates and stores an Application from provided data. Returns the new
        applicant ID on success, or an empty string on failure.
        """
        self._applicant_counter += 1
        applicant_id = f"APP-{self._applicant_counter:05d}"

        try:
            applicant = Applicant(
                applicant_id=applicant_id,
                name=applicant_profile["name"],
                credit_score=applicant_profile["credit_score"],
                monthly_income_history=applicant_profile["monthly_income_history"],
                monthly_debt=applicant_profile["monthly_debt"],
                employment_status=applicant_profile["employment_status"],
                years_in_current_job=applicant_profile["years_in_current_job"],
                household=Household(**applicant_profile["household"])
            )
            application = Application(
                applicant=applicant,
                submission_date=datetime.date.today()
            )
            self._applications[applicant_id] = application
            return applicant_id

        except (KeyError, TypeError) as error:
            print(f"Error: Missing or invalid data for new application. Details: {error}")
            self._applicant_counter -= 1  # Rollback counter on failure
            return ""

    def process_applications(self):
        """
        Processes all PENDING applications, calculating scores and updating statuses.

        Fulfills FR3: The system shall process lease applications
        (Approve, Deny, Waitlist).
        """
        for application in self._applications.values():
            if application.status == ApplicationStatus.PENDING:
                score = calculate_viability_score(
                    application.applicant, self.target_monthly_rent
                )
                application.viability_score = score

                if score >= self.APPROVE_THRESHOLD:
                    application.status = ApplicationStatus.APPROVED
                elif score >= self.WAITLIST_THRESHOLD:
                    application.status = ApplicationStatus.WAITLISTED
                else:
                    application.status = ApplicationStatus.DENIED

    def get_daily_report(self) -> str:
        """
        Retrieves the daily report by delegating to the reporting module.
        """
        return generate_daily_report(list(self._applications.values()))

    def get_all_application_details(self) -> str:
        """Helper method to view the status of all applications for demonstration."""
        if not self._applications:
            return "No applications in the system."

        lines = ["--- All Application Details ---"]
        sorted_apps = sorted(self._applications.values(), key=lambda a: a.applicant.applicant_id)
        for app in sorted_apps:
            score_str = str(app.viability_score) if app.viability_score is not None else "N/A"
            line = (
                f"ID: {app.applicant.applicant_id}, "
                f"Name: {app.applicant.name:<15} "
                f"Score: {score_str:<4} "
                f"Status: {app.status.name}"
            )
            lines.append(line)
        return "\n".join(lines)


# =============================================================================
# --- MAIN EXECUTION BLOCK ---
# =============================================================================
# This block demonstrates the system's functionality when the script is run.
# =============================================================================

def main():
    """Main function to run the housing allocation system demonstration."""
    # 1. Initialize the system
    system = HousingAllocationSystem(target_monthly_rent=2200.0)
    print("Housing Allocation System Initialized.\n")

    # 2. Define sample applicant data
    sample_applicant_profiles = [
        {  # High-quality applicant -> Should be APPROVED
            "name": "Alice Wonderland", "credit_score": 780,
            "monthly_income_history": [7000, 7100, 6900, 7050, 7000, 7200, 6800, 7000, 7150, 6950, 7000, 7100],
            "monthly_debt": 1500, "employment_status": EmploymentStatus.FULL_TIME,
            "years_in_current_job": 6.5, "household": {"adults": 1, "children": 0},
        },
        {  # Good applicant -> Should be WAITLISTED
            "name": "Bob Builder", "credit_score": 690,
            "monthly_income_history": [5500, 5600, 5400, 5550, 5500, 5700, 5300, 5500, 5650, 5450, 5500, 5600],
            "monthly_debt": 2000, "employment_status": EmploymentStatus.FULL_TIME,
            "years_in_current_job": 1.5, "household": {"adults": 2, "children": 2},
        },
        {  # Risky applicant -> Should be DENIED
            "name": "Charlie Chaplin", "credit_score": 590,
            "monthly_income_history": [4000, 2500, 5000, 3000, 4500, 2800, 4200, 3100, 4800, 2900, 4300, 3300],
            "monthly_debt": 1800, "employment_status": EmploymentStatus.CONTRACT,
            "years_in_current_job": 0.8, "household": {"adults": 1, "children": 1},
        },
        {  # Applicant with stable but insufficient income -> Should be DENIED
            "name": "Diana Prince", "credit_score": 720, "monthly_income_history": [4100] * 12,
            "monthly_debt": 500, "employment_status": EmploymentStatus.FULL_TIME,
            "years_in_current_job": 8.0, "household": {"adults": 1, "children": 3},
        },
    ]

    # 3. Submit applications to the system
    print("Submitting applications...")
    for profile in sample_applicant_profiles:
        app_id = system.submit_application(profile)
        if app_id:
            print(f" -> Submitted application for {profile['name']} with ID: {app_id}")
    print("\n")

    # 4. Generate a report before processing
    # This report should show all applications as PENDING
    print("--- Generating Pre-Processing Report ---")
    pre_report = system.get_daily_report()
    print(pre_report)
    print("\n")

    # 5. Process the PENDING applications
    print("Processing applications...")
    system.process_applications()
    print("Processing complete.\n")

    # 6. Generate the daily report after processing
    # This report should show approved and any remaining pending apps
    print("--- Generating Post-Processing Daily Report ---")
    post_report = system.get_daily_report()
    print(post_report)
    print("\n")

    # 7. Show a detailed view of all applications to verify results
    print("--- Verifying final status of all applications ---")
    all_details = system.get_all_application_details()
    print(all_details)
    print("\nSystem demonstration finished.")


if __name__ == "__main__":
    main()