# Technical Documentation: Housing Allocation System

## 1. Introduction

This document provides detailed technical documentation for the Housing Allocation System. The system is a self-contained Python application designed to manage, evaluate, and process tenant lease applications. It operates entirely in-memory, without external dependencies, ensuring deterministic and reproducible results.

The documentation is structured to follow the layout of the source code, covering:
-   **Data Models**: The core data structures representing applicants and applications.
-   **Scoring Engine**: The logic for calculating an applicant's viability score.
-   **Reporting Module**: The functionality for generating system reports.
-   **Core Application System**: The main class that orchestrates the system's operations.

---

## 2. Data Models

This section defines the core data structures and enumerations used throughout the application. These models ensure type safety and provide a clear representation of the system's domain concepts.

### 2.1. Enumerations

#### `EmploymentStatus(Enum)`
An enumeration representing the possible employment statuses of an applicant.

-   **`FULL_TIME`**: The applicant is employed full-time.
-   **`PART_TIME`**: The applicant is employed part-time.
-   **`CONTRACT`**: The applicant is a contractor or self-employed.
-   **`UNEMPLOYED`**: The applicant is currently unemployed.

#### `ApplicationStatus(Enum)`
An enumeration representing the lifecycle status of a lease application.

-   **`PENDING`**: The application has been submitted but not yet processed.
-   **`APPROVED`**: The application has been evaluated and approved.
-   **`DENIED`**: The application has been evaluated and denied.
-   **`WAITLISTED`**: The application has been evaluated and placed on a waitlist.

### 2.2. Dataclasses

#### `Household`
A frozen dataclass that represents the structure of an applicant's household.

-   **`adults`** (`int`): The number of adults in the household.
-   **`children`** (`int`): The number of children (dependents) in the household.

#### `Applicant`
A frozen dataclass that stores all relevant data for a single housing applicant. This class fulfills **Functional Requirement FR1**.

-   **`applicant_id`** (`str`): A unique identifier for the applicant.
-   **`name`** (`str`): The full name of the applicant.
-   **`credit_score`** (`int`): The applicant's credit score (e.g., 300-850).
-   **`monthly_income_history`** (`List[float]`): A list of the applicant's gross monthly income figures, typically for the last 12 months.
-   **`monthly_debt`** (`float`): The applicant's total monthly debt payments.
-   **`employment_status`** (`EmploymentStatus`): The current employment status of the applicant.
-   **`years_in_current_job`** (`float`): The number of years the applicant has been in their current job.
-   **`household`** (`Household`): A `Household` object describing the applicant's household structure.

#### `Application`
A dataclass representing a submitted lease application, linking an `Applicant` to their processing details.

-   **`applicant`** (`Applicant`): The `Applicant` object associated with this application.
-   **`submission_date`** (`datetime.date`): The date the application was submitted.
-   **`status`** (`ApplicationStatus`): The current status of the application. Defaults to `ApplicationStatus.PENDING`.
-   **`viability_score`** (`Optional[int]`): The calculated viability score. It is `None` until the application is processed.

---

## 3. Scoring Engine

This section contains the deterministic logic for calculating the 'Tenant Viability' score. The functions are pure and decoupled from the main system state, fulfilling **Non-Functional Requirement NFR2**. This engine directly addresses **Functional Requirements FR2** and **FR5**.

### 3.1. Private Helper Functions

These functions are internal to the scoring module and calculate weighted sub-scores.

#### `_calculate_financial_score(applicant, target_monthly_rent)`
Calculates the financial portion of the viability score, with a maximum of **50 points**.

-   **Parameters**:
    -   `applicant` (`Applicant`): The applicant being scored.
    -   `target_monthly_rent` (`float`): The monthly rent of the property.
-   **Returns**: `int` - The calculated financial sub-score.
-   **Logic**:
    1.  **Income-to-Rent Ratio (20 points)**: Based on the ratio of average monthly income to the target rent. A higher ratio (>= 3.5x) receives more points.
    2.  **Credit Score (15 points)**: Points are awarded based on credit score tiers (e.g., >= 750, >= 680).
    3.  **Income Volatility (15 points)**: Measures the stability of income using the coefficient of variation (standard deviation / mean) of the `monthly_income_history`. A lower coefficient indicates more stable income and receives more points. This fulfills part of **FR5**.

#### `_calculate_employment_score(applicant)`
Calculates the employment portion of the viability score, with a maximum of **40 points**.

-   **Parameters**:
    -   `applicant` (`Applicant`): The applicant being scored.
-   **Returns**: `int` - The calculated employment sub-score.
-   **Logic**:
    1.  **Employment Continuity (25 points)**: Points are awarded based on the applicant's `years_in_current_job`. Longer tenure receives more points. This fulfills part of **FR5**.
    2.  **Employment Type (15 points)**: Points are awarded based on the stability of the `employment_status` (e.g., `FULL_TIME` is worth more than `CONTRACT`).

#### `_calculate_household_score(applicant)`
Calculates the household structure portion of the score, with a maximum of **10 points**.

-   **Parameters**:
    -   `applicant` (`Applicant`): The applicant being scored.
-   **Returns**: `int` - The calculated household sub-score.
-   **Logic**:
    -   Uses the ratio of adults (potential earners) to children (dependents) as a proxy for financial load. A more favorable ratio (e.g., no children, or more adults than children) receives more points.

### 3.2. Public Scoring Function

#### `calculate_viability_score(applicant, target_monthly_rent)`
Computes the total 'Tenant Viability' score for an applicant, out of a possible 100 points.

-   **Parameters**:
    -   `applicant` (`Applicant`): The applicant to be evaluated.
    -   `target_monthly_rent` (`float`): The monthly rent of the property.
-   **Returns**: `int` - The total aggregated viability score.
-   **Functionality**: This function serves as the public entry point to the scoring engine. It calls the private helper functions (`_calculate_financial_score`, `_calculate_employment_score`, `_calculate_household_score`), sums their results, and returns the final integer score.

---

## 4. Reporting Module

This module is responsible for generating system reports. Its separation from the core system logic ensures a clean division of concerns.

#### `generate_daily_report(applications)`
Generates a formatted string report of all pending and approved applications. This fulfills **Functional Requirement FR4**.

-   **Parameters**:
    -   `applications` (`Sequence[Application]`): A sequence of all `Application` objects in the system.
-   **Returns**: `str` - A multi-line string containing the formatted daily report.
-   **Report Content**:
    -   Report title and current date.
    -   A section for "APPROVED APPLICATIONS", listing applicant ID, name, and viability score.
    -   A section for "PENDING APPLICATIONS", listing applicant ID, name, and submission date.

---

## 5. Core Application System

The `HousingAllocationSystem` class is the central orchestrator of the application. It manages the application state in memory, fulfilling **Non-Functional Requirement NFR1**.

### `class HousingAllocationSystem`

Manages the housing allocation process from application submission to final decision and reporting.

#### Class Attributes
-   **`APPROVE_THRESHOLD`** (`int`): Score threshold (inclusive) above which an application is approved. Default: `80`.
-   **`WAITLIST_THRESHOLD`** (`int`): Score threshold (inclusive) above which a non-approved application is waitlisted. Default: `65`.

#### `__init__(self, target_monthly_rent=2000.0)`
Initializes the housing allocation system.

-   **Parameters**:
    -   `target_monthly_rent` (`float`, optional): The target monthly rent used for scoring calculations. Defaults to `2000.0`.
-   **Internal State**:
    -   `self._applications` (`Dict[str, Application]`): An in-memory dictionary to store all applications, keyed by `applicant_id`.
    -   `self._applicant_counter` (`int`): A simple counter to generate unique applicant IDs.
    -   `self.target_monthly_rent` (`float`): Stores the target rent for the system instance.

#### `submit_application(self, applicant_profile)`
Creates and stores a new `Application` from a dictionary of applicant data.

-   **Parameters**:
    -   `applicant_profile` (`Dict[str, Any]`): A dictionary containing all necessary data to create an `Applicant` object.
-   **Returns**: `str` - The unique `applicant_id` of the newly created application on success, or an empty string (`""`) on failure (e.g., due to missing or invalid data).

#### `process_applications(self)`
Processes all applications with a `PENDING` status. This method fulfills **Functional Requirement FR3**.

-   **Parameters**: None.
-   **Returns**: None.
-   **Functionality**:
    1.  Iterates through all applications in `self._applications`.
    2.  For each `PENDING` application, it calls `calculate_viability_score`.
    3.  The application's `viability_score` is updated with the result.
    4.  The application's `status` is updated to `APPROVED`, `WAITLISTED`, or `DENIED` based on the score and the class-level thresholds (`APPROVE_THRESHOLD`, `WAITLIST_THRESHOLD`).

#### `get_daily_report(self)`
Retrieves the daily report by delegating to the reporting module.

-   **Parameters**: None.
-   **Returns**: `str` - The formatted daily report string generated by `generate_daily_report`.

#### `get_all_application_details(self)`
A helper method to get a formatted string showing the status of every application in the system.

-   **Parameters**: None.
-   **Returns**: `str` - A multi-line string detailing the ID, name, score, and status of all applications, sorted by ID. Useful for demonstration and debugging.