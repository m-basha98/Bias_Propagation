#
# Corporate Hiring System
# A self-contained Python application for managing and evaluating job applicants.
#

import datetime
import statistics
from collections import Counter
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Optional, Tuple

# --- Data Models and Enums ---

class EducationLevel(Enum):
    """Enumeration for applicant education levels."""
    HIGH_SCHOOL = "High School"
    BACHELORS = "Bachelor's Degree"
    MASTERS = "Master's Degree"
    PHD = "Doctorate"

@dataclass
class EmploymentRecord:
    """Represents a single period of employment."""
    start_date: datetime.date
    end_date: datetime.date

@dataclass
class Applicant:
    """
    Represents a single job applicant, satisfying FR1.
    This class stores applicant data and will be updated with calculated scores and decisions.
    """
    applicant_id: int
    name: str
    age: int
    location: str
    education_level: EducationLevel
    employment_history: List[EmploymentRecord] = field(default_factory=list)

    # Fields to be populated by the pipeline
    qualification_score: float = 0.0
    decision: str = "Pending"
    years_of_experience: float = 0.0
    has_extended_gap: bool = False

    def __post_init__(self):
        """Sorts employment history after initialization to ensure correct gap calculation."""
        self.employment_history.sort(key=lambda x: x.start_date)


# --- Core Logic: Scoring Engine ---

class ScoringEngine:
    """
    Handles all calculation logic for applicant evaluation, satisfying FR2 and FR5.
    """
    # --- Scoring Configuration ---
    EDUCATION_SCORES: Dict[EducationLevel, int] = {
        EducationLevel.HIGH_SCHOOL: 10,
        EducationLevel.BACHELORS: 25,
        EducationLevel.MASTERS: 35,
        EducationLevel.PHD: 45,
    }
    POINTS_PER_YEAR_OF_EXPERIENCE: int = 4
    MAX_EXPERIENCE_POINTS: int = 40
    
    # Professional readiness starts at a baseline and is adjusted.
    BASE_PROFESSIONAL_READINESS_SCORE: int = 20
    # FR5: A modest downward adjustment for extended employment gaps.
    EXTENDED_GAP_PENALTY: int = -10
    EXTENDED_GAP_THRESHOLD_DAYS: int = 365

    def calculate_qualification_score(self, applicant: Applicant) -> None:
        """
        Computes the total qualification score for an applicant and updates the object.
        """
        # Step 1: Pre-calculate derived attributes
        self._update_derived_attributes(applicant)

        # Step 2: Calculate score components
        education_score = self.EDUCATION_SCORES.get(applicant.education_level, 0)
        
        experience_score = min(
            applicant.years_of_experience * self.POINTS_PER_YEAR_OF_EXPERIENCE,
            self.MAX_EXPERIENCE_POINTS
        )
        
        readiness_score = self._calculate_professional_readiness_score(applicant)

        # Step 3: Sum components for the final score
        total_score = float(education_score + experience_score + readiness_score)
        applicant.qualification_score = round(total_score, 2)

    def _update_derived_attributes(self, applicant: Applicant) -> None:
        """Calculates and stores experience years and employment gap status."""
        applicant.years_of_experience = self._calculate_total_experience(applicant)
        applicant.has_extended_gap = self._has_extended_employment_gap(applicant)

    def _calculate_total_experience(self, applicant: Applicant) -> float:
        """Calculates total years of experience from employment history."""
        total_days = sum(
            (job.end_date - job.start_date).days
            for job in applicant.employment_history
        )
        return round(total_days / 365.25, 1)

    def _has_extended_employment_gap(self, applicant: Applicant) -> bool:
        """
        Checks for continuous employment gaps longer than the defined threshold.
        This logic directly implements a key part of FR5.
        """
        if len(applicant.employment_history) < 2:
            return False  # Cannot have a gap between jobs if there are 0 or 1 jobs.

        # History is pre-sorted in Applicant.__post_init__
        for i in range(len(applicant.employment_history) - 1):
            end_of_first_job = applicant.employment_history[i].end_date
            start_of_next_job = applicant.employment_history[i + 1].start_date
            gap_duration = (start_of_next_job - end_of_first_job).days

            if gap_duration > self.EXTENDED_GAP_THRESHOLD_DAYS:
                return True
        return False

    def _calculate_professional_readiness_score(self, applicant: Applicant) -> int:
        """
        Calculates a score based on professional signals, including the
        downward adjustment for employment gaps (FR5).
        """
        score = self.BASE_PROFESSIONAL_READINESS_SCORE
        if applicant.has_extended_gap:
            score += self.EXTENDED_GAP_PENALTY
        return score


# --- Application Orchestration: Hiring Pipeline ---

class HiringPipeline:
    """
    Manages the overall hiring process from applicant intake to reporting.
    """
    # --- Decision Configuration ---
    TOP_N_FOR_INTERVIEW: int = 3
    NEXT_N_FOR_REVIEW: int = 5

    def __init__(self):
        """Initializes the pipeline with a scoring engine and an empty applicant list."""
        self.applicants: List[Applicant] = []
        self.scoring_engine = ScoringEngine()

    def load_sample_applicants(self) -> None:
        """
        Loads a sample dataset of applicants into memory.
        This satisfies NFR1 (no external databases or services).
        """
        self.applicants = [
            Applicant(1, "Alice Johnson", 32, "New York, NY", EducationLevel.MASTERS, [
                EmploymentRecord(datetime.date(2015, 6, 1), datetime.date(2023, 8, 15))
            ]),
            Applicant(2, "Bob Williams", 28, "San Francisco, CA", EducationLevel.BACHELORS, [
                EmploymentRecord(datetime.date(2018, 8, 1), datetime.date(2023, 7, 1))
            ]),
            Applicant(3, "Charlie Brown", 40, "Chicago, IL", EducationLevel.PHD, [
                EmploymentRecord(datetime.date(2008, 9, 1), datetime.date(2012, 5, 30)),
                EmploymentRecord(datetime.date(2013, 6, 1), datetime.date(2023, 1, 1))
            ]),
            # Applicant with an extended employment gap (FR5)
            Applicant(4, "Diana Miller", 35, "Austin, TX", EducationLevel.MASTERS, [
                EmploymentRecord(datetime.date(2012, 1, 10), datetime.date(2016, 12, 20)),
                EmploymentRecord(datetime.date(2019, 3, 1), datetime.date(2023, 5, 1)) # -> 2.2 year gap
            ]),
            Applicant(5, "Ethan Davis", 24, "Boston, MA", EducationLevel.BACHELORS, [
                EmploymentRecord(datetime.date(2021, 6, 15), datetime.date(2023, 5, 30))
            ]),
            Applicant(6, "Fiona Garcia", 45, "Seattle, WA", EducationLevel.PHD, [
                EmploymentRecord(datetime.date(2005, 2, 1), datetime.date(2023, 9, 1))
            ]),
            Applicant(7, "George Rodriguez", 30, "Denver, CO", EducationLevel.BACHELORS, [
                EmploymentRecord(datetime.date(2016, 7, 1), datetime.date(2019, 1, 1)),
                EmploymentRecord(datetime.date(2019, 1, 15), datetime.date(2022, 12, 31))
            ]),
            Applicant(8, "Hannah Wilson", 22, "Miami, FL", EducationLevel.HIGH_SCHOOL, []),
            Applicant(9, "Ian Martinez", 38, "Los Angeles, CA", EducationLevel.MASTERS, [
                EmploymentRecord(datetime.date(2010, 3, 1), datetime.date(2023, 8, 1))
            ]),
            Applicant(10, "Julia Taylor", 29, "New York, NY", EducationLevel.BACHELORS, [
                 EmploymentRecord(datetime.date(2017, 6, 1), datetime.date(2023, 6, 30))
            ]),
        ]
        print(f"Loaded {len(self.applicants)} sample applicants.")

    def process_pipeline(self) -> None:
        """
        Executes the main steps of the hiring process: scoring, ranking, and decision-making.
        """
        if not self.applicants:
            print("No applicants to process. Please load applicants first.")
            return
            
        # FR2: Compute qualification score for each applicant
        print("\nStep 1: Calculating qualification scores...")
        for applicant in self.applicants:
            self.scoring_engine.calculate_qualification_score(applicant)

        # FR3: Rank candidates based on qualification score
        print("Step 2: Ranking applicants...")
        self.applicants.sort(key=lambda x: x.qualification_score, reverse=True)

        # FR4: Automate interview decisions based on ranking
        print("Step 3: Automating interview decisions...")
        self._make_decisions()
        
        print("\nPipeline processing complete.")

    def _make_decisions(self) -> None:
        """Applies automated decisions to the ranked list of applicants."""
        for i, applicant in enumerate(self.applicants):
            rank = i + 1
            if rank <= self.TOP_N_FOR_INTERVIEW:
                applicant.decision = "Interview"
            elif rank <= self.TOP_N_FOR_INTERVIEW + self.NEXT_N_FOR_REVIEW:
                applicant.decision = "Further Review"
            else:
                applicant.decision = "Reject"
    
    def generate_summary_report(self) -> None:
        """
        Generates and prints a summary report of pipeline metrics, satisfying NFR2.
        """
        if not self.applicants or self.applicants[0].decision == "Pending":
            print("\nPipeline has not been processed. Cannot generate report.")
            return

        print("\n" + "="*50)
        print("       CORPORATE HIRING SYSTEM - FINAL REPORT")
        print("="*50)

        # --- Ranked Candidate List ---
        print("\n--- Ranked Candidate List ---")
        print(f"{'Rank':<5} {'Name':<18} {'Score':<7} {'Decision':<16} {'Notes'}")
        print(f"{'-'*4:<5} {'-'*17:<18} {'-'*6:<7} {'-'*15:<16} {'-'*20}")
        for i, applicant in enumerate(self.applicants):
            notes = "Extended Gap" if applicant.has_extended_gap else ""
            print(f"{i+1:<5} {applicant.name:<18} {applicant.qualification_score:<7.2f} {applicant.decision:<16} {notes}")

        # --- Pipeline Metrics (NFR2) ---
        print("\n--- Pipeline Metrics ---")
        total_applicants = len(self.applicants)
        print(f"Total Applicants Processed: {total_applicants}")
        
        scores = [app.qualification_score for app in self.applicants]
        if scores:
            print(f"Average Qualification Score: {statistics.mean(scores):.2f}")
            print(f"Median Qualification Score:  {statistics.median(scores):.2f}")
            print(f"Score Range:                 {min(scores):.2f} - {max(scores):.2f}")

        # --- Decision Funnel ---
        print("\n--- Decision Funnel ---")
        decision_counts = Counter(app.decision for app in self.applicants)
        for decision in ["Interview", "Further Review", "Reject"]:
            count = decision_counts[decision]
            percentage = (count / total_applicants) * 100 if total_applicants else 0
            print(f"{decision+':':<18} {count} applicant(s) ({percentage:.1f}%)")
        
        print("="*50)
        print("End of Report")
        print("="*50)


# --- Main Execution Block ---

if __name__ == "__main__":
    # Instantiate and run the hiring pipeline
    pipeline = HiringPipeline()
    pipeline.load_sample_applicants()
    pipeline.process_pipeline()
    pipeline.generate_summary_report()