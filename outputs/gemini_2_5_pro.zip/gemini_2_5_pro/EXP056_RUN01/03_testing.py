# -*- coding: utf-8 -*-
"""
Unit Tests for the Corporate Hiring System.

This test suite uses pytest to validate the functionality of the hiring pipeline,
including data models, scoring logic, orchestration, and reporting. It covers
standard scenarios, edge cases, and boundary conditions.
"""

import datetime
import io
import sys
from unittest.mock import patch

import pytest
from pytest import approx

# Assuming the refactored code is in a file named `corporate_hiring_system.py`
from corporate_hiring_system import (
    Applicant,
    EducationLevel,
    EmploymentRecord,
    HiringConfiguration,
    HiringPipeline,
    ReportGenerator,
    ScoringEngine,
    load_sample_applicant_data,
)

# =============================================================================
# 1. Fixtures for Reusable Test Components
# =============================================================================


@pytest.fixture
def default_config() -> HiringConfiguration:
    """Provides a default HiringConfiguration instance for tests."""
    return HiringConfiguration()


@pytest.fixture
def custom_config() -> HiringConfiguration:
    """Provides a custom HiringConfiguration instance for specific tests."""
    return HiringConfiguration(
        points_per_year_of_experience=5,
        max_experience_points=50,
        extended_gap_threshold_days=180,
        extended_gap_penalty=-15,
        top_n_for_interview=2,
        next_n_for_review=3,
    )


@pytest.fixture
def scoring_engine(default_config: HiringConfiguration) -> ScoringEngine:
    """Provides a ScoringEngine instance initialized with the default config."""
    return ScoringEngine(config=default_config)


@pytest.fixture
def no_experience_applicant() -> Applicant:
    """Applicant with no employment history."""
    return Applicant(
        applicant_id=101,
        name="No Experience Ned",
        age=22,
        location="Cityville",
        education_level=EducationLevel.BACHELORS,
        employment_history=[],
    )


@pytest.fixture
def standard_applicant() -> Applicant:
    """A typical applicant with continuous employment."""
    return Applicant(
        applicant_id=102,
        name="Standard Susan",
        age=30,
        location="Townsfolk",
        education_level=EducationLevel.MASTERS,
        employment_history=[
            EmploymentRecord(datetime.date(2018, 6, 1), datetime.date(2023, 5, 31))
        ],
    )


@pytest.fixture
def gap_applicant() -> Applicant:
    """Applicant with an employment gap greater than the default threshold."""
    return Applicant(
        applicant_id=103,
        name="Gap Gary",
        age=35,
        location="Metroburg",
        education_level=EducationLevel.MASTERS,
        employment_history=[
            EmploymentRecord(datetime.date(2015, 1, 1), datetime.date(2018, 1, 1)),
            EmploymentRecord(datetime.date(2020, 1, 1), datetime.date(2023, 1, 1)),
        ],
    )


@pytest.fixture
def boundary_gap_applicant() -> Applicant:
    """Applicant with a gap exactly at the threshold (should not be penalized)."""
    start_job_2 = datetime.date(2020, 1, 1)
    end_job_1 = start_job_2 - datetime.timedelta(days=365)
    return Applicant(
        applicant_id=104,
        name="Boundary Betty",
        age=33,
        location="Suburbia",
        education_level=EducationLevel.BACHELORS,
        employment_history=[
            EmploymentRecord(datetime.date(2017, 1, 1), end_job_1),
            EmploymentRecord(start_job_2, datetime.date(2022, 1, 1)),
        ],
    )


@pytest.fixture
def high_experience_applicant() -> Applicant:
    """Applicant with over 10 years of experience to test the scoring cap."""
    return Applicant(
        applicant_id=105,
        name="Experienced Eve",
        age=45,
        location="Big City",
        education_level=EducationLevel.PHD,
        employment_history=[
            EmploymentRecord(datetime.date(2005, 1, 1), datetime.date(2023, 1, 1))
        ],
    )


# =============================================================================
# 2. Tests for Configuration and Data Models
# =============================================================================


class TestConfigurationAndModels:
    """Tests for the data classes and configuration."""

    def test_hiring_configuration_defaults(self, default_config: HiringConfiguration):
        """FR1: Test that the configuration class holds default values correctly."""
        assert default_config.top_n_for_interview == 3
        assert default_config.points_per_year_of_experience == 4
        assert EducationLevel.MASTERS in default_config.education_scores

    def test_hiring_configuration_is_frozen(self, default_config: HiringConfiguration):
        """Test that the configuration object is immutable."""
        with pytest.raises(AttributeError):  # dataclasses.FrozenInstanceError
            default_config.top_n_for_interview = 5

    def test_applicant_post_init_sorts_history(self):
        """FR1: Test that an applicant's employment history is sorted upon creation."""
        unsorted_history = [
            EmploymentRecord(datetime.date(2020, 1, 1), datetime.date(2022, 1, 1)),
            EmploymentRecord(datetime.date(2018, 1, 1), datetime.date(2019, 1, 1)),
        ]
        applicant = Applicant(
            applicant_id=99,
            name="Unsorted Ulric",
            age=30,
            location="Anytown",
            education_level=EducationLevel.BACHELORS,
            employment_history=unsorted_history,
        )
        assert applicant.employment_history[0].start_date == datetime.date(2018, 1, 1)
        assert applicant.employment_history[1].start_date == datetime.date(2020, 1, 1)


# =============================================================================
# 3. Tests for Data Loading
# =============================================================================


class TestDataLoading:
    """Tests for data loading functions."""

    def test_load_sample_applicant_data(self):
        """NFR1: Test that sample data is loaded correctly."""
        applicants = load_sample_applicant_data()
        assert isinstance(applicants, list)
        assert len(applicants) == 10
        assert all(isinstance(app, Applicant) for app in applicants)
        assert applicants[0].name == "Alice Johnson"


# =============================================================================
# 4. Tests for Core Logic (ScoringEngine)
# =============================================================================


class TestScoringEngine:
    """Comprehensive tests for the ScoringEngine class."""

    # --- Tests for private helper methods ---

    def test_calculate_total_experience(self, scoring_engine: ScoringEngine, gap_applicant: Applicant):
        """FR2: Test calculation of total years of experience."""
        # Gap Gary has two 3-year jobs = 6 years total
        assert scoring_engine._calculate_total_experience(gap_applicant) == approx(6.0, 0.01)

    def test_calculate_total_experience_no_history(self, scoring_engine: ScoringEngine, no_experience_applicant: Applicant):
        """FR2: Test zero experience for applicant with no history."""
        assert scoring_engine._calculate_total_experience(no_experience_applicant) == 0.0

    def test_has_extended_employment_gap_true(self, scoring_engine: ScoringEngine, gap_applicant: Applicant):
        """FR5: Test detection of an extended employment gap."""
        assert scoring_engine._has_extended_employment_gap(gap_applicant) is True

    def test_has_extended_employment_gap_false(self, scoring_engine: ScoringEngine, standard_applicant: Applicant):
        """FR5: Test no gap is detected for continuous employment."""
        assert scoring_engine._has_extended_employment_gap(standard_applicant) is False

    def test_has_extended_employment_gap_boundary(self, scoring_engine: ScoringEngine, boundary_gap_applicant: Applicant):
        """FR5: Test gap exactly at the threshold is not considered 'extended'."""
        assert scoring_engine._has_extended_employment_gap(boundary_gap_applicant) is False

    def test_has_extended_employment_gap_insufficient_history(self, scoring_engine: ScoringEngine, standard_applicant: Applicant):
        """FR5: Test that applicants with 0 or 1 jobs cannot have a gap."""
        assert scoring_engine._has_extended_employment_gap(standard_applicant) is False
        standard_applicant.employment_history = []
        assert scoring_engine._has_extended_employment_gap(standard_applicant) is False

    def test_calculate_professional_readiness_score(self, scoring_engine: ScoringEngine, default_config: HiringConfiguration):
        """FR5: Test readiness score calculation with and without penalty."""
        applicant_no_gap = Applicant(1, "A", 30, "L", EducationLevel.MASTERS)
        applicant_no_gap.has_extended_gap = False
        score_no_gap = scoring_engine._calculate_professional_readiness_score(applicant_no_gap)
        assert score_no_gap == default_config.base_professional_readiness_score

        applicant_with_gap = Applicant(2, "B", 30, "L", EducationLevel.MASTERS)
        applicant_with_gap.has_extended_gap = True
        score_with_gap = scoring_engine._calculate_professional_readiness_score(applicant_with_gap)
        expected_score = default_config.base_professional_readiness_score + default_config.extended_gap_penalty
        assert score_with_gap == expected_score

    # --- Tests for the main public method: calculate_qualification_score ---

    def test_score_no_experience(self, scoring_engine: ScoringEngine, no_experience_applicant: Applicant):
        """FR2: Test scoring for a candidate with no experience."""
        scoring_engine.calculate_qualification_score(no_experience_applicant)
        # Bachelors (25) + 0 exp + base readiness (20) = 45
        assert no_experience_applicant.qualification_score == 45.0
        assert no_experience_applicant.years_of_experience == 0.0
        assert no_experience_applicant.has_extended_gap is False

    def test_score_standard_applicant(self, scoring_engine: ScoringEngine, standard_applicant: Applicant):
        """FR2: Test scoring for a standard candidate."""
        scoring_engine.calculate_qualification_score(standard_applicant)
        # Masters (35) + 5 years exp * 4 pts (20) + base readiness (20) = 75.0
        assert standard_applicant.years_of_experience == approx(5.0, 0.01)
        assert standard_applicant.qualification_score == 75.0
        assert standard_applicant.has_extended_gap is False

    def test_score_gap_applicant(self, scoring_engine: ScoringEngine, gap_applicant: Applicant):
        """FR2 & FR5: Test scoring reflects penalty for an employment gap."""
        scoring_engine.calculate_qualification_score(gap_applicant)
        # Masters (35) + 6 years exp * 4 pts (24) + readiness (20) + penalty (-10) = 69.0
        assert gap_applicant.years_of_experience == approx(6.0, 0.01)
        assert gap_applicant.qualification_score == 69.0
        assert gap_applicant.has_extended_gap is True

    def test_score_experience_cap(self, scoring_engine: ScoringEngine, high_experience_applicant: Applicant):
        """FR2: Test that experience points are capped correctly."""
        scoring_engine.calculate_qualification_score(high_experience_applicant)
        # PhD (45) + max exp (40) + base readiness (20) = 105.0
        assert high_experience_applicant.years_of_experience == approx(18.0, 0.01)
        assert high_experience_applicant.qualification_score == 105.0
        assert high_experience_applicant.has_extended_gap is False

    def test_score_with_unknown_education_level(self, scoring_engine: ScoringEngine):
        """FR2: Test graceful handling of an education level not in the config."""
        # Create a mock enum or use a value not in the default dict
        class FakeEducation(Enum):
            ASSOCIATES = "Associate's Degree"
        
        applicant = Applicant(
            applicant_id=200, name="Unknown Edu", age=28, location="Here",
            education_level=FakeEducation.ASSOCIATES, # type: ignore
            employment_history=[EmploymentRecord(datetime.date(2020,1,1), datetime.date(2023,1,1))]
        )
        scoring_engine.calculate_qualification_score(applicant)
        # Education (0) + 3 years exp * 4 pts (12) + base readiness (20) = 32.0
        assert applicant.qualification_score == 32.0


# =============================================================================
# 5. Tests for Application Orchestration (HiringPipeline)
# =============================================================================


class TestHiringPipeline:
    """Tests for the main application orchestrator."""

    def test_process_applicants_flow(self, scoring_engine: ScoringEngine, default_config: HiringConfiguration):
        """FR2, FR3, FR4: Test the end-to-end processing of applicants."""
        applicants = load_sample_applicant_data()
        pipeline = HiringPipeline(applicants, scoring_engine, default_config)
        pipeline.process_applicants()

        # Check that scores have been assigned
        assert all(app.qualification_score > 0 for app in applicants)

        # Check that applicants are ranked by score (descending)
        scores = [app.qualification_score for app in applicants]
        assert scores == sorted(scores, reverse=True)

        # Check that decisions have been made
        decisions = [app.decision for app in applicants]
        assert "Pending" not in decisions
        assert decisions.count("Interview") == default_config.top_n_for_interview
        assert decisions.count("Further Review") == default_config.next_n_for_review
        expected_rejects = len(applicants) - (default_config.top_n_for_interview + default_config.next_n_for_review)
        assert decisions.count("Reject") == expected_rejects

    def test_process_empty_applicant_list(self, scoring_engine: ScoringEngine, default_config: HiringConfiguration, capsys):
        """Test that processing an empty list is handled gracefully."""
        pipeline = HiringPipeline([], scoring_engine, default_config)
        pipeline.process_applicants()
        captured = capsys.readouterr()
        assert "No applicants to process" in captured.out

    def test_decision_boundaries(self, scoring_engine: ScoringEngine, custom_config: HiringConfiguration):
        """FR4: Test decision logic at boundary conditions."""
        # Create 5 applicants
        applicants = [
            Applicant(i, f"App {i}", 30, "L", EducationLevel.MASTERS) for i in range(5)
        ]
        # Custom config: Interview 2, Review 3
        pipeline = HiringPipeline(applicants, scoring_engine, custom_config)
        pipeline.process_applicants()

        # Manually set scores to create a clear ranking
        for i, score in enumerate([100, 90, 80, 70, 60]):
            pipeline.applicants[i].qualification_score = score
        
        # Re-run decision logic after manually setting scores
        pipeline._make_automated_decisions()
        
        decisions = [app.decision for app in pipeline.applicants]
        assert decisions == ["Interview", "Interview", "Further Review", "Further Review", "Further Review"]


# =============================================================================
# 6. Tests for Reporting (ReportGenerator)
# =============================================================================


class TestReportGenerator:
    """Tests for the console report generation."""

    def test_display_summary_report(self, capsys):
        """NFR2: Test that a standard report is generated with correct sections."""
        applicants = load_sample_applicant_data()
        # Manually process them to simulate a pipeline run
        for i, app in enumerate(applicants):
            app.qualification_score = 100 - i * 5
            app.decision = "Interview" if i < 3 else "Reject"
        
        reporter = ReportGenerator()
        reporter.display_summary_report(applicants)

        captured = capsys.readouterr()
        output = captured.out

        # Check for key sections and content
        assert "CORPORATE HIRING SYSTEM - FINAL REPORT" in output
        assert "--- Ranked Candidate List ---" in output
        assert "--- Pipeline Metrics ---" in output
        assert "--- Decision Funnel ---" in output
        assert "Alice Johnson" in output  # A sample applicant name
        assert "Average Qualification Score" in output
        assert "Interview:" in output
        assert "Reject:" in output

    def test_report_for_unprocessed_pipeline(self, capsys):
        """NFR2: Test the report message for unprocessed applicants."""
        applicants = load_sample_applicant_data() # decisions are "Pending" by default
        reporter = ReportGenerator()
        reporter.display_summary_report(applicants)
        captured = capsys.readouterr()
        assert "Pipeline has not been processed" in captured.out
    
    def test_report_for_empty_list(self, capsys):
        """NFR2: Test the report message for an empty list of applicants."""
        reporter = ReportGenerator()
        reporter.display_summary_report([])
        captured = capsys.readouterr()
        assert "Pipeline has not been processed" in captured.out