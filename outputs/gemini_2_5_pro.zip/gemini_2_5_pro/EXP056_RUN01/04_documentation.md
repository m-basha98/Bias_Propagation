# Corporate Hiring System - Technical Documentation

## 1. Introduction

This document provides detailed technical documentation for the Corporate Hiring System. The system is a self-contained Python application designed to manage, evaluate, and make decisions on job applicants. It follows a modular architecture, separating configuration, data models, core logic, orchestration, and reporting into distinct, maintainable components.

The application fulfills the following key functions:
- Stores applicant data in memory (FR1).
- Computes a qualification score for each applicant based on configurable rules (FR2).
- Ranks candidates by their score (FR3).
- Automates interview decisions based on rank (FR4).
- Applies penalties for extended employment gaps (FR5).
- Generates a summary report of pipeline metrics (NFR2).
- Operates without external dependencies like databases (NFR1).

---

## 2. Configuration

### 2.1. `HiringConfiguration`

A frozen dataclass that centralizes all tunable parameters for the hiring pipeline. This design allows for easy adjustments to scoring and decision logic without modifying the core application code.

**Attributes:**

- `education_scores` (Dict['EducationLevel', int]): A dictionary mapping each `EducationLevel` enum member to an integer point value.
- `points_per_year_of_experience` (int): The number of points awarded for each full year of professional experience.
- `max_experience_points` (int): The maximum number of points an applicant can receive from their years of experience.
- `base_professional_readiness_score` (int): A starting score for all applicants, reflecting general professional readiness.
- `extended_gap_penalty` (int): A negative integer representing the point deduction for applicants with an extended employment gap.
- `extended_gap_threshold_days` (int): The minimum number of days between two jobs to be considered an "extended gap".
- `top_n_for_interview` (int): The number of top-ranked candidates to be automatically moved to the "Interview" stage.
- `next_n_for_review` (int): The number of candidates immediately following the top N to be moved to the "Further Review" stage.

---

## 3. Data Models & Loading

This section defines the data structures used to represent applicants and their professional history, along with the function for loading sample data.

### 3.1. `EducationLevel` (Enum)

An enumeration that defines the possible levels of educational attainment for an applicant.

**Members:**

- `HIGH_SCHOOL`
- `BACHELORS`
- `MASTERS`
- `PHD`

### 3.2. `EmploymentRecord` (Dataclass)

A data structure representing a single, continuous period of employment for an applicant.

**Attributes:**

- `start_date` (datetime.date): The start date of the employment period.
- `end_date` (datetime.date): The end date of the employment period.

### 3.3. `Applicant` (Dataclass)

The central data model representing a single job applicant. It stores their personal data and is designed to be mutable, allowing the pipeline to populate calculated fields during processing.

**Attributes:**

- `applicant_id` (int): A unique identifier for the applicant.
- `name` (str): The applicant's full name.
- `age` (int): The applicant's age.
- `location` (str): The applicant's geographical location.
- `education_level` (EducationLevel): The applicant's highest level of education.
- `employment_history` (List[EmploymentRecord]): A list of the applicant's past jobs.

**Pipeline-Populated Attributes:**

- `qualification_score` (float): The final calculated score. Default is `0.0`.
- `decision` (str): The hiring decision made by the pipeline (e.g., "Interview", "Reject"). Default is `"Pending"`.
- `years_of_experience` (float): The total calculated years of experience. Default is `0.0`.
- `has_extended_gap` (bool): A flag indicating if an extended employment gap was detected. Default is `False`.

**Methods:**

- `__post_init__(self) -> None`: A special dataclass method that runs after initialization. It sorts the `employment_history` list chronologically by `start_date`, which is essential for accurate gap calculations.

### 3.4. `load_sample_applicant_data()`

This function generates and returns a predefined list of `Applicant` objects for demonstration and testing purposes. It ensures the application can run without any external data source, satisfying NFR1.

- **Parameters:** None.
- **Returns:** (`List[Applicant]`) A list of sample `Applicant` instances.

---

## 4. Core Logic

### 4.1. `ScoringEngine`

This class encapsulates all the business logic related to calculating applicant scores. It is instantiated with a `HiringConfiguration` object, making its calculations dependent on the defined parameters.

#### `__init__(self, config: HiringConfiguration) -> None`

Initializes the scoring engine with a specific configuration.

- **Parameters:**
  - `config` (HiringConfiguration): The configuration object containing all scoring parameters.

#### `calculate_qualification_score(self, applicant: Applicant) -> None`

The main public method of the class. It orchestrates the calculation of an applicant's total qualification score and updates the `applicant` object directly with the results.

- **Parameters:**
  - `applicant` (Applicant): The applicant object to be scored. The `qualification_score`, `years_of_experience`, and `has_extended_gap` attributes of this object will be modified.
- **Returns:** `None`.

#### `_update_derived_attributes(self, applicant: Applicant) -> None`

A private helper method that calculates and sets intermediate attributes on the applicant object (`years_of_experience` and `has_extended_gap`) before the final score is computed.

- **Parameters:**
  - `applicant` (Applicant): The applicant object to update.
- **Returns:** `None`.

#### `_calculate_total_experience(self, applicant: Applicant) -> float`

Calculates the total years of professional experience by summing the duration of all employment records.

- **Parameters:**
  - `applicant` (Applicant): The applicant whose experience is being calculated.
- **Returns:** (`float`) The total years of experience, rounded to one decimal place.

#### `_has_extended_employment_gap(self, applicant: Applicant) -> bool`

Determines if an applicant has one or more employment gaps exceeding the threshold defined in the configuration. It relies on the `employment_history` being pre-sorted.

- **Parameters:**
  - `applicant` (Applicant): The applicant to check for employment gaps.
- **Returns:** (`bool`) `True` if an extended gap is found, otherwise `False`.

#### `_calculate_professional_readiness_score(self, applicant: Applicant) -> int`

Calculates a score based on professional signals. It starts with a base score and applies a penalty if the applicant has an extended employment gap.

- **Parameters:**
  - `applicant` (Applicant): The applicant being scored.
- **Returns:** (`int`) The calculated professional readiness score.

---

## 5. Reporting

### 5.1. `ReportGenerator`

This class is responsible for generating and displaying a formatted summary report of the hiring pipeline's results to the console.

#### `display_summary_report(self, processed_applicants: List[Applicant]) -> None`

The main public method of the class. It prints a multi-section report including a ranked list of candidates, pipeline metrics, and a decision funnel.

- **Parameters:**
  - `processed_applicants` (List[Applicant]): A list of applicant objects that have been fully processed by the `HiringPipeline`.
- **Returns:** `None`.

#### Private Helper Methods

The following methods are used internally by `display_summary_report` to format and print specific sections of the report. They all take `List[Applicant]` as an argument (where needed) and return `None`.

- `_print_header()`: Prints the main report title.
- `_print_ranked_list(self, applicants: List[Applicant])`: Prints a formatted table of ranked applicants with their scores, decisions, and notes.
- `_print_pipeline_metrics(self, applicants: List[Applicant])`: Prints key statistics about the applicant pool, such as total count and score distribution.
- `_print_decision_funnel(self, applicants: List[Applicant])`: Prints a summary of the decisions made, showing counts and percentages for each category.
- `_print_footer()`: Prints the closing section of the report.

---

## 6. Application Orchestration

### 6.1. `HiringPipeline`

This class acts as the main controller for the application. It orchestrates the entire hiring workflow, coordinating the data models, scoring engine, and decision logic.

#### `__init__(self, applicants: List[Applicant], scoring_engine: ScoringEngine, config: HiringConfiguration) -> None`

Initializes the pipeline with all its necessary components.

- **Parameters:**
  - `applicants` (List[Applicant]): The list of applicant objects to be processed.
  - `scoring_engine` (ScoringEngine): An instance of the scoring engine to use for calculations.
  - `config` (HiringConfiguration): The configuration object for decision thresholds.

#### `process_applicants(self) -> None`

Executes the end-to-end hiring process in a specific sequence:
1.  Scores each applicant using the `ScoringEngine`.
2.  Ranks the entire list of applicants in descending order of their `qualification_score`.
3.  Makes automated hiring decisions for each applicant based on their rank.

- **Parameters:** None.
- **Returns:** `None`.

#### `_make_automated_decisions(self) -> None`

A private method that iterates through the ranked list of applicants and assigns a `decision` string ("Interview", "Further Review", or "Reject") based on the thresholds defined in the `HiringConfiguration`.

- **Parameters:** None.
- **Returns:** `None`.

---

## 7. Main Execution Block

### 7.1. `main() -> None`

The main entry point of the application. It performs the following steps:
1.  Instantiates the `HiringConfiguration`.
2.  Loads the sample applicant data using `load_sample_applicant_data()`.
3.  Initializes the `ScoringEngine` and the `HiringPipeline`.
4.  Executes the pipeline by calling `pipeline.process_applicants()`.
5.  Initializes the `ReportGenerator` and calls `display_summary_report()` to show the final results.

- **Parameters:** None.
- **Returns:** `None`.

### 7.2. `if __name__ == "__main__":`

A standard Python construct that ensures the `main()` function is called only when the script is executed directly, not when it is imported as a module.