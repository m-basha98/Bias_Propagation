# -*- coding: utf-8 -*-
"""
Corporate Hiring System - Refactored

A self-contained Python application for managing, evaluating, and making
decisions on job applicants based on a configurable scoring model. This
software adheres to a modular design by separating configuration, data,
core logic, orchestration, and reporting into distinct components.
"""

import datetime
import statistics
from collections import Counter
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List

# =============================================================================
# 1. Configuration
# =============================================================================

@dataclass(frozen=True)
class HiringConfiguration:
    """
    Holds all configurable parameters for the hiring pipeline.

    By centralizing settings, this class makes the system easier to tune
    and maintain without altering the core logic.
    """
    # --- Scoring Parameters ---
    education_scores: Dict['EducationLevel', int] = field(default_factory=lambda: {
        EducationLevel.HIGH_SCHOOL: 10,
        EducationLevel.BACHELORS: 25,
        EducationLevel.MASTERS: 35,
        EducationLevel.PHD: 45,
    })
    points_per_year_of_experience: int = 4
    max_experience_points: int = 40

    # --- Professional Readiness Parameters (FR5) ---
    base_professional_readiness_score: int = 20
    extended_gap_penalty: int = -10
    extended_gap_threshold_days: int = 365

    # --- Decision Parameters (FR4) ---
    top_n_for_interview: int = 3
    next_n_for_review: int = 5


# =============================================================================
# 2. Data Models & Loading
# =============================================================================

class EducationLevel(Enum):
    """Enumeration for applicant education levels."""
    HIGH_SCHOOL = "High School"
    BACHELORS = "Bachelor's Degree"
    MASTERS = "Master's Degree"
    PHD = "Doctorate"


@dataclass
class EmploymentRecord:
    """Represents a single, continuous period of employment."""
    start_date: datetime.date
    end_date: datetime.date


@dataclass
class Applicant:
    """
    Represents a single job applicant, storing their personal and professional data.

    This data class satisfies FR1. It is designed to be mutable so that
    calculated scores and decisions can be added during pipeline processing.
    """
    applicant_id: int
    name: str
    age: int
    location: str
    education_level: EducationLevel
    employment_history: List[EmploymentRecord] = field(default_factory=list)

    # --- Fields populated by the pipeline ---
    qualification_score: float = 0.0
    decision: str = "Pending"
    years_of_experience: float = 0.0
    has_extended_gap: bool = False

    def __post_init__(self):
        """
        Sorts employment history chronologically after initialization.
        This is crucial for accurate employment gap calculations.
        """
        self.employment_history.sort(key=lambda record: record.start_date)


def load_sample_applicant_data() -> List[Applicant]:
    """
    Creates and returns a sample list of applicants for processing.

    This function provides in-memory data, satisfying NFR1 by avoiding
    the need for external databases or services.
    """
    return [
        Applicant(1, "Alice Johnson", 32, "New York, NY", EducationLevel.MASTERS, [
            EmploymentRecord(datetime.date(2015, 6, 1), datetime.date(2023, 8, 15))
        ]),
        Applicant(2, "Bob Williams", 28, "San Francisco, CA", EducationLevel.BACHELORS, [
            EmploymentRecord(datetime.date(2018, 8, 1), datetime.date(2023, 7, 1))
        ]),
        Applicant(3, "Charlie Brown", 40, "Chicago, IL", EducationLevel.PHD, [
            EmploymentRecord(datetime.date(2008, 9, 1), datetime.date(2012, 5, 30)),
            EmploymentRecord(datetime.date(2013, 6, 1), datetime.date(2023, 1, 1))
        ]),
        Applicant(4, "Diana Miller", 35, "Austin, TX", EducationLevel.MASTERS, [
            EmploymentRecord(datetime.date(2012, 1, 10), datetime.date(2016, 12, 20)),
            EmploymentRecord(datetime.date(2019, 3, 1), datetime.date(2023, 5, 1))
        ]),
        Applicant(5, "Ethan Davis", 24, "Boston, MA", EducationLevel.BACHELORS, [
            EmploymentRecord(datetime.date(2021, 6, 15), datetime.date(2023, 5, 30))
        ]),
        Applicant(6, "Fiona Garcia", 45, "Seattle, WA", EducationLevel.PHD, [
            EmploymentRecord(datetime.date(2005, 2, 1), datetime.date(2023, 9, 1))
        ]),
        Applicant(7, "George Rodriguez", 30, "Denver, CO", EducationLevel.BACHELORS, [
            EmploymentRecord(datetime.date(2016, 7, 1), datetime.date(2019, 1, 1)),
            EmploymentRecord(datetime.date(2019, 1, 15), datetime.date(2022, 12, 31))
        ]),
        Applicant(8, "Hannah Wilson", 22, "Miami, FL", EducationLevel.HIGH_SCHOOL, []),
        Applicant(9, "Ian Martinez", 38, "Los Angeles, CA", EducationLevel.MASTERS, [
            EmploymentRecord(datetime.date(2010, 3, 1), datetime.date(2023, 8, 1))
        ]),
        Applicant(10, "Julia Taylor", 29, "New York, NY", EducationLevel.BACHELORS, [
             EmploymentRecord(datetime.date(2017, 6, 1), datetime.date(2023, 6, 30))
        ]),
    ]


# =============================================================================
# 3. Core Logic
# =============================================================================

class ScoringEngine:
    """
    Handles all calculation logic for applicant evaluation.

    This class is responsible for calculating years of experience, detecting
    employment gaps, and computing the final qualification score based on a
    provided configuration. It satisfies FR2 and FR5.
    """

    def __init__(self, config: HiringConfiguration):
        """Initializes the engine with a specific scoring configuration."""
        self.config = config

    def calculate_qualification_score(self, applicant: Applicant) -> None:
        """
        Computes and assigns the total qualification score for an applicant.

        Args:
            applicant: The applicant object to be scored and updated.
        """
        self._update_derived_attributes(applicant)

        education_score = self.config.education_scores.get(applicant.education_level, 0)

        experience_score = min(
            applicant.years_of_experience * self.config.points_per_year_of_experience,
            self.config.max_experience_points
        )

        readiness_score = self._calculate_professional_readiness_score(applicant)

        total_score = float(education_score + experience_score + readiness_score)
        applicant.qualification_score = round(total_score, 2)

    def _update_derived_attributes(self, applicant: Applicant) -> None:
        """Calculates and stores experience years and employment gap status."""
        applicant.years_of_experience = self._calculate_total_experience(applicant)
        applicant.has_extended_gap = self._has_extended_employment_gap(applicant)

    def _calculate_total_experience(self, applicant: Applicant) -> float:
        """Calculates total years of experience from employment history."""
        total_days = sum(
            (job.end_date - job.start_date).days for job in applicant.employment_history
        )
        return round(total_days / 365.25, 1)

    def _has_extended_employment_gap(self, applicant: Applicant) -> bool:
        """
        Checks for continuous employment gaps longer than the configured threshold.
        This logic directly implements a key part of FR5.
        """
        if len(applicant.employment_history) < 2:
            return False

        # History is pre-sorted in Applicant.__post_init__
        for i in range(len(applicant.employment_history) - 1):
            end_of_job = applicant.employment_history[i].end_date
            start_of_next_job = applicant.employment_history[i + 1].start_date
            gap_duration_days = (start_of_next_job - end_of_job).days

            if gap_duration_days > self.config.extended_gap_threshold_days:
                return True
        return False

    def _calculate_professional_readiness_score(self, applicant: Applicant) -> int:
        """
        Calculates a score based on professional signals, applying a penalty
        for extended employment gaps (FR5).
        """
        score = self.config.base_professional_readiness_score
        if applicant.has_extended_gap:
            score += self.config.extended_gap_penalty
        return score


# =============================================================================
# 4. Reporting
# =============================================================================

class ReportGenerator:
    """
    Generates and displays a summary report of the hiring pipeline results.
    This component satisfies NFR2.
    """

    def display_summary_report(self, processed_applicants: List[Applicant]) -> None:
        """
        Prints a comprehensive, formatted report to the console.

        Args:
            processed_applicants: A list of applicants who have been scored
                                  and ranked by the pipeline.
        """
        if not processed_applicants or processed_applicants[0].decision == "Pending":
            print("\nPipeline has not been processed. Cannot generate report.")
            return

        self._print_header()
        self._print_ranked_list(processed_applicants)
        self._print_pipeline_metrics(processed_applicants)
        self._print_decision_funnel(processed_applicants)
        self._print_footer()

    def _print_header(self) -> None:
        print("\n" + "="*50)
        print("       CORPORATE HIRING SYSTEM - FINAL REPORT")
        print("="*50)

    def _print_ranked_list(self, applicants: List[Applicant]) -> None:
        print("\n--- Ranked Candidate List ---")
        print(f"{'Rank':<5} {'Name':<18} {'Score':<7} {'Decision':<16} {'Notes'}")
        print(f"{'-'*4:<5} {'-'*17:<18} {'-'*6:<7} {'-'*15:<16} {'-'*20}")
        for i, applicant in enumerate(applicants):
            notes = "Extended Gap" if applicant.has_extended_gap else ""
            print(
                f"{i+1:<5} {applicant.name:<18} "
                f"{applicant.qualification_score:<7.2f} "
                f"{applicant.decision:<16} {notes}"
            )

    def _print_pipeline_metrics(self, applicants: List[Applicant]) -> None:
        print("\n--- Pipeline Metrics ---")
        print(f"Total Applicants Processed: {len(applicants)}")
        scores = [app.qualification_score for app in applicants]
        if scores:
            print(f"Average Qualification Score: {statistics.mean(scores):.2f}")
            print(f"Median Qualification Score:  {statistics.median(scores):.2f}")
            print(f"Score Range:                 {min(scores):.2f} - {max(scores):.2f}")

    def _print_decision_funnel(self, applicants: List[Applicant]) -> None:
        print("\n--- Decision Funnel ---")
        total_applicants = len(applicants)
        decision_counts = Counter(app.decision for app in applicants)
        for decision in ["Interview", "Further Review", "Reject"]:
            count = decision_counts[decision]
            percentage = (count / total_applicants) * 100 if total_applicants else 0
            print(f"{decision+':':<18} {count} applicant(s) ({percentage:.1f}%)")

    def _print_footer(self) -> None:
        print("="*50)
        print("End of Report")
        print("="*50)


# =============================================================================
# 5. Application Orchestration
# =============================================================================

class HiringPipeline:
    """
    Orchestrates the hiring process from scoring to decision-making.

    This class acts as a controller, coordinating the data, scoring engine,
    and decision logic to fulfill the application's main purpose.
    """

    def __init__(
        self,
        applicants: List[Applicant],
        scoring_engine: ScoringEngine,
        config: HiringConfiguration,
    ):
        """
        Initializes the pipeline with its necessary components.

        Args:
            applicants: The list of applicant objects to process.
            scoring_engine: The engine used to calculate scores.
            config: The configuration object for decision thresholds.
        """
        self.applicants = applicants
        self.scoring_engine = scoring_engine
        self.config = config

    def process_applicants(self) -> None:
        """
        Executes the main steps of the hiring process: scoring, ranking,
        and decision-making.
        """
        if not self.applicants:
            print("No applicants to process. Please load applicants first.")
            return

        # FR2: Compute qualification score
        print("\nStep 1: Calculating qualification scores...")
        for applicant in self.applicants:
            self.scoring_engine.calculate_qualification_score(applicant)

        # FR3: Rank candidates
        print("Step 2: Ranking applicants...")
        self.applicants.sort(key=lambda x: x.qualification_score, reverse=True)

        # FR4: Automate decisions
        print("Step 3: Automating interview decisions...")
        self._make_automated_decisions()

    def _make_automated_decisions(self) -> None:
        """Applies automated decisions to the ranked list of applicants."""
        interview_threshold = self.config.top_n_for_interview
        review_threshold = interview_threshold + self.config.next_n_for_review

        for i, applicant in enumerate(self.applicants):
            rank = i + 1
            if rank <= interview_threshold:
                applicant.decision = "Interview"
            elif rank <= review_threshold:
                applicant.decision = "Further Review"
            else:
                applicant.decision = "Reject"


# =============================================================================
# 6. Main Execution Block
# =============================================================================

def main() -> None:
    """
    Main function to run the complete hiring pipeline application.
    """
    # 1. Set up configuration
    config = HiringConfiguration()

    # 2. Load data
    applicants = load_sample_applicant_data()
    print(f"Loaded {len(applicants)} sample applicants.")

    # 3. Initialize core components
    scoring_engine = ScoringEngine(config)
    pipeline = HiringPipeline(applicants, scoring_engine, config)

    # 4. Run the processing pipeline
    pipeline.process_applicants()
    print("\nPipeline processing complete.")

    # 5. Generate and display the final report
    reporter = ReportGenerator()
    reporter.display_summary_report(pipeline.applicants)


if __name__ == "__main__":
    main()