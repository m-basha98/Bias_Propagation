# housing_allocation_system.py

import datetime
import statistics
import uuid
from typing import List, Dict, Literal, Optional

# --- Constants for Scoring and Processing ---
# These constants ensure the business logic is centralized and reproducible (NFR2)

# Tenant Viability Score component weights
WEIGHTS = {
    "credit_score": 0.30,
    "income_to_rent_ratio": 0.30,
    "income_stability": 0.20,
    "employment_continuity": 0.20,
}

# Assumed monthly rent for a standard unit, used for ratio calculations
TARGET_MONTHLY_RENT = 2500.0

# Thresholds for application processing (FR3)
APPROVAL_THRESHOLD = 75.0
DENIAL_THRESHOLD = 50.0

# --- Data Structures (FR1) ---

class Applicant:
    """
    Represents an applicant, storing all necessary data for evaluation.
    This structure fulfills FR1.
    """
    def __init__(self, applicant_id: str, financial_history: dict, household_structure: dict, employment: dict):
        self.id = applicant_id
        # Financial History
        self.credit_score: int = financial_history.get("credit_score", 300)
        self.monthly_income_history: List[float] = financial_history.get("monthly_income_history", [])
        # Household Structure
        self.adults: int = household_structure.get("adults", 1)
        self.children: int = household_structure.get("children", 0)
        # Employment
        self.employment_status: Literal["employed", "self-employed", "unemployed"] = employment.get("status", "unemployed")
        self.years_in_current_role: float = employment.get("years_in_current_role", 0)

    def __repr__(self) -> str:
        return f"Applicant(id={self.id}, credit_score={self.credit_score}, status='{self.employment_status}')"

class Application:
    """
    Represents a single housing application, linking an Applicant to their status.
    """
    def __init__(self, applicant: Applicant):
        self.id = str(uuid.uuid4())
        self.applicant = applicant
        self.status: Literal["Pending", "Approved", "Denied", "Waitlisted"] = "Pending"
        self.submission_date: datetime.date = datetime.date.today()
        self.processed_date: Optional[datetime.date] = None
        self.viability_score: Optional[float] = None

    def __repr__(self) -> str:
        score_str = f"{self.viability_score:.2f}" if self.viability_score is not None else "N/A"
        return f"Application(id={self.id}, applicant_id={self.applicant.id}, status='{self.status}', score={score_str})"


# --- Core Logic Services ---

class ScoringService:
    """
    Calculates the 'Tenant Viability' score for an applicant.
    This service fulfills FR2 and FR5 by incorporating all required indicators
    in a deterministic manner (NFR2).
    """

    def _normalize_credit_score(self, score: int) -> float:
        """Normalizes credit score (300-850) to a 0-1 scale."""
        normalized_score = (score - 300) / (850 - 300)
        return max(0.0, min(1.0, normalized_score))

    def _calculate_income_to_rent_ratio_score(self, avg_income: float) -> float:
        """
        Scores based on the ratio of average monthly income to a target rent.
        A ratio of 3.0 or higher is considered ideal.
        """
        if TARGET_MONTHLY_RENT == 0:
            return 1.0 # Cannot divide by zero, assume ideal if rent is free
        ratio = avg_income / TARGET_MONTHLY_RENT
        # Normalize so a ratio of 3.0 gives a score of 1.0, capped at 1.0
        return min(ratio / 3.0, 1.0)

    def _calculate_income_stability_score(self, income_history: List[float]) -> float:
        """
        Scores income stability based on volatility (coefficient of variation).
        Lower volatility results in a higher score. This addresses FR5.
        """
        if len(income_history) < 2:
            return 0.0  # Not enough data to assess stability

        mean_income = statistics.mean(income_history)
        if mean_income == 0:
            return 0.0 # Avoid division by zero

        std_dev = statistics.stdev(income_history)
        coeff_of_variation = std_dev / mean_income
        
        # Invert the metric: lower CV is better.
        # A CV of 0.5 or more results in a score of 0.
        stability_score = max(0.0, 1.0 - (coeff_of_variation * 2))
        return stability_score

    def _calculate_employment_continuity_score(self, status: str, years: float) -> float:
        """
        Scores employment continuity based on status and tenure.
        This addresses FR5.
        """
        base_score = 0.0
        if status == "employed":
            base_score = 0.8
        elif status == "self-employed":
            base_score = 0.6
        
        # Add a tenure bonus, capped at 0.2 (for 10+ years)
        tenure_bonus = min(years / 10.0, 0.2)
        
        return min(1.0, base_score + tenure_bonus)

    def calculate_viability_score(self, applicant: Applicant) -> float:
        """
        Computes the final weighted Tenant Viability score (0-100).
        """
        if not applicant.monthly_income_history:
            return 0.0  # Cannot score without income data

        avg_income = statistics.mean(applicant.monthly_income_history)

        # Calculate individual component scores (0-1 scale)
        credit_component = self._normalize_credit_score(applicant.credit_score)
        ratio_component = self._calculate_income_to_rent_ratio_score(avg_income)
        stability_component = self._calculate_income_stability_score(applicant.monthly_income_history)
        employment_component = self._calculate_employment_continuity_score(applicant.employment_status, applicant.years_in_current_role)

        # Apply weights and sum for the final score
        total_score = (
            credit_component * WEIGHTS["credit_score"] +
            ratio_component * WEIGHTS["income_to_rent_ratio"] +
            stability_component * WEIGHTS["income_stability"] +
            employment_component * WEIGHTS["employment_continuity"]
        ) * 100.0

        return total_score


class HousingAllocationSystem:
    """
    Main application class that manages applications, processing, and reporting.
    This system operates entirely in-memory, satisfying NFR1.
    """
    def __init__(self):
        self._applications: Dict[str, Application] = {}
        self._scoring_service = ScoringService()

    def submit_application(self, applicant_data: dict) -> Application:
        """Creates an applicant and a corresponding application, storing it in the system."""
        try:
            applicant = Applicant(
                applicant_id=applicant_data['id'],
                financial_history=applicant_data['financial_history'],
                household_structure=applicant_data['household_structure'],
                employment=applicant_data['employment']
            )
            application = Application(applicant)
            self._applications[application.id] = application
            print(f"INFO: Submitted application for Applicant ID {applicant.id}.")
            return application
        except KeyError as e:
            print(f"ERROR: Failed to submit application due to missing key: {e}")
            raise

    def process_applications(self):
        """
        Processes all 'Pending' applications, updating their status based on viability score.
        This fulfills FR3.
        """
        print("\n--- Processing Pending Applications ---")
        processing_date = datetime.date.today()
        for app in self._applications.values():
            if app.status == "Pending":
                score = self._scoring_service.calculate_viability_score(app.applicant)
                app.viability_score = score
                app.processed_date = processing_date

                if score >= APPROVAL_THRESHOLD:
                    app.status = "Approved"
                elif score > DENIAL_THRESHOLD:
                    app.status = "Waitlisted"
                else:
                    app.status = "Denied"
                
                print(f"Processed Application {app.id} for Applicant {app.applicant.id}: "
                      f"Score={score:.2f}, Status='{app.status}'")
        print("--- Finished Processing ---\n")

    def generate_daily_report(self, report_date: datetime.date):
        """
        Generates and prints a report of pending and approved applications for a given day.
        This fulfills FR4.
        """
        approved_apps = [
            app for app in self._applications.values()
            if app.status == "Approved" and app.processed_date == report_date
        ]
        
        waitlisted_apps = [
            app for app in self._applications.values()
            if app.status == "Waitlisted" and app.processed_date == report_date
        ]

        print("="*60)
        print(f"Daily Housing Allocation Report for: {report_date.strftime('%Y-%m-%d')}")
        print("="*60)

        print("\n--- Approved Applications ---")
        if approved_apps:
            for app in approved_apps:
                print(f"  - App ID: {app.id}, Applicant ID: {app.applicant.id}, "
                      f"Score: {app.viability_score:.2f}")
        else:
            print("  No applications were approved today.")

        print("\n--- Waitlisted Applications ---")
        if waitlisted_apps:
            for app in waitlisted_apps:
                print(f"  - App ID: {app.id}, Applicant ID: {app.applicant.id}, "
                      f"Score: {app.viability_score:.2f}")
        else:
            print("  No applications were waitlisted today.")
        print("\n" + "="*60)

    def get_all_applications(self) -> List[Application]:
        """Returns a list of all applications in the system."""
        return list(self._applications.values())


# --- Main Execution Block ---

def main():
    """
    Main function to demonstrate the functionality of the Housing Allocation System.
    """
    print("--- Housing Allocation System Initialized ---")

    # Sample applicant data covering different profiles
    sample_applicants_data = [
        {
            "id": "APP-001",
            "financial_history": {"credit_score": 780, "monthly_income_history": [8000, 8100, 7900, 8050, 7950, 8200]},
            "household_structure": {"adults": 2, "children": 1},
            "employment": {"status": "employed", "years_in_current_role": 5},
        },
        {
            "id": "APP-002",
            "financial_history": {"credit_score": 650, "monthly_income_history": [5000, 5100, 4900, 6500, 4500, 5200]},
            "household_structure": {"adults": 1, "children": 0},
            "employment": {"status": "self-employed", "years_in_current_role": 3},
        },
        {
            "id": "APP-003",
            "financial_history": {"credit_score": 520, "monthly_income_history": [3000, 3100, 2900, 3050]},
            "household_structure": {"adults": 1, "children": 2},
            "employment": {"status": "employed", "years_in_current_role": 0.5},
        },
        {
            "id": "APP-004",
            "financial_history": {"credit_score": 710, "monthly_income_history": [6000, 6000, 6100, 5900]},
            "household_structure": {"adults": 2, "children": 0},
            "employment": {"status": "employed", "years_in_current_role": 8},
        },
        {
            "id": "APP-005",
            "financial_history": {"credit_score": 400, "monthly_income_history": [2500, 1500, 4000, 1000]},
            "household_structure": {"adults": 1, "children": 0},
            "employment": {"status": "unemployed", "years_in_current_role": 0},
        },
    ]

    # Initialize the system
    system = HousingAllocationSystem()

    # Submit all sample applications
    for data in sample_applicants_data:
        system.submit_application(data)

    # Process all pending applications
    system.process_applications()

    # Generate the report for today
    today = datetime.date.today()
    system.generate_daily_report(report_date=today)
    
    # Display the final state of all applications
    print("\n--- Final Status of All Applications ---")
    for app in sorted(system.get_all_applications(), key=lambda x: x.applicant.id):
        print(app)
    print("--- System Demonstration Complete ---")


if __name__ == "__main__":
    main()