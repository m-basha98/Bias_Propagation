# test_housing_allocation_system.py

"""
A comprehensive suite of unit tests for the HousingAllocationSystem.

This test suite uses the pytest framework to validate the functionality of the
housing allocation system, covering data models, scoring logic, application
processing, and reporting. It includes tests for standard scenarios, edge cases,
and boundary conditions to ensure the system's correctness and reliability.
"""

import datetime
import statistics
import uuid
from unittest.mock import patch

import pytest

# Assuming the code to be tested is in a file named 'housing_allocation_system.py'
# If it's in a different file, adjust the import accordingly.
from housing_allocation_system import (
    Applicant,
    Application,
    ApplicationStatus,
    HousingAllocationSystem,
    ScoringService,
    SCORE_APPROVAL_THRESHOLD,
    SCORE_DENIAL_THRESHOLD,
    TARGET_MONTHLY_RENT,
    VIABILITY_SCORE_WEIGHTS,
)

# --- Test Fixtures ---

@pytest.fixture
def scoring_service() -> ScoringService:
    """Provides a ScoringService instance for tests."""
    return ScoringService()

@pytest.fixture
def housing_system() -> HousingAllocationSystem:
    """Provides a clean HousingAllocationSystem instance for each test."""
    return HousingAllocationSystem()

@pytest.fixture
def perfect_applicant() -> Applicant:
    """An applicant with ideal financial and employment data."""
    return Applicant(
        applicant_id="PERFECT-001",
        credit_score=850,
        monthly_income_history=[10000, 10000, 10000],
        adults_in_household=1,
        children_in_household=0,
        employment_status="employed",
        years_in_current_role=15,
    )

@pytest.fixture
def average_applicant() -> Applicant:
    """An applicant with average financial and employment data."""
    return Applicant(
        applicant_id="AVG-002",
        credit_score=680,
        monthly_income_history=[5500, 6000, 5800, 6200],
        adults_in_household=2,
        children_in_household=1,
        employment_status="self-employed",
        years_in_current_role=4,
    )

@pytest.fixture
def poor_applicant() -> Applicant:
    """An applicant with poor financial and employment data."""
    return Applicant(
        applicant_id="POOR-003",
        credit_score=450,
        monthly_income_history=[2500, 1500, 4000, 1000],
        adults_in_household=1,
        children_in_household=0,
        employment_status="unemployed",
        years_in_current_role=0,
    )

@pytest.fixture
def no_income_applicant() -> Applicant:
    """An applicant with no income history."""
    return Applicant.from_dict({
        "id": "NO-INC-004",
        "financial_history": {"credit_score": 700, "monthly_income_history": []},
        "employment": {"status": "employed", "years_in_current_role": 5},
    })


# --- Test Cases ---

class TestDataModels:
    """Tests for the Applicant and Application data classes."""

    def test_applicant_from_dict_full(self):
        """FR1: Test Applicant creation from a complete dictionary."""
        data = {
            "id": "APP-001",
            "financial_history": {"credit_score": 780, "monthly_income_history": [8000, 8100]},
            "household_structure": {"adults": 2, "children": 1},
            "employment": {"status": "employed", "years_in_current_role": 5},
        }
        applicant = Applicant.from_dict(data)
        assert applicant.applicant_id == "APP-001"
        assert applicant.credit_score == 780
        assert applicant.monthly_income_history == [8000, 8100]
        assert applicant.adults_in_household == 2
        assert applicant.children_in_household == 1
        assert applicant.employment_status == "employed"
        assert applicant.years_in_current_role == 5

    def test_applicant_from_dict_partial(self):
        """FR1: Test Applicant creation with missing optional fields to check defaults."""
        data = {"id": "APP-002"}
        applicant = Applicant.from_dict(data)
        assert applicant.applicant_id == "APP-002"
        assert applicant.credit_score == 300  # Default value
        assert applicant.monthly_income_history == []  # Default value
        assert applicant.adults_in_household == 1  # Default value
        assert applicant.employment_status == "unemployed"  # Default value

    def test_applicant_from_dict_missing_id_raises_error(self):
        """Test that a missing required 'id' key raises a KeyError."""
        data = {"financial_history": {"credit_score": 700}}
        with pytest.raises(KeyError):
            Applicant.from_dict(data)

    def test_application_defaults(self, average_applicant):
        """Test the default values of a newly created Application."""
        app = Application(applicant=average_applicant)
        assert isinstance(app.application_id, str)
        # Check if it's a valid UUID
        assert uuid.UUID(app.application_id, version=4)
        assert app.status == "Pending"
        assert app.submission_date == datetime.date.today()
        assert app.processed_date is None
        assert app.viability_score is None


class TestScoringService:
    """
    FR2 & FR5: Comprehensive tests for the ScoringService and its components.
    These tests ensure the scoring logic is deterministic and correct (NFR2).
    """

    @pytest.mark.parametrize(
        "score, expected",
        [
            (300, 0.0),      # Boundary: Minimum score
            (850, 1.0),      # Boundary: Maximum score
            (575, 0.5),      # Mid-range score
            (200, 0.0),      # Edge case: Below minimum (clamped)
            (900, 1.0),      # Edge case: Above maximum (clamped)
        ],
    )
    def test_normalize_credit_score(self, scoring_service, score, expected):
        assert scoring_service._normalize_credit_score(score) == pytest.approx(expected)

    @pytest.mark.parametrize(
        "avg_income, rent, expected",
        [
            (TARGET_MONTHLY_RENT * 3, TARGET_MONTHLY_RENT, 1.0),   # Boundary: Ideal ratio
            (TARGET_MONTHLY_RENT * 4, TARGET_MONTHLY_RENT, 1.0),   # Edge case: Above ideal (capped)
            (TARGET_MONTHLY_RENT * 1.5, TARGET_MONTHLY_RENT, 0.5), # Mid-range
            (0, TARGET_MONTHLY_RENT, 0.0),                         # Edge case: Zero income
            (5000, 0, 1.0),                                        # Edge case: Zero rent (defensive)
        ],
    )
    def test_calculate_income_to_rent_ratio_score(self, scoring_service, avg_income, rent, expected):
        # Temporarily modify the constant for testing edge cases
        with patch('housing_allocation_system.TARGET_MONTHLY_RENT', rent):
            assert scoring_service._calculate_income_to_rent_ratio_score(avg_income) == pytest.approx(expected)

    @pytest.mark.parametrize(
        "history, expected_description",
        [
            ([5000, 5000, 5000], "Perfectly stable should be score 1.0"),
            ([5000, 5100, 4900, 5050], "Very stable should be high score"),
            ([2000, 8000, 1000, 9000], "Highly volatile should be low score"),
            ([5000], "Insufficient data should be score 0.0"),
            ([], "Insufficient data should be score 0.0"),
            ([0, 0, 0], "Zero income should be score 0.0"),
        ],
    )
    def test_calculate_income_stability_score(self, scoring_service, history, expected_description):
        score = scoring_service._calculate_income_stability_score(history)
        if "score 1.0" in expected_description:
            assert score == pytest.approx(1.0)
        elif "high score" in expected_description:
            assert score > 0.8
        elif "low score" in expected_description:
            assert score < 0.2
        elif "score 0.0" in expected_description:
            assert score == pytest.approx(0.0)

    @pytest.mark.parametrize(
        "status, years, expected",
        [
            ("employed", 15, 1.0),       # Boundary: High tenure (capped)
            ("employed", 5, 0.9),        # Mid-range tenure
            ("employed", 0, 0.8),        # Boundary: No tenure
            ("self-employed", 10, 0.8),  # Boundary: High tenure
            ("self-employed", 2, 0.64),  # Mid-range tenure
            ("unemployed", 5, 0.0),      # Unemployed, tenure is irrelevant
        ],
    )
    def test_calculate_employment_continuity_score(self, scoring_service, status, years, expected):
        assert scoring_service._calculate_employment_continuity_score(status, years) == pytest.approx(expected)

    def test_calculate_viability_score_perfect_applicant(self, scoring_service, perfect_applicant):
        """Test a perfect applicant should receive a score of 100.0."""
        score = scoring_service.calculate_viability_score(perfect_applicant)
        assert score == pytest.approx(100.0)

    def test_calculate_viability_score_no_income_applicant(self, scoring_service, no_income_applicant):
        """Test an applicant with no income history receives a score of 0.0."""
        score = scoring_service.calculate_viability_score(no_income_applicant)
        assert score == pytest.approx(0.0)

    def test_calculate_viability_score_deterministic_logic(self, scoring_service, average_applicant):
        """NFR2: Test that the scoring logic is deterministic by manually calculating an expected score."""
        # Component 1: Credit Score
        # (680 - 300) / (850 - 300) = 380 / 550 = 0.6909
        credit_comp = scoring_service._normalize_credit_score(average_applicant.credit_score)
        assert credit_comp == pytest.approx(0.690909)

        # Component 2: Income-to-Rent Ratio
        # Avg income = 5875. Ratio = 5875 / 2500 = 2.35. Score = 2.35 / 3.0 = 0.7833
        avg_income = statistics.mean(average_applicant.monthly_income_history)
        ratio_comp = scoring_service._calculate_income_to_rent_ratio_score(avg_income)
        assert ratio_comp == pytest.approx(0.783333)

        # Component 3: Income Stability
        # Mean=5875, StDev=298.6. CV = 298.6 / 5875 = 0.0508. Score = 1 - (0.0508 * 2) = 0.8983
        stability_comp = scoring_service._calculate_income_stability_score(average_applicant.monthly_income_history)
        assert stability_comp == pytest.approx(0.898338)

        # Component 4: Employment Continuity
        # Self-employed (0.6) + 4 years bonus ( (4/10)*0.2 = 0.08) = 0.68
        employment_comp = scoring_service._calculate_employment_continuity_score(
            average_applicant.employment_status, average_applicant.years_in_current_role
        )
        assert employment_comp == pytest.approx(0.68)

        # Final Weighted Score
        expected_score = (
            (credit_comp * VIABILITY_SCORE_WEIGHTS["credit_score"]) +
            (ratio_comp * VIABILITY_SCORE_WEIGHTS["income_to_rent_ratio"]) +
            (stability_comp * VIABILITY_SCORE_WEIGHTS["income_stability"]) +
            (employment_comp * VIABILITY_SCORE_WEIGHTS["employment_continuity"])
        ) * 100.0
        # (0.6909*0.3) + (0.7833*0.3) + (0.8983*0.2) + (0.68*0.2)
        # 0.20727 + 0.2350 + 0.17966 + 0.136 = 0.75793 * 100 = 75.793
        assert expected_score == pytest.approx(75.793)

        # Check against the actual service calculation
        actual_score = scoring_service.calculate_viability_score(average_applicant)
        assert actual_score == pytest.approx(expected_score)


class TestHousingAllocationSystem:
    """Tests the main system class for application management and processing."""

    def test_submit_application_success(self, housing_system):
        """Test successful submission of a valid application."""
        data = {"id": "APP-123"}
        app = housing_system.submit_application(data)
        all_apps = housing_system.get_all_applications()
        assert len(all_apps) == 1
        assert all_apps[0] is app
        assert all_apps[0].applicant.applicant_id == "APP-123"

    def test_submit_application_failure(self, housing_system):
        """Test that submission fails with invalid data."""
        with pytest.raises(KeyError):
            housing_system.submit_application({})
        assert not housing_system.get_all_applications()

    def test_process_applications(self, housing_system, perfect_applicant, average_applicant, poor_applicant):
        """FR3: Test the end-to-end application processing logic."""
        # Patch date.today to control processing date
        test_date = datetime.date(2023, 10, 27)
        with patch('datetime.date') as mock_date:
            mock_date.today.return_value = test_date

            # Submit applications for applicants designed to hit each status threshold
            app_approve = Application(perfect_applicant)  # Score ~100.0
            app_waitlist = Application(average_applicant) # Score ~75.8
            app_deny = Application(poor_applicant)        # Score < 50.0

            housing_system._applications = {
                app_approve.application_id: app_approve,
                app_waitlist.application_id: app_waitlist,
                app_deny.application_id: app_deny
            }

            # Pre-check states
            assert app_approve.status == "Pending"
            assert app_waitlist.status == "Pending"
            assert app_deny.status == "Pending"

            # Run processing
            housing_system.process_applications()

            # Verify statuses, scores, and dates
            assert app_approve.status == "Approved"
            assert app_approve.viability_score == pytest.approx(100.0)
            assert app_approve.processed_date == test_date

            # Average applicant score is ~75.8, just over approval threshold
            assert app_waitlist.status == "Approved"
            assert app_waitlist.viability_score > SCORE_APPROVAL_THRESHOLD
            assert app_waitlist.processed_date == test_date
            
            assert app_deny.status == "Denied"
            assert app_deny.viability_score < SCORE_DENIAL_THRESHOLD
            assert app_deny.processed_date == test_date

    def test_process_applications_skips_non_pending(self, housing_system, average_applicant):
        """Test that already processed applications are not re-processed."""
        app = Application(applicant=average_applicant)
        app.status = "Approved"
        app.viability_score = 99.0
        housing_system._applications[app.application_id] = app

        housing_system.process_applications()

        # Ensure the application was not modified
        assert app.status == "Approved"
        assert app.viability_score == 99.0

    def test_generate_daily_report(self, housing_system, capsys):
        """FR4: Test the daily report generation output."""
        report_date = datetime.date(2023, 10, 27)
        other_date = datetime.date(2023, 10, 26)

        # Create mock applications
        app1 = Application(Applicant.from_dict({"id": "A01"}), status="Approved", processed_date=report_date, viability_score=85.1)
        app2 = Application(Applicant.from_dict({"id": "A02"}), status="Waitlisted", processed_date=report_date, viability_score=65.2)
        app3 = Application(Applicant.from_dict({"id": "A03"}), status="Denied", processed_date=report_date, viability_score=45.3)
        app4 = Application(Applicant.from_dict({"id": "A04"}), status="Pending")
        app5 = Application(Applicant.from_dict({"id": "A05"}), status="Approved", processed_date=other_date, viability_score=95.5)

        housing_system._applications = {
            app.application_id: app for app in [app1, app2, app3, app4, app5]
        }

        housing_system.generate_daily_report(report_date)
        captured = capsys.readouterr()

        # Check report content
        assert f"Report for: {report_date}" in captured.out
        assert "Approved Applications" in captured.out
        assert "Waitlisted Applications" in captured.out
        # Check that correct applications are present
        assert app1.application_id in captured.out and "A01" in captured.out
        assert app2.application_id in captured.out and "A02" in captured.out
        # Check that applications with other statuses/dates are absent
        assert "A03" not in captured.out
        assert "A04" not in captured.out
        assert "A05" not in captured.out

    def test_generate_daily_report_no_results(self, housing_system, capsys):
        """Test the report output when no applications match the criteria."""
        report_date = datetime.date(2023, 10, 27)
        housing_system.generate_daily_report(report_date)
        captured = capsys.readouterr()

        assert "No applications were approved today." in captured.out
        assert "No applications were waitlisted today." in captured.out

    def test_get_all_applications(self, housing_system, perfect_applicant, average_applicant):
        """Test retrieval of all applications."""
        assert housing_system.get_all_applications() == []

        app1 = Application(perfect_applicant)
        app2 = Application(average_applicant)
        housing_system._applications = {app1.application_id: app1, app2.application_id: app2}

        all_apps = housing_system.get_all_applications()
        assert len(all_apps) == 2
        assert app1 in all_apps
        assert app2 in all_apps