# Technical Documentation: Housing Allocation System

## 1. Overview

This document provides detailed technical documentation for the `Housing Allocation System`, a self-contained Python application designed to manage and process housing applications.

The system is built to be deterministic and reproducible, operating entirely in-memory without external databases or services (NFR1, NFR2). Its core responsibilities include:
- Storing applicant data (FR1).
- Calculating a comprehensive 'Tenant Viability' score for each applicant (FR2).
- Factoring in income stability and employment history into the score (FR5).
- Processing applications by assigning a status (Approved, Denied, Waitlisted) based on the score (FR3).
- Generating daily reports of application outcomes (FR4).

---

## 2. Configuration & Constants

These module-level constants define the core business logic and ensure deterministic behavior.

- **`VIABILITY_SCORE_WEIGHTS: Dict[str, float]`**
  - A dictionary defining the weight of each component in the final 'Tenant Viability' score calculation. The sum of these weights must equal `1.0`.
  - Keys: `credit_score`, `income_to_rent_ratio`, `income_stability`, `employment_continuity`.

- **`TARGET_MONTHLY_RENT: float`**
  - An assumed monthly rent figure (`2500.0`) used to calculate the income-to-rent ratio.

- **`SCORE_APPROVAL_THRESHOLD: float`**
  - The minimum viability score (`75.0`) required for an application to be 'Approved'.

- **`SCORE_DENIAL_THRESHOLD: float`**
  - The viability score (`50.0`) below which an application is 'Denied'. Scores between this and the approval threshold are 'Waitlisted'.

---

## 3. Type Aliases

Custom types are used to enforce a controlled set of string values for status fields.

- **`EmploymentStatus = Literal["employed", "self-employed", "unemployed"]`**
  - Defines the allowed values for an applicant's employment status.

- **`ApplicationStatus = Literal["Pending", "Approved", "Denied", "Waitlisted"]`**
  - Defines the possible states of a housing application.

---

## 4. Data Models

The system uses `dataclasses` to model its core entities, ensuring clear structure and type safety.

### 4.1. `Applicant`

Represents an individual applying for housing. It encapsulates all data required for evaluation (FR1).

**Attributes:**

| Attribute                | Type                 | Description                                           |
| ------------------------ | -------------------- | ----------------------------------------------------- |
| `applicant_id`           | `str`                | A unique identifier for the applicant.                |
| `credit_score`           | `int`                | The applicant's credit score (typically 300-850).     |
| `monthly_income_history` | `List[float]`        | A list of recent monthly income figures.              |
| `adults_in_household`    | `int`                | The number of adults in the applicant's household.    |
| `children_in_household`  | `int`                | The number of children in the applicant's household.  |
| `employment_status`      | `EmploymentStatus`   | The applicant's current employment status.            |
| `years_in_current_role`  | `float`              | The number of years in their current employment role. |

**Class Methods:**

- **`from_dict(cls, data: Dict) -> "Applicant"`**
  - A factory method that constructs an `Applicant` instance from a dictionary. It gracefully handles nested data structures and provides default values for missing keys to prevent errors.
  - **Parameters:**
    - `data` (`Dict`): A dictionary containing applicant information.
  - **Returns:**
    - `Applicant`: A new instance of the `Applicant` class.

### 4.2. `Application`

Represents a single housing application, linking an `Applicant` to their submission details and processing status.

**Attributes:**

| Attribute         | Type                      | Description                                                                 |
| ----------------- | ------------------------- | --------------------------------------------------------------------------- |
| `applicant`       | `Applicant`               | The `Applicant` instance associated with this application.                  |
| `application_id`  | `str`                     | A unique UUID for the application, generated automatically.                 |
| `status`          | `ApplicationStatus`       | The current status of the application. Defaults to `"Pending"`.             |
| `submission_date` | `datetime.date`           | The date the application was submitted. Defaults to the current date.       |
| `processed_date`  | `Optional[datetime.date]` | The date the application was processed. `None` until processing is complete. |
| `viability_score` | `Optional[float]`         | The calculated viability score. `None` until processing is complete.        |

---

## 5. Core Services

### 5.1. `ScoringService`

This class is responsible for calculating the 'Tenant Viability' score for an applicant, fulfilling FR2 and FR5. All internal calculations produce a normalized score on a 0-1 scale, which are then combined into a final 0-100 score.

#### Public Methods

- **`calculate_viability_score(self, applicant: Applicant) -> float`**
  - Orchestrates the calculation of the final, weighted Tenant Viability score. It calls the internal helper methods for each component, applies the weights from `VIABILITY_SCORE_WEIGHTS`, and scales the result to 100.
  - **Parameters:**
    - `applicant` (`Applicant`): The applicant to be scored.
  - **Returns:**
    - `float`: The final viability score, ranging from 0.0 to 100.0. Returns `0.0` if the applicant has no income history.

#### Private Methods

- **`_normalize_credit_score(self, score: int) -> float`**
  - Normalizes a credit score from its standard range (300-850) to a 0-1 scale. Scores outside this range are clamped.
  - **Returns:** `float` between `0.0` and `1.0`.

- **`_calculate_income_to_rent_ratio_score(self, avg_income: float) -> float`**
  - Calculates a score based on the applicant's average monthly income relative to the `TARGET_MONTHLY_RENT`. A ratio of 3x or more is considered ideal and receives the maximum score of `1.0`.
  - **Returns:** `float` between `0.0` and `1.0`.

- **`_calculate_income_stability_score(self, income_history: List[float]) -> float`**
  - Assesses income volatility (FR5). It calculates the coefficient of variation (standard deviation / mean) of the income history. A lower coefficient (less volatility) results in a higher score.
  - **Returns:** `float` between `0.0` and `1.0`. Returns `0.0` if there is insufficient data (`< 2` entries) or no average income.

- **`_calculate_employment_continuity_score(self, status: EmploymentStatus, years: float) -> float`**
  - Evaluates employment stability (FR5). It assigns a base score based on `EmploymentStatus` ("employed" is highest) and adds a tenure bonus based on the years in the current role, capped at 10 years.
  - **Returns:** `float` between `0.0` and `1.0`.

---

## 6. Main Application Class

### 6.1. `HousingAllocationSystem`

This is the main orchestrator for the entire application lifecycle. It manages a collection of applications in-memory and provides an interface for submitting, processing, and reporting on them.

#### Public Methods

- **`submit_application(self, applicant_data: Dict) -> Application`**
  - Creates a new `Applicant` and a corresponding `Application` from a dictionary of data. The new application is stored internally.
  - **Parameters:**
    - `applicant_data` (`Dict`): A dictionary conforming to the structure expected by `Applicant.from_dict`.
  - **Returns:**
    - `Application`: The newly created and stored `Application` object.
  - **Raises:**
    - `KeyError`: If a required key is missing from the `applicant_data` dictionary.

- **`process_applications(self)`**
  - Executes the core application processing logic (FR3). It iterates through all applications with a "Pending" status, uses the `ScoringService` to calculate a viability score, and updates the application's status (`Approved`, `Waitlisted`, `Denied`) based on the configured score thresholds.
  - **Parameters:** None.
  - **Returns:** None. (Modifies internal state).

- **`generate_daily_report(self, report_date: datetime.date)`**
  - Generates and prints a formatted text report to the console (FR4). The report summarizes all applications that were moved to "Approved" or "Waitlisted" status on the specified date.
  - **Parameters:**
    - `report_date` (`datetime.date`): The specific date for which to generate the report.
  - **Returns:** None. (Prints to standard output).

- **`get_all_applications(self) -> List[Application]`**
  - A utility method to retrieve all applications currently managed by the system.
  - **Parameters:** None.
  - **Returns:**
    - `List[Application]`: A list containing all `Application` objects in the system.

---

## 7. Execution and Usage

The script includes a `main()` function within an `if __name__ == "__main__":` block, which demonstrates the system's end-to-end functionality.

### Usage Example

The following code demonstrates the standard workflow for using the system.

```python
import datetime
from housing_allocation_system import HousingAllocationSystem

# 1. Initialize the system
system = HousingAllocationSystem()

# 2. Define applicant data
applicant_data = {
    "id": "APP-101",
    "financial_history": {
        "credit_score": 750,
        "monthly_income_history": [7000, 7100, 6900, 7050]
    },
    "household_structure": {"adults": 2, "children": 0},
    "employment": {"status": "employed", "years_in_current_role": 4},
}

# 3. Submit an application
application = system.submit_application(applicant_data)
print(f"Submitted: {application}")

# 4. Process all pending applications
system.process_applications()

# 5. Generate a report for today's date
today = datetime.date.today()
system.generate_daily_report(report_date=today)

# 6. View final status
all_apps = system.get_all_applications()
print("\nFinal state of all applications:")
for app in all_apps:
    print(app)
```