# housing_allocation_system.py

"""
A self-contained system for managing and processing housing applications.

This system handles applicant data, calculates a 'Tenant Viability' score,
processes applications based on this score, and generates daily reports.
It operates entirely in-memory, without external dependencies, ensuring
deterministic and reproducible outcomes.
"""

import datetime
import statistics
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Literal, Optional

# --- Constants & Configuration ---
# Centralized constants ensure deterministic logic (NFR2).

# Weights for calculating the Tenant Viability Score (FR2, FR5). The sum must be 1.0.
VIABILITY_SCORE_WEIGHTS: Dict[str, float] = {
    "credit_score": 0.30,
    "income_to_rent_ratio": 0.30,
    "income_stability": 0.20,
    "employment_continuity": 0.20,
}

# Assumed monthly rent for a standard unit, used for ratio calculations.
TARGET_MONTHLY_RENT: float = 2500.0

# Thresholds for application status decisions (FR3).
SCORE_APPROVAL_THRESHOLD: float = 75.0
SCORE_DENIAL_THRESHOLD: float = 50.0

# --- Data Models (FR1) ---

EmploymentStatus = Literal["employed", "self-employed", "unemployed"]
ApplicationStatus = Literal["Pending", "Approved", "Denied", "Waitlisted"]


@dataclass
class Applicant:
    """
    Represents an applicant, storing all necessary data for evaluation.

    This data class fulfills FR1 by modeling financial history, household
    structure, and employment information.
    """
    applicant_id: str
    credit_score: int
    monthly_income_history: List[float]
    adults_in_household: int
    children_in_household: int
    employment_status: EmploymentStatus
    years_in_current_role: float

    @classmethod
    def from_dict(cls, data: Dict) -> "Applicant":
        """Factory method to create an Applicant from a dictionary."""
        financial = data.get("financial_history", {})
        household = data.get("household_structure", {})
        employment = data.get("employment", {})

        return cls(
            applicant_id=data["id"],
            credit_score=financial.get("credit_score", 300),
            monthly_income_history=financial.get("monthly_income_history", []),
            adults_in_household=household.get("adults", 1),
            children_in_household=household.get("children", 0),
            employment_status=employment.get("status", "unemployed"),
            years_in_current_role=employment.get("years_in_current_role", 0),
        )

    def __repr__(self) -> str:
        return (
            f"Applicant(id={self.applicant_id}, "
            f"credit_score={self.credit_score}, "
            f"status='{self.employment_status}')"
        )


@dataclass
class Application:
    """
    Represents a single housing application, linking an applicant to their status.
    """
    applicant: Applicant
    application_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    status: ApplicationStatus = "Pending"
    submission_date: datetime.date = field(default_factory=datetime.date.today)
    processed_date: Optional[datetime.date] = None
    viability_score: Optional[float] = None

    def __repr__(self) -> str:
        score_str = f"{self.viability_score:.2f}" if self.viability_score is not None else "N/A"
        return (
            f"Application(id={self.application_id}, "
            f"applicant_id={self.applicant.applicant_id}, "
            f"status='{self.status}', score={score_str})"
        )


# --- Core Services ---

class ScoringService:
    """
    Calculates the 'Tenant Viability' score for an applicant.

    This service fulfills FR2 and FR5 by incorporating various financial
    and employment indicators in a deterministic manner (NFR2). All component
    scores are normalized to a 0-1 scale before weighting.
    """

    def _normalize_credit_score(self, score: int) -> float:
        """Normalizes a credit score (300-850 range) to a 0-1 scale."""
        normalized_score = (score - 300) / (850 - 300)
        return max(0.0, min(1.0, normalized_score))

    def _calculate_income_to_rent_ratio_score(self, avg_income: float) -> float:
        """Scores income-to-rent ratio, idealizing >= 3x the target rent."""
        if TARGET_MONTHLY_RENT <= 0:
            return 1.0  # Ideal score if rent is zero or negative.
        ratio = avg_income / TARGET_MONTHLY_RENT
        # Normalize so a ratio of 3.0 or more yields a score of 1.0.
        return min(ratio / 3.0, 1.0)

    def _calculate_income_stability_score(
        self, income_history: List[float]
    ) -> float:
        """
        Scores income stability based on its coefficient of variation.
        Lower volatility (less risk) results in a higher score. This addresses FR5.
        """
        if len(income_history) < 2:
            return 0.0  # Insufficient data to assess stability.
        mean_income = statistics.mean(income_history)
        if mean_income == 0:
            return 0.0  # Avoid division by zero with no income.

        std_dev = statistics.stdev(income_history)
        coeff_of_variation = std_dev / mean_income

        # Invert the metric: lower variation is better.
        # A CV of 0.5 or more is considered highly unstable, resulting in a score of 0.
        stability_score = max(0.0, 1.0 - (coeff_of_variation * 2))
        return stability_score

    def _calculate_employment_continuity_score(
        self, status: EmploymentStatus, years: float
    ) -> float:
        """
        Scores employment continuity based on status and tenure. This addresses FR5.
        """
        base_score = 0.0
        if status == "employed":
            base_score = 0.8
        elif status == "self-employed":
            base_score = 0.6

        # Add a tenure bonus, capped at 0.2 (achieved at 10+ years).
        tenure_bonus = min((years / 10.0) * 0.2, 0.2)

        return min(1.0, base_score + tenure_bonus)

    def calculate_viability_score(self, applicant: Applicant) -> float:
        """
        Computes the final weighted Tenant Viability score (0-100).
        """
        if not applicant.monthly_income_history:
            return 0.0  # Cannot score an applicant without income data.

        avg_income = statistics.mean(applicant.monthly_income_history)

        # Calculate individual component scores (0-1 scale).
        credit_component = self._normalize_credit_score(applicant.credit_score)
        ratio_component = self._calculate_income_to_rent_ratio_score(avg_income)
        stability_component = self._calculate_income_stability_score(
            applicant.monthly_income_history
        )
        employment_component = self._calculate_employment_continuity_score(
            applicant.employment_status, applicant.years_in_current_role
        )

        # Apply weights and sum to get the final score.
        total_score = (
            credit_component * VIABILITY_SCORE_WEIGHTS["credit_score"]
            + ratio_component * VIABILITY_SCORE_WEIGHTS["income_to_rent_ratio"]
            + stability_component * VIABILITY_SCORE_WEIGHTS["income_stability"]
            + employment_component * VIABILITY_SCORE_WEIGHTS["employment_continuity"]
        )

        # Return score on a 0-100 scale.
        return total_score * 100.0


# --- Main Application Class ---

class HousingAllocationSystem:
    """
    Manages the lifecycle of housing applications, including submission,
    processing, and reporting. This system operates entirely in-memory,
    satisfying NFR1.
    """
    def __init__(self):
        self._applications: Dict[str, Application] = {}
        self._scoring_service = ScoringService()

    def submit_application(self, applicant_data: Dict) -> Application:
        """
        Creates an applicant and a corresponding application, storing it.
        """
        try:
            applicant = Applicant.from_dict(applicant_data)
            application = Application(applicant)
            self._applications[application.application_id] = application
            print(f"INFO: Submitted application for Applicant "
                  f"ID {applicant.applicant_id}.")
            return application
        except KeyError as e:
            print(f"ERROR: Failed to submit application due to missing key: {e}")
            raise

    def process_applications(self):
        """
        Processes all 'Pending' applications, updating their status based on
        the calculated viability score. This fulfills FR3.
        """
        print("\n--- Processing Pending Applications ---")
        processing_date = datetime.date.today()
        for app in self._applications.values():
            if app.status == "Pending":
                score = self._scoring_service.calculate_viability_score(app.applicant)
                app.viability_score = score
                app.processed_date = processing_date

                if score >= SCORE_APPROVAL_THRESHOLD:
                    app.status = "Approved"
                elif score > SCORE_DENIAL_THRESHOLD:
                    app.status = "Waitlisted"
                else:
                    app.status = "Denied"

                print(f"Processed App {app.application_id[:8]} for "
                      f"Applicant {app.applicant.applicant_id}: "
                      f"Score={score:.2f}, Status='{app.status}'")
        print("--- Finished Processing ---\n")

    def generate_daily_report(self, report_date: datetime.date):
        """
        Generates and prints a report of approved and waitlisted applications
        processed on a given date. This fulfills FR4.
        """
        approved = [
            app for app in self._applications.values()
            if app.status == "Approved" and app.processed_date == report_date
        ]
        waitlisted = [
            app for app in self._applications.values()
            if app.status == "Waitlisted" and app.processed_date == report_date
        ]

        report_header = f"Daily Housing Allocation Report for: {report_date}"
        print("=" * len(report_header))
        print(report_header)
        print("=" * len(report_header))

        print("\n--- Approved Applications ---")
        if approved:
            for app in approved:
                print(f"  - App ID: {app.application_id}, "
                      f"Applicant ID: {app.applicant.applicant_id}, "
                      f"Score: {app.viability_score:.2f}")
        else:
            print("  No applications were approved today.")

        print("\n--- Waitlisted Applications ---")
        if waitlisted:
            for app in waitlisted:
                print(f"  - App ID: {app.application_id}, "
                      f"Applicant ID: {app.applicant.applicant_id}, "
                      f"Score: {app.viability_score:.2f}")
        else:
            print("  No applications were waitlisted today.")

        print("\n" + "=" * len(report_header))

    def get_all_applications(self) -> List[Application]:
        """Returns a list of all applications currently in the system."""
        return list(self._applications.values())


# --- Demonstration ---

def main():
    """
    Main function to demonstrate the functionality of the system.
    """
    print("--- Housing Allocation System Initialized ---")

    # Sample applicant data covering various profiles.
    sample_applicants_data = [
        {
            "id": "APP-001",
            "financial_history": {"credit_score": 780, "monthly_income_history": [8000, 8100, 7900, 8050, 7950, 8200]},
            "household_structure": {"adults": 2, "children": 1},
            "employment": {"status": "employed", "years_in_current_role": 5},
        },
        {
            "id": "APP-002",
            "financial_history": {"credit_score": 650, "monthly_income_history": [5000, 5100, 4900, 6500, 4500, 5200]},
            "household_structure": {"adults": 1, "children": 0},
            "employment": {"status": "self-employed", "years_in_current_role": 3},
        },
        {
            "id": "APP-003",
            "financial_history": {"credit_score": 520, "monthly_income_history": [3000, 3100, 2900, 3050]},
            "household_structure": {"adults": 1, "children": 2},
            "employment": {"status": "employed", "years_in_current_role": 0.5},
        },
        {
            "id": "APP-004",
            "financial_history": {"credit_score": 710, "monthly_income_history": [6000, 6000, 6100, 5900]},
            "household_structure": {"adults": 2, "children": 0},
            "employment": {"status": "employed", "years_in_current_role": 8},
        },
        {
            "id": "APP-005",
            "financial_history": {"credit_score": 400, "monthly_income_history": [2500, 1500, 4000, 1000]},
            "household_structure": {"adults": 1, "children": 0},
            "employment": {"status": "unemployed", "years_in_current_role": 0},
        },
    ]

    # Initialize the system.
    system = HousingAllocationSystem()

    # Submit all sample applications.
    for data in sample_applicants_data:
        system.submit_application(data)

    # Process all pending applications.
    system.process_applications()

    # Generate the report for today.
    today = datetime.date.today()
    system.generate_daily_report(report_date=today)

    # Display the final state of all applications for review.
    print("\n--- Final Status of All Applications ---")
    all_apps = sorted(
        system.get_all_applications(), key=lambda app: app.applicant.applicant_id
    )
    for app in all_apps:
        print(app)
    print("--- System Demonstration Complete ---")


if __name__ == "__main__":
    main()