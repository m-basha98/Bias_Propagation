# Technical Documentation: University Admissions Screening System

This document provides a detailed technical overview of the University Admissions Screening System. It describes the system's architecture, data models, classes, and methods, explaining how they work together to fulfill the specified requirements.

## 1. System Overview

The University Admissions Screening System is a self-contained Python application designed to automate the initial stages of a university admissions process. It operates without external dependencies like databases or services, handling all data in-memory.

The system's architecture is modular, composed of four primary components:
1.  **Data Models**: Simple `dataclass` objects represent applicants and application outcomes.
2.  **Configuration**: A centralized, immutable class holds all business rules, weights, and thresholds.
3.  **Core Logic**: Separate classes encapsulate the logic for scoring applicants (`ScoringEngine`), generating reports (`ReportGenerator`), and orchestrating the overall workflow (`UniversityAdmissionsSystem`).
4.  **Application Entry Point**: A `main` function demonstrates a complete execution cycle, from loading data to generating a final report.

This design ensures that the system is maintainable, readable, and easy to modify. For instance, changing the weight of the GPA in the holistic score is a simple one-line change in the `AdmissionsConfiguration` class.

---

## 2. Module: `university_admissions`

This is the main module containing all the code for the application.

### 2.1. Type Aliases

#### `Decision`
A type alias representing the possible outcomes of an application review.

```python
Decision = Literal["Admit", "Waitlist", "Reject"]
```

---

## 3. Data Models

These `dataclasses` define the core data structures used throughout the application, fulfilling **FR1**.

### 3.1. `Applicant`

Represents an individual applicant's data profile.

```python
@dataclass
class Applicant:
    """
    Represents an individual applicant's data.

    FR1: The system shall store applicant data (grades, test scores,
    demographics, geography).
    """
    applicant_id: str
    gpa: float
    test_score: int
    institutional_reputation_score: int
    graduate_outcomes_score: int
    is_first_generation: bool
    is_underrepresented: bool
    is_in_state: bool
```

**Attributes:**

*   `applicant_id` (`str`): A unique identifier for the applicant.
*   `gpa` (`float`): The applicant's Grade Point Average, on a 0.0 to 4.0 scale.
*   `test_score` (`int`): The applicant's standardized test score (e.g., SAT), on a 400 to 1600 scale.
*   `institutional_reputation_score` (`int`): A score from 1-10 representing the reputation of the applicant's prior institution. Used for **FR5**.
*   `graduate_outcomes_score` (`int`): A score from 1-10 representing the historical success of graduates from the applicant's prior institution. Used for **FR5**.
*   `is_first_generation` (`bool`): True if the applicant is the first in their family to attend university.
*   `is_underrepresented` (`bool`): True if the applicant belongs to an underrepresented demographic group.
*   `is_in_state` (`bool`): True if the applicant is an in-state resident.

### 3.2. `ApplicationResult`

Stores the outcome of a single processed application, linking the applicant's data to their calculated score and final decision.

```python
@dataclass
class ApplicationResult:
    """Stores the outcome of a processed application."""
    applicant: Applicant
    holistic_score: float
    decision: Decision
    notes: str = ""
```

**Attributes:**

*   `applicant` (`Applicant`): The original `Applicant` data object.
*   `holistic_score` (`float`): The final computed holistic score, rounded to two decimal places.
*   `decision` (`Decision`): The final admission decision (`Admit`, `Waitlist`, or `Reject`).
*   `notes` (`str`, optional): An optional field for storing notes about the decision process, such as the reason for an automatic rejection. Defaults to `""`.

---

## 4. System Configuration

### 4.1. `AdmissionsConfiguration`

A frozen `dataclass` that centralizes all business rules, weights, and thresholds for the admissions process. Using `frozen=True` makes instances of this class immutable, preventing accidental modification of rules during runtime.

```python
@dataclass(frozen=True)
class AdmissionsConfiguration:
    # ... attributes and property ...
```

**Attributes:**

*   `min_institutional_reputation` (`int`): The minimum institutional reputation score required to pass initial screening (**FR5**). Default: `5`.
*   `min_graduate_outcomes` (`int`): The minimum graduate outcomes score required to pass initial screening (**FR5**). Default: `5`.
*   `academic_weight` (`int`): The percentage weight of the academic component in the final holistic score. Default: `70`.
*   `contextual_weight` (`int`): The percentage weight of the contextual component in the final holistic score. Default: `30`.
*   `gpa_weight` (`float`): The weight of the GPA within the academic component. Must sum to 1.0 with `test_score_weight`. Default: `0.60`.
*   `test_score_weight` (`float`): The weight of the test score within the academic component. Default: `0.40`.
*   `min_test_score` (`int`): The bottom of the test score range for normalization. Default: `400`.
*   `max_test_score` (`int`): The top of the test score range for normalization. Default: `1600`.
*   `max_gpa` (`float`): The top of the GPA scale for normalization. Default: `4.0`.
*   `first_gen_bonus` (`int`): Bonus points awarded for being a first-generation student. Default: `8`.
*   `underrepresented_bonus` (`int`): Bonus points awarded for belonging to an underrepresented group. Default: `8`.
*   `in_state_bonus` (`int`): Bonus points awarded for in-state residency. Default: `5`.
*   `admit_threshold` (`float`): The minimum holistic score required for an "Admit" decision (**FR3**). Default: `80.0`.
*   `waitlist_threshold` (`float`): The minimum holistic score required for a "Waitlist" decision (**FR3**). Default: `65.0`.

**Properties:**

*   **`max_possible_bonus`**
    *   **Description:** Calculates the maximum possible sum of contextual bonus points. This value is used to normalize the contextual score to a 0-100 scale.
    *   **Returns:** (`int`) The sum of all defined bonus points.

---

## 5. Core Logic Classes

### 5.1. `ScoringEngine`

Encapsulates all logic for calculating an applicant's holistic score, fulfilling **FR2**.

```python
class ScoringEngine:
    # ... methods ...
```

#### `__init__(self, config: AdmissionsConfiguration)`

Initializes the scoring engine with a given configuration.

*   **Args:**
    *   `config` (`AdmissionsConfiguration`): An immutable object containing all scoring rules and weights.

#### `calculate_holistic_score(self, applicant: Applicant) -> float`

Computes the final holistic score by combining the weighted academic and contextual scores. This is the primary public method of the class.

*   **Args:**
    *   `applicant` (`Applicant`): The applicant data object to score.
*   **Returns:**
    *   `float`: The final holistic score, on a scale of 0 to 100.

#### `_calculate_academic_score(self, applicant: Applicant) -> float`

(Private) Calculates the academic component of the score. It normalizes GPA and test scores to a common 0-100 scale and then applies the configured sub-weights.

*   **Args:**
    *   `applicant` (`Applicant`): The applicant data object.
*   **Returns:**
    *   `float`: The weighted academic score (0-100).

#### `_calculate_contextual_score(self, applicant: Applicant) -> float`

(Private) Calculates the contextual component of the score. It sums the bonus points based on the applicant's profile and then normalizes the total to a 0-100 scale using `max_possible_bonus`.

*   **Args:**
    *   `applicant` (`Applicant`): The applicant data object.
*   **Returns:**
    *   `float`: The normalized contextual score (0-100).

### 5.2. `ReportGenerator`

Generates a formatted text summary of the admissions cohort, fulfilling **FR4** and **NFR2**.

```python
class ReportGenerator:
    # ... methods ...
```

#### `__init__(self, results: List[ApplicationResult], config: AdmissionsConfiguration)`

Initializes the report generator.

*   **Args:**
    *   `results` (`List[ApplicationResult]`): A list of all processed application results.
    *   `config` (`AdmissionsConfiguration`): The configuration used during the admissions cycle, needed to report on the rules.

#### `generate_report(self) -> str`

Generates the full, multi-section report as a single string. It combines the scoring metrics summary with the cohort statistics.

*   **Returns:**
    *   `str`: The formatted, human-readable report.

#### Private Helper Methods

The class uses several private methods (`_build_metrics_section`, `_build_summary_section`, etc.) to construct different parts of the report. These methods handle the detailed logic for calculating and formatting statistics like decision breakdowns, average GPAs, and demographic profiles of the admitted cohort. The `_build_metrics_section` method specifically addresses **NFR2** by providing a transparent summary of all scoring rules.

### 5.3. `UniversityAdmissionsSystem`

Orchestrates the entire admissions process, from initial data loading to final decision-making. It ensures that the application can run self-contained (**NFR1**).

```python
class UniversityAdmissionsSystem:
    # ... methods ...
```

#### `__init__(self, applicants: List[Applicant], config: AdmissionsConfiguration)`

Initializes the system with a list of applicants and a configuration object.

*   **Args:**
    *   `applicants` (`List[Applicant]`): The list of applicant records to be processed.
    *   `config` (`AdmissionsConfiguration`): The set of rules for the admissions cycle.

**Attributes:**

*   `applicants` (`List[Applicant]`): The input list of applicants.
*   `config` (`AdmissionsConfiguration`): The provided configuration.
*   `scoring_engine` (`ScoringEngine`): An instance of the `ScoringEngine` initialized with the config.
*   `results` (`List[ApplicationResult]`): An empty list that will be populated with `ApplicationResult` objects as applicants are processed.

#### `process_applications(self) -> None`

The main processing loop. It iterates through all applicants, performs initial screening, calculates the holistic score for those who pass, makes a final decision, and stores the result.

*   **Args:** None.
*   **Returns:** `None`. (This method modifies the instance's `self.results` list in-place).

#### `_passes_initial_screening(self, applicant: Applicant) -> bool`

(Private) Checks if an applicant meets the minimum requirements for institutional reputation and graduate outcomes, as defined in the configuration. This method directly implements **FR5**.

*   **Args:**
    *   `applicant` (`Applicant`): The applicant to screen.
*   **Returns:**
    *   `bool`: `True` if the applicant passes screening, `False` otherwise.

#### `_make_decision(self, score: float) -> Decision`

(Private) Determines the admission decision by comparing the holistic score against the thresholds defined in the configuration. This method implements **FR3**.

*   **Args:**
    *   `score` (`float`): The applicant's final holistic score.
*   **Returns:**
    *   `Decision`: The admission decision ("Admit", "Waitlist", or "Reject").

---

## 6. Application Entry Point

These functions are used to execute the application and demonstrate its functionality.

### 6.1. `get_sample_applicants() -> List[Applicant]`

A factory function that provides a diverse set of sample `Applicant` data for demonstration purposes.

*   **Args:** None.
*   **Returns:**
    *   `List[Applicant]`: A list of hardcoded `Applicant` objects.

### 6.2. `main()`

The main function that serves as the application's entry point. It orchestrates the entire process:
1.  Initializes the `AdmissionsConfiguration`.
2.  Loads sample applicant data using `get_sample_applicants`.
3.  Initializes the `UniversityAdmissionsSystem`.
4.  Runs the application processing.
5.  Prints individual results to the console.
6.  Initializes the `ReportGenerator` and prints the final summary report.

This function demonstrates the end-to-end, self-contained execution of the system, fulfilling **NFR1**.

*   **Args:** None.
*   **Returns:** `None`.