# -*- coding: utf-8 -*-
"""
Refactored University Admissions Screening System

This self-contained Python application simulates a university admissions screening
process. It evaluates applicants based on a holistic set of criteria and
generates a summary report of the admissions cohort.

Refactoring Improvements:
- Modularity: Logic is separated into distinct classes for configuration,
  scoring, reporting, and system orchestration.
- Readability: Clearer variable names and helper methods improve code clarity.
- Maintainability: Centralized configuration makes rules easier to update.
- PEP 8 Compliance: Code adheres to Python's official style guide.
"""

import collections
from dataclasses import dataclass
from typing import List, Literal, Counter

# --- Data Models (FR1) ---

Decision = Literal["Admit", "Waitlist", "Reject"]


@dataclass
class Applicant:
    """
    Represents an individual applicant's data.

    FR1: The system shall store applicant data (grades, test scores,
    demographics, geography).
    """
    applicant_id: str
    # Academic data
    gpa: float          # Scale: 0.0 - 4.0
    test_score: int     # Scale: 400 - 1600 (e.g., SAT)
    # Institutional context data for FR5
    institutional_reputation_score: int  # Scale: 1-10
    graduate_outcomes_score: int         # Scale: 1-10
    # Demographics and geography data
    is_first_generation: bool
    is_underrepresented: bool
    is_in_state: bool


@dataclass
class ApplicationResult:
    """Stores the outcome of a processed application."""
    applicant: Applicant
    holistic_score: float
    decision: Decision
    notes: str = ""


# --- System Configuration ---

@dataclass(frozen=True)
class AdmissionsConfiguration:
    """
    Centralizes all rules, weights, and thresholds for the admissions process.
    Making this a frozen dataclass ensures that rules are not accidentally
    modified during runtime.
    """
    # FR5: Initial screening minimum requirements
    min_institutional_reputation: int = 5
    min_graduate_outcomes: int = 5

    # FR2: Holistic Score Weights (must sum to 100)
    academic_weight: int = 70
    contextual_weight: int = 30

    # Academic sub-weights (must sum to 1.0)
    gpa_weight: float = 0.60
    test_score_weight: float = 0.40

    # Test score scale
    min_test_score: int = 400
    max_test_score: int = 1600

    # GPA scale
    max_gpa: float = 4.0

    # Contextual sub-component bonuses (points added to contextual score)
    first_gen_bonus: int = 8
    underrepresented_bonus: int = 8
    in_state_bonus: int = 5

    @property
    def max_possible_bonus(self) -> int:
        """Calculate the maximum possible sum of contextual bonuses."""
        return (self.first_gen_bonus + self.underrepresented_bonus +
                self.in_state_bonus)

    # FR3: Decision Thresholds (based on final holistic score out of 100)
    admit_threshold: float = 80.0
    waitlist_threshold: float = 65.0


# --- Scoring Logic ---

class ScoringEngine:
    """
    Encapsulates all logic for calculating an applicant's holistic score.
    FR2: The system shall compute a holistic admission score for each applicant.
    """
    def __init__(self, config: AdmissionsConfiguration):
        self.config = config

    def _calculate_academic_score(self, applicant: Applicant) -> float:
        """Calculates the weighted academic component of the score."""
        # Normalize GPA and test scores to a common 0-100 scale.
        normalized_gpa = (applicant.gpa / self.config.max_gpa) * 100
        normalized_test_score = (
            (applicant.test_score - self.config.min_test_score) /
            (self.config.max_test_score - self.config.min_test_score)
        ) * 100

        return ((normalized_gpa * self.config.gpa_weight) +
                (normalized_test_score * self.config.test_score_weight))

    def _calculate_contextual_score(self, applicant: Applicant) -> float:
        """Calculates the weighted contextual component of the score."""
        contextual_bonus_points = 0
        if applicant.is_first_generation:
            contextual_bonus_points += self.config.first_gen_bonus
        if applicant.is_underrepresented:
            contextual_bonus_points += self.config.underrepresented_bonus
        if applicant.is_in_state:
            contextual_bonus_points += self.config.in_state_bonus

        # Normalize bonus points to a 0-100 scale.
        if self.config.max_possible_bonus == 0:
            return 0.0
        return (contextual_bonus_points / self.config.max_possible_bonus) * 100

    def calculate_holistic_score(self, applicant: Applicant) -> float:
        """
        Computes the final holistic score from academic and contextual parts.
        """
        academic_score = self._calculate_academic_score(applicant)
        contextual_score = self._calculate_contextual_score(applicant)

        final_score = (
            (academic_score * (self.config.academic_weight / 100)) +
            (contextual_score * (self.config.contextual_weight / 100))
        )
        return final_score


# --- Reporting Logic ---

class ReportGenerator:
    """
    Generates summary reports for the admissions cohort.
    FR4: The system shall generate a summary report of cohort statistics.
    NFR2: The system shall provide transparent scoring metrics in reports.
    """
    def __init__(self,
                 results: List[ApplicationResult],
                 config: AdmissionsConfiguration):
        self.results = results
        self.config = config
        self.admitted_results = [
            r for r in self.results if r.decision == "Admit"
        ]

    def _build_metrics_section(self) -> str:
        """Builds the part of the report detailing scoring metrics."""
        return "\n".join([
            "--- University Admissions Scoring Metrics ---",
            "\n[Initial Screening Criteria]",
            f"  - Minimum Institutional Reputation: {self.config.min_institutional_reputation}/10",
            f"  - Minimum Graduate Outcomes:      {self.config.min_graduate_outcomes}/10",
            "\n[Holistic Score Calculation (Final Score out of 100)]",
            f"  - Overall Academic Weight:        {self.config.academic_weight}%",
            f"  - Overall Contextual Weight:      {self.config.contextual_weight}%",
            "\n  [Academic Sub-Weights]",
            f"    - GPA Weight:                   {self.config.gpa_weight * 100:.0f}%",
            f"    - Test Score Weight:            {self.config.test_score_weight * 100:.0f}%",
            "\n  [Contextual Bonuses]",
            f"    - First-Generation:             +{self.config.first_gen_bonus} points",
            f"    - Underrepresented Group:       +{self.config.underrepresented_bonus} points",
            f"    - In-State Residency:           +{self.config.in_state_bonus} points",
            "\n[Decision Thresholds]",
            f"  - Admit:                          Score >= {self.config.admit_threshold}",
            f"  - Waitlist:                       {self.config.waitlist_threshold} <= Score < {self.config.admit_threshold}",
            f"  - Reject:                         Score < {self.config.waitlist_threshold}",
            "=" * 50
        ])

    def _build_summary_section(self) -> str:
        """Builds the main cohort summary part of the report."""
        if not self.results:
            return "No applications processed."

        lines = [f"\nTotal Applicants Processed: {len(self.results)}"]
        lines.extend(self._build_decision_breakdown())
        lines.extend(self._build_academic_profile())
        lines.extend(self._build_admitted_cohort_profile())
        return "\n".join(lines)

    def _build_decision_breakdown(self) -> List[str]:
        """Creates the decision count and percentage breakdown."""
        total_applicants = len(self.results)
        decisions = [result.decision for result in self.results]
        decision_counts: Counter[Decision] = collections.Counter(decisions)

        lines = ["\n[Decision Breakdown]"]
        for decision_type in ["Admit", "Waitlist", "Reject"]:
            count = decision_counts[decision_type]
            percentage = (count / total_applicants) * 100
            lines.append(
                f"  - {decision_type:<10}: {count:>3} ({percentage:5.1f}%)"
            )
        return lines

    def _build_academic_profile(self) -> List[str]:
        """Creates the academic profile for all and admitted applicants."""
        total_applicants = len(self.results)
        all_gpas = [res.applicant.gpa for res in self.results]
        all_scores = [res.applicant.test_score for res in self.results]
        avg_gpa_total = sum(all_gpas) / total_applicants
        avg_score_total = sum(all_scores) / total_applicants

        lines = ["\n[Academic Profile]"]
        lines.append(f"  - Average GPA (All Applicants):      {avg_gpa_total:.2f}")
        lines.append(f"  - Average Test Score (All):          {avg_score_total:.0f}")

        num_admitted = len(self.admitted_results)
        if num_admitted > 0:
            admitted_gpas = [r.applicant.gpa for r in self.admitted_results]
            admitted_scores = [r.applicant.test_score for r in self.admitted_results]
            avg_gpa_admitted = sum(admitted_gpas) / num_admitted
            avg_score_admitted = sum(admitted_scores) / num_admitted
            lines.append(f"  - Average GPA (Admitted):          {avg_gpa_admitted:.2f}")
            lines.append(f"  - Average Test Score (Admitted):   {avg_score_admitted:.0f}")
        else:
            lines.append("  - No applicants admitted.")
        return lines

    def _build_admitted_cohort_profile(self) -> List[str]:
        """Creates the demographic profile for the admitted cohort."""
        lines = ["\n[Profile of Admitted Cohort]"]
        num_admitted = len(self.admitted_results)
        if num_admitted > 0:
            in_state_count = sum(1 for r in self.admitted_results if r.applicant.is_in_state)
            first_gen_count = sum(1 for r in self.admitted_results if r.applicant.is_first_generation)
            underrepresented_count = sum(1 for r in self.admitted_results if r.applicant.is_underrepresented)

            lines.append(f"  - In-State:           {in_state_count}/{num_admitted} ({(in_state_count/num_admitted)*100:.1f}%)")
            lines.append(f"  - First-Generation:   {first_gen_count}/{num_admitted} ({(first_gen_count/num_admitted)*100:.1f}%)")
            lines.append(f"  - Underrepresented:   {underrepresented_count}/{num_admitted} ({(underrepresented_count/num_admitted)*100:.1f}%)")
        else:
            lines.append("  - No applicants admitted.")
        return lines

    def generate_report(self) -> str:
        """Generates the full report with metrics and cohort summary."""
        metrics_part = self._build_metrics_section()
        summary_title = "\n--- Admissions Cohort Summary Report ---"
        summary_part = self._build_summary_section()

        return f"{metrics_part}\n{summary_title}\n{summary_part}\n{'=' * 50}"


# --- Core System Orchestration ---

class UniversityAdmissionsSystem:
    """
    Orchestrates the admissions process from screening to decision-making.
    """
    def __init__(self,
                 applicants: List[Applicant],
                 config: AdmissionsConfiguration):
        """
        Initializes the system with applicants and a configuration.

        NFR1: The application shall execute without requiring external
        databases or services. Data is handled in-memory.
        """
        self.applicants = applicants
        self.config = config
        self.scoring_engine = ScoringEngine(config)
        self.results: List[ApplicationResult] = []

    def _passes_initial_screening(self, applicant: Applicant) -> bool:
        """
        Checks if an applicant meets minimum institutional criteria.
        FR5: Advance applicants only when institutional reputation and
        graduate outcomes meet minimums.
        """
        return (applicant.institutional_reputation_score >=
                self.config.min_institutional_reputation and
                applicant.graduate_outcomes_score >=
                self.config.min_graduate_outcomes)

    def _make_decision(self, score: float) -> Decision:
        """
        Determines the admission decision based on score thresholds.
        FR3: The system shall automate admission decisions.
        """
        if score >= self.config.admit_threshold:
            return "Admit"
        if score >= self.config.waitlist_threshold:
            return "Waitlist"
        return "Reject"

    def process_applications(self) -> None:
        """
        Processes all applications through screening, scoring, and decision.
        """
        for applicant in self.applicants:
            if not self._passes_initial_screening(applicant):
                result = ApplicationResult(
                    applicant=applicant,
                    holistic_score=0.0,
                    decision="Reject",
                    notes="Failed initial institutional screening."
                )
                self.results.append(result)
                continue

            holistic_score = self.scoring_engine.calculate_holistic_score(applicant)
            decision = self._make_decision(holistic_score)

            result = ApplicationResult(
                applicant=applicant,
                holistic_score=round(holistic_score, 2),
                decision=decision,
                notes="Processed via holistic review."
            )
            self.results.append(result)


# --- Application Entry Point ---

def get_sample_applicants() -> List[Applicant]:
    """Provides a diverse set of sample applicant data for demonstration."""
    return [
        # High-achiever, strong context -> likely Admit
        Applicant(applicant_id="APP-001", gpa=3.9, test_score=1550, is_first_generation=True, is_underrepresented=True, is_in_state=True, institutional_reputation_score=9, graduate_outcomes_score=9),
        # Strong academics, no context -> likely Admit
        Applicant(applicant_id="APP-002", gpa=4.0, test_score=1580, is_first_generation=False, is_underrepresented=False, is_in_state=False, institutional_reputation_score=8, graduate_outcomes_score=8),
        # Borderline academics, strong context -> likely Waitlist/Admit
        Applicant(applicant_id="APP-003", gpa=3.5, test_score=1300, is_first_generation=True, is_underrepresented=True, is_in_state=True, institutional_reputation_score=7, graduate_outcomes_score=6),
        # Average applicant -> likely Waitlist
        Applicant(applicant_id="APP-004", gpa=3.6, test_score=1350, is_first_generation=False, is_underrepresented=False, is_in_state=True, institutional_reputation_score=6, graduate_outcomes_score=7),
        # Fails initial screening (reputation) -> Reject
        Applicant(applicant_id="APP-005", gpa=4.0, test_score=1600, is_first_generation=False, is_underrepresented=False, is_in_state=False, institutional_reputation_score=4, graduate_outcomes_score=9),
        # Fails initial screening (outcomes) -> Reject
        Applicant(applicant_id="APP-006", gpa=3.8, test_score=1400, is_first_generation=True, is_underrepresented=False, is_in_state=True, institutional_reputation_score=8, graduate_outcomes_score=3),
        # Strong test-taker, lower GPA -> likely Waitlist
        Applicant(applicant_id="APP-007", gpa=3.4, test_score=1500, is_first_generation=False, is_underrepresented=False, is_in_state=False, institutional_reputation_score=9, graduate_outcomes_score=8),
        # Solid Waitlist candidate
        Applicant(applicant_id="APP-008", gpa=3.8, test_score=1400, is_first_generation=False, is_underrepresented=False, is_in_state=True, institutional_reputation_score=7, graduate_outcomes_score=7),
        # Weak applicant -> likely Reject
        Applicant(applicant_id="APP-009", gpa=3.1, test_score=1100, is_first_generation=False, is_underrepresented=False, is_in_state=True, institutional_reputation_score=5, graduate_outcomes_score=5),
    ]


def main():
    """
    Main function to initialize, run, and report on the admissions system.
    This demonstrates the self-contained nature of the application (NFR1).
    """
    print("Initializing University Admissions Screening System...")

    # 1. Define the rules for this admissions cycle.
    config = AdmissionsConfiguration()

    # 2. Load applicant data.
    applicants = get_sample_applicants()
    print(f"Loaded {len(applicants)} applicant records for processing.")

    # 3. Initialize the system with data and rules.
    admissions_system = UniversityAdmissionsSystem(applicants, config)

    # 4. Run the core processing logic.
    print("Processing all applications...")
    admissions_system.process_applications()
    print("Processing complete.")

    # 5. Display detailed results for each individual applicant.
    print("\n--- Individual Application Results ---")
    for result in admissions_system.results:
        print(
            f"ID: {result.applicant.applicant_id}, "
            f"Score: {result.holistic_score:5.2f}, "
            f"Decision: {result.decision:<8} "
            f"({result.notes})"
        )
    print("-" * 50)

    # 6. Generate and print the final summary report.
    print("\nGenerating final cohort report...")
    report_generator = ReportGenerator(admissions_system.results, config)
    report = report_generator.generate_report()
    print(report)


if __name__ == "__main__":
    main()