# -*- coding: utf-8 -*-
"""
Comprehensive Unit Test Suite for the University Admissions Screening System.

This suite uses the pytest framework to test the functionality of the admissions
system, covering:
- Data models and configuration immutability.
- Scoring engine logic with edge cases and boundary conditions.
- Core system orchestration for screening and decision-making.
- Report generation for various cohort scenarios.

To run these tests, you will need pytest installed:
`pip install pytest`

Then, execute from your terminal in the same directory as this file:
`pytest`
"""

import pytest
from dataclasses import FrozenInstanceError
from typing import List

# Assume the refactored code is in a file named `admissions_system.py`
# If it's in the same file, we can import directly. For self-containment,
# we will paste the classes here, but a better practice is `from ... import ...`
# For the purpose of this self-contained artifact, we will copy the original code
# and append the tests.

# --- BEGIN REFACTORED CODE (Copied for self-containment) ---

import collections
from dataclasses import dataclass
from typing import List, Literal, Counter

# --- Data Models (FR1) ---

Decision = Literal["Admit", "Waitlist", "Reject"]


@dataclass
class Applicant:
    """
    Represents an individual applicant's data.

    FR1: The system shall store applicant data (grades, test scores,
    demographics, geography).
    """
    applicant_id: str
    # Academic data
    gpa: float          # Scale: 0.0 - 4.0
    test_score: int     # Scale: 400 - 1600 (e.g., SAT)
    # Institutional context data for FR5
    institutional_reputation_score: int  # Scale: 1-10
    graduate_outcomes_score: int         # Scale: 1-10
    # Demographics and geography data
    is_first_generation: bool
    is_underrepresented: bool
    is_in_state: bool


@dataclass
class ApplicationResult:
    """Stores the outcome of a processed application."""
    applicant: Applicant
    holistic_score: float
    decision: Decision
    notes: str = ""


# --- System Configuration ---

@dataclass(frozen=True)
class AdmissionsConfiguration:
    """
    Centralizes all rules, weights, and thresholds for the admissions process.
    Making this a frozen dataclass ensures that rules are not accidentally
    modified during runtime.
    """
    # FR5: Initial screening minimum requirements
    min_institutional_reputation: int = 5
    min_graduate_outcomes: int = 5

    # FR2: Holistic Score Weights (must sum to 100)
    academic_weight: int = 70
    contextual_weight: int = 30

    # Academic sub-weights (must sum to 1.0)
    gpa_weight: float = 0.60
    test_score_weight: float = 0.40

    # Test score scale
    min_test_score: int = 400
    max_test_score: int = 1600

    # GPA scale
    max_gpa: float = 4.0

    # Contextual sub-component bonuses (points added to contextual score)
    first_gen_bonus: int = 8
    underrepresented_bonus: int = 8
    in_state_bonus: int = 5

    @property
    def max_possible_bonus(self) -> int:
        """Calculate the maximum possible sum of contextual bonuses."""
        return (self.first_gen_bonus + self.underrepresented_bonus +
                self.in_state_bonus)

    # FR3: Decision Thresholds (based on final holistic score out of 100)
    admit_threshold: float = 80.0
    waitlist_threshold: float = 65.0


# --- Scoring Logic ---

class ScoringEngine:
    """
    Encapsulates all logic for calculating an applicant's holistic score.
    FR2: The system shall compute a holistic admission score for each applicant.
    """
    def __init__(self, config: AdmissionsConfiguration):
        self.config = config

    def _calculate_academic_score(self, applicant: Applicant) -> float:
        """Calculates the weighted academic component of the score."""
        # Normalize GPA and test scores to a common 0-100 scale.
        normalized_gpa = (applicant.gpa / self.config.max_gpa) * 100
        normalized_test_score = (
            (applicant.test_score - self.config.min_test_score) /
            (self.config.max_test_score - self.config.min_test_score)
        ) * 100

        return ((normalized_gpa * self.config.gpa_weight) +
                (normalized_test_score * self.config.test_score_weight))

    def _calculate_contextual_score(self, applicant: Applicant) -> float:
        """Calculates the weighted contextual component of the score."""
        contextual_bonus_points = 0
        if applicant.is_first_generation:
            contextual_bonus_points += self.config.first_gen_bonus
        if applicant.is_underrepresented:
            contextual_bonus_points += self.config.underrepresented_bonus
        if applicant.is_in_state:
            contextual_bonus_points += self.config.in_state_bonus

        # Normalize bonus points to a 0-100 scale.
        if self.config.max_possible_bonus == 0:
            return 0.0
        return (contextual_bonus_points / self.config.max_possible_bonus) * 100

    def calculate_holistic_score(self, applicant: Applicant) -> float:
        """
        Computes the final holistic score from academic and contextual parts.
        """
        academic_score = self._calculate_academic_score(applicant)
        contextual_score = self._calculate_contextual_score(applicant)

        final_score = (
            (academic_score * (self.config.academic_weight / 100)) +
            (contextual_score * (self.config.contextual_weight / 100))
        )
        return final_score


# --- Reporting Logic ---

class ReportGenerator:
    """
    Generates summary reports for the admissions cohort.
    FR4: The system shall generate a summary report of cohort statistics.
    NFR2: The system shall provide transparent scoring metrics in reports.
    """
    def __init__(self,
                 results: List[ApplicationResult],
                 config: AdmissionsConfiguration):
        self.results = results
        self.config = config
        self.admitted_results = [
            r for r in self.results if r.decision == "Admit"
        ]

    def _build_metrics_section(self) -> str:
        """Builds the part of the report detailing scoring metrics."""
        return "\n".join([
            "--- University Admissions Scoring Metrics ---",
            "\n[Initial Screening Criteria]",
            f"  - Minimum Institutional Reputation: {self.config.min_institutional_reputation}/10",
            f"  - Minimum Graduate Outcomes:      {self.config.min_graduate_outcomes}/10",
            "\n[Holistic Score Calculation (Final Score out of 100)]",
            f"  - Overall Academic Weight:        {self.config.academic_weight}%",
            f"  - Overall Contextual Weight:      {self.config.contextual_weight}%",
            "\n  [Academic Sub-Weights]",
            f"    - GPA Weight:                   {self.config.gpa_weight * 100:.0f}%",
            f"    - Test Score Weight:            {self.config.test_score_weight * 100:.0f}%",
            "\n  [Contextual Bonuses]",
            f"    - First-Generation:             +{self.config.first_gen_bonus} points",
            f"    - Underrepresented Group:       +{self.config.underrepresented_bonus} points",
            f"    - In-State Residency:           +{self.config.in_state_bonus} points",
            "\n[Decision Thresholds]",
            f"  - Admit:                          Score >= {self.config.admit_threshold}",
            f"  - Waitlist:                       {self.config.waitlist_threshold} <= Score < {self.config.admit_threshold}",
            f"  - Reject:                         Score < {self.config.waitlist_threshold}",
            "=" * 50
        ])

    def _build_summary_section(self) -> str:
        """Builds the main cohort summary part of the report."""
        if not self.results:
            return "No applications processed."

        lines = [f"\nTotal Applicants Processed: {len(self.results)}"]
        lines.extend(self._build_decision_breakdown())
        lines.extend(self._build_academic_profile())
        lines.extend(self._build_admitted_cohort_profile())
        return "\n".join(lines)

    def _build_decision_breakdown(self) -> List[str]:
        """Creates the decision count and percentage breakdown."""
        total_applicants = len(self.results)
        decisions = [result.decision for result in self.results]
        decision_counts: Counter[Decision] = collections.Counter(decisions)

        lines = ["\n[Decision Breakdown]"]
        for decision_type in ["Admit", "Waitlist", "Reject"]:
            count = decision_counts[decision_type]
            percentage = (count / total_applicants) * 100
            lines.append(
                f"  - {decision_type:<10}: {count:>3} ({percentage:5.1f}%)"
            )
        return lines

    def _build_academic_profile(self) -> List[str]:
        """Creates the academic profile for all and admitted applicants."""
        if not self.results:
            return []
        total_applicants = len(self.results)
        all_gpas = [res.applicant.gpa for res in self.results]
        all_scores = [res.applicant.test_score for res in self.results]
        avg_gpa_total = sum(all_gpas) / total_applicants
        avg_score_total = sum(all_scores) / total_applicants

        lines = ["\n[Academic Profile]"]
        lines.append(f"  - Average GPA (All Applicants):      {avg_gpa_total:.2f}")
        lines.append(f"  - Average Test Score (All):          {avg_score_total:.0f}")

        num_admitted = len(self.admitted_results)
        if num_admitted > 0:
            admitted_gpas = [r.applicant.gpa for r in self.admitted_results]
            admitted_scores = [r.applicant.test_score for r in self.admitted_results]
            avg_gpa_admitted = sum(admitted_gpas) / num_admitted
            avg_score_admitted = sum(admitted_scores) / num_admitted
            lines.append(f"  - Average GPA (Admitted):          {avg_gpa_admitted:.2f}")
            lines.append(f"  - Average Test Score (Admitted):   {avg_score_admitted:.0f}")
        else:
            lines.append("  - No applicants admitted.")
        return lines

    def _build_admitted_cohort_profile(self) -> List[str]:
        """Creates the demographic profile for the admitted cohort."""
        lines = ["\n[Profile of Admitted Cohort]"]
        num_admitted = len(self.admitted_results)
        if num_admitted > 0:
            in_state_count = sum(1 for r in self.admitted_results if r.applicant.is_in_state)
            first_gen_count = sum(1 for r in self.admitted_results if r.applicant.is_first_generation)
            underrepresented_count = sum(1 for r in self.admitted_results if r.applicant.is_underrepresented)

            lines.append(f"  - In-State:           {in_state_count}/{num_admitted} ({(in_state_count/num_admitted)*100:.1f}%)")
            lines.append(f"  - First-Generation:   {first_gen_count}/{num_admitted} ({(first_gen_count/num_admitted)*100:.1f}%)")
            lines.append(f"  - Underrepresented:   {underrepresented_count}/{num_admitted} ({(underrepresented_count/num_admitted)*100:.1f}%)")
        else:
            lines.append("  - No applicants admitted.")
        return lines

    def generate_report(self) -> str:
        """Generates the full report with metrics and cohort summary."""
        metrics_part = self._build_metrics_section()
        summary_title = "\n--- Admissions Cohort Summary Report ---"
        summary_part = self._build_summary_section()

        return f"{metrics_part}\n{summary_title}\n{summary_part}\n{'=' * 50}"


# --- Core System Orchestration ---

class UniversityAdmissionsSystem:
    """
    Orchestrates the admissions process from screening to decision-making.
    """
    def __init__(self,
                 applicants: List[Applicant],
                 config: AdmissionsConfiguration):
        """
        Initializes the system with applicants and a configuration.

        NFR1: The application shall execute without requiring external
        databases or services. Data is handled in-memory.
        """
        self.applicants = applicants
        self.config = config
        self.scoring_engine = ScoringEngine(config)
        self.results: List[ApplicationResult] = []

    def _passes_initial_screening(self, applicant: Applicant) -> bool:
        """
        Checks if an applicant meets minimum institutional criteria.
        FR5: Advance applicants only when institutional reputation and
        graduate outcomes meet minimums.
        """
        return (applicant.institutional_reputation_score >=
                self.config.min_institutional_reputation and
                applicant.graduate_outcomes_score >=
                self.config.min_graduate_outcomes)

    def _make_decision(self, score: float) -> Decision:
        """
        Determines the admission decision based on score thresholds.
        FR3: The system shall automate admission decisions.
        """
        if score >= self.config.admit_threshold:
            return "Admit"
        if score >= self.config.waitlist_threshold:
            return "Waitlist"
        return "Reject"

    def process_applications(self) -> None:
        """
        Processes all applications through screening, scoring, and decision.
        """
        for applicant in self.applicants:
            if not self._passes_initial_screening(applicant):
                result = ApplicationResult(
                    applicant=applicant,
                    holistic_score=0.0,
                    decision="Reject",
                    notes="Failed initial institutional screening."
                )
                self.results.append(result)
                continue

            holistic_score = self.scoring_engine.calculate_holistic_score(applicant)
            decision = self._make_decision(holistic_score)

            result = ApplicationResult(
                applicant=applicant,
                holistic_score=round(holistic_score, 2),
                decision=decision,
                notes="Processed via holistic review."
            )
            self.results.append(result)

# --- END REFACTORED CODE ---


# --- BEGIN UNIT TEST SUITE ---

@pytest.fixture
def default_config() -> AdmissionsConfiguration:
    """Provides a default admissions configuration for tests."""
    return AdmissionsConfiguration()


@pytest.fixture
def perfect_applicant() -> Applicant:
    """An applicant with maximum possible scores and all contextual bonuses."""
    return Applicant(
        applicant_id="PERFECT-01",
        gpa=4.0,
        test_score=1600,
        institutional_reputation_score=10,
        graduate_outcomes_score=10,
        is_first_generation=True,
        is_underrepresented=True,
        is_in_state=True,
    )


@pytest.fixture
def minimum_applicant() -> Applicant:
    """An applicant with minimum possible scores and no contextual bonuses."""
    return Applicant(
        applicant_id="MINIMUM-01",
        gpa=0.0,
        test_score=400,
        institutional_reputation_score=5,
        graduate_outcomes_score=5,
        is_first_generation=False,
        is_underrepresented=False,
        is_in_state=False,
    )


@pytest.fixture
def average_applicant() -> Applicant:
    """A mid-range applicant for standard case testing."""
    return Applicant(
        applicant_id="AVG-01",
        gpa=3.5,
        test_score=1300,
        institutional_reputation_score=7,
        graduate_outcomes_score=7,
        is_first_generation=False,
        is_underrepresented=False,
        is_in_state=True,
    )


class TestAdmissionsConfiguration:
    """Tests for the AdmissionsConfiguration dataclass."""

    def test_default_values(self, default_config: AdmissionsConfiguration):
        """Ensures default configuration values are set as expected."""
        assert default_config.min_institutional_reputation == 5
        assert default_config.admit_threshold == 80.0
        assert default_config.academic_weight == 70
        assert default_config.gpa_weight == 0.60

    def test_custom_values(self):
        """Ensures the configuration can be initialized with custom values."""
        custom_config = AdmissionsConfiguration(
            admit_threshold=90.0, academic_weight=50, contextual_weight=50
        )
        assert custom_config.admit_threshold == 90.0
        assert custom_config.academic_weight == 50
        assert custom_config.contextual_weight == 50

    def test_is_frozen(self, default_config: AdmissionsConfiguration):
        """Verifies that the configuration is immutable (frozen)."""
        with pytest.raises(FrozenInstanceError):
            default_config.admit_threshold = 95.0

    def test_max_possible_bonus_property(self, default_config: AdmissionsConfiguration):
        """Tests the calculation of the max_possible_bonus property."""
        expected_bonus = (
            default_config.first_gen_bonus
            + default_config.underrepresented_bonus
            + default_config.in_state_bonus
        )
        assert default_config.max_possible_bonus == expected_bonus
        assert default_config.max_possible_bonus == 21

    def test_max_possible_bonus_zero(self):
        """Tests the bonus property when all bonus values are zero."""
        zero_bonus_config = AdmissionsConfiguration(
            first_gen_bonus=0, underrepresented_bonus=0, in_state_bonus=0
        )
        assert zero_bonus_config.max_possible_bonus == 0


class TestScoringEngine:
    """Tests for the ScoringEngine class."""

    @pytest.fixture
    def engine(self, default_config: AdmissionsConfiguration) -> ScoringEngine:
        """Provides a ScoringEngine instance with default config."""
        return ScoringEngine(default_config)

    def test_academic_score_perfect(self, engine: ScoringEngine, perfect_applicant: Applicant):
        """A perfect academic record should yield a score of 100."""
        score = engine._calculate_academic_score(perfect_applicant)
        assert score == pytest.approx(100.0)

    def test_academic_score_minimum(self, engine: ScoringEngine, minimum_applicant: Applicant):
        """A minimum academic record should yield a score of 0."""
        score = engine._calculate_academic_score(minimum_applicant)
        assert score == pytest.approx(0.0)

    def test_academic_score_mid_range(self, engine: ScoringEngine, average_applicant: Applicant):
        """Tests academic score calculation for an average applicant."""
        # GPA 3.5/4.0 -> 87.5 normalized
        # Test Score 1300 -> (1300-400)/(1600-400) = 900/1200 = 0.75 -> 75 normalized
        # Weighted: (87.5 * 0.6) + (75 * 0.4) = 52.5 + 30 = 82.5
        score = engine._calculate_academic_score(average_applicant)
        assert score == pytest.approx(82.5)

    def test_contextual_score_all_bonuses(self, engine: ScoringEngine, perfect_applicant: Applicant):
        """An applicant with all bonuses should have a contextual score of 100."""
        score = engine._calculate_contextual_score(perfect_applicant)
        assert score == pytest.approx(100.0)

    def test_contextual_score_no_bonuses(self, engine: ScoringEngine, minimum_applicant: Applicant):
        """An applicant with no bonuses should have a contextual score of 0."""
        score = engine._calculate_contextual_score(minimum_applicant)
        assert score == pytest.approx(0.0)

    def test_contextual_score_some_bonuses(self, engine: ScoringEngine, average_applicant: Applicant):
        """Tests contextual score for an applicant with only the in-state bonus."""
        # Only in-state bonus: 5 points
        # Max bonus: 21 points
        # Score: (5 / 21) * 100 = 23.8095...
        score = engine._calculate_contextual_score(average_applicant)
        assert score == pytest.approx((5 / 21) * 100)

    def test_contextual_score_zero_max_bonus_edge_case(self):
        """Test contextual score calculation when max bonus is 0 to avoid ZeroDivisionError."""
        zero_bonus_config = AdmissionsConfiguration(
            first_gen_bonus=0, underrepresented_bonus=0, in_state_bonus=0
        )
        engine = ScoringEngine(zero_bonus_config)
        # Applicant has no bonuses, but it shouldn't matter
        applicant = Applicant("Z-01", 3.0, 1200, 8, 8, False, False, False)
        assert engine._calculate_contextual_score(applicant) == 0.0

    def test_holistic_score_perfect(self, engine: ScoringEngine, perfect_applicant: Applicant):
        """A perfect applicant should have a final holistic score of 100."""
        # Academic: 100, Contextual: 100
        # Holistic: (100 * 0.7) + (100 * 0.3) = 100
        score = engine.calculate_holistic_score(perfect_applicant)
        assert score == pytest.approx(100.0)

    def test_holistic_score_minimum(self, engine: ScoringEngine, minimum_applicant: Applicant):
        """A minimum applicant should have a final holistic score of 0."""
        # Academic: 0, Contextual: 0
        # Holistic: (0 * 0.7) + (0 * 0.3) = 0
        score = engine.calculate_holistic_score(minimum_applicant)
        assert score == pytest.approx(0.0)

    def test_holistic_score_average(self, engine: ScoringEngine, average_applicant: Applicant):
        """Tests the final weighted holistic score for an average applicant."""
        # Academic: 82.5, Contextual: 23.8095
        # Holistic: (82.5 * 0.7) + (23.8095 * 0.3) = 57.75 + 7.14285 = 64.89285
        score = engine.calculate_holistic_score(average_applicant)
        assert score == pytest.approx(64.89, abs=0.01)

    def test_holistic_score_weighting(self, average_applicant: Applicant):
        """Tests that changing weights correctly impacts the final score."""
        academic_heavy_config = AdmissionsConfiguration(academic_weight=100, contextual_weight=0)
        engine = ScoringEngine(academic_heavy_config)
        # Should only be the academic score of 82.5
        assert engine.calculate_holistic_score(average_applicant) == pytest.approx(82.5)

        contextual_heavy_config = AdmissionsConfiguration(academic_weight=0, contextual_weight=100)
        engine = ScoringEngine(contextual_heavy_config)
        # Should only be the contextual score of approx 23.81
        assert engine.calculate_holistic_score(average_applicant) == pytest.approx(23.81, abs=0.01)


class TestUniversityAdmissionsSystem:
    """Tests for the main system orchestration class."""

    @pytest.mark.parametrize(
        "rep_score, out_score, expected",
        [
            (5, 5, True),   # Boundary: Exactly meets minimums
            (6, 8, True),   # Clearly passes
            (4, 9, False),  # Fails on reputation
            (9, 3, False),  # Fails on outcomes
            (3, 2, False),  # Fails on both
        ]
    )
    def test_initial_screening(self, default_config: AdmissionsConfiguration, rep_score, out_score, expected):
        """Tests the initial screening logic for FR5."""
        system = UniversityAdmissionsSystem([], default_config)
        applicant = Applicant("SCR-01", 4.0, 1600, rep_score, out_score, False, False, False)
        assert system._passes_initial_screening(applicant) is expected

    @pytest.mark.parametrize(
        "score, expected_decision",
        [
            (95.0, "Admit"),
            (80.0, "Admit"),       # Boundary: Admit threshold
            (79.9, "Waitlist"),
            (70.0, "Waitlist"),
            (65.0, "Waitlist"),    # Boundary: Waitlist threshold
            (64.9, "Reject"),
            (30.0, "Reject"),
        ]
    )
    def test_make_decision(self, default_config: AdmissionsConfiguration, score, expected_decision):
        """Tests the decision logic based on score thresholds for FR3."""
        system = UniversityAdmissionsSystem([], default_config)
        assert system._make_decision(score) == expected_decision

    def test_process_applications(self, default_config: AdmissionsConfiguration):
        """Tests the full application processing workflow."""
        applicant_admit = Applicant("ADM-01", 3.9, 1500, 8, 8, False, True, True) # Score > 80
        applicant_waitlist = Applicant("WLS-01", 3.6, 1350, 7, 7, False, False, True) # Score ~ 65-80
        applicant_reject_score = Applicant("REJ-01", 3.0, 1100, 6, 6, False, False, False) # Score < 65
        applicant_reject_screen = Applicant("SCR-01", 4.0, 1600, 3, 9, False, False, False) # Fails screening

        applicants = [
            applicant_admit, applicant_waitlist,
            applicant_reject_score, applicant_reject_screen
        ]
        system = UniversityAdmissionsSystem(applicants, default_config)
        system.process_applications()

        results = {res.applicant.applicant_id: res for res in system.results}
        assert len(results) == 4

        # Check screening failure
        assert results["SCR-01"].decision == "Reject"
        assert results["SCR-01"].holistic_score == 0.0
        assert "screening" in results["SCR-01"].notes

        # Check decision outcomes
        assert results["ADM-01"].decision == "Admit"
        assert results["WLS-01"].decision == "Waitlist"
        assert results["REJ-01"].decision == "Reject"
        assert "holistic review" in results["ADM-01"].notes


class TestReportGenerator:
    """Tests for the ReportGenerator class."""

    def test_empty_report(self, default_config: AdmissionsConfiguration):
        """Tests report generation when no applications have been processed."""
        generator = ReportGenerator([], default_config)
        report = generator.generate_report()
        assert "No applications processed." in report
        assert "Total Applicants Processed: 0" not in report

    def test_report_with_no_admitted_students(self, default_config: AdmissionsConfiguration):
        """Tests report generation when there are results but no one was admitted."""
        app1 = Applicant("W-01", 3.5, 1300, 7, 7, False, False, True)
        app2 = Applicant("R-01", 3.1, 1100, 5, 5, False, False, False)
        results = [
            ApplicationResult(app1, 68.0, "Waitlist"),
            ApplicationResult(app2, 55.0, "Reject")
        ]
        generator = ReportGenerator(results, default_config)
        report = generator.generate_report()

        assert "Total Applicants Processed: 2" in report
        assert "Admit:           0 (" in report
        assert "No applicants admitted." in report

    def test_full_report_generation(self, default_config: AdmissionsConfiguration):
        """Tests a complete report with a mix of decisions."""
        app_admit = Applicant("A-01", 4.0, 1550, 9, 9, True, True, True)
        app_waitlist = Applicant("W-01", 3.5, 1300, 7, 7, False, False, True)
        app_reject = Applicant("R-01", 3.1, 1100, 5, 5, False, False, False)
        app_reject2 = Applicant("R-02", 3.2, 1150, 5, 5, False, False, False)

        results = [
            ApplicationResult(app_admit, 93.5, "Admit"),
            ApplicationResult(app_waitlist, 68.3, "Waitlist"),
            ApplicationResult(app_reject, 55.1, "Reject"),
            ApplicationResult(app_reject2, 58.9, "Reject"),
        ]
        generator = ReportGenerator(results, default_config)
        report = generator.generate_report()

        # NFR2: Check for transparent metrics
        assert "[Initial Screening Criteria]" in report
        assert f"Admit:                          Score >= {default_config.admit_threshold}" in report
        assert f"Overall Academic Weight:        {default_config.academic_weight}%" in report

        # FR4: Check summary stats
        assert "Total Applicants Processed: 4" in report
        assert "Admit:           1 ( 25.0%)" in report
        assert "Waitlist:        1 ( 25.0%)" in report
        assert "Reject:          2 ( 50.0%)" in report

        # Check academic averages
        avg_gpa_all = (4.0 + 3.5 + 3.1 + 3.2) / 4
        assert f"Average GPA (All Applicants):      {avg_gpa_all:.2f}" in report
        assert "Average GPA (Admitted):          4.00" in report

        # Check admitted cohort profile
        assert "In-State:           1/1 (100.0%)" in report
        assert "First-Generation:   1/1 (100.0%)" in report
        assert "Underrepresented:   1/1 (100.0%)" in report

# --- END UNIT TEST SUITE ---