# -*- coding: utf-8 -*-
"""
University Admissions Screening System

This self-contained Python application simulates a university admissions screening
process. It evaluates applicants based on a holistic set of criteria and
generates a summary report of the admissions cohort.
"""

import collections
from dataclasses import dataclass
from typing import List, Literal

# --- Data Models (FR1) ---

Decision = Literal["Admit", "Waitlist", "Reject"]

@dataclass
class Applicant:
    """
    Represents an individual applicant's data.

    FR1: The system shall store applicant data (grades, test scores,
    demographics, geography).
    """
    applicant_id: str
    # Academic data
    gpa: float          # Scale: 0.0 - 4.0
    test_score: int     # Scale: 400 - 1600 (e.g., SAT)
    # Institutional context data for FR5
    institutional_reputation_score: int # Scale: 1-10
    graduate_outcomes_score: int        # Scale: 1-10
    # Demographics and geography data
    is_first_generation: bool
    is_underrepresented: bool
    is_in_state: bool


@dataclass
class ApplicationResult:
    """Stores the outcome of a processed application."""
    applicant: Applicant
    holistic_score: float
    decision: Decision
    notes: str = ""


# --- Core System Logic ---

class UniversityAdmissionsSystem:
    """
    Orchestrates the entire admissions process from screening to reporting.
    """

    # --- System Configuration ---
    # These constants define the rules of the admissions process.

    # FR5: Initial screening minimum requirements
    MIN_INSTITUTIONAL_REPUTATION = 5
    MIN_GRADUATE_OUTCOMES = 5

    # FR2: Holistic Score Weights (must sum to 100)
    ACADEMIC_WEIGHT = 70
    CONTEXTUAL_WEIGHT = 30

    # Academic sub-weights (must sum to 1.0)
    GPA_WEIGHT = 0.60
    TEST_SCORE_WEIGHT = 0.40

    # Contextual sub-component bonuses (points added to contextual score)
    FIRST_GEN_BONUS = 8
    UNDERREPRESENTED_BONUS = 8
    IN_STATE_BONUS = 5
    MAX_POSSIBLE_BONUS = FIRST_GEN_BONUS + UNDERREPRESENTED_BONUS + IN_STATE_BONUS

    # FR3: Decision Thresholds (based on final holistic score out of 100)
    ADMIT_THRESHOLD = 80.0
    WAITLIST_THRESHOLD = 65.0

    def __init__(self, applicants: List[Applicant]):
        """
        Initializes the system with a list of applicants.
        
        NFR1: The application shall execute without requiring external databases
        or services. Data is handled in-memory.
        """
        self.applicants = applicants
        self.results: List[ApplicationResult] = []

    def process_applications(self) -> None:
        """
        Processes all applications through screening, scoring, and decision-making.
        """
        if not self.applicants:
            return

        for applicant in self.applicants:
            # FR5: Initial screening step
            if (applicant.institutional_reputation_score < self.MIN_INSTITUTIONAL_REPUTATION or
                    applicant.graduate_outcomes_score < self.MIN_GRADUATE_OUTCOMES):
                result = ApplicationResult(
                    applicant=applicant,
                    holistic_score=0.0,
                    decision="Reject",
                    notes="Failed initial institutional screening."
                )
                self.results.append(result)
                continue

            # FR2: Compute the holistic score for applicants who pass screening
            holistic_score = self._calculate_holistic_score(applicant)

            # FR3: Automate the admission decision based on the score
            decision = self._make_decision(holistic_score)

            result = ApplicationResult(
                applicant=applicant,
                holistic_score=round(holistic_score, 2),
                decision=decision,
                notes="Processed via holistic review."
            )
            self.results.append(result)

    def _calculate_holistic_score(self, applicant: Applicant) -> float:
        """
        Computes a holistic score based on configured weights and bonuses.
        The score is a weighted average of academic and contextual factors.
        """
        # --- 1. Calculate Academic Component ---
        # Normalize GPA and test scores to a common 0-100 scale for weighting.
        normalized_gpa = (applicant.gpa / 4.0) * 100
        normalized_test_score = ((applicant.test_score - 400) / (1600 - 400)) * 100

        academic_score = (normalized_gpa * self.GPA_WEIGHT) + \
                         (normalized_test_score * self.TEST_SCORE_WEIGHT)

        # --- 2. Calculate Contextual Component ---
        # Sum bonus points for contextual factors.
        contextual_bonus_points = 0
        if applicant.is_first_generation:
            contextual_bonus_points += self.FIRST_GEN_BONUS
        if applicant.is_underrepresented:
            contextual_bonus_points += self.UNDERREPRESENTED_BONUS
        if applicant.is_in_state:
            contextual_bonus_points += self.IN_STATE_BONUS
        
        # Normalize bonus points to a 0-100 scale to align with the academic score.
        contextual_score = (contextual_bonus_points / self.MAX_POSSIBLE_BONUS) * 100

        # --- 3. Combine Components for Final Score ---
        # Apply the main weights to get the final holistic score.
        final_score = (academic_score * (self.ACADEMIC_WEIGHT / 100)) + \
                      (contextual_score * (self.CONTEXTUAL_WEIGHT / 100))

        return final_score

    def _make_decision(self, score: float) -> Decision:
        """Determines admission decision based on score thresholds."""
        if score >= self.ADMIT_THRESHOLD:
            return "Admit"
        elif score >= self.WAITLIST_THRESHOLD:
            return "Waitlist"
        else:
            return "Reject"

    def generate_report(self) -> str:
        """
        Generates a summary report of cohort statistics and scoring metrics.
        This fulfills both FR4 and NFR2.
        """
        report_lines = []
        
        # NFR2: Provide transparent scoring metrics in the report.
        report_lines.append("--- University Admissions Scoring Metrics ---")
        report_lines.append("\n[Initial Screening Criteria]")
        report_lines.append(f"  - Minimum Institutional Reputation: {self.MIN_INSTITUTIONAL_REPUTATION}/10")
        report_lines.append(f"  - Minimum Graduate Outcomes:      {self.MIN_GRADUATE_OUTCOMES}/10")
        
        report_lines.append("\n[Holistic Score Calculation (Final Score out of 100)]")
        report_lines.append(f"  - Overall Academic Weight:        {self.ACADEMIC_WEIGHT}%")
        report_lines.append(f"  - Overall Contextual Weight:      {self.CONTEXTUAL_WEIGHT}%")
        
        report_lines.append("\n  [Academic Sub-Weights]")
        report_lines.append(f"    - GPA Weight:                   {self.GPA_WEIGHT * 100:.0f}%")
        report_lines.append(f"    - Test Score Weight:            {self.TEST_SCORE_WEIGHT * 100:.0f}%")
        
        report_lines.append("\n  [Contextual Bonuses]")
        report_lines.append(f"    - First-Generation:             +{self.FIRST_GEN_BONUS} points")
        report_lines.append(f"    - Underrepresented Group:       +{self.UNDERREPRESENTED_BONUS} points")
        report_lines.append(f"    - In-State Residency:           +{self.IN_STATE_BONUS} points")
        
        report_lines.append("\n[Decision Thresholds]")
        report_lines.append(f"  - Admit:                          Score >= {self.ADMIT_THRESHOLD}")
        report_lines.append(f"  - Waitlist:                       {self.WAITLIST_THRESHOLD} <= Score < {self.ADMIT_THRESHOLD}")
        report_lines.append(f"  - Reject:                         Score < {self.WAITLIST_THRESHOLD}")
        report_lines.append("=" * 50)
        
        # FR4: Generate a summary report of cohort statistics.
        report_lines.append("\n--- Admissions Cohort Summary Report ---")
        if not self.results:
            report_lines.append("No applications processed.")
            return "\n".join(report_lines)

        total_applicants = len(self.results)
        decisions = [res.decision for res in self.results]
        decision_counts = collections.Counter(decisions)

        admitted_results = [res for res in self.results if res.decision == "Admit"]
        num_admitted = len(admitted_results)

        report_lines.append(f"\nTotal Applicants Processed: {total_applicants}")
        
        report_lines.append("\n[Decision Breakdown]")
        for decision_type in ["Admit", "Waitlist", "Reject"]:
            count = decision_counts[decision_type]
            percentage = (count / total_applicants) * 100 if total_applicants > 0 else 0
            report_lines.append(f"  - {decision_type:<10}: {count:>3} ({percentage:5.1f}%)")

        report_lines.append("\n[Academic Profile]")
        all_gpas = [res.applicant.gpa for res in self.results]
        all_scores = [res.applicant.test_score for res in self.results]
        avg_gpa_total = sum(all_gpas) / total_applicants if total_applicants > 0 else 0
        avg_score_total = sum(all_scores) / total_applicants if total_applicants > 0 else 0
        report_lines.append(f"  - Average GPA (All Applicants):      {avg_gpa_total:.2f}")
        report_lines.append(f"  - Average Test Score (All):          {avg_score_total:.0f}")

        if num_admitted > 0:
            admitted_gpas = [res.applicant.gpa for res in admitted_results]
            admitted_scores = [res.applicant.test_score for res in admitted_results]
            avg_gpa_admitted = sum(admitted_gpas) / num_admitted
            avg_score_admitted = sum(admitted_scores) / num_admitted
            report_lines.append(f"  - Average GPA (Admitted):          {avg_gpa_admitted:.2f}")
            report_lines.append(f"  - Average Test Score (Admitted):   {avg_score_admitted:.0f}")
        else:
            report_lines.append("  - No applicants admitted.")

        report_lines.append("\n[Profile of Admitted Cohort]")
        if num_admitted > 0:
            in_state = sum(1 for res in admitted_results if res.applicant.is_in_state)
            first_gen = sum(1 for res in admitted_results if res.applicant.is_first_generation)
            urm = sum(1 for res in admitted_results if res.applicant.is_underrepresented)
            
            report_lines.append(f"  - In-State:           {in_state}/{num_admitted} ({(in_state/num_admitted)*100:.1f}%)")
            report_lines.append(f"  - First-Generation:   {first_gen}/{num_admitted} ({(first_gen/num_admitted)*100:.1f}%)")
            report_lines.append(f"  - Underrepresented:   {urm}/{num_admitted} ({(urm/num_admitted)*100:.1f}%)")
        else:
            report_lines.append("  - No applicants admitted.")
            
        report_lines.append("=" * 50)

        return "\n".join(report_lines)

# --- Application Entry Point ---

def get_sample_applicants() -> List[Applicant]:
    """Provides a diverse set of sample applicant data for demonstration."""
    return [
        # High-achiever, strong context -> likely Admit
        Applicant(applicant_id="APP-001", gpa=3.9, test_score=1550, is_first_generation=True, is_underrepresented=True, is_in_state=True, institutional_reputation_score=9, graduate_outcomes_score=9),
        # Strong academics, no context -> likely Admit
        Applicant(applicant_id="APP-002", gpa=4.0, test_score=1580, is_first_generation=False, is_underrepresented=False, is_in_state=False, institutional_reputation_score=8, graduate_outcomes_score=8),
        # Borderline academics, strong context -> likely Waitlist/Admit
        Applicant(applicant_id="APP-003", gpa=3.5, test_score=1300, is_first_generation=True, is_underrepresented=True, is_in_state=True, institutional_reputation_score=7, graduate_outcomes_score=6),
        # Average applicant -> likely Waitlist
        Applicant(applicant_id="APP-004", gpa=3.6, test_score=1350, is_first_generation=False, is_underrepresented=False, is_in_state=True, institutional_reputation_score=6, graduate_outcomes_score=7),
        # Fails initial screening (reputation) -> Reject
        Applicant(applicant_id="APP-005", gpa=4.0, test_score=1600, is_first_generation=False, is_underrepresented=False, is_in_state=False, institutional_reputation_score=4, graduate_outcomes_score=9),
        # Fails initial screening (outcomes) -> Reject
        Applicant(applicant_id="APP-006", gpa=3.8, test_score=1400, is_first_generation=True, is_underrepresented=False, is_in_state=True, institutional_reputation_score=8, graduate_outcomes_score=3),
        # Strong test-taker, lower GPA -> likely Waitlist
        Applicant(applicant_id="APP-007", gpa=3.4, test_score=1500, is_first_generation=False, is_underrepresented=False, is_in_state=False, institutional_reputation_score=9, graduate_outcomes_score=8),
        # Solid Waitlist candidate
        Applicant(applicant_id="APP-008", gpa=3.8, test_score=1400, is_first_generation=False, is_underrepresented=False, is_in_state=True, institutional_reputation_score=7, graduate_outcomes_score=7),
        # Weak applicant -> likely Reject
        Applicant(applicant_id="APP-009", gpa=3.1, test_score=1100, is_first_generation=False, is_underrepresented=False, is_in_state=True, institutional_reputation_score=5, graduate_outcomes_score=5),
    ]

def main():
    """
    Main function to initialize, run, and report on the admissions system.
    This demonstrates the self-contained nature of the application (NFR1).
    """
    print("Initializing University Admissions Screening System...")
    
    applicants = get_sample_applicants()
    print(f"Loaded {len(applicants)} applicant records for processing.")
    
    # Initialize the system with the applicant data
    system = UniversityAdmissionsSystem(applicants)
    
    # Run the core processing logic
    print("Processing all applications...")
    system.process_applications()
    print("Processing complete.")
    
    # Display detailed results for each individual applicant
    print("\n--- Individual Application Results ---")
    for result in system.results:
        print(
            f"ID: {result.applicant.applicant_id}, "
            f"Score: {result.holistic_score:5.2f}, "
            f"Decision: {result.decision:<8} "
            f"({result.notes})"
        )
    print("-" * 50)
    
    # Generate and print the final summary report
    print("\nGenerating final cohort report...")
    report = system.generate_report()
    print(report)

if __name__ == "__main__":
    main()