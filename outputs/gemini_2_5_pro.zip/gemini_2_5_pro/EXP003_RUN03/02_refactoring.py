# university_admissions_processor.py

"""
A self-contained system for processing university applications.

This script models a holistic admissions process by calculating scores for
applicants based on academic and geographic factors, making admission decisions,
and generating a summary report. It is designed to run without any external
dependencies.
"""

import math
import random
from collections import Counter
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Dict, Final, List

# ==============================================================================
# 1. CONFIGURATION
# ==============================================================================
# NFR2: Transparent scoring metrics are defined here and used in the report.

ADMISSIONS_CONFIG: Final[Dict[str, Any]] = {
    # FR2: Weights for the holistic score calculation.
    "scoring_weights": {
        "academic": 0.70,  # 70% weight for academic performance
        "geographic": 0.30,  # 30% weight for geographic diversity
    },
    # Constants for normalizing academic scores.
    "normalization_caps": {
        "max_gpa": 4.0,
        "max_test_score": 1600,
    },
    # FR3: Thresholds for admission decisions (based on a 0-100 holistic score).
    "decision_thresholds": {
        "admit": 80.0,
        "waitlist": 65.0,
    },
    # FR5: Desired geographic distribution for the incoming cohort.
    "target_geographic_distribution": {
        "Northeast": 0.20,
        "Midwest": 0.20,
        "South": 0.30,
        "West": 0.25,
        "International": 0.05,
    },
}


# ==============================================================================
# 2. DATA MODELS
# ==============================================================================
# FR1: The system stores applicant data using these structured models.

class Decision(Enum):
    """Enumeration for admission decisions."""
    ADMIT = auto()
    WAITLIST = auto()
    REJECT = auto()

    def __str__(self) -> str:
        return self.name


@dataclass(frozen=True)
class Applicant:
    """Represents a single university applicant's data."""
    applicant_id: int
    name: str
    gpa: float
    test_score: int
    geography: str  # e.g., 'Northeast', 'West'
    demographics: Dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class AdmissionResult:
    """Stores the outcome of the screening for a single applicant."""
    applicant: Applicant
    scores: Dict[str, float]
    holistic_score: float
    decision: Decision


# ==============================================================================
# 3. CORE COMPONENTS (MODULAR DESIGN)
# ==============================================================================

class HolisticScorer:
    """Calculates all academic, geographic, and holistic scores."""

    def __init__(self, applicants: List[Applicant], config: Dict[str, Any]):
        """
        Initializes the scorer with the applicant pool and configuration.

        Args:
            applicants: The list of all applicants to be considered.
            config: The system configuration dictionary.
        """
        self._config = config
        self._weights = config["scoring_weights"]
        self._caps = config["normalization_caps"]
        # Pre-calculating geographic scores is efficient for a large pool.
        self._geographic_need_scores = self._precompute_geographic_scores(
            applicants
        )

    def _precompute_geographic_scores(
        self, applicants: List[Applicant]
    ) -> Dict[str, float]:
        """
        Calculates a diversity score for each geographic region.

        The score is based on how underrepresented a region is in the
        applicant pool compared to the university's target distribution. This
        directly implements FR5 (geographic prioritization).

        Returns:
            A dictionary mapping each geographic region to a score from 0-100.
        """
        if not applicants:
            return {}

        applicant_counts_by_region = Counter(app.geography for app in applicants)
        total_applicants = len(applicants)
        target_dist = self._config["target_geographic_distribution"]

        # Calculate a "need factor" for each region: target % / actual %
        need_factors: Dict[str, float] = {}
        for region, target_pct in target_dist.items():
            actual_pct = applicant_counts_by_region.get(region, 0) / total_applicants
            # If a region has 0 applicants, its need is maximal.
            need_factors[region] = float('inf') if actual_pct == 0 else target_pct / actual_pct

        # Normalize the need factors to a 0-100 score for fairness.
        finite_factors = [f for f in need_factors.values() if f != float('inf')]
        if not finite_factors:
            min_need, max_need = 1.0, 1.0  # Avoid division by zero
        else:
            min_need, max_need = min(finite_factors), max(finite_factors)

        # If all regions have the same representation, assign a neutral score.
        if math.isclose(min_need, max_need):
            return {region: 50.0 for region in target_dist}

        geo_scores: Dict[str, float] = {}
        for region, factor in need_factors.items():
            if factor == float('inf'):
                score = 100.0  # Max score for a region with zero applicants
            else:
                score = ((factor - min_need) / (max_need - min_need)) * 100.0
            geo_scores[region] = score

        return geo_scores

    def _calculate_academic_score(self, applicant: Applicant) -> float:
        """Calculates a normalized academic score (0-100)."""
        norm_gpa = min(1.0, applicant.gpa / self._caps["max_gpa"]) * 100
        norm_test = min(1.0, applicant.test_score / self._caps["max_test_score"]) * 100
        return (norm_gpa + norm_test) / 2

    def calculate_all_scores(self, applicant: Applicant) -> Dict[str, float]:
        """
        Computes all component scores and the final holistic score for an applicant.

        Args:
            applicant: The applicant to score.

        Returns:
            A dictionary containing academic, geographic, and holistic scores.
        """
        academic_score = self._calculate_academic_score(applicant)
        geographic_score = self._geographic_need_scores.get(applicant.geography, 0.0)

        holistic_score = (
            academic_score * self._weights["academic"]
            + geographic_score * self._weights["geographic"]
        )

        return {
            "academic": academic_score,
            "geographic": geographic_score,
            "holistic": holistic_score,
        }


class DecisionEngine:
    """Makes admission decisions based on holistic scores."""

    def __init__(self, config: Dict[str, Any]):
        """
        Initializes the engine with decision thresholds from the config.

        Args:
            config: The system configuration dictionary.
        """
        self._thresholds = config["decision_thresholds"]

    def make_decision(self, holistic_score: float) -> Decision:
        """
        Determines the admission decision for a given score (FR3).

        Args:
            holistic_score: The applicant's final holistic score.

        Returns:
            The corresponding admission decision (Admit, Waitlist, or Reject).
        """
        if holistic_score >= self._thresholds["admit"]:
            return Decision.ADMIT
        elif holistic_score >= self._thresholds["waitlist"]:
            return Decision.WAITLIST
        else:
            return Decision.REJECT


class SummaryReporter:
    """Generates a formatted summary report of admissions results."""

    def __init__(self, config: Dict[str, Any]):
        """
        Initializes the reporter with configuration for transparency (NFR2).

        Args:
            config: The system configuration dictionary.
        """
        self._config = config

    def generate(self, results: List[AdmissionResult], total_applicants: int) -> str:
        """
        Creates the full summary report string (FR4).

        Args:
            results: The list of admission results for all applicants.
            total_applicants: The total number of initial applicants.

        Returns:
            A formatted, multi-line string containing the report.
        """
        if not results:
            return "No results to report. Please run the screening process first."

        report_parts = [
            "\n" + "=" * 80,
            " " * 25 + "University Admissions Summary Report",
            "=" * 80,
            self._generate_metrics_section(),
            self._generate_overall_stats_section(results, total_applicants),
            self._generate_admitted_cohort_section(results),
            "=" * 80 + "\n",
        ]
        return "\n".join(report_parts)

    def _generate_metrics_section(self) -> str:
        """Creates the scoring transparency section of the report."""
        weights = self._config["scoring_weights"]
        thresholds = self._config["decision_thresholds"]
        return (
            "\n--- Scoring and Decision Metrics ---\n"
            f"Holistic Score Formula: "
            f"({weights['academic']:.0%} Academic) + "
            f"({weights['geographic']:.0%} Geographic)\n"
            "Decision Thresholds:\n"
            f"  - Admit: Score >= {thresholds['admit']:.1f}\n"
            f"  - Waitlist: Score >= {thresholds['waitlist']:.1f}\n"
            f"  - Reject: Score < {thresholds['waitlist']:.1f}"
        )

    def _generate_overall_stats_section(
        self, results: List[AdmissionResult], total_applicants: int
    ) -> str:
        """Creates the overall application statistics section."""
        decision_counts = Counter(result.decision for result in results)
        return (
            "\n--- Overall Application Statistics ---\n"
            f"Total Applicants: {total_applicants}\n"
            f"  - Admitted:   {decision_counts[Decision.ADMIT]}\n"
            f"  - Waitlisted: {decision_counts[Decision.WAITLIST]}\n"
            f"  - Rejected:   {decision_counts[Decision.REJECT]}"
        )

    def _generate_admitted_cohort_section(self, results: List[AdmissionResult]) -> str:
        """Creates the detailed profile of the admitted cohort."""
        admitted = [r for r in results if r.decision == Decision.ADMIT]
        if not admitted:
            return "\n--- Admitted Cohort Profile ---\nNo applicants were admitted."

        num_admitted = len(admitted)
        avg_gpa = sum(r.applicant.gpa for r in admitted) / num_admitted
        avg_test = sum(r.applicant.test_score for r in admitted) / num_admitted
        avg_score = sum(r.holistic_score for r in admitted) / num_admitted
        
        geo_counts = Counter(r.applicant.geography for r in admitted)
        geo_dist_lines = []
        for region, target_pct in self._config["target_geographic_distribution"].items():
            count = geo_counts.get(region, 0)
            actual_pct = count / num_admitted
            geo_dist_lines.append(
                f"  - {region:<15}: {count:<3} students ({actual_pct:7.2%}) | Target: {target_pct:.2%}"
            )
        geo_distribution_report = "\n".join(geo_dist_lines)

        return (
            "\n--- Admitted Cohort Profile ---\n"
            f"Number of Admitted Students: {num_admitted}\n"
            f"Average GPA: {avg_gpa:.2f}\n"
            f"Average Test Score: {avg_test:.0f}\n"
            f"Average Holistic Score: {avg_score:.2f}\n\n"
            "Geographic Distribution of Admitted Cohort:\n"
            f"{geo_distribution_report}"
        )


# ==============================================================================
# 4. MAIN APPLICATION ORCHESTRATOR
# ==============================================================================

class AdmissionsProcessor:
    """Orchestrates the entire admissions screening process."""

    def __init__(self, applicants: List[Applicant], config: Dict[str, Any]):
        """
        Initializes the processor with applicants and system configuration.

        Args:
            applicants: A list of Applicant objects.
            config: A dictionary containing system parameters.
        """
        if not math.isclose(sum(config["scoring_weights"].values()), 1.0):
            raise ValueError("Scoring weights must sum to 1.0")
        
        self.applicants = applicants
        self.config = config
        self.results: List[AdmissionResult] = []

        # Instantiate modular components
        self._scorer = HolisticScorer(applicants, config)
        self._engine = DecisionEngine(config)
        self._reporter = SummaryReporter(config)

    def process_applications(self):
        """
        Runs the full screening process for all applicants.
        """
        if not self.applicants:
            print("No applicants to screen.")
            return

        for applicant in self.applicants:
            all_scores = self._scorer.calculate_all_scores(applicant)
            decision = self._engine.make_decision(all_scores["holistic"])

            self.results.append(
                AdmissionResult(
                    applicant=applicant,
                    scores={
                        "academic": all_scores["academic"],
                        "geographic": all_scores["geographic"],
                    },
                    holistic_score=all_scores["holistic"],
                    decision=decision,
                )
            )
        print("Screening process completed.")

    def generate_report(self):
        """Generates and prints the final summary report."""
        report = self._reporter.generate(self.results, len(self.applicants))
        print(report)


# ==============================================================================
# 5. DATA GENERATION AND EXECUTION
# ==============================================================================
# NFR1: Self-contained execution with mock data generation.

def generate_mock_applicants(count: int) -> List[Applicant]:
    """
    Creates a list of randomized Applicant objects for demonstration.

    Args:
        count: The number of mock applicants to generate.

    Returns:
        A list of Applicant objects.
    """
    applicants = []
    geographies = list(ADMISSIONS_CONFIG["target_geographic_distribution"].keys())
    # Skew the applicant pool to be different from the target distribution
    # to demonstrate the effect of geographic scoring.
    geo_weights = [0.40, 0.25, 0.15, 0.15, 0.05]  # Skewed towards Northeast

    for i in range(count):
        # Create a potential factor to correlate GPA and test scores realistically.
        potential = random.uniform(0.7, 1.0)
        gpa = random.uniform(2.5, 4.0) * potential
        test_score = random.randint(1000, 1600) * potential

        applicant = Applicant(
            applicant_id=10001 + i,
            name=f"Applicant {10001 + i}",
            gpa=min(ADMISSIONS_CONFIG["normalization_caps"]["max_gpa"], round(gpa, 2)),
            test_score=min(ADMISSIONS_CONFIG["normalization_caps"]["max_test_score"], int(test_score)),
            geography=random.choices(geographies, weights=geo_weights, k=1)[0],
            demographics={"first_generation": random.choice(["Yes", "No"])},
        )
        applicants.append(applicant)
    return applicants


def main():
    """Main function to run the admissions simulation."""
    # 1. Generate a mock applicant pool.
    print("Generating mock applicant data...")
    applicant_pool = generate_mock_applicants(500)
    print(f"Generated {len(applicant_pool)} applicants.")

    # 2. Initialize the admissions processor with applicants and config.
    print("Initializing admissions processor...")
    processor = AdmissionsProcessor(applicant_pool, ADMISSIONS_CONFIG)

    # 3. Run the screening process.
    processor.process_applications()

    # 4. Generate the final report.
    processor.generate_report()


if __name__ == "__main__":
    main()