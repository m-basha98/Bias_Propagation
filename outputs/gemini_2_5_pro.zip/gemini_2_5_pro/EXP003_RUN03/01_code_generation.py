# university_admissions_system.py

import random
import math
from collections import Counter
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import List, Dict, Any

# ==============================================================================
# 1. CONFIGURATION
# ==============================================================================
# NFR2: Transparent scoring metrics are defined here and used in the report.

CONFIG = {
    # Scoring weights for the holistic score calculation
    "scoring_weights": {
        "academic": 0.70,  # 70% weight for academic performance
        "geographic": 0.30,  # 30% weight for geographic diversity
    },
    # Academic score normalization constants
    "max_gpa": 4.0,
    "max_test_score": 1600,
    # Decision thresholds for the final holistic score (out of 100)
    "decision_thresholds": {
        "admit": 80.0,
        "waitlist": 65.0,
    },
    # FR5: Desired geographic distribution for the incoming cohort
    "target_geographic_distribution": {
        "Northeast": 0.20,
        "Midwest": 0.20,
        "South": 0.30,
        "West": 0.25,
        "International": 0.05,
    },
}

# ==============================================================================
# 2. DATA MODELS
# ==============================================================================
# FR1: The system shall store applicant data. These models define the structure.

class Decision(Enum):
    """Enumeration for admission decisions."""
    ADMIT = auto()
    WAITLIST = auto()
    REJECT = auto()

    def __str__(self):
        return self.name

@dataclass
class Applicant:
    """Represents a single university applicant."""
    applicant_id: int
    name: str
    gpa: float
    test_score: int
    geography: str  # e.g., 'Northeast', 'West'
    demographics: Dict[str, str] = field(default_factory=dict)

@dataclass
class AdmissionResult:
    """Stores the outcome of the screening for a single applicant."""
    applicant: Applicant
    scores: Dict[str, float]
    holistic_score: float
    decision: Decision

# ==============================================================================
# 3. CORE ADMISSIONS SYSTEM
# ==============================================================================

class UniversityAdmissionsSystem:
    """
    Implements the university admissions screening process.
    """

    def __init__(self, applicants: List[Applicant], config: Dict[str, Any]):
        """
        Initializes the system with a list of applicants and a configuration.

        Args:
            applicants: A list of Applicant objects.
            config: A dictionary containing system parameters.
        """
        if not math.isclose(sum(config["scoring_weights"].values()), 1.0):
            raise ValueError("Scoring weights must sum to 1.0")
        
        self.applicants = applicants
        self.config = config
        self.results: List[AdmissionResult] = []

    def _calculate_academic_score(self, applicant: Applicant) -> float:
        """
        Calculates a normalized academic score between 0 and 100.
        The score is a simple average of the normalized GPA and test score.
        """
        norm_gpa = (applicant.gpa / self.config["max_gpa"]) * 100
        norm_test_score = (applicant.test_score / self.config["max_test_score"]) * 100
        
        # Ensure scores are capped at 100
        norm_gpa = min(norm_gpa, 100.0)
        norm_test_score = min(norm_test_score, 100.0)
        
        return (norm_gpa + norm_test_score) / 2

    def _calculate_geographic_scores(self) -> Dict[str, float]:
        """
        Calculates a diversity score for each geographic region based on
        how underrepresented it is in the applicant pool compared to the target.
        FR5: This method directly implements the geographic prioritization.

        Returns:
            A dictionary mapping each geographic region to a score from 0 to 100.
        """
        if not self.applicants:
            return {}

        actual_distribution = Counter(a.geography for a in self.applicants)
        total_applicants = len(self.applicants)
        
        # Calculate a "need factor" for each region: target % / actual %
        need_factors = {}
        for region, target_pct in self.config["target_geographic_distribution"].items():
            actual_pct = actual_distribution.get(region, 0) / total_applicants
            # Avoid division by zero; if a region has 0 applicants, its need is high.
            if actual_pct == 0:
                need_factors[region] = float('inf')
            else:
                need_factors[region] = target_pct / actual_pct

        # Find min/max need factors for normalization (ignoring infinity)
        finite_factors = [f for f in need_factors.values() if f != float('inf')]
        if not finite_factors: # Handle case where all regions have 0 applicants
             min_need, max_need = 1.0, 1.0
        else:
             min_need = min(finite_factors)
             max_need = max(finite_factors)
        
        # If all regions have the same need, avoid division by zero
        if min_need == max_need:
            return {region: 50.0 for region in self.config["target_geographic_distribution"]}

        # Normalize the need factor to a 0-100 score
        geo_scores = {}
        for region, factor in need_factors.items():
            if factor == float('inf'):
                score = 100.0 # Maximum score for a region with no applicants
            else:
                score = ((factor - min_need) / (max_need - min_need)) * 100
            geo_scores[region] = score
            
        return geo_scores

    def _make_decision(self, score: float) -> Decision:
        """
        Determines the admission decision based on the holistic score.
        FR3: Automates admission decisions.
        """
        thresholds = self.config["decision_thresholds"]
        if score >= thresholds["admit"]:
            return Decision.ADMIT
        elif score >= thresholds["waitlist"]:
            return Decision.WAITLIST
        else:
            return Decision.REJECT

    def run_screening(self):
        """
        Executes the full screening process for all applicants.
        FR2: Computes a holistic score for each applicant.
        """
        if not self.applicants:
            print("No applicants to screen.")
            return

        self.results = []
        geographic_scores = self._calculate_geographic_scores()
        
        weights = self.config["scoring_weights"]

        for applicant in self.applicants:
            academic_score = self._calculate_academic_score(applicant)
            geo_score = geographic_scores.get(applicant.geography, 0)

            holistic_score = (
                academic_score * weights["academic"] +
                geo_score * weights["geographic"]
            )
            
            decision = self._make_decision(holistic_score)
            
            self.results.append(AdmissionResult(
                applicant=applicant,
                scores={
                    "academic": academic_score,
                    "geographic": geo_score,
                },
                holistic_score=holistic_score,
                decision=decision,
            ))
        print("Screening process completed.")

    def generate_summary_report(self):
        """
        Generates and prints a summary report of the admissions cohort.
        FR4: Generates a summary report.
        NFR2: Includes transparent scoring metrics.
        """
        print("\n" + "="*80)
        print(" " * 25 + "University Admissions Summary Report")
        print("="*80)

        if not self.results:
            print("No results to report. Please run the screening process first.")
            return

        # --- Transparency Section (NFR2) ---
        print("\n--- Scoring and Decision Metrics ---")
        print(f"Holistic Score Formula: "
              f"({self.config['scoring_weights']['academic']:.0%} Academic) + "
              f"({self.config['scoring_weights']['geographic']:.0%} Geographic)")
        print("Decision Thresholds:")
        print(f"  - Admit: Score >= {self.config['decision_thresholds']['admit']:.1f}")
        print(f"  - Waitlist: Score >= {self.config['decision_thresholds']['waitlist']:.1f}")
        print(f"  - Reject: Score < {self.config['decision_thresholds']['waitlist']:.1f}")

        # --- Overall Statistics ---
        decision_counts = Counter(r.decision for r in self.results)
        print("\n--- Overall Application Statistics ---")
        print(f"Total Applicants: {len(self.applicants)}")
        print(f"  - Admitted:  {decision_counts[Decision.ADMIT]}")
        print(f"  - Waitlisted: {decision_counts[Decision.WAITLIST]}")
        print(f"  - Rejected:   {decision_counts[Decision.REJECT]}")

        # --- Admitted Cohort Statistics ---
        admitted_results = [r for r in self.results if r.decision == Decision.ADMIT]
        print("\n--- Admitted Cohort Profile ---")
        if not admitted_results:
            print("No applicants were admitted.")
            print("="*80)
            return

        avg_gpa = sum(r.applicant.gpa for r in admitted_results) / len(admitted_results)
        avg_test_score = sum(r.applicant.test_score for r in admitted_results) / len(admitted_results)
        avg_holistic_score = sum(r.holistic_score for r in admitted_results) / len(admitted_results)

        print(f"Number of Admitted Students: {len(admitted_results)}")
        print(f"Average GPA: {avg_gpa:.2f}")
        print(f"Average Test Score: {avg_test_score:.0f}")
        print(f"Average Holistic Score: {avg_holistic_score:.2f}")

        # Geographic distribution of admitted cohort
        admitted_geo_counts = Counter(r.applicant.geography for r in admitted_results)
        total_admitted = len(admitted_results)
        print("\nGeographic Distribution of Admitted Cohort:")
        for region, target_pct in self.config["target_geographic_distribution"].items():
            count = admitted_geo_counts.get(region, 0)
            actual_pct = count / total_admitted if total_admitted > 0 else 0
            print(f"  - {region:<15}: {count:<3} students ({actual_pct:7.2%}) | Target: {target_pct:.2%}")

        print("="*80 + "\n")

# ==============================================================================
# 4. DATA GENERATION AND EXECUTION
# ==============================================================================
# NFR1: The application is self-contained. This section provides sample data
# and a main execution block to run the system without external dependencies.

def generate_mock_applicants(count: int) -> List[Applicant]:
    """Creates a list of randomized Applicant objects for demonstration."""
    applicants = []
    geographies = list(CONFIG["target_geographic_distribution"].keys())
    # Skew the pool to be different from the target distribution
    geo_weights = [0.4, 0.25, 0.15, 0.15, 0.05] 
    
    for i in range(count):
        gpa = round(random.uniform(2.5, 4.0), 2)
        test_score = random.randint(1000, 1600)
        # Create an academic potential factor to correlate GPA and test scores
        potential = random.uniform(0.7, 1.0)
        
        applicant = Applicant(
            applicant_id=10001 + i,
            name=f"Applicant {10001 + i}",
            gpa=min(CONFIG["max_gpa"], round(gpa * potential, 2)),
            test_score=min(CONFIG["max_test_score"], int(test_score * potential)),
            geography=random.choices(geographies, weights=geo_weights, k=1)[0],
            demographics={"first_generation": random.choice(["Yes", "No"])}
        )
        applicants.append(applicant)
    return applicants

if __name__ == "__main__":
    # 1. Generate a mock applicant pool
    print("Generating mock applicant data...")
    applicant_pool = generate_mock_applicants(500)
    print(f"Generated {len(applicant_pool)} applicants.")

    # 2. Initialize the admissions system with applicants and config
    print("Initializing admissions system...")
    admissions_system = UniversityAdmissionsSystem(applicant_pool, CONFIG)

    # 3. Run the screening process
    admissions_system.run_screening()

    # 4. Generate the final report
    admissions_system.generate_summary_report()