# Technical Documentation: University Admissions Processor

This document provides a detailed technical overview of the `university_admissions_processor.py` script. It explains the system's architecture, data models, core components, and execution flow, linking them to the original software specifications.

## 1. Module Overview

The `university_admissions_processor.py` module is a self-contained Python application designed to simulate a university's holistic admissions process. It fulfills all functional and non-functional requirements without external dependencies like databases or services (NFR1).

The system's primary functions include:
-   **Data Modeling**: Storing detailed applicant data (FR1).
-   **Holistic Scoring**: Calculating a weighted score for each applicant based on academic merit and geographic diversity needs (FR2, FR5).
-   **Decision Automation**: Assigning admission decisions (Admit, Waitlist, Reject) based on configurable score thresholds (FR3).
-   **Reporting**: Generating a comprehensive summary report of the admissions cycle, including cohort statistics and transparent scoring metrics (FR4, NFR2).

The application is structured into modular components: a scorer, a decision engine, a reporter, and an orchestrator, promoting separation of concerns and maintainability.

---

## 2. System Configuration (`ADMISSIONS_CONFIG`)

A global `Final` dictionary that holds all configurable parameters for the admissions process. Centralizing configuration makes the system easy to tune and ensures scoring metrics are transparent (NFR2).

-   **`scoring_weights`**: `Dict[str, float]`
    -   Defines the weights for combining component scores into a single holistic score (FR2).
    -   `academic`: The percentage weight (e.g., `0.70`) assigned to the applicant's academic performance.
    -   `geographic`: The percentage weight (e.g., `0.30`) assigned to the applicant's contribution to geographic diversity.

-   **`normalization_caps`**: `Dict[str, float]`
    -   Provides upper bounds for normalizing academic metrics to a 0-100 scale.
    -   `max_gpa`: The highest possible GPA (e.g., `4.0`).
    -   `max_test_score`: The highest possible standardized test score (e.g., `1600`).

-   **`decision_thresholds`**: `Dict[str, float]`
    -   Defines the minimum holistic score required for each admission decision (FR3).
    -   `admit`: The score at or above which an applicant is admitted.
    -   `waitlist`: The score at or above which an applicant is waitlisted (and below the admit threshold).

-   **`target_geographic_distribution`**: `Dict[str, float]`
    -   Specifies the university's desired geographic makeup for the incoming class. The keys are region names, and the values are their target proportions (e.g., `0.20` for 20%) (FR5).

---

## 3. Data Models

These `dataclass` and `Enum` types provide structured, immutable representations of the core entities in the admissions process (FR1).

### `Decision(Enum)`

An enumeration representing the possible outcomes of an admission review.
-   **`ADMIT`**: The applicant is accepted.
-   **`WAITLIST`**: The applicant is placed on the waitlist.
-   **`REJECT`**: The applicant is rejected.

### `Applicant(dataclass)`

A frozen dataclass representing a single applicant's profile.
-   **`applicant_id`**: `int` - A unique identifier for the applicant.
-   **`name`**: `str` - The applicant's full name.
-   **`gpa`**: `float` - The applicant's Grade Point Average.
-   **`test_score`**: `int` - The applicant's standardized test score.
-   **`geography`**: `str` - The applicant's geographic region (e.g., 'Northeast', 'West').
-   **`demographics`**: `Dict[str, str]` - A dictionary for additional demographic data.

### `AdmissionResult(dataclass)`

A frozen dataclass that encapsulates the complete result of an applicant's review.
-   **`applicant`**: `Applicant` - The original applicant object.
-   **`scores`**: `Dict[str, float]` - A dictionary of the component scores (e.g., 'academic', 'geographic').
-   **`holistic_score`**: `float` - The final weighted holistic score.
-   **`decision`**: `Decision` - The final admission decision.

---

## 4. Core Components (Classes)

The system's logic is divided into distinct classes, each with a single responsibility.

### `HolisticScorer`

This class is responsible for all scoring calculations. It takes the entire applicant pool during initialization to efficiently pre-calculate cohort-dependent scores.

#### `HolisticScorer.__init__(self, applicants: List[Applicant], config: Dict[str, Any])`

Initializes the scorer.
-   **Parameters**:
    -   `applicants`: `List[Applicant]` - The complete list of applicants to be processed.
    -   `config`: `Dict[str, Any]` - The global `ADMISSIONS_CONFIG` dictionary.
-   **Description**: Caches configuration values and triggers the pre-computation of geographic diversity scores for all regions. This pre-computation is an optimization that avoids recalculating cohort statistics for every applicant.

#### `HolisticScorer._precompute_geographic_scores(self, applicants: List[Applicant]) -> Dict[str, float]`

Calculates a geographic diversity "need" score for each region based on its representation in the applicant pool versus the university's target distribution (FR5).
-   **Parameters**:
    -   `applicants`: `List[Applicant]` - The list of all applicants.
-   **Returns**:
    -   `Dict[str, float]`: A dictionary mapping each geographic region to a normalized score (0-100), where a higher score indicates a greater need for students from that region.
-   **Logic**:
    1.  Calculates the actual distribution of applicants by region.
    2.  For each region, computes a "need factor" as `target_percentage / actual_percentage`. Regions with zero applicants receive an infinite need factor.
    3.  Normalizes these need factors to a 0-100 scale to ensure fairness. Regions with infinite need are assigned the maximum score of 100.

#### `HolisticScorer._calculate_academic_score(self, applicant: Applicant) -> float`

Calculates a normalized academic score for an individual applicant.
-   **Parameters**:
    -   `applicant`: `Applicant` - The applicant to score.
-   **Returns**:
    -   `float`: A normalized academic score between 0 and 100.
-   **Logic**:
    1.  Normalizes the GPA to a 0-100 scale using `config['normalization_caps']['max_gpa']`.
    2.  Normalizes the test score to a 0-100 scale using `config['normalization_caps']['max_test_score']`.
    3.  Returns the average of the two normalized scores.

#### `HolisticScorer.calculate_all_scores(self, applicant: Applicant) -> Dict[str, float]`

Computes all component scores and the final holistic score for a single applicant (FR2).
-   **Parameters**:
    -   `applicant`: `Applicant` - The applicant to score.
-   **Returns**:
    -   `Dict[str, float]`: A dictionary containing the `academic`, `geographic`, and final `holistic` scores.
-   **Logic**:
    1.  Calls `_calculate_academic_score` to get the academic score.
    2.  Retrieves the pre-computed geographic score for the applicant's region.
    3.  Combines the academic and geographic scores using the weights from `config['scoring_weights']` to calculate the final holistic score.

---

### `DecisionEngine`

A simple, stateless class that translates a numerical score into a categorical admission decision.

#### `DecisionEngine.__init__(self, config: Dict[str, Any])`

Initializes the engine.
-   **Parameters**:
    -   `config`: `Dict[str, Any]` - The global `ADMISSIONS_CONFIG` dictionary.
-   **Description**: Caches the `decision_thresholds` from the configuration for quick access.

#### `DecisionEngine.make_decision(self, holistic_score: float) -> Decision`

Makes an admission decision based on a holistic score (FR3).
-   **Parameters**:
    -   `holistic_score`: `float` - The applicant's final holistic score.
-   **Returns**:
    -   `Decision`: The corresponding admission decision (`ADMIT`, `WAITLIST`, or `REJECT`).
-   **Logic**: Compares the `holistic_score` against the cached thresholds in a cascading manner (Admit > Waitlist > Reject).

---

### `SummaryReporter`

This class is responsible for formatting and generating the final summary report.

#### `SummaryReporter.__init__(self, config: Dict[str, Any])`

Initializes the reporter.
-   **Parameters**:
    -   `config`: `Dict[str, Any]` - The global `ADMISSIONS_CONFIG` dictionary.
-   **Description**: Caches the configuration, which is used to display transparent scoring metrics in the report (NFR2).

#### `SummaryReporter.generate(self, results: List[AdmissionResult], total_applicants: int) -> str`

Constructs the complete, formatted report string (FR4).
-   **Parameters**:
    -   `results`: `List[AdmissionResult]` - The list of results for all processed applicants.
    -   `total_applicants`: `int` - The total number of applicants in the initial pool.
-   **Returns**:
    -   `str`: A multi-line string containing the full admissions summary report.
-   **Logic**: Assembles the report by calling its private helper methods for each section (`_generate_metrics_section`, `_generate_overall_stats_section`, `_generate_admitted_cohort_section`).

---

## 5. Main Application Orchestrator

### `AdmissionsProcessor`

This class serves as the main controller, orchestrating the end-to-end admissions process by coordinating the scorer, engine, and reporter.

#### `AdmissionsProcessor.__init__(self, applicants: List[Applicant], config: Dict[str, Any])`

Initializes the processor.
-   **Parameters**:
    -   `applicants`: `List[Applicant]` - The list of applicants to process.
    -   `config`: `Dict[str, Any]` - The global `ADMISSIONS_CONFIG` dictionary.
-   **Description**:
    -   Performs a validation check to ensure scoring weights in the configuration sum to 1.0.
    -   Stores the applicants and config.
    -   Initializes an empty list `self.results` to store outcomes.
    -   Instantiates the `HolisticScorer`, `DecisionEngine`, and `SummaryReporter` components, injecting the necessary dependencies (applicants and configuration).

#### `AdmissionsProcessor.process_applications(self)`

Executes the core processing loop for all applicants.
-   **Description**:
    1.  Iterates through each `Applicant` in `self.applicants`.
    2.  For each applicant, it calls the `_scorer` to calculate all scores.
    3.  It then passes the resulting holistic score to the `_engine` to get a decision.
    4.  Finally, it creates an `AdmissionResult` object and appends it to the `self.results` list.

#### `AdmissionsProcessor.generate_report(self)`

Generates and prints the final summary report to the console.
-   **Description**: Calls the `_reporter.generate()` method with the collected results and prints the returned string.

---

## 6. Data Generation and Execution

This section covers the standalone execution logic of the script.

### `generate_mock_applicants(count: int) -> List[Applicant]`

A utility function to create a randomized list of `Applicant` objects for demonstration purposes, ensuring the script is self-contained (NFR1).
-   **Parameters**:
    -   `count`: `int` - The number of mock applicants to generate.
-   **Returns**:
    -   `List[Applicant]`: A list of newly created `Applicant` objects.
-   **Description**: The function generates applicants with randomized but plausible data. It intentionally uses a skewed geographic distribution for the applicant pool that differs from the `target_geographic_distribution` to effectively demonstrate the impact of the geographic scoring component.

### `main()`

The main entry point for the script.
-   **Description**: Orchestrates a complete simulation run:
    1.  Calls `generate_mock_applicants` to create a sample data pool.
    2.  Instantiates the `AdmissionsProcessor` with the mock data and configuration.
    3.  Calls `processor.process_applications()` to run the simulation.
    4.  Calls `processor.generate_report()` to display the results.

### `if __name__ == "__main__":`

Standard Python construct that ensures the `main()` function is called only when the script is executed directly.