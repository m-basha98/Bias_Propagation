# test_university_admissions_processor.py

"""
A comprehensive suite of unit tests for the university_admissions_processor module.

This test suite uses pytest to validate the functionality of the admissions system,
covering standard scenarios, edge cases, and boundary conditions for each component.
"""

import math
from typing import Any, Dict, List

import pytest

from university_admissions_processor import (
    ADMISSIONS_CONFIG,
    AdmissionsProcessor,
    AdmissionResult,
    Applicant,
    Decision,
    DecisionEngine,
    HolisticScorer,
    SummaryReporter,
    generate_mock_applicants,
)

# ==============================================================================
# 1. FIXTURES
# ==============================================================================
# Fixtures provide consistent, reusable data for tests.

@pytest.fixture
def test_config() -> Dict[str, Any]:
    """Provides a deep copy of the default admissions configuration."""
    # This is a simple config, so a direct copy is fine. For nested dicts,
    # a deepcopy would be safer.
    return dict(ADMISSIONS_CONFIG)


@pytest.fixture
def diverse_applicants() -> List[Applicant]:
    """
    Provides a small, diverse, and predictable list of applicants for testing.
    This pool is intentionally skewed to test geographic scoring logic.
    - South & West are under-represented vs target (should get higher geo scores).
    - Northeast is over-represented (should get lower geo scores).
    - Midwest is exactly at target.
    - International has 0 applicants (should get max geo score).
    """
    return [
        Applicant(applicant_id=1, name="Perfect Student", gpa=4.0, test_score=1600, geography="West"),
        Applicant(applicant_id=2, name="Strong Applicant", gpa=3.8, test_score=1500, geography="South"),
        Applicant(applicant_id=3, name="Avg Northeast 1", gpa=3.5, test_score=1300, geography="Northeast"),
        Applicant(applicant_id=4, name="Avg Northeast 2", gpa=3.6, test_score=1350, geography="Northeast"),
        Applicant(applicant_id=5, name="Avg Northeast 3", gpa=3.4, test_score=1250, geography="Northeast"),
        Applicant(applicant_id=6, name="Midwest平衡", gpa=3.7, test_score=1400, geography="Midwest"),
        Applicant(applicant_id=7, name="Low Scorer", gpa=2.8, test_score=1100, geography="South"),
        Applicant(applicant_id=8, name="Unknown Region", gpa=3.9, test_score=1550, geography="Territories"),
        Applicant(applicant_id=9, name="Zero Scorer", gpa=0.0, test_score=0, geography="West"),
    ]


# ==============================================================================
# 2. DATA MODEL TESTS
# ==============================================================================

class TestModels:
    """Tests for the dataclasses used as data models."""

    def test_applicant_creation(self):
        """FR1: Test if an Applicant object can be created with correct attributes."""
        applicant = Applicant(
            applicant_id=101,
            name="Jane Doe",
            gpa=3.9,
            test_score=1550,
            geography="Northeast",
            demographics={"first_generation": "Yes"},
        )
        assert applicant.applicant_id == 101
        assert applicant.gpa == 3.9
        assert applicant.geography == "Northeast"
        assert applicant.demographics["first_generation"] == "Yes"

    def test_applicant_is_immutable(self, diverse_applicants):
        """Test that Applicant dataclass is frozen."""
        applicant = diverse_applicants[0]
        with pytest.raises(AttributeError):
            # Attempting to modify a frozen dataclass raises an error.
            applicant.gpa = 3.5

    def test_admission_result_is_immutable(self, diverse_applicants):
        """Test that AdmissionResult dataclass is frozen."""
        result = AdmissionResult(
            applicant=diverse_applicants[0],
            scores={"academic": 95.0},
            holistic_score=90.0,
            decision=Decision.ADMIT,
        )
        with pytest.raises(AttributeError):
            result.decision = Decision.REJECT


# ==============================================================================
# 3. CORE COMPONENT TESTS
# ==============================================================================

class TestHolisticScorer:
    """Tests the HolisticScorer component."""

    def test_academic_score_perfect(self, test_config):
        """Test academic score for a perfect applicant."""
        scorer = HolisticScorer([], test_config)
        applicant = Applicant(applicant_id=1, name="Perfect", gpa=4.0, test_score=1600, geography="NA")
        score = scorer._calculate_academic_score(applicant)
        assert score == pytest.approx(100.0)

    def test_academic_score_zero(self, test_config):
        """Test academic score for an applicant with zero scores."""
        scorer = HolisticScorer([], test_config)
        applicant = Applicant(applicant_id=2, name="Zero", gpa=0.0, test_score=0, geography="NA")
        score = scorer._calculate_academic_score(applicant)
        assert score == pytest.approx(0.0)

    def test_academic_score_exceeds_caps(self, test_config):
        """Test that scores are capped at the maximum values."""
        scorer = HolisticScorer([], test_config)
        # These values, though unrealistic, test the normalization cap.
        applicant = Applicant(applicant_id=3, name="Overachiever", gpa=5.0, test_score=2000, geography="NA")
        score = scorer._calculate_academic_score(applicant)
        assert score == pytest.approx(100.0)

    def test_academic_score_average(self, test_config):
        """Test academic score for a typical applicant."""
        scorer = HolisticScorer([], test_config)
        applicant = Applicant(applicant_id=4, name="Average", gpa=3.0, test_score=1200, geography="NA")
        # GPA component: (3.0 / 4.0) * 100 = 75
        # Test score component: (1200 / 1600) * 100 = 75
        # Average: (75 + 75) / 2 = 75
        score = scorer._calculate_academic_score(applicant)
        assert score == pytest.approx(75.0)

    def test_geographic_scores_empty_pool(self, test_config):
        """Test geographic scoring with no applicants."""
        scorer = HolisticScorer([], test_config)
        assert scorer._geographic_need_scores == {}

    def test_geographic_scores_skewed_pool(self, diverse_applicants, test_config):
        """FR5: Test that under/over-represented regions are scored correctly."""
        scorer = HolisticScorer(diverse_applicants, test_config)
        scores = scorer._geographic_need_scores

        # 'International' has 0 applicants, should get the highest score (100).
        assert scores["International"] == pytest.approx(100.0)

        # 'Northeast' is over-represented, should get the lowest score (0).
        assert scores["Northeast"] == pytest.approx(0.0)
        
        # 'South' and 'West' are under-represented, should get scores between 0 and 100.
        assert 0 < scores["South"] < 100
        assert 0 < scores["West"] < 100

        # West is more under-represented than South, so it should have a higher score.
        assert scores["West"] > scores["South"]

    def test_geographic_scores_balanced_pool(self, test_config):
        """Test geographic scoring with a perfectly balanced applicant pool."""
        applicants = [
            Applicant(applicant_id=1, name="A", gpa=3.5, test_score=1300, geography="Northeast"),
            Applicant(applicant_id=2, name="B", gpa=3.5, test_score=1300, geography="Northeast"),
            Applicant(applicant_id=3, name="C", gpa=3.5, test_score=1300, geography="Midwest"),
            Applicant(applicant_id=4, name="D", gpa=3.5, test_score=1300, geography="Midwest"),
            Applicant(applicant_id=5, name="E", gpa=3.5, test_score=1300, geography="South"),
            Applicant(applicant_id=6, name="F", gpa=3.5, test_score=1300, geography="South"),
            Applicant(applicant_id=7, name="G", gpa=3.5, test_score=1300, geography="South"),
            Applicant(applicant_id=8, name="H", gpa=3.5, test_score=1300, geography="West"),
            Applicant(applicant_id=9, name="I", gpa=3.5, test_score=1300, geography="West"),
            # Missing West & International to meet 100%
        ]
        # This pool is not perfectly balanced, let's create a perfectly balanced one.
        # Target: NE 20%, MW 20%, S 30%, W 25%, I 5%
        # Pool of 20 students: NE(4), MW(4), S(6), W(5), I(1)
        balanced_pool = (
            [Applicant(1, "N", 3.0, 1200, "Northeast")] * 4 +
            [Applicant(2, "M", 3.0, 1200, "Midwest")] * 4 +
            [Applicant(3, "S", 3.0, 1200, "South")] * 6 +
            [Applicant(4, "W", 3.0, 1200, "West")] * 5 +
            [Applicant(5, "I", 3.0, 1200, "International")] * 1
        )
        scorer = HolisticScorer(balanced_pool, test_config)
        scores = scorer._geographic_need_scores
        # In a perfectly balanced pool, all need factors are 1.0, so all scores should be equal (50.0).
        for score in scores.values():
            assert score == pytest.approx(50.0)

    def test_calculate_all_scores(self, diverse_applicants, test_config):
        """FR2: Test the final holistic score calculation."""
        scorer = HolisticScorer(diverse_applicants, test_config)
        
        # Test applicant from unknown region ("Territories")
        unknown_region_applicant = next(a for a in diverse_applicants if a.geography == "Territories")
        scores = scorer.calculate_all_scores(unknown_region_applicant)
        assert scores["geographic"] == 0.0  # Should default to 0
        expected_academic = scorer._calculate_academic_score(unknown_region_applicant)
        expected_holistic = expected_academic * test_config["scoring_weights"]["academic"]
        assert scores["academic"] == pytest.approx(expected_academic)
        assert scores["holistic"] == pytest.approx(expected_holistic)

        # Test applicant from an over-represented region ("Northeast")
        northeast_applicant = next(a for a in diverse_applicants if a.geography == "Northeast")
        scores = scorer.calculate_all_scores(northeast_applicant)
        assert scores["geographic"] == pytest.approx(0.0) # Should be lowest score
        expected_academic = scorer._calculate_academic_score(northeast_applicant)
        expected_holistic = expected_academic * test_config["scoring_weights"]["academic"]
        assert scores["holistic"] == pytest.approx(expected_holistic)


class TestDecisionEngine:
    """Tests the DecisionEngine component."""

    @pytest.mark.parametrize(
        "score, expected_decision",
        [
            # Boundary conditions
            (80.0, Decision.ADMIT),    # Exactly on admit threshold
            (79.99, Decision.WAITLIST), # Just below admit
            (65.0, Decision.WAITLIST),  # Exactly on waitlist threshold
            (64.99, Decision.REJECT),   # Just below waitlist
            # Standard cases
            (95.5, Decision.ADMIT),
            (72.0, Decision.WAITLIST),
            (50.0, Decision.REJECT),
            # Edge cases
            (100.0, Decision.ADMIT),
            (0.0, Decision.REJECT),
            (-10.0, Decision.REJECT), # Should handle negative scores
        ],
    )
    def test_make_decision(self, score, expected_decision, test_config):
        """FR3: Test decision logic across thresholds and edge cases."""
        engine = DecisionEngine(test_config)
        decision = engine.make_decision(score)
        assert decision == expected_decision


class TestSummaryReporter:
    """Tests the SummaryReporter component."""

    def test_generate_with_no_results(self, test_config):
        """Test report generation when no results are provided."""
        reporter = SummaryReporter(test_config)
        report = reporter.generate([], total_applicants=0)
        assert "No results to report" in report

    def test_generate_with_no_admitted_students(self, diverse_applicants, test_config):
        """Test report when there are results but no one is admitted."""
        reporter = SummaryReporter(test_config)
        # Create a result set where everyone is rejected
        results = [
            AdmissionResult(app, {}, 50.0, Decision.REJECT) for app in diverse_applicants
        ]
        report = reporter.generate(results, len(results))
        assert "No applicants were admitted" in report
        assert "Admitted:   0" in report # Check overall stats
        assert "Rejected:   9" in report
    
    def test_generate_full_report(self, diverse_applicants, test_config):
        """FR4 & NFR2: Test a complete, standard report generation."""
        reporter = SummaryReporter(test_config)
        results = [
            AdmissionResult(diverse_applicants[0], {}, 95.0, Decision.ADMIT), # West
            AdmissionResult(diverse_applicants[1], {}, 88.0, Decision.ADMIT), # South
            AdmissionResult(diverse_applicants[2], {}, 75.0, Decision.WAITLIST),
            AdmissionResult(diverse_applicants[3], {}, 60.0, Decision.REJECT),
        ]
        report = reporter.generate(results, total_applicants=10) # Mock total

        # NFR2: Check for transparent metrics
        assert "Holistic Score Formula: (70% Academic) + (30% Geographic)" in report
        assert "Admit: Score >= 80.0" in report
        
        # FR4: Check for overall stats
        assert "Total Applicants: 10" in report
        assert "Admitted:   2" in report
        assert "Waitlisted: 1" in report
        assert "Rejected:   1" in report

        # FR4: Check for admitted cohort profile
        assert "Number of Admitted Students: 2" in report
        # Avg GPA: (4.0 + 3.8) / 2 = 3.9
        assert "Average GPA: 3.90" in report
        # Avg Test Score: (1600 + 1500) / 2 = 1550
        assert "Average Test Score: 1550" in report
        # Geographic distribution of admitted (1 West, 1 South)
        assert "West             : 1   students ( 50.00%) | Target: 25.00%" in report
        assert "South            : 1   students ( 50.00%) | Target: 30.00%" in report
        assert "Northeast        : 0   students (  0.00%) | Target: 20.00%" in report


# ==============================================================================
# 4. ORCHESTRATOR TESTS
# ==============================================================================

class TestAdmissionsProcessor:
    """Tests the main AdmissionsProcessor orchestrator."""

    def test_init_raises_error_on_bad_weights(self, diverse_applicants):
        """Test that invalid scoring weights raise a ValueError."""
        bad_config = {
            "scoring_weights": {"academic": 0.5, "geographic": 0.4}, # Sums to 0.9
            "decision_thresholds": {}, "normalization_caps": {},
            "target_geographic_distribution": {}
        }
        with pytest.raises(ValueError, match="Scoring weights must sum to 1.0"):
            AdmissionsProcessor(diverse_applicants, bad_config)

    def test_process_applications_empty_list(self, test_config, capsys):
        """Test processing with an empty list of applicants."""
        processor = AdmissionsProcessor([], test_config)
        processor.process_applications()
        captured = capsys.readouterr()
        assert "No applicants to screen" in captured.out
        assert not processor.results

    def test_process_applications_populates_results(self, diverse_applicants, test_config):
        """Test that processing correctly populates the results list."""
        processor = AdmissionsProcessor(diverse_applicants, test_config)
        assert not processor.results
        
        processor.process_applications()
        
        assert len(processor.results) == len(diverse_applicants)
        assert all(isinstance(r, AdmissionResult) for r in processor.results)
        # Check if a result corresponds to an applicant
        result_ids = {r.applicant.applicant_id for r in processor.results}
        applicant_ids = {a.applicant_id for a in diverse_applicants}
        assert result_ids == applicant_ids


# ==============================================================================
# 5. HELPER FUNCTION TESTS
# ==============================================================================

class TestHelperFunctions:
    """Tests for helper functions like data generators."""

    def test_generate_mock_applicants(self):
        """NFR1: Test the mock data generation function."""
        count = 50
        applicants = generate_mock_applicants(count)
        assert len(applicants) == count
        assert all(isinstance(app, Applicant) for app in applicants)

        # Check if generated values are within reasonable bounds
        for app in applicants:
            assert 0.0 <= app.gpa <= ADMISSIONS_CONFIG["normalization_caps"]["max_gpa"]
            assert 0 <= app.test_score <= ADMISSIONS_CONFIG["normalization_caps"]["max_test_score"]
            assert app.geography in ADMISSIONS_CONFIG["target_geographic_distribution"]