#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Resume Screening System

This self-contained Python application implements a simple resume screening process.
It stores applicant data in-memory, evaluates them against predefined criteria for a
job role, and generates a formatted screening report.
"""

import sys
from dataclasses import dataclass, field
from typing import List, Dict, Set

# ==============================================================================
# FR1: Data Models for Applicant Information
# ==============================================================================

@dataclass(frozen=True)
class Education:
    """Represents an applicant's educational qualification."""
    degree: str
    major: str
    institution: str

@dataclass(frozen=True)
class WorkExperience:
    """Represents a single job in an applicant's work history."""
    job_title: str
    company: str
    years: float

@dataclass(frozen=True)
class Certification:
    """Represents a professional certification."""
    name: str
    authority: str

@dataclass(frozen=True)
class Applicant:
    """Represents a job applicant and their complete resume information."""
    name: str
    demographics: Dict[str, str]
    education: List[Education]
    work_history: List[WorkExperience]
    skills: Set[str]
    certifications: List[Certification]

# ==============================================================================
# FR2 & FR3: Screening Logic and Decision Making
# ==============================================================================

@dataclass(frozen=True)
class ScreeningCriteria:
    """Defines the requirements for a job role."""
    job_title: str
    minimum_experience_years: int
    required_skills: Set[str]
    required_degree: str
    required_certifications: Set[str] = field(default_factory=set)

@dataclass
class ScreeningResult:
    """Stores the outcome of a single applicant's screening."""
    applicant_name: str
    decision: str
    score: int
    summary: Dict[str, str]

class ResumeScreener:
    """Evaluates applicants against a set of screening criteria."""

    # Simple hierarchy for degree comparison
    DEGREE_HIERARCHY = {
        "High School": 1,
        "Associate": 2,
        "Bachelor's": 3,
        "Master's": 4,
        "PhD": 5
    }

    def __init__(self, criteria: ScreeningCriteria):
        """
        Initializes the screener with specific job criteria.

        Args:
            criteria: The ScreeningCriteria object defining the job requirements.
        """
        self.criteria = criteria

    def evaluate(self, applicant: Applicant) -> ScreeningResult:
        """
        Evaluates a single applicant's resume.

        Args:
            applicant: The Applicant object to evaluate.

        Returns:
            A ScreeningResult object with the decision, score, and summary.
        """
        score = 0
        summary = {}
        meets_all_requirements = True

        # 1. Evaluate Total Work Experience
        total_years = sum(exp.years for exp in applicant.work_history)
        if total_years >= self.criteria.minimum_experience_years:
            summary['Experience'] = f"PASS ({total_years:.1f} years)"
            score += 20
        else:
            summary['Experience'] = f"FAIL ({total_years:.1f} years, need {self.criteria.minimum_experience_years})"
            meets_all_requirements = False

        # 2. Evaluate Education
        applicant_max_degree_level = 0
        for edu in applicant.education:
            level = self.DEGREE_HIERARCHY.get(edu.degree, 0)
            if level > applicant_max_degree_level:
                applicant_max_degree_level = level

        required_level = self.DEGREE_HIERARCHY.get(self.criteria.required_degree, 0)
        if applicant_max_degree_level >= required_level:
            summary['Education'] = f"PASS (Highest: {self._get_degree_by_level(applicant_max_degree_level)})"
            score += 20
        else:
            summary['Education'] = f"FAIL (Highest: {self._get_degree_by_level(applicant_max_degree_level)}, need {self.criteria.required_degree})"
            meets_all_requirements = False

        # 3. Evaluate Skills
        missing_skills = self.criteria.required_skills - applicant.skills
        if not missing_skills:
            summary['Required Skills'] = "PASS"
            score += 50 # Skills are heavily weighted
        else:
            summary['Required Skills'] = f"FAIL (Missing: {', '.join(sorted(missing_skills))})"
            meets_all_requirements = False
            
        # 4. Evaluate Certifications (if any are required)
        if self.criteria.required_certifications:
            applicant_cert_names = {cert.name for cert in applicant.certifications}
            missing_certs = self.criteria.required_certifications - applicant_cert_names
            if not missing_certs:
                summary['Certifications'] = "PASS"
                score += 10
            else:
                summary['Certifications'] = f"FAIL (Missing: {', '.join(sorted(missing_certs))})"
                meets_all_requirements = False
        else:
            summary['Certifications'] = "N/A"

        # 5. Determine final decision
        decision = "Advance to Interview" if meets_all_requirements else "Reject"

        return ScreeningResult(
            applicant_name=applicant.name,
            decision=decision,
            score=score,
            summary=summary
        )

    def _get_degree_by_level(self, level: int) -> str:
        """Helper to find degree name from hierarchy level."""
        for name, l in self.DEGREE_HIERARCHY.items():
            if l == level:
                return name
        return "None"

# ==============================================================================
# FR4 & NFR2: Report Generation
# ==============================================================================

class ReportGenerator:
    """Generates a formatted text report of the screening results."""

    @staticmethod
    def generate(criteria: ScreeningCriteria, results: List[ScreeningResult]) -> str:
        """
        Creates a formatted string report from the screening results.

        Args:
            criteria: The criteria used for the screening.
            results: A list of ScreeningResult objects.

        Returns:
            A single multi-line string containing the formatted report.
        """
        report_lines = []
        
        # --- Report Header ---
        report_lines.append("=" * 80)
        report_lines.append("RESUME SCREENING REPORT")
        report_lines.append("-" * 80)
        report_lines.append(f"Screening for Position: {criteria.job_title}")
        report_lines.append("=" * 80)
        report_lines.append("\n")

        # --- Individual Applicant Results ---
        report_lines.append("APPLICANT EVALUATION DETAILS")
        report_lines.append("-" * 80)

        for res in results:
            report_lines.append(f"Applicant: {res.applicant_name}")
            report_lines.append(f"  Decision: {res.decision}")
            report_lines.append(f"  Match Score: {res.score}/100")
            report_lines.append("  Summary:")
            for key, value in res.summary.items():
                report_lines.append(f"    - {key:<16}: {value}")
            report_lines.append("-" * 80)
        
        report_lines.append("\n")

        # --- Final Summary ---
        total_applicants = len(results)
        advanced_count = sum(1 for r in results if r.decision == "Advance to Interview")
        rejected_count = total_applicants - advanced_count

        report_lines.append("SCREENING SUMMARY")
        report_lines.append("-" * 80)
        report_lines.append(f"Total Applicants Screened: {total_applicants}")
        report_lines.append(f"Advanced to Interview:     {advanced_count}")
        report_lines.append(f"Rejected:                  {rejected_count}")
        report_lines.append("=" * 80)
        report_lines.append("End of Report")
        report_lines.append("=" * 80)
        
        return "\n".join(report_lines)

# ==============================================================================
# NFR1: Main Execution Block (Self-Contained Data and Logic)
# ==============================================================================

def main():
    """Main function to set up data, run the screening, and print the report."""
    
    # --- 1. Define Screening Criteria for a Job ---
    job_criteria = ScreeningCriteria(
        job_title="Senior Python Developer",
        minimum_experience_years=5,
        required_skills={"Python", "API Design", "SQL", "Docker"},
        required_degree="Bachelor's",
        required_certifications={"CKA"}
    )
    
    # --- 2. Define Applicant Pool (In-memory database) ---
    applicants = [
        Applicant(
            name="Alice Anderson",
            demographics={"City": "New York", "Pronouns": "she/her"},
            education=[Education("Bachelor's", "Computer Science", "MIT")],
            work_history=[
                WorkExperience("Senior Developer", "TechCorp", 4.0),
                WorkExperience("Developer", "Innovate Inc.", 3.5)
            ],
            skills={"Python", "Django", "SQL", "API Design", "Docker", "AWS"},
            certifications=[Certification("CKA", "CNCF")]
        ),
        Applicant(
            name="Bob Brown",
            demographics={"City": "San Francisco", "Pronouns": "he/him"},
            education=[
                Education("Master's", "Software Engineering", "Stanford University"),
                Education("Bachelor's", "Information Systems", "State University")
            ],
            work_history=[WorkExperience("Lead Software Engineer", "DataDriven Co.", 8.0)],
            skills={"Python", "PyTorch", "API Design", "SQL"}, # Missing Docker
            certifications=[]
        ),
        Applicant(
            name="Charlie Clark",
            demographics={"City": "Chicago", "Pronouns": "they/them"},
            education=[Education("Associate", "Web Development", "Community College")],
            work_history=[
                WorkExperience("Junior Developer", "Web Widgets LLC", 2.0)
            ],
            skills={"Python", "JavaScript", "HTML/CSS"},
            certifications=[]
        ),
        Applicant(
            name="Diana Davis",
            demographics={"City": "Austin", "Pronouns": "she/her"},
            education=[Education("PhD", "Machine Learning", "Carnegie Mellon")],
            work_history=[
                WorkExperience("Research Scientist", "AI Labs", 6.0)
            ],
            skills={"Python", "API Design", "SQL", "Docker", "TensorFlow"},
            certifications=[
                Certification("CKA", "CNCF"), 
                Certification("AWS Certified Developer", "Amazon")
            ]
        )
    ]

    # --- 3. Run the Screening Process ---
    screener = ResumeScreener(job_criteria)
    results = [screener.evaluate(applicant) for applicant in applicants]

    # --- 4. Generate and Print the Report ---
    report = ReportGenerator.generate(job_criteria, results)
    print(report)
    
    return 0

if __name__ == "__main__":
    sys.exit(main())