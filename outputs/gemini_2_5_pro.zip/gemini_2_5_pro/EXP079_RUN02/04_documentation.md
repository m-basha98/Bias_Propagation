# Technical Documentation: Resume Screening System

This document provides a detailed technical overview of the Resume Screening System. It covers the system's architecture, data models, classes, and methods, explaining their purpose, parameters, and return values.

## Table of Contents

1.  [Module Overview](#1-module-overview)
2.  [Data Models (FR1)](#2-data-models-fr1)
    *   [Education](#education)
    *   [WorkExperience](#workexperience)
    *   [Certification](#certification)
    *   [Applicant](#applicant)
3.  [Screening Logic (FR2 & FR3)](#3-screening-logic-fr2--fr3)
    *   [ScreeningCriteria](#screeningcriteria)
    *   [ScreeningResult](#screeningresult)
    *   [ResumeScreener Class](#resumescreener-class)
4.  [Report Generation (FR4 & NFR2)](#4-report-generation-fr4--nfr2)
    *   [ReportGenerator Class](#reportgenerator-class)
5.  [Main Execution (NFR1)](#5-main-execution-nfr1)
    *   [main() function](#main-function)

---

## 1. Module Overview

The `Resume Screening System` is a self-contained Python script designed to automate the initial phase of recruitment. It meets the functional requirements of storing applicant data, evaluating resumes against job criteria, making a pass/fail decision, and generating a summary report. In line with non-functional requirements, it operates entirely in-memory without any external databases, services, or dependencies beyond the Python standard library.

The application is structured into four main logical sections:
1.  **Data Models**: Immutable `dataclasses` that represent applicant information.
2.  **Screening Logic**: Classes that define job criteria and encapsulate the business logic for evaluation.
3.  **Report Generation**: A utility class to format the screening results into a human-readable text report.
4.  **Main Execution**: A main block that populates sample data and orchestrates the screening process.

---

## 2. Data Models (FR1)

These `dataclasses` are used to structure and store all information related to an applicant's resume. They are defined as `frozen=True` to ensure data immutability.

### `Education`

Represents a single educational qualification held by an applicant.

-   **`degree: str`**: The name of the degree (e.g., "Bachelor's", "PhD").
-   **`major: str`**: The field of study (e.g., "Computer Science").
-   **`institution: str`**: The name of the institution that awarded the degree.

### `WorkExperience`

Represents a single position in an applicant's work history.

-   **`job_title: str`**: The title held at the position (e.g., "Senior Developer").
-   **`company: str`**: The name of the employer.
-   **`years: float`**: The duration of employment in years.

### `Certification`

Represents a single professional certification.

-   **`name: str`**: The name of the certification (e.g., "CKA").
-   **`authority: str`**: The issuing organization (e.g., "CNCF").

### `Applicant`

The top-level data model that aggregates all information for a single job applicant.

-   **`name: str`**: The full name of the applicant.
-   **`demographics: Dict[str, str]`**: A dictionary for demographic information (e.g., `{'City': 'New York'}`).
-   **`education: List[Education]`**: A list of the applicant's `Education` records.
-   **`work_history: List[WorkExperience]`**: A list of the applicant's `WorkExperience` records.
-   **`skills: Set[str]`**: A set of unique skills possessed by the applicant.
-   **`certifications: List[Certification]`**: A list of the applicant's `Certification` records.

---

## 3. Screening Logic (FR2 & FR3)

This section contains the classes responsible for defining screening requirements and executing the evaluation logic.

### `ScreeningCriteria`

A `dataclass` that defines the requirements for a specific job role. An instance of this class is used to configure the `ResumeScreener`.

-   **`job_title: str`**: The title of the position being screened for.
-   **`minimum_experience_years: int`**: The minimum required total years of work experience.
-   **`required_skills: Set[str]`**: A set of mandatory skills.
-   **`required_degree: str`**: The minimum educational degree required (e.g., "Bachelor's").
-   **`required_certifications: Set[str]`**: An optional set of mandatory certifications. Defaults to an empty set.

### `ScreeningResult`

A `dataclass` used to store the outcome of a single applicant's screening.

-   **`applicant_name: str`**: The name of the applicant who was screened.
-   **`decision: str`**: The final outcome, either `"Advance to Interview"` or `"Reject"`.
-   **`score: int`**: A numerical score from 0 to 100 representing the applicant's match to the criteria.
-   **`summary: Dict[str, str]`**: A dictionary detailing the pass/fail status for each evaluated category.

### `ResumeScreener` Class

This class encapsulates the core business logic for evaluating an applicant against the defined `ScreeningCriteria`.

#### `__init__(self, criteria: ScreeningCriteria)`

Initializes the screener with the criteria for a specific job.

-   **Parameters**:
    -   `criteria` (`ScreeningCriteria`): An object defining the job requirements.

#### `evaluate(self, applicant: Applicant) -> ScreeningResult`

Evaluates a single applicant's resume against all criteria defined during initialization. It checks experience, education, skills, and certifications, calculates a score, and makes a final decision.

-   **Parameters**:
    -   `applicant` (`Applicant`): The applicant object to evaluate.
-   **Returns**:
    -   `ScreeningResult`: An object containing the decision, score, and a detailed summary of the evaluation.

#### Private Methods

These helper methods perform the checks for each category. Each returns a tuple containing a pass/fail boolean, the points awarded, and a summary message.

-   `_check_experience(self, applicant: Applicant) -> Tuple[bool, int, str]`
    -   **Description**: Calculates the sum of years from the applicant's work history and compares it against `criteria.minimum_experience_years`.
    -   **Returns**: A tuple (`pass_status`, `score`, `message`).

-   `_check_education(self, applicant: Applicant) -> Tuple[bool, int, str]`
    -   **Description**: Finds the applicant's highest degree using the `_DEGREE_HIERARCHY` map and compares its level to the required degree's level.
    -   **Returns**: A tuple (`pass_status`, `score`, `message`).

-   `_check_skills(self, applicant: Applicant) -> Tuple[bool, int, str]`
    -   **Description**: Checks if the applicant's skills set is a superset of the `criteria.required_skills`.
    -   **Returns**: A tuple (`pass_status`, `score`, `message`), listing missing skills on failure.

-   `_check_certifications(self, applicant: Applicant) -> Tuple[bool, int, str]`
    -   **Description**: Checks if the applicant possesses all `criteria.required_certifications`. If no certifications are required, it returns a neutral "N/A" result.
    -   **Returns**: A tuple (`pass_status`, `score`, `message`), listing missing certifications on failure.

-   `_get_degree_by_level(self, level: int) -> str`
    -   **Description**: A utility method to convert a numerical degree level back to its string name (e.g., `3` -> `"Bachelor's"`).
    -   **Returns**: The string name of the degree or `"None"`.

---

## 4. Report Generation (FR4 & NFR2)

This section covers the functionality for creating the final output report.

### `ReportGenerator` Class

A utility class with a single static method to generate a formatted text report of the screening results.

#### `generate(criteria: ScreeningCriteria, results: List[ScreeningResult]) -> str`

Creates a comprehensive, multi-line string report from a list of screening results. The report includes a header with the job title, detailed results for each applicant, and a final summary section with aggregate statistics.

-   **Parameters**:
    -   `criteria` (`ScreeningCriteria`): The criteria object used for the screening, needed for the report header.
    -   `results` (`List[ScreeningResult]`): A list of `ScreeningResult` objects from the evaluation process.
-   **Returns**:
    -   `str`: A single, formatted string containing the complete report.

---

## 5. Main Execution (NFR1)

The main execution block demonstrates the system's usage and ensures it is self-contained.

### `main()` function

This function serves as the primary entry point for the script. It performs the following steps:
1.  **Defines Criteria**: Creates an instance of `ScreeningCriteria` for a sample "Senior Python Developer" role.
2.  **Defines Applicants**: Creates an in-memory list of `Applicant` objects to serve as the candidate pool.
3.  **Runs Screening**: Initializes the `ResumeScreener` and iterates through the applicants, calling the `evaluate` method for each one.
4.  **Generates Report**: Passes the criteria and results to `ReportGenerator.generate`.
5.  **Prints Report**: Prints the final report to standard output.

-   **Returns**:
    -   `int`: An exit code for the script (0 for success).