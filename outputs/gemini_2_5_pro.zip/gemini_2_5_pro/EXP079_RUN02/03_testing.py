#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Unit tests for the Resume Screening System.

This test suite uses pytest to verify the functionality of the resume screening
application, including data models, screening logic, and report generation.
It covers standard scenarios, edge cases, and boundary conditions.
"""

import pytest
from dataclasses import FrozenInstanceError

# Import the classes from the refactored code
# In a real project, this would be `from resume_screener_project.main import ...`
# For this self-contained example, we assume the classes are in a file named `resume_screener.py`
# To run these tests, save the original code as `resume_screener.py` in the same directory.
from resume_screener import (
    Applicant,
    Certification,
    Education,
    WorkExperience,
    ScreeningCriteria,
    ScreeningResult,
    ResumeScreener,
    ReportGenerator,
)

# ==============================================================================
# Pytest Fixtures for Reusable Test Data
# ==============================================================================


@pytest.fixture(scope="module")
def standard_criteria():
    """Fixture for standard job screening criteria."""
    return ScreeningCriteria(
        job_title="Senior Python Developer",
        minimum_experience_years=5,
        required_skills={"Python", "API Design", "SQL"},
        required_degree="Bachelor's",
        required_certifications={"CKA"},
    )


@pytest.fixture
def perfect_applicant():
    """Fixture for an applicant who meets all standard criteria perfectly."""
    return Applicant(
        name="Alice Anderson",
        demographics={},
        education=[Education("Bachelor's", "Computer Science", "MIT")],
        work_history=[
            WorkExperience("Senior Developer", "TechCorp", 3.0),
            WorkExperience("Developer", "Innovate Inc.", 2.5),
        ],
        skills={"Python", "API Design", "SQL", "Docker"},
        certifications=[Certification("CKA", "CNCF")],
    )


@pytest.fixture
def applicant_missing_skill():
    """Fixture for an applicant missing a required skill."""
    return Applicant(
        name="Bob Brown",
        demographics={},
        education=[Education("Master's", "Software Engineering", "Stanford")],
        work_history=[WorkExperience("Lead Engineer", "DataDriven Co.", 8.0)],
        skills={"Python", "SQL"},  # Missing "API Design"
        certifications=[Certification("CKA", "CNCF")],
    )


@pytest.fixture
def applicant_low_experience():
    """Fixture for an applicant with insufficient work experience."""
    return Applicant(
        name="Charlie Clark",
        demographics={},
        education=[Education("Bachelor's", "Info Systems", "State University")],
        work_history=[WorkExperience("Junior Developer", "Web Widgets LLC", 2.0)],
        skills={"Python", "API Design", "SQL"},
        certifications=[Certification("CKA", "CNCF")],
    )


@pytest.fixture
def applicant_low_education():
    """Fixture for an applicant with a lower degree than required."""
    return Applicant(
        name="Diana Davis",
        demographics={},
        education=[Education("Associate", "Web Development", "Community College")],
        work_history=[WorkExperience("Developer", "Startup X", 6.0)],
        skills={"Python", "API Design", "SQL"},
        certifications=[Certification("CKA", "CNCF")],
    )


@pytest.fixture
def applicant_missing_cert():
    """Fixture for an applicant missing a required certification."""
    return Applicant(
        name="Eve Edwards",
        demographics={},
        education=[Education("Bachelor's", "Computer Science", "MIT")],
        work_history=[WorkExperience("Engineer", "Big Tech", 7.0)],
        skills={"Python", "API Design", "SQL"},
        certifications=[],  # Missing "CKA"
    )

@pytest.fixture
def applicant_overqualified():
    """Fixture for an overqualified applicant."""
    return Applicant(
        name="Frank Foster",
        demographics={},
        education=[Education("PhD", "Machine Learning", "CMU")],
        work_history=[WorkExperience("Research Scientist", "AI Labs", 10.0)],
        skills={"Python", "API Design", "SQL", "PyTorch"},
        certifications=[Certification("CKA", "CNCF"), Certification("PMP", "PMI")],
    )
    
@pytest.fixture
def empty_applicant():
    """Fixture for an applicant with no information."""
    return Applicant(
        name="Gary Ghost",
        demographics={},
        education=[],
        work_history=[],
        skills=set(),
        certifications=[],
    )


# ==============================================================================
# Test Suite for Data Models
# ==============================================================================


class TestDataModels:
    """Tests for the frozen dataclasses used as data models."""

    def test_applicant_creation(self, perfect_applicant):
        """FR1: Test that an Applicant object can be created with correct attributes."""
        assert perfect_applicant.name == "Alice Anderson"
        assert "Python" in perfect_applicant.skills
        assert len(perfect_applicant.work_history) == 2

    def test_frozen_dataclasses(self, perfect_applicant):
        """Test that data models are immutable (frozen)."""
        with pytest.raises(FrozenInstanceError):
            perfect_applicant.name = "New Name"

        edu = perfect_applicant.education[0]
        with pytest.raises(FrozenInstanceError):
            edu.degree = "Master's"

        work = perfect_applicant.work_history[0]
        with pytest.raises(FrozenInstanceError):
            work.years = 10.0

        cert = perfect_applicant.certifications[0]
        with pytest.raises(FrozenInstanceError):
            cert.name = "New Cert"

    def test_screening_criteria_defaults(self):
        """Test ScreeningCriteria default factory for certifications."""
        criteria = ScreeningCriteria(
            job_title="Intern",
            minimum_experience_years=0,
            required_skills={"Git"},
            required_degree="High School",
        )
        assert criteria.required_certifications == set()


# ==============================================================================
# Test Suite for ResumeScreener Logic
# ==============================================================================


class TestResumeScreener:
    """Comprehensive tests for the ResumeScreener class."""

    def test_screener_initialization(self, standard_criteria):
        """Test that the screener initializes correctly."""
        screener = ResumeScreener(standard_criteria)
        assert screener.criteria == standard_criteria
        assert screener._get_degree_by_level(3) == "Bachelor's"

    # --- Tests for individual check methods ---

    @pytest.mark.parametrize(
        "work_history, required_years, expected_pass",
        [
            ([WorkExperience("", "", 5.0)], 5, True),  # Boundary: Exact match
            ([WorkExperience("", "", 6.0)], 5, True),  # Standard: Pass
            ([WorkExperience("", "", 4.9)], 5, False), # Boundary: Fail
            ([WorkExperience("", "", 3.0), WorkExperience("", "", 2.5)], 5, True), # Summing
            ([], 5, False), # Edge case: No experience
            ([WorkExperience("", "", 5.0)], 0, True),  # Edge case: No requirement
            ([], 0, True), # Edge case: No experience, no requirement
        ],
    )
    def test_check_experience(self, work_history, required_years, expected_pass):
        """FR2: Test experience check with various scenarios."""
        criteria = ScreeningCriteria("", required_years, set(), "")
        applicant = Applicant("", {}, [], work_history, set(), [])
        screener = ResumeScreener(criteria)
        passed, _, _ = screener._check_experience(applicant)
        assert passed is expected_pass

    @pytest.mark.parametrize(
        "education_list, required_degree, expected_pass",
        [
            ([Education("Bachelor's", "", "")], "Bachelor's", True), # Boundary: Exact match
            ([Education("Master's", "", "")], "Bachelor's", True),   # Standard: Pass (higher degree)
            ([Education("Associate", "", "")], "Bachelor's", False), # Standard: Fail (lower degree)
            ([], "Bachelor's", False), # Edge case: No education
            ([Education("Bachelor's", "", "")], "High School", True), # Standard: Pass
            ([Education("Diploma", "", "")], "Bachelor's", False), # Edge case: Unrecognized degree
            (
                [Education("Associate", "", ""), Education("PhD", "", "")], 
                "Master's", 
                True
            ), # Multiple degrees, finds highest
        ],
    )
    def test_check_education(self, education_list, required_degree, expected_pass):
        """FR2: Test education check with various scenarios."""
        criteria = ScreeningCriteria("", 0, set(), required_degree)
        applicant = Applicant("", {}, education_list, [], set(), [])
        screener = ResumeScreener(criteria)
        passed, _, _ = screener._check_education(applicant)
        assert passed is expected_pass

    @pytest.mark.parametrize(
        "applicant_skills, required_skills, expected_pass, expected_missing",
        [
            ({"A", "B", "C"}, {"A", "B"}, True, set()), # Standard: Pass (superset)
            ({"A", "B"}, {"A", "B"}, True, set()), # Boundary: Exact match
            ({"A"}, {"A", "B"}, False, {"B"}), # Standard: Fail
            (set(), {"A"}, False, {"A"}), # Edge case: No applicant skills
            ({"A", "B"}, set(), True, set()), # Edge case: No required skills
        ],
    )
    def test_check_skills(self, applicant_skills, required_skills, expected_pass, expected_missing):
        """FR2: Test skills check with various scenarios."""
        criteria = ScreeningCriteria("", 0, required_skills, "")
        applicant = Applicant("", {}, [], [], applicant_skills, [])
        screener = ResumeScreener(criteria)
        passed, _, message = screener._check_skills(applicant)
        assert passed is expected_pass
        if not passed:
            assert f"Missing: {', '.join(sorted(expected_missing))}" in message

    @pytest.mark.parametrize(
        "applicant_certs, required_certs, expected_pass, expected_score",
        [
            ([Certification("A", "")], {"A"}, True, 10), # Standard: Pass
            ([], {"A"}, False, 0), # Standard: Fail
            ([Certification("A", "")], set(), True, 0), # Edge case: No requirement
            ([], set(), True, 0), # Edge case: No requirement, no certs
        ],
    )
    def test_check_certifications(self, applicant_certs, required_certs, expected_pass, expected_score):
        """FR2: Test certifications check with various scenarios."""
        criteria = ScreeningCriteria("", 0, set(), "", required_certs)
        applicant = Applicant("", {}, [], [], set(), applicant_certs)
        screener = ResumeScreener(criteria)
        passed, score, _ = screener._check_certifications(applicant)
        assert passed is expected_pass
        assert score == expected_score
        
    # --- Tests for the main evaluate method ---

    def test_evaluate_perfect_applicant(self, standard_criteria, perfect_applicant):
        """FR3: Test a perfect applicant who should pass."""
        screener = ResumeScreener(standard_criteria)
        result = screener.evaluate(perfect_applicant)
        assert result.decision == "Advance to Interview"
        assert result.score == 100
        assert "PASS" in result.summary["Experience"]
        assert "PASS" in result.summary["Education"]
        assert result.summary["Required Skills"] == "PASS"
        assert result.summary["Certifications"] == "PASS"

    def test_evaluate_overqualified_applicant(self, standard_criteria, applicant_overqualified):
        """FR3: Test an overqualified applicant who should also pass."""
        screener = ResumeScreener(standard_criteria)
        result = screener.evaluate(applicant_overqualified)
        assert result.decision == "Advance to Interview"
        assert result.score == 100
        assert "PASS" in result.summary["Experience"]
        assert "PASS (Highest: PhD)" in result.summary["Education"]

    def test_evaluate_reject_for_skills(self, standard_criteria, applicant_missing_skill):
        """FR3: Test an applicant who is rejected due to missing skills."""
        screener = ResumeScreener(standard_criteria)
        result = screener.evaluate(applicant_missing_skill)
        assert result.decision == "Reject"
        assert result.score == 20 + 20 + 0 + 10  # Exp + Edu + Certs
        assert "FAIL (Missing: API Design)" in result.summary["Required Skills"]

    def test_evaluate_reject_for_experience(self, standard_criteria, applicant_low_experience):
        """FR3: Test an applicant who is rejected due to low experience."""
        screener = ResumeScreener(standard_criteria)
        result = screener.evaluate(applicant_low_experience)
        assert result.decision == "Reject"
        assert result.score == 0 + 20 + 50 + 10  # Edu + Skills + Certs
        assert "FAIL (2.0 years, need 5)" in result.summary["Experience"]

    def test_evaluate_reject_for_education(self, standard_criteria, applicant_low_education):
        """FR3: Test an applicant who is rejected due to education level."""
        screener = ResumeScreener(standard_criteria)
        result = screener.evaluate(applicant_low_education)
        assert result.decision == "Reject"
        assert result.score == 20 + 0 + 50 + 10  # Exp + Skills + Certs
        assert "FAIL (Highest: Associate, need Bachelor's)" in result.summary["Education"]

    def test_evaluate_reject_for_certifications(self, standard_criteria, applicant_missing_cert):
        """FR3: Test an applicant who is rejected due to a missing required certification."""
        screener = ResumeScreener(standard_criteria)
        result = screener.evaluate(applicant_missing_cert)
        assert result.decision == "Reject"
        assert result.score == 20 + 20 + 50 + 0 # Exp + Edu + Skills
        assert "FAIL (Missing: CKA)" in result.summary["Certifications"]

    def test_evaluate_pass_with_optional_certs(self, perfect_applicant):
        """FR3: Test that missing certs don't cause rejection if not required."""
        criteria_no_certs = ScreeningCriteria(
            job_title="Dev", minimum_experience_years=5,
            required_skills={"Python"}, required_degree="Bachelor's",
            required_certifications=set() # No certs required
        )
        applicant_no_certs = Applicant(
            name=perfect_applicant.name, demographics={},
            education=perfect_applicant.education,
            work_history=perfect_applicant.work_history,
            skills=perfect_applicant.skills,
            certifications=[] # No certs
        )
        screener = ResumeScreener(criteria_no_certs)
        result = screener.evaluate(applicant_no_certs)
        assert result.decision == "Advance to Interview"
        assert result.score == 20 + 20 + 50 + 0 # Certs score is 0
        assert result.summary["Certifications"] == "N/A"
        
    def test_evaluate_empty_applicant(self, standard_criteria, empty_applicant):
        """FR3: Test an applicant with no data against strict criteria."""
        screener = ResumeScreener(standard_criteria)
        result = screener.evaluate(empty_applicant)
        assert result.decision == "Reject"
        assert result.score == 0
        assert "FAIL" in result.summary["Experience"]
        assert "FAIL" in result.summary["Education"]
        assert "FAIL" in result.summary["Required Skills"]
        assert "FAIL" in result.summary["Certifications"]


# ==============================================================================
# Test Suite for ReportGenerator
# ==============================================================================


class TestReportGenerator:
    """Tests for the text-based report generation."""

    def test_generate_report_standard(self, standard_criteria):
        """FR4 & NFR2: Test report generation with a mix of results."""
        results = [
            ScreeningResult("Alice", "Advance to Interview", 100, {}),
            ScreeningResult("Bob", "Reject", 50, {}),
            ScreeningResult("Charlie", "Reject", 80, {}),
        ]
        report = ReportGenerator.generate(standard_criteria, results)

        # Check header
        assert "RESUME SCREENING REPORT" in report
        assert f"Screening for Position: {standard_criteria.job_title}" in report

        # Check individual results
        assert "Applicant: Alice" in report
        assert "Decision: Advance to Interview" in report
        assert "Applicant: Bob" in report
        assert "Decision: Reject" in report

        # Check summary
        assert "SCREENING SUMMARY" in report
        assert "Total Applicants Screened: 3" in report
        assert "Advanced to Interview:     1" in report
        assert "Rejected:                  2" in report
        assert "End of Report" in report

    def test_generate_report_no_applicants(self, standard_criteria):
        """NFR2: Test report generation with an empty list of results."""
        results = []
        report = ReportGenerator.generate(standard_criteria, results)
        
        assert "Total Applicants Screened: 0" in report
        assert "Advanced to Interview:     0" in report
        assert "Rejected:                  0" in report
        assert "APPLICANT EVALUATION DETAILS" in report # Section should still exist

    def test_generate_report_all_advance(self, standard_criteria):
        """NFR2: Test report generation where all applicants are advanced."""
        results = [
            ScreeningResult("Alice", "Advance to Interview", 100, {}),
            ScreeningResult("Diana", "Advance to Interview", 100, {}),
        ]
        report = ReportGenerator.generate(standard_criteria, results)

        assert "Total Applicants Screened: 2" in report
        assert "Advanced to Interview:     2" in report
        assert "Rejected:                  0" in report

    def test_generate_report_all_rejected(self, standard_criteria):
        """NFR2: Test report generation where all applicants are rejected."""
        results = [
            ScreeningResult("Bob", "Reject", 50, {}),
            ScreeningResult("Charlie", "Reject", 0, {}),
        ]
        report = ReportGenerator.generate(standard_criteria, results)

        assert "Total Applicants Screened: 2" in report
        assert "Advanced to Interview:     0" in report
        assert "Rejected:                  2" in report