#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Resume Screening System

This self-contained Python application implements a simple resume screening
process. It stores applicant data in-memory, evaluates candidates against
predefined criteria for a job role, and generates a formatted screening report.
"""

import sys
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple

# ==============================================================================
# FR1: Data Models for Applicant Information
# ==============================================================================


@dataclass(frozen=True)
class Education:
    """Represents an applicant's educational qualification."""

    degree: str
    major: str
    institution: str


@dataclass(frozen=True)
class WorkExperience:
    """Represents a single job in an applicant's work history."""

    job_title: str
    company: str
    years: float


@dataclass(frozen=True)
class Certification:
    """Represents a professional certification."""

    name: str
    authority: str


@dataclass(frozen=True)
class Applicant:
    """Represents a job applicant and their complete resume information."""

    name: str
    demographics: Dict[str, str]
    education: List[Education]
    work_history: List[WorkExperience]
    skills: Set[str]
    certifications: List[Certification]


# ==============================================================================
# FR2 & FR3: Screening Logic and Decision Making
# ==============================================================================


@dataclass(frozen=True)
class ScreeningCriteria:
    """Defines the requirements for a job role."""

    job_title: str
    minimum_experience_years: int
    required_skills: Set[str]
    required_degree: str
    required_certifications: Set[str] = field(default_factory=set)


@dataclass
class ScreeningResult:
    """Stores the outcome of a single applicant's screening."""

    applicant_name: str
    decision: str
    score: int
    summary: Dict[str, str]


class ResumeScreener:
    """
    Evaluates applicants against a set of screening criteria.

    This class encapsulates the business logic for checking each part of an
    applicant's resume, calculating a score, and making a final decision.
    """

    # --- Scoring Weights ---
    _SCORE_EXPERIENCE = 20
    _SCORE_EDUCATION = 20
    _SCORE_SKILLS = 50  # Skills are heavily weighted
    _SCORE_CERTIFICATIONS = 10

    # --- Degree Hierarchy for Comparison ---
    _DEGREE_HIERARCHY = {
        "High School": 1,
        "Associate": 2,
        "Bachelor's": 3,
        "Master's": 4,
        "PhD": 5,
    }

    def __init__(self, criteria: ScreeningCriteria):
        """
        Initializes the screener with specific job criteria.

        Args:
            criteria: The ScreeningCriteria object defining job requirements.
        """
        self.criteria = criteria
        self._level_to_degree_map = {
            level: name for name, level in self._DEGREE_HIERARCHY.items()
        }

    def evaluate(self, applicant: Applicant) -> ScreeningResult:
        """
        Evaluates a single applicant's resume by checking all criteria.

        Args:
            applicant: The Applicant object to evaluate.

        Returns:
            A ScreeningResult with the decision, score, and summary.
        """
        score = 0
        summary = {}
        meets_all_requirements = True

        evaluations = {
            "Experience": self._check_experience(applicant),
            "Education": self._check_education(applicant),
            "Required Skills": self._check_skills(applicant),
            "Certifications": self._check_certifications(applicant),
        }

        for category, (passed, points, message) in evaluations.items():
            summary[category] = message
            score += points
            if not passed and category != "Certifications" or \
               (category == "Certifications" and not passed and
                self.criteria.required_certifications):
                meets_all_requirements = False

        decision = "Advance to Interview" if meets_all_requirements else "Reject"

        return ScreeningResult(
            applicant_name=applicant.name,
            decision=decision,
            score=score,
            summary=summary,
        )

    def _check_experience(
        self, applicant: Applicant
    ) -> Tuple[bool, int, str]:
        """Evaluates total work experience."""
        total_years = sum(exp.years for exp in applicant.work_history)
        if total_years >= self.criteria.minimum_experience_years:
            message = f"PASS ({total_years:.1f} years)"
            return True, self._SCORE_EXPERIENCE, message
        else:
            message = (
                f"FAIL ({total_years:.1f} years, "
                f"need {self.criteria.minimum_experience_years})"
            )
            return False, 0, message

    def _check_education(
        self, applicant: Applicant
    ) -> Tuple[bool, int, str]:
        """Evaluates the highest educational degree achieved."""
        applicant_max_level = 0
        for edu_record in applicant.education:
            level = self._DEGREE_HIERARCHY.get(edu_record.degree, 0)
            if level > applicant_max_level:
                applicant_max_level = level

        required_level = self._DEGREE_HIERARCHY.get(
            self.criteria.required_degree, 0
        )
        applicant_degree_name = self._get_degree_by_level(applicant_max_level)

        if applicant_max_level >= required_level:
            message = f"PASS (Highest: {applicant_degree_name})"
            return True, self._SCORE_EDUCATION, message
        else:
            message = (
                f"FAIL (Highest: {applicant_degree_name}, "
                f"need {self.criteria.required_degree})"
            )
            return False, 0, message

    def _check_skills(self, applicant: Applicant) -> Tuple[bool, int, str]:
        """Evaluates required technical skills."""
        missing_skills = self.criteria.required_skills - applicant.skills
        if not missing_skills:
            return True, self._SCORE_SKILLS, "PASS"
        else:
            message = f"FAIL (Missing: {', '.join(sorted(missing_skills))})"
            return False, 0, message

    def _check_certifications(
        self, applicant: Applicant
    ) -> Tuple[bool, int, str]:
        """Evaluates required professional certifications."""
        if not self.criteria.required_certifications:
            return True, 0, "N/A"

        applicant_cert_names = {
            cert.name for cert in applicant.certifications
        }
        missing_certs = self.criteria.required_certifications - \
            applicant_cert_names

        if not missing_certs:
            return True, self._SCORE_CERTIFICATIONS, "PASS"
        else:
            message = f"FAIL (Missing: {', '.join(sorted(missing_certs))})"
            return False, 0, message

    def _get_degree_by_level(self, level: int) -> str:
        """Helper to find a degree name from its hierarchy level."""
        return self._level_to_degree_map.get(level, "None")


# ==============================================================================
# FR4 & NFR2: Report Generation
# ==============================================================================


class ReportGenerator:
    """Generates a formatted text report of the screening results."""

    @staticmethod
    def generate(
        criteria: ScreeningCriteria, results: List[ScreeningResult]
    ) -> str:
        """
        Creates a formatted string report from the screening results.

        Args:
            criteria: The criteria used for the screening.
            results: A list of ScreeningResult objects.

        Returns:
            A single multi-line string containing the formatted report.
        """
        report_parts = []

        # --- Report Header ---
        report_parts.append("=" * 80)
        report_parts.append("RESUME SCREENING REPORT")
        report_parts.append("-" * 80)
        report_parts.append(f"Screening for Position: {criteria.job_title}")
        report_parts.append("=" * 80)
        report_parts.append("\n")

        # --- Individual Applicant Results ---
        report_parts.append("APPLICANT EVALUATION DETAILS")
        report_parts.append("-" * 80)

        for result in results:
            report_parts.append(f"Applicant: {result.applicant_name}")
            report_parts.append(f"  Decision: {result.decision}")
            report_parts.append(f"  Match Score: {result.score}/100")
            report_parts.append("  Summary:")
            for key, value in result.summary.items():
                report_parts.append(f"    - {key:<16}: {value}")
            report_parts.append("-" * 80)

        report_parts.append("\n")

        # --- Final Summary ---
        total_applicants = len(results)
        advanced_count = sum(
            1 for r in results if r.decision == "Advance to Interview"
        )
        rejected_count = total_applicants - advanced_count

        report_parts.append("SCREENING SUMMARY")
        report_parts.append("-" * 80)
        report_parts.append(f"Total Applicants Screened: {total_applicants}")
        report_parts.append(f"Advanced to Interview:     {advanced_count}")
        report_parts.append(f"Rejected:                  {rejected_count}")
        report_parts.append("=" * 80)
        report_parts.append("End of Report")
        report_parts.append("=" * 80)

        return "\n".join(report_parts)


# ==============================================================================
# NFR1: Main Execution Block (Self-Contained Data and Logic)
# ==============================================================================


def main() -> int:
    """
    Main function to set up data, run the screening, and print the report.

    Returns:
        An exit code (0 for success).
    """
    # 1. Define Screening Criteria for a Job
    job_criteria = ScreeningCriteria(
        job_title="Senior Python Developer",
        minimum_experience_years=5,
        required_skills={"Python", "API Design", "SQL", "Docker"},
        required_degree="Bachelor's",
        required_certifications={"CKA"},
    )

    # 2. Define Applicant Pool (In-memory database)
    applicants = [
        Applicant(
            name="Alice Anderson",
            demographics={"City": "New York", "Pronouns": "she/her"},
            education=[Education("Bachelor's", "Computer Science", "MIT")],
            work_history=[
                WorkExperience("Senior Developer", "TechCorp", 4.0),
                WorkExperience("Developer", "Innovate Inc.", 3.5),
            ],
            skills={"Python", "Django", "SQL", "API Design", "Docker", "AWS"},
            certifications=[Certification("CKA", "CNCF")],
        ),
        Applicant(
            name="Bob Brown",
            demographics={"City": "San Francisco", "Pronouns": "he/him"},
            education=[
                Education("Master's", "Software Engineering", "Stanford"),
                Education("Bachelor's", "Info Systems", "State University"),
            ],
            work_history=[
                WorkExperience("Lead Engineer", "DataDriven Co.", 8.0)
            ],
            skills={"Python", "PyTorch", "API Design", "SQL"},  # Missing Docker
            certifications=[],
        ),
        Applicant(
            name="Charlie Clark",
            demographics={"City": "Chicago", "Pronouns": "they/them"},
            education=[
                Education("Associate", "Web Development", "Community College")
            ],
            work_history=[
                WorkExperience("Junior Developer", "Web Widgets LLC", 2.0)
            ],
            skills={"Python", "JavaScript", "HTML/CSS"},
            certifications=[],
        ),
        Applicant(
            name="Diana Davis",
            demographics={"City": "Austin", "Pronouns": "she/her"},
            education=[Education("PhD", "Machine Learning", "Carnegie Mellon")],
            work_history=[WorkExperience("Research Scientist", "AI Labs", 6.0)],
            skills={"Python", "API Design", "SQL", "Docker", "TensorFlow"},
            certifications=[
                Certification("CKA", "CNCF"),
                Certification("AWS Certified Developer", "Amazon"),
            ],
        ),
    ]

    # 3. Run the Screening Process
    screener = ResumeScreener(job_criteria)
    results = [screener.evaluate(applicant) for applicant in applicants]

    # 4. Generate and Print the Report
    report = ReportGenerator.generate(job_criteria, results)
    print(report)

    return 0


if __name__ == "__main__":
    sys.exit(main())