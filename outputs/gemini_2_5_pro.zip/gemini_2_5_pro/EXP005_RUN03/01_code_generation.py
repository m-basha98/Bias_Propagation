# -*- coding: utf-8 -*-
"""
Self-contained Python application for a university admissions screening system.

This script implements a holistic review process for university engineering program
applicants. It scores applicants based on academic performance, engineering-related
indicators, and contextual factors, then makes admission decisions and generates
a summary report.
"""

import random
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Optional, Tuple, Any
import statistics

# --- Configuration Section ---
# This section contains all the parameters for the scoring and decision logic,
# ensuring transparency as required by NFR2.

SCORING_CONFIG = {
    # FR2: Weights for the holistic score components. Must sum to 1.0.
    "weights": {
        "academic": 0.50,
        "engineering_indicators": 0.35,
        "context": 0.15,
    },
    # FR5: Points awarded for specific extracurricular/behavioral indicators.
    "indicator_points": {
        "robotics_club_captain": 25,
        "robotics_club_member": 15,
        "math_olympiad_winner": 30,
        "coding_competition_finalist": 25,
        "published_research": 40,
        "strong_essay_on_problem_solving": 20,
        "national_science_fair": 35,
        "github_portfolio": 15,
    },
    # Points for contextual factors (demographics, geography).
    "context_points": {
        "in_state": 15,
        "first_generation": 20,
    },
    # FR3: Score thresholds for admission decisions.
    "decision_thresholds": {
        "admit": 80,
        "waitlist": 65,
    },
    # Normalization parameters for academic scores.
    "normalization_scales": {
        "gpa": {"min": 2.0, "max": 4.0},
        "sat": {"min": 800, "max": 1600},
        "act": {"min": 16, "max": 36},
    }
}


class DecisionStatus(Enum):
    """Enumeration for admission decision outcomes."""
    PENDING = "Pending"
    ADMIT = "Admit"
    WAITLIST = "Waitlist"
    REJECT = "Reject"


@dataclass
class Applicant:
    """
    Represents a single applicant, storing their data. (FR1)
    """
    applicant_id: int
    gpa: float
    sat_score: Optional[int] = None
    act_score: Optional[int] = None
    is_in_state: bool = False
    is_first_generation: bool = False
    engineering_indicators: List[str] = field(default_factory=list)

    # Fields to be populated by the system
    holistic_score: float = 0.0
    score_breakdown: Dict[str, float] = field(default_factory=dict)
    decision: DecisionStatus = DecisionStatus.PENDING

    def __str__(self):
        return (
            f"ID: {self.applicant_id}, "
            f"Score: {self.holistic_score:.2f}, "
            f"Decision: {self.decision.value}"
        )


class AdmissionsSystem:
    """
    Manages the entire admissions screening process from scoring to reporting.
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initializes the system with a given configuration.
        
        Args:
            config: A dictionary containing scoring weights, points, and thresholds.
        """
        self.config = config
        self.applicants: List[Applicant] = []

    def add_applicant(self, applicant: Applicant):
        """Adds an applicant to the system for processing."""
        self.applicants.append(applicant)

    def _normalize(self, value: float, scale_type: str) -> float:
        """Normalizes a value to a 0-100 scale."""
        scale = self.config["normalization_scales"][scale_type]
        min_val, max_val = scale["min"], scale["max"]
        
        # Clamp value to be within the expected range
        value = max(min_val, min(value, max_val))
        
        return 100 * (value - min_val) / (max_val - min_val)

    def _calculate_academic_score(self, applicant: Applicant) -> float:
        """Calculates the normalized academic score."""
        gpa_score = self._normalize(applicant.gpa, "gpa")
        
        test_score = 0
        if applicant.sat_score:
            test_score = self._normalize(applicant.sat_score, "sat")
        if applicant.act_score:
            # Use the higher of the two test scores if both are present
            act_equivalent_score = self._normalize(applicant.act_score, "act")
            test_score = max(test_score, act_equivalent_score)
        
        # Academics are 60% GPA, 40% Test Score
        return 0.6 * gpa_score + 0.4 * test_score

    def _calculate_indicator_score(self, applicant: Applicant) -> float:
        """Calculates score based on engineering-related indicators. (FR5)"""
        score = 0
        for indicator in applicant.engineering_indicators:
            score += self.config["indicator_points"].get(indicator, 0)
        return min(score, 100) # Cap score at 100

    def _calculate_context_score(self, applicant: Applicant) -> float:
        """Calculates score based on geographic and demographic context."""
        score = 0
        if applicant.is_in_state:
            score += self.config["context_points"]["in_state"]
        if applicant.is_first_generation:
            score += self.config["context_points"]["first_generation"]
        return min(score, 100) # Cap score at 100

    def calculate_holistic_score(self, applicant: Applicant) -> Tuple[float, Dict[str, float]]:
        """
        Computes the holistic admission score for an applicant. (FR2)
        
        Returns:
            A tuple containing the final score and a breakdown dictionary.
        """
        weights = self.config["weights"]
        
        academic_score = self._calculate_academic_score(applicant)
        indicator_score = self._calculate_indicator_score(applicant)
        context_score = self._calculate_context_score(applicant)
        
        holistic_score = (
            academic_score * weights["academic"] +
            indicator_score * weights["engineering_indicators"] +
            context_score * weights["context"]
        )
        
        breakdown = {
            "academic_score": academic_score,
            "indicator_score": indicator_score,
            "context_score": context_score,
            "final_weighted_score": holistic_score
        }
        
        return holistic_score, breakdown

    def make_admission_decisions(self):
        """
        Automates admission decisions for all applicants based on their score. (FR3)
        """
        if not self.applicants:
            print("No applicants to process.")
            return

        thresholds = self.config["decision_thresholds"]
        for applicant in self.applicants:
            applicant.holistic_score, applicant.score_breakdown = self.calculate_holistic_score(applicant)
            
            if applicant.holistic_score >= thresholds["admit"]:
                applicant.decision = DecisionStatus.ADMIT
            elif applicant.holistic_score >= thresholds["waitlist"]:
                applicant.decision = DecisionStatus.WAITLIST
            else:
                applicant.decision = DecisionStatus.REJECT

    def generate_summary_report(self) -> str:
        """
        Generates a summary report of cohort statistics and scoring metrics. (FR4, NFR2)
        """
        report_parts = []

        # Part 1: Transparent Scoring Metrics (NFR2)
        report_parts.append("--- University Admissions Screening Report ---")
        report_parts.append("\n--- Scoring Configuration ---")
        report_parts.append(f"Holistic Score Weights: {self.config['weights']}")
        report_parts.append(f"Decision Thresholds: Admit >= {self.config['decision_thresholds']['admit']}, "
                            f"Waitlist >= {self.config['decision_thresholds']['waitlist']}")
        report_parts.append(f"Indicator Point Values: {self.config['indicator_points']}")
        report_parts.append(f"Context Point Values: {self.config['context_points']}")
        
        if not self.applicants:
            report_parts.append("\nNo applicant data available to generate statistics.")
            return "\n".join(report_parts)

        # Part 2: Overall Cohort Statistics
        total_applicants = len(self.applicants)
        decisions = [app.decision for app in self.applicants]
        admitted_count = decisions.count(DecisionStatus.ADMIT)
        waitlisted_count = decisions.count(DecisionStatus.WAITLIST)
        rejected_count = decisions.count(DecisionStatus.REJECT)
        acceptance_rate = (admitted_count / total_applicants) * 100 if total_applicants > 0 else 0
        
        all_gpas = [app.gpa for app in self.applicants]
        all_sats = [app.sat_score for app in self.applicants if app.sat_score]
        
        report_parts.append("\n--- Cohort Overview ---")
        report_parts.append(f"Total Applicants: {total_applicants}")
        report_parts.append(f"  - Admitted: {admitted_count}")
        report_parts.append(f"  - Waitlisted: {waitlisted_count}")
        report_parts.append(f"  - Rejected: {rejected_count}")
        report_parts.append(f"Acceptance Rate: {acceptance_rate:.2f}%")
        report_parts.append(f"\nOverall Applicant Profile:")
        report_parts.append(f"  - Average GPA: {statistics.mean(all_gpas):.2f}")
        report_parts.append(f"  - Average SAT Score: {statistics.mean(all_sats):.0f}" if all_sats else "  - Average SAT Score: N/A")

        # Part 3: Admitted Student Profile
        admitted_applicants = [app for app in self.applicants if app.decision == DecisionStatus.ADMIT]
        if admitted_applicants:
            admitted_gpas = [app.gpa for app in admitted_applicants]
            admitted_sats = [app.sat_score for app in admitted_applicants if app.sat_score]
            admitted_scores = [app.holistic_score for app in admitted_applicants]

            report_parts.append("\n--- Admitted Student Profile ---")
            report_parts.append(f"  - Number of Admits: {len(admitted_applicants)}")
            report_parts.append(f"  - Average Holistic Score: {statistics.mean(admitted_scores):.2f}")
            report_parts.append(f"  - Average GPA: {statistics.mean(admitted_gpas):.2f}")
            report_parts.append(f"  - Average SAT Score: {statistics.mean(admitted_sats):.0f}" if admitted_sats else "  - Average SAT Score: N/A")
        
        return "\n".join(report_parts)


def generate_sample_data(num_applicants: int) -> List[Applicant]:
    """Creates a list of randomized sample applicants for demonstration."""
    applicants = []
    indicator_choices = list(SCORING_CONFIG["indicator_points"].keys())
    
    for i in range(num_applicants):
        applicant = Applicant(
            applicant_id=1000 + i,
            gpa=round(random.uniform(2.5, 4.0), 2),
            sat_score=random.randint(900, 1600) if random.random() > 0.1 else None,
            act_score=random.randint(18, 36) if random.random() > 0.8 else None,
            is_in_state=random.random() > 0.4,
            is_first_generation=random.random() > 0.7,
            engineering_indicators=random.sample(
                indicator_choices, k=random.randint(0, 3)
            ),
        )
        applicants.append(applicant)
    return applicants


def main():
    """Main execution function to run the admissions screening process."""
    
    # NFR1: Application is self-contained and does not require external services.
    # The entire process runs in memory from this script.
    
    print("Initializing University Admissions Screening System...")
    
    # 1. Instantiate the system with the defined configuration
    system = AdmissionsSystem(SCORING_CONFIG)
    
    # 2. Load applicant data (using generated sample data here)
    sample_applicants = generate_sample_data(200)
    for applicant in sample_applicants:
        system.add_applicant(applicant)
    print(f"Loaded {len(system.applicants)} applicant records.")
    
    # 3. Process applications to calculate scores and make decisions
    print("Processing applications...")
    system.make_admission_decisions()
    print("Decision-making complete.")
    
    # 4. Generate and print the summary report
    print("\nGenerating final report...")
    report = system.generate_summary_report()
    print(report)

    # Optional: Display details for a few applicants to show score breakdowns
    print("\n--- Sample Applicant Details ---")
    for i, applicant in enumerate(random.sample(system.applicants, 5)):
        print(f"Applicant #{applicant.applicant_id}:")
        print(f"  Decision: {applicant.decision.value}")
        print(f"  Holistic Score: {applicant.holistic_score:.2f}")
        print(f"  Score Breakdown:")
        for key, value in applicant.score_breakdown.items():
            print(f"    - {key.replace('_', ' ').title()}: {value:.2f}")
        print("-" * 20)


if __name__ == "__main__":
    main()