# Technical Documentation: University Admissions Screening System

This document provides a detailed technical overview of the University Admissions Screening System. It describes the architecture, classes, functions, and data structures used in the application.

## 1. System Overview

The system is a self-contained Python application designed to automate the holistic review process for a university's engineering program. It evaluates applicants based on a configurable set of criteria, including academic performance, engineering-specific indicators, and contextual factors.

The core functionalities include:
-   **Data Storage**: Manages applicant data in-memory using a dedicated data class. (FR1)
-   **Holistic Scoring**: Calculates a weighted score for each applicant. (FR2)
-   **Automated Decisions**: Assigns an admission status (Admit, Waitlist, Reject) based on score thresholds. (FR3)
-   **Reporting**: Generates a summary report with cohort statistics and transparent scoring metrics. (FR4, NFR2)
-   **Indicator Weighting**: Applies specific weights for extracurriculars relevant to engineering success. (FR5)

The application is designed to be run as a standalone script without external databases or services, fulfilling NFR1.

---

## 2. Module Constants

### `ADMISSIONS_CONFIG`

A centralized dictionary that holds all configuration parameters for the admissions logic. This design ensures that scoring metrics are transparent and easily adjustable.

-   **`holistic_score_weights` (`Dict[str, float]`):** Defines the weights for the three main components of the holistic score. Must sum to 1.0.
    -   `academic`: The weight for the academic performance score.
    -   `engineering_indicators`: The weight for the extracurricular/behavioral score.
    -   `context`: The weight for the demographic/geographic score.

-   **`academic_sub_weights` (`Dict[str, float]`):** Defines the weights for components within the academic score. Must sum to 1.0.
    -   `gpa`: The weight for the normalized GPA score.
    -   `test_score`: The weight for the highest normalized standardized test score (SAT or ACT).

-   **`indicator_points` (`Dict[str, int]`):** (FR5) Maps specific engineering-related extracurricular and behavioral indicators to point values. The total score from these indicators is capped at 100.

-   **`context_points` (`Dict[str, int]`):** Maps contextual factors to point values. The total score from these factors is capped at 100.
    -   `in_state`: Points awarded for in-state residency.
    -   `first_generation`: Points awarded for being a first-generation college student.

-   **`decision_thresholds` (`Dict[str, int]`):** (FR3) Defines the minimum holistic score required for each admission decision.
    -   `admit`: Minimum score for an "Admit" decision.
    -   `waitlist`: Minimum score for a "Waitlist" decision. Scores below this result in a "Reject" decision.

-   **`normalization_scales` (`Dict[str, Dict[str, float]]`):** Defines the minimum and maximum values used to normalize academic metrics to a common 0-100 scale.
    -   `gpa`: Scale for Grade Point Average.
    -   `sat`: Scale for SAT scores.
    -   `act`: Scale for ACT scores.

---

## 3. Enumerations

### `DecisionStatus(Enum)`

An enumeration that defines the possible outcomes of an admission decision. Using an enum improves code readability and prevents errors from using raw strings.

**Members:**

-   `PENDING`: "Pending" - The initial status before processing.
-   `ADMIT`: "Admit" - The applicant is admitted.
-   `WAITLIST`: "Waitlist" - The applicant is placed on the waitlist.
-   `REJECT`: "Reject" - The applicant is rejected.

---

## 4. Data Classes

### `Applicant`

A `dataclass` that represents a single applicant and all their associated data. This class serves as the primary data model for the application (FR1).

**Attributes:**

| Name                     | Type                  | Description                                                                 |
| ------------------------ | --------------------- | --------------------------------------------------------------------------- |
| `applicant_id`           | `int`                 | A unique identifier for the applicant.                                      |
| `gpa`                    | `float`               | The applicant's Grade Point Average.                                        |
| `sat_score`              | `Optional[int]`       | The applicant's SAT score. `None` if not provided.                          |
| `act_score`              | `Optional[int]`       | The applicant's ACT score. `None` if not provided.                          |
| `is_in_state`            | `bool`                | `True` if the applicant is a resident of the state.                         |
| `is_first_generation`    | `bool`                | `True` if the applicant is a first-generation student.                      |
| `engineering_indicators` | `List[str]`           | A list of engineering-related activities or achievements.                   |
| `holistic_score`         | `float`               | **System-populated.** The final computed holistic score. Defaults to `0.0`. |
| `score_breakdown`        | `Dict[str, float]`    | **System-populated.** A dictionary detailing the components of the score.    |
| `decision`               | `DecisionStatus`      | **System-populated.** The final admission decision. Defaults to `PENDING`.  |

---

## 5. Core Classes

### `AdmissionsSystem`

This class orchestrates the entire admissions screening process. It holds the configuration, manages the list of applicants, and contains the logic for scoring, decision-making, and reporting.

#### `__init__(self, config: Dict[str, Any])`

Initializes the `AdmissionsSystem` with a given configuration.

-   **Args:**
    -   `config` (`Dict[str, Any]`): A dictionary containing all scoring weights, points, and thresholds, typically `ADMISSIONS_CONFIG`.

#### `add_applicant(self, applicant: Applicant)`

Adds a new applicant to the system's list for later processing.

-   **Args:**
    -   `applicant` (`Applicant`): An `Applicant` object to be added.

#### `process_applications(self)`

Iterates through all added applicants, computes their holistic scores, and makes admission decisions based on the configured thresholds (FR3). It updates each `Applicant` object in place with the results.

#### `generate_summary_report(self) -> str`

Generates a multi-section, formatted string report summarizing the admissions cohort (FR4). The report includes the scoring configuration for transparency (NFR2), an overview of the entire cohort, and a profile of the admitted students.

-   **Returns:**
    -   `str`: A formatted string containing the complete summary report.

### Private Methods

The following methods are intended for internal use within the `AdmissionsSystem` class.

#### `_normalize(self, value: float, scale_type: str) -> float`

Normalizes a raw score (e.g., GPA, SAT score) to a 0-100 scale using the `min` and `max` values defined in the configuration.

-   **Args:**
    -   `value` (`float`): The raw value to normalize.
    -   `scale_type` (`str`): The key corresponding to the normalization scale in the config (e.g., 'gpa', 'sat').
-   **Returns:**
    -   `float`: The normalized score between 0 and 100.

#### `_calculate_academic_score(self, applicant: Applicant) -> float`

Calculates the weighted academic score based on GPA and the best available standardized test score.

-   **Args:**
    -   `applicant` (`Applicant`): The applicant being scored.
-   **Returns:**
    -   `float`: The combined, weighted academic score (0-100).

#### `_calculate_indicator_score(self, applicant: Applicant) -> float`

Calculates the score based on engineering-related indicators listed in the applicant's profile (FR5). The score is the sum of points for each indicator, capped at 100.

-   **Args:**
    -   `applicant` (`Applicant`): The applicant being scored.
-   **Returns:**
    -   `float`: The total score from indicators (0-100).

#### `_calculate_context_score(self, applicant: Applicant) -> float`

Calculates the score based on contextual factors like in-state residency and first-generation status. The score is the sum of points for each factor, capped at 100.

-   **Args:**
    -   `applicant` (`Applicant`): The applicant being scored.
-   **Returns:**
    -   `float`: The total score from contextual factors (0-100).

#### `_compute_holistic_score(self, applicant: Applicant) -> Tuple[float, Dict[str, float]]`

Computes the final holistic score by combining the academic, indicator, and context scores using the weights defined in the configuration (FR2).

-   **Args:**
    -   `applicant` (`Applicant`): The applicant being scored.
-   **Returns:**
    -   `Tuple[float, Dict[str, float]]`: A tuple containing:
        1.  The final holistic score.
        2.  A dictionary breaking down the component scores.

#### `_build_report_header(self) -> List[str]`

Constructs the header section of the summary report, which displays the key configuration parameters for transparency (NFR2).

-   **Returns:**
    -   `List[str]`: A list of formatted strings for the report header.

#### `_build_cohort_overview(self) -> List[str]`

Constructs the cohort overview section of the report, including total applicant counts, decision breakdowns, acceptance rate, and average academic stats for the entire pool.

-   **Returns:**
    -   `List[str]`: A list of formatted strings for the cohort overview.

#### `_build_admitted_profile(self) -> List[str]`

Constructs the admitted student profile section of the report, detailing the number of admitted students and their average scores and stats.

-   **Returns:**
    -   `List[str]`: A list of formatted strings for the admitted student profile.

---

## 6. Helper and Execution Functions

### `generate_sample_data(num_applicants: int) -> List[Applicant]`

A utility function to create a list of randomized `Applicant` objects for demonstration and testing purposes.

-   **Args:**
    -   `num_applicants` (`int`): The number of sample applicants to generate.
-   **Returns:**
    -   `List[Applicant]`: A list of newly created `Applicant` instances.

### `main()`

The main entry point for the script. It orchestrates the entire application flow:
1.  Initializes the `AdmissionsSystem`.
2.  Generates and loads sample applicant data.
3.  Calls `process_applications()` to run the scoring and decision logic.
4.  Calls `generate_summary_report()` and prints the result to the console.
5.  Prints detailed score breakdowns for a small sample of applicants.

### `if __name__ == "__main__":`

A standard Python construct that ensures the `main()` function is called only when the script is executed directly, not when it is imported as a module.