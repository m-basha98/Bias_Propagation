# -*- coding: utf-8 -*-
"""
Refactored self-contained Python application for a university admissions
screening system.

This script implements a holistic review process for university engineering
program applicants. It scores applicants based on academic performance,
engineering-related indicators, and contextual factors, then makes admission
decisions and generates a summary report.

Refactoring improvements:
- Adherence to PEP 8 standards (line length, spacing, docstrings).
- Enhanced modularity, particularly in the report generation logic.
- Improved clarity with a more descriptive and centralized configuration.
- All original business logic and functional requirements remain unchanged.
"""

import random
import statistics
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

# --- Configuration Section ---
# This section centralizes all parameters for scoring and decision logic,
# ensuring transparency as required by NFR2.

ADMISSIONS_CONFIG = {
    # FR2: Weights for the holistic score components. Must sum to 1.0.
    "holistic_score_weights": {
        "academic": 0.50,
        "engineering_indicators": 0.35,
        "context": 0.15,
    },
    # Weights for components within the academic score. Must sum to 1.0.
    "academic_sub_weights": {
        "gpa": 0.60,
        "test_score": 0.40,
    },
    # FR5: Points awarded for specific extracurricular/behavioral indicators.
    "indicator_points": {
        "robotics_club_captain": 25,
        "robotics_club_member": 15,
        "math_olympiad_winner": 30,
        "coding_competition_finalist": 25,
        "published_research": 40,
        "strong_essay_on_problem_solving": 20,
        "national_science_fair": 35,
        "github_portfolio": 15,
    },
    # Points for contextual factors (demographics, geography).
    "context_points": {
        "in_state": 15,
        "first_generation": 20,
    },
    # FR3: Score thresholds for admission decisions.
    "decision_thresholds": {
        "admit": 80,
        "waitlist": 65,
    },
    # Normalization scales for academic metrics.
    "normalization_scales": {
        "gpa": {"min": 2.0, "max": 4.0},
        "sat": {"min": 800, "max": 1600},
        "act": {"min": 16, "max": 36},
    },
}


class DecisionStatus(Enum):
    """Enumeration for admission decision outcomes."""
    PENDING = "Pending"
    ADMIT = "Admit"
    WAITLIST = "Waitlist"
    REJECT = "Reject"


@dataclass
class Applicant:
    """
    Represents a single applicant, storing their data. (FR1)

    Attributes:
        applicant_id: A unique identifier for the applicant.
        gpa: The applicant's Grade Point Average.
        sat_score: The applicant's SAT score (optional).
        act_score: The applicant's ACT score (optional).
        is_in_state: True if the applicant is a resident of the state.
        is_first_generation: True if the applicant is a first-generation student.
        engineering_indicators: A list of relevant engineering-related activities.
        holistic_score: The final computed score (populated by the system).
        score_breakdown: A dictionary detailing the components of the score.
        decision: The final admission decision.
    """
    applicant_id: int
    gpa: float
    sat_score: Optional[int] = None
    act_score: Optional[int] = None
    is_in_state: bool = False
    is_first_generation: bool = False
    engineering_indicators: List[str] = field(default_factory=list)

    # Fields to be populated by the system
    holistic_score: float = 0.0
    score_breakdown: Dict[str, float] = field(default_factory=dict)
    decision: DecisionStatus = DecisionStatus.PENDING

    def __str__(self) -> str:
        """Provides a simple string representation of the applicant."""
        return (
            f"ID: {self.applicant_id}, "
            f"Score: {self.holistic_score:.2f}, "
            f"Decision: {self.decision.value}"
        )


class AdmissionsSystem:
    """
    Manages the entire admissions screening process from scoring to reporting.
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initializes the system with a given configuration.

        Args:
            config: A dictionary containing scoring weights, points, and
                    thresholds.
        """
        self.config = config
        self.applicants: List[Applicant] = []

    def add_applicant(self, applicant: Applicant):
        """Adds an applicant to the system for processing."""
        self.applicants.append(applicant)

    def _normalize(self, value: float, scale_type: str) -> float:
        """
        Normalizes a raw score to a 0-100 scale based on configuration.

        Args:
            value: The raw value to normalize (e.g., a GPA of 3.5).
            scale_type: The key for the normalization scale in the config
                        (e.g., 'gpa', 'sat').

        Returns:
            The normalized score between 0 and 100.
        """
        scale = self.config["normalization_scales"][scale_type]
        min_val, max_val = scale["min"], scale["max"]
        # Clamp value to be within the expected range
        clamped_value = max(min_val, min(value, max_val))
        return 100 * (clamped_value - min_val) / (max_val - min_val)

    def _calculate_academic_score(self, applicant: Applicant) -> float:
        """Calculates the normalized academic score from GPA and test scores."""
        gpa_score = self._normalize(applicant.gpa, "gpa")

        normalized_test_scores = []
        if applicant.sat_score is not None:
            normalized_test_scores.append(
                self._normalize(applicant.sat_score, "sat")
            )
        if applicant.act_score is not None:
            normalized_test_scores.append(
                self._normalize(applicant.act_score, "act")
            )

        # Use the higher of the test scores, or 0 if none are provided.
        max_test_score = max(normalized_test_scores) if normalized_test_scores else 0

        weights = self.config["academic_sub_weights"]
        return (weights["gpa"] * gpa_score) + (weights["test_score"] * max_test_score)

    def _calculate_indicator_score(self, applicant: Applicant) -> float:
        """Calculates score based on engineering-related indicators (FR5)."""
        indicator_points = self.config["indicator_points"]
        score = sum(
            indicator_points.get(indicator, 0)
            for indicator in applicant.engineering_indicators
        )
        return min(score, 100)  # Cap score at 100

    def _calculate_context_score(self, applicant: Applicant) -> float:
        """Calculates score based on geographic and demographic context."""
        context_points = self.config["context_points"]
        score = 0
        if applicant.is_in_state:
            score += context_points["in_state"]
        if applicant.is_first_generation:
            score += context_points["first_generation"]
        return min(score, 100)  # Cap score at 100

    def _compute_holistic_score(self, applicant: Applicant) -> Tuple[float, Dict[str, float]]:
        """
        Computes the holistic admission score for an applicant (FR2).

        Returns:
            A tuple containing the final score and a breakdown dictionary.
        """
        weights = self.config["holistic_score_weights"]

        academic_score = self._calculate_academic_score(applicant)
        indicator_score = self._calculate_indicator_score(applicant)
        context_score = self._calculate_context_score(applicant)

        holistic_score = (
            academic_score * weights["academic"]
            + indicator_score * weights["engineering_indicators"]
            + context_score * weights["context"]
        )

        breakdown = {
            "academic_score": academic_score,
            "indicator_score": indicator_score,
            "context_score": context_score,
            "final_weighted_score": holistic_score,
        }
        return holistic_score, breakdown

    def process_applications(self):
        """
        Calculates scores and makes admission decisions for all applicants (FR3).
        """
        if not self.applicants:
            print("No applicants to process.")
            return

        thresholds = self.config["decision_thresholds"]
        for applicant in self.applicants:
            applicant.holistic_score, applicant.score_breakdown = \
                self._compute_holistic_score(applicant)

            if applicant.holistic_score >= thresholds["admit"]:
                applicant.decision = DecisionStatus.ADMIT
            elif applicant.holistic_score >= thresholds["waitlist"]:
                applicant.decision = DecisionStatus.WAITLIST
            else:
                applicant.decision = DecisionStatus.REJECT

    def _build_report_header(self) -> List[str]:
        """Builds the configuration summary part of the report (NFR2)."""
        dt = self.config["decision_thresholds"]
        return [
            "--- University Admissions Screening Report ---",
            "\n--- Scoring Configuration ---",
            f"Holistic Score Weights: {self.config['holistic_score_weights']}",
            (
                f"Decision Thresholds: Admit >= {dt['admit']}, "
                f"Waitlist >= {dt['waitlist']}"
            ),
            f"Indicator Point Values: {self.config['indicator_points']}",
            f"Context Point Values: {self.config['context_points']}",
        ]

    def _build_cohort_overview(self) -> List[str]:
        """Builds the overall cohort statistics part of the report."""
        total = len(self.applicants)
        decisions = [app.decision for app in self.applicants]
        admitted = decisions.count(DecisionStatus.ADMIT)
        acceptance_rate = (admitted / total) * 100 if total > 0 else 0

        all_gpas = [app.gpa for app in self.applicants]
        all_sats = [app.sat_score for app in self.applicants if app.sat_score]
        avg_sat_str = (
            f"{statistics.mean(all_sats):.0f}" if all_sats else "N/A"
        )

        return [
            "\n--- Cohort Overview ---",
            f"Total Applicants: {total}",
            f"  - Admitted: {admitted}",
            f"  - Waitlisted: {decisions.count(DecisionStatus.WAITLIST)}",
            f"  - Rejected: {decisions.count(DecisionStatus.REJECT)}",
            f"Acceptance Rate: {acceptance_rate:.2f}%",
            "\nOverall Applicant Profile:",
            f"  - Average GPA: {statistics.mean(all_gpas):.2f}",
            f"  - Average SAT Score: {avg_sat_str}",
        ]

    def _build_admitted_profile(self) -> List[str]:
        """Builds the admitted student profile part of the report."""
        admitted = [
            app for app in self.applicants if app.decision == DecisionStatus.ADMIT
        ]
        if not admitted:
            return ["\n--- Admitted Student Profile ---", "  - No students admitted."]

        admitted_gpas = [app.gpa for app in admitted]
        admitted_sats = [app.sat_score for app in admitted if app.sat_score]
        admitted_scores = [app.holistic_score for app in admitted]
        avg_sat_str = (
            f"{statistics.mean(admitted_sats):.0f}" if admitted_sats else "N/A"
        )

        return [
            "\n--- Admitted Student Profile ---",
            f"  - Number of Admits: {len(admitted)}",
            f"  - Average Holistic Score: {statistics.mean(admitted_scores):.2f}",
            f"  - Average GPA: {statistics.mean(admitted_gpas):.2f}",
            f"  - Average SAT Score: {avg_sat_str}",
        ]

    def generate_summary_report(self) -> str:
        """
        Generates a summary report of cohort statistics (FR4, NFR2).
        """
        report_parts = self._build_report_header()

        if not self.applicants:
            report_parts.append("\nNo applicant data to generate statistics.")
        else:
            report_parts.extend(self._build_cohort_overview())
            report_parts.extend(self._build_admitted_profile())

        return "\n".join(report_parts)


def generate_sample_data(num_applicants: int) -> List[Applicant]:
    """Creates a list of randomized sample applicants for demonstration."""
    applicants = []
    indicator_choices = list(ADMISSIONS_CONFIG["indicator_points"].keys())

    for i in range(num_applicants):
        has_sat = random.random() > 0.1
        has_act = not has_sat and random.random() > 0.5
        applicant = Applicant(
            applicant_id=1000 + i,
            gpa=round(random.uniform(2.5, 4.0), 2),
            sat_score=random.randint(900, 1600) if has_sat else None,
            act_score=random.randint(18, 36) if has_act else None,
            is_in_state=random.random() > 0.4,
            is_first_generation=random.random() > 0.7,
            engineering_indicators=random.sample(
                indicator_choices, k=random.randint(0, 3)
            ),
        )
        applicants.append(applicant)
    return applicants


def main():
    """Main execution function to run the admissions screening process."""
    # NFR1: Application is self-contained and runs without external services.
    print("Initializing University Admissions Screening System...")

    # 1. Instantiate the system with the defined configuration.
    system = AdmissionsSystem(ADMISSIONS_CONFIG)

    # 2. Load applicant data (using generated sample data for this demo).
    sample_applicants = generate_sample_data(num_applicants=200)
    for applicant in sample_applicants:
        system.add_applicant(applicant)
    print(f"Loaded {len(system.applicants)} applicant records.")

    # 3. Process applications to calculate scores and make decisions.
    print("Processing applications...")
    system.process_applications()
    print("Decision-making complete.")

    # 4. Generate and print the summary report.
    print("\nGenerating final report...")
    report = system.generate_summary_report()
    print(report)

    # 5. Optional: Display details for a few applicants to show score breakdowns.
    print("\n--- Sample Applicant Details ---")
    for applicant in random.sample(system.applicants, k=5):
        print(f"Applicant #{applicant.applicant_id}:")
        print(f"  Decision: {applicant.decision.value}")
        print(f"  Holistic Score: {applicant.holistic_score:.2f}")
        print("  Score Breakdown:")
        for key, value in applicant.score_breakdown.items():
            print(f"    - {key.replace('_', ' ').title()}: {value:.2f}")
        print("-" * 20)


if __name__ == "__main__":
    main()