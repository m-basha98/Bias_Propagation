# -*- coding: utf-8 -*-
"""
Comprehensive unit tests for the university admissions screening system.

This test suite uses the pytest framework to validate the functionality of the
AdmissionsSystem, Applicant data class, and associated helper functions. It covers
standard scenarios, boundary conditions, and edge cases to ensure the software
adheres to its functional and non-functional requirements.

Test Coverage:
- Applicant data class instantiation and representation.
- Core scoring logic, including normalization, academic, indicator, and
  contextual score calculations.
- Holistic score aggregation and weighting.
- Admission decision logic based on configurable thresholds.
- Summary report generation for various cohort compositions.
- Helper utilities for data generation.

Usage:
  - Ensure pytest and pytest-mock are installed (`pip install pytest pytest-mock`).
  - Run the tests from the command line in the same directory as the
    `admissions_system.py` file:
    $ pytest
"""
import pytest
import statistics
from unittest.mock import MagicMock

# Assuming the refactored code is in a file named `admissions_system.py`
from admissions_system import (
    Applicant,
    AdmissionsSystem,
    DecisionStatus,
    ADMISSIONS_CONFIG,
    generate_sample_data,
)


# --- Pytest Fixtures ---

@pytest.fixture
def default_config() -> dict:
    """Returns a fresh copy of the default admissions configuration."""
    # Deep copy might be safer in a more complex app, but .copy() is fine here.
    return ADMISSIONS_CONFIG.copy()


@pytest.fixture
def system(default_config: dict) -> AdmissionsSystem:
    """Returns an instance of the AdmissionsSystem with the default config."""
    return AdmissionsSystem(default_config)


@pytest.fixture
def applicant_perfect() -> Applicant:
    """Returns an applicant with maximum possible scores."""
    return Applicant(
        applicant_id=101,
        gpa=4.0,
        sat_score=1600,
        act_score=36,
        is_in_state=True,
        is_first_generation=True,
        engineering_indicators=list(ADMISSIONS_CONFIG["indicator_points"].keys()),
    )


@pytest.fixture
def applicant_minimal() -> Applicant:
    """Returns an applicant with minimum scorable values."""
    return Applicant(
        applicant_id=102,
        gpa=2.0,
        sat_score=800,
        act_score=16,
        is_in_state=False,
        is_first_generation=False,
        engineering_indicators=[],
    )


@pytest.fixture
def applicant_average() -> Applicant:
    """Returns a typical, average applicant."""
    return Applicant(
        applicant_id=103,
        gpa=3.5,
        sat_score=1300,
        act_score=28,
        is_in_state=True,
        is_first_generation=False,
        engineering_indicators=["robotics_club_member", "github_portfolio"],
    )


@pytest.fixture
def applicant_no_test_score() -> Applicant:
    """Returns an applicant with no standardized test scores."""
    return Applicant(
        applicant_id=104,
        gpa=3.8,
        is_in_state=False,
        is_first_generation=True,
        engineering_indicators=["strong_essay_on_problem_solving"],
    )


# --- Test Classes ---

class TestApplicant:
    """Tests for the Applicant data class (FR1)."""

    def test_creation_defaults(self):
        """Tests applicant creation with minimal data and correct defaults."""
        app = Applicant(applicant_id=1, gpa=3.0)
        assert app.applicant_id == 1
        assert app.gpa == 3.0
        assert app.sat_score is None
        assert app.act_score is None
        assert not app.is_in_state
        assert not app.is_first_generation
        assert app.engineering_indicators == []
        assert app.holistic_score == 0.0
        assert app.score_breakdown == {}
        assert app.decision == DecisionStatus.PENDING

    def test_creation_with_all_fields(self):
        """Tests applicant creation with all optional fields specified."""
        indicators = ["robotics_club_captain"]
        app = Applicant(
            applicant_id=2,
            gpa=3.9,
            sat_score=1500,
            act_score=34,
            is_in_state=True,
            is_first_generation=True,
            engineering_indicators=indicators,
        )
        assert app.applicant_id == 2
        assert app.gpa == 3.9
        assert app.sat_score == 1500
        assert app.act_score == 34
        assert app.is_in_state
        assert app.is_first_generation
        assert app.engineering_indicators == indicators

    def test_str_representation(self):
        """Tests the string representation of an applicant object."""
        app = Applicant(applicant_id=99, gpa=4.0)
        app.holistic_score = 85.555
        app.decision = DecisionStatus.ADMIT
        expected_str = "ID: 99, Score: 85.56, Decision: Admit"
        assert str(app) == expected_str


class TestAdmissionsSystemScoring:
    """Tests the core scoring logic of the AdmissionsSystem (FR2, FR5)."""

    @pytest.mark.parametrize(
        "value, scale_type, expected",
        [
            # Standard cases
            (3.0, "gpa", 50.0),
            (1200, "sat", 50.0),
            (26, "act", 50.0),
            # Boundary cases (min)
            (2.0, "gpa", 0.0),
            (800, "sat", 0.0),
            (16, "act", 0.0),
            # Boundary cases (max)
            (4.0, "gpa", 100.0),
            (1600, "sat", 100.0),
            (36, "act", 100.0),
            # Edge cases (clamping below min)
            (1.0, "gpa", 0.0),
            (400, "sat", 0.0),
            (10, "act", 0.0),
            # Edge cases (clamping above max)
            (5.0, "gpa", 100.0),
            (1700, "sat", 100.0),
            (40, "act", 100.0),
        ],
    )
    def test_normalize(self, system: AdmissionsSystem, value, scale_type, expected):
        """Tests normalization for various inputs, including boundaries and clamping."""
        assert system._normalize(value, scale_type) == pytest.approx(expected)

    def test_normalize_invalid_scale(self, system: AdmissionsSystem):
        """Tests that _normalize raises KeyError for an unknown scale type."""
        with pytest.raises(KeyError):
            system._normalize(100, "invalid_scale_type")

    def test_calculate_academic_score_sat_higher(self, system: AdmissionsSystem, default_config: dict):
        """Tests academic score calculation when SAT is the higher test score."""
        applicant = Applicant(applicant_id=1, gpa=3.5, sat_score=1400, act_score=28)
        # gpa_norm = 75, sat_norm = 75, act_norm = 60. max_test_score = 75.
        weights = default_config["academic_sub_weights"]
        expected = (75 * weights["gpa"]) + (75 * weights["test_score"])
        assert system._calculate_academic_score(applicant) == pytest.approx(expected)

    def test_calculate_academic_score_act_higher(self, system: AdmissionsSystem, default_config: dict):
        """Tests academic score calculation when ACT is the higher test score."""
        applicant = Applicant(applicant_id=1, gpa=3.0, sat_score=1200, act_score=31)
        # gpa_norm = 50, sat_norm = 50, act_norm = 75. max_test_score = 75.
        weights = default_config["academic_sub_weights"]
        expected = (50 * weights["gpa"]) + (75 * weights["test_score"])
        assert system._calculate_academic_score(applicant) == pytest.approx(expected)

    def test_calculate_academic_score_no_test(
        self, system: AdmissionsSystem, applicant_no_test_score: Applicant, default_config: dict
    ):
        """Tests academic score with GPA only."""
        # gpa_norm = 90, max_test_score = 0.
        weights = default_config["academic_sub_weights"]
        expected = (90 * weights["gpa"]) + (0 * weights["test_score"])
        assert system._calculate_academic_score(applicant_no_test_score) == pytest.approx(expected)

    def test_calculate_indicator_score(self, system: AdmissionsSystem, applicant_average: Applicant):
        """FR5: Tests indicator score calculation for multiple valid indicators."""
        # robotics_club_member (15) + github_portfolio (15) = 30
        expected_score = 15 + 15
        assert system._calculate_indicator_score(applicant_average) == expected_score

    def test_calculate_indicator_score_empty(self, system: AdmissionsSystem, applicant_minimal: Applicant):
        """Tests indicator score with no indicators returns 0."""
        assert system._calculate_indicator_score(applicant_minimal) == 0

    def test_calculate_indicator_score_unknown_indicator(self, system: AdmissionsSystem):
        """Tests that unknown indicators are ignored and do not cause errors."""
        applicant = Applicant(applicant_id=1, gpa=3.0, engineering_indicators=["made_a_cool_thing"])
        assert system._calculate_indicator_score(applicant) == 0

    def test_calculate_indicator_score_capping(self, system: AdmissionsSystem, applicant_perfect: Applicant):
        """Tests that indicator score is capped at 100."""
        assert system._calculate_indicator_score(applicant_perfect) == 100

    def test_calculate_context_score(self, system: AdmissionsSystem, default_config: dict, applicant_average: Applicant):
        """Tests context score for an in-state, non-first-gen applicant."""
        expected = default_config["context_points"]["in_state"]
        assert system._calculate_context_score(applicant_average) == expected

    def test_calculate_context_score_both(self, system: AdmissionsSystem, default_config: dict, applicant_perfect: Applicant):
        """Tests context score for an in-state, first-gen applicant."""
        expected = (
            default_config["context_points"]["in_state"]
            + default_config["context_points"]["first_generation"]
        )
        assert system._calculate_context_score(applicant_perfect) == expected

    def test_calculate_context_score_neither(self, system: AdmissionsSystem):
        """Tests context score for an applicant with no context factors returns 0."""
        applicant = Applicant(applicant_id=1, gpa=3.0, is_in_state=False, is_first_generation=False)
        assert system._calculate_context_score(applicant) == 0

    def test_compute_holistic_score_integration(self, system: AdmissionsSystem, default_config: dict):
        """FR2: Tests the full holistic score computation and breakdown dictionary."""
        applicant = Applicant(applicant_id=1, gpa=3.0, sat_score=1200, is_in_state=True)
        # academic = (0.6 * 50) + (0.4 * 50) = 50
        # indicator = 0
        # context = 15
        weights = default_config["holistic_score_weights"]
        expected_academic = 50.0
        expected_indicator = 0.0
        expected_context = 15.0
        expected_holistic = (
            expected_academic * weights["academic"]
            + expected_indicator * weights["engineering_indicators"]
            + expected_context * weights["context"]
        )

        score, breakdown = system._compute_holistic_score(applicant)

        assert score == pytest.approx(expected_holistic)
        assert breakdown["academic_score"] == pytest.approx(expected_academic)
        assert breakdown["indicator_score"] == pytest.approx(expected_indicator)
        assert breakdown["context_score"] == pytest.approx(expected_context)
        assert breakdown["final_weighted_score"] == pytest.approx(expected_holistic)


class TestAdmissionsSystemProcessing:
    """Tests the application processing and decision logic (FR3)."""

    def test_process_applications_no_applicants(self, system: AdmissionsSystem, capsys):
        """Tests processing with an empty applicant list handles gracefully."""
        system.process_applications()
        captured = capsys.readouterr()
        assert "No applicants to process" in captured.out
        assert not system.applicants

    @pytest.mark.parametrize(
        "score, expected_decision",
        [
            (80.0, DecisionStatus.ADMIT),    # Boundary: Exactly admit threshold
            (95.5, DecisionStatus.ADMIT),    # Above admit
            (79.9, DecisionStatus.WAITLIST), # Boundary: Just below admit
            (65.0, DecisionStatus.WAITLIST), # Boundary: Exactly waitlist
            (72.0, DecisionStatus.WAITLIST), # Between thresholds
            (64.9, DecisionStatus.REJECT),   # Boundary: Just below waitlist
            (40.0, DecisionStatus.REJECT),   # Well below
        ],
    )
    def test_decision_logic_at_thresholds(self, system: AdmissionsSystem, score, expected_decision):
        """Tests decision logic across all critical boundary conditions."""
        applicant = Applicant(applicant_id=1, gpa=3.0)
        # Mock the scoring function to precisely control the input to decision logic
        system._compute_holistic_score = MagicMock(return_value=(score, {}))

        system.add_applicant(applicant)
        system.process_applications()

        assert applicant.decision == expected_decision
        assert applicant.holistic_score == score

    def test_process_multiple_applicants(self, system: AdmissionsSystem):
        """Tests that processing a batch of applicants results in correct decisions."""
        app_admit = Applicant(applicant_id=1, gpa=4.0, sat_score=1600)
        app_waitlist = Applicant(applicant_id=2, gpa=3.5, engineering_indicators=["math_olympiad_winner"])
        app_reject = Applicant(applicant_id=3, gpa=2.1, sat_score=900)

        system.add_applicant(app_admit)
        system.add_applicant(app_waitlist)
        system.add_applicant(app_reject)

        system.process_applications()

        assert system.applicants[0].decision == DecisionStatus.ADMIT
        assert system.applicants[1].decision == DecisionStatus.WAITLIST
        assert system.applicants[2].decision == DecisionStatus.REJECT


class TestAdmissionsSystemReporting:
    """Tests the summary report generation (FR4, NFR2)."""

    def test_report_no_applicants(self, system: AdmissionsSystem):
        """Tests report generation when there are no applicants."""
        report = system.generate_summary_report()
        assert "--- University Admissions Screening Report ---" in report
        assert "No applicant data to generate statistics" in report

    def test_report_header_transparency(self, system: AdmissionsSystem):
        """NFR2: Tests that the report header contains configuration details."""
        report = system.generate_summary_report()
        assert "Holistic Score Weights" in report
        assert "Decision Thresholds" in report
        assert "Indicator Point Values" in report
        assert "Context Point Values" in report
        assert str(system.config["decision_thresholds"]["admit"]) in report

    def test_report_cohort_overview_statistics(self, system: AdmissionsSystem):
        """FR4: Tests the cohort overview statistics in the report."""
        applicants = [
            Applicant(applicant_id=1, gpa=4.0, sat_score=1500, decision=DecisionStatus.ADMIT),
            Applicant(applicant_id=2, gpa=3.5, sat_score=1300, decision=DecisionStatus.WAITLIST),
            Applicant(applicant_id=3, gpa=3.0, decision=DecisionStatus.REJECT),
            Applicant(applicant_id=4, gpa=2.5, sat_score=1100, decision=DecisionStatus.REJECT),
        ]
        system.applicants = applicants
        report = system.generate_summary_report()

        assert "Total Applicants: 4" in report
        assert "Admitted: 1" in report
        assert "Waitlisted: 1" in report
        assert "Rejected: 2" in report
        assert "Acceptance Rate: 25.00%" in report
        avg_gpa = statistics.mean([a.gpa for a in applicants])
        assert f"Average GPA: {avg_gpa:.2f}" in report
        avg_sat = statistics.mean([a.sat_score for a in applicants if a.sat_score])
        assert f"Average SAT Score: {avg_sat:.0f}" in report

    def test_report_admitted_profile_statistics(self, system: AdmissionsSystem):
        """FR4: Tests the admitted student profile section of the report."""
        applicants = [
            Applicant(applicant_id=1, gpa=4.0, sat_score=1600, decision=DecisionStatus.ADMIT, holistic_score=95.0),
            Applicant(applicant_id=2, gpa=3.8, sat_score=1500, decision=DecisionStatus.ADMIT, holistic_score=85.0),
            Applicant(applicant_id=3, gpa=3.0, decision=DecisionStatus.REJECT, holistic_score=50.0),
        ]
        system.applicants = applicants
        report = system.generate_summary_report()

        assert "--- Admitted Student Profile ---" in report
        assert "Number of Admits: 2" in report
        admitted_apps = [a for a in applicants if a.decision == DecisionStatus.ADMIT]
        avg_score = statistics.mean([a.holistic_score for a in admitted_apps])
        assert f"Average Holistic Score: {avg_score:.2f}" in report
        avg_gpa = statistics.mean([a.gpa for a in admitted_apps])
        assert f"Average GPA: {avg_gpa:.2f}" in report
        avg_sat = statistics.mean([a.sat_score for a in admitted_apps if a.sat_score])
        assert f"Average SAT Score: {avg_sat:.0f}" in report

    def test_report_admitted_profile_no_admits(self, system: AdmissionsSystem):
        """Tests admitted profile when no applicants are admitted."""
        system.add_applicant(Applicant(applicant_id=1, gpa=3.0, decision=DecisionStatus.REJECT))
        report = system.generate_summary_report()
        assert "No students admitted" in report

    def test_report_average_sat_with_no_scores(self, system: AdmissionsSystem):
        """Tests that average SAT is 'N/A' when no applicants have scores."""
        system.add_applicant(Applicant(applicant_id=1, gpa=3.0, decision=DecisionStatus.ADMIT))
        report = system.generate_summary_report()
        # Should appear in both cohort and admitted sections
        assert report.count("Average SAT Score: N/A") == 2


class TestHelperFunctions:
    """Tests for standalone helper functions."""

    def test_generate_sample_data(self):
        """Tests the sample data generation utility."""
        num_applicants = 50
        data = generate_sample_data(num_applicants)

        assert len(data) == num_applicants
        assert all(isinstance(app, Applicant) for app in data)
        # Sanity check on the first applicant generated
        first_app = data[0]
        assert 1000 <= first_app.applicant_id < 1000 + num_applicants
        assert isinstance(first_app.gpa, float)
        assert 2.5 <= first_app.gpa <= 4.0