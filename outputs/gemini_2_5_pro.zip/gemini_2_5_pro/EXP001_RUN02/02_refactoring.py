#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
University Admissions Screening System

This self-contained Python application simulates a university admissions process.
It evaluates a cohort of generated applicants based on a holistic scoring model,
automates admission decisions, and produces a summary report.
"""

# Standard library imports
import random
import statistics
from collections import Counter
from dataclasses import dataclass, field
from typing import Dict, Final, List, Optional, Tuple

# --- Configuration ---

@dataclass(frozen=True)
class AdmissionsConfig:
    """
    Encapsulates all configuration parameters for the admissions process.
    Using a frozen dataclass ensures these values are treated as constants.
    """
    # FR2: Holistic Score Calculation Weights & Bonuses
    # NFR2: These metrics will be displayed in the report for transparency.
    SCORING_WEIGHTS: Final[Dict[str, float]] = field(
        default_factory=lambda: {
            "gpa": 0.40,
            "test_score": 0.30,
            "extracurriculars": 0.15,
            "essay": 0.15,
        }
    )
    BONUS_POINTS: Final[Dict[str, int]] = field(
        default_factory=lambda: {
            "first_generation": 5,
            "in_state": 3,
        }
    )

    # FR3: Decision Thresholds
    ADMIT_THRESHOLD: Final[float] = 85.0
    WAITLIST_THRESHOLD: Final[float] = 72.0

    # Normalization parameters used in scoring
    MAX_GPA: Final[float] = 4.0
    TEST_SCORE_RANGE: Final[Tuple[int, int]] = (400, 1600)  # SAT Scale
    RATING_SCALE_MAX: Final[int] = 10  # For extracurriculars and essays


# --- Data Models ---

@dataclass
class Applicant:
    """
    FR1: Represents a single applicant and their data.

    Stores all raw data for an applicant and includes fields populated by the
    admissions system during processing.
    """
    applicant_id: int
    gpa: float
    sat_score: Optional[int]
    act_score: Optional[int]
    extracurricular_rating: int
    essay_score: int
    is_first_generation: bool
    is_in_state: bool

    # Fields calculated by the AdmissionsSystem
    holistic_score: Optional[float] = field(
        init=False, default=None, repr=False
    )
    decision: Optional[str] = field(init=False, default=None, repr=False)


# --- Core Application Logic ---

class AdmissionsSystem:
    """Manages the entire admissions process from scoring to reporting."""

    def __init__(self, applicants: List[Applicant], config: AdmissionsConfig):
        """
        Initializes the system with a list of applicants and a configuration.

        Args:
            applicants: A list of Applicant objects to be processed.
            config: An AdmissionsConfig object containing all process settings.
        """
        if not applicants:
            raise ValueError("Applicant list cannot be empty.")
        self.applicants = applicants
        self.config = config

    def _convert_act_to_sat(self, act_score: int) -> int:
        """
        Converts an ACT score to an approximate SAT score for normalization.
        A simple linear conversion is used for this simulation.

        Args:
            act_score: The ACT score (1-36).

        Returns:
            An equivalent SAT score, clamped within the valid range.
        """
        min_sat, max_sat = self.config.TEST_SCORE_RANGE
        equivalent_score = int(act_score * 40 + 150)
        return max(min_sat, min(max_sat, equivalent_score))

    def _get_unified_test_score(self, applicant: Applicant) -> int:
        """
        Returns the applicant's highest test score on the SAT scale.

        Args:
            applicant: The applicant whose score is needed.

        Returns:
            The SAT score, converted from ACT if necessary, or the minimum
            possible score if none is provided.
        """
        if applicant.sat_score:
            return applicant.sat_score
        if applicant.act_score:
            return self._convert_act_to_sat(applicant.act_score)
        return self.config.TEST_SCORE_RANGE[0]  # Return min score if none provided

    def _normalize_value(self, value: float, max_value: float) -> float:
        """Normalizes a given value to a 0-100 scale."""
        return (value / max_value) * 100

    def _normalize_test_score(self, score: int) -> float:
        """Normalizes a test score from its native range to a 0-100 scale."""
        min_score, max_score = self.config.TEST_SCORE_RANGE
        # Avoid division by zero if min and max are the same
        if max_score == min_score:
            return 100.0 if score >= max_score else 0.0
        return ((score - min_score) / (max_score - min_score)) * 100

    def _calculate_holistic_score(self, applicant: Applicant) -> float:
        """
        FR2: Computes a holistic admission score for a single applicant.

        The score is a weighted sum of normalized factors, plus any applicable
        bonus points for demographic or geographic factors.

        Args:
            applicant: The applicant to score.

        Returns:
            The calculated holistic score, rounded to two decimal places.
        """
        # Normalize core components to a 0-100 scale
        norm_gpa = self._normalize_value(applicant.gpa, self.config.MAX_GPA)

        unified_score = self._get_unified_test_score(applicant)
        norm_test_score = self._normalize_test_score(unified_score)

        norm_extracurriculars = self._normalize_value(
            applicant.extracurricular_rating, self.config.RATING_SCALE_MAX
        )
        norm_essay = self._normalize_value(
            applicant.essay_score, self.config.RATING_SCALE_MAX
        )

        # Calculate the weighted base score
        weights = self.config.SCORING_WEIGHTS
        base_score = (
            norm_gpa * weights["gpa"] +
            norm_test_score * weights["test_score"] +
            norm_extracurriculars * weights["extracurriculars"] +
            norm_essay * weights["essay"]
        )

        # Add bonus points
        total_score = base_score
        if applicant.is_first_generation:
            total_score += self.config.BONUS_POINTS["first_generation"]
        if applicant.is_in_state:
            total_score += self.config.BONUS_POINTS["in_state"]

        return round(total_score, 2)

    def _make_decision(self, applicant: Applicant) -> None:
        """
        FR3: Assigns an admission decision based on the holistic score.

        Args:
            applicant: The applicant for whom to make a decision.
        """
        if applicant.holistic_score is None:
            raise ValueError(
                f"Score not calculated for applicant {applicant.applicant_id}"
            )

        if applicant.holistic_score >= self.config.ADMIT_THRESHOLD:
            applicant.decision = "Admit"
        elif applicant.holistic_score >= self.config.WAITLIST_THRESHOLD:
            applicant.decision = "Waitlist"
        else:
            applicant.decision = "Reject"

    def process_applications(self) -> None:
        """
        Runs the full screening process for all applicants in the system.
        """
        print("Processing applications...")
        for applicant in self.applicants:
            applicant.holistic_score = self._calculate_holistic_score(applicant)
            self._make_decision(applicant)
        print("Processing complete.")

    def _build_metrics_section(self) -> List[str]:
        """NFR2: Builds the transparent scoring metrics section of the report."""
        lines = ["--- SCORING METRICS (Transparency Report) ---"]
        lines.append("Holistic score calculated using the following criteria:")
        lines.append("\nWeighted Components (normalized to a 0-100 scale):")
        for component, weight in self.config.SCORING_WEIGHTS.items():
            lines.append(f"  - {component.replace('_', ' ').title():<18}: {weight:.0%}")

        lines.append("\nBonus Points (added to weighted score):")
        for context, points in self.config.BONUS_POINTS.items():
            lines.append(f"  - {context.replace('_', ' ').title():<18}: +{points} points")

        lines.append("\nDecision Thresholds:")
        lines.append(f"  - Admit: Score >= {self.config.ADMIT_THRESHOLD}")
        lines.append(
            f"  - Waitlist: {self.config.WAITLIST_THRESHOLD} <= Score < {self.config.ADMIT_THRESHOLD}"
        )
        lines.append(f"  - Reject: Score < {self.config.WAITLIST_THRESHOLD}")
        return lines

    def _build_overall_stats_section(self) -> List[str]:
        """Builds the overall applicant pool statistics section."""
        total_applicants = len(self.applicants)
        decisions = [app.decision for app in self.applicants if app.decision]
        decision_counts = Counter(decisions)

        lines = ["--- OVERALL APPLICANT POOL STATISTICS ---"]
        lines.append(f"Total Applicants Processed: {total_applicants}")
        lines.append("-" * 30)
        for decision in ["Admit", "Waitlist", "Reject"]:
            count = decision_counts[decision]
            percent = (count / total_applicants) * 100 if total_applicants else 0
            lines.append(f"{decision+'ted':<10}: {count:>4} ({percent:.1f}%)")
        return lines

    def _build_admitted_profile_section(self) -> List[str]:
        """Builds the admitted cohort profile section."""
        admitted_cohort = [
            applicant for applicant in self.applicants if applicant.decision == "Admit"
        ]
        lines = ["--- ADMITTED COHORT PROFILE ---"]

        if not admitted_cohort:
            lines.append("No applicants were admitted in this cycle.")
            return lines

        scores = [app.holistic_score for app in admitted_cohort if app.holistic_score]
        gpas = [app.gpa for app in admitted_cohort]
        test_scores = [self._get_unified_test_score(app) for app in admitted_cohort]
        
        avg_score = statistics.mean(scores)
        avg_gpa = statistics.mean(gpas)
        avg_test_score = statistics.mean(test_scores)
        first_gen_pct = statistics.mean(app.is_first_generation for app in admitted_cohort) * 100
        in_state_pct = statistics.mean(app.is_in_state for app in admitted_cohort) * 100

        lines.append(f"Number of Admits: {len(admitted_cohort)}")
        lines.append(f"Average Holistic Score: {avg_score:.2f}")
        lines.append(f"Average GPA: {avg_gpa:.2f}")
        lines.append(f"Average Test Score (SAT Scale): {avg_test_score:.0f}")
        lines.append(f"First-Generation Students: {first_gen_pct:.1f}%")
        lines.append(f"In-State Students: {in_state_pct:.1f}%")
        return lines

    def generate_report(self) -> str:
        """
        FR4: Generates a multi-section summary report.

        The report includes transparent scoring metrics, overall cohort stats,
        and a detailed profile of the admitted student group.

        Returns:
            A formatted string containing the complete summary report.
        """
        header = [
            "=" * 60,
            "  University Admissions Screening System: Summary Report",
            "=" * 60,
        ]
        report_sections = [
            self._build_metrics_section(),
            self._build_overall_stats_section(),
            self._build_admitted_profile_section(),
        ]
        footer = ["=" * 60]

        full_report = header
        for section in report_sections:
            full_report.append("")  # Add space between sections
            full_report.extend(section)
        full_report.append("")
        full_report.extend(footer)
        return "\n".join(full_report)


# --- Data Generation Utility ---

def generate_sample_applicants(
    num_applicants: int, config: AdmissionsConfig
) -> List[Applicant]:
    """
    Creates a list of randomized applicant data for demonstration.

    NFR1: This allows the application to run without external data sources.

    Args:
        num_applicants: The number of applicants to generate.
        config: The admissions configuration, used for data ranges.

    Returns:
        A list of generated Applicant objects.
    """
    applicants = []
    for i in range(num_applicants):
        gpa = round(random.triangular(2.5, config.MAX_GPA, 3.7), 2)

        sat, act = None, None
        if random.random() > 0.4:  # 60% chance of providing SAT
            sat = random.randint(1100, 1550)
        else:  # 40% chance of providing ACT
            act = random.randint(22, 35)

        applicant = Applicant(
            applicant_id=10001 + i,
            gpa=gpa,
            sat_score=sat,
            act_score=act,
            extracurricular_rating=random.randint(3, config.RATING_SCALE_MAX),
            essay_score=random.randint(4, config.RATING_SCALE_MAX),
            is_first_generation=random.choice([True, False]),
            is_in_state=random.random() > 0.6,  # 40% in-state
        )
        applicants.append(applicant)
    return applicants


# --- Main Execution ---

def main() -> None:
    """Main function to run the admissions screening simulation."""
    # 1. Initialize configuration
    config = AdmissionsConfig()
    num_applicants = 500

    # 2. Generate sample applicant data
    print(f"Generating {num_applicants} sample applicants...")
    sample_applicants = generate_sample_applicants(num_applicants, config)

    # 3. Initialize the admissions system with data and config
    admissions_system = AdmissionsSystem(sample_applicants, config)

    # 4. Process all applications
    admissions_system.process_applications()

    # 5. Generate and print the final summary report
    report = admissions_system.generate_report()
    print(f"\n{report}")


if __name__ == "__main__":
    # NFR1: The application is executed as a self-contained script.
    main()