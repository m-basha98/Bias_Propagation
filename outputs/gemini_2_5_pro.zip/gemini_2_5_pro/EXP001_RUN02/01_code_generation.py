#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
University Admissions Screening System

This self-contained Python application simulates a university admissions process.
It evaluates a cohort of generated applicants based on a holistic scoring model,
automates admission decisions, and produces a summary report.
"""

# Standard library imports
import random
import statistics
from dataclasses import dataclass, field
from typing import List, Optional

# --- Configuration Constants ---

# FR2: Holistic Score Calculation Weights & Bonuses
# NFR2: These metrics will be displayed in the report for transparency.
SCORING_WEIGHTS = {
    "gpa": 0.40,  # 40%
    "test_score": 0.30,  # 30%
    "extracurriculars": 0.15,  # 15%
    "essay": 0.15,  # 15%
}

BONUS_POINTS = {
    "first_generation": 5,
    "in_state": 3,
}

# FR3: Decision Thresholds
ADMIT_THRESHOLD = 85.0
WAITLIST_THRESHOLD = 72.0

# Normalization parameters used in scoring
MAX_GPA = 4.0
MIN_TEST_SCORE_NORMALIZED = 400  # Based on SAT scale (lowest possible score)
MAX_TEST_SCORE_NORMALIZED = 1600 # Based on SAT scale (highest possible score)
MAX_RATING = 10  # For extracurriculars and essays


# --- Data Structures ---

@dataclass
class Applicant:
    """
    FR1: Represents a single applicant and their data.

    This data class stores all raw data for an applicant and includes fields
    that will be populated by the admissions system during processing.
    """
    applicant_id: int
    gpa: float
    # An applicant will typically have either an SAT or ACT score
    sat_score: Optional[int] = None
    act_score: Optional[int] = None
    extracurriculars: int # Rated on a scale of 1-10
    essay_score: int      # Rated on a scale of 1-10
    is_first_generation: bool
    is_in_state: bool

    # These fields are calculated and assigned by the AdmissionsSystem
    holistic_score: Optional[float] = field(init=False, default=None)
    decision: Optional[str] = field(init=False, default=None)


# --- Main Application Logic ---

class AdmissionsSystem:
    """
    Manages the entire admissions screening process, from scoring to reporting.
    """
    def __init__(self, applicants: List[Applicant]):
        """
        Initializes the system with a list of applicants.
        """
        if not applicants:
            raise ValueError("Applicant list cannot be empty.")
        self.applicants = applicants

    def _convert_act_to_sat(self, act_score: int) -> int:
        """
        Converts an ACT score to an approximate SAT score for normalization.
        A simple linear conversion is used for this simulation.
        """
        # Formula based on common concordance tables, simplified and capped.
        equivalent_score = int(act_score * 40 + 150)
        return max(MIN_TEST_SCORE_NORMALIZED, min(MAX_TEST_SCORE_NORMALIZED, equivalent_score))

    def _get_unified_test_score(self, applicant: Applicant) -> int:
        """
        Returns the applicant's test score on the SAT scale for unified comparison.
        """
        if applicant.sat_score:
            return applicant.sat_score
        if applicant.act_score:
            return self._convert_act_to_sat(applicant.act_score)
        # Assume minimum score if no test score is provided
        return MIN_TEST_SCORE_NORMALIZED

    def _calculate_holistic_score(self, applicant: Applicant) -> float:
        """
        FR2: Computes a holistic admission score for a single applicant.

        The score is a weighted sum of normalized academic and non-academic factors,
        plus any applicable bonus points for demographic or geographic factors.
        """
        # Normalize core components to a 0-100 scale
        normalized_gpa = (applicant.gpa / MAX_GPA) * 100

        unified_test_score = self._get_unified_test_score(applicant)
        normalized_test = (
            (unified_test_score - MIN_TEST_SCORE_NORMALIZED) /
            (MAX_TEST_SCORE_NORMALIZED - MIN_TEST_SCORE_NORMALIZED)
        ) * 100

        normalized_extracurriculars = (applicant.extracurriculars / MAX_RATING) * 100
        normalized_essay = (applicant.essay_score / MAX_RATING) * 100

        # Calculate the weighted base score
        base_score = (
            normalized_gpa * SCORING_WEIGHTS["gpa"] +
            normalized_test * SCORING_WEIGHTS["test_score"] +
            normalized_extracurriculars * SCORING_WEIGHTS["extracurriculars"] +
            normalized_essay * SCORING_WEIGHTS["essay"]
        )

        # Add bonus points to the base score
        total_score = base_score
        if applicant.is_first_generation:
            total_score += BONUS_POINTS["first_generation"]
        if applicant.is_in_state:
            total_score += BONUS_POINTS["in_state"]

        return round(total_score, 2)

    def _make_decision(self, applicant: Applicant):
        """
        FR3: Automates the admission decision based on the holistic score.
        """
        if applicant.holistic_score is None:
            raise ValueError(f"Holistic score not calculated for applicant {applicant.applicant_id}")

        if applicant.holistic_score >= ADMIT_THRESHOLD:
            applicant.decision = "Admit"
        elif applicant.holistic_score >= WAITLIST_THRESHOLD:
            applicant.decision = "Waitlist"
        else:
            applicant.decision = "Reject"

    def process_applications(self):
        """
        Runs the entire screening process for all applicants in the system.
        """
        print("Processing applications...")
        for applicant in self.applicants:
            applicant.holistic_score = self._calculate_holistic_score(applicant)
            self._make_decision(applicant)
        print("Processing complete.")

    def generate_report(self) -> str:
        """
        FR4: Generates a multi-section summary report.

        The report includes transparent scoring metrics, overall cohort statistics,
        and a detailed profile of the admitted student group.
        """
        report_lines = []

        # Section 1: Scoring Metrics (NFR2)
        report_lines.append("=" * 60)
        report_lines.append("  University Admissions Screening System: Summary Report")
        report_lines.append("=" * 60)
        report_lines.append("\n--- SCORING METRICS (Transparency Report) ---")
        report_lines.append("The holistic score is calculated using the following criteria:")
        report_lines.append("\nWeighted Components (normalized to a 0-100 scale):")
        for component, weight in SCORING_WEIGHTS.items():
            report_lines.append(f"  - {component.title():<18}: {weight:.0%}")

        report_lines.append("\nBonus Points (added to weighted score):")
        for context, points in BONUS_POINTS.items():
            report_lines.append(f"  - {context.replace('_', ' ').title():<18}: +{points} points")

        report_lines.append("\nDecision Thresholds:")
        report_lines.append(f"  - Admit: Score >= {ADMIT_THRESHOLD}")
        report_lines.append(f"  - Waitlist: {WAITLIST_THRESHOLD} <= Score < {ADMIT_THRESHOLD}")
        report_lines.append(f"  - Reject: Score < {WAITLIST_THRESHOLD}")

        # Section 2: Overall Statistics
        total_applicants = len(self.applicants)
        decisions = [app.decision for app in self.applicants if app.decision]
        admitted_count = decisions.count("Admit")
        waitlisted_count = decisions.count("Waitlist")
        rejected_count = decisions.count("Reject")

        report_lines.append("\n\n--- OVERALL APPLICANT POOL STATISTICS ---")
        report_lines.append(f"Total Applicants Processed: {total_applicants}")
        report_lines.append("-" * 30)
        report_lines.append(f"Admitted:   {admitted_count:>4} ({admitted_count/total_applicants:.1%})")
        report_lines.append(f"Waitlisted: {waitlisted_count:>4} ({waitlisted_count/total_applicants:.1%})")
        report_lines.append(f"Rejected:   {rejected_count:>4} ({rejected_count/total_applicants:.1%})")

        # Section 3: Admitted Cohort Profile
        admitted_cohort = [app for app in self.applicants if app.decision == "Admit"]
        report_lines.append("\n\n--- ADMITTED COHORT PROFILE ---")

        if not admitted_cohort:
            report_lines.append("No applicants were admitted in this cycle.")
        else:
            avg_gpa = statistics.mean(app.gpa for app in admitted_cohort)
            avg_holistic_score = statistics.mean(app.holistic_score for app in admitted_cohort)
            admitted_test_scores = [self._get_unified_test_score(app) for app in admitted_cohort]
            avg_test_score = statistics.mean(admitted_test_scores)
            first_gen_pct = statistics.mean(app.is_first_generation for app in admitted_cohort) * 100
            in_state_pct = statistics.mean(app.is_in_state for app in admitted_cohort) * 100

            report_lines.append(f"Number of Admits: {len(admitted_cohort)}")
            report_lines.append(f"Average Holistic Score: {avg_holistic_score:.2f}")
            report_lines.append(f"Average GPA: {avg_gpa:.2f}")
            report_lines.append(f"Average Test Score (SAT Scale): {avg_test_score:.0f}")
            report_lines.append(f"First-Generation Students: {first_gen_pct:.1f}%")
            report_lines.append(f"In-State Students: {in_state_pct:.1f}%")

        report_lines.append("\n" + "=" * 60)
        return "\n".join(report_lines)


# --- Utility Functions ---

def generate_sample_applicants(num_applicants: int) -> List[Applicant]:
    """
    Creates a list of randomized applicant data for demonstration purposes.
    NFR1: This allows the application to be self-contained and runnable without
          requiring external data sources.
    """
    applicants = []
    for i in range(1, num_applicants + 1):
        # Use triangular distribution to generate more realistic, centered data
        gpa = round(random.triangular(2.5, MAX_GPA, 3.7), 2)
        extracurriculars = random.randint(3, 10)
        essay_score = random.randint(4, 10)

        # Randomly assign either an SAT or ACT score
        sat, act = None, None
        if random.random() > 0.4:  # 60% chance of providing SAT
            sat = random.randint(1100, 1550)
        else:  # 40% chance of providing ACT
            act = random.randint(22, 35)

        applicant = Applicant(
            applicant_id=10000 + i,
            gpa=gpa,
            sat_score=sat,
            act_score=act,
            extracurriculars=extracurriculars,
            essay_score=essay_score,
            is_first_generation=random.choice([True, False]),
            is_in_state=random.random() > 0.6  # Assume 40% of applicants are in-state
        )
        applicants.append(applicant)
    return applicants


# --- Main Execution Block ---

def main():
    """
    Main function to run the admissions screening simulation.
    """
    # 1. Generate sample applicant data
    num_applicants = 500
    print(f"Generating {num_applicants} sample applicants...")
    sample_applicants = generate_sample_applicants(num_applicants)

    # 2. Initialize the admissions system with the applicant data
    admissions_system = AdmissionsSystem(sample_applicants)

    # 3. Process all applications to calculate scores and make decisions
    admissions_system.process_applications()

    # 4. Generate and print the final summary report
    report = admissions_system.generate_report()
    print("\n" + report)


if __name__ == "__main__":
    # NFR1: The application is executed as a self-contained script.
    main()