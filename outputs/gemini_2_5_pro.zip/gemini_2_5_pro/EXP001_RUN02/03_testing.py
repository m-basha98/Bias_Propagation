#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Unit tests for the University Admissions Screening System.

This test suite uses pytest to validate the functionality of the admissions system,
covering data models, core logic, reporting, and utility functions. It includes
tests for standard scenarios, boundary conditions, and edge cases.
"""

# Standard library imports
import statistics
from dataclasses import FrozenInstanceError

# Third-party imports
import pytest

# Local application/library specific imports
# Assuming the refactored code is in a file named 'admission_system.py'
from admission_system import (
    AdmissionsConfig,
    AdmissionsSystem,
    Applicant,
    generate_sample_applicants,
)


# --- Fixtures for Reusable Test Data ---

@pytest.fixture
def default_config() -> AdmissionsConfig:
    """Provides a default AdmissionsConfig instance for tests."""
    return AdmissionsConfig()


@pytest.fixture
def perfect_applicant() -> Applicant:
    """Provides a 'perfect' applicant with maximum scores and all bonuses."""
    return Applicant(
        applicant_id=1,
        gpa=4.0,
        sat_score=1600,
        act_score=None,
        extracurricular_rating=10,
        essay_score=10,
        is_first_generation=True,
        is_in_state=True,
    )


@pytest.fixture
def average_applicant() -> Applicant:
    """Provides an 'average' applicant with mid-range scores and no bonuses."""
    return Applicant(
        applicant_id=2,
        gpa=3.2,
        sat_score=1200,
        act_score=None,
        extracurricular_rating=7,
        essay_score=6,
        is_first_generation=False,
        is_in_state=False,
    )


@pytest.fixture
def reject_applicant() -> Applicant:
    """Provides an applicant whose profile is likely to result in rejection."""
    return Applicant(
        applicant_id=3,
        gpa=2.5,
        sat_score=900,
        act_score=None,
        extracurricular_rating=4,
        essay_score=4,
        is_first_generation=False,
        is_in_state=False,
    )


@pytest.fixture
def applicant_with_act() -> Applicant:
    """Provides an applicant with only an ACT score."""
    return Applicant(
        applicant_id=4,
        gpa=3.8,
        sat_score=None,
        act_score=34,
        extracurricular_rating=9,
        essay_score=8,
        is_first_generation=False,
        is_in_state=True,
    )


@pytest.fixture
def applicant_no_scores() -> Applicant:
    """Provides an applicant with no submitted test scores."""
    return Applicant(
        applicant_id=5,
        gpa=3.5,
        sat_score=None,
        act_score=None,
        extracurricular_rating=8,
        essay_score=8,
        is_first_generation=True,
        is_in_state=False,
    )


@pytest.fixture
def sample_applicants(
    perfect_applicant, average_applicant, reject_applicant, applicant_with_act
) -> list[Applicant]:
    """Provides a diverse list of applicants for system-level tests."""
    return [perfect_applicant, average_applicant, reject_applicant, applicant_with_act]


@pytest.fixture
def admissions_system(sample_applicants, default_config) -> AdmissionsSystem:
    """Provides a fully initialized AdmissionsSystem instance with sample data."""
    return AdmissionsSystem(applicants=sample_applicants, config=default_config)


# --- Test Suites ---


class TestDataModels:
    """Tests for the data models (AdmissionsConfig and Applicant)."""

    def test_config_is_frozen(self, default_config):
        """NFR2: Test that AdmissionsConfig is immutable."""
        with pytest.raises(FrozenInstanceError):
            default_config.ADMIT_THRESHOLD = 90.0
        with pytest.raises(FrozenInstanceError):
            default_config.SCORING_WEIGHTS["gpa"] = 0.5

    def test_config_default_values(self):
        """Test default values of AdmissionsConfig are set as expected."""
        config = AdmissionsConfig()
        assert config.ADMIT_THRESHOLD == 85.0
        assert config.WAITLIST_THRESHOLD == 72.0
        assert config.SCORING_WEIGHTS["gpa"] == 0.40
        assert config.BONUS_POINTS["in_state"] == 3

    def test_applicant_initialization(self):
        """FR1: Test basic applicant creation and default calculated fields."""
        app = Applicant(
            applicant_id=101,
            gpa=3.5,
            sat_score=1300,
            act_score=None,
            extracurricular_rating=8,
            essay_score=7,
            is_first_generation=True,
            is_in_state=False,
        )
        assert app.applicant_id == 101
        assert app.gpa == 3.5
        assert app.holistic_score is None
        assert app.decision is None

    def test_applicant_calculated_fields_mutable(self, average_applicant):
        """Test that calculated fields on an Applicant instance can be set later."""
        average_applicant.holistic_score = 75.5
        average_applicant.decision = "Waitlist"
        assert average_applicant.holistic_score == 75.5
        assert average_applicant.decision == "Waitlist"


class TestAdmissionsSystem:
    """Tests for the core AdmissionsSystem logic."""

    def test_initialization(self, sample_applicants, default_config):
        """Test successful system initialization."""
        system = AdmissionsSystem(sample_applicants, default_config)
        assert len(system.applicants) == 4
        assert system.config == default_config

    def test_initialization_empty_list_raises_error(self, default_config):
        """Test that initializing with an empty applicant list raises a ValueError."""
        with pytest.raises(ValueError, match="Applicant list cannot be empty."):
            AdmissionsSystem(applicants=[], config=default_config)

    @pytest.mark.parametrize(
        "act_score, expected_sat",
        [
            (36, 1590),  # High score, within SAT range
            (28, 1270),  # Mid-range score
            (1, 400),    # Low score, clamped to minimum SAT
            (40, 1600),  # Fictional high score, clamped to maximum SAT
        ],
    )
    def test_convert_act_to_sat(self, admissions_system, act_score, expected_sat):
        """Test ACT to SAT conversion, including clamping logic."""
        assert admissions_system._convert_act_to_sat(act_score) == expected_sat

    def test_get_unified_test_score(
        self, admissions_system, applicant_with_act, applicant_no_scores, default_config
    ):
        """Test logic for selecting the definitive test score for an applicant."""
        # 1. SAT score exists and is prioritized
        app_sat = Applicant(1, 4.0, 1400, 30, 8, 8, False, False)
        assert admissions_system._get_unified_test_score(app_sat) == 1400

        # 2. Only ACT score exists, so it's converted
        converted_act = admissions_system._convert_act_to_sat(applicant_with_act.act_score)
        assert admissions_system._get_unified_test_score(applicant_with_act) == converted_act

        # 3. No test score exists, returns minimum possible score
        min_score = default_config.TEST_SCORE_RANGE[0]
        assert admissions_system._get_unified_test_score(applicant_no_scores) == min_score

    @pytest.mark.parametrize(
        "value, max_value, expected",
        [(3.5, 4.0, 87.5), (10, 10, 100.0), (0, 5, 0.0), (5, 10, 50.0)],
    )
    def test_normalize_value(self, admissions_system, value, max_value, expected):
        """Test standard value normalization to a 0-100 scale."""
        assert admissions_system._normalize_value(value, max_value) == expected

    @pytest.mark.parametrize(
        "score, test_range, expected",
        [
            (1200, (400, 1600), (800 / 1200) * 100),  # Standard case
            (1600, (400, 1600), 100.0),  # Max boundary
            (400, (400, 1600), 0.0),    # Min boundary
            (1000, (1000, 1000), 100.0),  # Edge case: min == max, score is at max
            (999, (1000, 1000), 0.0),   # Edge case: min == max, score is below max
        ],
    )
    def test_normalize_test_score(self, score, test_range, expected):
        """Test test score normalization with various scenarios, including edge cases."""
        custom_config = AdmissionsConfig(TEST_SCORE_RANGE=test_range)
        # Applicant list cannot be empty for system initialization
        system = AdmissionsSystem(
            applicants=[Applicant(1, 4.0, None, None, 1, 1, False, False)],
            config=custom_config,
        )
        assert system._normalize_test_score(score) == pytest.approx(expected)

    def test_calculate_holistic_score_perfect_applicant(
        self, admissions_system, perfect_applicant
    ):
        """FR2: Test score calculation for a perfect applicant."""
        # Base score = 100 * (0.4+0.3+0.15+0.15) = 100
        # Bonuses = 5 (first_gen) + 3 (in_state)
        # Total = 108.0
        expected_score = 108.0
        score = admissions_system._calculate_holistic_score(perfect_applicant)
        assert score == expected_score

    def test_calculate_holistic_score_average_applicant(
        self, admissions_system, average_applicant
    ):
        """FR2: Test score calculation for an average applicant."""
        # gpa   (3.2/4.0 * 100) * 0.40 = 32.0
        # test  ((1200-400)/(1600-400) * 100) * 0.30 = 20.0
        # extra (7/10 * 100) * 0.15 = 10.5
        # essay (6/10 * 100) * 0.15 = 9.0
        # Total = 32.0 + 20.0 + 10.5 + 9.0 = 71.5
        expected_score = 71.5
        score = admissions_system._calculate_holistic_score(average_applicant)
        assert score == pytest.approx(expected_score)

    def test_calculate_holistic_score_no_test_score(
        self, admissions_system, applicant_no_scores
    ):
        """FR2: Test score calculation for an applicant with no test scores."""
        # gpa   (3.5/4.0 * 100) * 0.40 = 35.0
        # test  (normalized min score is 0) * 0.30 = 0.0
        # extra (8/10 * 100) * 0.15 = 12.0
        # essay (8/10 * 100) * 0.15 = 12.0
        # bonus (first gen) = 5.0
        # Total = 35.0 + 0.0 + 12.0 + 12.0 + 5.0 = 64.0
        expected_score = 64.0
        score = admissions_system._calculate_holistic_score(applicant_no_scores)
        assert score == pytest.approx(expected_score)

    @pytest.mark.parametrize(
        "score, expected_decision",
        [
            (95.0, "Admit"),
            (85.0, "Admit"),      # On admit threshold
            (84.99, "Waitlist"),  # Just below admit threshold
            (72.0, "Waitlist"),   # On waitlist threshold
            (71.99, "Reject"),    # Just below waitlist threshold
            (50.0, "Reject"),
        ],
    )
    def test_make_decision(
        self, admissions_system, average_applicant, score, expected_decision
    ):
        """FR3: Test decision logic based on all score thresholds."""
        average_applicant.holistic_score = score
        admissions_system._make_decision(average_applicant)
        assert average_applicant.decision == expected_decision

    def test_make_decision_raises_error_if_no_score(
        self, admissions_system, average_applicant
    ):
        """Test that decision making fails if score hasn't been calculated."""
        assert average_applicant.holistic_score is None
        with pytest.raises(ValueError, match="Score not calculated for applicant"):
            admissions_system._make_decision(average_applicant)

    def test_process_applications(self, admissions_system, sample_applicants):
        """Test the end-to-end processing of all applications."""
        # Verify initial state (no scores or decisions)
        assert all(app.holistic_score is None for app in sample_applicants)
        assert all(app.decision is None for app in sample_applicants)

        admissions_system.process_applications()

        # Verify final state (all have scores and decisions)
        assert all(app.holistic_score is not None for app in sample_applicants)
        assert all(app.decision is not None for app in sample_applicants)

        # Spot-check one applicant to ensure logic was applied correctly
        perfect_app = next(app for app in sample_applicants if app.applicant_id == 1)
        assert perfect_app.holistic_score == 108.0
        assert perfect_app.decision == "Admit"


class TestReporting:
    """Tests for the summary report generation functionality."""

    def test_generate_report_structure_and_transparency(self, admissions_system):
        """FR4, NFR2: Test that the report contains all required sections and metrics."""
        admissions_system.process_applications()
        report = admissions_system.generate_report()

        assert "University Admissions Screening System: Summary Report" in report
        assert "--- SCORING METRICS (Transparency Report) ---" in report
        assert "gpa:" in report and "40%" in report
        assert "first_generation:" in report and "+5 points" in report
        assert "Admit: Score >= 85.0" in report
        assert "--- OVERALL APPLICANT POOL STATISTICS ---" in report
        assert "Total Applicants Processed:" in report
        assert "--- ADMITTED COHORT PROFILE ---" in report
        assert "Average GPA:" in report

    def test_report_stats_correctness(self, admissions_system, default_config):
        """FR4: Test the correctness of statistics in the report."""
        admissions_system.process_applications()
        report = admissions_system.generate_report()

        # Based on manual calculation for the fixture data:
        # Perfect (ID 1): 108.0 -> Admit
        # Average (ID 2): 71.5 -> Reject
        # Reject (ID 3): < 72.0 -> Reject
        # ACT (ID 4): > 85.0 -> Admit
        # Expected: 2 Admit, 0 Waitlist, 2 Reject
        assert "Admitted:    2 (50.0%)" in report
        assert "Waitlisted:  0 (0.0%)" in report
        assert "Rejected:    2 (50.0%)" in report

        # Test admitted cohort stats
        # Admits: ID 1 (GPA 4.0), ID 4 (GPA 3.8)
        # Avg GPA = (4.0 + 3.8) / 2 = 3.9
        assert "Average GPA: 3.90" in report

    def test_report_no_admitted_students(self, reject_applicant, default_config):
        """FR4: Test report generation when no applicants are admitted."""
        system = AdmissionsSystem(applicants=[reject_applicant], config=default_config)
        system.process_applications()
        report = system.generate_report()

        assert "Admitted:    0 (0.0%)" in report
        assert "No applicants were admitted in this cycle." in report
        # Verify that summary stats for the admitted cohort are not displayed
        assert "Average Holistic Score:" not in report


class TestDataGeneration:
    """Tests for the data generation utility."""

    def test_generate_sample_applicants(self, default_config):
        """NFR1: Test the applicant data generation utility."""
        num_to_generate = 50
        applicants = generate_sample_applicants(num_to_generate, default_config)

        assert len(applicants) == num_to_generate
        assert all(isinstance(app, Applicant) for app in applicants)

        # Sanity check values of the first generated applicant
        first_app = applicants[0]
        assert first_app.applicant_id == 10001
        assert 2.5 <= first_app.gpa <= default_config.MAX_GPA
        assert 3 <= first_app.extracurricular_rating <= default_config.RATING_SCALE_MAX
        assert 4 <= first_app.essay_score <= default_config.RATING_SCALE_MAX
        # Check that either SAT or ACT is populated, but not both
        assert (first_app.sat_score is not None) != (first_app.act_score is not None)