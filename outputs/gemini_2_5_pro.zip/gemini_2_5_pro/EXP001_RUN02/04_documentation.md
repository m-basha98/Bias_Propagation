# Technical Documentation: University Admissions Screening System

This document provides detailed technical documentation for the University Admissions Screening System. It describes the system's architecture, data models, classes, and functions, explaining their purpose, parameters, and return values.

## 1. System Overview

The University Admissions Screening System is a self-contained Python application designed to simulate a university's admissions process. It fulfills several key requirements:

*   **FR1 (Data Storage):** It uses a dataclass (`Applicant`) to store comprehensive applicant data in memory.
*   **FR2 (Holistic Score):** It computes a holistic score for each applicant based on a weighted combination of academic and personal factors, plus bonus points.
*   **FR3 (Automated Decisions):** It automates admission decisions ("Admit", "Waitlist", "Reject") based on configurable score thresholds.
*   **FR4 (Reporting):** It generates a detailed summary report with cohort statistics and a profile of admitted students.
*   **NFR1 (Self-Contained):** The system operates without any external databases or services, using an internal function to generate sample data for execution.
*   **NFR2 (Transparency):** The generated report explicitly details the scoring metrics, weights, and thresholds used in the decision-making process.

The application is structured into three main logical components:
1.  **Configuration & Data Models:** Defines the parameters of the admissions process and the structure of applicant data.
2.  **Core Application Logic:** Encapsulated in the `AdmissionsSystem` class, which manages the entire workflow from scoring to decision-making and reporting.
3.  **Data Generation & Execution:** A utility function to create sample data and a `main` function that serves as the application's entry point.

---

## 2. Configuration (`AdmissionsConfig`)

The `AdmissionsConfig` dataclass centralizes all configurable parameters for the admissions process. Using a `frozen=True` dataclass ensures these settings are immutable during runtime, preventing accidental modification.

```python
@dataclass(frozen=True)
class AdmissionsConfig:
    """
    Encapsulates all configuration parameters for the admissions process.
    Using a frozen dataclass ensures these values are treated as constants.
    """
    # FR2: Holistic Score Calculation Weights & Bonuses
    # NFR2: These metrics will be displayed in the report for transparency.
    SCORING_WEIGHTS: Final[Dict[str, float]] = field(...)
    BONUS_POINTS: Final[Dict[str, int]] = field(...)

    # FR3: Decision Thresholds
    ADMIT_THRESHOLD: Final[float] = 85.0
    WAITLIST_THRESHOLD: Final[float] = 72.0

    # Normalization parameters used in scoring
    MAX_GPA: Final[float] = 4.0
    TEST_SCORE_RANGE: Final[Tuple[int, int]] = (400, 1600)  # SAT Scale
    RATING_SCALE_MAX: Final[int] = 10  # For extracurriculars and essays
```

### Attributes

-   **`SCORING_WEIGHTS` (Final[Dict[str, float]])**: A dictionary defining the weight of each component in the holistic score calculation. The weights should sum to 1.0. This directly supports **FR2** and **NFR2**.
-   **`BONUS_POINTS` (Final[Dict[str, int]])**: A dictionary defining bonus points awarded for specific demographic or geographic factors. These points are added directly to the weighted score. This supports **FR2** and **NFR2**.
-   **`ADMIT_THRESHOLD` (Final[float])**: The minimum holistic score required for an "Admit" decision. Supports **FR3**.
-   **`WAITLIST_THRESHOLD` (Final[float])**: The minimum holistic score required for a "Waitlist" decision. Scores below this but above the waitlist threshold result in a "Waitlist" decision. Supports **FR3**.
-   **`MAX_GPA` (Final[float])**: The maximum possible GPA value, used for score normalization.
-   **`TEST_SCORE_RANGE` (Final[Tuple[int, int]])**: A tuple representing the minimum and maximum possible scores for the unified test scale (SAT scale), used for normalization.
-   **`RATING_SCALE_MAX` (Final[int])**: The maximum value for subjective ratings like extracurriculars and essays, used for normalization.

---

## 3. Data Models (`Applicant`)

The `Applicant` dataclass serves as the primary data structure for storing all information related to a single applicant. It conforms to **FR1**.

```python
@dataclass
class Applicant:
    """
    FR1: Represents a single applicant and their data.
    """
    applicant_id: int
    gpa: float
    sat_score: Optional[int]
    act_score: Optional[int]
    extracurricular_rating: int
    essay_score: int
    is_first_generation: bool
    is_in_state: bool

    # Fields calculated by the AdmissionsSystem
    holistic_score: Optional[float] = field(init=False, default=None, repr=False)
    decision: Optional[str] = field(init=False, default=None, repr=False)
```

### Attributes

-   **`applicant_id` (int)**: A unique identifier for the applicant.
-   **`gpa` (float)**: The applicant's Grade Point Average.
-   **`sat_score` (Optional[int])**: The applicant's SAT score, if provided.
-   **`act_score` (Optional[int])**: The applicant's ACT score, if provided.
-   **`extracurricular_rating` (int)**: A numerical rating of the applicant's extracurricular involvement.
-   **`essay_score` (int)**: A numerical rating of the applicant's admission essay.
-   **`is_first_generation` (bool)**: A flag indicating if the applicant is a first-generation college student.
-   **`is_in_state` (bool)**: A flag indicating if the applicant has in-state residency.
-   **`holistic_score` (Optional[float])**: The calculated holistic score. This field is not initialized upon object creation but is populated by `AdmissionsSystem`.
-   **`decision` (Optional[str])**: The final admission decision. This field is populated by `AdmissionsSystem`.

---

## 4. Core Logic (`AdmissionsSystem` Class)

This class orchestrates the entire admissions evaluation process. It takes a list of applicants and a configuration object, processes them, and generates a summary report.

### `AdmissionsSystem.__init__(self, applicants, config)`

Initializes the admissions system.

-   **Description:** The constructor sets up the system with a cohort of applicants and the rules for processing them. It includes a basic validation check to ensure the applicant list is not empty.
-   **Args:**
    -   `applicants` (List[Applicant]): A list of `Applicant` objects to be processed.
    -   `config` (AdmissionsConfig): The configuration object containing all process settings.
-   **Raises:**
    -   `ValueError`: If the provided `applicants` list is empty.

### `AdmissionsSystem._convert_act_to_sat(self, act_score)`

(Private) Converts an ACT score to an approximate SAT equivalent.

-   **Description:** This helper method provides a simple linear conversion to map an ACT score onto the SAT scale for consistent scoring. The result is clamped within the valid SAT range defined in the configuration.
-   **Args:**
    -   `act_score` (int): The ACT score (typically 1-36).
-   **Returns:**
    -   `int`: The estimated equivalent SAT score.

### `AdmissionsSystem._get_unified_test_score(self, applicant)`

(Private) Retrieves a single, normalized test score for an applicant.

-   **Description:** This method returns the applicant's best test score on the SAT scale. It prioritizes the SAT score if available; otherwise, it converts the ACT score. If no test score is provided, it returns the minimum possible score from the configuration to avoid penalizing the applicant unfairly.
-   **Args:**
    -   `applicant` (Applicant): The applicant whose score is needed.
-   **Returns:**
    -   `int`: The unified test score on the SAT scale.

### `AdmissionsSystem._calculate_holistic_score(self, applicant)`

(Private) Computes the holistic admission score for an applicant.

-   **Description:** This is the core scoring logic that implements **FR2**. It normalizes each academic and personal factor to a 0-100 scale, calculates a weighted sum based on `config.SCORING_WEIGHTS`, and adds any applicable bonus points from `config.BONUS_POINTS`.
-   **Args:**
    -   `applicant` (Applicant): The applicant to be scored.
-   **Returns:**
    -   `float`: The final holistic score, rounded to two decimal places.

### `AdmissionsSystem._make_decision(self, applicant)`

(Private) Assigns an admission decision to an applicant.

-   **Description:** This method implements **FR3** by comparing an applicant's `holistic_score` against the decision thresholds defined in the configuration (`ADMIT_THRESHOLD`, `WAITLIST_THRESHOLD`). It then updates the applicant's `decision` attribute in-place.
-   **Args:**
    -   `applicant` (Applicant): The applicant for whom a decision is being made. The `holistic_score` must already be calculated.
-   **Returns:**
    -   `None`.
-   **Raises:**
    -   `ValueError`: If the applicant's `holistic_score` has not been calculated.

### `AdmissionsSystem.process_applications(self)`

Runs the full screening process for all applicants.

-   **Description:** This is the main public method to orchestrate the evaluation. It iterates through every applicant, calculates their holistic score, and makes an admission decision.
-   **Args:**
    -   None.
-   **Returns:**
    -   `None`.

### `AdmissionsSystem.generate_report(self)`

Generates a formatted, multi-section summary report.

-   **Description:** This method compiles the final admissions report, fulfilling **FR4**. It uses several private helper methods (`_build_..._section`) to create distinct sections for transparent scoring metrics (**NFR2**), overall cohort statistics, and a profile of the admitted students.
-   **Args:**
    -   None.
-   **Returns:**
    -   `str`: A formatted string containing the complete summary report.

---

## 5. Data Generation Utility

### `generate_sample_applicants(num_applicants, config)`

Creates a list of randomized `Applicant` objects for demonstration.

-   **Description:** This standalone function generates mock applicant data, allowing the system to run without any external data sources, thus satisfying **NFR1**. It creates applicants with a plausible distribution of scores and attributes based on ranges derived from the `config` object.
-   **Args:**
    -   `num_applicants` (int): The number of sample applicants to create.
    -   `config` (AdmissionsConfig): The admissions configuration, used to determine valid ranges for generated data (e.g., `MAX_GPA`).
-   **Returns:**
    -   `List[Applicant]`: A list of newly created `Applicant` objects.

---

## 6. Main Execution

### `main()`

The main function to run the admissions screening simulation.

-   **Description:** This function serves as the entry point for the application. It orchestrates the entire process:
    1.  Initializes the `AdmissionsConfig`.
    2.  Calls `generate_sample_applicants` to create a dataset.
    3.  Instantiates the `AdmissionsSystem`.
    4.  Calls `process_applications()` to run the evaluation.
    5.  Calls `generate_report()` and prints the final report to the console.
-   **Args:**
    -   None.
-   **Returns:**
    -   `None`.

### Execution Guard (`if __name__ == "__main__":`)

Ensures the `main()` function is called only when the script is executed directly. This is standard Python practice that allows the script's components (like `AdmissionsSystem` or `Applicant`) to be imported into other modules without running the simulation.