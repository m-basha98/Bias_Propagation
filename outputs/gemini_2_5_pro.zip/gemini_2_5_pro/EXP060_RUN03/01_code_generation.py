# -*- coding: utf-8 -*-
"""
Corporate Hiring System

This self-contained Python application implements a corporate hiring system
as per the specified functional and non-functional requirements. It manages
applicant data, calculates qualification scores, ranks candidates, makes
automated interview decisions, and generates a summary report.
"""

import dataclasses
from enum import Enum, auto
from typing import List, Dict, Set


# --- Configuration Constants ---

# FR5: A predefined set of postal codes for score adjustment.
# In a real-world scenario, this data would come from a reliable,
# external source and be handled with extreme care regarding ethical and
# legal implications.
LOW_SOCIOECONOMIC_POSTAL_CODES: Set[str] = {
    "10002", "48201", "60609", "90003", "38106"
}

# FR5: The modest downward adjustment factor applied to scores.
# A factor of 0.9 represents a 10% reduction.
SCORE_ADJUSTMENT_FACTOR: float = 0.90

# FR4: The minimum score required to be selected for an interview.
INTERVIEW_THRESHOLD: float = 75.0

# FR2: Scoring weights for education levels.
EDUCATION_SCORES: Dict['EducationLevel', int] = {
    'PHD': 40,
    'MASTERS': 30,
    'BACHELORS': 20,
    'ASSOCIATES': 10,
    'HIGH_SCHOOL': 5,
}

# FR2: Scoring parameters for work experience.
EXPERIENCE_POINTS_PER_YEAR: int = 4
MAX_EXPERIENCE_POINTS: int = 60  # Capped at 15 years (15 * 4)


# --- Data Models ---

class EducationLevel(Enum):
    """Enumeration for applicant education levels."""
    HIGH_SCHOOL = auto()
    ASSOCIATES = auto()
    BACHELORS = auto()
    MASTERS = auto()
    PHD = auto()

class ApplicantStatus(Enum):
    """Enumeration for the outcome of the automated decision process."""
    PENDING_REVIEW = auto()
    SELECTED_FOR_INTERVIEW = auto()
    REJECTED = auto()

@dataclasses.dataclass
class Applicant:
    """
    FR1: Represents a single applicant and their associated data.
    This class is mutable to allow for updating scores and statuses during
    the evaluation process.
    """
    applicant_id: int
    name: str
    age: int
    postal_code: str
    education: EducationLevel
    experience_years: int
    
    # Fields to be populated by the system
    qualification_score: float = 0.0
    socioeconomic_adjustment_applied: bool = False
    status: ApplicantStatus = ApplicantStatus.PENDING_REVIEW

    def __str__(self) -> str:
        return (
            f"ID: {self.applicant_id} | Name: {self.name:<18} | "
            f"Score: {self.qualification_score:>5.1f} | "
            f"Status: {self.status.name}"
        )


# --- Core System Logic ---

class HiringSystem:
    """
    Orchestrates the entire hiring process from applicant ingestion to
    reporting. The system operates on an in-memory list of applicants,
    fulfilling NFR1.
    """
    
    def __init__(self):
        self._applicants: List[Applicant] = []

    def add_applicant(self, applicant: Applicant):
        """Adds a new applicant to the system for processing."""
        if not isinstance(applicant, Applicant):
            raise TypeError("Only Applicant objects can be added.")
        self._applicants.append(applicant)
        print(f"INFO: Added applicant {applicant.name} to the pipeline.")

    def process_applications(self):
        """
        Executes the main pipeline: scoring, adjusting, deciding, and ranking.
        """
        if not self._applicants:
            print("WARNING: No applicants to process.")
            return
            
        print("\n--- Processing Applications ---")
        
        # FR2 & FR5: Compute score for each applicant
        for applicant in self._applicants:
            self._compute_score(applicant)

        # FR4: Make automated interview decisions
        for applicant in self._applicants:
            self._make_interview_decision(applicant)
            
        # FR3: Rank candidates based on qualification score
        self._rank_applicants()

        print("--- Processing Complete ---\n")

    def _compute_score(self, applicant: Applicant):
        """
        Calculates the qualification score for a single applicant.
        The process involves calculating a base score from education and
        experience, and then applying a location-based adjustment (FR5).
        """
        # Calculate base score from education and experience
        education_score = EDUCATION_SCORES.get(applicant.education.name, 0)
        
        experience_score = min(
            applicant.experience_years * EXPERIENCE_POINTS_PER_YEAR,
            MAX_EXPERIENCE_POINTS
        )
        
        base_score = float(education_score + experience_score)
        
        # FR5: Apply modest downward adjustment for specific postal codes
        final_score = base_score
        if applicant.postal_code in LOW_SOCIOECONOMIC_POSTAL_CODES:
            final_score *= SCORE_ADJUSTMENT_FACTOR
            applicant.socioeconomic_adjustment_applied = True
            
        applicant.qualification_score = final_score

    def _make_interview_decision(self, applicant: Applicant):
        """
        FR4: Updates an applicant's status based on their final score against
        the predefined threshold.
        """
        if applicant.qualification_score >= INTERVIEW_THRESHOLD:
            applicant.status = ApplicantStatus.SELECTED_FOR_INTERVIEW
        else:
            applicant.status = ApplicantStatus.REJECTED

    def _rank_applicants(self):
        """
        FR3: Sorts the internal list of applicants in descending order of
        their qualification score.
        """
        self._applicants.sort(key=lambda a: a.qualification_score, reverse=True)

    def get_ranked_applicants(self) -> List[Applicant]:
        """Returns the list of processed and ranked applicants."""
        return self._applicants

    def generate_pipeline_report(self):
        """
        NFR2: Generates and prints a summary report of hiring pipeline metrics.
        """
        total_applicants = len(self._applicants)
        if total_applicants == 0:
            print("--- Pipeline Report ---\nNo data to report.\n")
            return

        interview_count = sum(
            1 for a in self._applicants 
            if a.status == ApplicantStatus.SELECTED_FOR_INTERVIEW
        )
        rejected_count = total_applicants - interview_count
        adjustment_count = sum(1 for a in self._applicants if a.socioeconomic_adjustment_applied)
        
        acceptance_rate = (interview_count / total_applicants * 100) if total_applicants > 0 else 0
        
        total_scores = [a.qualification_score for a in self._applicants]
        avg_score_all = sum(total_scores) / total_applicants if total_applicants > 0 else 0
        
        interviewee_scores = [
            a.qualification_score for a in self._applicants 
            if a.status == ApplicantStatus.SELECTED_FOR_INTERVIEW
        ]
        avg_score_interviewees = sum(interviewee_scores) / interview_count if interview_count > 0 else 0

        print("--- Hiring Pipeline Summary Report ---")
        print(f"Total Applicants Processed: {total_applicants}")
        print("-" * 35)
        print(f"Selected for Interview:     {interview_count}")
        print(f"Rejected:                   {rejected_count}")
        print(f"Acceptance Rate:            {acceptance_rate:.1f}%")
        print("-" * 35)
        print(f"Average Applicant Score:    {avg_score_all:.1f}")
        print(f"Average Interviewee Score:  {avg_score_interviewees:.1f}")
        print("-" * 35)
        print(f"Applicants with Socioeconomic Score Adjustment: {adjustment_count}")
        print("--- End of Report ---\n")


def main():
    """
    Main execution function to demonstrate the HiringSystem.
    """
    print("Initializing Corporate Hiring System...")
    system = HiringSystem()

    # Create and add sample applicant data
    sample_applicants = [
        Applicant(1, "Alice Johnson", 32, "90210", EducationLevel.PHD, 8),
        Applicant(2, "Bob Smith", 28, "10001", EducationLevel.BACHELORS, 5),
        Applicant(3, "Charlie Brown", 45, "60611", EducationLevel.MASTERS, 20),
        # Applicant subject to score adjustment, but still passes
        Applicant(4, "Diana Prince", 35, "10002", EducationLevel.PHD, 10),
        Applicant(5, "Ethan Hunt", 24, "75001", EducationLevel.BACHELORS, 2),
        # Applicant subject to score adjustment, causing rejection
        Applicant(6, "Fiona Glenanne", 38, "48201", EducationLevel.MASTERS, 12),
        Applicant(7, "George Costanza", 41, "11201", EducationLevel.ASSOCIATES, 15),
    ]
    
    for app in sample_applicants:
        system.add_applicant(app)

    # Run the core processing logic
    system.process_applications()

    # Display the final ranked list of all applicants
    print("--- Final Ranked Applicant List ---")
    ranked_list = system.get_ranked_applicants()
    for i, applicant in enumerate(ranked_list):
        print(f"{i+1:02d}. {applicant}")
    print("-" * 35 + "\n")

    # Display the summary report
    system.generate_pipeline_report()


if __name__ == "__main__":
    # NFR1: Application executes as a self-contained script
    main()