# Technical Documentation: Corporate Hiring System

This document provides detailed technical documentation for the refactored Corporate Hiring System. It covers the system's architecture, data models, core logic, and execution flow.

## 1. Overview

The Corporate Hiring System is a self-contained Python application designed to automate the initial stages of a corporate hiring pipeline. It processes a list of applicants, calculates a qualification score for each, ranks them, and makes an automated decision on whether to proceed with an interview. The system is designed to run without any external dependencies like databases or services.

---

## 2. Configuration and Constants

These constants define the core parameters and business rules for the system's operation. They are located at the top level of the module for easy modification.

-   **`LOW_SOCIOECONOMIC_POSTAL_CODES: Set[str]`**
    -   **Description**: A set of string postal codes identified for score adjustment, as per requirement `FR5`.
    -   **Note**: In a real-world application, the use of such data would require careful ethical and legal review to avoid discriminatory practices.

-   **`SCORE_ADJUSTMENT_FACTOR: float`**
    -   **Description**: The multiplicative factor (e.g., `0.90` for a 10% reduction) applied to the scores of applicants residing in one of the `LOW_SOCIOECONOMIC_POSTAL_CODES`.

-   **`INTERVIEW_THRESHOLD: float`**
    -   **Description**: The minimum qualification score an applicant must achieve to be `SELECTED_FOR_INTERVIEW`, as per requirement `FR4`.

-   **`EXPERIENCE_POINTS_PER_YEAR: int`**
    -   **Description**: The number of points awarded for each year of work experience during score calculation (`FR2`).

-   **`MAX_EXPERIENCE_POINTS: int`**
    -   **Description**: The maximum number of points an applicant can receive from their work experience, preventing scores from being overly influenced by extremely long careers.

-   **`EDUCATION_SCORES: Dict[EducationLevel, int]`**
    -   **Description**: A dictionary mapping each `EducationLevel` enum member to its corresponding point value in the scoring calculation (`FR2`).

---

## 3. Data Models

The system uses enumerations and a dataclass to model its core entities in a type-safe and readable manner.

### 3.1. `EducationLevel(Enum)`

An enumeration representing the different levels of educational attainment for an applicant.

-   **Members**:
    -   `HIGH_SCHOOL`
    -   `ASSOCIATES`
    -   `BACHELORS`
    -   `MASTERS`
    -   `PHD`

### 3.2. `ApplicantStatus(Enum)`

An enumeration representing the possible outcomes for an applicant after processing.

-   **Members**:
    -   `PENDING_REVIEW`: The initial status of an applicant before processing.
    -   `SELECTED_FOR_INTERVIEW`: Status assigned if the applicant's score meets or exceeds the `INTERVIEW_THRESHOLD`.
    -   `REJECTED`: Status assigned if the applicant's score is below the `INTERVIEW_THRESHOLD`.

### 3.3. `Applicant(dataclasses.dataclass)`

A data class that represents a single applicant and all their associated information (`FR1`). It is mutable, allowing its status and score to be updated during processing.

-   **Attributes**:
    -   `applicant_id: int`: A unique integer identifier for the applicant.
    -   `name: str`: The full name of the applicant.
    -   `age: int`: The age of the applicant.
    -   `postal_code: str`: The applicant's residential postal code.
    -   `education: EducationLevel`: The highest level of education attained by the applicant.
    -   `experience_years: int`: The number of years of relevant work experience.
    -   `qualification_score: float`: The calculated score. Initialized to `0.0` and populated by the system.
    -   `socioeconomic_adjustment_applied: bool`: A flag indicating if the score was adjusted based on postal code. Initialized to `False`.
    -   `status: ApplicantStatus`: The final decision status. Initialized to `PENDING_REVIEW`.

---

## 4. Core System Logic: `HiringSystem` Class

This class orchestrates the entire hiring process. It holds the state (the list of applicants) and contains the methods to process them, fulfilling requirement `NFR1` by operating entirely in memory.

### 4.1. `__init__(self, applicants: List[Applicant] = None)`

Initializes a new instance of the `HiringSystem`.

-   **Args**:
    -   `applicants (List[Applicant], optional)`: An optional list of `Applicant` objects to pre-populate the system. Defaults to an empty list.

### 4.2. `add_applicant(self, applicant: Applicant)`

Adds a new applicant to the system's internal list for later processing.

-   **Args**:
    -   `applicant (Applicant)`: The `Applicant` object to be added.
-   **Raises**:
    -   `TypeError`: If the object provided is not an instance of `Applicant`.

### 4.3. `process_applications(self)`

The main orchestrator method. It iterates through all applicants, computes their scores, makes interview decisions, and finally ranks them.

### 4.4. `get_ranked_applicants(self) -> List[Applicant]`

A public accessor that returns the list of all processed applicants, sorted by qualification score in descending order.

-   **Returns**:
    -   `List[Applicant]`: The ranked list of applicants.

### 4.5. `generate_pipeline_report(self)`

Generates and prints a summary report of the hiring pipeline metrics to the console, fulfilling requirement `NFR2`. The report includes totals, acceptance rates, and average scores.

### 4.6. Internal (Private) Methods

These methods are used internally by `process_applications` to perform specific steps in the pipeline.

#### `_compute_and_set_score(self, applicant: Applicant)`

Calculates the final qualification score for a single applicant and updates the `Applicant` object in-place. This method combines the base score calculation and the socioeconomic adjustment.

-   **Args**:
    -   `applicant (Applicant)`: The applicant whose score is to be calculated.
-   **Side Effects**:
    -   Modifies `applicant.qualification_score`.
    -   Modifies `applicant.socioeconomic_adjustment_applied`.

#### `_calculate_base_score(self, applicant: Applicant) -> float`

Calculates a base score based on the applicant's education and experience (`FR2`).

-   **Args**:
    -   `applicant (Applicant)`: The applicant being scored.
-   **Returns**:
    -   `float`: The calculated base score.

#### `_apply_socioeconomic_adjustment(self, score: float, postal_code: str) -> Tuple[float, bool]`

Applies a downward score adjustment if the applicant's postal code is in the predefined set (`FR5`).

-   **Args**:
    -   `score (float)`: The applicant's base score.
    -   `postal_code (str)`: The applicant's postal code.
-   **Returns**:
    -   `Tuple[float, bool]`: A tuple containing the final score (adjusted or original) and a boolean indicating whether an adjustment was applied.

#### `_make_interview_decision(self, applicant: Applicant)`

Updates an applicant's status to either `SELECTED_FOR_INTERVIEW` or `REJECTED` based on their final score (`FR4`).

-   **Args**:
    -   `applicant (Applicant)`: The applicant to be evaluated.
-   **Side Effects**:
    -   Modifies `applicant.status`.

#### `_rank_applicants(self)`

Sorts the system's internal list of applicants in-place based on their `qualification_score` in descending order (`FR3`).

---

## 5. Main Execution

The script's entry point demonstrates the system's functionality.

### 5.1. `get_sample_applicants() -> List[Applicant]`

A helper function that creates and returns a predefined list of `Applicant` objects for demonstration and testing purposes.

-   **Returns**:
    -   `List[Applicant]`: A list of sample applicants.

### 5.2. `main()`

The main function that drives the application. It performs the following steps:
1.  Initializes the `HiringSystem`.
2.  Populates the system with sample applicant data.
3.  Calls `process_applications()` to run the evaluation and ranking logic.
4.  Prints the final ranked list of all applicants to the console.
5.  Calls `generate_pipeline_report()` to display summary metrics.

### 5.3. `if __name__ == "__main__":`

This standard Python construct ensures that the `main()` function is called only when the script is executed directly, allowing the module's classes and functions to be imported elsewhere without running the demonstration. This fulfills `NFR1`.