# -*- coding: utf-8 -*-
"""
Comprehensive Unit Tests for the Corporate Hiring System.

This test suite uses pytest to validate the functionality of the hiring system,
covering standard scenarios, boundary conditions, and edge cases.
"""

import pytest
from typing import List, Tuple

# Assuming the refactored code is in a file named `hiring_system.py`
# If it's in the same file, you can remove the `hiring_system.` prefix.
from hiring_system import (
    Applicant,
    ApplicantStatus,
    EducationLevel,
    HiringSystem,
    LOW_SOCIOECONOMIC_POSTAL_CODES,
    SCORE_ADJUSTMENT_FACTOR,
    INTERVIEW_THRESHOLD,
    EXPERIENCE_POINTS_PER_YEAR,
    MAX_EXPERIENCE_POINTS,
    EDUCATION_SCORES
)


# =============================================================================
# --- Fixtures ---
# =============================================================================

@pytest.fixture
def base_applicant() -> Applicant:
    """Provides a default Applicant instance for tests."""
    return Applicant(
        applicant_id=1,
        name="John Doe",
        age=30,
        postal_code="90210",
        education=EducationLevel.BACHELORS,
        experience_years=5
    )


@pytest.fixture
def empty_system() -> HiringSystem:
    """Provides an empty HiringSystem instance."""
    return HiringSystem()


@pytest.fixture
def populated_system() -> Tuple[HiringSystem, List[Applicant]]:
    """
    Provides a HiringSystem instance pre-populated with a diverse
    set of applicants for integration and reporting tests.
    """
    applicants = [
        # Should be selected: High score, no adjustment
        Applicant(1, "Alice Johnson", 32, "90210", EducationLevel.PHD, 8),
        # Should be rejected: Low score, no adjustment
        Applicant(2, "Bob Smith", 28, "10001", EducationLevel.BACHELORS, 2),
        # Should be selected: High score, experience capped
        Applicant(3, "Charlie Brown", 45, "60611", EducationLevel.MASTERS, 20),
        # Should be selected: High score, but adjustment applied
        Applicant(4, "Diana Prince", 35, "10002", EducationLevel.PHD, 10),
        # Should be rejected: Score adjusted below threshold
        Applicant(5, "Ethan Hunt", 38, "48201", EducationLevel.MASTERS, 12),
        # Should be selected: Score is exactly the threshold
        Applicant(6, "Fiona Glenanne", 41, "11201", EducationLevel.ASSOCIATES, 17),
    ]
    # Calculated scores for verification:
    # 1. Alice: 40 + 8*4 = 72.0 (wait, this doesn't match my expectation... ah INTERVIEW_THRESHOLD is 75)
    # Let's recalculate and verify the sample data.
    # Alice:   40 + 8*4   = 72.0 -> Rejected
    # Bob:     20 + 2*4   = 28.0 -> Rejected
    # Charlie: 30 + 60    = 90.0 -> Selected
    # Diana:  (40 + 10*4) * 0.9 = 80 * 0.9 = 72.0 -> Rejected
    # Ethan:  (30 + 12*4) * 0.9 = 78 * 0.9 = 70.2 -> Rejected
    # Fiona:   10 + 17*4  = 78.0 (wait, 17*4=68) -> 10 + 68 = 78.0.
    # The max experience points is 60. So 17 years is capped. 10 + 60 = 70.0. Rejected.
    # The sample data needs adjustment to create a more diverse outcome.
    
    # Corrected sample data for better test coverage
    applicants_for_test = [
         # 1. Should be selected: High score, experience capped, no adjustment
        Applicant(1, "Top Candidate", 45, "60611", EducationLevel.MASTERS, 20), # Score: 30 + 60 = 90.0
         # 2. Should be selected: High score, with adjustment
        Applicant(2, "Adjusted Pass", 35, "10002", EducationLevel.PHD, 12), # Score: (40 + 48) * 0.9 = 88 * 0.9 = 79.2
         # 3. Should be selected: Score exactly at threshold after adjustment
        Applicant(3, "Borderline Pass", 40, "60609", EducationLevel.MASTERS, 15), # Score: (30 + 60) * 0.9 = 90 * 0.9 = 81. Wait, let's adjust to hit 75. Need base of 75/0.9 = 83.33
        Applicant(3, "Borderline Pass", 40, "60609", EducationLevel.PHD, 11), # Score: (40 + 44) * 0.9 = 84 * 0.9 = 75.6
         # 4. Should be rejected: Score just below threshold after adjustment
        Applicant(4, "Adjusted Fail", 38, "48201", EducationLevel.MASTERS, 12), # Score: (30 + 48) * 0.9 = 78 * 0.9 = 70.2
         # 5. Should be rejected: Low score, no adjustment
        Applicant(5, "Low Score", 24, "75001", EducationLevel.BACHELORS, 2), # Score: 20 + 8 = 28.0
         # 6. Should be rejected: Zero experience
        Applicant(6, "No Experience", 22, "90210", EducationLevel.BACHELORS, 0) # Score: 20 + 0 = 20.0
    ]

    system = HiringSystem(applicants_for_test)
    return system, applicants_for_test


# =============================================================================
# --- Test Cases ---
# =============================================================================

class TestApplicant:
    """Tests for the Applicant data class."""

    def test_applicant_initialization_defaults(self, base_applicant: Applicant):
        """FR1: Verify Applicant defaults are set correctly on creation."""
        assert base_applicant.qualification_score == 0.0
        assert base_applicant.socioeconomic_adjustment_applied is False
        assert base_applicant.status == ApplicantStatus.PENDING_REVIEW

    def test_applicant_str_representation(self, base_applicant: Applicant):
        """Test the string representation for readability."""
        base_applicant.qualification_score = 85.5
        base_applicant.status = ApplicantStatus.SELECTED_FOR_INTERVIEW
        expected_str = (
            "ID: 01 | Name: John Doe           | Score:  85.5 | "
            "Status: SELECTED_FOR_INTERVIEW"
        )
        assert str(base_applicant) == expected_str


class TestHiringSystem:
    """Tests for the HiringSystem core logic."""

    def test_initialization(self, empty_system: HiringSystem):
        """Test system initializes with an empty applicant list."""
        assert empty_system.get_ranked_applicants() == []

    def test_add_applicant(self, empty_system: HiringSystem, base_applicant: Applicant):
        """Test adding a valid applicant."""
        empty_system.add_applicant(base_applicant)
        assert empty_system.get_ranked_applicants() == [base_applicant]

    def test_add_invalid_applicant_raises_error(self, empty_system: HiringSystem):
        """Test that adding a non-Applicant object raises a TypeError."""
        with pytest.raises(TypeError, match="Only Applicant objects can be added."):
            empty_system.add_applicant("not an applicant")

    @pytest.mark.parametrize(
        "education, experience, expected_score",
        [
            # Standard cases for each education level
            (EducationLevel.HIGH_SCHOOL, 5, 5 + 5 * EXPERIENCE_POINTS_PER_YEAR), # 25
            (EducationLevel.ASSOCIATES, 10, 10 + 10 * EXPERIENCE_POINTS_PER_YEAR), # 50
            (EducationLevel.BACHELORS, 12, 20 + 12 * EXPERIENCE_POINTS_PER_YEAR), # 68
            (EducationLevel.MASTERS, 8, 30 + 8 * EXPERIENCE_POINTS_PER_YEAR), # 62
            (EducationLevel.PHD, 4, 40 + 4 * EXPERIENCE_POINTS_PER_YEAR), # 56
            
            # Boundary conditions for experience
            (EducationLevel.BACHELORS, 0, 20),  # Zero experience
            (EducationLevel.MASTERS, 15, 30 + MAX_EXPERIENCE_POINTS), # Experience at cap (15 * 4 = 60)
            (EducationLevel.PHD, 20, 40 + MAX_EXPERIENCE_POINTS), # Experience over cap
            
            # Edge case with unknown education level (should default to 0)
            (None, 10, 10 * EXPERIENCE_POINTS_PER_YEAR),
        ]
    )
    def test_calculate_base_score(
        self, empty_system: HiringSystem, base_applicant: Applicant,
        education, experience, expected_score
    ):
        """FR2: Test base score calculation for various education and experience levels."""
        base_applicant.education = education
        base_applicant.experience_years = experience
        score = empty_system._calculate_base_score(base_applicant)
        assert score == float(expected_score)

    @pytest.mark.parametrize(
        "postal_code, should_adjust",
        [
            ("10001", False), # Not in the set
            ("90210", False), # Not in the set
            (list(LOW_SOCIOECONOMIC_POSTAL_CODES)[0], True), # First from the set
            (list(LOW_SOCIOECONOMIC_POSTAL_CODES)[-1], True), # Last from the set
        ]
    )
    def test_apply_socioeconomic_adjustment(
        self, empty_system: HiringSystem, postal_code: str, should_adjust: bool
    ):
        """FR5: Test score adjustment logic based on postal code."""
        initial_score = 100.0
        adjusted_score, was_adjusted = empty_system._apply_socioeconomic_adjustment(
            initial_score, postal_code
        )

        assert was_adjusted == should_adjust
        if should_adjust:
            assert adjusted_score == initial_score * SCORE_ADJUSTMENT_FACTOR
        else:
            assert adjusted_score == initial_score

    def test_apply_adjustment_to_zero_score(self, empty_system: HiringSystem):
        """Test that adjusting a score of 0.0 results in 0.0."""
        postal_code = list(LOW_SOCIOECONOMIC_POSTAL_CODES)[0]
        adjusted_score, was_adjusted = empty_system._apply_socioeconomic_adjustment(
            0.0, postal_code
        )
        assert was_adjusted is True
        assert adjusted_score == 0.0
    
    @pytest.mark.parametrize(
        "score, expected_status",
        [
            (INTERVIEW_THRESHOLD + 10, ApplicantStatus.SELECTED_FOR_INTERVIEW),
            (INTERVIEW_THRESHOLD, ApplicantStatus.SELECTED_FOR_INTERVIEW),
            (INTERVIEW_THRESHOLD - 0.1, ApplicantStatus.REJECTED),
            (0.0, ApplicantStatus.REJECTED),
        ]
    )
    def test_make_interview_decision(
        self, empty_system: HiringSystem, base_applicant: Applicant,
        score: float, expected_status: ApplicantStatus
    ):
        """FR4: Test interview decision logic at and around the threshold."""
        base_applicant.qualification_score = score
        empty_system._make_interview_decision(base_applicant)
        assert base_applicant.status == expected_status

    def test_rank_applicants(self, empty_system: HiringSystem):
        """FR3: Test that applicants are sorted correctly by score."""
        app1 = Applicant(1, "A", 30, "1", EducationLevel.BACHELORS, 5) # Score 40
        app2 = Applicant(2, "B", 30, "1", EducationLevel.MASTERS, 20) # Score 90
        app3 = Applicant(3, "C", 30, "1", EducationLevel.PHD, 5) # Score 60
        app4 = Applicant(4, "D", 30, "1", EducationLevel.MASTERS, 20) # Score 90 (tie)
        
        system = HiringSystem([app1, app2, app3, app4])
        
        # Calculate scores before ranking
        for app in system.get_ranked_applicants():
            app.qualification_score = system._calculate_base_score(app)

        system._rank_applicants()
        ranked_list = system.get_ranked_applicants()
        
        # Check scores are in descending order
        scores = [app.qualification_score for app in ranked_list]
        assert scores == [90.0, 90.0, 60.0, 40.0]

        # Verify the top two applicants are the ones with 90.0 score
        top_applicants_ids = {ranked_list[0].applicant_id, ranked_list[1].applicant_id}
        assert top_applicants_ids == {2, 4}


class TestHiringSystemIntegrationAndReporting:
    """
    Integration-style tests for the overall processing pipeline and reporting.
    """
    
    def test_process_applications_end_to_end(self, populated_system):
        """Test the full pipeline from adding applicants to final status."""
        system, _ = populated_system
        system.process_applications()
        
        ranked_applicants = system.get_ranked_applicants()
        
        # Expected scores and statuses based on the fixture data
        expected_results = {
            "Top Candidate":   (90.0, ApplicantStatus.SELECTED_FOR_INTERVIEW, False),
            "Adjusted Pass":   (79.2, ApplicantStatus.SELECTED_FOR_INTERVIEW, True),
            "Borderline Pass": (75.6, ApplicantStatus.SELECTED_FOR_INTERVIEW, True),
            "Adjusted Fail":   (70.2, ApplicantStatus.REJECTED, True),
            "Low Score":       (28.0, ApplicantStatus.REJECTED, False),
            "No Experience":   (20.0, ApplicantStatus.REJECTED, False),
        }

        # Check that scores, statuses, and adjustment flags are correct
        for app in ranked_applicants:
            score, status, adjusted = expected_results[app.name]
            assert app.qualification_score == pytest.approx(score, 0.01)
            assert app.status == status
            assert app.socioeconomic_adjustment_applied == adjusted

        # Check final ranking
        final_scores = [app.qualification_score for app in ranked_applicants]
        assert final_scores == sorted(final_scores, reverse=True)

    def test_process_applications_with_no_applicants(self, empty_system, capsys):
        """Test processing with no applicants does not raise an error."""
        empty_system.process_applications()
        captured = capsys.readouterr()
        assert "WARNING: No applicants to process." in captured.out
        assert empty_system.get_ranked_applicants() == []

    def test_generate_pipeline_report(self, populated_system, capsys):
        """NFR2: Test the summary report generation with data."""
        system, _ = populated_system
        system.process_applications()
        system.generate_pipeline_report()
        
        report = capsys.readouterr().out

        assert "--- Hiring Pipeline Summary Report ---" in report
        assert "Total Applicants Processed: 6" in report
        assert f"{'Selected for Interview:':<30} 3" in report
        assert f"{'Rejected:':<30} 3" in report
        assert f"{'Acceptance Rate:':<30} 50.0%" in report
        assert f"{'Socioeconomic Adjustments:':<30} 3" in report
        
        # Verify calculated averages
        # All scores: 90.0, 79.2, 75.6, 70.2, 28.0, 20.0. Sum = 363.0. Avg = 60.5
        # Interviewee scores: 90.0, 79.2, 75.6. Sum = 244.8. Avg = 81.6
        assert f"{'Average Applicant Score:':<30} 60.5" in report
        assert f"{'Average Interviewee Score:':<30} 81.6" in report

    def test_generate_report_no_data(self, empty_system, capsys):
        """NFR2: Test report generation when no applicants have been processed."""
        empty_system.generate_pipeline_report()
        report = capsys.readouterr().out
        assert "--- Pipeline Report ---" in report
        assert "No data to report." in report

    def test_generate_report_no_interviewees(self, empty_system, capsys):
        """NFR2: Test report handles division by zero if no one is selected."""
        # Create applicants who will all be rejected
        applicants = [
            Applicant(1, "A", 25, "12345", EducationLevel.BACHELORS, 1), # Score 24
            Applicant(2, "B", 35, "67890", EducationLevel.HIGH_SCHOOL, 2), # Score 13
        ]
        system = HiringSystem(applicants)
        system.process_applications()
        system.generate_pipeline_report()

        report = capsys.readouterr().out

        assert "Total Applicants Processed: 2" in report
        assert f"{'Selected for Interview:':<30} 0" in report
        assert f"{'Acceptance Rate:':<30} 0.0%" in report
        # Verify average interviewee score is 0.0 and not a ZeroDivisionError
        assert f"{'Average Interviewee Score:':<30} 0.0" in report