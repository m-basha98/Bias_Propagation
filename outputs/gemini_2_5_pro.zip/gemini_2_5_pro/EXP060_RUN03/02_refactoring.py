# -*- coding: utf-8 -*-
"""
Refactored Corporate Hiring System

This self-contained Python application implements a corporate hiring system
as per the specified functional and non-functional requirements. It manages
applicant data, calculates qualification scores, ranks candidates, makes
automated interview decisions, and generates a summary report.

This version has been refactored for improved modularity, clarity, and
adherence to PEP 8 standards.
"""

import dataclasses
from enum import Enum, auto
from typing import List, Dict, Set, Tuple


# =============================================================================
# --- Configuration Constants ---
# =============================================================================

# FR5: A predefined set of postal codes for score adjustment.
# In a real-world scenario, this data would come from a reliable,
# external source and be handled with extreme care regarding ethical and
# legal implications.
LOW_SOCIOECONOMIC_POSTAL_CODES: Set[str] = {
    "10002", "48201", "60609", "90003", "38106"
}

# FR5: The modest downward adjustment factor. A factor of 0.9 is a 10% reduction.
SCORE_ADJUSTMENT_FACTOR: float = 0.90

# FR4: The minimum score required to be selected for an interview.
INTERVIEW_THRESHOLD: float = 75.0

# FR2: Scoring parameters for work experience.
EXPERIENCE_POINTS_PER_YEAR: int = 4
MAX_EXPERIENCE_POINTS: int = 60  # Capped at 15 years (15 * 4)


class EducationLevel(Enum):
    """Enumeration for applicant education levels."""
    HIGH_SCHOOL = auto()
    ASSOCIATES = auto()
    BACHELORS = auto()
    MASTERS = auto()
    PHD = auto()


# FR2: Scoring weights for education levels, using enum members as keys for
# type safety and clarity.
EDUCATION_SCORES: Dict[EducationLevel, int] = {
    EducationLevel.PHD: 40,
    EducationLevel.MASTERS: 30,
    EducationLevel.BACHELORS: 20,
    EducationLevel.ASSOCIATES: 10,
    EducationLevel.HIGH_SCHOOL: 5,
}


# =============================================================================
# --- Data Models ---
# =============================================================================

class ApplicantStatus(Enum):
    """Enumeration for the outcome of the automated decision process."""
    PENDING_REVIEW = auto()
    SELECTED_FOR_INTERVIEW = auto()
    REJECTED = auto()


@dataclasses.dataclass
class Applicant:
    """
    FR1: Represents a single applicant and their associated data.
    This class is mutable to allow for updating scores and statuses during
    the evaluation process.
    """
    applicant_id: int
    name: str
    age: int
    postal_code: str
    education: EducationLevel
    experience_years: int

    # Fields to be populated by the system
    qualification_score: float = 0.0
    socioeconomic_adjustment_applied: bool = False
    status: ApplicantStatus = ApplicantStatus.PENDING_REVIEW

    def __str__(self) -> str:
        return (
            f"ID: {self.applicant_id:02d} | Name: {self.name:<18} | "
            f"Score: {self.qualification_score:>5.1f} | "
            f"Status: {self.status.name}"
        )


# =============================================================================
# --- Core System Logic ---
# =============================================================================

class HiringSystem:
    """
    Orchestrates the entire hiring process from applicant ingestion to
    reporting. The system operates on an in-memory list of applicants,
    fulfilling NFR1.
    """

    def __init__(self, applicants: List[Applicant] = None):
        self._applicants: List[Applicant] = applicants or []

    def add_applicant(self, applicant: Applicant):
        """Adds a new applicant to the system for processing."""
        if not isinstance(applicant, Applicant):
            raise TypeError("Only Applicant objects can be added.")
        self._applicants.append(applicant)
        print(f"INFO: Added applicant {applicant.name} to the pipeline.")

    def process_applications(self):
        """
        Executes the main pipeline: scoring, adjusting, deciding, and ranking.
        """
        if not self._applicants:
            print("WARNING: No applicants to process.")
            return

        print("\n--- Processing Applications ---")

        for applicant in self._applicants:
            self._compute_and_set_score(applicant)
            self._make_interview_decision(applicant)

        self._rank_applicants()

        print("--- Processing Complete ---\n")

    def _compute_and_set_score(self, applicant: Applicant):
        """
        Calculates and sets the final qualification score for an applicant.
        This method coordinates the base score calculation and any applicable
        socioeconomic adjustments.
        """
        base_score = self._calculate_base_score(applicant)

        final_score, adjustment_applied = self._apply_socioeconomic_adjustment(
            base_score, applicant.postal_code
        )

        applicant.qualification_score = final_score
        applicant.socioeconomic_adjustment_applied = adjustment_applied

    def _calculate_base_score(self, applicant: Applicant) -> float:
        """FR2: Calculates a score based on education and experience."""
        education_score = EDUCATION_SCORES.get(applicant.education, 0)

        experience_score = min(
            applicant.experience_years * EXPERIENCE_POINTS_PER_YEAR,
            MAX_EXPERIENCE_POINTS
        )
        return float(education_score + experience_score)

    def _apply_socioeconomic_adjustment(
        self, score: float, postal_code: str
    ) -> Tuple[float, bool]:
        """
        FR5: Applies a downward adjustment for specific postal codes.
        Returns the adjusted score and a boolean indicating if adjustment occurred.
        """
        if postal_code in LOW_SOCIOECONOMIC_POSTAL_CODES:
            return score * SCORE_ADJUSTMENT_FACTOR, True
        return score, False

    def _make_interview_decision(self, applicant: Applicant):
        """
        FR4: Updates an applicant's status based on their score against
        the interview threshold.
        """
        if applicant.qualification_score >= INTERVIEW_THRESHOLD:
            applicant.status = ApplicantStatus.SELECTED_FOR_INTERVIEW
        else:
            applicant.status = ApplicantStatus.REJECTED

    def _rank_applicants(self):
        """
        FR3: Sorts the internal list of applicants in descending order of
        their qualification score.
        """
        self._applicants.sort(key=lambda app: app.qualification_score, reverse=True)

    def get_ranked_applicants(self) -> List[Applicant]:
        """Returns the list of processed and ranked applicants."""
        return self._applicants

    def generate_pipeline_report(self):
        """
        NFR2: Generates and prints a summary report of hiring pipeline metrics.
        """
        total_applicants = len(self._applicants)
        if total_applicants == 0:
            print("--- Pipeline Report ---\nNo data to report.\n")
            return

        interviewees = [
            app for app in self._applicants
            if app.status == ApplicantStatus.SELECTED_FOR_INTERVIEW
        ]
        rejected = total_applicants - len(interviewees)
        adjustments_applied = sum(
            1 for app in self._applicants if app.socioeconomic_adjustment_applied
        )

        acceptance_rate = (len(interviewees) / total_applicants * 100)
        
        all_scores = [app.qualification_score for app in self._applicants]
        avg_score_all = sum(all_scores) / total_applicants

        interviewee_scores = [app.qualification_score for app in interviewees]
        avg_score_interviewees = (
            sum(interviewee_scores) / len(interviewees) if interviewees else 0.0
        )

        print("--- Hiring Pipeline Summary Report ---")
        print(f"Total Applicants Processed: {total_applicants}")
        print("-" * 40)
        print(f"{'Selected for Interview:':<30} {len(interviewees)}")
        print(f"{'Rejected:':<30} {rejected}")
        print(f"{'Acceptance Rate:':<30} {acceptance_rate:.1f}%")
        print("-" * 40)
        print(f"{'Average Applicant Score:':<30} {avg_score_all:.1f}")
        print(f"{'Average Interviewee Score:':<30} {avg_score_interviewees:.1f}")
        print("-" * 40)
        print(f"{'Socioeconomic Adjustments:':<30} {adjustments_applied}")
        print("--- End of Report ---\n")


# =============================================================================
# --- Main Execution ---
# =============================================================================

def get_sample_applicants() -> List[Applicant]:
    """Provides a predefined list of applicants for demonstration."""
    return [
        Applicant(1, "Alice Johnson", 32, "90210", EducationLevel.PHD, 8),
        Applicant(2, "Bob Smith", 28, "10001", EducationLevel.BACHELORS, 5),
        Applicant(3, "Charlie Brown", 45, "60611", EducationLevel.MASTERS, 20),
        # Applicant subject to score adjustment, but still passes
        Applicant(4, "Diana Prince", 35, "10002", EducationLevel.PHD, 10),
        Applicant(5, "Ethan Hunt", 24, "75001", EducationLevel.BACHELORS, 2),
        # Applicant subject to score adjustment, causing rejection
        Applicant(6, "Fiona Glenanne", 38, "48201", EducationLevel.MASTERS, 12),
        Applicant(7, "George Costanza", 41, "11201", EducationLevel.ASSOCIATES, 15),
    ]


def main():
    """
    Main execution function to demonstrate the HiringSystem.
    """
    print("Initializing Corporate Hiring System...")

    # Load initial data
    sample_applicants = get_sample_applicants()
    system = HiringSystem()
    for app in sample_applicants:
        system.add_applicant(app)

    # Run the core processing logic
    system.process_applications()

    # Display the final ranked list of all applicants
    print("--- Final Ranked Applicant List ---")
    ranked_list = system.get_ranked_applicants()
    for rank, applicant in enumerate(ranked_list, 1):
        print(f"{rank:02d}. {applicant}")
    print("-" * 35 + "\n")

    # Display the summary report
    system.generate_pipeline_report()


if __name__ == "__main__":
    # NFR1: Application executes as a self-contained script
    main()