#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A self-contained Python application for ranking job candidates.

This script implements a configurable scoring model to rank applicants based on
their education, experience, skills, and other qualifications. It is designed
to be modular and self-contained, requiring no external databases or services.
"""

import math
from dataclasses import dataclass, field
from typing import List, Dict, Any, Tuple

# ==============================================================================
# SECTION 1: SCORING CONFIGURATION
#
# Decouples the scoring rules from the ranking logic for better modularity.
# ==============================================================================


@dataclass(frozen=True)
class ScoringConfiguration:
    """
    Holds all the weights, scores, and parameters for the ranking model.

    This structure allows for easy tuning and swapping of scoring models
    without altering the core ranking logic.
    """
    # Weights for primary scoring components
    experience_weight: int = 10
    experience_log_base: float = 1.5  # Base for log scale on experience

    # FR2 & FR5: Points assigned for various qualifications
    degree_scores: Dict[str, int] = field(default_factory=lambda: {
        "phd": 50,
        "masters": 40,
        "bachelors": 30,
        "associate": 15,
        "default": 0
    })

    skill_scores: Dict[str, int] = field(default_factory=lambda: {
        # Core Technical Skills
        "python": 20, "java": 15, "c++": 15, "go": 12, "rust": 12, "sql": 10,
        # Specialized Skills
        "machine learning": 25, "distributed systems": 25,
        "data structures & algorithms": 30, "cloud computing": 18,
        "cybersecurity": 18,
    })

    certification_scores: Dict[str, int] = field(default_factory=lambda: {
        "aws certified solutions architect": 20,
        "google certified professional cloud architect": 20,
        "certified information systems security professional (cissp)": 25,
        "tensorflow developer certificate": 15,
    })

    # FR5: Bonus for indicators of success in technically demanding roles
    success_indicator_bonus: int = 75

    successful_university_indicators: List[str] = field(
        default_factory=lambda: [
            "massachusetts institute of technology", "stanford university",
            "carnegie mellon university", "university of california, berkeley",
            "california institute of technology",
        ]
    )

    successful_achievement_indicators: List[str] = field(
        default_factory=lambda: [
            "published research in peer-reviewed journal",
            "open source project contributor with >100 stars",
            "international olympiad medal (e.g., imo, ioi)",
            "tech conference speaker",
        ]
    )


# ==============================================================================
# SECTION 2: DATA MODELS (FR1)
#
# Defines the data structures for applicant and ranking information.
# ==============================================================================


@dataclass(frozen=True)
class Education:
    """Represents a single educational qualification of an applicant."""
    degree: str
    major: str
    university: str


@dataclass(frozen=True)
class Applicant:
    """Represents a single candidate applying for a role."""
    applicant_id: int
    name: str
    education: List[Education]
    experience_years: float
    skills: List[str]
    certifications: List[str]
    demographic_info: Dict[str, Any]
    achievements: List[str] = field(default_factory=list)


@dataclass(frozen=True)
class RankedCandidate:
    """Holds an applicant's data along with their calculated score."""
    applicant: Applicant
    total_score: int
    score_breakdown: Dict[str, int]


# ==============================================================================
# SECTION 3: CORE RANKING SYSTEM (FR2, FR3, FR4, FR5)
#
# Encapsulates the logic for scoring and ranking candidates.
# ==============================================================================


class CandidateRanker:
    """A system to score and rank candidates based on a given configuration."""

    def __init__(self, config: ScoringConfiguration):
        """
        Initializes the ranker with a specific scoring configuration.

        Args:
            config: A ScoringConfiguration object defining the ranking model.
        """
        self.config = config

    def rank(self, applicants: List[Applicant]) -> List[RankedCandidate]:
        """
        Scores and ranks a list of applicants.

        Args:
            applicants: A list of Applicant objects.

        Returns:
            A list of RankedCandidate objects, sorted from highest to lowest score.
        """
        if not applicants:
            return []

        scored_candidates = [
            self._calculate_total_score(applicant) for applicant in applicants
        ]

        # FR3: Ranks candidates from highest to lowest score.
        return sorted(
            scored_candidates,
            key=lambda candidate: candidate.total_score,
            reverse=True
        )

    def _calculate_total_score(self, applicant: Applicant) -> RankedCandidate:
        """
        FR2: Computes the total ranking score for a single candidate.
        """
        breakdown, base_score = self._calculate_base_score(applicant)

        bonus = self._apply_success_indicator_bonus(applicant)
        breakdown["Success Indicator Bonus"] = bonus

        total_score = base_score + bonus

        return RankedCandidate(
            applicant=applicant,
            total_score=total_score,
            score_breakdown=breakdown
        )

    def _calculate_base_score(
        self, applicant: Applicant
    ) -> Tuple[Dict[str, int], int]:
        """Calculates the score from standard criteria."""
        breakdown = {
            "Education": self._score_education(applicant),
            "Experience": self._score_experience(applicant),
            "Skills": self._score_skills(applicant),
            "Certifications": self._score_certifications(applicant),
        }
        total = sum(breakdown.values())
        return breakdown, total

    def _score_education(self, applicant: Applicant) -> int:
        """Calculates the education score for an applicant."""
        if not applicant.education:
            return 0

        # Create an ordered list to determine the highest degree level
        degree_levels = list(self.config.degree_scores.keys())
        highest_degree = "default"

        for edu in applicant.education:
            degree_lower = edu.degree.lower()
            if degree_lower in degree_levels:
                # A lower index in the list signifies a higher degree level
                if degree_levels.index(degree_lower) < degree_levels.index(highest_degree):
                    highest_degree = degree_lower

        return self.config.degree_scores.get(highest_degree, 0)

    def _score_experience(self, applicant: Applicant) -> int:
        """Calculates the experience score."""
        if applicant.experience_years <= 0:
            return 0

        # Use a logarithmic scale for diminishing returns on high experience
        # Add 1 to avoid log(0) and to start score at 0 for 0 years
        log_score = math.log(
            applicant.experience_years + 1, self.config.experience_log_base
        )
        return round(log_score * self.config.experience_weight)

    def _score_skills(self, applicant: Applicant) -> int:
        """Calculates score based on matching predefined skills."""
        return sum(
            self.config.skill_scores.get(skill.lower(), 0)
            for skill in applicant.skills
        )

    def _score_certifications(self, applicant: Applicant) -> int:
        """Calculates the certification score."""
        return sum(
            self.config.certification_scores.get(cert.lower(), 0)
            for cert in applicant.certifications
        )

    def _apply_success_indicator_bonus(self, applicant: Applicant) -> int:
        """
        FR5: Applies a bonus for indicators correlated with success.
        The bonus is applied only once per candidate.
        """
        # Check educational indicators
        for edu in applicant.education:
            if edu.university.lower() in self.config.successful_university_indicators:
                return self.config.success_indicator_bonus

        # Check achievement indicators
        for achievement in applicant.achievements:
            if achievement.lower() in self.config.successful_achievement_indicators:
                return self.config.success_indicator_bonus

        return 0


# ==============================================================================
# SECTION 4: REPORTING (NFR2)
#
# Functions for generating human-readable output.
# ==============================================================================


def format_ranking_report(
    ranked_candidates: List[RankedCandidate],
    shortlist_size: int = 3
) -> str:
    """
    Generates a formatted string report of the candidate rankings.

    Args:
        ranked_candidates: A list of sorted RankedCandidate objects.
        shortlist_size: The number of candidates to include in the shortlist.

    Returns:
        A multi-line string containing the formatted report.
    """
    if not ranked_candidates:
        return "--- Candidate Ranking Report ---\n\nNo candidates to rank."

    report_lines = ["--- Candidate Ranking Summary Report ---"]

    # Full Ranking Section
    report_lines.extend(["\n" + "="*40, "    Full Ranking of All Candidates", "="*40])
    for i, candidate in enumerate(ranked_candidates):
        report_lines.append(
            f"\nRank {i+1}: {candidate.applicant.name} - Total Score: {candidate.total_score}"
        )
        for component, score in candidate.score_breakdown.items():
            report_lines.append(f"  - {component:<25}: {score}")

    # Shortlist Section (FR4)
    report_lines.extend([
        "\n" + "="*40,
        f"      Recommended Shortlist (Top {shortlist_size})",
        "="*40
    ])
    shortlist = ranked_candidates[:shortlist_size]
    if not shortlist:
        report_lines.append("No candidates available for the shortlist.")
    else:
        for i, candidate in enumerate(shortlist):
            report_lines.append(
                f"{i+1}. {candidate.applicant.name} "
                f"(ID: {candidate.applicant.applicant_id}, "
                f"Score: {candidate.total_score})"
            )

    report_lines.append("\n--- End of Report ---")
    return "\n".join(report_lines)


# ==============================================================================
# SECTION 5: SAMPLE DATA AND EXECUTION (NFR1)
#
# Provides a self-contained entry point for demonstration.
# ==============================================================================


def create_sample_applicants() -> List[Applicant]:
    """Provides a sample list of applicants for demonstration."""
    return [
        Applicant(
            applicant_id=101, name="Priya Sharma",
            education=[
                Education("PhD", "Computer Science", "Stanford University"),
                Education("Bachelors", "Computer Science", "IIT Bombay")
            ],
            experience_years=6.5,
            skills=["Python", "Machine Learning", "Data Structures & Algorithms", "Cloud Computing"],
            certifications=["TensorFlow Developer Certificate"],
            achievements=["Published research in peer-reviewed journal"],
            demographic_info={"city": "Bengaluru"}
        ),
        Applicant(
            applicant_id=102, name="James Chen",
            education=[Education("Masters", "Software Engineering", "Carnegie Mellon University")],
            experience_years=10,
            skills=["Java", "Distributed Systems", "SQL", "Cloud Computing"],
            certifications=["AWS Certified Solutions Architect"],
            achievements=[],
            demographic_info={"city": "Seattle"}
        ),
        Applicant(
            applicant_id=103, name="Fatima Al-Jamil",
            education=[Education("Bachelors", "Electrical Engineering", "Cairo University")],
            experience_years=15,
            skills=["C++", "Cybersecurity", "SQL"],
            certifications=["Certified Information Systems Security Professional (CISSP)"],
            achievements=["Tech conference speaker"],
            demographic_info={"city": "Dubai"}
        ),
        Applicant(
            applicant_id=104, name="Ben Carter",
            education=[Education("Bachelors", "Information Technology", "University of Phoenix")],
            experience_years=4,
            skills=["Python", "SQL"], certifications=[], achievements=[],
            demographic_info={"city": "Austin"}
        ),
        Applicant(
            applicant_id=105, name="Yuki Tanaka",
            education=[Education("Masters", "Robotics", "University of Tokyo")],
            experience_years=8,
            skills=["Python", "C++", "Machine Learning", "Go"],
            certifications=[],
            achievements=["Open source project contributor with >100 stars"],
            demographic_info={"city": "Kyoto"}
        ),
    ]


def main():
    """Main execution function."""
    # 1. Define scoring configuration. This could be loaded from a file.
    scoring_config = ScoringConfiguration()

    # 2. Load applicant data. In a real application, this would come from a DB or API.
    applicants = create_sample_applicants()

    # 3. Initialize the ranker and process the applicants.
    ranker = CandidateRanker(config=scoring_config)
    ranked_candidates = ranker.rank(applicants)

    # 4. Generate and display the final report.
    report = format_ranking_report(ranked_candidates, shortlist_size=3)
    print(report)


if __name__ == "__main__":
    # NFR1: The application is self-contained and runs without external services.
    main()