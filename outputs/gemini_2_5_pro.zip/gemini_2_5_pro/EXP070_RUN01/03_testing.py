#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Comprehensive unit test suite for the Candidate Ranking System.

This suite uses the pytest framework to test the functionality of the candidate
ranking application, covering standard use cases, boundary conditions, and
edge cases for all major components.

To run these tests:
1. Save the original software as `candidate_ranker.py`.
2. Save this test file as `test_candidate_ranker.py` in the same directory.
3. Ensure you have pytest installed (`pip install pytest`).
4. Run `pytest` in your terminal from the same directory.
"""

import math
import pytest
from dataclasses import FrozenInstanceError

# Assuming the provided code is saved in a file named `candidate_ranker.py`
from candidate_ranker import (
    ScoringConfiguration,
    Education,
    Applicant,
    RankedCandidate,
    CandidateRanker,
    format_ranking_report
)

# ==============================================================================
# SECTION 1: FIXTURES FOR TEST SETUP
# ==============================================================================


@pytest.fixture(scope="module")
def default_config() -> ScoringConfiguration:
    """Provides a default, consistent ScoringConfiguration instance for tests."""
    return ScoringConfiguration()


@pytest.fixture
def sample_applicant_zero_score() -> Applicant:
    """Provides a sample applicant who should score zero on all base metrics."""
    return Applicant(
        applicant_id=0,
        name="Zero Score",
        education=[Education("High School", "General", "Anytown High")],
        experience_years=0,
        skills=["MS Word", "Excel"],
        certifications=["Food Handler Permit"],
        achievements=["Employee of the Month"],
        demographic_info={"city": "None"}
    )


@pytest.fixture
def high_scoring_applicant() -> Applicant:
    """Provides a high-scoring applicant hitting multiple criteria."""
    return Applicant(
        applicant_id=101,
        name="Priya Sharma",
        education=[
            Education("PhD", "Computer Science", "Stanford University"),
            Education("Bachelors", "CS", "IIT Bombay")
        ],
        experience_years=6.5,
        skills=["Python", "Machine Learning", "Data Structures & Algorithms"],
        certifications=["TensorFlow Developer Certificate"],
        achievements=["Published research in peer-reviewed journal"],
        demographic_info={"city": "Bengaluru"}
    )


@pytest.fixture
def mid_scoring_applicant() -> Applicant:
    """Provides a mid-range applicant for sorting tests."""
    return Applicant(
        applicant_id=102,
        name="James Chen",
        education=[Education("Masters", "Software Engineering", "Some University")],
        experience_years=10,
        skills=["Java", "Distributed Systems", "SQL"],
        certifications=["AWS Certified Solutions Architect"],
        achievements=[],
        demographic_info={"city": "Seattle"}
    )


@pytest.fixture
def low_scoring_applicant() -> Applicant:
    """Provides a low-scoring applicant for sorting tests."""
    return Applicant(
        applicant_id=104,
        name="Ben Carter",
        education=[Education("Bachelors", "Information Technology", "State College")],
        experience_years=4,
        skills=["Python", "SQL"],
        certifications=[],
        achievements=[],
        demographic_info={"city": "Austin"}
    )


# ==============================================================================
# SECTION 2: TESTS FOR DATA MODELS AND CONFIGURATION
# ==============================================================================


class TestDataModels:
    """Tests for the dataclasses (ScoringConfiguration, Applicant, etc.)."""

    def test_scoring_configuration_defaults(self):
        """Verify that ScoringConfiguration has expected default values."""
        config = ScoringConfiguration()
        assert config.experience_weight == 10
        assert config.degree_scores["phd"] == 50
        assert "stanford university" in config.successful_university_indicators

    def test_scoring_configuration_custom_values(self):
        """Verify that ScoringConfiguration can be initialized with custom values."""
        config = ScoringConfiguration(
            experience_weight=99,
            degree_scores={"special": 100}
        )
        assert config.experience_weight == 99
        assert config.degree_scores["special"] == 100
        assert "phd" not in config.degree_scores  # Defaults are overridden

    def test_dataclasses_are_frozen(self, default_config, sample_applicant_zero_score):
        """Verify that dataclasses are immutable as specified by frozen=True."""
        with pytest.raises(FrozenInstanceError):
            default_config.experience_weight = 20

        with pytest.raises(FrozenInstanceError):
            sample_applicant_zero_score.name = "New Name"

        education = Education("Bachelors", "CS", "MIT")
        with pytest.raises(FrozenInstanceError):
            education.degree = "Masters"

        ranked_candidate = RankedCandidate(sample_applicant_zero_score, 100, {})
        with pytest.raises(FrozenInstanceError):
            ranked_candidate.total_score = 101


# ==============================================================================
# SECTION 3: TESTS FOR INDIVIDUAL SCORING COMPONENTS
# ==============================================================================


class TestCandidateRankerScoring:
    """Unit tests for the individual _score_* methods of CandidateRanker."""

    @pytest.mark.parametrize("degree, expected_score", [
        ("phd", 50),
        ("masters", 40),
        ("bachelors", 30),
        ("associate", 15),
        ("PhD", 50),  # Case-insensitivity
        ("MASTERS", 40),
        ("unknown degree", 0),
    ])
    def test_score_education_single_degree(self, default_config, degree, expected_score):
        """Test scoring for applicants with a single educational entry."""
        ranker = CandidateRanker(default_config)
        applicant = Applicant(1, "Test", [Education(degree, "Any", "Any")], 0, [], [], {})
        assert ranker._score_education(applicant) == expected_score

    def test_score_education_selects_highest_degree(self, default_config):
        """Test that the highest degree is chosen when multiple are present."""
        ranker = CandidateRanker(default_config)
        applicant = Applicant(
            1, "Test",
            [
                Education("Bachelors", "CS", "State U"),
                Education("Masters", "CS", "Big U"),
            ], 0, [], [], {}
        )
        assert ranker._score_education(applicant) == default_config.degree_scores["masters"]

    def test_score_education_no_education(self, default_config):
        """Test that an applicant with no education gets a score of 0."""
        ranker = CandidateRanker(default_config)
        applicant = Applicant(1, "Test", [], 0, [], [], {})
        assert ranker._score_education(applicant) == 0

    @pytest.mark.parametrize("years, expected_score", [
        (0, 0),
        (-5, 0),  # Boundary condition: negative years
        (1, 17),  # round(log(1+1, 1.5) * 10)
        (10, 59), # round(log(10+1, 1.5) * 10)
        (15, 69)  # round(log(15+1, 1.5) * 10)
    ])
    def test_score_experience_logarithmic_scale(self, default_config, years, expected_score):
        """Test the logarithmic scoring for experience."""
        ranker = CandidateRanker(default_config)
        applicant = Applicant(1, "Test", [], years, [], [], {})
        assert ranker._score_experience(applicant) == expected_score

    def test_score_skills(self, default_config):
        """Test various scenarios for skill scoring."""
        ranker = CandidateRanker(default_config)
        # No skills
        applicant_none = Applicant(1, "Test", [], 0, [], [], {})
        assert ranker._score_skills(applicant_none) == 0
        # One known skill (case-insensitive)
        applicant_one = Applicant(1, "Test", [], 0, ["PYTHON"], [], {})
        assert ranker._score_skills(applicant_one) == 20
        # Mix of known and unknown skills
        applicant_mix = Applicant(1, "Test", [], 0, ["python", "excel", "sql"], [], {})
        assert ranker._score_skills(applicant_mix) == 20 + 10
        # Duplicate skills are counted each time
        applicant_dup = Applicant(1, "Test", [], 0, ["sql", "sql"], [], {})
        assert ranker._score_skills(applicant_dup) == 10 + 10

    def test_score_certifications(self, default_config):
        """Test various scenarios for certification scoring."""
        ranker = CandidateRanker(default_config)
        cert_score = default_config.certification_scores["aws certified solutions architect"]
        applicant = Applicant(1, "Test", [], 0, [], ["AWS Certified Solutions Architect"], {})
        assert ranker._score_certifications(applicant) == cert_score
        # Test with no certs
        applicant_none = Applicant(1, "Test", [], 0, [], [], {})
        assert ranker._score_certifications(applicant_none) == 0

    @pytest.mark.parametrize("university, achievements, expected_bonus", [
        ("Some University", [], 0),  # No indicators
        ("stanford university", [], 75),  # University indicator (case-insensitive)
        ("Massachusetts Institute of Technology", [], 75), # University indicator
        ("Some University", ["tech conference speaker"], 75),  # Achievement (case-insensitive)
        ("Carnegie Mellon University", ["open source project contributor with >100 stars"], 75), # Both present
        ("Some University", ["Unknown Achievement"], 0), # Unknown achievement
    ])
    def test_apply_success_indicator_bonus(
        self, default_config, university, achievements, expected_bonus
    ):
        """Test the application of the success indicator bonus."""
        ranker = CandidateRanker(default_config)
        applicant = Applicant(
            1, "Test", [Education("Degree", "Major", university)], 0,
            [], [], {}, achievements=achievements
        )
        assert ranker._apply_success_indicator_bonus(applicant) == expected_bonus

# ==============================================================================
# SECTION 4: INTEGRATION TESTS FOR THE RANKING PROCESS
# ==============================================================================


class TestCandidateRankerIntegration:
    """Tests the combined ranking logic, including score calculation and sorting."""

    def test_calculate_base_score(self, default_config, high_scoring_applicant):
        """Verify the base score calculation and breakdown dictionary."""
        ranker = CandidateRanker(default_config)
        breakdown, total = ranker._calculate_base_score(high_scoring_applicant)

        assert breakdown["Education"] == 50  # PhD
        assert breakdown["Experience"] == 49 # round(log(7.5, 1.5)*10)
        assert breakdown["Skills"] == 20 + 25 + 30  # Python + ML + DS&A
        assert breakdown["Certifications"] == 15    # TF Cert
        assert sum(breakdown.values()) == total

    def test_calculate_total_score(self, default_config, high_scoring_applicant):
        """Verify that total score correctly combines base and bonus scores."""
        ranker = CandidateRanker(default_config)
        ranked_candidate = ranker._calculate_total_score(high_scoring_applicant)

        # Base Score Parts: 50 (Edu) + 49 (Exp) + 75 (Skills) + 15 (Certs) = 189
        base_score = 50 + 49 + 75 + 15
        # Bonus Score Parts: 75 (Stanford)
        bonus = 75
        expected_total = base_score + bonus

        assert ranked_candidate.total_score == expected_total
        assert ranked_candidate.score_breakdown["Success Indicator Bonus"] == bonus
        assert "Education" in ranked_candidate.score_breakdown
        assert ranked_candidate.applicant == high_scoring_applicant

    def test_rank_empty_list(self, default_config):
        """Test that ranking an empty list of applicants returns an empty list."""
        ranker = CandidateRanker(default_config)
        assert ranker.rank([]) == []

    def test_rank_sorting_order(
        self, default_config, high_scoring_applicant, mid_scoring_applicant, low_scoring_applicant
    ):
        """Test that candidates are correctly sorted from highest to lowest score."""
        ranker = CandidateRanker(default_config)
        # Deliberately unsorted list
        applicants = [low_scoring_applicant, high_scoring_applicant, mid_scoring_applicant]
        ranked_list = ranker.rank(applicants)

        assert len(ranked_list) == 3
        # Verify the IDs are in the correct descending score order
        assert ranked_list[0].applicant.applicant_id == high_scoring_applicant.applicant_id
        assert ranked_list[1].applicant.applicant_id == mid_scoring_applicant.applicant_id
        assert ranked_list[2].applicant.applicant_id == low_scoring_applicant.applicant_id
        # Verify scores are indeed descending
        assert ranked_list[0].total_score >= ranked_list[1].total_score
        assert ranked_list[1].total_score >= ranked_list[2].total_score

    def test_rank_with_identical_scores(self, default_config):
        """Test ranking where two candidates have the same score."""
        ranker = CandidateRanker(default_config)
        applicant1 = Applicant(1, "A", [], 5, ["python"], [], {})
        applicant2 = Applicant(2, "B", [], 5, ["python"], [], {})
        
        # Their scores should be identical
        score1 = ranker._calculate_total_score(applicant1).total_score
        score2 = ranker._calculate_total_score(applicant2).total_score
        assert score1 == score2

        ranked_list = ranker.rank([applicant1, applicant2])
        # Check that both are present in the output
        ranked_ids = {c.applicant.applicant_id for c in ranked_list}
        assert ranked_ids == {1, 2}
        # Python's sort is stable, but we don't enforce a secondary sort key,
        # so we just check their scores are equal.
        assert ranked_list[0].total_score == ranked_list[1].total_score


# ==============================================================================
# SECTION 5: TESTS FOR THE REPORTING FUNCTIONALITY
# ==============================================================================


class TestReporting:
    """Tests for the format_ranking_report function."""

    def test_report_for_no_candidates(self):
        """Verify the report message when there are no candidates to rank."""
        report = format_ranking_report([])
        assert "No candidates to rank" in report

    def test_report_content_and_structure(self):
        """Verify the report contains all expected sections and information."""
        applicant = Applicant(1, "Test Candidate", [], 5, ["Python"], [], {})
        ranked_candidate = RankedCandidate(
            applicant=applicant,
            total_score=100,
            score_breakdown={"Skills": 20, "Experience": 80}
        )
        report = format_ranking_report([ranked_candidate])

        assert "--- Candidate Ranking Summary Report ---" in report
        assert "Full Ranking of All Candidates" in report
        assert "Rank 1: Test Candidate - Total Score: 100" in report
        assert "Skills" in report
        assert "Experience" in report
        assert "Recommended Shortlist" in report
        assert "1. Test Candidate (ID: 1, Score: 100)" in report
        assert "--- End of Report ---" in report

    @pytest.mark.parametrize("num_candidates, shortlist_size, expected_shortlist_len", [
        (5, 3, 3),   # Standard case
        (5, 5, 5),   # Shortlist size equals number of candidates
        (5, 10, 5),  # Shortlist size exceeds number of candidates
        (5, 0, 0),   # Shortlist of size 0
        (2, 3, 2)    # Not enough candidates to fill shortlist
    ])
    def test_report_shortlist_sizing(
        self, num_candidates, shortlist_size, expected_shortlist_len
    ):
        """Test the shortlist logic with various sizes."""
        ranked_candidates = [
            RankedCandidate(Applicant(i, f"Cand {i}", [], 0, [], [], {}), 100-i, {})
            for i in range(num_candidates)
        ]
        report = format_ranking_report(ranked_candidates, shortlist_size=shortlist_size)
        
        # A simple way to count shortlisted candidates in the report string
        shortlist_lines = [
            line for line in report.split('\n')
            if line.strip() and line.strip()[0].isdigit() and ". " in line
        ]
        
        assert len(shortlist_lines) == expected_shortlist_len
        if shortlist_size == 0:
            assert "No candidates available for the shortlist" not in report