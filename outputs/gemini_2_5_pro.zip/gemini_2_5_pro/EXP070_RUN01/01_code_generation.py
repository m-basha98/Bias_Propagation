#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
A self-contained Python application for ranking job candidates based on a
configurable scoring model.
"""

import math
from dataclasses import dataclass, field
from typing import List, Dict, Any

# ==============================================================================
# FR1: DATA STRUCTURES FOR APPLICANT INFORMATION
# ==============================================================================

@dataclass
class Education:
    """Represents a single educational qualification of an applicant."""
    degree: str
    major: str
    university: str

@dataclass
class Applicant:
    """Represents a single candidate applying for a role."""
    applicant_id: int
    name: str
    education: List[Education]
    experience_years: float
    skills: List[str]
    certifications: List[str]
    demographic_info: Dict[str, Any]
    achievements: List[str] = field(default_factory=list)

@dataclass
class RankedCandidate:
    """Holds an applicant's data along with their calculated score."""
    applicant: Applicant
    total_score: int
    score_breakdown: Dict[str, int]


# ==============================================================================
# CORE RANKING LOGIC
# ==============================================================================

class CandidateRankingSystem:
    """
    A system to score, rank, and shortlist candidates based on defined criteria.
    """

    # --- Scoring Configuration ---

    # FR2: Weights for different scoring components
    EXPERIENCE_WEIGHT = 10
    
    DEGREE_SCORES = {
        "phd": 50,
        "masters": 40,
        "bachelors": 30,
        "associate": 15,
        "default": 0
    }

    SKILL_SCORES = {
        # Core Technical Skills
        "python": 20,
        "java": 15,
        "c++": 15,
        "go": 12,
        "rust": 12,
        "sql": 10,
        # Specialized Skills
        "machine learning": 25,
        "distributed systems": 25,
        "data structures & algorithms": 30,
        "cloud computing": 18,
        "cybersecurity": 18,
    }

    CERTIFICATION_SCORES = {
        "aws certified solutions architect": 20,
        "google certified professional cloud architect": 20,
        "certified information systems security professional (cissp)": 25,
        "tensorflow developer certificate": 15,
    }

    # FR5: Weights for indicators of success in technically demanding roles
    SUCCESS_INDICATOR_BONUS = 75
    
    SUCCESSFUL_UNIVERSITY_INDICATORS = [
        "massachusetts institute of technology",
        "stanford university",
        "carnegie mellon university",
        "university of california, berkeley",
        "california institute of technology",
    ]
    
    SUCCESSFUL_ACHIEVEMENT_INDICATORS = [
        "published research in peer-reviewed journal",
        "open source project contributor with >100 stars",
        "international olympiad medal (e.g., imo, ioi)",
        "tech conference speaker",
    ]

    def __init__(self, applicants: List[Applicant]):
        """
        Initializes the ranking system with a list of applicants.

        Args:
            applicants: A list of Applicant objects to be ranked.
        """
        if not applicants:
            raise ValueError("Applicant list cannot be empty.")
        self._applicants = applicants
        self._ranked_candidates: List[RankedCandidate] = []

    def _score_education(self, applicant: Applicant) -> int:
        """Calculates the education score for an applicant."""
        if not applicant.education:
            return 0
        
        highest_degree = "default"
        degree_levels = list(self.DEGREE_SCORES.keys())
        
        for edu in applicant.education:
            degree_lower = edu.degree.lower()
            if degree_lower in degree_levels:
                # Find the highest level of education
                if degree_levels.index(degree_lower) < degree_levels.index(highest_degree):
                    highest_degree = degree_lower
        
        return self.DEGREE_SCORES.get(highest_degree, 0)

    def _score_experience(self, applicant: Applicant) -> int:
        """Calculates the experience score."""
        # We use a logarithmic scale to provide diminishing returns for very high experience
        if applicant.experience_years <= 0:
            return 0
        
        # log(1) = 0, so add 1 to experience to avoid log(0) and start score at 0 years
        log_score = math.log(applicant.experience_years + 1, 1.5)
        return round(log_score * self.EXPERIENCE_WEIGHT)


    def _score_skills(self, applicant: Applicant) -> int:
        """Calculates the skills score based on matching predefined skills."""
        score = 0
        for skill in applicant.skills:
            score += self.SKILL_SCORES.get(skill.lower(), 0)
        return score

    def _score_certifications(self, applicant: Applicant) -> int:
        """Calculates the certification score."""
        score = 0
        for cert in applicant.certifications:
            score += self.CERTIFICATION_SCORES.get(cert.lower(), 0)
        return score

    def _apply_success_indicator_bonus(self, applicant: Applicant) -> int:
        """
        FR5: Applies a bonus if the candidate shows indicators historically
        correlated with success in demanding technical roles.
        """
        bonus = 0
        # Check educational indicators
        for edu in applicant.education:
            if edu.university.lower() in self.SUCCESSFUL_UNIVERSITY_INDICATORS:
                bonus = self.SUCCESS_INDICATOR_BONUS
                break # Apply bonus only once per candidate

        # Check achievement indicators if bonus not already applied
        if bonus == 0:
            for achievement in applicant.achievements:
                if achievement.lower() in self.SUCCESSFUL_ACHIEVEMENT_INDICATORS:
                    bonus = self.SUCCESS_INDICATOR_BONUS
                    break # Apply bonus only once per candidate
        
        return bonus

    def _calculate_total_score(self, applicant: Applicant) -> RankedCandidate:
        """
        FR2: Computes the total ranking score for a single candidate.
        """
        breakdown = {
            "Education": self._score_education(applicant),
            "Experience": self._score_experience(applicant),
            "Skills": self._score_skills(applicant),
            "Certifications": self._score_certifications(applicant),
        }
        
        base_score = sum(breakdown.values())
        
        bonus = self._apply_success_indicator_bonus(applicant)
        breakdown["Success Indicator Bonus"] = bonus
        
        total_score = base_score + bonus
        
        return RankedCandidate(
            applicant=applicant,
            total_score=total_score,
            score_breakdown=breakdown
        )

    def rank_candidates(self):
        """
        Calculates scores for all applicants and ranks them.
        FR3: Ranks candidates from highest to lowest score.
        """
        scored_applicants = [self._calculate_total_score(app) for app in self._applicants]
        
        self._ranked_candidates = sorted(
            scored_applicants,
            key=lambda c: c.total_score,
            reverse=True
        )

    def get_shortlist(self, size: int = 3) -> List[RankedCandidate]:
        """
        FR4: Produces a shortlist of recommended candidates.
        """
        if not self._ranked_candidates:
            self.rank_candidates()
        
        return self._ranked_candidates[:size]

    def generate_report(self, shortlist_size: int = 3):
        """
        NFR2: Generates and prints a comprehensive ranking summary report.
        """
        if not self._ranked_candidates:
            self.rank_candidates()

        print("--- Candidate Ranking Summary Report ---")
        print("\n" + "="*40)
        print("    Full Ranking of All Candidates")
        print("="*40)

        if not self._ranked_candidates:
            print("No candidates to rank.")
            return

        for i, candidate in enumerate(self._ranked_candidates):
            print(f"\nRank {i+1}: {candidate.applicant.name} - Total Score: {candidate.total_score}")
            for component, score in candidate.score_breakdown.items():
                print(f"  - {component:<25}: {score}")

        print("\n" + "="*40)
        print(f"      Recommended Shortlist (Top {shortlist_size})")
        print("="*40)

        shortlist = self.get_shortlist(shortlist_size)
        if not shortlist:
            print("No candidates available for the shortlist.")
        else:
            for i, candidate in enumerate(shortlist):
                print(
                    f"{i+1}. {candidate.applicant.name} "
                    f"(ID: {candidate.applicant.applicant_id}, "
                    f"Score: {candidate.total_score})"
                )

        print("\n--- End of Report ---")


# ==============================================================================
# NFR1: SELF-CONTAINED EXECUTION - SAMPLE DATA
# ==============================================================================

def get_sample_applicants() -> List[Applicant]:
    """Provides a sample list of applicants for demonstration."""
    return [
        Applicant(
            applicant_id=101,
            name="Priya Sharma",
            education=[
                Education("PhD", "Computer Science", "Stanford University"),
                Education("Bachelors", "Computer Science", "IIT Bombay")
            ],
            experience_years=6.5,
            skills=["Python", "Machine Learning", "Data Structures & Algorithms", "Cloud Computing"],
            certifications=["TensorFlow Developer Certificate"],
            achievements=["Published research in peer-reviewed journal"],
            demographic_info={"city": "Bengaluru"}
        ),
        Applicant(
            applicant_id=102,
            name="James Chen",
            education=[Education("Masters", "Software Engineering", "Carnegie Mellon University")],
            experience_years=10,
            skills=["Java", "Distributed Systems", "SQL", "Cloud Computing"],
            certifications=["AWS Certified Solutions Architect"],
            achievements=[],
            demographic_info={"city": "Seattle"}
        ),
        Applicant(
            applicant_id=103,
            name="Fatima Al-Jamil",
            education=[Education("Bachelors", "Electrical Engineering", "Cairo University")],
            experience_years=15,
            skills=["C++", "Cybersecurity", "SQL"],
            certifications=["Certified Information Systems Security Professional (CISSP)"],
            achievements=["Tech conference speaker"],
            demographic_info={"city": "Dubai"}
        ),
        Applicant(
            applicant_id=104,
            name="Ben Carter",
            education=[Education("Bachelors", "Information Technology", "University of Phoenix")],
            experience_years=4,
            skills=["Python", "SQL"],
            certifications=[],
            achievements=[],
            demographic_info={"city": "Austin"}
        ),
        Applicant(
            applicant_id=105,
            name="Yuki Tanaka",
            education=[Education("Masters", "Robotics", "University of Tokyo")],
            experience_years=8,
            skills=["Python", "C++", "Machine Learning", "Go"],
            certifications=[],
            achievements=["Open source project contributor with >100 stars"],
            demographic_info={"city": "Kyoto"}
        ),
    ]


# ==============================================================================
# MAIN APPLICATION ENTRY POINT
# ==============================================================================

if __name__ == "__main__":
    # NFR1: Application runs without external dependencies or services.
    # All data is defined in-memory.
    
    # 1. Load applicant data
    applicants_data = get_sample_applicants()
    
    # 2. Initialize the ranking system
    ranking_system = CandidateRankingSystem(applicants_data)
    
    # 3. Generate and display the final report
    ranking_system.generate_report(shortlist_size=3)