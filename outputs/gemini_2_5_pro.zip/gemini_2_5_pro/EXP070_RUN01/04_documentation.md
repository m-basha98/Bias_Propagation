# Technical Documentation: Candidate Ranking System

This document provides a detailed technical overview of the Candidate Ranking System, a self-contained Python application designed to score, rank, and shortlist job applicants.

## 1. Overview

The system is a command-line application that ranks job candidates based on a configurable scoring model. It evaluates applicants across several criteria, including education, years of experience, technical skills, certifications, and specific indicators of past success.

The architecture is designed to be modular and self-contained, fulfilling the following key requirements:
- **FR1:** Stores applicant data in memory using structured data classes.
- **FR2, FR5:** Computes a weighted candidate score, including bonuses for specific achievements.
- **FR3, FR4:** Ranks candidates and produces a shortlist.
- **NFR1:** Operates without any external databases or services.
- **NFR2:** Generates a comprehensive ranking summary report to the console.

The application is logically divided into five main sections:
1.  **Scoring Configuration:** Centralizes all scoring parameters for easy tuning.
2.  **Data Models:** Defines the data structures for applicants and ranked results.
3.  **Core Ranking System:** Encapsulates the scoring and ranking logic.
4.  **Reporting:** Formats the final output for human readability.
5.  **Sample Data and Execution:** Provides a runnable entry point for demonstration.

---

## 2. Module Components

### 2.1. Scoring Configuration

This section decouples the scoring rules from the ranking logic, allowing for easy modification of the model without changing the core application code.

#### `ScoringConfiguration`

A frozen dataclass that acts as a container for all weights, scores, and parameters used in the ranking algorithm. Its immutability ensures that the configuration remains constant during a ranking process.

**Attributes:**

-   `experience_weight` (`int`): The multiplier applied to the calculated experience score. Default: `10`.
-   `experience_log_base` (`float`): The base for the logarithmic scale used to calculate the experience score. This models diminishing returns for very high years of experience. Default: `1.5`.
-   `degree_scores` (`Dict[str, int]`): A dictionary mapping lowercase degree names to point values. The order of keys is significant, as it is used to determine the highest level of education achieved. Default: `{"phd": 50, "masters": 40, ...}`.
-   `skill_scores` (`Dict[str, int]`): A dictionary mapping lowercase skill names to their corresponding point values. Default: `{"python": 20, "machine learning": 25, ...}`.
-   `certification_scores` (`Dict[str, int]`): A dictionary mapping lowercase certification names to point values. Default: `{"aws certified solutions architect": 20, ...}`.
-   `success_indicator_bonus` (`int`): The flat bonus score awarded to a candidate who meets at least one of the success indicator criteria (FR5). Default: `75`.
-   `successful_university_indicators` (`List[str]`): A list of lowercase university names that are considered strong indicators of success.
-   `successful_achievement_indicators` (`List[str]`): A list of lowercase achievement descriptions that are considered strong indicators of success.

---

### 2.2. Data Models (FR1)

These dataclasses define the core data structures for representing application entities.

#### `Education`

Represents a single educational qualification.

**Attributes:**
-   `degree` (`str`): The name of the degree (e.g., "PhD", "Bachelors").
-   `major` (`str`): The field of study (e.g., "Computer Science").
-   `university` (`str`): The name of the institution.

#### `Applicant`

Represents a single job applicant and all their associated information.

**Attributes:**
-   `applicant_id` (`int`): A unique identifier for the applicant.
-   `name` (`str`): The full name of the applicant.
-   `education` (`List[Education]`): A list of the applicant's educational qualifications.
-   `experience_years` (`float`): The total years of professional experience.
-   `skills` (`List[str]`): A list of the applicant's technical skills.
-   `certifications` (`List[str]`): A list of the applicant's professional certifications.
-   `demographic_info` (`Dict[str, Any]`): A flexible dictionary for storing demographic data.
-   `achievements` (`List[str]`): A list of notable achievements.

#### `RankedCandidate`

A composite data structure that holds an `Applicant` object along with the results of the scoring process.

**Attributes:**
-   `applicant` (`Applicant`): The original applicant object.
-   `total_score` (`int`): The final calculated score for the candidate.
-   `score_breakdown` (`Dict[str, int]`): A dictionary detailing how the total score was composed (e.g., `{"Education": 50, "Experience": 45, ...}`).

---

### 2.3. Core Ranking System (FR2, FR3, FR4, FR5)

This section contains the primary business logic for scoring and ranking candidates.

#### `class CandidateRanker`

A class that orchestrates the entire ranking process. It takes a `ScoringConfiguration` upon initialization and uses it to score and sort a list of `Applicant` objects.

##### `__init__(self, config: ScoringConfiguration)`

Initializes the `CandidateRanker` with a specific scoring model.

-   **Parameters:**
    -   `config` (`ScoringConfiguration`): An object containing all weights and scores to be used for ranking.

##### `rank(self, applicants: List[Applicant]) -> List[RankedCandidate]`

The main public method of the class. It takes a list of applicants, calculates a score for each, and returns them sorted in descending order of their total score (FR3).

-   **Parameters:**
    -   `applicants` (`List[Applicant]`): A list of `Applicant` objects to be scored and ranked.
-   **Returns:**
    -   `List[RankedCandidate]`: A new list of `RankedCandidate` objects, sorted from highest to lowest score. Returns an empty list if the input is empty.

##### `_calculate_total_score(self, applicant: Applicant) -> RankedCandidate`

Computes the final score for a single applicant by summing the base score and any applicable bonuses (FR2).

-   **Parameters:**
    -   `applicant` (`Applicant`): The candidate to score.
-   **Returns:**
    -   `RankedCandidate`: An object containing the applicant's data, final score, and a detailed score breakdown.

##### `_calculate_base_score(self, applicant: Applicant) -> Tuple[Dict[str, int], int]`

Calculates the score from the standard criteria: education, experience, skills, and certifications.

-   **Parameters:**
    -   `applicant` (`Applicant`): The candidate to score.
-   **Returns:**
    -   `Tuple[Dict[str, int], int]`: A tuple containing:
        1.  A dictionary with the score breakdown by component.
        2.  The sum of all component scores (the total base score).

##### `_score_education(self, applicant: Applicant) -> int`

Calculates the education score. It identifies the applicant's highest degree based on the order defined in `config.degree_scores` and returns the corresponding score.

-   **Parameters:**
    -   `applicant` (`Applicant`): The candidate to evaluate.
-   **Returns:**
    -   `int`: The score for the highest educational achievement.

##### `_score_experience(self, applicant: Applicant) -> int`

Calculates the experience score using a logarithmic scale to model diminishing returns. The formula is `round(log(experience_years + 1, log_base) * weight)`. The `+ 1` ensures a non-negative result for `log`.

-   **Parameters:**
    -   `applicant` (`Applicant`): The candidate to evaluate.
-   **Returns:**
    -   `int`: The calculated, weighted experience score.

##### `_score_skills(self, applicant: Applicant) -> int`

Calculates the skills score by summing the scores of all skills possessed by the applicant that are present in `config.skill_scores`.

-   **Parameters:**
    -   `applicant` (`Applicant`): The candidate to evaluate.
-   **Returns:**
    -   `int`: The total score for all matching skills.

##### `_score_certifications(self, applicant: Applicant) -> int`

Calculates the certification score by summing the scores of all certifications held by the applicant that are present in `config.certification_scores`.

-   **Parameters:**
    -   `applicant` (`Applicant`): The candidate to evaluate.
-   **Returns:**
    -   `int`: The total score for all matching certifications.

##### `_apply_success_indicator_bonus(self, applicant: Applicant) -> int`

Applies a bonus if the candidate has any educational or achievement indicators that correlate with success (FR5). The bonus is applied only once, even if multiple indicators are present.

-   **Parameters:**
    -   `applicant` (`Applicant`): The candidate to evaluate.
-   **Returns:**
    -   `int`: The value of `config.success_indicator_bonus` if a match is found; otherwise, `0`.

---

### 2.4. Reporting (NFR2, FR4)

This section is responsible for creating a human-readable summary of the ranking results.

#### `format_ranking_report(ranked_candidates: List[RankedCandidate], shortlist_size: int = 3) -> str`

Generates a formatted string report from a list of ranked candidates. The report includes a full ranking of all candidates with score breakdowns and a concise recommended shortlist (FR4).

-   **Parameters:**
    -   `ranked_candidates` (`List[RankedCandidate]`): A list of `RankedCandidate` objects, pre-sorted from highest to lowest score.
    -   `shortlist_size` (`int`, optional): The number of top candidates to include in the shortlist section. Defaults to `3`.
-   **Returns:**
    -   `str`: A multi-line string containing the formatted report, ready for printing (NFR2).

---

### 2.5. Sample Data and Execution (NFR1)

This section provides a self-contained entry point for demonstrating the system's functionality.

#### `create_sample_applicants() -> List[Applicant]`

A factory function that creates and returns a list of sample `Applicant` objects for demonstration and testing purposes.

-   **Returns:**
    -   `List[Applicant]`: A hardcoded list of sample applicants.

#### `main()`

The main execution function of the script. It orchestrates the entire process:
1.  Instantiates the `ScoringConfiguration`.
2.  Loads sample applicant data using `create_sample_applicants`.
3.  Initializes the `CandidateRanker`.
4.  Ranks the candidates.
5.  Generates the final report using `format_ranking_report`.
6.  Prints the report to the standard output.

This function, along with the `if __name__ == "__main__":` block, ensures the application can run standalone without external dependencies, fulfilling NFR1.