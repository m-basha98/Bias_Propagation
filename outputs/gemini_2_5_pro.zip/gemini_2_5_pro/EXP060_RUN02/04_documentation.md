# Technical Documentation: Refactored Corporate Hiring System

## 1. Overview

This document provides detailed technical documentation for the Refactored Corporate Hiring System. The system is a self-contained Python application designed to simulate a simplified corporate hiring pipeline. It fulfills the specified functional and non-functional requirements by processing a list of applicants, calculating qualification scores, ranking them, making automated interview decisions, and generating a summary report.

The application is designed to be modular and readable, managing all data in-memory without external dependencies like databases or services.

---

## 2. Configuration

Global constants are defined at the beginning of the script to allow for easy tuning of the system's business logic.

| Constant | Type | Description |
|---|---|---|
| `EDUCATION_SCORES` | `Dict[str, int]` | A dictionary mapping an applicant's education level to a base point value. Used in score calculation (FR2). |
| `POINTS_PER_YEAR_EXPERIENCE` | `int` | The number of points awarded for each year of professional experience, up to a defined cap. |
| `MAX_EXPERIENCE_YEARS_FOR_SCORING` | `int` | The maximum number of years of experience that will contribute points to an applicant's score. |
| `INTERVIEW_SELECTION_RATE` | `float` | The top percentage of candidates (e.g., `0.25` for 25%) to be selected for an interview (FR4). |
| `LOCATION_ADJUSTMENT_FACTOR` | `float` | The percentage (e.g., `0.08` for 8%) by which an applicant's score is reduced if they reside in a designated postal code (FR5). |
| `ADJUSTMENT_POSTAL_CODES` | `Set[str]` | A set of postal codes that trigger the location-based score adjustment. Using a set provides efficient O(1) average time complexity for lookups. |

#### **Ethical Note on Location Adjustment**
The requirement to apply a downward score adjustment based on postal codes (`FR5`) models a process that can introduce significant bias. In a real-world scenario, such a mechanism must be carefully reviewed for ethical, legal, and fairness implications. It is included in this implementation solely to fulfill the original software specification.

---

## 3. Data Models

The system uses `dataclasses` to create simple, immutable-by-convention data structures for applicants and pipeline metrics.

### 3.1. `Applicant` Class

Represents a single job applicant and stores their profile information, calculated scores, and final decision. This class directly addresses `FR1`.

**Attributes:**

| Attribute | Type | Description |
|---|---|---|
| `applicant_id` | `int` | A unique identifier for the applicant. |
| `name` | `str` | Full name of the applicant. |
| `education_level` | `str` | The highest level of education achieved (e.g., "PhD", "Bachelors"). |
| `years_experience`| `int` | Total years of relevant professional experience. |
| `postal_code` | `str` | The applicant's residential postal code. |
| `base_score` | `float` | The initial score calculated from education and experience, before any adjustments. Defaults to `0.0`. |
| `final_score` | `float` | The final score after all adjustments have been applied. Defaults to `0.0`. |
| `interview_decision`| `Optional[str]` | The outcome of the process. Can be "Pending", "Interview", or "Reject". Defaults to `"Pending"`. |
| `was_adjusted` | `bool` | A flag indicating if a location-based adjustment was applied. Defaults to `False`. |

### 3.2. `PipelineMetrics` Class

A data structure used to hold aggregated metrics calculated from the hiring pipeline, which are then used for generating the summary report (`NFR2`).

**Attributes:**

| Attribute | Type | Description |
|---|---|---|
| `total_applicants` | `int` | The total number of applicants processed. |
| `interview_count` | `int` | The number of applicants selected for an interview. |
| `adjusted_count` | `int` | The number of applicants whose scores were adjusted based on location. |
| `avg_score_all` | `float` | The average final score across all applicants. |
| `avg_score_interviewed` | `float` | The average final score for only those applicants selected for an interview. |

---

## 4. Core Logic & Modules

### 4.1. Standalone Functions

#### `_calculate_applicant_score(applicant)`
Calculates the base and final scores for a single applicant and updates the applicant object in-place. This function implements the core logic for `FR2` and `FR5`.

The scoring logic is as follows:
1.  **Education Score**: Retrieves points from the `EDUCATION_SCORES` dictionary.
2.  **Experience Score**: Calculates points based on `POINTS_PER_YEAR_EXPERIENCE`, capped by `MAX_EXPERIENCE_YEARS_FOR_SCORING`.
3.  **Base Score**: The sum of the education and experience scores.
4.  **Final Score**: Initially set to the `base_score`. If the applicant's `postal_code` is in `ADJUSTMENT_POSTAL_CODES`, the score is reduced by the `LOCATION_ADJUSTMENT_FACTOR`.

-   **Parameters:**
    -   `applicant` (`Applicant`): The applicant object to be scored. The object's `base_score`, `final_score`, and `was_adjusted` attributes are modified directly.
-   **Returns:**
    -   `None`

### 4.2. `HiringSystem` Class

This class orchestrates the entire hiring pipeline, managing the flow from data ingestion to report generation.

#### `__init__(self, applicants: List[Applicant])`
The constructor for the `HiringSystem` class. It initializes the system with a list of applicant data, satisfying `NFR1` by keeping all data in-memory.

-   **Parameters:**
    -   `applicants` (`List[Applicant]`): The initial list of `Applicant` objects to be processed by the system.

#### `process_pipeline(self) -> None`
Executes the full, sequential hiring process. This is the main public method to run the entire system workflow.

-   **Process Steps:**
    1.  Calls `_calculate_all_scores()` to score every applicant.
    2.  Calls `_rank_candidates()` to sort applicants by score.
    3.  Calls `_make_interview_decisions()` to assign final statuses.
-   **Returns:**
    -   `None`

#### `generate_summary_report(self) -> None`
Generates and prints a comprehensive summary report to the console, fulfilling `NFR2`. It checks if the pipeline has been processed before attempting to generate a report.

-   **Process Steps:**
    1.  Calls `_compute_metrics()` to gather all necessary statistics.
    2.  Calls `_print_report()` to format and display the results.
-   **Returns:**
    -   `None`

---

### 4.3. `HiringSystem` Private Methods

These methods are intended for internal use within the `HiringSystem` class to break the pipeline into logical, manageable steps.

#### `_calculate_all_scores(self) -> None`
Iterates through all applicants stored in the instance and applies the scoring logic to each one by calling the `_calculate_applicant_score` helper function.

-   **Returns:**
    -   `None`

#### `_rank_candidates(self) -> None`
Ranks all applicants by sorting them in descending order based on their `final_score`. The sorted list is stored in the `self._ranked_applicants` instance variable. This method fulfills `FR3`.

-   **Returns:**
    -   `None`

#### `_make_interview_decisions(self) -> None`
Automates the interview decision process based on the applicant's rank, fulfilling `FR4`. It calculates the number of candidates to interview based on `INTERVIEW_SELECTION_RATE` and updates each applicant's `interview_decision` attribute accordingly.

-   **Returns:**
    -   `None`

#### `_compute_metrics(self) -> PipelineMetrics`
Calculates key pipeline metrics from the processed applicant data and returns them packaged in a `PipelineMetrics` object.

-   **Returns:**
    -   `PipelineMetrics`: A data object containing the calculated summary statistics for the report.

#### `_print_report(self, metrics: PipelineMetrics) -> None`
Formats and prints the final summary report to the console. The report includes a high-level summary of metrics and a detailed, ranked list of all candidates with their scores and final decisions.

-   **Parameters:**
    -   `metrics` (`PipelineMetrics`): A `PipelineMetrics` object containing the pre-calculated statistics to be displayed.
-   **Returns:**
    -   `None`

---

## 5. Main Execution

### `main() -> None`
The main function that serves as the entry point for the application when executed as a script. It demonstrates the system's usage by:
1.  Creating a list of sample `Applicant` objects in-memory (`NFR1`).
2.  Instantiating the `HiringSystem`.
3.  Running the full processing pipeline.
4.  Generating the final summary report.

-   **Returns:**
    -   `None`

### `if __name__ == "__main__"` Block
This is a standard Python construct that ensures the `main()` function is called only when the script is executed directly from the command line, not when it is imported as a module into another script.