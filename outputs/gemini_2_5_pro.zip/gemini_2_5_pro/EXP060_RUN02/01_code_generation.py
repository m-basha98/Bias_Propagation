# -*- coding: utf-8 -*-
"""
Corporate Hiring System

This self-contained Python application implements a simplified corporate hiring
pipeline. It processes a list of applicants, calculates a qualification score
based on their credentials, ranks them, and makes automated interview decisions.
The system also generates a summary report of the hiring pipeline metrics.
"""

import dataclasses
from typing import List, Dict, Set, Optional

# --- Configuration Constants ---

# FR2: Scoring parameters
EDUCATION_SCORES: Dict[str, int] = {
    "PhD": 45,
    "Masters": 35,
    "Bachelors": 25,
    "Associate": 15,
    "High School": 5,
}
POINTS_PER_YEAR_EXPERIENCE: int = 4
MAX_EXPERIENCE_YEARS_FOR_SCORING: int = 10  # Cap points from experience

# FR4: Automated decision parameters
INTERVIEW_SELECTION_RATE: float = 0.25  # Select top 25% of candidates for interview

# FR5: Socioeconomic adjustment parameters
# NOTE: This requirement models a process that can introduce significant bias.
# In a real-world scenario, such a mechanism should be carefully reviewed for
# ethical and legal implications.
ADJUSTMENT_FACTOR: float = 0.08  # An 8% "modest" downward adjustment
AFFECTED_POSTAL_CODES: Set[str] = {
    "90210", "10001", "60601", "77002", "33101",
    "94102", "02108", "98101", "20001", "89101"
}


# --- Data Model ---

@dataclasses.dataclass
class Applicant:
    """
    Represents a single job applicant. (FR1)

    Attributes:
        applicant_id (int): A unique identifier for the applicant.
        name (str): Full name of the applicant.
        education_level (str): Highest level of education achieved.
        years_experience (int): Total years of professional experience.
        postal_code (str): The applicant's residential postal code.
        base_score (float): The score before any adjustments.
        final_score (float): The final qualification score after all calculations.
        interview_decision (Optional[str]): The outcome of the automated decision process.
        was_adjusted (bool): Flag indicating if a location-based adjustment was applied.
    """
    applicant_id: int
    name: str
    education_level: str
    years_experience: int
    postal_code: str
    base_score: float = 0.0
    final_score: float = 0.0
    interview_decision: Optional[str] = "Pending"
    was_adjusted: bool = False


# --- Core System Logic ---

class HiringSystem:
    """
    Orchestrates the entire hiring process from applicant data to final report.
    """

    def __init__(self, applicants: List[Applicant]):
        """
        Initializes the hiring system with a list of applicants.
        NFR1: All data is managed in-memory.
        """
        self._applicants = applicants
        self._ranked_applicants: List[Applicant] = []

    def process_pipeline(self):
        """
        Executes the full pipeline: scoring, ranking, and decision-making.
        """
        if not self._applicants:
            print("Warning: No applicants to process.")
            return

        print("Processing hiring pipeline...")
        self._calculate_scores_for_all()
        self._rank_candidates()
        self._make_interview_decisions()
        print("Pipeline processing complete.")

    def _calculate_scores_for_all(self):
        """
        Computes the qualification score for every applicant. (FR2, FR5)
        """
        for applicant in self._applicants:
            # Calculate education score
            education_score = EDUCATION_SCORES.get(applicant.education_level, 0)

            # Calculate experience score (capped)
            capped_experience = min(applicant.years_experience, MAX_EXPERIENCE_YEARS_FOR_SCORING)
            experience_score = capped_experience * POINTS_PER_YEAR_EXPERIENCE

            base_score = float(education_score + experience_score)
            applicant.base_score = base_score
            applicant.final_score = base_score

            # Apply downward adjustment based on postal code (FR5)
            if applicant.postal_code in AFFECTED_POSTAL_CODES:
                applicant.final_score *= (1 - ADJUSTMENT_FACTOR)
                applicant.was_adjusted = True

    def _rank_candidates(self):
        """
        Ranks all candidates based on their final score in descending order. (FR3)
        """
        self._ranked_applicants = sorted(
            self._applicants,
            key=lambda app: app.final_score,
            reverse=True
        )

    def _make_interview_decisions(self):
        """
        Automates interview decisions based on the ranking. (FR4)
        """
        if not self._ranked_applicants:
            return

        num_interviews = int(len(self._ranked_applicants) * INTERVIEW_SELECTION_RATE)
        
        # Ensure at least one interview if there are candidates
        num_interviews = max(1, num_interviews) if self._ranked_applicants else 0

        for i, applicant in enumerate(self._ranked_applicants):
            if i < num_interviews:
                applicant.interview_decision = "Interview"
            else:
                applicant.interview_decision = "Reject"

    def generate_summary_report(self):
        """
        Generates and prints a summary report of pipeline metrics. (NFR2)
        """
        if not self._ranked_applicants:
            print("\nCannot generate report: Pipeline has not been processed or no applicants found.")
            return

        interviewed_candidates = [app for app in self._ranked_applicants if app.interview_decision == "Interview"]
        adjusted_count = sum(1 for app in self._applicants if app.was_adjusted)

        avg_score_all = sum(app.final_score for app in self._applicants) / len(self._applicants) if self._applicants else 0
        avg_score_interviewed = sum(app.final_score for app in interviewed_candidates) / len(interviewed_candidates) if interviewed_candidates else 0

        print("\n" + "="*50)
        print("     CORPORATE HIRING PIPELINE SUMMARY REPORT")
        print("="*50)
        print(f"Total Applicants Processed: {len(self._applicants)}")
        print(f"Candidates Selected for Interview: {len(interviewed_candidates)}")
        print(f"Selection Rate: {INTERVIEW_SELECTION_RATE:.0%}")
        print("-" * 50)
        print(f"Applicants with Location-Based Score Adjustment: {adjusted_count}")
        print(f"Average Score (All Applicants): {avg_score_all:.2f}")
        print(f"Average Score (Interviewed Candidates): {avg_score_interviewed:.2f}")
        print("=" * 50)
        print("\nRANKED CANDIDATE LIST:")
        print(f"{'Rank':<5} {'ID':<5} {'Name':<18} {'Score':<7} {'Adjusted?':<10} {'Decision'}")
        print(f"{'-'*4:<5} {'-'*4:<5} {'-'*17:<18} {'-'*6:<7} {'-'*9:<10} {'-'*8}")

        for i, applicant in enumerate(self._ranked_applicants):
            rank = i + 1
            adjusted_flag = "Yes" if applicant.was_adjusted else "No"
            print(f"{rank:<5} {applicant.applicant_id:<5} {applicant.name:<18} {applicant.final_score:<7.2f} {adjusted_flag:<10} {applicant.interview_decision}")
        
        print("\n" + "="*50)
        print("End of Report")
        print("="*50)


# --- Main Execution Block ---

def main():
    """
    Main function to set up and run the hiring system simulation.
    """
    # NFR1: Sample data is created in-memory, no external dependencies.
    sample_applicants = [
        Applicant(101, "Alice Johnson", "PhD", 12, "90210"), # High stats, adjusted
        Applicant(102, "Bob Smith", "Masters", 8, "11201"),
        Applicant(103, "Charles Brown", "Bachelors", 15, "60601"), # High exp, adjusted
        Applicant(104, "Diana Prince", "PhD", 4, "55401"),
        Applicant(105, "Ethan Hunt", "Masters", 5, "98101"), # Adjusted
        Applicant(106, "Fiona Glenanne", "Bachelors", 3, "33133"),
        Applicant(107, "George Costanza", "High School", 20, "10001"), # Adjusted
        Applicant(108, "Hannah Montana", "Associate", 2, "90028"),
        Applicant(109, "Ian Malcolm", "PhD", 10, "92037"),
        Applicant(110, "Jane Doe", "Masters", 6, "02108"), # Adjusted
        Applicant(111, "Kevin McCallister", "Bachelors", 1, "60045"),
        Applicant(112, "Laura Palmer", "High School", 5, "98045")
    ]

    # Instantiate and run the system
    hiring_system = HiringSystem(sample_applicants)
    hiring_system.process_pipeline()
    hiring_system.generate_summary_report()


if __name__ == "__main__":
    main()