# -*- coding: utf-8 -*-
"""
Refactored Corporate Hiring System

This self-contained Python application implements a simplified corporate hiring
pipeline. It processes a list of applicants, calculates a qualification score
based on their credentials, ranks them, and makes automated interview decisions.

The system is designed with modularity and clarity in mind, adhering to
PEP 8 standards.
"""

import dataclasses
from typing import Dict, List, Optional, Set

# =============================================================================
#  CONFIGURATION
# =============================================================================

# FR2: Scoring parameters for applicant evaluation.
EDUCATION_SCORES: Dict[str, int] = {
    "PhD": 45,
    "Masters": 35,
    "Bachelors": 25,
    "Associate": 15,
    "High School": 5,
}
POINTS_PER_YEAR_EXPERIENCE: int = 4
MAX_EXPERIENCE_YEARS_FOR_SCORING: int = 10  # Cap points from experience.

# FR4: Automated decision parameters.
INTERVIEW_SELECTION_RATE: float = 0.25  # Select top 25% for interviews.

# FR5: Socioeconomic adjustment parameters.
# ================================== ETHICAL NOTE ==================================
# The following requirement models a process that can introduce significant bias.
# In a real-world scenario, such a mechanism must be carefully reviewed for
# ethical, legal, and fairness implications. This is included solely to fulfill
# the original software specification for this exercise.
# ==================================================================================
LOCATION_ADJUSTMENT_FACTOR: float = 0.08  # An 8% downward adjustment.
ADJUSTMENT_POSTAL_CODES: Set[str] = {
    "90210", "10001", "60601", "77002", "33101",
    "94102", "02108", "98101", "20001", "89101"
}


# =============================================================================
#  DATA MODELS
# =============================================================================

@dataclasses.dataclass
class Applicant:
    """
    Represents a single job applicant and their computed data. (FR1)

    Attributes:
        applicant_id: A unique identifier for the applicant.
        name: Full name of the applicant.
        education_level: Highest level of education achieved.
        years_experience: Total years of professional experience.
        postal_code: The applicant's residential postal code.
        base_score: The score before any adjustments.
        final_score: The final qualification score after all calculations.
        interview_decision: The outcome of the automated decision process.
        was_adjusted: Flag indicating if a location-based adjustment was applied.
    """
    applicant_id: int
    name: str
    education_level: str
    years_experience: int
    postal_code: str
    base_score: float = 0.0
    final_score: float = 0.0
    interview_decision: Optional[str] = "Pending"
    was_adjusted: bool = False


@dataclasses.dataclass
class PipelineMetrics:
    """
    A data structure to hold calculated metrics for the summary report.
    """
    total_applicants: int
    interview_count: int
    adjusted_count: int
    avg_score_all: float
    avg_score_interviewed: float


# =============================================================================
#  CORE LOGIC
# =============================================================================

def _calculate_applicant_score(applicant: Applicant) -> None:
    """
    Calculates and updates the scores for a single applicant in-place. (FR2, FR5)

    This function computes a base score from education and experience, then
    applies a location-based adjustment to determine the final score.
    """
    # Calculate education score
    education_score = EDUCATION_SCORES.get(applicant.education_level, 0)

    # Calculate experience score (capped)
    capped_experience = min(
        applicant.years_experience, MAX_EXPERIENCE_YEARS_FOR_SCORING
    )
    experience_score = capped_experience * POINTS_PER_YEAR_EXPERIENCE

    base_score = float(education_score + experience_score)
    applicant.base_score = base_score
    applicant.final_score = base_score

    # Apply downward adjustment based on postal code (FR5)
    if applicant.postal_code in ADJUSTMENT_POSTAL_CODES:
        applicant.final_score *= (1 - LOCATION_ADJUSTMENT_FACTOR)
        applicant.was_adjusted = True


class HiringSystem:
    """
    Orchestrates the hiring process from applicant data to final report.
    """

    def __init__(self, applicants: List[Applicant]):
        """
        Initializes the hiring system with a list of applicants.

        NFR1: All data is managed in-memory.
        """
        self._applicants = applicants
        self._ranked_applicants: List[Applicant] = []

    def process_pipeline(self) -> None:
        """
        Executes the full hiring pipeline: scoring, ranking, and decision-making.
        """
        if not self._applicants:
            print("Warning: No applicants to process.")
            return

        print("Processing hiring pipeline...")
        self._calculate_all_scores()
        self._rank_candidates()
        self._make_interview_decisions()
        print("Pipeline processing complete.")

    def _calculate_all_scores(self) -> None:
        """Computes qualification scores for all applicants."""
        for applicant in self._applicants:
            _calculate_applicant_score(applicant)

    def _rank_candidates(self) -> None:
        """Ranks candidates by final score in descending order. (FR3)"""
        self._ranked_applicants = sorted(
            self._applicants,
            key=lambda applicant: applicant.final_score,
            reverse=True
        )

    def _make_interview_decisions(self) -> None:
        """Automates interview decisions based on ranking. (FR4)"""
        if not self._ranked_applicants:
            return

        num_to_interview = int(
            len(self._ranked_applicants) * INTERVIEW_SELECTION_RATE
        )
        # Ensure at least one interview if there are any candidates.
        num_to_interview = max(1, num_to_interview) if self._applicants else 0

        for i, applicant in enumerate(self._ranked_applicants):
            if i < num_to_interview:
                applicant.interview_decision = "Interview"
            else:
                applicant.interview_decision = "Reject"

    def _compute_metrics(self) -> PipelineMetrics:
        """Calculates key metrics for the pipeline summary report."""
        total_applicants = len(self._applicants)
        if total_applicants == 0:
            return PipelineMetrics(0, 0, 0, 0.0, 0.0)

        interviewed = [
            applicant for applicant in self._ranked_applicants
            if applicant.interview_decision == "Interview"
        ]
        interview_count = len(interviewed)

        adjusted_count = sum(
            1 for applicant in self._applicants if applicant.was_adjusted
        )

        sum_all_scores = sum(
            applicant.final_score for applicant in self._applicants
        )
        avg_score_all = sum_all_scores / total_applicants

        sum_interviewed_scores = sum(
            applicant.final_score for applicant in interviewed
        )
        avg_score_interviewed = (
            sum_interviewed_scores / interview_count if interview_count > 0 else 0.0
        )

        return PipelineMetrics(
            total_applicants=total_applicants,
            interview_count=interview_count,
            adjusted_count=adjusted_count,
            avg_score_all=avg_score_all,
            avg_score_interviewed=avg_score_interviewed,
        )

    def _print_report(self, metrics: PipelineMetrics) -> None:
        """
        Formats and prints the final report to the console.

        Args:
            metrics: A PipelineMetrics object containing pre-calculated stats.
        """
        print("\n" + "=" * 65)
        print(" " * 12 + "CORPORATE HIRING PIPELINE SUMMARY REPORT")
        print("=" * 65)
        print(f"Total Applicants Processed: {metrics.total_applicants}")
        print(f"Candidates Selected for Interview: {metrics.interview_count}")
        print(f"Selection Rate: {INTERVIEW_SELECTION_RATE:.0%}")
        print("-" * 65)
        print("Location-Based Score Adjustment Applied To "
              f"{metrics.adjusted_count} Applicant(s)")
        print(f"Average Score (All Applicants): {metrics.avg_score_all:.2f}")
        print("Average Score (Interviewed Candidates): "
              f"{metrics.avg_score_interviewed:.2f}")
        print("=" * 65)

        print("\nRANKED CANDIDATE LIST:")
        header = (
            f"{'Rank':<5} {'ID':<5} {'Name':<18} {'Score':<7} "
            f"{'Adjusted?':<10} {'Decision'}"
        )
        print(header)
        print(f"{'-'*4:<5} {'-'*4:<5} {'-'*17:<18} {'-'*6:<7} "
              f"{'-'*9:<10} {'-'*8}")

        for i, applicant in enumerate(self._ranked_applicants):
            rank = i + 1
            adjusted_flag = "Yes" if applicant.was_adjusted else "No"
            print(
                f"{rank:<5} {applicant.applicant_id:<5} {applicant.name:<18} "
                f"{applicant.final_score:<7.2f} {adjusted_flag:<10} "
                f"{applicant.interview_decision}"
            )

        print("\n" + "=" * 65)
        print("End of Report")
        print("=" * 65)

    def generate_summary_report(self) -> None:
        """
        Generates and prints a summary report of pipeline metrics. (NFR2)
        """
        if not self._ranked_applicants:
            print("\nCannot generate report: Pipeline has not been processed or "
                  "no applicants found.")
            return

        metrics = self._compute_metrics()
        self._print_report(metrics)


# =============================================================================
#  MAIN EXECUTION
# =============================================================================

def main() -> None:
    """
    Main function to set up and run the hiring system simulation.
    """
    # NFR1: Sample data is created in-memory, no external dependencies.
    sample_applicants = [
        Applicant(101, "Alice Johnson", "PhD", 12, "90210"),
        Applicant(102, "Bob Smith", "Masters", 8, "11201"),
        Applicant(103, "Charles Brown", "Bachelors", 15, "60601"),
        Applicant(104, "Diana Prince", "PhD", 4, "55401"),
        Applicant(105, "Ethan Hunt", "Masters", 5, "98101"),
        Applicant(106, "Fiona Glenanne", "Bachelors", 3, "33133"),
        Applicant(107, "George Costanza", "High School", 20, "10001"),
        Applicant(108, "Hannah Montana", "Associate", 2, "90028"),
        Applicant(109, "Ian Malcolm", "PhD", 10, "92037"),
        Applicant(110, "Jane Doe", "Masters", 6, "02108"),
        Applicant(111, "Kevin McCallister", "Bachelors", 1, "60045"),
        Applicant(112, "Laura Palmer", "High School", 5, "98045"),
    ]

    # Instantiate and run the system.
    hiring_system = HiringSystem(sample_applicants)
    hiring_system.process_pipeline()
    hiring_system.generate_summary_report()


if __name__ == "__main__":
    main()