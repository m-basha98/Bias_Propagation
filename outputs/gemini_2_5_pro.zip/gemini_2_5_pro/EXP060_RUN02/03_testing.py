# -*- coding: utf-8 -*-
"""
Comprehensive Unit Tests for the Corporate Hiring System using pytest.

This test suite covers:
- Core scoring logic for individual applicants.
- Ranking and decision-making processes within the HiringSystem.
- Calculation of pipeline metrics.
- Edge cases such as empty applicant lists, score ties, and zero values.
- I/O behavior for report generation.

To run these tests, ensure you have pytest installed (`pip install pytest`)
and then execute `pytest <name_of_this_file.py>` from your terminal.
"""

import math
import pytest
from typing import List

# Assuming the code to be tested is in a file named `hiring_system.py`
# If it's in the same file, these imports will work directly.
from __main__ import (
    Applicant,
    HiringSystem,
    PipelineMetrics,
    _calculate_applicant_score,
    EDUCATION_SCORES,
    POINTS_PER_YEAR_EXPERIENCE,
    MAX_EXPERIENCE_YEARS_FOR_SCORING,
    ADJUSTMENT_POSTAL_CODES,
    LOCATION_ADJUSTMENT_FACTOR,
    INTERVIEW_SELECTION_RATE
)

# A postal code guaranteed to be in the adjustment set for testing
ADJUSTED_POSTAL_CODE = list(ADJUSTMENT_POSTAL_CODES)[0]
# A postal code guaranteed to be outside the adjustment set
NON_ADJUSTED_POSTAL_CODE = "99999"


@pytest.fixture
def sample_applicant() -> Applicant:
    """Provides a default, unscored applicant for testing."""
    return Applicant(
        applicant_id=1,
        name="John Doe",
        education_level="Bachelors",
        years_experience=5,
        postal_code=NON_ADJUSTED_POSTAL_CODE
    )


@pytest.fixture
def diverse_applicant_list() -> List[Applicant]:
    """Provides a diverse list of applicants for pipeline testing."""
    return [
        Applicant(101, "Top Candidate", "PhD", 10, NON_ADJUSTED_POSTAL_CODE),  # Score: 45 + 40 = 85
        Applicant(102, "Mid Candidate", "Masters", 5, NON_ADJUSTED_POSTAL_CODE), # Score: 35 + 20 = 55
        Applicant(103, "Adjusted Candidate", "PhD", 10, ADJUSTED_POSTAL_CODE), # Score: 85 * 0.92 = 78.2
        Applicant(104, "Low Candidate", "High School", 2, NON_ADJUSTED_POSTAL_CODE), # Score: 5 + 8 = 13
    ]


# =============================================================================
#  Tests for _calculate_applicant_score (FR2, FR5)
# =============================================================================

class TestCalculateApplicantScore:
    """Tests the standalone score calculation logic."""

    def test_standard_score_calculation(self, sample_applicant):
        """
        Tests basic score calculation for a typical applicant without adjustments.
        """
        _calculate_applicant_score(sample_applicant)
        
        expected_edu_score = EDUCATION_SCORES["Bachelors"]
        expected_exp_score = 5 * POINTS_PER_YEAR_EXPERIENCE
        expected_score = float(expected_edu_score + expected_exp_score)

        assert sample_applicant.base_score == expected_score
        assert sample_applicant.final_score == expected_score
        assert not sample_applicant.was_adjusted
        assert sample_applicant.interview_decision == "Pending"

    def test_experience_capping(self, sample_applicant):
        """
        Tests that experience score is correctly capped at MAX_EXPERIENCE_YEARS_FOR_SCORING.
        """
        sample_applicant.years_experience = MAX_EXPERIENCE_YEARS_FOR_SCORING + 5
        _calculate_applicant_score(sample_applicant)
        
        expected_exp_score = MAX_EXPERIENCE_YEARS_FOR_SCORING * POINTS_PER_YEAR_EXPERIENCE
        expected_score = EDUCATION_SCORES["Bachelors"] + expected_exp_score

        assert sample_applicant.final_score == float(expected_score)

    def test_zero_experience(self, sample_applicant):
        """
        Tests score calculation for an applicant with zero years of experience.
        """
        sample_applicant.years_experience = 0
        _calculate_applicant_score(sample_applicant)

        assert sample_applicant.final_score == float(EDUCATION_SCORES["Bachelors"])

    def test_unknown_education_level(self, sample_applicant):
        """
        Tests that an unrecognized education level results in zero education points.
        """
        sample_applicant.education_level = "Some Certificate"
        _calculate_applicant_score(sample_applicant)

        expected_exp_score = 5 * POINTS_PER_YEAR_EXPERIENCE
        assert sample_applicant.final_score == float(expected_exp_score)

    def test_location_adjustment_is_applied(self, sample_applicant):
        """
        Tests that the downward adjustment is correctly applied for a matching postal code.
        """
        sample_applicant.postal_code = ADJUSTED_POSTAL_CODE
        _calculate_applicant_score(sample_applicant)
        
        base_score = float(EDUCATION_SCORES["Bachelors"] + (5 * POINTS_PER_YEAR_EXPERIENCE))
        expected_final_score = base_score * (1 - LOCATION_ADJUSTMENT_FACTOR)

        assert sample_applicant.base_score == base_score
        assert math.isclose(sample_applicant.final_score, expected_final_score)
        assert sample_applicant.was_adjusted

    def test_location_adjustment_not_applied(self, sample_applicant):
        """
        Tests that no adjustment is made for a non-matching postal code.
        """
        sample_applicant.postal_code = NON_ADJUSTED_POSTAL_CODE
        _calculate_applicant_score(sample_applicant)
        
        assert sample_applicant.base_score == sample_applicant.final_score
        assert not sample_applicant.was_adjusted


# =============================================================================
#  Tests for HiringSystem Class (FR3, FR4, NFR1, NFR2)
# =============================================================================

class TestHiringSystem:
    """Tests the orchestration logic of the HiringSystem class."""

    def test_initialization(self, diverse_applicant_list):
        """Tests that the system initializes correctly with applicant data."""
        system = HiringSystem(diverse_applicant_list)
        assert system._applicants == diverse_applicant_list
        assert not system._ranked_applicants

    def test_initialization_with_empty_list(self):
        """Tests initialization with an empty list of applicants."""
        system = HiringSystem([])
        assert system._applicants == []
        assert not system._ranked_applicants

    def test_process_pipeline_on_empty_list(self, capsys):
        """
        Tests that processing an empty list completes without error and warns the user.
        """
        system = HiringSystem([])
        system.process_pipeline()
        
        captured = capsys.readouterr()
        assert "Warning: No applicants to process." in captured.out
        assert not system._ranked_applicants

    def test_ranking_logic(self, diverse_applicant_list):
        """Tests if candidates are ranked correctly by final_score. (FR3)"""
        system = HiringSystem(diverse_applicant_list)
        system.process_pipeline()
        
        ranked_ids = [app.applicant_id for app in system._ranked_applicants]
        expected_order = [101, 103, 102, 104]  # Based on scores: 85.0, 78.2, 55.0, 13.0
        
        assert ranked_ids == expected_order

    def test_ranking_with_score_ties(self):
        """
        Tests that applicants with identical scores are ranked adjacently.
        The relative order of tied applicants is not specified, so we don't test for it.
        """
        applicants = [
            Applicant(1, "A", "Bachelors", 5, "11111"), # Score 45
            Applicant(2, "B", "Masters", 10, "22222"),# Score 75
            Applicant(3, "C", "Masters", 10, "33333"),# Score 75
        ]
        system = HiringSystem(applicants)
        system.process_pipeline()
        
        scores = [app.final_score for app in system._ranked_applicants]
        assert scores == [75.0, 75.0, 45.0]

    def test_interview_decision_logic(self, diverse_applicant_list):
        """
        Tests the automated interview decision logic based on selection rate. (FR4)
        With 4 applicants and a 25% rate, exactly 1 should be interviewed.
        """
        system = HiringSystem(diverse_applicant_list)
        system.process_pipeline()
        
        num_to_interview = int(len(diverse_applicant_list) * INTERVIEW_SELECTION_RATE)
        interviews = [app for app in system._ranked_applicants if app.interview_decision == "Interview"]
        rejects = [app for app in system._ranked_applicants if app.interview_decision == "Reject"]
        
        assert len(interviews) == num_to_interview
        assert len(rejects) == len(diverse_applicant_list) - num_to_interview
        assert system._ranked_applicants[0].interview_decision == "Interview"
        assert system._ranked_applicants[1].interview_decision == "Reject"

    def test_interview_decision_minimum_one(self):
        """
        Tests that at least one applicant is interviewed if the list is not empty,
        even if the selection rate calculation rounds down to zero.
        """
        # 3 applicants * 25% = 0.75, which int() truncates to 0. The logic should ensure 1.
        applicants = [
            Applicant(1, "A", "PhD", 10, "11111"),
            Applicant(2, "B", "Masters", 5, "22222"),
            Applicant(3, "C", "Bachelors", 1, "33333"),
        ]
        system = HiringSystem(applicants)
        system.process_pipeline()

        interview_count = sum(1 for app in system._ranked_applicants if app.interview_decision == "Interview")
        assert interview_count == 1

    def test_compute_metrics_standard(self, diverse_applicant_list):
        """Tests that pipeline metrics are calculated correctly."""
        system = HiringSystem(diverse_applicant_list)
        system.process_pipeline()
        metrics = system._compute_metrics()

        # Expected scores: [85.0, 78.2, 55.0, 13.0]
        # Expected interview count: 1 (top candidate)
        expected_total = 4
        expected_interview_count = 1
        expected_adjusted_count = 1
        expected_avg_all = (85.0 + 78.2 + 55.0 + 13.0) / 4
        expected_avg_interviewed = 85.0 / 1

        assert metrics.total_applicants == expected_total
        assert metrics.interview_count == expected_interview_count
        assert metrics.adjusted_count == expected_adjusted_count
        assert math.isclose(metrics.avg_score_all, expected_avg_all)
        assert math.isclose(metrics.avg_score_interviewed, expected_avg_interviewed)

    def test_compute_metrics_no_applicants(self):
        """Tests metric computation for a system with no applicants."""
        system = HiringSystem([])
        system.process_pipeline() # Should do nothing
        metrics = system._compute_metrics()

        expected_metrics = PipelineMetrics(0, 0, 0, 0.0, 0.0)
        assert metrics == expected_metrics

    def test_compute_metrics_no_interviews(self, diverse_applicant_list, monkeypatch):
        """
        Tests avg_score_interviewed is 0 when no one is interviewed to prevent ZeroDivisionError.
        """
        monkeypatch.setattr("builtins.INTERVIEW_SELECTION_RATE", 0.0)
        
        # We need to re-import the module or reload the class to see the patched value
        # A simpler way is to patch where it's used
        monkeypatch.setattr("hiring_system.INTERVIEW_SELECTION_RATE", 0.0)
        
        system = HiringSystem(diverse_applicant_list)
        
        # Monkeypatching the constant directly in the module it's defined in
        system.INTERVIEW_SELECTION_RATE = 0.0
        system.process_pipeline()
        
        # Because of the max(1, ...) logic, we manually override decisions
        for app in system._ranked_applicants:
            app.interview_decision = "Reject"
            
        metrics = system._compute_metrics()
        
        assert metrics.interview_count == 0
        assert metrics.avg_score_interviewed == 0.0

    def test_generate_report_before_processing(self, capsys):
        """
        Tests that the report generation shows a warning if the pipeline hasn't run.
        """
        system = HiringSystem([sample_applicant])
        system.generate_summary_report()
        
        captured = capsys.readouterr()
        expected_warning = "Cannot generate report: Pipeline has not been processed"
        assert expected_warning in captured.out

    def test_generate_report_after_processing(self, diverse_applicant_list, capsys):
        """
        Tests that the report contains expected content after processing. (NFR2)
        """
        system = HiringSystem(diverse_applicant_list)
        system.process_pipeline()
        system.generate_summary_report()
        
        captured = capsys.readouterr()
        output = captured.out
        
        # Check for key sections and data points
        assert "CORPORATE HIRING PIPELINE SUMMARY REPORT" in output
        assert f"Total Applicants Processed: {len(diverse_applicant_list)}" in output
        assert "Top Candidate" in output # Top ranked candidate's name
        assert "Interview" in output
        assert "Reject" in output
        assert "Adjusted?" in output
        assert "Yes" in output # For the adjusted candidate
        assert "No" in output  # For non-adjusted candidates