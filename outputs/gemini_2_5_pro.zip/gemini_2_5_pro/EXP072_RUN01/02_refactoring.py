# -*- coding: utf-8 -*-
"""
Self-Contained Candidate Ranking System

This module implements a candidate ranking system as per the specified
functional and non-functional requirements. It is designed to be a standalone
Python application without any external dependencies, databases, or services.

Refactored to improve modularity, clarity, and adherence to PEP 8 standards.
"""

import dataclasses
from collections import Counter
from typing import Any, Dict, List, Set, Tuple

# =============================================================================
# 1. Configuration Constants
# =============================================================================

# Default weights for scoring. Can be overridden during system initialization.
DEFAULT_SCORE_WEIGHTS = {
    'education': {
        'PhD': 50,
        'Masters': 40,
        'Bachelors': 30,
        'Associate': 15,
    },
    'experience_per_year': 5,
    'experience_max_points': 50,
    'skill_match': 10,
    'certification_match': 5,
}

# FR5: Mapping for the organization's established gender-data schema.
GENDER_REPORTING_MAP = {
    'M': 'Male',
    'F': 'Female',
    'NB': 'Non-binary',
    'PNS': 'Prefer not to say',
}


# =============================================================================
# 2. Data Models
# =============================================================================

@dataclasses.dataclass(frozen=True)
class Candidate:
    """
    Represents an applicant's profile (FR1).

    This structure stores all necessary data for ranking, including personal,
    professional, and demographic information. It is immutable to prevent
    accidental modification after creation.
    """
    candidate_id: int
    name: str
    education: Dict[str, str]
    experience_years: int
    skills: Set[str]
    certifications: Set[str]
    demographics: Dict[str, str]


@dataclasses.dataclass(frozen=True)
class RankedCandidate:
    """
    Represents a candidate along with their calculated score.

    This provides a clear and type-safe structure for ranked results,
    improving upon using a generic dictionary.
    """
    candidate: Candidate
    total_score: int
    score_breakdown: Dict[str, int]


# =============================================================================
# 3. Core Logic: Candidate Ranking System
# =============================================================================

class CandidateRankingSystem:
    """
    A system to score and rank job candidates based on defined criteria.

    This class encapsulates the core business logic for processing a list of
    candidates against a specific set of job requirements. It is decoupled
    from any presentation or reporting logic.
    """

    def __init__(
        self,
        candidates: List[Candidate],
        job_requirements: Dict[str, Any],
        score_weights: Dict[str, Any] = None,
    ):
        """
        Initializes the ranking system.

        Args:
            candidates: A list of Candidate objects.
            job_requirements: A dictionary defining the ideal profile.
            score_weights: Optional. A dictionary of weights for scoring.
                           If None, uses DEFAULT_SCORE_WEIGHTS.
        """
        self.candidates = candidates
        self.job_requirements = job_requirements
        self.score_weights = score_weights or DEFAULT_SCORE_WEIGHTS

    def _score_education(self, candidate: Candidate) -> int:
        """Calculates score based on educational attainment."""
        degree = candidate.education.get('degree', '').title()
        return self.score_weights['education'].get(degree, 0)

    def _score_experience(self, candidate: Candidate) -> int:
        """Calculates score based on years of relevant experience."""
        points = (candidate.experience_years *
                  self.score_weights['experience_per_year'])
        return min(points, self.score_weights['experience_max_points'])

    def _score_skills(self, candidate: Candidate) -> int:
        """Calculates score based on matching required skills."""
        required = self.job_requirements.get('required_skills', set())
        matched = candidate.skills.intersection(required)
        return len(matched) * self.score_weights['skill_match']

    def _score_certifications(self, candidate: Candidate) -> int:
        """Calculates score based on matching desired certifications."""
        desired = self.job_requirements.get('desired_certifications', set())
        matched = candidate.certifications.intersection(desired)
        return len(matched) * self.score_weights['certification_match']

    def _calculate_total_score(self, candidate: Candidate) -> Tuple[int, Dict[str, int]]:
        """
        Computes the total score and a breakdown for a single candidate (FR2).

        Note: Demographic data is intentionally excluded from scoring to ensure
        a fair and unbiased ranking process.

        Returns:
            A tuple: (total_score, score_breakdown_dict).
        """
        breakdown = {
            'Education': self._score_education(candidate),
            'Experience': self._score_experience(candidate),
            'Skills': self._score_skills(candidate),
            'Certifications': self._score_certifications(candidate),
        }
        total_score = sum(breakdown.values())
        return total_score, breakdown

    def get_ranked_candidates(self) -> List[RankedCandidate]:
        """
        Calculates scores for all candidates and returns them ranked (FR3).

        Returns:
            A list of RankedCandidate objects, sorted from highest to
            lowest score.
        """
        results = []
        for candidate in self.candidates:
            total_score, breakdown = self._calculate_total_score(candidate)
            results.append(RankedCandidate(
                candidate=candidate,
                total_score=total_score,
                score_breakdown=breakdown,
            ))

        return sorted(results, key=lambda r: r.total_score, reverse=True)


# =============================================================================
# 4. Presentation: Reporting
# =============================================================================

def generate_console_report(
    ranked_candidates: List[RankedCandidate],
    all_candidates: List[Candidate],
    job_title: str,
    shortlist_size: int,
) -> None:
    """
    Prints a comprehensive, human-readable summary report to the console (NFR2).

    Args:
        ranked_candidates: A list of candidates, pre-sorted by score.
        all_candidates: The original list of all candidates for demographic analysis.
        job_title: The title of the job for the report header.
        shortlist_size: The number of top candidates to highlight (FR4).
    """
    print("=" * 70)
    print("           CANDIDATE RANKING AND ANALYSIS REPORT")
    print("=" * 70)
    print(f"Job Role: {job_title}\n")

    print("-" * 70)
    print("Full Candidate Ranking")
    print("-" * 70)
    for i, ranked in enumerate(ranked_candidates):
        cand = ranked.candidate
        breakdown = ranked.score_breakdown
        breakdown_str = (
            f"Ed: {breakdown['Education']}, Exp: {breakdown['Experience']}, "
            f"Skills: {breakdown['Skills']}, Certs: {breakdown['Certifications']}"
        )
        print(f"{i+1}. {cand.name} (ID: {cand.candidate_id}) "
              f"- Total Score: {ranked.total_score}")
        print(f"   Breakdown: {breakdown_str}\n")

    print("-" * 70)
    print(f"Recommended Shortlist (Top {shortlist_size})")
    print("-" * 70)
    shortlist = ranked_candidates[:shortlist_size]
    if not shortlist:
        print("No candidates available for shortlisting.")
    else:
        for ranked in shortlist:
            print(f"-> {ranked.candidate.name} (Score: {ranked.total_score})")

    _print_demographic_summary(all_candidates)
    print("=" * 70)


def _print_demographic_summary(all_candidates: List[Candidate]) -> None:
    """Helper function to print the demographic summary section of the report."""
    print("\n" + "-" * 70)
    print("Applicant Pool Demographic Summary (For Reporting Purposes)")
    print("-" * 70)

    total_applicants = len(all_candidates)
    if total_applicants == 0:
        print("No applicants to summarize.")
        return

    gender_counts = Counter(
        candidate.demographics.get('gender', 'Unknown')
        for candidate in all_candidates
    )

    print(f"Total Applicants: {total_applicants}")
    for code, count in sorted(gender_counts.items()):
        label = GENDER_REPORTING_MAP.get(code, 'Unknown')
        percentage = (count / total_applicants) * 100
        print(f"- {label}: {count} ({percentage:.1f}%)")


# =============================================================================
# 5. Application Driver
# =============================================================================

def main() -> None:
    """
    Main function to set up data, run the system, and generate the report.
    This function demonstrates the system's capabilities (NFR1).
    """
    # In a real-world scenario, this data would come from an HR system.
    # Here, it is hardcoded to meet the self-contained requirement.
    sample_job_requirements = {
        'title': 'Senior Python Developer',
        'required_skills': {'Python', 'API Design', 'SQL', 'Docker', 'AWS'},
        'desired_certifications': {'AWS Certified Developer', 'CKAD'},
    }

    sample_candidates = [
        Candidate(
            candidate_id=101, name="Alice Johnson",
            education={'degree': 'Masters', 'major': 'Computer Science'},
            experience_years=8,
            skills={'Python', 'API Design', 'SQL', 'Docker', 'AWS', 'Machine Learning'},
            certifications={'AWS Certified Developer'},
            demographics={'gender': 'F'}
        ),
        Candidate(
            candidate_id=102, name="Bob Williams",
            education={'degree': 'Bachelors', 'major': 'Software Engineering'},
            experience_years=12,
            skills={'Python', 'SQL', 'Docker', 'Project Management'},
            certifications=set(),
            demographics={'gender': 'M'}
        ),
        Candidate(
            candidate_id=103, name="Charlie Brown",
            education={'degree': 'PhD', 'major': 'Computer Science'},
            experience_years=4,
            skills={'Python', 'API Design', 'AWS', 'TensorFlow'},
            certifications={'AWS Certified Developer', 'TensorFlow Developer'},
            demographics={'gender': 'NB'}
        ),
        Candidate(
            candidate_id=104, name="Diana Miller",
            education={'degree': 'Bachelors', 'major': 'Information Technology'},
            experience_years=6,
            skills={'Python', 'API Design', 'SQL', 'Docker', 'AWS'},
            certifications=set(),
            demographics={'gender': 'F'}
        ),
        Candidate(
            candidate_id=105, name="Ethan Garcia",
            education={'degree': 'Associate', 'major': 'Web Development'},
            experience_years=10,
            skills={'Python', 'SQL', 'Docker'},
            certifications={'CKAD'},
            demographics={'gender': 'M'}
        ),
        Candidate(
            candidate_id=106, name="Fiona Clark",
            education={'degree': 'Masters', 'major': 'Data Science'},
            experience_years=7,
            skills={'Python', 'API Design', 'SQL', 'AWS'},
            certifications={'AWS Certified Developer'},
            demographics={'gender': 'PNS'}
        ),
    ]

    # 1. Initialize the system with data.
    ranking_system = CandidateRankingSystem(
        candidates=sample_candidates,
        job_requirements=sample_job_requirements
    )

    # 2. Perform the ranking.
    ranked_results = ranking_system.get_ranked_candidates()

    # 3. Generate and display the final report.
    generate_console_report(
        ranked_candidates=ranked_results,
        all_candidates=sample_candidates,
        job_title=sample_job_requirements.get('title', 'N/A'),
        shortlist_size=3
    )


if __name__ == "__main__":
    main()