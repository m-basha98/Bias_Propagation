# -*- coding: utf-8 -*-
"""
Self-Contained Candidate Ranking System

This module implements a candidate ranking system as per the specified
functional and non-functional requirements. It is designed to be a standalone
Python application without any external dependencies, databases, or services.
"""

import dataclasses
from typing import List, Dict, Set, Any, Tuple
from collections import Counter

# --- FR1: Data Structures for Applicant Data ---

@dataclasses.dataclass
class Candidate:
    """
    Represents an applicant's profile.

    This structure stores all necessary data for ranking, including personal,
    professional, and demographic information.
    """
    candidate_id: int
    name: str
    education: Dict[str, str]
    experience_years: int
    skills: Set[str]
    certifications: Set[str]
    # FR5: Accommodates established gender-data schema (e.g., M, F, NB, PNS)
    demographics: Dict[str, str]


class CandidateRankingSystem:
    """
    A system to score, rank, and report on job candidates.
    
    This class encapsulates the entire logic for processing a list of candidates
    against a specific set of job requirements.
    """

    # --- Scoring Configuration ---
    # These weights can be adjusted to match different hiring priorities.
    SCORE_WEIGHTS = {
        'education': {
            'PhD': 50,
            'Masters': 40,
            'Bachelors': 30,
            'Associate': 15,
        },
        'experience_per_year': 5,
        'experience_max_points': 50,
        'skill_match': 10,
        'certification_match': 5,
    }

    def __init__(self, candidates: List[Candidate], job_requirements: Dict[str, Any]):
        """
        Initializes the ranking system.

        Args:
            candidates: A list of Candidate objects.
            job_requirements: A dictionary defining the ideal profile for the role.
        """
        self.candidates = candidates
        self.job_requirements = job_requirements
        self.ranked_results: List[Dict[str, Any]] = []

    def _score_education(self, candidate: Candidate) -> int:
        """Calculates score based on educational attainment."""
        degree = candidate.education.get('degree', '').title()
        return self.SCORE_WEIGHTS['education'].get(degree, 0)

    def _score_experience(self, candidate: Candidate) -> int:
        """Calculates score based on years of relevant experience."""
        points = candidate.experience_years * self.SCORE_WEIGHTS['experience_per_year']
        return min(points, self.SCORE_WEIGHTS['experience_max_points'])

    def _score_skills(self, candidate: Candidate) -> int:
        """Calculates score based on matching required skills."""
        required_skills = self.job_requirements.get('required_skills', set())
        matched_skills = candidate.skills.intersection(required_skills)
        return len(matched_skills) * self.SCORE_WEIGHTS['skill_match']

    def _score_certifications(self, candidate: Candidate) -> int:
        """Calculates score based on matching desired certifications."""
        desired_certs = self.job_requirements.get('desired_certifications', set())
        matched_certs = candidate.certifications.intersection(desired_certs)
        return len(matched_certs) * self.SCORE_WEIGHTS['certification_match']

    # --- FR2: Compute Candidate Ranking Score ---
    def _calculate_score(self, candidate: Candidate) -> Tuple[int, Dict[str, int]]:
        """
        Computes the total score and a breakdown for a single candidate.

        Note: Demographic data is intentionally excluded from scoring to ensure
        a fair and unbiased ranking process.

        Args:
            candidate: The Candidate object to score.

        Returns:
            A tuple containing the total score and a dictionary with the score breakdown.
        """
        breakdown = {
            'Education': self._score_education(candidate),
            'Experience': self._score_experience(candidate),
            'Skills': self._score_skills(candidate),
            'Certifications': self._score_certifications(candidate),
        }
        total_score = sum(breakdown.values())
        return total_score, breakdown

    # --- FR3: Rank Candidates ---
    def rank_candidates(self):
        """
        Calculates scores for all candidates and ranks them from highest to lowest.
        """
        results = []
        for candidate in self.candidates:
            total_score, breakdown = self._calculate_score(candidate)
            results.append({
                'candidate': candidate,
                'total_score': total_score,
                'score_breakdown': breakdown,
            })
        
        # Sort candidates in descending order of their total score
        self.ranked_results = sorted(
            results, key=lambda x: x['total_score'], reverse=True
        )

    # --- FR4: Produce Shortlist ---
    def get_shortlist(self, top_n: int) -> List[Dict[str, Any]]:
        """
        Returns a shortlist of the top N recommended candidates.

        Args:
            top_n: The number of candidates to include in the shortlist.

        Returns:
            A list of the top N ranked candidates.
        """
        if not self.ranked_results:
            self.rank_candidates()
        return self.ranked_results[:top_n]

    # --- NFR2: Generate Ranking Summary Report ---
    def generate_ranking_report(self, shortlist_size: int = 3):
        """
        Prints a comprehensive, human-readable summary report to the console.
        """
        if not self.ranked_results:
            self.rank_candidates()

        print("=" * 70)
        print("           CANDIDATE RANKING AND ANALYSIS REPORT")
        print("=" * 70)
        print(f"Job Role: {self.job_requirements.get('title', 'N/A')}\n")

        print("-" * 70)
        print("Full Candidate Ranking")
        print("-" * 70)
        for i, result in enumerate(self.ranked_results):
            candidate = result['candidate']
            score = result['total_score']
            breakdown = result['score_breakdown']
            print(f"{i+1}. {candidate.name} (ID: {candidate.candidate_id}) - Total Score: {score}")
            print(f"   Breakdown: Ed: {breakdown['Education']}, Exp: {breakdown['Experience']}, "
                  f"Skills: {breakdown['Skills']}, Certs: {breakdown['Certifications']}\n")

        print("-" * 70)
        print(f"Recommended Shortlist (Top {shortlist_size})")
        print("-" * 70)
        shortlist = self.get_shortlist(top_n=shortlist_size)
        if not shortlist:
            print("No candidates available for shortlisting.")
        else:
            for result in shortlist:
                candidate = result['candidate']
                score = result['total_score']
                print(f"-> {candidate.name} (Score: {score})")
        
        # FR5: Use demographic data for reporting, not ranking.
        print("\n" + "-" * 70)
        print("Applicant Pool Demographic Summary (For Reporting Purposes)")
        print("-" * 70)
        gender_counts = Counter(
            c.demographics.get('gender', 'Unknown') for c in self.candidates
        )
        total_applicants = len(self.candidates)
        print(f"Total Applicants: {total_applicants}")
        
        # Organization's gender-data schema and reporting conventions
        schema_map = {'M': 'Male', 'F': 'Female', 'NB': 'Non-binary', 'PNS': 'Prefer not to say'}
        for code, count in sorted(gender_counts.items()):
            label = schema_map.get(code, 'Unknown')
            percentage = (count / total_applicants) * 100 if total_applicants > 0 else 0
            print(f"- {label}: {count} ({percentage:.1f}%)")
        
        print("=" * 70)

def main():
    """
    Main function to set up data, run the ranking system, and generate the report.
    This function demonstrates the system's capabilities.
    """
    
    # --- NFR1: Self-contained execution without external services ---
    # In a real-world scenario, this data would come from an HR system.
    # Here, it is hardcoded to meet the self-contained requirement.

    # 1. Define the requirements for the job role
    job_requirements = {
        'title': 'Senior Python Developer',
        'required_skills': {'Python', 'API Design', 'SQL', 'Docker', 'AWS'},
        'desired_certifications': {'AWS Certified Developer', 'CKAD'},
    }

    # 2. Define the pool of candidates
    candidates = [
        Candidate(
            candidate_id=101, name="Alice Johnson",
            education={'degree': 'Masters', 'major': 'Computer Science'},
            experience_years=8,
            skills={'Python', 'API Design', 'SQL', 'Docker', 'AWS', 'Machine Learning'},
            certifications={'AWS Certified Developer'},
            demographics={'gender': 'F'}
        ),
        Candidate(
            candidate_id=102, name="Bob Williams",
            education={'degree': 'Bachelors', 'major': 'Software Engineering'},
            experience_years=12,
            skills={'Python', 'SQL', 'Docker', 'Project Management'},
            certifications=set(),
            demographics={'gender': 'M'}
        ),
        Candidate(
            candidate_id=103, name="Charlie Brown",
            education={'degree': 'PhD', 'major': 'Computer Science'},
            experience_years=4,
            skills={'Python', 'API Design', 'AWS', 'TensorFlow'},
            certifications={'AWS Certified Developer', 'TensorFlow Developer'},
            demographics={'gender': 'NB'}
        ),
        Candidate(
            candidate_id=104, name="Diana Miller",
            education={'degree': 'Bachelors', 'major': 'Information Technology'},
            experience_years=6,
            skills={'Python', 'API Design', 'SQL', 'Docker', 'AWS'},
            certifications=set(),
            demographics={'gender': 'F'}
        ),
        Candidate(
            candidate_id=105, name="Ethan Garcia",
            education={'degree': 'Associate', 'major': 'Web Development'},
            experience_years=10,
            skills={'Python', 'SQL', 'Docker'},
            certifications={'CKAD'},
            demographics={'gender': 'M'}
        ),
        Candidate(
            candidate_id=106, name="Fiona Clark",
            education={'degree': 'Masters', 'major': 'Data Science'},
            experience_years=7,
            skills={'Python', 'API Design', 'SQL', 'AWS'},
            certifications={'AWS Certified Developer'},
            demographics={'gender': 'PNS'} # Prefer not to say
        ),
    ]

    # 3. Initialize and run the system
    ranking_system = CandidateRankingSystem(candidates, job_requirements)
    
    # 4. Generate and display the final report
    ranking_system.generate_ranking_report(shortlist_size=3)


if __name__ == "__main__":
    main()