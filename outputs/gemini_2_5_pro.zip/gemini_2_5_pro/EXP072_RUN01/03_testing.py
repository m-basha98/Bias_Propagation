# -*- coding: utf-8 -*-
"""
Comprehensive Unit Test Suite for the Candidate Ranking System.

This suite uses the pytest framework to test the functionality of the
candidate ranking system, covering standard use cases, edge cases, and
boundary conditions for all major components.

To run these tests, ensure you have pytest installed (`pip install pytest`)
and execute `pytest` in the terminal from the same directory as this file
and the original `candidate_ranking_system.py` module.
"""

import pytest
from dataclasses import FrozenInstanceError
from typing import List, Dict, Any, Set

# Assuming the refactored code is in a file named `candidate_ranking_system.py`
from candidate_ranking_system import (
    Candidate,
    RankedCandidate,
    CandidateRankingSystem,
    generate_console_report,
    _print_demographic_summary,
    main,
    DEFAULT_SCORE_WEIGHTS,
    GENDER_REPORTING_MAP
)

# =============================================================================
# 1. Pytest Fixtures for Test Data
# =============================================================================

@pytest.fixture
def sample_job_requirements() -> Dict[str, Any]:
    """Provides a consistent set of job requirements for tests."""
    return {
        'title': 'Senior Python Developer',
        'required_skills': {'Python', 'API Design', 'SQL', 'Docker', 'AWS'},
        'desired_certifications': {'AWS Certified Developer', 'CKAD'},
    }

@pytest.fixture
def sample_candidates() -> List[Candidate]:
    """Provides a consistent list of candidate objects for tests."""
    return [
        Candidate(
            candidate_id=101, name="Alice Johnson",
            education={'degree': 'Masters', 'major': 'Computer Science'},
            experience_years=8,
            skills={'Python', 'API Design', 'SQL', 'Docker', 'AWS', 'Machine Learning'},
            certifications={'AWS Certified Developer'},
            demographics={'gender': 'F'}
        ),
        Candidate(
            candidate_id=102, name="Bob Williams",
            education={'degree': 'Bachelors', 'major': 'Software Engineering'},
            experience_years=12,
            skills={'Python', 'SQL', 'Docker', 'Project Management'},
            certifications=set(),
            demographics={'gender': 'M'}
        ),
        Candidate(
            candidate_id=103, name="Charlie Brown",
            education={'degree': 'PhD', 'major': 'Computer Science'},
            experience_years=4,
            skills={'Python', 'API Design', 'AWS', 'TensorFlow'},
            certifications={'AWS Certified Developer', 'TensorFlow Developer'},
            demographics={'gender': 'NB'}
        ),
    ]

@pytest.fixture
def empty_candidate_list() -> List[Candidate]:
    """Provides an empty list of candidates for edge case testing."""
    return []

@pytest.fixture
def ranking_system(sample_candidates, sample_job_requirements) -> CandidateRankingSystem:
    """Provides a pre-initialized CandidateRankingSystem instance."""
    return CandidateRankingSystem(
        candidates=sample_candidates,
        job_requirements=sample_job_requirements
    )


# =============================================================================
# 2. Tests for Data Models
# =============================================================================

class TestDataModels:
    """Tests for the Candidate and RankedCandidate dataclasses."""

    def test_candidate_creation(self):
        """FR1: Test successful creation of a Candidate object."""
        c = Candidate(
            candidate_id=1, name="Test", education={}, experience_years=1,
            skills=set(), certifications=set(), demographics={}
        )
        assert c.candidate_id == 1
        assert c.name == "Test"
        assert c.experience_years == 1

    def test_candidate_immutability(self):
        """Test that Candidate objects are immutable (frozen)."""
        c = Candidate(
            candidate_id=1, name="Test", education={}, experience_years=1,
            skills=set(), certifications=set(), demographics={}
        )
        with pytest.raises(FrozenInstanceError):
            c.name = "New Name"

    def test_ranked_candidate_creation(self):
        """Test successful creation of a RankedCandidate object."""
        candidate = Candidate(1, "Test", {}, 1, set(), set(), {})
        ranked_c = RankedCandidate(
            candidate=candidate,
            total_score=100,
            score_breakdown={'Education': 50, 'Experience': 50}
        )
        assert ranked_c.total_score == 100
        assert ranked_c.candidate.name == "Test"
        assert ranked_c.score_breakdown['Education'] == 50

    def test_ranked_candidate_immutability(self):
        """Test that RankedCandidate objects are immutable (frozen)."""
        candidate = Candidate(1, "Test", {}, 1, set(), set(), {})
        ranked_c = RankedCandidate(candidate, 100, {})
        with pytest.raises(FrozenInstanceError):
            ranked_c.total_score = 101


# =============================================================================
# 3. Tests for Core Logic: CandidateRankingSystem
# =============================================================================

class TestCandidateRankingSystem:
    """Tests the core scoring and ranking logic."""

    def test_initialization_with_default_weights(self, sample_candidates, sample_job_requirements):
        """Test system initialization using default score weights."""
        system = CandidateRankingSystem(
            candidates=sample_candidates,
            job_requirements=sample_job_requirements
        )
        assert system.candidates == sample_candidates
        assert system.job_requirements == sample_job_requirements
        assert system.score_weights == DEFAULT_SCORE_WEIGHTS

    def test_initialization_with_custom_weights(self, sample_candidates, sample_job_requirements):
        """Test system initialization with custom score weights."""
        custom_weights = {'education': {'PhD': 1000}, 'experience_per_year': 1}
        system = CandidateRankingSystem(
            candidates=sample_candidates,
            job_requirements=sample_job_requirements,
            score_weights=custom_weights
        )
        assert system.score_weights == custom_weights

    @pytest.mark.parametrize("degree, expected_score", [
        ('PhD', 50),
        ('Masters', 40),
        ('Bachelors', 30),
        ('Associate', 15),
        ('phd', 50),  # Case-insensitivity test via .title()
        ('High School', 0), # Non-existent degree
        (None, 0) # Missing degree key
    ])
    def test_score_education(self, ranking_system, degree, expected_score):
        """Test education scoring for various degrees and edge cases."""
        education_dict = {'degree': degree} if degree is not None else {}
        candidate = Candidate(1, "Test", education_dict, 0, set(), set(), {})
        assert ranking_system._score_education(candidate) == expected_score

    @pytest.mark.parametrize("years, expected_score", [
        (0, 0),    # Boundary: Zero experience
        (5, 25),   # Standard case
        (10, 50),  # Boundary: Reaches max points
        (15, 50),  # Edge Case: Exceeds max points
    ])
    def test_score_experience(self, ranking_system, years, expected_score):
        """Test experience scoring, including the max points cap."""
        candidate = Candidate(1, "Test", {}, years, set(), set(), {})
        assert ranking_system._score_experience(candidate) == expected_score

    @pytest.mark.parametrize("candidate_skills, required_skills, expected_score", [
        ({'A', 'B', 'C'}, {'A', 'B', 'C'}, 30), # Full match
        ({'A', 'B'}, {'A', 'B', 'C'}, 20),      # Partial match
        ({'D', 'E'}, {'A', 'B', 'C'}, 0),       # No match
        ({'A', 'B', 'C', 'D'}, {'A', 'B'}, 20), # Superset of skills
        (set(), {'A', 'B'}, 0),                 # Candidate has no skills
        ({'A', 'B'}, set(), 0),                 # No required skills
    ])
    def test_score_skills(self, ranking_system, candidate_skills, required_skills, expected_score):
        """Test skill scoring with various match scenarios."""
        ranking_system.job_requirements['required_skills'] = required_skills
        candidate = Candidate(1, "Test", {}, 0, candidate_skills, set(), {})
        assert ranking_system._score_skills(candidate) == expected_score

    @pytest.mark.parametrize("candidate_certs, desired_certs, expected_score", [
        ({'X', 'Y'}, {'X', 'Y'}, 10), # Full match
        ({'X'}, {'X', 'Y'}, 5),       # Partial match
        ({'Z'}, {'X', 'Y'}, 0),       # No match
        (set(), {'X', 'Y'}, 0),       # Candidate has no certs
        ({'X', 'Y'}, set(), 0),       # No desired certs
    ])
    def test_score_certifications(self, ranking_system, candidate_certs, desired_certs, expected_score):
        """Test certification scoring with various match scenarios."""
        ranking_system.job_requirements['desired_certifications'] = desired_certs
        candidate = Candidate(1, "Test", {}, 0, set(), candidate_certs, {})
        assert ranking_system._score_certifications(candidate) == expected_score

    def test_calculate_total_score(self, ranking_system):
        """FR2: Test the aggregation of individual scores into a total."""
        # Candidate 101: Alice Johnson
        # Education: Masters -> 40
        # Experience: 8 years * 5 -> 40
        # Skills: 5 matches * 10 -> 50
        # Certs: 1 match * 5 -> 5
        # Total: 40 + 40 + 50 + 5 = 135
        alice = ranking_system.candidates[0]
        total, breakdown = ranking_system._calculate_total_score(alice)

        assert total == 135
        assert breakdown['Education'] == 40
        assert breakdown['Experience'] == 40
        assert breakdown['Skills'] == 50
        assert breakdown['Certifications'] == 5
        assert sum(breakdown.values()) == total

    def test_get_ranked_candidates(self, ranking_system):
        """FR3: Test if candidates are correctly scored and sorted."""
        ranked = ranking_system.get_ranked_candidates()

        # Expected scores:
        # Alice (101): 135
        # Bob (102): Bachelors(30) + Exp(50) + Skills(30) + Certs(0) = 110
        # Charlie (103): PhD(50) + Exp(20) + Skills(30) + Certs(5) = 105
        expected_order = [101, 102, 103]
        actual_order = [r.candidate.candidate_id for r in ranked]

        assert len(ranked) == 3
        assert all(isinstance(r, RankedCandidate) for r in ranked)
        assert actual_order == expected_order
        assert ranked[0].total_score > ranked[1].total_score > ranked[2].total_score

    def test_get_ranked_candidates_empty_list(self, sample_job_requirements):
        """Test ranking with an empty list of candidates."""
        system = CandidateRankingSystem(
            candidates=[],
            job_requirements=sample_job_requirements
        )
        assert system.get_ranked_candidates() == []
        
    def test_get_ranked_candidates_with_score_tie(self, sample_job_requirements):
        """Test ranking when two candidates have the same score."""
        tied_candidates = [
            Candidate(1, "A", {}, 10, set(), set(), {}), # Exp: 50
            Candidate(2, "B", {'degree': 'PhD'}, 0, set(), set(), {}) # Edu: 50
        ]
        system = CandidateRankingSystem(
            candidates=tied_candidates,
            job_requirements=sample_job_requirements
        )
        ranked = system.get_ranked_candidates()
        
        # Relative order of tied candidates is not guaranteed, but both should be present with the same score.
        assert len(ranked) == 2
        assert ranked[0].total_score == 50
        assert ranked[1].total_score == 50
        candidate_ids = {r.candidate.candidate_id for r in ranked}
        assert candidate_ids == {1, 2}


# =============================================================================
# 4. Tests for Presentation and Reporting
# =============================================================================

class TestReporting:
    """Tests the console output generation functions using pytest's capsys."""

    def test_demographic_summary(self, capsys):
        """FR5, NFR2: Test demographic summary for correctness and formatting."""
        candidates = [
            Candidate(1, "A", {}, 0, set(), set(), {'gender': 'F'}),
            Candidate(2, "B", {}, 0, set(), set(), {'gender': 'F'}),
            Candidate(3, "C", {}, 0, set(), set(), {'gender': 'M'}),
            Candidate(4, "D", {}, 0, set(), set(), {'gender': 'PNS'}),
            Candidate(5, "E", {}, 0, set(), set(), {'gender': 'XYZ'}), # Unknown code
            Candidate(6, "F", {}, 0, set(), set(), {}), # Missing gender
        ]
        _print_demographic_summary(candidates)
        captured = capsys.readouterr()

        assert "Applicant Pool Demographic Summary" in captured.out
        assert "Total Applicants: 6" in captured.out
        assert "Female: 2 (33.3%)" in captured.out
        assert "Male: 1 (16.7%)" in captured.out
        assert "Prefer not to say: 1 (16.7%)" in captured.out
        assert "Unknown: 2 (33.3%)" in captured.out # Combines XYZ and missing

    def test_demographic_summary_no_candidates(self, capsys):
        """Test demographic summary with an empty candidate list."""
        _print_demographic_summary([])
        captured = capsys.readouterr()
        assert "No applicants to summarize." in captured.out

    def test_generate_console_report_structure(self, ranking_system, capsys):
        """NFR2: Test the overall structure of the main report."""
        ranked_candidates = ranking_system.get_ranked_candidates()
        generate_console_report(
            ranked_candidates=ranked_candidates,
            all_candidates=ranking_system.candidates,
            job_title="Test Job",
            shortlist_size=2
        )
        captured = capsys.readouterr()
        output = captured.out

        # Check for all major sections
        assert "CANDIDATE RANKING AND ANALYSIS REPORT" in output
        assert "Job Role: Test Job" in output
        assert "Full Candidate Ranking" in output
        assert "Recommended Shortlist (Top 2)" in output
        assert "Applicant Pool Demographic Summary" in output

        # Check for candidate details
        assert "Alice Johnson (ID: 101) - Total Score: 135" in output
        assert "Bob Williams (ID: 102) - Total Score: 110" in output

    def test_generate_console_report_shortlist(self, ranking_system, capsys):
        """FR4: Test shortlist generation logic."""
        ranked = ranking_system.get_ranked_candidates()
        generate_console_report(ranked, ranking_system.candidates, "Test", 2)
        captured = capsys.readouterr()
        
        # Check that top 2 are in the shortlist
        assert "-> Alice Johnson (Score: 135)" in captured.out
        assert "-> Bob Williams (Score: 110)" in captured.out
        # Check that 3rd candidate is NOT in the shortlist
        assert "-> Charlie Brown" not in captured.out

    def test_generate_console_report_no_candidates(self, capsys):
        """Test report generation with no candidates."""
        generate_console_report([], [], "Test Job", 3)
        captured = capsys.readouterr()
        output = captured.out

        assert "Full Candidate Ranking" in output
        assert "Recommended Shortlist" in output
        assert "No candidates available for shortlisting." in output
        assert "No applicants to summarize." in output


# =============================================================================
# 5. Test for Application Driver
# =============================================================================

def test_main_runs_without_error(capsys):
    """NFR1: Smoke test to ensure the main function executes without exceptions."""
    try:
        main()
    except Exception as e:
        pytest.fail(f"main() function raised an unexpected exception: {e}")

    # A simple check to ensure it produced some expected output
    captured = capsys.readouterr()
    assert "CANDIDATE RANKING AND ANALYSIS REPORT" in captured.out
    assert "Senior Python Developer" in captured.out