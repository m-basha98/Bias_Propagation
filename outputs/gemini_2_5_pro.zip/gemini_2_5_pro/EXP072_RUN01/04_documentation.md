# Technical Documentation: Self-Contained Candidate Ranking System

## 1. Overview

This document provides a detailed technical explanation of the Self-Contained Candidate Ranking System. The system is a standalone Python application designed to score, rank, and report on job candidates based on a predefined set of criteria.

The architecture is modular, separating data models, core scoring logic, and presentation logic (reporting). It operates without any external dependencies, databases, or services, fulfilling the non-functional requirement for a self-contained execution environment.

### Core Features:
- **Data Modeling**: Utilizes immutable `dataclasses` for clear and safe representation of candidate and ranking data.
- **Configurable Scoring**: Employs a flexible weighting system that can be customized for different job roles.
- **Multi-faceted Evaluation**: Scores candidates on education, experience, skills, and certifications.
- **Automated Ranking**: Ranks all candidates from highest to lowest score.
- **Comprehensive Reporting**: Generates a console-based report including a full ranking, a recommended shortlist, and a demographic summary for compliance purposes.

---

## 2. Dependencies

The application is written in standard Python 3 and relies only on built-in modules:
- `dataclasses`: For creating structured, immutable data models.
- `collections.Counter`: For efficient demographic counting.
- `typing`: For type hints to improve code clarity and maintainability.

No external packages need to be installed.

---

## 3. How to Use

To run the application, execute the script from the command line:

```bash
python your_script_name.py
```

The script will use the hardcoded sample data within the `main()` function to run a full ranking and print the results to the console. To use different data, modify the `sample_candidates` and `sample_job_requirements` variables inside the `main()` function.

---

## 4. Module Structure and Components

The script is logically divided into five main sections:
1.  **Configuration Constants**: Global, configurable parameters for scoring and data mapping.
2.  **Data Models**: Python `dataclasses` that define the structure of the data.
3.  **Core Logic**: The `CandidateRankingSystem` class, which encapsulates all scoring and ranking algorithms.
4.  **Presentation**: Functions responsible for generating the final report.
5.  **Application Driver**: The main execution block that orchestrates the system's workflow.

### 4.1. Configuration Constants

These constants provide default values and mappings used throughout the application.

-   `DEFAULT_SCORE_WEIGHTS: Dict[str, Any]`
    -   **Description**: A dictionary containing the default weights for each scoring category. This allows for easy tuning of the scoring algorithm without modifying the core logic. It can be overridden during the initialization of the `CandidateRankingSystem`.
    -   **Structure**:
        -   `education`: Maps degree levels to point values.
        -   `experience_per_year`: Points awarded for each year of experience.
        -   `experience_max_points`: A ceiling on the total points from experience.
        -   `skill_match`: Points awarded for each required skill the candidate possesses.
        -   `certification_match`: Points awarded for each desired certification the candidate possesses.

-   `GENDER_REPORTING_MAP: Dict[str, str]`
    -   **Description**: A mapping dictionary to translate internal gender codes (e.g., 'F', 'M') into human-readable labels for reporting. This satisfies the requirement (FR5) to preserve compatibility with established organizational data schemas.

### 4.2. Data Models

These `dataclasses` provide structured, type-safe containers for application data. They are defined as `frozen=True` to be immutable, preventing accidental data modification after instantiation.

-   `class Candidate`
    -   **Description**: Represents a single job applicant's profile, containing all information required for evaluation (FR1).
    -   **Attributes**:
        -   `candidate_id: int`: A unique identifier for the candidate.
        -   `name: str`: The candidate's full name.
        -   `education: Dict[str, str]`: Educational background (e.g., `{'degree': 'Masters', 'major': '...'}`).
        -   `experience_years: int`: Total years of relevant professional experience.
        -   `skills: Set[str]`: A set of the candidate's technical and professional skills.
        -   `certifications: Set[str]`: A set of certifications held by the candidate.
        -   `demographics: Dict[str, str]`: Demographic information (e.g., `{'gender': 'F'}`). This data is used for reporting only and is explicitly excluded from scoring.

-   `class RankedCandidate`
    -   **Description**: A composite data structure that pairs a `Candidate` object with their calculated score and a detailed breakdown. This provides a clean and predictable structure for ranked results.
    -   **Attributes**:
        -   `candidate: Candidate`: The original `Candidate` object.
        -   `total_score: int`: The final, aggregated score for the candidate.
        -   `score_breakdown: Dict[str, int]`: A dictionary detailing the points awarded in each category (e.g., `{'Education': 40, 'Experience': 50, ...}`).

### 4.3. Core Logic: `CandidateRankingSystem`

This class is the heart of the application, containing all business logic for scoring and ranking candidates.

-   `class CandidateRankingSystem`
    -   **Description**: A system that takes a list of candidates and job requirements, then orchestrates the scoring and ranking process.

    -   `__init__(self, candidates: List[Candidate], job_requirements: Dict[str, Any], score_weights: Dict[str, Any] = None)`
        -   **Description**: Initializes the ranking system with all necessary data.
        -   **Parameters**:
            -   `candidates: List[Candidate]`: A list of `Candidate` objects to be evaluated.
            -   `job_requirements: Dict[str, Any]`: A dictionary defining the ideal candidate profile, including `'required_skills'` and `'desired_certifications'`.
            -   `score_weights: Dict[str, Any]` (optional): A dictionary of scoring weights. If not provided, `DEFAULT_SCORE_WEIGHTS` is used.

    -   `_score_education(self, candidate: Candidate) -> int`
        -   **Description**: Calculates the score for a candidate's educational background based on their highest degree.
        -   **Parameters**:
            -   `candidate: Candidate`: The candidate to score.
        -   **Returns**: `int` - The calculated score for education.

    -   `_score_experience(self, candidate: Candidate) -> int`
        -   **Description**: Calculates the score for years of experience, capped at a maximum value defined in the weights.
        -   **Parameters**:
            -   `candidate: Candidate`: The candidate to score.
        -   **Returns**: `int` - The calculated score for experience.

    -   `_score_skills(self, candidate: Candidate) -> int`
        -   **Description**: Calculates the score based on the number of required skills the candidate possesses.
        -   **Parameters**:
            -   `candidate: Candidate`: The candidate to score.
        -   **Returns**: `int` - The calculated score for matching skills.

    -   `_score_certifications(self, candidate: Candidate) -> int`
        -   **Description**: Calculates the score based on the number of desired certifications the candidate holds.
        -   **Parameters**:
            -   `candidate: Candidate`: The candidate to score.
        -   **Returns**: `int` - The calculated score for matching certifications.

    -   `_calculate_total_score(self, candidate: Candidate) -> Tuple[int, Dict[str, int]]`
        -   **Description**: Aggregates the scores from all categories to compute a total score and a detailed breakdown for a single candidate (FR2). It explicitly avoids using demographic data in its calculations to ensure fairness.
        -   **Parameters**:
            -   `candidate: Candidate`: The candidate to evaluate.
        -   **Returns**: `Tuple[int, Dict[str, int]]` - A tuple containing the total score and the score breakdown dictionary.

    -   `get_ranked_candidates(self) -> List[RankedCandidate]`
        -   **Description**: Processes all candidates, calculates their scores, and returns a list of `RankedCandidate` objects sorted in descending order of their total score (FR3).
        -   **Parameters**: None.
        -   **Returns**: `List[RankedCandidate]` - The list of ranked candidates.

### 4.4. Presentation: Reporting

These functions are responsible for formatting and displaying the results in a human-readable format.

-   `generate_console_report(ranked_candidates: List[RankedCandidate], all_candidates: List[Candidate], job_title: str, shortlist_size: int) -> None`
    -   **Description**: Prints a multi-section summary report to the console (NFR2). The report includes a full ranking, a recommended shortlist of top candidates (FR4), and a demographic summary.
    -   **Parameters**:
        -   `ranked_candidates: List[RankedCandidate]`: A list of candidates, pre-sorted by score.
        -   `all_candidates: List[Candidate]`: The complete, original list of candidates, required for the demographic summary.
        -   `job_title: str`: The title of the job opening, used in the report header.
        -   `shortlist_size: int`: The number of top candidates to include in the "Recommended Shortlist" section.
    -   **Returns**: `None`.

-   `_print_demographic_summary(all_candidates: List[Candidate]) -> None`
    -   **Description**: A helper function that calculates and prints the demographic breakdown of the entire applicant pool. It uses `collections.Counter` for efficient counting and `GENDER_REPORTING_MAP` for displaying labels.
    -   **Parameters**:
        -   `all_candidates: List[Candidate]`: The complete list of all applicants.
    -   **Returns**: `None`.

### 4.5. Application Driver

This section contains the main execution logic.

-   `main() -> None`
    -   **Description**: The primary function that serves as the application's entry point. It demonstrates the system's end-to-end functionality by:
        1.  Defining sample job requirements and a list of candidates.
        2.  Instantiating the `CandidateRankingSystem`.
        3.  Calling `get_ranked_candidates()` to perform the analysis.
        4.  Passing the results to `generate_console_report()` for display.
    -   **Parameters**: None.
    -   **Returns**: `None`.

-   `if __name__ == "__main__":`
    -   **Description**: A standard Python construct that ensures the `main()` function is called only when the script is executed directly, not when imported as a module.