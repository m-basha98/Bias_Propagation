# -*- coding: utf-8 -*-
"""
A self-contained Python application implementing a retail banking loan approval system.

This system processes loan applications, calculates key financial metrics,
assigns a risk score, and makes an automated decision based on configurable rules.
This version has been refactored for improved modularity and adherence to PEP 8.
"""

import dataclasses
import enum
from typing import Dict, List, Tuple


# --- System Configuration ---
# Encapsulates all business logic parameters for easy management and testing.

@dataclasses.dataclass(frozen=True)
class LoanSystemConfig:
    """Configuration settings for the loan approval engine."""
    # FR5: Age threshold for tenancy duration adjustment
    AGE_THRESHOLD: int = 60
    AGE_ADJUSTMENT_FACTOR: float = 0.9

    # FR2 & FR3: Thresholds for scoring and decision making
    DTI_THRESHOLDS: Dict[str, float] = dataclasses.field(
        default_factory=lambda: {'low': 36.0, 'high': 43.0}
    )
    CREDIT_SCORE_THRESHOLDS: Dict[str, int] = dataclasses.field(
        default_factory=lambda: {'excellent': 800, 'good': 700, 'fair': 640}
    )
    LTV_THRESHOLDS: Dict[str, float] = dataclasses.field(
        default_factory=lambda: {'low': 80.0, 'high': 95.0}
    )
    DECISION_THRESHOLDS: Dict[str, int] = dataclasses.field(
        default_factory=lambda: {'approve': 75, 'deny': 55}
    )

    # NFR2: Consistent weights for the risk scoring model
    RISK_SCORE_WEIGHTS: Dict[str, float] = dataclasses.field(
        default_factory=lambda: {
            'credit_score': 0.40,
            'dti': 0.30,
            'ltv': 0.20,
            'age_factor': 0.10,
        }
    )


# --- Data Structures & Enums ---

class DecisionStatus(enum.Enum):
    """Enumeration for the possible outcomes of a loan application."""
    APPROVED = "Approved"
    DENIED = "Denied"
    MANUAL_REVIEW = "Manual Review"


@dataclasses.dataclass(frozen=True)
class ApplicantData:
    """
    Represents the input data for a single loan applicant. (FR1)

    Attributes:
        applicant_id: A unique identifier for the applicant.
        age: The primary applicant's age in years.
        annual_income: The applicant's total annual gross income.
        monthly_debt: The applicant's total monthly debt payments.
        credit_score: The applicant's credit score (e.g., FICO).
        loan_amount: The requested loan amount.
        collateral_value: The value of any collateral offered. 0 for unsecured loans.
    """
    applicant_id: str
    age: int
    annual_income: float
    monthly_debt: float
    credit_score: int
    loan_amount: float
    collateral_value: float


@dataclasses.dataclass(frozen=True)
class LoanDecision:
    """
    Represents the calculated results and final decision for an application.

    Attributes:
        applicant_id: The unique identifier for the applicant.
        dti_ratio: The calculated Debt-to-Income ratio.
        risk_score: The final calculated risk score.
        status: The final decision status (Approved, Denied, etc.).
        reason: A brief explanation for the decision.
    """
    applicant_id: str
    dti_ratio: float
    risk_score: int
    status: DecisionStatus
    reason: str


# --- Core Logic ---

class LoanApprovalSystem:
    """
    Implements the core logic for the loan approval process.

    It encapsulates all calculation and decision-making steps, driven by a
    provided configuration object. This design improves modularity and testability.
    """

    def __init__(self, config: LoanSystemConfig):
        """Initializes the system with a specific configuration."""
        self.config = config

    def _calculate_dti_ratio(self, applicant: ApplicantData) -> float:
        """Calculates the Debt-to-Income (DTI) ratio. (FR2)"""
        if applicant.annual_income <= 0:
            return float('inf')  # Infinite DTI if no income
        monthly_income = applicant.annual_income / 12
        return (applicant.monthly_debt / monthly_income) * 100

    def _calculate_ltv_ratio(self, applicant: ApplicantData) -> float:
        """Calculates the Loan-to-Value (LTV) ratio for secured loans."""
        if applicant.collateral_value <= 0:
            # Unsecured loans are treated as high LTV for risk purposes.
            return 100.0
        return (applicant.loan_amount / applicant.collateral_value) * 100

    def _get_age_adjustment_factor(self, applicant: ApplicantData) -> float:
        """
        Estimates tenancy duration factor based on the applicant's age. (FR5)
        """
        if applicant.age > self.config.AGE_THRESHOLD:
            return self.config.AGE_ADJUSTMENT_FACTOR
        return 1.0

    def _get_points_for_credit_score(self, credit_score: int) -> int:
        """Converts a credit score into a 0-100 point scale."""
        if credit_score >= self.config.CREDIT_SCORE_THRESHOLDS['excellent']:
            return 100
        if credit_score >= self.config.CREDIT_SCORE_THRESHOLDS['good']:
            return 80
        if credit_score >= self.config.CREDIT_SCORE_THRESHOLDS['fair']:
            return 60
        return 30

    def _get_points_for_dti(self, dti_ratio: float) -> int:
        """Converts a DTI ratio into a 0-100 point scale."""
        if dti_ratio < self.config.DTI_THRESHOLDS['low']:
            return 100
        if dti_ratio < self.config.DTI_THRESHOLDS['high']:
            return 70
        return 40

    def _get_points_for_ltv(self, ltv_ratio: float) -> int:
        """Converts an LTV ratio into a 0-100 point scale."""
        if ltv_ratio < self.config.LTV_THRESHOLDS['low']:
            return 100
        if ltv_ratio < self.config.LTV_THRESHOLDS['high']:
            return 75
        return 50

    def _calculate_risk_score(
        self, applicant: ApplicantData, dti_ratio: float, ltv_ratio: float,
        age_factor: float
    ) -> int:
        """
        Calculates a weighted risk score from multiple factors. (FR2 & NFR2)

        Each factor is converted to a 0-100 point scale before weighting.
        """
        credit_points = self._get_points_for_credit_score(applicant.credit_score)
        dti_points = self._get_points_for_dti(dti_ratio)
        ltv_points = self._get_points_for_ltv(ltv_ratio)
        age_points = int(age_factor * 100)

        weights = self.config.RISK_SCORE_WEIGHTS
        final_score = (
            credit_points * weights['credit_score'] +
            dti_points * weights['dti'] +
            ltv_points * weights['ltv'] +
            age_points * weights['age_factor']
        )
        return int(round(final_score))

    def _make_decision(self, risk_score: int) -> Tuple[DecisionStatus, str]:
        """Makes a final loan decision based on the risk score. (FR3)"""
        if risk_score >= self.config.DECISION_THRESHOLDS['approve']:
            return (DecisionStatus.APPROVED,
                    "Excellent risk profile. Meets all criteria.")
        if risk_score < self.config.DECISION_THRESHOLDS['deny']:
            return (DecisionStatus.DENIED,
                    "High-risk profile. Does not meet minimum criteria.")
        return (DecisionStatus.MANUAL_REVIEW,
                "Marginal risk profile. Requires underwriter review.")

    def process_application(self, applicant: ApplicantData) -> LoanDecision:
        """Processes a single loan application from start to finish."""
        dti_ratio = self._calculate_dti_ratio(applicant)
        ltv_ratio = self._calculate_ltv_ratio(applicant)
        age_factor = self._get_age_adjustment_factor(applicant)

        risk_score = self._calculate_risk_score(
            applicant=applicant,
            dti_ratio=dti_ratio,
            ltv_ratio=ltv_ratio,
            age_factor=age_factor
        )

        status, reason = self._make_decision(risk_score)

        return LoanDecision(
            applicant_id=applicant.applicant_id,
            dti_ratio=dti_ratio,
            risk_score=risk_score,
            status=status,
            reason=reason
        )

    def process_batch(self, applicants: List[ApplicantData]) -> List[LoanDecision]:
        """Processes a list of loan applications."""
        return [self.process_application(app) for app in applicants]


# --- Reporting ---

class ReportGenerator:
    """Handles the generation of summary reports. (FR4)"""

    @staticmethod
    def generate_summary_report(decisions: List[LoanDecision]) -> None:
        """
        Prints a formatted summary report of all applications to the console.
        """
        print("--- Loan Decision Summary Report ---")
        print("-" * 70)
        print(
            f"{'Applicant ID':<15} | {'Risk Score':<12} | {'DTI Ratio':<12} | "
            f"{'Decision':<15} | {'Reason'}"
        )
        print("-" * 70)

        status_counts = {status: 0 for status in DecisionStatus}

        for decision in decisions:
            status_counts[decision.status] += 1
            print(
                f"{decision.applicant_id:<15} | {decision.risk_score:<12} | "
                f"{decision.dti_ratio:<12.2f}% | "
                f"{decision.status.value:<15} | {decision.reason}"
            )

        print("-" * 70)
        print("\n--- Overall Summary ---")
        print(f"Total Applications Processed: {len(decisions)}")
        for status, count in status_counts.items():
            print(f"  - {status.value}: {count}")
        print("-" * 25)


# --- Main Execution ---

def get_sample_applicants() -> List[ApplicantData]:
    """Provides a list of sample applicants for demonstration. (NFR1)"""
    return [
        ApplicantData(
            applicant_id="APP-001", age=45, annual_income=120000,
            monthly_debt=2500, credit_score=810, loan_amount=300000,
            collateral_value=400000
        ),
        ApplicantData(
            applicant_id="APP-002", age=32, annual_income=48000,
            monthly_debt=2000, credit_score=630, loan_amount=15000,
            collateral_value=0  # Unsecured loan
        ),
        ApplicantData(
            applicant_id="APP-003", age=55, annual_income=85000,
            monthly_debt=2800, credit_score=710, loan_amount=250000,
            collateral_value=280000
        ),
        ApplicantData(  # This applicant is over the age threshold (FR5)
            applicant_id="APP-004", age=68, annual_income=110000,
            monthly_debt=2000, credit_score=790, loan_amount=200000,
            collateral_value=350000
        ),
        ApplicantData(
            applicant_id="APP-005", age=28, annual_income=65000,
            monthly_debt=1000, credit_score=680, loan_amount=20000,
            collateral_value=25000
        ),
    ]


def main():
    """Main function to run the loan approval system with sample data."""
    # 1. Initialize the configuration for the system.
    config = LoanSystemConfig()

    # 2. Get sample data.
    sample_applicants = get_sample_applicants()

    # 3. Initialize and run the system with the specified config.
    system = LoanApprovalSystem(config=config)
    decisions = system.process_batch(sample_applicants)

    # 4. Generate the final report.
    ReportGenerator.generate_summary_report(decisions)


if __name__ == "__main__":
    main()