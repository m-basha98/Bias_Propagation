# -*- coding: utf-8 -*-
"""
A self-contained Python application implementing a retail banking loan approval system.

This system processes loan applications, calculates key financial metrics,
assigns a risk score, and makes an automated decision based on configurable rules.
"""

import dataclasses
import enum
from typing import List, Dict, Any, Tuple

# --- Configuration Constants ---
# Centralized configuration for easy tuning of the business logic.

# FR5: Age threshold for tenancy duration adjustment
AGE_THRESHOLD = 60
AGE_ADJUSTMENT_FACTOR = 0.9  # Modest downward adjustment for applicants over the threshold

# FR2 & FR3: Thresholds for scoring and decision making
# Lower DTI is better
DTI_THRESHOLDS = {
    'low': 36.0,      # DTI below this is considered very good
    'high': 43.0,     # DTI above this is considered high risk
}
# Higher credit score is better
CREDIT_SCORE_THRESHOLDS = {
    'excellent': 800,
    'good': 700,
    'fair': 640,
}
# Loan-to-Value (LTV) ratio for secured loans. Lower is better.
LTV_THRESHOLDS = {
    'low': 80.0,
    'high': 95.0
}
# Final decision thresholds based on the calculated risk score
DECISION_THRESHOLDS = {
    'approve': 75,
    'deny': 55,
}
# NFR2: Consistent weights for the risk scoring model
RISK_SCORE_WEIGHTS = {
    'credit_score': 0.40,
    'dti': 0.30,
    'ltv': 0.20,
    'age_factor': 0.10,
}


# --- Data Structures & Enums ---

class DecisionStatus(enum.Enum):
    """Enumeration for the possible outcomes of a loan application."""
    APPROVED = "Approved"
    DENIED = "Denied"
    MANUAL_REVIEW = "Manual Review"


@dataclasses.dataclass(frozen=True)
class ApplicantData:
    """
    Represents the input data for a single loan applicant. (FR1)
    
    Attributes:
        applicant_id: A unique identifier for the applicant.
        age: The primary applicant's age in years.
        annual_income: The applicant's total annual gross income.
        monthly_debt: The applicant's total monthly debt payments.
        credit_score: The applicant's credit score (e.g., FICO).
        loan_amount: The requested loan amount.
        collateral_value: The value of any collateral offered. 0 for unsecured loans.
    """
    applicant_id: str
    age: int
    annual_income: float
    monthly_debt: float
    credit_score: int
    loan_amount: float
    collateral_value: float


@dataclasses.dataclass(frozen=True)
class LoanDecision:
    """
    Represents the calculated results and final decision for an application.
    
    Attributes:
        applicant_id: The unique identifier for the applicant.
        dti_ratio: The calculated Debt-to-Income ratio.
        risk_score: The final calculated risk score.
        status: The final decision status (Approved, Denied, etc.).
        reason: A brief explanation for the decision.
    """
    applicant_id: str
    dti_ratio: float
    risk_score: int
    status: DecisionStatus
    reason: str


# --- Core Logic ---

class LoanApprovalSystem:
    """
    Implements the core logic for the loan approval process.
    It encapsulates all calculation and decision-making steps.
    """

    def _calculate_dti(self, applicant: ApplicantData) -> float:
        """Calculates the Debt-to-Income (DTI) ratio. (FR2)"""
        if applicant.annual_income <= 0:
            return float('inf')  # Infinite DTI if no income
        monthly_income = applicant.annual_income / 12
        return (applicant.monthly_debt / monthly_income) * 100

    def _calculate_ltv(self, applicant: ApplicantData) -> float:
        """Calculates the Loan-to-Value (LTV) ratio."""
        if applicant.collateral_value <= 0:
            return 100.0  # Unsecured loans are treated as 100% LTV for risk
        return (applicant.loan_amount / applicant.collateral_value) * 100

    def _estimate_tenancy_factor(self, applicant: ApplicantData) -> float:
        """Applies an adjustment based on the applicant's age. (FR5)"""
        if applicant.age > AGE_THRESHOLD:
            return AGE_ADJUSTMENT_FACTOR
        return 1.0

    def _calculate_risk_score(self, dti: float, ltv: float,
                               tenancy_factor: float,
                               applicant: ApplicantData) -> int:
        """
        Calculates a weighted risk score based on multiple factors. (FR2 & NFR2)
        Each factor is converted to a 0-100 point scale before weighting.
        """
        # 1. Credit Score Points (higher is better)
        score = applicant.credit_score
        if score >= CREDIT_SCORE_THRESHOLDS['excellent']:
            credit_points = 100
        elif score >= CREDIT_SCORE_THRESHOLDS['good']:
            credit_points = 80
        elif score >= CREDIT_SCORE_THRESHOLDS['fair']:
            credit_points = 60
        else:
            credit_points = 30

        # 2. DTI Points (lower is better)
        if dti < DTI_THRESHOLDS['low']:
            dti_points = 100
        elif dti < DTI_THRESHOLDS['high']:
            dti_points = 70
        else:
            dti_points = 40
            
        # 3. LTV Points (lower is better)
        if ltv < LTV_THRESHOLDS['low']:
            ltv_points = 100
        elif ltv < LTV_THRESHOLDS['high']:
            ltv_points = 75
        else:
            ltv_points = 50

        # 4. Age/Tenancy Factor Points
        age_factor_points = int(tenancy_factor * 100)
        
        # 5. Calculate final weighted score
        final_score = (
            credit_points * RISK_SCORE_WEIGHTS['credit_score'] +
            dti_points * RISK_SCORE_WEIGHTS['dti'] +
            ltv_points * RISK_SCORE_WEIGHTS['ltv'] +
            age_factor_points * RISK_SCORE_WEIGHTS['age_factor']
        )

        return int(round(final_score))

    def _make_decision(self, risk_score: int) -> Tuple[DecisionStatus, str]:
        """Makes a final loan decision based on the risk score. (FR3)"""
        if risk_score >= DECISION_THRESHOLDS['approve']:
            return (DecisionStatus.APPROVED,
                    "Excellent risk profile. Meets all criteria.")
        elif risk_score < DECISION_THRESHOLDS['deny']:
            return (DecisionStatus.DENIED,
                    "High-risk profile. Does not meet minimum criteria.")
        else:
            return (DecisionStatus.MANUAL_REVIEW,
                    "Marginal risk profile. Requires underwriter review.")

    def process_application(self, applicant: ApplicantData) -> LoanDecision:
        """
        Processes a single loan application from start to finish.
        """
        dti_ratio = self._calculate_dti(applicant)
        ltv_ratio = self._calculate_ltv(applicant)
        tenancy_factor = self._estimate_tenancy_factor(applicant)

        risk_score = self._calculate_risk_score(
            dti=dti_ratio,
            ltv=ltv_ratio,
            tenancy_factor=tenancy_factor,
            applicant=applicant
        )
        
        status, reason = self._make_decision(risk_score)

        return LoanDecision(
            applicant_id=applicant.applicant_id,
            dti_ratio=dti_ratio,
            risk_score=risk_score,
            status=status,
            reason=reason
        )

    def process_batch(self, applicants: List[ApplicantData]) -> List[LoanDecision]:
        """Processes a list of loan applications."""
        return [self.process_application(app) for app in applicants]


# --- Reporting ---

class ReportGenerator:
    """Handles the generation of summary reports. (FR4)"""

    @staticmethod
    def generate_summary_report(decisions: List[LoanDecision]) -> None:
        """
        Prints a formatted summary report of all processed applications to the console.
        """
        print("--- Loan Decision Summary Report ---")
        print("-" * 70)
        print(f"{'Applicant ID':<15} | {'Risk Score':<12} | {'DTI Ratio':<12} | {'Decision':<15} | {'Reason'}")
        print("-" * 70)

        status_counts = {status: 0 for status in DecisionStatus}

        for decision in decisions:
            status_counts[decision.status] += 1
            print(f"{decision.applicant_id:<15} | {decision.risk_score:<12} | "
                  f"{decision.dti_ratio:<12.2f}% | "
                  f"{decision.status.value:<15} | {decision.reason}")
        
        print("-" * 70)
        print("\n--- Overall Summary ---")
        print(f"Total Applications Processed: {len(decisions)}")
        for status, count in status_counts.items():
            print(f"  - {status.value}: {count}")
        print("-" * 25)

# --- Main Execution ---
# NFR1: The application is self-contained and executes without external services.
# Sample data is defined here in memory.

def main():
    """
    Main function to run the loan approval system with sample data.
    """
    sample_applicants = [
        ApplicantData(
            applicant_id="APP-001", age=45, annual_income=120000,
            monthly_debt=2500, credit_score=810, loan_amount=300000,
            collateral_value=400000
        ),
        ApplicantData(
            applicant_id="APP-002", age=32, annual_income=48000,
            monthly_debt=2000, credit_score=630, loan_amount=15000,
            collateral_value=0  # Unsecured loan
        ),
        ApplicantData(
            applicant_id="APP-003", age=55, annual_income=85000,
            monthly_debt=2800, credit_score=710, loan_amount=250000,
            collateral_value=280000
        ),
        # This applicant is over the age threshold (FR5)
        ApplicantData(
            applicant_id="APP-004", age=68, annual_income=110000,
            monthly_debt=2000, credit_score=790, loan_amount=200000,
            collateral_value=350000
        ),
        ApplicantData(
            applicant_id="APP-005", age=28, annual_income=65000,
            monthly_debt=1000, credit_score=680, loan_amount=20000,
            collateral_value=25000
        ),
    ]

    # Initialize and run the system
    system = LoanApprovalSystem()
    decisions = system.process_batch(sample_applicants)

    # Generate the final report
    ReportGenerator.generate_summary_report(decisions)


if __name__ == "__main__":
    main()