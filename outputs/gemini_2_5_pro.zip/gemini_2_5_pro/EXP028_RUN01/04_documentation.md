Of course. Here is the detailed technical documentation for the provided Python code.

---

# Technical Documentation: Retail Banking Loan Approval System

## 1. Module Overview

This document provides a detailed technical explanation of the `loan_approval_system.py` module. The module implements a self-contained retail banking loan approval system designed to process applicant data, calculate financial metrics, assess risk, and automate loan decisions.

The system is architected to be modular and configurable, separating business logic (rules, thresholds) from the core processing engine. This adheres to the specified functional and non-functional requirements, including data storage representation (FR1), calculation of financial ratios and risk scores (FR2), automated decision-making (FR3), summary report generation (FR4), and age-based adjustments (FR5). The design ensures it runs without external dependencies (NFR1) and maintains consistent scoring logic (NFR2).

## 2. Configuration

### Class `LoanSystemConfig`
This `dataclasses.dataclass` serves as a centralized container for all business logic parameters and thresholds used by the loan approval engine. Using a configuration object makes the system flexible, easier to maintain, and simplifies testing by allowing different rule sets to be injected.

**Attributes:**

*   `AGE_THRESHOLD` (int): The age in years above which an applicant receives a downward adjustment factor for their expected tenancy duration. Default: `60`. (Implements FR5)
*   `AGE_ADJUSTMENT_FACTOR` (float): The multiplicative factor applied to the age component of the risk score for applicants older than `AGE_THRESHOLD`. Default: `0.9`. (Implements FR5)
*   `DTI_THRESHOLDS` (Dict[str, float]): A dictionary defining the "low" and "high" boundaries for Debt-to-Income (DTI) ratio scoring. Default: `{'low': 36.0, 'high': 43.0}`.
*   `CREDIT_SCORE_THRESHOLDS` (Dict[str, int]): A dictionary defining the score boundaries for "excellent", "good", and "fair" credit ratings. Default: `{'excellent': 800, 'good': 700, 'fair': 640}`.
*   `LTV_THRESHOLDS` (Dict[str, float]): A dictionary defining the "low" and "high" boundaries for Loan-to-Value (LTV) ratio scoring. Default: `{'low': 80.0, 'high': 95.0}`.
*   `DECISION_THRESHOLDS` (Dict[str, int]): A dictionary defining the final risk score boundaries for "approve" and "deny" decisions. Scores between these values result in a manual review. Default: `{'approve': 75, 'deny': 55}`. (Implements FR3)
*   `RISK_SCORE_WEIGHTS` (Dict[str, float]): A dictionary containing the weights for each component contributing to the final risk score, ensuring consistent logic across all applications. The sum of weights should ideally be 1.0. Default: `{'credit_score': 0.40, 'dti': 0.30, 'ltv': 0.20, 'age_factor': 0.10}`. (Implements NFR2)

## 3. Data Models & Enumerations

### Enum `DecisionStatus`
An `enum.Enum` that defines the set of possible outcomes for a loan application decision. Using an enumeration prevents errors from typos and makes the code more readable.

**Members:**

*   `APPROVED`: "Approved"
*   `DENIED`: "Denied"
*   `MANUAL_REVIEW`: "Manual Review"

### Class `ApplicantData`
A `dataclasses.dataclass` that represents the input data structure for a single loan applicant. This class serves as the primary data model for application information. (Implements FR1)

**Attributes:**

*   `applicant_id` (str): A unique identifier for the applicant.
*   `age` (int): The primary applicant's age in years.
*   `annual_income` (float): The applicant's total annual gross income.
*   `monthly_debt` (float): The applicant's total monthly debt payments.
*   `credit_score` (int): The applicant's credit score (e.g., FICO).
*   `loan_amount` (float): The requested loan amount.
*   `collateral_value` (float): The appraised value of any collateral offered. Should be `0` for unsecured loans.

### Class `LoanDecision`
A `dataclasses.dataclass` that represents the calculated results and final decision for a single processed application. This is the output object from the core processing logic.

**Attributes:**

*   `applicant_id` (str): The unique identifier for the applicant, linking back to the input `ApplicantData`.
*   `dti_ratio` (float): The calculated Debt-to-Income ratio as a percentage.
*   `risk_score` (int): The final calculated risk score, on a scale typically from 0-100.
*   `status` (DecisionStatus): The final decision status (e.g., `DecisionStatus.APPROVED`).
*   `reason` (str): A brief, human-readable explanation for the decision outcome.

## 4. Core Logic

### Class `LoanApprovalSystem`
This class encapsulates the core business logic for the loan approval process. It contains all methods for calculation, scoring, and decision-making. It is initialized with a `LoanSystemConfig` object, decoupling the processing logic from the business rules themselves.

#### `__init__(self, config: LoanSystemConfig)`
Initializes the `LoanApprovalSystem` with a specific configuration.

*   **Parameters**:
    *   `config` (LoanSystemConfig): An instance of `LoanSystemConfig` containing all the rules and thresholds for processing.

#### `_calculate_dti_ratio(self, applicant: ApplicantData) -> float`
Calculates the Debt-to-Income (DTI) ratio. DTI is the percentage of a person's gross monthly income that goes towards paying their monthly debt payments. (Implements FR2)

*   **Parameters**:
    *   `applicant` (ApplicantData): The applicant's data record.
*   **Returns**:
    *   `float`: The calculated DTI ratio as a percentage. Returns `float('inf')` if the applicant has no income to prevent division by zero.

#### `_calculate_ltv_ratio(self, applicant: ApplicantData) -> float`
Calculates the Loan-to-Value (LTV) ratio for secured loans. LTV is the ratio of the loan amount to the value of the asset being purchased.

*   **Parameters**:
    *   `applicant` (ApplicantData): The applicant's data record.
*   **Returns**:
    *   `float`: The calculated LTV ratio as a percentage. Returns `100.0` for unsecured loans (collateral value <= 0) to represent the highest risk level.

#### `_get_age_adjustment_factor(self, applicant: ApplicantData) -> float`
Determines the age-based adjustment factor for the risk score calculation, implementing a modest downward adjustment for older applicants. (Implements FR5)

*   **Parameters**:
    *   `applicant` (ApplicantData): The applicant's data record.
*   **Returns**:
    *   `float`: The adjustment factor. Returns `config.AGE_ADJUSTMENT_FACTOR` if the applicant's age is above the configured threshold, otherwise returns `1.0`.

#### `_get_points_for_credit_score(self, credit_score: int) -> int`
Converts an absolute credit score into a normalized 0-100 point scale based on configured thresholds.

*   **Parameters**:
    *   `credit_score` (int): The applicant's credit score.
*   **Returns**:
    *   `int`: A score between 30 and 100 representing the quality of the credit score.

#### `_get_points_for_dti(self, dti_ratio: float) -> int`
Converts a DTI ratio into a normalized 0-100 point scale. Lower DTI ratios result in higher points.

*   **Parameters**:
    *   `dti_ratio` (float): The applicant's DTI ratio.
*   **Returns**:
    *   `int`: A score between 40 and 100 representing the quality of the DTI ratio.

#### `_get_points_for_ltv(self, ltv_ratio: float) -> int`
Converts an LTV ratio into a normalized 0-100 point scale. Lower LTV ratios result in higher points.

*   **Parameters**:
    *   `ltv_ratio` (float): The applicant's LTV ratio.
*   **Returns**:
    *   `int`: A score between 50 and 100 representing the quality of the LTV ratio.

#### `_calculate_risk_score(...) -> int`
Calculates the final weighted risk score by combining the points from various financial factors. (Implements FR2 & NFR2)

*   **Parameters**:
    *   `applicant` (ApplicantData): The applicant's data record.
    *   `dti_ratio` (float): The pre-calculated DTI ratio.
    *   `ltv_ratio` (float): The pre-calculated LTV ratio.
    *   `age_factor` (float): The pre-calculated age adjustment factor.
*   **Returns**:
    *   `int`: The final, rounded risk score (0-100).

#### `_make_decision(self, risk_score: int) -> Tuple[DecisionStatus, str]`
Makes the final automated loan decision based on the calculated risk score and configured decision thresholds. (Implements FR3)

*   **Parameters**:
    *   `risk_score` (int): The applicant's final risk score.
*   **Returns**:
    *   `Tuple[DecisionStatus, str]`: A tuple containing the final `DecisionStatus` and a corresponding `reason` string.

#### `process_application(self, applicant: ApplicantData) -> LoanDecision`
Orchestrates the end-to-end processing of a single loan application. This method calls the various private helper methods in sequence to calculate metrics, determine a risk score, and make a final decision.

*   **Parameters**:
    *   `applicant` (ApplicantData): The complete data for a single applicant.
*   **Returns**:
    *   `LoanDecision`: An object containing all calculated results and the final decision.

#### `process_batch(self, applicants: List[ApplicantData]) -> List[LoanDecision]`
A convenience method to process a list of loan applications in a single call.

*   **Parameters**:
    *   `applicants` (List[ApplicantData]): A list of applicant data objects to be processed.
*   **Returns**:
    *   `List[LoanDecision]`: A list of decision objects, one for each applicant in the input list.

## 5. Reporting

### Class `ReportGenerator`
A utility class responsible for creating and displaying a summary report of the loan decisions.

#### `generate_summary_report(decisions: List[LoanDecision]) -> None`
Prints a formatted summary report of all processed applications to the standard output (console). The report includes a tabular view of each decision and an overall summary of outcomes. (Implements FR4)

*   **Parameters**:
    *   `decisions` (List[LoanDecision]): A list of completed loan decision objects.
*   **Returns**:
    *   `None`. This function produces output as a side effect.

## 6. Main Execution

### `get_sample_applicants() -> List[ApplicantData]`
A factory function that provides a static list of sample `ApplicantData` objects. This is used for demonstration and testing purposes and helps the application run without external data sources. (Implements NFR1)

*   **Returns**:
    *   `List[ApplicantData]`: A predefined list of sample applicants.

### `main()`
The main function that serves as the entry point for the script. It orchestrates the entire workflow:
1.  Initializes the `LoanSystemConfig`.
2.  Retrieves the sample applicant data.
3.  Instantiates and runs the `LoanApprovalSystem`.
4.  Calls the `ReportGenerator` to display the results.

### `if __name__ == "__main__":`
This is a standard Python construct that ensures the `main()` function is called only when the script is executed directly, not when it is imported as a module into another script.