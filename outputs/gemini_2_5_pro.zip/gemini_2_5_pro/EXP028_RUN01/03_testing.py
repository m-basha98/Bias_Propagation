# test_loan_system.py

# -*- coding: utf-8 -*-
"""
A comprehensive suite of unit tests for the retail banking loan approval system.

This suite uses the pytest framework to validate the functionality of the loan
approval system, covering standard scenarios, edge cases, and boundary conditions
for each component of the application.
"""

import math
import sys
from io import StringIO
from typing import List

import pytest

# Import all necessary components from the software module
# In a real project, this would be `from loan_system import ...`
# For this self-contained example, we assume the code is in a file named `loan_system.py`
# To run this test, you would save the original code as `loan_system.py` and this code as `test_loan_system.py`
# and then run `pytest` in the terminal.
from loan_system import (
    ApplicantData,
    DecisionStatus,
    LoanApprovalSystem,
    LoanDecision,
    LoanSystemConfig,
    ReportGenerator,
)


# --- Fixtures for Reusability ---

@pytest.fixture(scope="module")
def default_config() -> LoanSystemConfig:
    """Provides a default, unaltered configuration for the system."""
    return LoanSystemConfig()


@pytest.fixture
def system(default_config: LoanSystemConfig) -> LoanApprovalSystem:
    """Provides a LoanApprovalSystem instance with the default configuration."""
    return LoanApprovalSystem(config=default_config)


@pytest.fixture
def perfect_applicant() -> ApplicantData:
    """Provides a perfect applicant, expected to be approved."""
    return ApplicantData(
        applicant_id="PERFECT-001",
        age=35,
        annual_income=240000,   # High income
        monthly_debt=1000,      # Low debt
        credit_score=850,       # Excellent credit
        loan_amount=200000,
        collateral_value=400000 # Low LTV
    )


@pytest.fixture
def high_risk_applicant() -> ApplicantData:
    """Provides a high-risk applicant, expected to be denied."""
    return ApplicantData(
        applicant_id="RISKY-001",
        age=25,
        annual_income=36000,    # Low income
        monthly_debt=1500,      # High debt relative to income
        credit_score=580,       # Poor credit
        loan_amount=25000,
        collateral_value=20000  # High LTV
    )


@pytest.fixture
def marginal_applicant() -> ApplicantData:
    """Provides a marginal applicant, expected to need manual review."""
    return ApplicantData(
        applicant_id="MARGINAL-001",
        age=45,
        annual_income=90000,
        monthly_debt=2700,      # DTI is okay
        credit_score=680,       # Credit is fair/good
        loan_amount=280000,
        collateral_value=300000 # LTV is high
    )


# --- Tests for Core Logic: LoanApprovalSystem ---

class TestLoanApprovalSystemCalculations:
    """
    Tests for the individual calculation methods within the LoanApprovalSystem.
    Focuses on unit testing each logical step of the process.
    """

    def test_calculate_dti_ratio_standard(self, system: LoanApprovalSystem):
        """FR2: Test DTI calculation with standard inputs."""
        applicant = ApplicantData("std", 40, 120000, 3000, 700, 100, 100)
        # Expected: (3000 / (120000 / 12)) * 100 = 30.0
        assert system._calculate_dti_ratio(applicant) == pytest.approx(30.0)

    def test_calculate_dti_ratio_zero_income(self, system: LoanApprovalSystem):
        """FR2: Test DTI with zero income, an edge case."""
        applicant = ApplicantData("zero_inc", 30, 0, 500, 600, 100, 100)
        assert system._calculate_dti_ratio(applicant) == float('inf')

    def test_calculate_dti_ratio_zero_debt(self, system: LoanApprovalSystem):
        """FR2: Test DTI with zero debt, a boundary condition."""
        applicant = ApplicantData("zero_debt", 50, 80000, 0, 750, 100, 100)
        assert system._calculate_dti_ratio(applicant) == pytest.approx(0.0)

    def test_calculate_ltv_ratio_standard(self, system: LoanApprovalSystem):
        """Test LTV calculation for a standard secured loan."""
        applicant = ApplicantData("std_ltv", 40, 100, 100, 700, 80000, 100000)
        # Expected: (80000 / 100000) * 100 = 80.0
        assert system._calculate_ltv_ratio(applicant) == pytest.approx(80.0)

    def test_calculate_ltv_ratio_unsecured(self, system: LoanApprovalSystem):
        """Test LTV for an unsecured loan (zero collateral)."""
        applicant = ApplicantData("unsecured", 30, 100, 100, 700, 5000, 0)
        assert system._calculate_ltv_ratio(applicant) == pytest.approx(100.0)

    def test_calculate_ltv_ratio_equal_values(self, system: LoanApprovalSystem):
        """Test LTV where loan amount equals collateral value."""
        applicant = ApplicantData("equal", 50, 100, 100, 700, 150000, 150000)
        assert system._calculate_ltv_ratio(applicant) == pytest.approx(100.0)

    @pytest.mark.parametrize(
        "age, expected_factor",
        [
            (59, 1.0),  # Below threshold
            (60, 1.0),  # Exactly on threshold
            (61, 0.9),  # Above threshold
            (99, 0.9),  # Well above threshold
        ],
    )
    def test_get_age_adjustment_factor(
        self, system: LoanApprovalSystem, age: int, expected_factor: float
    ):
        """FR5: Test age adjustment factor at and around the threshold."""
        applicant = ApplicantData("age_test", age, 100, 100, 700, 100, 100)
        assert system._get_age_adjustment_factor(applicant) == expected_factor

    @pytest.mark.parametrize(
        "score, expected_points",
        [
            (850, 100),  # Excellent
            (800, 100),  # Excellent boundary
            (799, 80),   # Good
            (700, 80),   # Good boundary
            (699, 60),   # Fair
            (640, 60),   # Fair boundary
            (639, 30),   # Poor
            (300, 30),   # Very Poor
        ],
    )
    def test_get_points_for_credit_score(
        self, system: LoanApprovalSystem, score: int, expected_points: int
    ):
        """Test credit score to points conversion across all thresholds."""
        assert system._get_points_for_credit_score(score) == expected_points

    @pytest.mark.parametrize(
        "dti, expected_points",
        [
            (35.9, 100), # Low DTI
            (36.0, 70),  # Low DTI boundary
            (42.9, 70),  # High DTI
            (43.0, 40),  # High DTI boundary
            (50.0, 40),  # Very High DTI
        ],
    )
    def test_get_points_for_dti(
        self, system: LoanApprovalSystem, dti: float, expected_points: int
    ):
        """Test DTI ratio to points conversion across all thresholds."""
        assert system._get_points_for_dti(dti) == expected_points

    @pytest.mark.parametrize(
        "ltv, expected_points",
        [
            (79.9, 100), # Low LTV
            (80.0, 75),  # Low LTV boundary
            (94.9, 75),  # High LTV
            (95.0, 50),  # High LTV boundary
            (100.0, 50), # Very High LTV
        ],
    )
    def test_get_points_for_ltv(
        self, system: LoanApprovalSystem, ltv: float, expected_points: int
    ):
        """Test LTV ratio to points conversion across all thresholds."""
        assert system._get_points_for_ltv(ltv) == expected_points

    def test_calculate_risk_score_consistency(
        self, system: LoanApprovalSystem, perfect_applicant: ApplicantData
    ):
        """FR2 & NFR2: Test the weighted risk score calculation for a known profile."""
        # Manually calculate expected score for perfect_applicant
        # 1. Factors
        dti_ratio = (1000 / (240000 / 12)) * 100  # 5.0
        ltv_ratio = (200000 / 400000) * 100      # 50.0
        age_factor = 1.0                         # Age 35 < 60

        # 2. Points
        credit_points = 100  # Score 850 is excellent
        dti_points = 100     # DTI 5.0 < 36.0
        ltv_points = 100     # LTV 50.0 < 80.0
        age_points = 100     # Factor 1.0 * 100

        # 3. Weighted Score
        weights = system.config.RISK_SCORE_WEIGHTS
        expected_score = (
            100 * weights['credit_score'] +  # 100 * 0.40 = 40
            100 * weights['dti'] +           # 100 * 0.30 = 30
            100 * weights['ltv'] +           # 100 * 0.20 = 20
            100 * weights['age_factor']      # 100 * 0.10 = 10
        )  # Total = 100
        expected_score = int(round(expected_score))

        actual_score = system._calculate_risk_score(
            applicant=perfect_applicant,
            dti_ratio=dti_ratio,
            ltv_ratio=ltv_ratio,
            age_factor=age_factor
        )

        assert actual_score == expected_score
        assert actual_score == 100

    @pytest.mark.parametrize(
        "score, expected_status, expected_reason_fragment",
        [
            (100, DecisionStatus.APPROVED, "Excellent risk profile"),
            (75, DecisionStatus.APPROVED, "Excellent risk profile"),
            (74, DecisionStatus.MANUAL_REVIEW, "Marginal risk profile"),
            (60, DecisionStatus.MANUAL_REVIEW, "Marginal risk profile"),
            (55, DecisionStatus.MANUAL_REVIEW, "Marginal risk profile"),
            (54, DecisionStatus.DENIED, "High-risk profile"),
            (0, DecisionStatus.DENIED, "High-risk profile"),
        ],
    )
    def test_make_decision(
        self, system: LoanApprovalSystem, score: int, expected_status: DecisionStatus,
        expected_reason_fragment: str
    ):
        """FR3: Test decision logic at and around the thresholds."""
        status, reason = system._make_decision(score)
        assert status == expected_status
        assert expected_reason_fragment in reason


class TestLoanApprovalSystemEndToEnd:
    """
    Tests the full application processing logic from input to decision.
    These are integration-style tests for the `LoanApprovalSystem` class.
    """

    def test_process_application_approved(
        self, system: LoanApprovalSystem, perfect_applicant: ApplicantData
    ):
        """Test a clear 'approve' case from start to finish."""
        decision = system.process_application(perfect_applicant)
        assert isinstance(decision, LoanDecision)
        assert decision.applicant_id == perfect_applicant.applicant_id
        assert decision.status == DecisionStatus.APPROVED
        assert decision.risk_score >= system.config.DECISION_THRESHOLDS['approve']

    def test_process_application_denied(
        self, system: LoanApprovalSystem, high_risk_applicant: ApplicantData
    ):
        """Test a clear 'deny' case from start to finish."""
        decision = system.process_application(high_risk_applicant)
        assert isinstance(decision, LoanDecision)
        assert decision.applicant_id == high_risk_applicant.applicant_id
        assert decision.status == DecisionStatus.DENIED
        assert decision.risk_score < system.config.DECISION_THRESHOLDS['deny']

    def test_process_application_manual_review(
        self, system: LoanApprovalSystem, marginal_applicant: ApplicantData
    ):
        """Test a marginal case requiring manual review."""
        decision = system.process_application(marginal_applicant)
        assert isinstance(decision, LoanDecision)
        assert decision.applicant_id == marginal_applicant.applicant_id
        assert decision.status == DecisionStatus.MANUAL_REVIEW
        assert (system.config.DECISION_THRESHOLDS['deny'] <=
                decision.risk_score <
                system.config.DECISION_THRESHOLDS['approve'])

    def test_age_adjustment_impact_on_decision(self, system: LoanApprovalSystem):
        """
        FR5: Verify that the age adjustment can impact the final risk score and decision.
        Creates two nearly identical applicants, one above and one below the age threshold.
        """
        base_applicant_attrs = {
            "annual_income": 110000,
            "monthly_debt": 2200,    # DTI = 24% (good)
            "credit_score": 790,     # Credit = Good (80 pts)
            "loan_amount": 200000,
            "collateral_value": 300000, # LTV = 66.7% (excellent)
        }

        # Applicant just under the age threshold
        applicant_under_60 = ApplicantData(
            applicant_id="AGE-TEST-59", age=59, **base_applicant_attrs
        )
        # Applicant just over the age threshold
        applicant_over_60 = ApplicantData(
            applicant_id="AGE-TEST-61", age=61, **base_applicant_attrs
        )

        decision_under_60 = system.process_application(applicant_under_60)
        decision_over_60 = system.process_application(applicant_over_60)

        # The only difference in score should come from the age factor weight
        # Age factor diff: (1.0 - 0.9) * 100 = 10 points
        # Weighted diff: 10 * weight['age_factor'] = 10 * 0.10 = 1 point
        expected_score_difference = round(
            (1.0 - system.config.AGE_ADJUSTMENT_FACTOR) * 100 *
            system.config.RISK_SCORE_WEIGHTS['age_factor']
        )

        assert decision_under_60.risk_score > decision_over_60.risk_score
        assert (decision_under_60.risk_score - decision_over_60.risk_score
                == expected_score_difference)

    def test_process_batch(
        self, system: LoanApprovalSystem, perfect_applicant: ApplicantData,
        high_risk_applicant: ApplicantData
    ):
        """Test the processing of a batch of applications."""
        applicants = [perfect_applicant, high_risk_applicant]
        decisions = system.process_batch(applicants)

        assert isinstance(decisions, list)
        assert len(decisions) == 2
        assert decisions[0].applicant_id == perfect_applicant.applicant_id
        assert decisions[0].status == DecisionStatus.APPROVED
        assert decisions[1].applicant_id == high_risk_applicant.applicant_id
        assert decisions[1].status == DecisionStatus.DENIED

    def test_process_batch_empty_list(self, system: LoanApprovalSystem):
        """Test processing an empty batch, an edge case."""
        decisions = system.process_batch([])
        assert decisions == []


# --- Tests for Reporting ---

class TestReportGenerator:
    """Tests for the ReportGenerator component."""

    @pytest.fixture
    def sample_decisions(self) -> List[LoanDecision]:
        """Provides a list of sample decisions for reporting tests."""
        return [
            LoanDecision(
                applicant_id="APP-001", dti_ratio=25.0, risk_score=85,
                status=DecisionStatus.APPROVED, reason="Excellent profile."
            ),
            LoanDecision(
                applicant_id="APP-002", dti_ratio=50.0, risk_score=52,
                status=DecisionStatus.DENIED, reason="High risk."
            ),
            LoanDecision(
                applicant_id="APP-003", dti_ratio=38.0, risk_score=68,
                status=DecisionStatus.MANUAL_REVIEW, reason="Marginal."
            ),
        ]

    def test_generate_summary_report_structure(
        self, sample_decisions: List[LoanDecision], capsys
    ):
        """
        FR4: Test if the report prints the correct headers, content, and summary.
        Uses pytest's `capsys` fixture to capture stdout.
        """
        ReportGenerator.generate_summary_report(sample_decisions)
        captured = capsys.readouterr()
        output = captured.out

        # Check for headers
        assert "--- Loan Decision Summary Report ---" in output
        assert "Applicant ID" in output and "Risk Score" in output
        assert "Decision" in output

        # Check for content from one of the decisions
        assert "APP-001" in output
        assert "85" in output
        assert "25.00%" in output
        assert "Approved" in output
        assert "Excellent profile." in output

        # Check for summary section
        assert "--- Overall Summary ---" in output
        assert "Total Applications Processed: 3" in output
        assert "Approved: 1" in output
        assert "Denied: 1" in output
        assert "Manual Review: 1" in output

    def test_generate_summary_report_empty(self, capsys):
        """Test report generation with an empty list of decisions."""
        ReportGenerator.generate_summary_report([])
        captured = capsys.readouterr()
        output = captured.out

        # Should still print headers and a zero-count summary
        assert "--- Loan Decision Summary Report ---" in output
        assert "--- Overall Summary ---" in output
        assert "Total Applications Processed: 0" in output
        assert "Approved: 0" in output
        assert "Denied: 0" in output
        assert "Manual Review: 0" in output