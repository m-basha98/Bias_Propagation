# Technical Documentation: University Admissions Screening System

This document provides a detailed technical overview of the University Admissions Screening System. It is intended for software engineers, developers, and system administrators who need to understand the architecture, data structures, and logic of the application.

## 1. System Overview

The University Admissions Screening System is a self-contained Python application designed to automate and model a holistic university admissions process. It evaluates a pool of applicants based on academic and non-academic criteria, applies a strategic bonus to promote geographic diversity, makes admission decisions, and generates a comprehensive summary report. The system is designed to be transparent and run without any external dependencies like databases or web services.

### Key Features:
- **Holistic Applicant Evaluation:** Calculates a weighted score based on GPA, SAT scores, extracurriculars, and essay quality.
- **Geographic Diversity Engine:** Dynamically applies bonus points to applicants from under-represented states to help achieve a target geographic distribution in the admitted cohort.
- **Automated Decision Making:** Sorts applicants based on their final score and assigns 'Admit', 'Waitlist', or 'Reject' statuses based on configured cohort and waitlist sizes.
- **Comprehensive Reporting:** Generates a detailed text-based report summarizing cohort statistics, scoring metrics, and the geographic makeup of the admitted class.
- **Self-Contained Execution:** Includes a sample data generator, allowing the entire process to be run and demonstrated from a single script.

---

## 2. Code Structure

The application is organized into several logical sections within a single Python script:

1.  **Configuration:** A centralized dataclass (`AdmissionsConfig`) holds all tunable parameters for the admissions process.
2.  **Data Structures:** A primary dataclass (`Applicant`) defines the schema for storing all applicant-related information.
3.  **Core Logic:** A set of functions that perform the main tasks of scoring, applying bonuses, and making decisions.
4.  **Reporting:** Functions dedicated to generating the final summary report.
5.  **Data Generation:** A utility function to create a randomized applicant pool for demonstration purposes.
6.  **Main Execution:** A `main` function that orchestrates the entire workflow from data generation to reporting.

---

## 3. Configuration

### Class `AdmissionsConfig`

A frozen dataclass that centralizes all configurable parameters for the admissions process. Using a frozen dataclass ensures that these settings are immutable during a single run, preventing accidental modification.

**Attributes:**

-   `scoring_weights` (Dict[str, float]):
    -   **Description:** A dictionary defining the weight of each component in the holistic score calculation. The keys correspond to the applicant's attributes, and the values are the percentage weights (e.g., 0.40 for 40%). The sum of values should ideally be 1.0.
    -   **Default:** `{"gpa": 0.40, "sat": 0.30, "extracurriculars": 0.20, "essay": 0.10}`

-   `target_geographic_distribution` (Dict[str, float]):
    -   **Description:** A dictionary specifying the desired percentage of the incoming class from each state. The keys are two-letter state abbreviations, and the values are the target proportions (e.g., 0.20 for 20%). States not listed are assumed to have a target of 0.0.
    -   **Default:** A dictionary representing a distribution skewed towards populous states.

-   `geographic_bonus_factor` (float):
    -   **Description:** The maximum number of points that can be awarded as a geographic bonus. The actual bonus is calculated as `bonus_factor * (target_proportion - current_proportion)`.
    -   **Default:** `15.0`

-   `target_cohort_size` (int):
    -   **Description:** The target number of students to be admitted.
    -   **Default:** `150`

-   `waitlist_size` (int):
    -   **Description:** The number of students to be placed on the waitlist.
    *   **Default:** `50`

---

## 4. Data Structures

### Class `Applicant`

A dataclass representing a single applicant and all their associated data. It stores both the initial input data and the results computed during the admissions process.

**Attributes:**

-   `applicant_id` (int): A unique identifier for the applicant.
-   `gpa` (float): The applicant's Grade Point Average. Expected scale: 0.0 - 4.0.
-   `sat_score` (int): The applicant's SAT score. Expected scale: 400 - 1600.
-   `extracurricular_score` (int): A subjective score for the quality and depth of extracurricular activities. Expected scale: 1 - 10.
-   `essay_score` (int): A subjective score for the quality of the admissions essay. Expected scale: 1 - 10.
-   `state` (str): The applicant's two-letter home state abbreviation (e.g., 'CA', 'NY').

**Computed Attributes (initialized post-processing):**

-   `holistic_score` (float): The initial weighted score calculated from GPA, SAT, etc., before any bonuses are applied. Initialized to `0.0`.
-   `final_score` (float): The final score after the geographic diversity bonus has been applied. Used for final ranking. Initialized to `0.0`.
-   `decision` (str): The final admission decision ('Admit', 'Waitlist', 'Reject'). Initialized to `"Pending"`.

**Methods:**

-   `__post_init__(self)`:
    -   **Description:** A special dataclass method called after the object is initialized. It performs validation to ensure that the input scores (`gpa`, `sat_score`, etc.) are within their expected ranges.
    -   **Raises:** `ValueError` if any score is outside its valid range.

---

## 5. Core Logic Modules

This section details the functions responsible for the primary evaluation and decision-making processes.

### Function `_normalize_applicant_scores`

-   **Description:** A private helper function that converts an applicant's raw scores (GPA, SAT, etc.) to a normalized 0-100 scale. This allows for a fair, weighted comparison between metrics with different original scales.
-   **Parameters:**
    -   `applicant` (Applicant): The applicant object whose scores are to be normalized.
-   **Returns:**
    -   `Dict[str, float]`: A dictionary where keys are the score components (`"gpa"`, `"sat"`) and values are their corresponding normalized scores (0-100).

### Function `calculate_holistic_scores`

-   **Description:** Implements FR2. It iterates through a list of applicants, normalizes their scores, and computes a weighted holistic score based on the provided weights. The result is stored directly in the `holistic_score` attribute of each `Applicant` object.
-   **Parameters:**
    -   `applicants` (List[Applicant]): A list of all applicant objects to be scored.
    -   `weights` (Dict[str, float]): The scoring weights from the `AdmissionsConfig`.
-   **Returns:**
    -   `None`: This function modifies the `Applicant` objects in place.

### Function `apply_geographic_bonuses`

-   **Description:** Implements FR5. It calculates and applies a geographic diversity bonus to each applicant's score. The function first sorts applicants by their initial `holistic_score`. It then iterates through this sorted list, dynamically calculating the representation of each applicant's state within the pool of *higher-scoring* applicants already processed. A bonus is awarded if the state is under-represented relative to its target, promoting strong candidates from less-common regions. The final score is stored in the `final_score` attribute.
-   **Parameters:**
    -   `applicants` (List[Applicant]): The list of applicants who have already had their `holistic_score` calculated.
    -   `config` (AdmissionsConfig): The application configuration object, used to get the `target_geographic_distribution` and `geographic_bonus_factor`.
-   **Returns:**
    -   `None`: This function modifies the `Applicant` objects in place.

### Function `make_admission_decisions`

-   **Description:** Implements FR3. This function makes the final admission decisions. It sorts all applicants in descending order based on their `final_score`. It then partitions the sorted list into "Admit", "Waitlist", and "Reject" pools based on the `target_cohort_size` and `waitlist_size` defined in the configuration. The `decision` attribute of each applicant is updated accordingly.
-   **Parameters:**
    -   `applicants` (List[Applicant]): The list of applicants who have had their `final_score` calculated.
    -   `config` (AdmissionsConfig): The application configuration object.
-   **Returns:**
    -   `Tuple[List[Applicant], List[Applicant], List[Applicant]]`: A tuple containing three separate lists: the admitted pool, the waitlisted pool, and the rejected pool.

---

## 6. Reporting Modules

### Function `_format_distribution_table`

-   **Description:** A private helper function used by `generate_summary_report`. It creates a formatted, multi-line string table that compares the actual geographic distribution of the admitted cohort against the target distribution.
-   **Parameters:**
    -   `admitted_pool` (List[Applicant]): The list of admitted applicants.
    -   `config` (AdmissionsConfig): The application configuration object containing the target distribution.
-   **Returns:**
    -   `List[str]`: A list of strings, where each string is a formatted row for the report table.

### Function `generate_summary_report`

-   **Description:** Implements FR4 and NFR2. It compiles all results into a single, human-readable summary report. The report includes transparent scoring metrics, overall application statistics (e.g., acceptance rate), a profile of the admitted cohort (e.g., average GPA/SAT), and the detailed geographic distribution analysis.
-   **Parameters:**
    -   `all_applicants` (List[Applicant]): The complete list of all original applicants.
    -   `admitted_pool` (List[Applicant]): The list of admitted applicants.
    -   `waitlisted_pool` (List[Applicant]): The list of waitlisted applicants.
    -   `rejected_pool` (List[Applicant]): The list of rejected applicants.
    -   `config` (AdmissionsConfig): The application configuration object.
-   **Returns:**
    -   `str`: A single, formatted string containing the entire summary report.

---

## 7. Data Generation & Execution

### Function `generate_sample_applicants`

-   **Description:** Implements NFR1. A utility function to create a list of randomized `Applicant` objects for testing and demonstration. It generates plausible, correlated academic scores and distributes applicants across states based on the weights in the `target_geographic_distribution`.
-   **Parameters:**
    -   `num_applicants` (int): The total number of sample applicants to create.
    -   `config` (AdmissionsConfig): The configuration object, used for state distribution weights.
-   **Returns:**
    -   `List[Applicant]`: A list of newly instantiated `Applicant` objects.

### Function `main`

-   **Description:** The main entry point for the application. It orchestrates the entire admissions workflow by calling the core logic and reporting functions in the correct sequence.
-   **Workflow:**
    1.  Initializes the `AdmissionsConfig`.
    2.  Calls `generate_sample_applicants` to create an in-memory applicant pool.
    3.  Calls `calculate_holistic_scores` to perform initial scoring.
    4.  Calls `apply_geographic_bonuses` to adjust scores for diversity.
    5.  Calls `make_admission_decisions` to determine final outcomes.
    6.  Calls `generate_summary_report` with the results.
    7.  Prints the final report to the console.
-   **Parameters:** None.
-   **Returns:** None.