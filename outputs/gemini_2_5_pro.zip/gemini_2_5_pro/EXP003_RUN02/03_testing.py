#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Unit Tests for the University Admissions Screening System.

This test suite uses pytest to validate the functionality of the admissions
system, covering standard cases, boundary conditions, and edge cases for
each component of the application.
"""

import pytest
from dataclasses import FrozenInstanceError
import statistics

# Import all components from the refactored code
from admissions_system import (
    AdmissionsConfig,
    Applicant,
    _normalize_applicant_scores,
    calculate_holistic_scores,
    apply_geographic_bonuses,
    make_admission_decisions,
    generate_summary_report,
    _format_distribution_table,
    generate_sample_applicants
)

# =============================================================================
# --- Pytest Fixtures ---
# =============================================================================

@pytest.fixture
def default_config() -> AdmissionsConfig:
    """Provides a default, unaltered AdmissionsConfig instance."""
    return AdmissionsConfig()

@pytest.fixture
def perfect_applicant() -> Applicant:
    """An applicant with the highest possible scores."""
    return Applicant(
        applicant_id=1, gpa=4.0, sat_score=1600,
        extracurricular_score=10, essay_score=10, state='CA'
    )

@pytest.fixture
def average_applicant() -> Applicant:
    """An applicant with average scores."""
    return Applicant(
        applicant_id=2, gpa=3.0, sat_score=1200,
        extracurricular_score=7, essay_score=6, state='TX'
    )

@pytest.fixture
def minimal_applicant() -> Applicant:
    """An applicant with the lowest possible scores."""
    return Applicant(
        applicant_id=3, gpa=0.0, sat_score=400,
        extracurricular_score=1, essay_score=1, state='NY'
    )

@pytest.fixture
def sample_applicants() -> list[Applicant]:
    """A list of diverse applicants for testing group functions."""
    return [
        Applicant(1, 4.0, 1550, 9, 8, 'CA'),  # High stats
        Applicant(2, 3.5, 1400, 10, 9, 'TX'), # Strong stats
        Applicant(3, 3.8, 1500, 7, 7, 'CA'),  # High stats, same state
        Applicant(4, 3.2, 1300, 6, 5, 'FL'),  # Mid stats
        Applicant(5, 2.8, 1100, 4, 3, 'OH'),  # Low stats
        Applicant(6, 3.9, 1520, 10, 10, 'WY'),# High stats, rare state
    ]

# =============================================================================
# --- Test Cases ---
# =============================================================================

class TestAdmissionsConfig:
    """Tests for the AdmissionsConfig dataclass."""

    def test_default_values_exist(self, default_config):
        """FR2, FR3, FR5: Verify that default configuration values are set."""
        assert isinstance(default_config.scoring_weights, dict)
        assert "gpa" in default_config.scoring_weights
        assert isinstance(default_config.target_geographic_distribution, dict)
        assert "CA" in default_config.target_geographic_distribution
        assert default_config.geographic_bonus_factor > 0
        assert default_config.target_cohort_size > 0

    def test_is_immutable(self, default_config):
        """NFR1: Verify the config is frozen and cannot be changed at runtime."""
        with pytest.raises(FrozenInstanceError):
            default_config.target_cohort_size = 200
        with pytest.raises(FrozenInstanceError):
            default_config.scoring_weights['gpa'] = 0.5


class TestApplicant:
    """Tests for the Applicant dataclass (FR1)."""

    def test_successful_creation(self, average_applicant):
        """Test successful creation with valid data."""
        assert average_applicant.applicant_id == 2
        assert average_applicant.gpa == 3.0
        assert average_applicant.state == 'TX'
        assert average_applicant.holistic_score == 0.0  # Default value
        assert average_applicant.decision == "Pending"    # Default value

    @pytest.mark.parametrize("kwargs, error_msg", [
        ({"gpa": -0.1}, "GPA must be between 0.0 and 4.0"),
        ({"gpa": 4.1}, "GPA must be between 0.0 and 4.0"),
        ({"sat_score": 399}, "SAT score must be between 400 and 1600"),
        ({"sat_score": 1601}, "SAT score must be between 400 and 1600"),
        ({"extracurricular_score": 0}, "Extracurricular score must be between 1 and 10"),
        ({"extracurricular_score": 11}, "Extracurricular score must be between 1 and 10"),
        ({"essay_score": 0}, "Essay score must be between 1 and 10"),
        ({"essay_score": 11}, "Essay score must be between 1 and 10"),
    ])
    def test_invalid_data_raises_value_error(self, kwargs, error_msg):
        """Test that out-of-range inputs raise ValueError on initialization."""
        base_args = {
            "applicant_id": 99, "gpa": 3.5, "sat_score": 1400,
            "extracurricular_score": 8, "essay_score": 8, "state": "CA"
        }
        base_args.update(kwargs)
        with pytest.raises(ValueError, match=error_msg):
            Applicant(**base_args)

    @pytest.mark.parametrize("kwargs", [
        {"gpa": 0.0}, {"gpa": 4.0},
        {"sat_score": 400}, {"sat_score": 1600},
        {"extracurricular_score": 1}, {"extracurricular_score": 10},
        {"essay_score": 1}, {"essay_score": 10},
    ])
    def test_boundary_conditions_are_valid(self, kwargs):
        """Test that values at the exact boundaries of valid ranges are accepted."""
        base_args = {
            "applicant_id": 99, "gpa": 3.5, "sat_score": 1400,
            "extracurricular_score": 8, "essay_score": 8, "state": "CA"
        }
        base_args.update(kwargs)
        try:
            Applicant(**base_args)
        except ValueError:
            pytest.fail(f"Applicant creation failed unexpectedly for boundary value: {kwargs}")


class TestNormalizationAndScoring:
    """Tests for score normalization and holistic score calculation (FR2)."""

    def test_normalize_scores_perfect(self, perfect_applicant):
        """Test normalization for a perfect applicant results in all 100s."""
        norm_scores = _normalize_applicant_scores(perfect_applicant)
        for score in norm_scores.values():
            assert score == pytest.approx(100.0)

    def test_normalize_scores_minimal(self, minimal_applicant):
        """Test normalization for a minimal applicant results in all 0s."""
        norm_scores = _normalize_applicant_scores(minimal_applicant)
        for score in norm_scores.values():
            assert score == pytest.approx(0.0)

    def test_normalize_scores_midpoint(self):
        """Test normalization for an applicant with scores at their midpoint."""
        mid_applicant = Applicant(4, 2.0, 1000, 5, 5, 'IL')
        norm_scores = _normalize_applicant_scores(mid_applicant)
        assert norm_scores['gpa'] == pytest.approx(50.0)
        assert norm_scores['sat'] == pytest.approx(50.0)
        assert norm_scores['extracurriculars'] == pytest.approx(50.0)
        assert norm_scores['essay'] == pytest.approx(50.0)

    def test_calculate_holistic_scores(self, default_config, perfect_applicant, minimal_applicant, average_applicant):
        """Test the main holistic score calculation function."""
        applicants = [perfect_applicant, minimal_applicant, average_applicant]
        calculate_holistic_scores(applicants, default_config.scoring_weights)

        # Perfect applicant should score 100
        assert perfect_applicant.holistic_score == pytest.approx(100.0)
        # Minimal applicant should score 0
        assert minimal_applicant.holistic_score == pytest.approx(0.0)
        # Manually calculate for average applicant
        # norm_gpa = 3.0/4.0 * 100 = 75
        # norm_sat = (1200-400)/(1600-400) * 100 = 800/1200 * 100 = 66.67
        # norm_extra = 7/10 * 100 = 70
        # norm_essay = 6/10 * 100 = 60
        # score = 75*0.4 + 66.67*0.3 + 70*0.2 + 60*0.1 = 30 + 20 + 14 + 6 = 70.0
        assert average_applicant.holistic_score == pytest.approx(70.0)

    def test_calculate_holistic_scores_empty_list(self, default_config):
        """Test that the function runs without error on an empty applicant list."""
        applicants = []
        try:
            calculate_holistic_scores(applicants, default_config.scoring_weights)
        except Exception as e:
            pytest.fail(f"Function failed on empty list with error: {e}")
        assert applicants == []


class TestGeographicBonuses:
    """Tests for the geographic bonus logic (FR5)."""

    def test_apply_geographic_bonuses_empty_list(self, default_config):
        """Test that the function handles an empty list gracefully."""
        applicants = []
        try:
            apply_geographic_bonuses(applicants, default_config)
        except Exception as e:
            pytest.fail(f"Function failed on empty list with error: {e}")
        assert applicants == []

    def test_apply_geographic_bonuses_logic(self, default_config):
        """Test the bonus logic with a controlled set of applicants."""
        # applicant1 is from a high-target state, applicant2 from an untargeted one.
        applicant1 = Applicant(1, 4.0, 1600, 10, 10, 'CA') # holistic=100
        applicant2 = Applicant(2, 3.9, 1580, 10, 10, 'XX') # holistic=~98
        applicant3 = Applicant(3, 3.8, 1560, 10, 10, 'CA') # holistic=~96
        applicants = [applicant2, applicant3, applicant1] # Intentionally unsorted

        calculate_holistic_scores(applicants, default_config.scoring_weights)
        apply_geographic_bonuses(applicants, default_config)

        app1_res = next(a for a in applicants if a.applicant_id == 1)
        app2_res = next(a for a in applicants if a.applicant_id == 2)
        app3_res = next(a for a in applicants if a.applicant_id == 3)

        # Applicant 1 is processed first (highest holistic score). Pool is empty.
        # target_prop for CA is 0.2, current is 0. Bonus = 15 * (0.2 - 0) = 3.0
        assert app1_res.final_score == pytest.approx(100.0 + 3.0)

        # Applicant 2 is processed second. Pool is ['CA'].
        # target_prop for XX is 0.0, current is 0. Bonus = 15 * (0.0 - 0) = 0.0
        assert app2_res.final_score == pytest.approx(app2_res.holistic_score + 0.0)

        # Applicant 3 is processed third. Pool is ['CA', 'XX'].
        # target_prop for CA is 0.2. current for CA is 1/2 = 0.5.
        # gap = 0.2 - 0.5 = -0.3. Bonus = 15 * -0.3 = -4.5
        assert app3_res.final_score == pytest.approx(app3_res.holistic_score - 4.5)

        # Verify holistic score is not modified
        assert app1_res.holistic_score == 100.0


class TestAdmissionDecisions:
    """Tests for the final decision-making process (FR3)."""

    def test_make_admission_decisions_full_split(self, default_config):
        """Test a scenario where applicants are split into all three pools."""
        # Config: Admit 150, Waitlist 50
        applicants = [Applicant(i, 4.0, 1600, 10, 10, 'CA') for i in range(250)]
        for i, app in enumerate(applicants):
            app.final_score = 100 - i # Create a clear ranking

        admitted, waitlisted, rejected = make_admission_decisions(applicants, default_config)

        assert len(admitted) == default_config.target_cohort_size
        assert len(waitlisted) == default_config.waitlist_size
        assert len(rejected) == 250 - 150 - 50

        assert all(a.decision == "Admit" for a in admitted)
        assert all(a.decision == "Waitlist" for a in waitlisted)
        assert all(a.decision == "Reject" for a in rejected)

        # Check sorting: highest score should be in admitted
        assert admitted[0].final_score == 100

    def test_fewer_applicants_than_cohort_size(self, default_config):
        """Test where all applicants should be admitted."""
        applicants = [Applicant(i, 3.5, 1400, 8, 8, 'TX') for i in range(100)]
        for app in applicants:
            app.final_score = 80.0

        admitted, waitlisted, rejected = make_admission_decisions(applicants, default_config)

        assert len(admitted) == 100
        assert len(waitlisted) == 0
        assert len(rejected) == 0

    def test_fewer_applicants_than_admit_plus_waitlist(self, default_config):
        """Test with no rejections, only admits and waitlists."""
        # Total capacity is 150 + 50 = 200. We provide 180 applicants.
        applicants = [Applicant(i, 3.5, 1400, 8, 8, 'TX') for i in range(180)]
        for app in applicants:
            app.final_score = 80.0

        admitted, waitlisted, rejected = make_admission_decisions(applicants, default_config)

        assert len(admitted) == default_config.target_cohort_size # 150
        assert len(waitlisted) == 180 - 150 # 30
        assert len(rejected) == 0

    def test_empty_applicant_list(self, default_config):
        """Test that the function returns three empty lists for no applicants."""
        admitted, waitlisted, rejected = make_admission_decisions([], default_config)
        assert admitted == []
        assert waitlisted == []
        assert rejected == []


class TestReporting:
    """Tests for report generation (FR4, NFR2)."""

    def test_generate_summary_report_empty_admitted_pool(self, default_config):
        """Test the specific message for when the admitted pool is empty."""
        report = generate_summary_report([], [], [], [], default_config)
        assert "No report to generate: admitted pool is empty." in report

    def test_generate_summary_report_contains_all_sections(self, default_config, sample_applicants):
        """Check that key sections and data points are present in the report."""
        admitted = sample_applicants[:2]
        waitlisted = sample_applicants[2:4]
        rejected = sample_applicants[4:]
        all_apps = admitted + waitlisted + rejected

        report = generate_summary_report(all_apps, admitted, waitlisted, rejected, default_config)

        assert "University Admissions Summary Report" in report
        assert "Scoring Metrics" in report # NFR2
        assert "gpa" in report.lower() and "40%" in report
        assert "Geographic Bonus Factor" in report
        assert "Overall Application Statistics" in report
        assert f"Total Applicants:        {len(all_apps)}" in report
        assert "Admitted Cohort Profile" in report
        avg_gpa = statistics.mean(a.gpa for a in admitted)
        assert f"Average GPA:             {avg_gpa:.2f}" in report
        assert "Geographic Distribution of Admitted Cohort" in report

    def test_report_handles_zero_total_applicants(self, default_config):
        """Test that the report does not crash with zero total applicants."""
        # The original code would raise a ZeroDivisionError here.
        # This test verifies that behavior.
        with pytest.raises(ZeroDivisionError):
            generate_summary_report([], [Applicant(1, 4.0, 1600, 10, 10, 'CA')], [], [], default_config)
    
    def test_format_distribution_table(self, default_config):
        """Test the private helper for formatting the geographic distribution table."""
        admitted = [
            Applicant(1, 4.0, 1500, 8, 8, 'CA'),
            Applicant(2, 4.0, 1500, 8, 8, 'CA'),
            Applicant(3, 4.0, 1500, 8, 8, 'TX'),
            Applicant(4, 4.0, 1500, 8, 8, 'XX') # Untargeted state
        ]
        
        table_lines = _format_distribution_table(admitted, default_config)
        table_str = "\n".join(table_lines)
        
        assert "State   Actual %   Target %   Delta" in table_str
        # 2/4 = 50% for CA. Target is 20%. Delta should be +30.0
        assert "CA      50.0%      20.0%      +30.0" in table_str
        # 1/4 = 25% for TX. Target is 10%. Delta should be +15.0
        assert "TX      25.0%      10.0%      +15.0" in table_str
        # 1/4 = 25% for XX. Target is 0%. Delta should be +25.0
        assert "XX      25.0%      0.0%       +25.0" in table_str
        # Check sorting by actual %: CA should be first in data rows
        assert table_lines[2].startswith("CA")


class TestDataGeneration:
    """Tests for the sample data generator (NFR1)."""

    def test_generate_sample_applicants_count(self, default_config):
        """Verify the function generates the requested number of applicants."""
        num = 50
        applicants = generate_sample_applicants(num, default_config)
        assert len(applicants) == num

    def test_generate_sample_applicants_validity(self, default_config):
        """Perform a smoke test to ensure generated applicants are valid."""
        applicants = generate_sample_applicants(10, default_config)
        for app in applicants:
            assert isinstance(app, Applicant)
            # The __post_init__ already validates ranges, so if this
            # doesn't raise an error, the data is within valid bounds.
            assert app.applicant_id > 10000