#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
University Admissions Screening System

This self-contained Python application models a holistic university admissions
process. It evaluates applicants based on multiple criteria, applies a
geographic diversity bonus, makes admission decisions, and generates a
summary report of the results.

This version has been refactored for improved modularity, clarity, and
adherence to PEP 8 standards.
"""

import random
import statistics
from dataclasses import dataclass, field
from typing import List, Dict, Tuple

# =============================================================================
# --- Configuration ---
# =============================================================================

@dataclass(frozen=True)
class AdmissionsConfig:
    """
    Centralized configuration for the admissions process.
    Using a frozen dataclass ensures settings are immutable during execution.
    """
    # FR2, NFR2: Holistic Score Weights (transparently reported)
    scoring_weights: Dict[str, float] = field(default_factory=lambda: {
        "gpa": 0.40,
        "sat": 0.30,
        "extracurriculars": 0.20,
        "essay": 0.10,
    })

    # FR5: Desired percentage of the incoming class from each state.
    target_geographic_distribution: Dict[str, float] = field(
        default_factory=lambda: {
            'CA': 0.20, 'TX': 0.10, 'NY': 0.10, 'FL': 0.08, 'IL': 0.05,
            'PA': 0.05, 'OH': 0.04, 'GA': 0.04, 'MI': 0.03, 'NC': 0.03,
            'MA': 0.02, 'NJ': 0.02, 'VA': 0.02, 'WA': 0.02, 'AZ': 0.01,
            'CO': 0.01, 'IN': 0.01, 'MD': 0.01, 'MN': 0.01, 'MO': 0.01,
            'OR': 0.01, 'TN': 0.01, 'WI': 0.01,
        }
    )

    # FR5: Max bonus points for applicants from under-represented states.
    geographic_bonus_factor: float = 15.0

    # FR3: Admission Decision Parameters
    target_cohort_size: int = 150
    waitlist_size: int = 50


# =============================================================================
# --- Data Structures ---
# =============================================================================

@dataclass
class Applicant:
    """
    Stores all data for a single applicant, fulfilling FR1.
    Includes raw scores, demographic info, and fields for computed results.
    """
    applicant_id: int
    gpa: float  # Scale: 0.0 - 4.0
    sat_score: int  # Scale: 400 - 1600
    extracurricular_score: int  # Scale: 1 - 10
    essay_score: int  # Scale: 1 - 10
    state: str

    # Computed fields, initialized after processing
    holistic_score: float = field(init=False, default=0.0)
    final_score: float = field(init=False, default=0.0)
    decision: str = field(init=False, default="Pending")

    def __post_init__(self):
        """Validates input data upon object creation."""
        if not (0.0 <= self.gpa <= 4.0):
            raise ValueError("GPA must be between 0.0 and 4.0")
        if not (400 <= self.sat_score <= 1600):
            raise ValueError("SAT score must be between 400 and 1600")
        if not (1 <= self.extracurricular_score <= 10):
            raise ValueError("Extracurricular score must be between 1 and 10")
        if not (1 <= self.essay_score <= 10):
            raise ValueError("Essay score must be between 1 and 10")


# =============================================================================
# --- Core Logic ---
# =============================================================================

def _normalize_applicant_scores(applicant: Applicant) -> Dict[str, float]:
    """Converts an applicant's raw scores to a common 0-100 scale."""
    normalized_gpa = (applicant.gpa / 4.0) * 100
    normalized_sat = ((applicant.sat_score - 400) / (1600 - 400)) * 100
    normalized_extracurriculars = (applicant.extracurricular_score / 10) * 100
    normalized_essay = (applicant.essay_score / 10) * 100
    return {
        "gpa": normalized_gpa,
        "sat": normalized_sat,
        "extracurriculars": normalized_extracurriculars,
        "essay": normalized_essay,
    }


def calculate_holistic_scores(
    applicants: List[Applicant],
    weights: Dict[str, float]
):
    """
    FR2: Computes and assigns a holistic score for each applicant in place.
    """
    for applicant in applicants:
        norm_scores = _normalize_applicant_scores(applicant)
        score = (
            norm_scores["gpa"] * weights["gpa"] +
            norm_scores["sat"] * weights["sat"] +
            norm_scores["extracurriculars"] * weights["extracurriculars"] +
            norm_scores["essay"] * weights["essay"]
        )
        applicant.holistic_score = round(score, 2)


def apply_geographic_bonuses(
    applicants: List[Applicant],
    config: AdmissionsConfig
):
    """
    FR5: Calculates and applies a geographic diversity bonus to each applicant.

    This function sorts applicants by their initial score and then iteratively
    calculates a dynamic bonus. The bonus is higher for applicants from states
    that are under-represented in the high-scoring applicant pool. This gives
    strong candidates from less-common regions a better chance.
    """
    sorted_by_holistic = sorted(
        applicants, key=lambda a: a.holistic_score, reverse=True
    )

    processed_applicant_states: List[str] = []
    for applicant in sorted_by_holistic:
        current_pool_size = len(processed_applicant_states)
        if current_pool_size > 0:
            state_count = processed_applicant_states.count(applicant.state)
            current_proportion = state_count / current_pool_size
        else:
            current_proportion = 0

        target_proportion = config.target_geographic_distribution.get(
            applicant.state, 0.0
        )

        representation_gap = target_proportion - current_proportion
        bonus = round(config.geographic_bonus_factor * representation_gap, 2)
        applicant.final_score = applicant.holistic_score + bonus

        processed_applicant_states.append(applicant.state)


def make_admission_decisions(
    applicants: List[Applicant],
    config: AdmissionsConfig
) -> Tuple[List[Applicant], List[Applicant], List[Applicant]]:
    """
    FR3: Assigns final decisions and partitions applicants into pools.

    Returns:
        A tuple containing three lists: (admitted, waitlisted, rejected).
    """
    final_ranking = sorted(
        applicants, key=lambda a: a.final_score, reverse=True
    )

    admitted_pool: List[Applicant] = []
    waitlisted_pool: List[Applicant] = []
    rejected_pool: List[Applicant] = []

    admit_cutoff = config.target_cohort_size
    waitlist_cutoff = admit_cutoff + config.waitlist_size

    for i, applicant in enumerate(final_ranking):
        if i < admit_cutoff:
            applicant.decision = "Admit"
            admitted_pool.append(applicant)
        elif i < waitlist_cutoff:
            applicant.decision = "Waitlist"
            waitlisted_pool.append(applicant)
        else:
            applicant.decision = "Reject"
            rejected_pool.append(applicant)

    return admitted_pool, waitlisted_pool, rejected_pool


# =============================================================================
# --- Reporting ---
# =============================================================================

def _format_distribution_table(
    admitted_pool: List[Applicant],
    config: AdmissionsConfig
) -> List[str]:
    """Helper to create the geographic distribution part of the report."""
    report_lines = []
    report_lines.append(f"{'State':<7} {'Actual %':<10} {'Target %':<10} {'Delta':<8}")
    report_lines.append(f"{'-'*5:<7} {'-'*8:<10} {'-'*8:<10} {'-'*6:<8}")

    admitted_count = len(admitted_pool)
    admitted_states = [a.state for a in admitted_pool]
    state_counts = {s: admitted_states.count(s) for s in set(admitted_states)}

    all_report_states = set(
        config.target_geographic_distribution.keys()
    ) | set(state_counts.keys())

    dist_data = []
    for state in sorted(list(all_report_states)):
        actual_pct = (state_counts.get(state, 0) / admitted_count) * 100
        target_pct = config.target_geographic_distribution.get(state, 0.0) * 100
        delta = actual_pct - target_pct
        dist_data.append((state, actual_pct, target_pct, delta))

    dist_data.sort(key=lambda x: x[1], reverse=True) # Sort by actual %

    for state, actual, target, delta in dist_data:
        delta_str = f"+{delta:.1f}" if delta > 0 else f"{delta:.1f}"
        report_lines.append(
            f"{state:<7} {actual:<9.1f}% {target:<9.1f}% {delta_str:<8}"
        )
    return report_lines


def generate_summary_report(
    all_applicants: List[Applicant],
    admitted_pool: List[Applicant],
    waitlisted_pool: List[Applicant],
    rejected_pool: List[Applicant],
    config: AdmissionsConfig
) -> str:
    """
    FR4 & NFR2: Generates a summary report of cohort statistics.
    """
    if not admitted_pool:
        return "No report to generate: admitted pool is empty."

    # --- Header ---
    report = ["="*50, "      University Admissions Summary Report", "="*50]

    # --- NFR2: Transparent Scoring Metrics ---
    report.append("\n--- Scoring Metrics ---")
    report.append("Holistic Score Weights:")
    for key, val in config.scoring_weights.items():
        report.append(f"  - {key.capitalize():<18}: {val:.0%}")
    report.append(
        f"Geographic Bonus Factor: Up to {config.geographic_bonus_factor} "
        "points"
    )

    # --- Overall Statistics ---
    total_applicants = len(all_applicants)
    admitted_count = len(admitted_pool)
    acceptance_rate = (admitted_count / total_applicants) * 100
    report.append("\n--- Overall Application Statistics ---")
    report.append(f"Total Applicants:        {total_applicants}")
    report.append(f"Admitted:                {admitted_count}")
    report.append(f"Waitlisted:              {len(waitlisted_pool)}")
    report.append(f"Rejected:                {len(rejected_pool)}")
    report.append(f"Acceptance Rate:         {acceptance_rate:.2f}%")

    # --- Admitted Cohort Profile ---
    admitted_gpas = [a.gpa for a in admitted_pool]
    admitted_sats = [a.sat_score for a in admitted_pool]
    report.append("\n--- Admitted Cohort Profile ---")
    report.append(f"Average GPA:             {statistics.mean(admitted_gpas):.2f}")
    report.append(f"Median GPA:              {statistics.median(admitted_gpas):.2f}")
    report.append(f"Average SAT Score:       {statistics.mean(admitted_sats):.0f}")
    report.append(f"Median SAT Score:        {statistics.median(admitted_sats):.0f}")

    # --- Geographic Distribution ---
    report.append("\n--- Geographic Distribution of Admitted Cohort ---")
    report.extend(_format_distribution_table(admitted_pool, config))

    report.append("="*50)
    return "\n".join(report)


# =============================================================================
# --- Data Generation ---
# =============================================================================

def generate_sample_applicants(
    num_applicants: int,
    config: AdmissionsConfig
) -> List[Applicant]:
    """
    NFR1: Creates randomized Applicant objects for a self-contained demo.
    """
    applicants = []
    states = list(config.target_geographic_distribution.keys())
    state_weights = list(config.target_geographic_distribution.values())

    other_states = ['NM', 'WV', 'ID', 'MT', 'WY']
    states.extend(other_states)
    state_weights.extend([0.005] * len(other_states))

    for i in range(num_applicants):
        base_academic_performance = random.uniform(0.6, 1.0)
        gpa = round(
            max(2.5, min(4.0, 2.5 + (base_academic_performance +
                random.uniform(-0.1, 0.1)) * 1.5)), 2
        )
        sat = int(
            max(800, min(1600, 1000 + (base_academic_performance +
                random.uniform(-0.15, 0.15)) * 600))
        )
        applicant = Applicant(
            applicant_id=10001 + i,
            gpa=gpa,
            sat_score=sat,
            extracurricular_score=random.randint(4, 10),
            essay_score=random.randint(5, 10),
            state=random.choices(states, weights=state_weights, k=1)[0]
        )
        applicants.append(applicant)
    return applicants


# =============================================================================
# --- Main Execution ---
# =============================================================================

def main():
    """Main function to run the admissions screening process."""
    # 1. Initialize configuration
    config = AdmissionsConfig()
    total_applicants_to_generate = 1000
    print(f"Generating {total_applicants_to_generate} sample applicants...")

    # 2. FR1 & NFR1: Generate and store applicant data in memory
    applicants = generate_sample_applicants(total_applicants_to_generate, config)

    # 3. Execute the admissions process in sequential, modular steps
    print("Starting admissions screening process...")

    calculate_holistic_scores(applicants, config.scoring_weights)
    print("1. Holistic scores calculated.")

    apply_geographic_bonuses(applicants, config)
    print("2. Geographic diversity bonuses applied.")

    admitted, waitlisted, rejected = make_admission_decisions(applicants, config)
    print("3. Final admission decisions have been made.")
    print("Process complete.\n")

    # 4. Generate and display the final report
    report = generate_summary_report(
        applicants, admitted, waitlisted, rejected, config
    )
    print(report)


if __name__ == "__main__":
    main()