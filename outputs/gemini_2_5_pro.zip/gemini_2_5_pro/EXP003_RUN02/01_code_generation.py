#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
University Admissions Screening System

This self-contained Python application models a holistic university admissions
process. It evaluates applicants based on multiple criteria, applies a
geographic diversity bonus, makes admission decisions, and generates a
summary report of the results.
"""

import random
import statistics
from dataclasses import dataclass, field
from typing import List, Dict, Any, Tuple

# --- Configuration ---

# FR2: Holistic Score Weights
# NFR2: These weights are transparently reported in the final summary.
SCORING_WEIGHTS = {
    "gpa": 0.40,  # 40%
    "sat": 0.30,  # 30%
    "extracurriculars": 0.20,  # 20%
    "essay": 0.10,  # 10%
}

# FR5: Geographic Distribution Targets
# Defines the desired percentage of the incoming class from each state.
# States not listed have a target of 0. The sum should ideally be 1.0.
TARGET_GEOGRAPHIC_DISTRIBUTION = {
    'CA': 0.20, 'TX': 0.10, 'NY': 0.10, 'FL': 0.08,
    'IL': 0.05, 'PA': 0.05, 'OH': 0.04, 'GA': 0.04,
    'MI': 0.03, 'NC': 0.03, 'WA': 0.02, 'VA': 0.02,
    'MA': 0.02, 'NJ': 0.02,
    # Representing a pool of smaller states
    'CO': 0.01, 'AZ': 0.01, 'OR': 0.01, 'MD': 0.01,
    'MN': 0.01, 'WI': 0.01, 'TN': 0.01, 'IN': 0.01,
    'MO': 0.01, 'CT': 0.01, 'SC': 0.01, 'AL': 0.01,
    'LA': 0.01, 'KY': 0.01, 'OK': 0.01, 'KS': 0.01,
    'IA': 0.01, 'UT': 0.01, 'NV': 0.01, 'AR': 0.01,
    'MS': 0.01, 'NE': 0.01,
    # Smallest states get a collective target through the bonus system
}

# The maximum bonus points an applicant from an under-represented state can receive.
# This factor amplifies the need for geographic diversity.
GEOGRAPHIC_BONUS_FACTOR = 15.0

# FR3: Admission Decision Parameters
TARGET_COHORT_SIZE = 150
WAITLIST_SIZE = 50

# --- Data Structures ---

@dataclass
class Applicant:
    """
    FR1: Stores all data for a single applicant.
    """
    applicant_id: int
    gpa: float  # Scale: 0.0 - 4.0
    sat_score: int  # Scale: 400 - 1600
    extracurricular_score: int  # Scale: 1 - 10
    essay_score: int  # Scale: 1 - 10
    state: str

    # Computed fields
    holistic_score: float = field(init=False, default=0.0)
    final_score: float = field(init=False, default=0.0)
    decision: str = field(init=False, default="Pending")

    def __post_init__(self):
        """Validates input data upon object creation."""
        if not (0.0 <= self.gpa <= 4.0):
            raise ValueError("GPA must be between 0.0 and 4.0")
        if not (400 <= self.sat_score <= 1600):
            raise ValueError("SAT score must be between 400 and 1600")
        if not (1 <= self.extracurricular_score <= 10):
            raise ValueError("Extracurricular score must be between 1 and 10")
        if not (1 <= self.essay_score <= 10):
            raise ValueError("Essay score must be between 1 and 10")


class AdmissionsSystem:
    """
    Orchestrates the entire admissions screening process from scoring to reporting.
    """

    def __init__(self, applicants: List[Applicant], config: Dict[str, Any]):
        """
        Initializes the system with a list of applicants and configuration.
        """
        self.all_applicants = applicants
        self.config = config
        self.admitted_pool: List[Applicant] = []
        self.waitlisted_pool: List[Applicant] = []
        self.rejected_pool: List[Applicant] = []

    def _normalize_scores(self, applicant: Applicant) -> Dict[str, float]:
        """Converts raw scores to a common 0-100 scale."""
        normalized_gpa = (applicant.gpa / 4.0) * 100
        normalized_sat = ((applicant.sat_score - 400) / (1600 - 400)) * 100
        normalized_extracurriculars = (applicant.extracurricular_score / 10) * 100
        normalized_essay = (applicant.essay_score / 10) * 100
        return {
            "gpa": normalized_gpa,
            "sat": normalized_sat,
            "extracurriculars": normalized_extracurriculars,
            "essay": normalized_essay,
        }

    def _calculate_holistic_scores(self):
        """
        FR2: Computes a holistic admission score for each applicant based on
        weighted academic and non-academic factors.
        """
        weights = self.config['scoring_weights']
        for applicant in self.all_applicants:
            norm_scores = self._normalize_scores(applicant)
            score = (
                norm_scores["gpa"] * weights["gpa"] +
                norm_scores["sat"] * weights["sat"] +
                norm_scores["extracurriculars"] * weights["extracurriculars"] +
                norm_scores["essay"] * weights["essay"]
            )
            applicant.holistic_score = round(score, 2)

    def _apply_geographic_bonus(self):
        """
        FR5: Calculates and applies a geographic diversity bonus.

        This method sorts applicants by their initial holistic score and then
        iteratively calculates a bonus. The bonus is dynamic: it's higher for
        applicants from states that are currently under-represented in the
        top-ranking pool. This ensures that strong candidates from less-common
        geographies are given extra consideration.
        """
        # Sort applicants by initial score to process the strongest first
        sorted_by_holistic = sorted(self.all_applicants, key=lambda a: a.holistic_score, reverse=True)

        temp_admit_pool_states: List[str] = []
        target_dist = self.config['target_geo_dist']
        bonus_factor = self.config['geo_bonus_factor']

        for applicant in sorted_by_holistic:
            # Calculate current distribution based on stronger applicants already processed
            current_pool_size = len(temp_admit_pool_states)
            if current_pool_size > 0:
                state_count = temp_admit_pool_states.count(applicant.state)
                current_proportion = state_count / current_pool_size
            else:
                current_proportion = 0

            target_proportion = target_dist.get(applicant.state, 0.0)

            # Bonus is proportional to how much the state is under-represented
            # A negative bonus (penalty) is applied if the state is over-represented
            representation_gap = target_proportion - current_proportion
            bonus = round(bonus_factor * representation_gap, 2)
            
            applicant.final_score = applicant.holistic_score + bonus

            # Add applicant's state to the temporary pool to influence subsequent calculations
            temp_admit_pool_states.append(applicant.state)

    def _make_decisions(self):
        """
        FR3: Automates admission decisions based on final scores and cohort size.
        """
        # Sort all applicants by their final, geographically-adjusted score
        final_ranking = sorted(self.all_applicants, key=lambda a: a.final_score, reverse=True)

        cohort_size = self.config['cohort_size']
        waitlist_size = self.config['waitlist_size']

        for i, applicant in enumerate(final_ranking):
            if i < cohort_size:
                applicant.decision = "Admit"
                self.admitted_pool.append(applicant)
            elif i < cohort_size + waitlist_size:
                applicant.decision = "Waitlist"
                self.waitlisted_pool.append(applicant)
            else:
                applicant.decision = "Reject"
                self.rejected_pool.append(applicant)

    def run_screening_process(self):
        """Executes the end-to-end admissions process."""
        print("Starting admissions screening process...")
        self._calculate_holistic_scores()
        print("1. Holistic scores calculated.")
        self._apply_geographic_bonus()
        print("2. Geographic diversity bonuses applied.")
        self._make_decisions()
        print("3. Final admission decisions have been made.")
        print("Process complete.\n")

    def generate_summary_report(self) -> str:
        """
        FR4 & NFR2: Generates a comprehensive summary report of the cohort statistics
        and transparently lists the scoring metrics used.
        """
        if not self.admitted_pool:
            return "No report generated. The screening process has not been run."

        # --- Report Header ---
        report = []
        report.append("="*50)
        report.append("      University Admissions Summary Report")
        report.append("="*50)

        # --- NFR2: Transparent Scoring Metrics ---
        report.append("\n--- Scoring Metrics ---")
        weights = self.config['scoring_weights']
        report.append(f"Holistic Score Weights:")
        for key, val in weights.items():
            report.append(f"  - {key.capitalize():<18}: {val:.0%}")
        report.append(f"Geographic Bonus Factor: Up to {self.config['geo_bonus_factor']} points")

        # --- Overall Statistics ---
        total_applicants = len(self.all_applicants)
        admitted_count = len(self.admitted_pool)
        acceptance_rate = (admitted_count / total_applicants) * 100 if total_applicants > 0 else 0
        report.append("\n--- Overall Application Statistics ---")
        report.append(f"Total Applicants:        {total_applicants}")
        report.append(f"Admitted:                {admitted_count}")
        report.append(f"Waitlisted:              {len(self.waitlisted_pool)}")
        report.append(f"Rejected:                {len(self.rejected_pool)}")
        report.append(f"Acceptance Rate:         {acceptance_rate:.2f}%")

        # --- Admitted Cohort Profile ---
        admitted_gpas = [a.gpa for a in self.admitted_pool]
        admitted_sats = [a.sat_score for a in self.admitted_pool]
        report.append("\n--- Admitted Cohort Profile ---")
        report.append(f"Average GPA:             {statistics.mean(admitted_gpas):.2f}")
        report.append(f"Median GPA:              {statistics.median(admitted_gpas):.2f}")
        report.append(f"Average SAT Score:       {statistics.mean(admitted_sats):.0f}")
        report.append(f"Median SAT Score:        {statistics.median(admitted_sats):.0f}")

        # --- Geographic Distribution Analysis ---
        report.append("\n--- Geographic Distribution of Admitted Cohort ---")
        report.append(f"{'State':<7} {'Actual %':<10} {'Target %':<10} {'Delta':<8}")
        report.append(f"{'-'*5:<7} {'-'*8:<10} {'-'*8:<10} {'-'*6:<8}")

        admitted_states = [a.state for a in self.admitted_pool]
        state_counts = {state: admitted_states.count(state) for state in set(admitted_states)}
        
        # Combine all states from target and actual for a complete report
        all_report_states = set(self.config['target_geo_dist'].keys()) | set(state_counts.keys())

        dist_data: List[Tuple[str, float, float]] = []
        for state in sorted(list(all_report_states)):
            actual_pct = (state_counts.get(state, 0) / admitted_count) * 100
            target_pct = self.config['target_geo_dist'].get(state, 0.0) * 100
            dist_data.append((state, actual_pct, target_pct))

        # Sort by actual percentage, descending
        dist_data.sort(key=lambda x: x[1], reverse=True)

        for state, actual_pct, target_pct in dist_data:
            delta = actual_pct - target_pct
            delta_str = f"+{delta:.1f}" if delta > 0 else f"{delta:.1f}"
            report.append(f"{state:<7} {actual_pct:<9.1f}% {target_pct:<9.1f}% {delta_str:<8}")

        report.append("="*50)
        return "\n".join(report)


def generate_sample_applicants(num_applicants: int) -> List[Applicant]:
    """
    NFR1: Creates a list of randomized Applicant objects for demonstration.
    This function ensures the application is self-contained and runnable
    without external data files.
    """
    applicants = []
    # Use weights to simulate a more realistic distribution of applicants
    states = list(TARGET_GEOGRAPHIC_DISTRIBUTION.keys())
    state_weights = list(TARGET_GEOGRAPHIC_DISTRIBUTION.values())
    
    # Add a few states not in the target list to simulate unexpected applicants
    other_states = ['NM', 'WV', 'ID', 'MT', 'WY']
    states.extend(other_states)
    state_weights.extend([0.005] * len(other_states))


    for i in range(num_applicants):
        # Generate correlated academic data (higher GPA often means higher SAT)
        base_academic_performance = random.uniform(0.6, 1.0)
        gpa = round(2.5 + (base_academic_performance + random.uniform(-0.1, 0.1)) * 1.5, 2)
        gpa = max(2.5, min(4.0, gpa))

        sat = int(1000 + (base_academic_performance + random.uniform(-0.15, 0.15)) * 600)
        sat = max(800, min(1600, sat))
        
        applicant = Applicant(
            applicant_id=10001 + i,
            gpa=gpa,
            sat_score=sat,
            extracurricular_score=random.randint(4, 10),
            essay_score=random.randint(5, 10),
            state=random.choices(states, weights=state_weights, k=1)[0]
        )
        applicants.append(applicant)
    return applicants


def main():
    """Main execution function."""
    
    # --- System Configuration ---
    config = {
        "scoring_weights": SCORING_WEIGHTS,
        "target_geo_dist": TARGET_GEOGRAPHIC_DISTRIBUTION,
        "geo_bonus_factor": GEOGRAPHIC_BONUS_FACTOR,
        "cohort_size": TARGET_COHORT_SIZE,
        "waitlist_size": WAITLIST_SIZE,
    }

    # FR1 & NFR1: Generate and store applicant data in memory
    total_applicants_to_generate = 1000
    print(f"Generating {total_applicants_to_generate} sample applicants...")
    applicants = generate_sample_applicants(total_applicants_to_generate)
    
    # --- Initialize and run the system ---
    admissions_process = AdmissionsSystem(applicants, config)
    admissions_process.run_screening_process()

    # --- Generate and display the final report ---
    report = admissions_process.generate_summary_report()
    print(report)


if __name__ == "__main__":
    main()