# Technical Documentation: Resume Screening System

## 1. Introduction

This document provides detailed technical documentation for the Refactored Resume Screening System. The system is a self-contained Python application designed to evaluate applicant resumes against a set of predefined criteria. It processes applicant data, scores each applicant, determines if they pass the initial screening, and generates a comprehensive report summarizing the results.

The application is built to be modular and operate without any external dependencies, such as databases or web services, satisfying all functional and non-functional requirements outlined in the specification.

## 2. Module Overview

The entire system is contained within a single Python script. It leverages standard library modules like `dataclasses`, `enum`, and `typing` for robust data modeling and type safety.

-   **Data Models**: Immutable data structures using `@dataclasses.dataclass(frozen=True)` and `typing.NamedTuple` represent entities like applicants, screening criteria, and results.
-   **Enumerations**: The `enum.Enum` class is used to enforce a controlled vocabulary for specific fields, such as gender.
-   **Core Logic**: The `ResumeScreener` class encapsulates the primary business logic for evaluating applicants.
-   **Reporting**: A standalone function `generate_screening_report` is responsible for formatting the final output.
-   **Execution**: A `main` function orchestrates the screening process using sample data for demonstration purposes.

---

## 3. Enumerations

### 3.1. `Gender`

An enumeration that defines the supported gender categories, fulfilling requirement **FR5**. This ensures data consistency and restricts values to a predefined set.

**Definition:**

```python
class Gender(Enum):
    """Enumeration for supported gender categories."""
    FEMALE = auto()
    MALE = auto()
    NON_BINARY = auto()
    PREFER_NOT_TO_SAY = auto()
```

**Members:**

-   `FEMALE`: Represents the female gender.
-   `MALE`: Represents the male gender.
-   `NON_BINARY`: Represents non-binary gender identity.
-   `PREFER_NOT_TO_SAY`: Represents an applicant's choice not to disclose their gender.

---

## 4. Data Classes and Structures

These classes model the core data entities of the system, primarily addressing requirement **FR1**. They are defined as immutable dataclasses to prevent accidental modification after creation.

### 4.1. `Demographics`

Stores demographic information for an applicant.

**Definition:**

```python
@dataclasses.dataclass(frozen=True)
class Demographics:
    gender: Gender
    city: str
```

**Attributes:**

-   `gender` (`Gender`): The applicant's gender, restricted to values from the `Gender` enum.
-   `city` (`str`): The city where the applicant resides.

### 4.2. `Education`

Stores information about an applicant's educational background. An applicant can have a list of these objects.

**Definition:**

```python
@dataclasses.dataclass(frozen=True)
class Education:
    degree_name: str
    institution: str
    graduation_year: int
```

**Attributes:**

-   `degree_name` (`str`): The name of the degree or certificate (e.g., "Bachelor of Science in Computer Science").
-   `institution` (`str`): The name of the educational institution.
-   `graduation_year` (`int`): The year of graduation.

### 4.3. `WorkExperience`

Stores information about a single entry in an applicant's work history.

**Definition:**

```python
@dataclasses.dataclass(frozen=True)
class WorkExperience:
    job_title: str
    company: str
    years_of_experience: float
```

**Attributes:**

-   `job_title` (`str`): The title held at the job (e.g., "Senior Software Engineer").
-   `company` (`str`): The name of the company.
-   `years_of_experience` (`float`): The duration of employment in years.

### 4.4. `Applicant`

Represents a single applicant, aggregating all their resume information into a complete profile.

**Definition:**

```python
@dataclasses.dataclass(frozen=True)
class Applicant:
    applicant_id: int
    name: str
    education: List[Education]
    work_history: List[WorkExperience]
    skills: Set[str]
    certifications: Set[str]
    demographics: Demographics
```

**Attributes:**

-   `applicant_id` (`int`): A unique identifier for the applicant.
-   `name` (`str`): The full name of the applicant.
-   `education` (`List[Education]`): A list of the applicant's educational qualifications.
-   `work_history` (`List[WorkExperience]`): A list of the applicant's previous jobs.
-   `skills` (`Set[str]`): A set of technical and professional skills.
-   `certifications` (`Set[str]`): A set of certifications held by the applicant.
-   `demographics` (`Demographics`): The applicant's demographic information.

**Properties:**

-   `total_experience` (`float`): A read-only property that calculates the sum of `years_of_experience` from all entries in the `work_history` list.

### 4.5. `ScreeningCriteria`

Defines the criteria for evaluating applicants for a specific job role, addressing requirement **FR2**.

**Definition:**

```python
@dataclasses.dataclass(frozen=True)
class ScreeningCriteria:
    job_title: str
    minimum_years_experience: float
    required_degree: str
    required_skills: Set[str]
    required_certifications: Set[str]
    passing_score_threshold: int
```

**Attributes:**

-   `job_title` (`str`): The title of the job for which applicants are being screened.
-   `minimum_years_experience` (`float`): The minimum total years of work experience required.
-   `required_degree` (`str`): A string that must be present in one of the applicant's `degree_name` fields.
-   `required_skills` (`Set[str]`): A set of skills that are required for the role.
-   `required_certifications` (`Set[str]`): A set of certifications required for the role.
-   `passing_score_threshold` (`int`): The minimum score an applicant must achieve to pass the screening.

### 4.6. `ScreeningResult`

A `NamedTuple` used to store the outcome of a single applicant's evaluation in a structured way.

**Definition:**

```python
class ScreeningResult(NamedTuple):
    applicant_name: str
    score: int
    passed: bool
    notes: List[str]
```

**Fields:**

-   `applicant_name` (`str`): The name of the evaluated applicant.
-   `score` (`int`): The final score calculated by the screener.
-   `passed` (`bool`): `True` if the applicant's score meets or exceeds the `passing_score_threshold`, `False` otherwise.
-   `notes` (`List[str]`): A list of explanatory notes generated during the evaluation, detailing why points were awarded or what requirements were missed.

---

## 5. Core Logic Class

### 5.1. `ResumeScreener`

This class is the core component of the system, responsible for evaluating applicants against the defined criteria.

**Definition:**
```python
class ResumeScreener:
    # ... methods ...
```

#### Class Attributes

-   `_POINT_VALUES` (`dict`): A private dictionary that maps evaluation components to their point values. This centralizes the scoring logic.
    -   `MIN_EXPERIENCE_MET`: Points for meeting the minimum years of experience.
    -   `EXPERIENCE_PER_YEAR_ABOVE_MIN`: Bonus points for each full year of experience above the minimum.
    -   `DEGREE_MATCH`: Points for having the required degree.
    -   `PER_SKILL_MATCH`: Points awarded for each required skill the applicant possesses.
    -   `PER_CERTIFICATION_MATCH`: Points awarded for each required certification the applicant possesses.

#### Methods

##### `__init__(self, criteria: ScreeningCriteria)`

The constructor for the `ResumeScreener`.

-   **Description:** Initializes a new `ResumeScreener` instance with a specific set of screening criteria.
-   **Parameters:**
    -   `criteria` (`ScreeningCriteria`): An object containing the rules for the job screening.

##### `evaluate(self, applicant: Applicant) -> ScreeningResult`

Evaluates a single applicant's resume and determines if they advance to the next stage, fulfilling requirements **FR2** and **FR3**.

-   **Description:** This public method orchestrates the evaluation process by calling the private `_evaluate_*` methods for each category (experience, education, etc.). It aggregates the scores and notes, compares the total score against the passing threshold, and returns a comprehensive `ScreeningResult`.
-   **Parameters:**
    -   `applicant` (`Applicant`): The applicant object to be evaluated.
-   **Returns:** (`ScreeningResult`) A named tuple containing the applicant's name, final score, pass/fail status, and detailed evaluation notes.

##### `_evaluate_experience(self, applicant: Applicant) -> Tuple[int, List[str]]`

A private helper method to evaluate an applicant's work experience.

-   **Description:** Calculates a score based on the applicant's total years of experience compared to the minimum requirement. Bonus points are awarded for years of experience exceeding the minimum.
-   **Parameters:**
    -   `applicant` (`Applicant`): The applicant being evaluated.
-   **Returns:** (`Tuple[int, List[str]]`) A tuple containing the calculated score for this category and a list of explanatory notes.

##### `_evaluate_education(self, applicant: Applicant) -> Tuple[int, List[str]]`

A private helper method to evaluate an applicant's educational background.

-   **Description:** Checks if any of the applicant's educational degrees contain the `required_degree` string from the criteria.
-   **Parameters:**
    -   `applicant` (`Applicant`): The applicant being evaluated.
-   **Returns:** (`Tuple[int, List[str]]`) A tuple containing the score (either `DEGREE_MATCH` or 0) and relevant notes.

##### `_evaluate_skills(self, applicant: Applicant) -> Tuple[int, List[str]]`

A private helper method to evaluate an applicant's skills.

-   **Description:** Compares the applicant's skills with the required skills. The score is calculated based on the number of matching skills.
-   **Parameters:**
    -   `applicant` (`Applicant`): The applicant being evaluated.
-   **Returns:** (`Tuple[int, List[str]]`) A tuple containing the total score for matched skills and notes detailing which skills matched and which were missing.

##### `_evaluate_certifications(self, applicant: Applicant) -> Tuple[int, List[str]]`

A private helper method to evaluate an applicant's certifications.

-   **Description:** Compares the applicant's certifications with the required certifications. The score is calculated based on the number of matching certifications.
-   **Parameters:**
    -   `applicant` (`Applicant`): The applicant being evaluated.
-   **Returns:** (`Tuple[int, List[str]]`) A tuple containing the total score for matched certifications and notes detailing which certifications matched and which were missing.

---

## 6. Utility Functions

### 6.1. `generate_screening_report(job_title: str, results: List[ScreeningResult]) -> str`

Generates a formatted, human-readable report from a list of screening results, fulfilling requirements **FR4** and **NFR2**.

-   **Description:** The function first provides a high-level summary, including the total number of applicants reviewed and the count of those who passed or failed. It then provides a detailed breakdown, listing each applicant under "Advancing to Interview" or "Not Advancing" sections. Within these sections, applicants are sorted by score in descending order, and their individual scores and evaluation notes are displayed.
-   **Parameters:**
    -   `job_title` (`str`): The title of the job, used for the report header.
    -   `results` (`List[ScreeningResult]`): A list of `ScreeningResult` objects from the evaluation process.
-   **Returns:** (`str`) A single multi-line string containing the formatted report.

---

## 7. Main Execution

### 7.1. `main()`

The main entry point for the application when run as a script.

-   **Description:** This function demonstrates the end-to-end functionality of the system. It performs the following steps:
    1.  Fetches sample applicant data from `_get_sample_applicants()`.
    2.  Fetches the screening criteria from `_get_screening_criteria()`.
    3.  Initializes the `ResumeScreener` with the criteria.
    4.  Runs the evaluation for each sample applicant.
    5.  Generates the final screening report using `generate_screening_report`.
    6.  Prints the report to the console.
-   This function also demonstrates **NFR1** by operating entirely with in-memory data.

### 7.2. `_get_sample_applicants() -> List[Applicant]`

A private helper function to provide a predefined list of `Applicant` objects for demonstration.

-   **Returns:** (`List[Applicant]`) A list of sample applicants.

### 7.3. `_get_screening_criteria() -> ScreeningCriteria`

A private helper function to provide a predefined `ScreeningCriteria` object for a sample job role.

-   **Returns:** (`ScreeningCriteria`) A sample screening criteria object.