#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Unit tests for the Refactored Resume Screening System.

This test suite uses pytest to verify the functionality of the resume screening
application, covering data models, screening logic, and report generation.
It includes tests for standard scenarios, edge cases, and boundary conditions.
"""

import pytest
from dataclasses import FrozenInstanceError

# Import classes from the application script
# Assumes the script is named 'resume_screening_app.py' and is in the same directory.
# For testing, you might need to rename the original file or adjust the import path.
from resume_screening_app import (
    Applicant,
    Demographics,
    Education,
    Gender,
    ResumeScreener,
    ScreeningCriteria,
    ScreeningResult,
    WorkExperience,
    generate_screening_report,
)


# =============================================================================
# Pytest Fixtures for Reusable Test Data
# =============================================================================

@pytest.fixture
def base_criteria() -> ScreeningCriteria:
    """Provides a standard set of screening criteria for a senior role."""
    return ScreeningCriteria(
        job_title="Senior Python Developer",
        minimum_years_experience=6.0,
        required_degree="Computer Science",
        required_skills={"Python", "PostgreSQL", "AWS"},
        required_certifications={"AWS Certified Developer - Associate"},
        passing_score_threshold=80,
    )


@pytest.fixture
def perfect_applicant() -> Applicant:
    """Provides an applicant who perfectly meets or exceeds all base criteria."""
    return Applicant(
        applicant_id=1,
        name="Ada Lovelace",
        education=[
            Education("Bachelor of Science in Computer Science", "University of London", 1840)
        ],
        work_history=[
            WorkExperience("Senior Engineer", "Tech Giant", 5.0),
            WorkExperience("Junior Engineer", "Startup", 2.0),
        ],
        skills={"Python", "PostgreSQL", "AWS", "Docker", "Kubernetes"},
        certifications={"AWS Certified Developer - Associate", "CKAD"},
        demographics=Demographics(Gender.FEMALE, "London"),
    )


@pytest.fixture
def unqualified_applicant() -> Applicant:
    """Provides an applicant who meets none of the key criteria."""
    return Applicant(
        applicant_id=2,
        name="John Doe",
        education=[Education("High School Diploma", "Local High", 2020)],
        work_history=[WorkExperience("Intern", "Corner Store", 0.5)],
        skills={"Microsoft Word", "Excel"},
        certifications=set(),
        demographics=Demographics(Gender.MALE, "Anytown"),
    )


@pytest.fixture
def applicant_with_no_experience() -> Applicant:
    """Provides an applicant with academic qualifications but no work history."""
    return Applicant(
        applicant_id=3,
        name="Jane Smith",
        education=[Education("Master of Science in Computer Science", "Top University", 2023)],
        work_history=[],
        skills={"Python", "PostgreSQL", "AWS"},
        certifications=set(),
        demographics=Demographics(Gender.NON_BINARY, "Metroville"),
    )


# =============================================================================
# Tests for Data Models (FR1, FR5)
# =============================================================================

class TestDataModels:
    """Tests for the data model dataclasses and enums."""

    def test_gender_enum(self):
        """FR5: Ensures Gender enum contains the correct, restricted values."""
        expected_members = {"FEMALE", "MALE", "NON_BINARY", "PREFER_NOT_TO_SAY"}
        assert set(Gender.__members__.keys()) == expected_members

    def test_applicant_total_experience_multiple_jobs(self, perfect_applicant):
        """FR1: Tests `total_experience` property with multiple work history entries."""
        assert perfect_applicant.total_experience == 7.0

    def test_applicant_total_experience_no_jobs(self, applicant_with_no_experience):
        """FR1: Tests `total_experience` is 0 for an applicant with no work history."""
        assert applicant_with_no_experience.total_experience == 0.0

    def test_applicant_total_experience_single_job(self):
        """FR1: Tests `total_experience` with a single work history entry."""
        applicant = Applicant(
            applicant_id=4, name="Test", education=[],
            work_history=[WorkExperience("Dev", "Company", 3.5)],
            skills=set(), certifications=set(), demographics=None
        )
        assert applicant.total_experience == 3.5

    def test_dataclasses_are_frozen(self, perfect_applicant):
        """Ensures the dataclasses are immutable as defined."""
        with pytest.raises(FrozenInstanceError):
            perfect_applicant.name = "A. Lovelace"

        with pytest.raises(FrozenInstanceError):
            perfect_applicant.education[0].degree_name = "New Degree"

        with pytest.raises(FrozenInstanceError):
            perfect_applicant.work_history[0].company = "New Company"

        with pytest.raises(FrozenInstanceError):
            perfect_applicant.demographics.city = "Paris"


# =============================================================================
# Tests for ResumeScreener Logic (FR2, FR3)
# =============================================================================

class TestResumeScreener:
    """Tests the core evaluation logic of the ResumeScreener class."""

    @pytest.mark.parametrize(
        "total_exp, min_exp, expected_score, expected_notes",
        [
            # Exceeds minimum experience
            (8.0, 6.0, 20 + 2 * 5, ["Met minimum experience of 6.0 years.", "Awarded 10 bonus points for 2 additional year(s) of experience."]),
            # Exactly meets minimum experience
            (6.0, 6.0, 20, ["Met minimum experience of 6.0 years."]),
            # Below minimum experience
            (5.9, 6.0, 0, ["Did not meet minimum experience requirement (5.9/6.0 years)."]),
            # Boundary case: minimum experience is 0
            (0.0, 0.0, 20, ["Met minimum experience of 0.0 years."]),
            # Boundary case: applicant has 0 experience, min is > 0
            (0.0, 1.0, 0, ["Did not meet minimum experience requirement (0.0/1.0 years)."]),
        ]
    )
    def test_evaluate_experience(self, base_criteria, total_exp, min_exp, expected_score, expected_notes):
        """Tests the _evaluate_experience method under various conditions."""
        criteria = dataclasses.replace(base_criteria, minimum_years_experience=min_exp)
        applicant = Applicant(
            applicant_id=1, name="Test", education=[],
            work_history=[WorkExperience("Dev", "Company", total_exp)],
            skills=set(), certifications=set(), demographics=None
        )
        screener = ResumeScreener(criteria)
        score, notes = screener._evaluate_experience(applicant)
        assert score == expected_score
        assert notes == expected_notes

    @pytest.mark.parametrize(
        "education_list, required_degree, expected_score, expected_note",
        [
            # Exact match (within a longer string)
            ([Education("Bachelor of Science in Computer Science", "U", 2020)], "Computer Science", 25, "Has required degree containing 'Computer Science'."),
            # No match
            ([Education("Bachelor of Arts in History", "U", 2020)], "Computer Science", 0, "Missing required degree: 'Computer Science'."),
            # No education at all
            ([], "Computer Science", 0, "Missing required degree: 'Computer Science'."),
            # Multiple degrees, one of which matches
            ([Education("B.A. History", "U", 2018), Education("M.S. in Computer Science", "U", 2020)], "Computer Science", 25, "Has required degree containing 'Computer Science'."),
        ]
    )
    def test_evaluate_education(self, base_criteria, education_list, required_degree, expected_score, expected_note):
        """Tests the _evaluate_education method."""
        criteria = dataclasses.replace(base_criteria, required_degree=required_degree)
        applicant = Applicant(
            applicant_id=1, name="Test", education=education_list,
            work_history=[], skills=set(), certifications=set(), demographics=None
        )
        screener = ResumeScreener(criteria)
        score, notes = screener._evaluate_education(applicant)
        assert score == expected_score
        assert notes == [expected_note]

    @pytest.mark.parametrize(
        "applicant_skills, required_skills, expected_score, expected_notes",
        [
            # All skills match
            ({"A", "B", "C"}, {"A", "B"}, 20, ["Matched 2 required skills: A, B."]),
            # Some skills match
            ({"A", "C"}, {"A", "B"}, 10, ["Matched 1 required skills: A.", "Missing 1 required skills: B."]),
            # No skills match
            ({"C", "D"}, {"A", "B"}, 0, ["Missing 2 required skills: A, B."]),
            # Applicant has no skills
            (set(), {"A", "B"}, 0, ["Missing 2 required skills: A, B."]),
            # No skills are required
            ({"A", "B"}, set(), 0, []),
        ]
    )
    def test_evaluate_skills(self, base_criteria, applicant_skills, required_skills, expected_score, expected_notes):
        """Tests the _evaluate_skills method."""
        criteria = dataclasses.replace(base_criteria, required_skills=required_skills)
        applicant = Applicant(
            applicant_id=1, name="Test", education=[], work_history=[],
            skills=applicant_skills, certifications=set(), demographics=None
        )
        screener = ResumeScreener(criteria)
        score, notes = screener._evaluate_skills(applicant)
        assert score == expected_score
        # Sort notes for comparison as intersection order is not guaranteed
        assert sorted(notes) == sorted(expected_notes)

    @pytest.mark.parametrize(
        "applicant_certs, required_certs, expected_score, expected_notes",
        [
            # All certifications match
            ({"CertA", "CertB"}, {"CertA"}, 15, ["Matched 1 required certifications: CertA."]),
            # No certifications match
            ({"CertC"}, {"CertA", "CertB"}, 0, ["Missing 2 required certifications: CertA, CertB."]),
            # No certifications are required
            ({"CertA"}, set(), 0, []),
        ]
    )
    def test_evaluate_certifications(self, base_criteria, applicant_certs, required_certs, expected_score, expected_notes):
        """Tests the _evaluate_certifications method."""
        criteria = dataclasses.replace(base_criteria, required_certifications=required_certs)
        applicant = Applicant(
            applicant_id=1, name="Test", education=[], work_history=[],
            skills=set(), certifications=applicant_certs, demographics=None
        )
        screener = ResumeScreener(criteria)
        score, notes = screener._evaluate_certifications(applicant)
        assert score == expected_score
        assert sorted(notes) == sorted(expected_notes)

    def test_full_evaluation_perfect_applicant(self, base_criteria, perfect_applicant):
        """FR2/FR3: Tests the main `evaluate` method with a perfect applicant."""
        screener = ResumeScreener(base_criteria)
        result = screener.evaluate(perfect_applicant)

        # Experience: 7 years vs 6 min -> 20 + 5*1 = 25 points
        # Education: "Computer Science" match -> 25 points
        # Skills: "Python", "PostgreSQL", "AWS" all match -> 3 * 10 = 30 points
        # Certs: "AWS Certified Developer - Associate" match -> 1 * 15 = 15 points
        # Total = 25 + 25 + 30 + 15 = 95
        expected_score = 95

        assert result.applicant_name == "Ada Lovelace"
        assert result.score == expected_score
        assert result.passed is True
        assert len(result.notes) > 0

    def test_full_evaluation_unqualified_applicant(self, base_criteria, unqualified_applicant):
        """FR2/FR3: Tests the main `evaluate` method with an unqualified applicant."""
        screener = ResumeScreener(base_criteria)
        result = screener.evaluate(unqualified_applicant)

        # Experience: 0.5 years vs 6 min -> 0 points
        # Education: No "Computer Science" -> 0 points
        # Skills: None match -> 0 points
        # Certs: None match -> 0 points
        # Total = 0
        expected_score = 0

        assert result.applicant_name == "John Doe"
        assert result.score == expected_score
        assert result.passed is False
        assert "Did not meet minimum experience" in result.notes[0]

    def test_full_evaluation_boundary_pass(self, base_criteria, perfect_applicant):
        """FR3: Tests an applicant who scores exactly the passing threshold."""
        # Adjust criteria so perfect applicant scores exactly 80
        # Original score is 95. Need to reduce by 15.
        # Removing the certification requirement will do this.
        criteria = dataclasses.replace(
            base_criteria,
            required_certifications=set(),
            passing_score_threshold=80
        )
        screener = ResumeScreener(criteria)
        result = screener.evaluate(perfect_applicant)
        
        # Expected score: 95 (original) - 15 (cert points) = 80
        assert result.score == 80
        assert result.passed is True

    def test_full_evaluation_boundary_fail(self, base_criteria, perfect_applicant):
        """FR3: Tests an applicant who scores just below the passing threshold."""
        # Adjust criteria so perfect applicant scores 79
        criteria = dataclasses.replace(
            base_criteria,
            required_certifications=set(),
            passing_score_threshold=81  # Threshold is just above their score
        )
        screener = ResumeScreener(criteria)
        result = screener.evaluate(perfect_applicant)
        
        # Expected score: 95 (original) - 15 (cert points) = 80
        assert result.score == 80
        assert result.passed is False


# =============================================================================
# Tests for Report Generation (FR4, NFR2)
# =============================================================================

class TestReportGeneration:
    """Tests the `generate_screening_report` function."""

    def test_report_with_mixed_results(self):
        """FR4/NFR2: Tests report with both passing and failing applicants."""
        job_title = "Test Role"
        results = [
            ScreeningResult("Alice", 90, True, ["Note A"]),
            ScreeningResult("Bob", 50, False, ["Note B"]),
            ScreeningResult("Charlie", 95, True, ["Note C"]),
        ]
        report = generate_screening_report(job_title, results)

        # Check summary
        assert "RESUME SCREENING REPORT: Test Role" in report
        assert "Total Applicants Reviewed: 3" in report
        assert "Applicants Advancing to Interview: 2" in report
        assert "Applicants Not Advancing: 1" in report

        # Check sorting and placement
        assert report.find("[PASS] Charlie") < report.find("[PASS] Alice")
        assert "[PASS] Charlie (Score: 95)" in report
        assert "[PASS] Alice (Score: 90)" in report
        assert "[FAIL] Bob (Score: 50)" in report
        assert "- Note A" in report
        assert "- Note B" in report
        assert "- Note C" in report

    def test_report_with_only_passing_results(self):
        """Tests report when all applicants pass."""
        job_title = "Exclusive Role"
        results = [
            ScreeningResult("Alice", 90, True, []),
            ScreeningResult("Bob", 85, True, []),
        ]
        report = generate_screening_report(job_title, results)
        assert "Applicants Advancing to Interview: 2" in report
        assert "Applicants Not Advancing: 0" in report
        assert "All applicants met the criteria to advance." in report
        assert "No applicants met the criteria to advance." not in report

    def test_report_with_only_failing_results(self):
        """Tests report when all applicants fail."""
        job_title = "Difficult Role"
        results = [
            ScreeningResult("Alice", 40, False, []),
            ScreeningResult("Bob", 30, False, []),
        ]
        report = generate_screening_report(job_title, results)
        assert "Applicants Advancing to Interview: 0" in report
        assert "Applicants Not Advancing: 2" in report
        assert "No applicants met the criteria to advance." in report
        assert "All applicants met the criteria to advance." not in report

    def test_report_with_no_results(self):
        """Tests report generation with an empty list of results (edge case)."""
        job_title = "Unfilled Role"
        results = []
        report = generate_screening_report(job_title, results)
        assert "Total Applicants Reviewed: 0" in report
        assert "Applicants Advancing to Interview: 0" in report
        assert "Applicants Not Advancing: 0" in report
        assert "No applicants met the criteria to advance." in report
        # Check that it appears in both sections
        assert report.count("No applicants met the criteria to advance.") == 1
        assert "All applicants met the criteria to advance." in report


# To run these tests:
# 1. Save the original script as `resume_screening_app.py`.
# 2. Save this test script as `test_resume_screening.py` in the same directory.
# 3. Make sure you have pytest installed (`pip install pytest`).
# 4. Run `pytest` from your terminal in that directory.