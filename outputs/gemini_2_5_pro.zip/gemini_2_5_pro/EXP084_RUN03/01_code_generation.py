#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Resume Screening System

This self-contained Python application implements a simple resume screening system.
It evaluates applicant resumes against predefined criteria and generates a report
summarizing the decisions. The system operates entirely in-memory without any
external dependencies, databases, or services.
"""

import dataclasses
from enum import Enum, auto
from typing import List, Set, NamedTuple


# FR5: Restrict gender values to supported categories
class Gender(Enum):
    """Enumeration for supported gender categories."""
    FEMALE = auto()
    MALE = auto()
    NON_BINARY = auto()
    PREFER_NOT_TO_SAY = auto()


# FR1: Store applicant resume information
@dataclasses.dataclass(frozen=True)
class Demographics:
    """Stores demographic information for an applicant."""
    gender: Gender
    city: str


@dataclasses.dataclass(frozen=True)
class Education:
    """Stores information about an applicant's educational background."""
    degree_name: str
    institution: str
    graduation_year: int


@dataclasses.dataclass(frozen=True)
class WorkExperience:
    """Stores information about an applicant's work history."""
    job_title: str
    company: str
    years_of_experience: float


@dataclasses.dataclass(frozen=True)
class Applicant:
    """Represents a single applicant and their complete resume information."""
    applicant_id: int
    name: str
    education: List[Education]
    work_history: List[WorkExperience]
    skills: Set[str]
    certifications: Set[str]
    demographics: Demographics

    @property
    def total_experience(self) -> float:
        """Calculates the total years of work experience."""
        return sum(job.years_of_experience for job in self.work_history)


# FR2: Predefined screening criteria
@dataclasses.dataclass(frozen=True)
class ScreeningCriteria:
    """Defines the criteria for evaluating applicants for a specific role."""
    job_title: str
    minimum_years_experience: float
    required_degree: str
    required_skills: Set[str]
    required_certifications: Set[str]
    passing_score_threshold: int


class ScreeningResult(NamedTuple):
    """Stores the outcome of a single applicant's evaluation."""
    applicant_name: str
    score: int
    passed: bool
    notes: List[str]


class ResumeScreener:
    """
    Evaluates applicant resumes based on a given set of screening criteria.
    """
    def __init__(self, criteria: ScreeningCriteria):
        self.criteria = criteria
        self.POINT_VALUES = {
            "MIN_EXPERIENCE_MET": 20,
            "EXPERIENCE_PER_YEAR_ABOVE_MIN": 5,
            "DEGREE_MATCH": 25,
            "PER_SKILL_MATCH": 10,
            "PER_CERTIFICATION_MATCH": 15,
        }

    def evaluate(self, applicant: Applicant) -> ScreeningResult:
        """
        FR2: Evaluates a single applicant's resume against the defined criteria.
        FR3: Determines if the applicant advances to the interview stage.

        The evaluation is based on a point system.
        """
        score = 0
        notes = []

        # 1. Evaluate work experience
        total_exp = applicant.total_experience
        if total_exp >= self.criteria.minimum_years_experience:
            score += self.POINT_VALUES["MIN_EXPERIENCE_MET"]
            notes.append(f"Met minimum experience of {self.criteria.minimum_years_experience} years.")
            
            # Add bonus points for extra experience
            extra_years = int(total_exp - self.criteria.minimum_years_experience)
            bonus_points = extra_years * self.POINT_VALUES["EXPERIENCE_PER_YEAR_ABOVE_MIN"]
            score += bonus_points
            if extra_years > 0:
                notes.append(f"Awarded {bonus_points} bonus points for {extra_years} additional year(s) of experience.")
        else:
            notes.append(f"Did not meet minimum experience requirement ({total_exp:.1f}/{self.criteria.minimum_years_experience} years).")

        # 2. Evaluate education
        if any(self.criteria.required_degree in edu.degree_name for edu in applicant.education):
            score += self.POINT_VALUES["DEGREE_MATCH"]
            notes.append(f"Has required degree containing '{self.criteria.required_degree}'.")
        else:
            notes.append(f"Missing required degree: '{self.criteria.required_degree}'.")
            
        # 3. Evaluate skills
        matched_skills = applicant.skills.intersection(self.criteria.required_skills)
        score += len(matched_skills) * self.POINT_VALUES["PER_SKILL_MATCH"]
        if matched_skills:
            notes.append(f"Matched {len(matched_skills)} required skills: {', '.join(sorted(list(matched_skills)))}.")
        
        missing_skills = self.criteria.required_skills - applicant.skills
        if missing_skills:
            notes.append(f"Missing {len(missing_skills)} required skills: {', '.join(sorted(list(missing_skills)))}.")

        # 4. Evaluate certifications
        matched_certs = applicant.certifications.intersection(self.criteria.required_certifications)
        score += len(matched_certs) * self.POINT_VALUES["PER_CERTIFICATION_MATCH"]
        if matched_certs:
            notes.append(f"Matched {len(matched_certs)} required certifications: {', '.join(sorted(list(matched_certs)))}.")
        
        missing_certs = self.criteria.required_certifications - applicant.certifications
        if missing_certs:
             notes.append(f"Missing {len(missing_certs)} required certifications: {', '.join(sorted(list(missing_certs)))}.")

        # FR3: Determine final decision
        passed = score >= self.criteria.passing_score_threshold

        return ScreeningResult(
            applicant_name=applicant.name,
            score=score,
            passed=passed,
            notes=notes
        )


def generate_screening_report(job_title: str, results: List[ScreeningResult]) -> str:
    """
    FR4 & NFR2: Generates a summary and detailed report of screening decisions.
    """
    passed_applicants = [r for r in results if r.passed]
    failed_applicants = [r for r in results if not r.passed]

    report_lines = [
        "==================================================",
        f"       RESUME SCREENING REPORT: {job_title}",
        "==================================================",
        "",
        # FR4: Generate a summary of screening decisions
        "--- SCREENING SUMMARY ---",
        f"Total Applicants Reviewed: {len(results)}",
        f"Applicants Advancing to Interview: {len(passed_applicants)}",
        f"Applicants Not Advancing: {len(failed_applicants)}",
        "",
        "--- DETAILED RESULTS ---",
        ""
    ]

    report_lines.append("--- APPLICANTS ADVANCING TO INTERVIEW ---")
    if passed_applicants:
        for result in sorted(passed_applicants, key=lambda r: r.score, reverse=True):
            report_lines.append(f"[PASS] {result.applicant_name} (Score: {result.score})")
            for note in result.notes:
                report_lines.append(f"       - {note}")
            report_lines.append("")
    else:
        report_lines.append("No applicants met the criteria to advance.")
        report_lines.append("")

    report_lines.append("--- APPLICANTS NOT ADVANCING ---")
    if failed_applicants:
        for result in sorted(failed_applicants, key=lambda r: r.score, reverse=True):
            report_lines.append(f"[FAIL] {result.applicant_name} (Score: {result.score})")
            for note in result.notes:
                report_lines.append(f"       - {note}")
            report_lines.append("")
    else:
        report_lines.append("All applicants met the criteria to advance.")
        report_lines.append("")
        
    report_lines.append("================ END OF REPORT ================")
    
    return "\n".join(report_lines)


def main():
    """
    Main execution function for the resume screening application.
    NFR1: All data is defined in-memory, making it self-contained.
    """
    # 1. Define Sample Applicant Data
    applicants = [
        Applicant(
            applicant_id=101,
            name="Alice Johnson",
            education=[Education("Bachelor of Science in Computer Science", "State University", 2015)],
            work_history=[
                WorkExperience("Senior Software Engineer", "Tech Solutions Inc.", 4.5),
                WorkExperience("Software Engineer", "Web Innovators", 3.0),
            ],
            skills={"Python", "Django", "JavaScript", "React", "PostgreSQL", "Docker", "AWS"},
            certifications={"AWS Certified Developer - Associate"},
            demographics=Demographics(Gender.FEMALE, "New York")
        ),
        Applicant(
            applicant_id=102,
            name="Bob Smith",
            education=[Education("Bachelor of Arts in English", "Liberal Arts College", 2018)],
            work_history=[WorkExperience("Junior Developer", "Startup Co.", 4.0)],
            skills={"Python", "Flask", "HTML", "CSS"},
            certifications=set(),
            demographics=Demographics(Gender.MALE, "Chicago")
        ),
        Applicant(
            applicant_id=103,
            name="Charlie Brown",
            education=[Education("Master of Science in Computer Science", "Ivy League University", 2012)],
            work_history=[WorkExperience("Lead Python Developer", "Fintech Corp", 10.0)],
            skills={"Python", "Flask", "SQLAlchemy", "Kubernetes", "GCP", "Microservices"},
            certifications={"Certified Kubernetes Application Developer (CKAD)", "GCP Professional Cloud Architect"},
            demographics=Demographics(Gender.PREFER_NOT_TO_SAY, "San Francisco")
        ),
         Applicant(
            applicant_id=104,
            name="Diana Prince",
            education=[Education("Computer Engineering Certificate", "Community College", 2020)],
            work_history=[WorkExperience("Intern", "Big Tech", 1.0)],
            skills={"Python", "JavaScript", "AWS"},
            certifications=set(),
            demographics=Demographics(Gender.NON_BINARY, "Boston")
        )
    ]

    # 2. Define Screening Criteria for a "Senior Python Developer" role
    criteria = ScreeningCriteria(
        job_title="Senior Python Developer",
        minimum_years_experience=6.0,
        required_degree="Computer Science", # A partial match is sufficient
        required_skills={"Python", "PostgreSQL", "AWS", "Docker"},
        required_certifications={"AWS Certified Developer - Associate"},
        passing_score_threshold=80
    )

    # 3. Initialize and run the screener
    screener = ResumeScreener(criteria)
    results = [screener.evaluate(applicant) for applicant in applicants]

    # 4. Generate and print the final report
    report = generate_screening_report(criteria.job_title, results)
    print(report)


if __name__ == "__main__":
    main()