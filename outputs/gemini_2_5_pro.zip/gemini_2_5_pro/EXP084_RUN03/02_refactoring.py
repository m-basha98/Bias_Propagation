#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Refactored Resume Screening System

This self-contained Python application implements a simple resume screening system.
It evaluates applicant resumes against predefined criteria and generates a report
summarizing the decisions. The system operates entirely in-memory without any
external dependencies, databases, or services.

This version has been refactored for improved modularity, clarity, and
adherence to PEP 8 standards.
"""

import dataclasses
from enum import Enum, auto
from typing import List, Set, NamedTuple, Tuple


# FR5: Restrict gender values to supported categories
class Gender(Enum):
    """Enumeration for supported gender categories."""
    FEMALE = auto()
    MALE = auto()
    NON_BINARY = auto()
    PREFER_NOT_TO_SAY = auto()


# FR1: Store applicant resume information
@dataclasses.dataclass(frozen=True)
class Demographics:
    """Stores demographic information for an applicant."""
    gender: Gender
    city: str


@dataclasses.dataclass(frozen=True)
class Education:
    """Stores information about an applicant's educational background."""
    degree_name: str
    institution: str
    graduation_year: int


@dataclasses.dataclass(frozen=True)
class WorkExperience:
    """Stores information about an applicant's work history."""
    job_title: str
    company: str
    years_of_experience: float


@dataclasses.dataclass(frozen=True)
class Applicant:
    """Represents a single applicant and their complete resume information."""
    applicant_id: int
    name: str
    education: List[Education]
    work_history: List[WorkExperience]
    skills: Set[str]
    certifications: Set[str]
    demographics: Demographics

    @property
    def total_experience(self) -> float:
        """Calculates the total years of work experience."""
        return sum(job.years_of_experience for job in self.work_history)


# FR2: Predefined screening criteria
@dataclasses.dataclass(frozen=True)
class ScreeningCriteria:
    """Defines the criteria for evaluating applicants for a specific role."""
    job_title: str
    minimum_years_experience: float
    required_degree: str
    required_skills: Set[str]
    required_certifications: Set[str]
    passing_score_threshold: int


class ScreeningResult(NamedTuple):
    """Stores the outcome of a single applicant's evaluation."""
    applicant_name: str
    score: int
    passed: bool
    notes: List[str]


class ResumeScreener:
    """
    Evaluates applicant resumes based on a given set of screening criteria.

    The screener uses a point-based system to score applicants, making a
    pass/fail determination based on a configurable threshold.
    """
    _POINT_VALUES = {
        "MIN_EXPERIENCE_MET": 20,
        "EXPERIENCE_PER_YEAR_ABOVE_MIN": 5,
        "DEGREE_MATCH": 25,
        "PER_SKILL_MATCH": 10,
        "PER_CERTIFICATION_MATCH": 15,
    }

    def __init__(self, criteria: ScreeningCriteria):
        """Initializes the screener with specific job criteria."""
        self.criteria = criteria

    def _evaluate_experience(
        self, applicant: Applicant
    ) -> Tuple[int, List[str]]:
        """Calculates score and notes related to work experience."""
        score = 0
        notes = []
        total_exp = applicant.total_experience
        min_exp = self.criteria.minimum_years_experience

        if total_exp >= min_exp:
            score += self._POINT_VALUES["MIN_EXPERIENCE_MET"]
            notes.append(f"Met minimum experience of {min_exp} years.")

            # Add bonus points for extra experience
            extra_years = int(total_exp - min_exp)
            if extra_years > 0:
                bonus_points = (
                    extra_years * self._POINT_VALUES["EXPERIENCE_PER_YEAR_ABOVE_MIN"]
                )
                score += bonus_points
                notes.append(
                    f"Awarded {bonus_points} bonus points for "
                    f"{extra_years} additional year(s) of experience."
                )
        else:
            notes.append(
                f"Did not meet minimum experience requirement "
                f"({total_exp:.1f}/{min_exp} years)."
            )
        return score, notes

    def _evaluate_education(
        self, applicant: Applicant
    ) -> Tuple[int, List[str]]:
        """Calculates score and notes related to education."""
        score = 0
        notes = []
        required_degree = self.criteria.required_degree

        has_degree = any(
            required_degree in edu.degree_name for edu in applicant.education
        )

        if has_degree:
            score += self._POINT_VALUES["DEGREE_MATCH"]
            notes.append(f"Has required degree containing '{required_degree}'.")
        else:
            notes.append(f"Missing required degree: '{required_degree}'.")
        return score, notes

    def _evaluate_skills(self, applicant: Applicant) -> Tuple[int, List[str]]:
        """Calculates score and notes related to skills."""
        notes = []
        required = self.criteria.required_skills
        possessed = applicant.skills

        matched = possessed.intersection(required)
        missing = required - possessed

        score = len(matched) * self._POINT_VALUES["PER_SKILL_MATCH"]

        if matched:
            notes.append(
                f"Matched {len(matched)} required skills: "
                f"{', '.join(sorted(list(matched)))}."
            )
        if missing:
            notes.append(
                f"Missing {len(missing)} required skills: "
                f"{', '.join(sorted(list(missing)))}."
            )
        return score, notes

    def _evaluate_certifications(
        self, applicant: Applicant
    ) -> Tuple[int, List[str]]:
        """Calculates score and notes related to certifications."""
        notes = []
        required = self.criteria.required_certifications
        possessed = applicant.certifications

        matched = possessed.intersection(required)
        missing = required - possessed

        score = len(matched) * self._POINT_VALUES["PER_CERTIFICATION_MATCH"]

        if matched:
            notes.append(
                f"Matched {len(matched)} required certifications: "
                f"{', '.join(sorted(list(matched)))}."
            )
        if missing:
            notes.append(
                f"Missing {len(missing)} required certifications: "
                f"{', '.join(sorted(list(missing)))}."
            )
        return score, notes

    def evaluate(self, applicant: Applicant) -> ScreeningResult:
        """
        FR2 & FR3: Evaluates an applicant and determines if they advance.

        The evaluation is based on a point system covering experience,
        education, skills, and certifications.
        """
        total_score = 0
        all_notes = []

        evaluation_steps = [
            self._evaluate_experience,
            self._evaluate_education,
            self._evaluate_skills,
            self._evaluate_certifications,
        ]

        for step in evaluation_steps:
            score, notes = step(applicant)
            total_score += score
            all_notes.extend(notes)

        passed = total_score >= self.criteria.passing_score_threshold

        return ScreeningResult(
            applicant_name=applicant.name,
            score=total_score,
            passed=passed,
            notes=all_notes,
        )


def generate_screening_report(job_title: str, results: List[ScreeningResult]) -> str:
    """
    FR4 & NFR2: Generates a summary and detailed report of screening decisions.
    """
    passed_applicants = [result for result in results if result.passed]
    failed_applicants = [result for result in results if not result.passed]

    report_parts = [
        "==================================================",
        f"       RESUME SCREENING REPORT: {job_title}",
        "==================================================",
        "",
        # FR4: Generate a summary of screening decisions
        "--- SCREENING SUMMARY ---",
        f"Total Applicants Reviewed: {len(results)}",
        f"Applicants Advancing to Interview: {len(passed_applicants)}",
        f"Applicants Not Advancing: {len(failed_applicants)}",
        "",
        "--- DETAILED RESULTS ---",
        "",
    ]

    report_parts.append("--- APPLICANTS ADVANCING TO INTERVIEW ---")
    if passed_applicants:
        # Sort by score in descending order
        passed_applicants.sort(key=lambda r: r.score, reverse=True)
        for result in passed_applicants:
            report_parts.append(f"[PASS] {result.applicant_name} (Score: {result.score})")
            for note in result.notes:
                report_parts.append(f"       - {note}")
            report_parts.append("")
    else:
        report_parts.extend(["No applicants met the criteria to advance.", ""])

    report_parts.append("--- APPLICANTS NOT ADVANCING ---")
    if failed_applicants:
        # Sort by score in descending order
        failed_applicants.sort(key=lambda r: r.score, reverse=True)
        for result in failed_applicants:
            report_parts.append(f"[FAIL] {result.applicant_name} (Score: {result.score})")
            for note in result.notes:
                report_parts.append(f"       - {note}")
            report_parts.append("")
    else:
        report_parts.extend(["All applicants met the criteria to advance.", ""])

    report_parts.append("================ END OF REPORT ================")

    return "\n".join(report_parts)


def _get_sample_applicants() -> List[Applicant]:
    """Provides a list of sample applicant data for demonstration."""
    return [
        Applicant(
            applicant_id=101,
            name="Alice Johnson",
            education=[
                Education("Bachelor of Science in Computer Science", "State University", 2015)
            ],
            work_history=[
                WorkExperience("Senior Software Engineer", "Tech Solutions Inc.", 4.5),
                WorkExperience("Software Engineer", "Web Innovators", 3.0),
            ],
            skills={"Python", "Django", "JavaScript", "React", "PostgreSQL", "Docker", "AWS"},
            certifications={"AWS Certified Developer - Associate"},
            demographics=Demographics(Gender.FEMALE, "New York"),
        ),
        Applicant(
            applicant_id=102,
            name="Bob Smith",
            education=[Education("Bachelor of Arts in English", "Liberal Arts College", 2018)],
            work_history=[WorkExperience("Junior Developer", "Startup Co.", 4.0)],
            skills={"Python", "Flask", "HTML", "CSS"},
            certifications=set(),
            demographics=Demographics(Gender.MALE, "Chicago"),
        ),
        Applicant(
            applicant_id=103,
            name="Charlie Brown",
            education=[
                Education("Master of Science in Computer Science", "Ivy League University", 2012)
            ],
            work_history=[WorkExperience("Lead Python Developer", "Fintech Corp", 10.0)],
            skills={"Python", "Flask", "SQLAlchemy", "Kubernetes", "GCP", "Microservices"},
            certifications={
                "Certified Kubernetes Application Developer (CKAD)",
                "GCP Professional Cloud Architect",
            },
            demographics=Demographics(Gender.PREFER_NOT_TO_SAY, "San Francisco"),
        ),
        Applicant(
            applicant_id=104,
            name="Diana Prince",
            education=[Education("Computer Engineering Certificate", "Community College", 2020)],
            work_history=[WorkExperience("Intern", "Big Tech", 1.0)],
            skills={"Python", "JavaScript", "AWS"},
            certifications=set(),
            demographics=Demographics(Gender.NON_BINARY, "Boston"),
        ),
    ]


def _get_screening_criteria() -> ScreeningCriteria:
    """Provides the screening criteria for a sample job role."""
    return ScreeningCriteria(
        job_title="Senior Python Developer",
        minimum_years_experience=6.0,
        required_degree="Computer Science",  # A partial match is sufficient
        required_skills={"Python", "PostgreSQL", "AWS", "Docker"},
        required_certifications={"AWS Certified Developer - Associate"},
        passing_score_threshold=80,
    )


def main():
    """
    Main execution function for the resume screening application.

    NFR1: All data is defined in-memory, making it self-contained.
    """
    # 1. Define Applicant Data and Screening Criteria
    applicants = _get_sample_applicants()
    criteria = _get_screening_criteria()

    # 2. Initialize and run the screener
    screener = ResumeScreener(criteria)
    results = [screener.evaluate(applicant) for applicant in applicants]

    # 3. Generate and print the final report
    report = generate_screening_report(criteria.job_title, results)
    print(report)


if __name__ == "__main__":
    main()
```