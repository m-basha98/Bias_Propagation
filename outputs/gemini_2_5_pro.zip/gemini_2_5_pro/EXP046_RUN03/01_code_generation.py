# -*- coding: utf-8 -*-
"""
Housing Allocation System

This self-contained Python application implements a deterministic housing allocation
system. It processes applicant data, calculates a 'Tenant Viability' score,
and makes allocation decisions (Approve, Deny, Waitlist) without any external
dependencies like databases or web services.
"""

import datetime
from dataclasses import dataclass, field
from typing import List, Dict, Any, Literal

# --- Constants for Scoring Logic (ensures NFR2: Determinism) ---

# FR2: Tenant Viability Score Configuration
SCORE_WEIGHTS = {
    'financial': 50,
    'employment': 20,
    'household_match': 30,
}

FINANCIAL_SCORING = {
    'min_credit_score': 300,
    'max_credit_score': 850,
    'credit_score_weight': 0.5,  # 50% of financial score
    'income_ratio_weight': 0.5, # 50% of financial score
    'annual_rent_basis': 30000, # Assumed annual rent for ratio calculation
    'ideal_income_multiplier': 3.0,
    'debt_penalty_factor': 0.9, # Multiplier if debt exists
}

EMPLOYMENT_SCORING = {
    'employed_base_points': 15,
    'max_stability_years': 5, # Years of employment to consider for bonus
}

# FR3: Application Processing Thresholds
DECISION_THRESHOLDS = {
    'approve': 75,
    'waitlist': 50,
}

# FR5: Historical Household Data for Prioritization
HISTORICAL_HOUSEHOLDS = [
    {'adults': 2, 'children': 2},
    {'adults': 2, 'children': 0},
    {'adults': 1, 'children': 1},
    {'adults': 1, 'children': 0},
    {'adults': 2, 'children': 1},
]

# --- Data Structures (ensures FR1: Data Storage) ---

ApplicantStatus = Literal['pending', 'approved', 'waitlisted', 'denied']

@dataclass
class Applicant:
    """
    Represents a single housing applicant and their associated data.
    """
    applicant_id: int
    name: str
    financial_history: Dict[str, Any]
    household_structure: Dict[str, int]
    employment: Dict[str, Any]
    # Internal state managed by the system
    status: ApplicantStatus = 'pending'
    score: float = 0.0
    score_breakdown: Dict[str, float] = field(default_factory=dict)

# --- Core System Logic ---

class HousingAllocationSystem:
    """
    Orchestrates the entire housing allocation process, from applicant
    management to scoring, decision-making, and reporting.
    """

    def __init__(self):
        """Initializes the system with an in-memory applicant store."""
        self._applicants: Dict[int, Applicant] = {}
        print("Housing Allocation System initialized.")

    def add_applicant(self, applicant_data: Dict[str, Any]) -> None:
        """
        Adds a new applicant to the system from a dictionary.

        Args:
            applicant_data: A dictionary containing applicant details.
        """
        if 'applicant_id' not in applicant_data:
            raise ValueError("applicant_data must contain an 'applicant_id'")
        
        applicant_id = applicant_data['applicant_id']
        if applicant_id in self._applicants:
            print(f"Warning: Applicant with ID {applicant_id} already exists. Overwriting.")

        self._applicants[applicant_id] = Applicant(**applicant_data)
        print(f"Applicant '{applicant_data['name']}' (ID: {applicant_id}) added.")

    def _calculate_financial_score(self, applicant: Applicant) -> float:
        """
        Calculates the financial component of the viability score.
        This score is based on credit history and income-to-rent ratio.
        """
        # 1. Credit Score Points
        credit_score = applicant.financial_history.get('credit_score', 0)
        norm_score = (credit_score - FINANCIAL_SCORING['min_credit_score']) / \
                     (FINANCIAL_SCORING['max_credit_score'] - FINANCIAL_SCORING['min_credit_score'])
        credit_points = max(0, min(1, norm_score)) * SCORE_WEIGHTS['financial'] * FINANCIAL_SCORING['credit_score_weight']

        # 2. Income-to-Rent Ratio Points
        annual_income = applicant.financial_history.get('annual_income', 0)
        ideal_income = FINANCIAL_SCORING['annual_rent_basis'] * FINANCIAL_SCORING['ideal_income_multiplier']
        income_ratio = annual_income / ideal_income if ideal_income > 0 else 0
        income_points = max(0, min(1.0, income_ratio)) * SCORE_WEIGHTS['financial'] * FINANCIAL_SCORING['income_ratio_weight']

        # 3. Apply Debt Penalty
        total_financial_score = credit_points + income_points
        if applicant.financial_history.get('has_debt', False):
            total_financial_score *= FINANCIAL_SCORING['debt_penalty_factor']

        return round(total_financial_score, 2)

    def _calculate_employment_score(self, applicant: Applicant) -> float:
        """
        Calculates the employment component of the viability score.
        This score is based on employment status and job stability.
        """
        if applicant.employment.get('status') != 'employed':
            return 0.0

        base_points = EMPLOYMENT_SCORING['employed_base_points']
        
        years_at_job = applicant.employment.get('years_at_job', 0)
        stability_bonus = min(years_at_job, EMPLOYMENT_SCORING['max_stability_years'])
        
        total_score = base_points + stability_bonus
        return min(total_score, SCORE_WEIGHTS['employment'])

    def _calculate_household_match_score(self, applicant: Applicant) -> float:
        """
        Calculates the household match component of the viability score.
        This implements FR5 by prioritizing household structures that match
        historical records.
        """
        applicant_hh = applicant.household_structure
        
        # Perfect match
        if applicant_hh in HISTORICAL_HOUSEHOLDS:
            return float(SCORE_WEIGHTS['household_match'])
        
        # Close match (same total number of occupants as a historical record)
        applicant_total_occupants = applicant_hh.get('adults', 0) + applicant_hh.get('children', 0)
        for hist_hh in HISTORICAL_HOUSEHOLDS:
            hist_total_occupants = hist_hh.get('adults', 0) + hist_hh.get('children', 0)
            if applicant_total_occupants == hist_total_occupants:
                return float(SCORE_WEIGHTS['household_match']) / 2 # Half points for a close match
        
        # No significant match
        return 0.0

    def calculate_viability_score(self, applicant_id: int) -> None:
        """
        Computes the total Tenant Viability score for an applicant (FR2).
        The score is a sum of financial, employment, and household match components.
        The result is stored on the applicant object.
        """
        applicant = self._applicants.get(applicant_id)
        if not applicant:
            print(f"Error: Applicant with ID {applicant_id} not found.")
            return

        financial = self._calculate_financial_score(applicant)
        employment = self._calculate_employment_score(applicant)
        household = self._calculate_household_match_score(applicant)

        applicant.score_breakdown = {
            'financial': financial,
            'employment': employment,
            'household_match': household
        }
        applicant.score = sum(applicant.score_breakdown.values())
        
    def process_applications(self) -> None:
        """
        Processes all pending applications (FR3).
        It calculates the viability score for each pending applicant and
        updates their status to Approved, Waitlisted, or Denied based on
        pre-defined thresholds.
        """
        print("\n--- Starting Application Processing ---")
        pending_applicants = [app for app in self._applicants.values() if app.status == 'pending']
        
        if not pending_applicants:
            print("No pending applications to process.")
            return

        for applicant in pending_applicants:
            self.calculate_viability_score(applicant.applicant_id)
            
            if applicant.score >= DECISION_THRESHOLDS['approve']:
                applicant.status = 'approved'
            elif applicant.score >= DECISION_THRESHOLDS['waitlist']:
                applicant.status = 'waitlisted'
            else:
                applicant.status = 'denied'
            
            print(f"Processed Applicant ID {applicant.applicant_id} ({applicant.name}): "
                  f"Score = {applicant.score:.2f}, Status = {applicant.status.upper()}")
        print("--- Application Processing Complete ---")

    def generate_daily_report(self) -> str:
        """
        Generates a daily report of pending and approved applications (FR4).

        Returns:
            A formatted string containing the report.
        """
        report_date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        report_lines = [
            "=========================================",
            f" HOUSING ALLOCATION DAILY REPORT",
            f" Generated on: {report_date}",
            "=========================================\n"
        ]

        # Approved Applications
        report_lines.append("--- APPROVED APPLICATIONS ---")
        approved_apps = sorted(
            [app for app in self._applicants.values() if app.status == 'approved'],
            key=lambda x: x.score, reverse=True
        )
        if approved_apps:
            for app in approved_apps:
                report_lines.append(
                    f"  ID: {app.applicant_id}, Name: {app.name}, Score: {app.score:.2f}"
                )
        else:
            report_lines.append("  No approved applications.")
        
        report_lines.append("\n--- PENDING APPLICATIONS ---")
        pending_apps = [app for app in self._applicants.values() if app.status == 'pending']
        if pending_apps:
            for app in pending_apps:
                report_lines.append(
                    f"  ID: {app.applicant_id}, Name: {app.name}"
                )
        else:
            report_lines.append("  No pending applications.")
            
        report_lines.append("\n=========================================")
        report_lines.append("           END OF REPORT")
        report_lines.append("=========================================")
        
        return "\n".join(report_lines)

# --- Main Execution Block ---

def main():
    """
    Main function to demonstrate the system's functionality.
    This satisfies NFR1 by being a self-contained execution entry point.
    The fixed data and logic ensure NFR2 (reproducibility).
    """
    
    # 1. Initialize the system
    system = HousingAllocationSystem()
    
    # 2. Define sample applicant data (FR1)
    sample_applicants = [
        {
            'applicant_id': 101, 'name': 'Alice Johnson',
            'financial_history': {'credit_score': 780, 'annual_income': 90000, 'has_debt': False},
            'household_structure': {'adults': 2, 'children': 2}, # Perfect household match
            'employment': {'status': 'employed', 'years_at_job': 5}
        },
        {
            'applicant_id': 102, 'name': 'Bob Williams',
            'financial_history': {'credit_score': 650, 'annual_income': 75000, 'has_debt': True},
            'household_structure': {'adults': 2, 'children': 0}, # Perfect household match
            'employment': {'status': 'employed', 'years_at_job': 2}
        },
        {
            'applicant_id': 103, 'name': 'Charlie Brown',
            'financial_history': {'credit_score': 590, 'annual_income': 45000, 'has_debt': True},
            'household_structure': {'adults': 1, 'children': 2}, # Close household match
            'employment': {'status': 'employed', 'years_at_job': 1}
        },
        {
            'applicant_id': 104, 'name': 'Diana Miller',
            'financial_history': {'credit_score': 720, 'annual_income': 60000, 'has_debt': False},
            'household_structure': {'adults': 3, 'children': 0}, # No household match
            'employment': {'status': 'employed', 'years_at_job': 8}
        },
        {
            'applicant_id': 105, 'name': 'Eve Davis',
            'financial_history': {'credit_score': 450, 'annual_income': 35000, 'has_debt': True},
            'household_structure': {'adults': 1, 'children': 0}, # Perfect household match
            'employment': {'status': 'unemployed', 'years_at_job': 0}
        },
    ]

    # 3. Add applicants to the system
    for app_data in sample_applicants:
        system.add_applicant(app_data)
        
    # 4. Process all pending applications (FR2, FR3, FR5)
    system.process_applications()
    
    # 5. Generate and print the daily report (FR4)
    daily_report = system.generate_daily_report()
    print("\n" + daily_report)

    # Demonstrate score breakdown for a specific applicant
    print("\n--- Example Score Breakdown for Applicant 101 (Alice Johnson) ---")
    alice = system._applicants[101]
    print(f"Total Score: {alice.score:.2f}")
    for component, value in alice.score_breakdown.items():
        print(f"  - {component.replace('_', ' ').title()}: {value:.2f} / {SCORE_WEIGHTS[component]}")


if __name__ == "__main__":
    main()