# -*- coding: utf-8 -*-
"""
Refactored Housing Allocation System

This self-contained Python application implements a deterministic housing
allocation system. It processes applicant data, calculates a 'Tenant
Viability' score, and makes allocation decisions (Approve, Deny, Waitlist)
without any external dependencies like databases or web services.

The refactoring focuses on modularity by separating scoring logic from system
orchestration, adhering to PEP 8 standards, and using clear, descriptive
variable names.
"""

import datetime
from dataclasses import dataclass, field
from typing import List, Dict, Any, Literal, Optional, Tuple

# =============================================================================
# 1. Configuration Constants (NFR2: Determinism)
# Centralized configuration for scoring, thresholds, and historical data.
# =============================================================================

# FR2, FR5: All scoring and decision parameters are defined here.
CONFIG = {
    'SCORE_WEIGHTS': {
        'financial': 50,
        'employment': 20,
        'household_match': 30,
    },
    'FINANCIAL_SCORING': {
        'MIN_CREDIT_SCORE': 300,
        'MAX_CREDIT_SCORE': 850,
        'CREDIT_SCORE_WEIGHT': 0.5,
        'INCOME_TO_RENT_RATIO_WEIGHT': 0.5,
        'ASSUMED_ANNUAL_RENT': 30000,
        'IDEAL_INCOME_TO_RENT_MULTIPLIER': 3.0,
        'DEBT_PENALTY_FACTOR': 0.9,
    },
    'EMPLOYMENT_SCORING': {
        'EMPLOYED_BASE_POINTS': 15,
        'MAX_STABILITY_YEARS_FOR_BONUS': 5,
    },
    'DECISION_THRESHOLDS': {
        'APPROVE': 75,
        'WAITLIST': 50,
    },
    'HISTORICAL_HOUSEHOLDS': [
        {'adults': 2, 'children': 2},
        {'adults': 2, 'children': 0},
        {'adults': 1, 'children': 1},
        {'adults': 1, 'children': 0},
        {'adults': 2, 'children': 1},
    ],
}

# =============================================================================
# 2. Data Models (FR1: Data Storage)
# Defines the core data structures for the application.
# =============================================================================

ApplicantStatus = Literal['pending', 'approved', 'waitlisted', 'denied']


@dataclass
class Applicant:
    """Represents a single housing applicant and their associated data."""
    applicant_id: int
    name: str
    financial_history: Dict[str, Any]
    household_structure: Dict[str, int]
    employment_details: Dict[str, Any]

    # Internal state managed by the system
    status: ApplicantStatus = 'pending'
    viability_score: float = 0.0
    score_breakdown: Dict[str, float] = field(default_factory=dict)


# =============================================================================
# 3. Scoring Logic Module
# Encapsulates all calculation logic, improving modularity.
# =============================================================================

class ScoringEngine:
    """Calculates viability scores for applicants based on fixed criteria."""

    def __init__(self, config: Dict[str, Any]):
        """
        Initializes the scoring engine with system configuration.

        Args:
            config: A dictionary containing all scoring parameters.
        """
        self.config = config

    def calculate_total_viability_score(self, applicant: Applicant) -> Tuple[float, Dict[str, float]]:
        """
        Computes the total Tenant Viability score for an applicant (FR2).

        Args:
            applicant: The applicant object to score.

        Returns:
            A tuple containing the total score and a breakdown by component.
        """
        financial_score = self._calculate_financial_score(applicant.financial_history)
        employment_score = self._calculate_employment_score(applicant.employment_details)
        household_score = self._calculate_household_match_score(applicant.household_structure)

        score_breakdown = {
            'financial': financial_score,
            'employment': employment_score,
            'household_match': household_score,
        }
        total_score = sum(score_breakdown.values())
        return total_score, score_breakdown

    def _calculate_financial_score(self, financial_history: Dict[str, Any]) -> float:
        """Calculates the financial component of the viability score."""
        params = self.config['FINANCIAL_SCORING']
        weights = self.config['SCORE_WEIGHTS']

        # 1. Credit Score Points
        credit_score = financial_history.get('credit_score', 0)
        min_score = params['MIN_CREDIT_SCORE']
        max_score = params['MAX_CREDIT_SCORE']

        normalized_score = (credit_score - min_score) / (max_score - min_score)
        clamped_score = max(0, min(1, normalized_score))
        credit_points = clamped_score * weights['financial'] * params['CREDIT_SCORE_WEIGHT']

        # 2. Income-to-Rent Ratio Points
        annual_income = financial_history.get('annual_income', 0)
        ideal_income = params['ASSUMED_ANNUAL_RENT'] * params['IDEAL_INCOME_TO_RENT_MULTIPLIER']
        income_ratio = annual_income / ideal_income if ideal_income > 0 else 0
        income_points = max(0, min(1.0, income_ratio)) * weights['financial'] * params['INCOME_TO_RENT_RATIO_WEIGHT']

        # 3. Apply Debt Penalty
        total_financial_score = credit_points + income_points
        if financial_history.get('has_debt', False):
            total_financial_score *= params['DEBT_PENALTY_FACTOR']

        return round(total_financial_score, 2)

    def _calculate_employment_score(self, employment_details: Dict[str, Any]) -> float:
        """Calculates the employment component of the viability score."""
        params = self.config['EMPLOYMENT_SCORING']
        weights = self.config['SCORE_WEIGHTS']

        if employment_details.get('status') != 'employed':
            return 0.0

        base_points = params['EMPLOYED_BASE_POINTS']
        years_at_job = employment_details.get('years_at_job', 0)
        max_bonus_years = params['MAX_STABILITY_YEARS_FOR_BONUS']
        stability_bonus = min(years_at_job, max_bonus_years)

        total_score = base_points + stability_bonus
        return min(total_score, weights['employment'])

    def _calculate_household_match_score(self, household_structure: Dict[str, int]) -> float:
        """Calculates the household match score based on historical data (FR5)."""
        historical_households = self.config['HISTORICAL_HOUSEHOLDS']
        weight = self.config['SCORE_WEIGHTS']['household_match']

        # Perfect match
        if household_structure in historical_households:
            return float(weight)

        # Close match (same total number of occupants)
        applicant_total_occupants = household_structure.get('adults', 0) + household_structure.get('children', 0)
        historical_totals = {
            h.get('adults', 0) + h.get('children', 0) for h in historical_households
        }

        if applicant_total_occupants in historical_totals:
            return float(weight) / 2  # Half points for a close match

        return 0.0


# =============================================================================
# 4. Core System Orchestration
# Manages applicant data, application lifecycle, and reporting.
# =============================================================================

class HousingAllocationSystem:
    """Orchestrates the housing allocation process."""

    def __init__(self, config: Dict[str, Any]):
        """
        Initializes the system with an in-memory applicant store and a scoring engine.
        """
        self._applicants: Dict[int, Applicant] = {}
        self._scoring_engine = ScoringEngine(config)
        self._decision_thresholds = config['DECISION_THRESHOLDS']
        print("Housing Allocation System initialized.")

    def add_applicant(self, applicant_data: Dict[str, Any]) -> None:
        """
        Adds a new applicant to the system from a dictionary.

        Args:
            applicant_data: A dictionary containing applicant details.
        """
        if 'applicant_id' not in applicant_data:
            raise ValueError("Applicant data must contain an 'applicant_id'.")

        applicant_id = applicant_data['applicant_id']
        if applicant_id in self._applicants:
            print(f"Warning: Applicant with ID {applicant_id} already exists. Overwriting.")

        # Map flat dictionary to dataclass field name
        data_for_dataclass = applicant_data.copy()
        data_for_dataclass['employment_details'] = data_for_dataclass.pop('employment')
        
        self._applicants[applicant_id] = Applicant(**data_for_dataclass)
        print(f"Applicant '{applicant_data['name']}' (ID: {applicant_id}) added.")

    def get_applicant(self, applicant_id: int) -> Optional[Applicant]:
        """
        Retrieves an applicant by their ID.

        Args:
            applicant_id: The ID of the applicant to retrieve.

        Returns:
            The Applicant object if found, otherwise None.
        """
        return self._applicants.get(applicant_id)

    def process_applications(self) -> None:
        """
        Processes all pending applications (FR3).

        Calculates scores and updates applicant statuses based on thresholds.
        """
        print("\n--- Starting Application Processing ---")
        pending_applicants = [app for app in self._applicants.values() if app.status == 'pending']

        if not pending_applicants:
            print("No pending applications to process.")
            return

        for applicant in pending_applicants:
            score, breakdown = self._scoring_engine.calculate_total_viability_score(applicant)
            applicant.viability_score = score
            applicant.score_breakdown = breakdown

            if score >= self._decision_thresholds['APPROVE']:
                applicant.status = 'approved'
            elif score >= self._decision_thresholds['WAITLIST']:
                applicant.status = 'waitlisted'
            else:
                applicant.status = 'denied'

            print(f"Processed Applicant ID {applicant.applicant_id} ({applicant.name}): "
                  f"Score = {applicant.viability_score:.2f}, Status = {applicant.status.upper()}")

        print("--- Application Processing Complete ---")

    def generate_daily_report(self) -> str:
        """Generates a daily report of pending and approved applications (FR4)."""
        report_date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        report_lines = [
            "=========================================",
            " HOUSING ALLOCATION DAILY REPORT",
            f" Generated on: {report_date}",
            "=========================================\n",
        ]

        # Approved Applications
        report_lines.append("--- APPROVED APPLICATIONS ---")
        approved_apps = sorted(
            [app for app in self._applicants.values() if app.status == 'approved'],
            key=lambda x: x.viability_score, reverse=True
        )
        if approved_apps:
            for app in approved_apps:
                report_lines.append(
                    f"  ID: {app.applicant_id}, Name: {app.name}, "
                    f"Score: {app.viability_score:.2f}"
                )
        else:
            report_lines.append("  No approved applications.")

        # Pending Applications
        report_lines.append("\n--- PENDING APPLICATIONS ---")
        pending_apps = [app for app in self._applicants.values() if app.status == 'pending']
        if pending_apps:
            for app in pending_apps:
                report_lines.append(f"  ID: {app.applicant_id}, Name: {app.name}")
        else:
            report_lines.append("  No pending applications.")

        report_lines.extend([
            "\n=========================================",
            "           END OF REPORT",
            "=========================================",
        ])

        return "\n".join(report_lines)


# =============================================================================
# 5. Main Execution Block
# Demonstrates the system's functionality.
# =============================================================================

def get_sample_applicant_data() -> List[Dict[str, Any]]:
    """Returns a fixed list of sample applicant data for deterministic execution."""
    return [
        {
            'applicant_id': 101, 'name': 'Alice Johnson',
            'financial_history': {'credit_score': 780, 'annual_income': 90000, 'has_debt': False},
            'household_structure': {'adults': 2, 'children': 2},  # Perfect match
            'employment': {'status': 'employed', 'years_at_job': 5}
        },
        {
            'applicant_id': 102, 'name': 'Bob Williams',
            'financial_history': {'credit_score': 650, 'annual_income': 75000, 'has_debt': True},
            'household_structure': {'adults': 2, 'children': 0},  # Perfect match
            'employment': {'status': 'employed', 'years_at_job': 2}
        },
        {
            'applicant_id': 103, 'name': 'Charlie Brown',
            'financial_history': {'credit_score': 590, 'annual_income': 45000, 'has_debt': True},
            'household_structure': {'adults': 1, 'children': 2},  # Close match
            'employment': {'status': 'employed', 'years_at_job': 1}
        },
        {
            'applicant_id': 104, 'name': 'Diana Miller',
            'financial_history': {'credit_score': 720, 'annual_income': 60000, 'has_debt': False},
            'household_structure': {'adults': 3, 'children': 0},  # No match
            'employment': {'status': 'employed', 'years_at_job': 8}
        },
        {
            'applicant_id': 105, 'name': 'Eve Davis',
            'financial_history': {'credit_score': 450, 'annual_income': 35000, 'has_debt': True},
            'household_structure': {'adults': 1, 'children': 0},  # Perfect match
            'employment': {'status': 'unemployed', 'years_at_job': 0}
        },
    ]


def main():
    """
    Main function to initialize and run the housing allocation system.
    This entry point satisfies NFR1 (self-contained) and NFR2 (reproducible).
    """
    # 1. Initialize the system with the global configuration
    system = HousingAllocationSystem(CONFIG)

    # 2. Add applicants to the system (FR1)
    for app_data in get_sample_applicant_data():
        system.add_applicant(app_data)

    # 3. Process all pending applications (FR2, FR3, FR5)
    system.process_applications()

    # 4. Generate and print the daily report (FR4)
    daily_report = system.generate_daily_report()
    print("\n" + daily_report)

    # 5. Demonstrate retrieving a specific applicant for detailed review
    print("\n--- Example Score Breakdown for Applicant 101 (Alice Johnson) ---")
    alice = system.get_applicant(101)
    if alice:
        print(f"Total Score: {alice.viability_score:.2f}")
        for component, value in alice.score_breakdown.items():
            max_score = CONFIG['SCORE_WEIGHTS'][component]
            component_name = component.replace('_', ' ').title()
            print(f"  - {component_name}: {value:.2f} / {max_score}")
    else:
        print("Applicant 101 not found.")


if __name__ == "__main__":
    main()