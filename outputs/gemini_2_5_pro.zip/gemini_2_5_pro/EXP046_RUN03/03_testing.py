# -*- coding: utf-8 -*-
"""
Unit Test Suite for the Housing Allocation System.

This test suite uses the pytest framework to validate the functionality of the
refactored Housing Allocation System. It covers all major components, including
the ScoringEngine and the HousingAllocationSystem, with a focus on edge cases,
boundary conditions, and standard scenarios.

To run these tests:
1. Save the original refactored code as `housing_allocation_system.py`.
2. Save this test code as `test_housing_system.py` in the same directory.
3. Ensure you have pytest installed (`pip install pytest`).
4. Run `pytest` from your terminal in that directory.
"""

import pytest
import datetime
from unittest.mock import patch

# Assuming the provided code is saved in a file named 'housing_allocation_system.py'
import housing_allocation_system as has


# =============================================================================
# 1. Pytest Fixtures
# Reusable components for setting up test conditions.
# =============================================================================

@pytest.fixture
def config():
    """Provides a fresh copy of the default system configuration for each test."""
    return has.CONFIG.copy()


@pytest.fixture
def scoring_engine(config):
    """Provides an instance of the ScoringEngine with default config."""
    return has.ScoringEngine(config)


@pytest.fixture
def allocation_system(config):
    """Provides a clean instance of the HousingAllocationSystem."""
    return has.HousingAllocationSystem(config)


@pytest.fixture
def applicant_perfect():
    """Provides an Applicant object representing a high-scoring candidate."""
    return has.Applicant(
        applicant_id=101, name='Perfect Candidate',
        financial_history={'credit_score': 850, 'annual_income': 90000, 'has_debt': False},
        household_structure={'adults': 2, 'children': 2},  # Perfect match
        employment_details={'status': 'employed', 'years_at_job': 10}
    )


@pytest.fixture
def applicant_borderline():
    """Provides an Applicant object representing a medium-scoring candidate."""
    return has.Applicant(
        applicant_id=102, name='Borderline Candidate',
        financial_history={'credit_score': 650, 'annual_income': 60000, 'has_debt': True},
        household_structure={'adults': 1, 'children': 2},  # Close match
        employment_details={'status': 'employed', 'years_at_job': 1}
    )


@pytest.fixture
def applicant_poor():
    """Provides an Applicant object representing a low-scoring candidate."""
    return has.Applicant(
        applicant_id=103, name='Poor Candidate',
        financial_history={'credit_score': 450, 'annual_income': 30000, 'has_debt': True},
        household_structure={'adults': 4, 'children': 0},  # No match
        employment_details={'status': 'unemployed', 'years_at_job': 0}
    )


# =============================================================================
# 2. Tests for ScoringEngine
# =============================================================================

class TestScoringEngine:
    """Tests the calculation logic within the ScoringEngine."""

    @pytest.mark.parametrize("history, expected_score", [
        # Perfect financial history
        ({'credit_score': 850, 'annual_income': 90000, 'has_debt': False}, 50.00),
        # Average financial history with debt
        ({'credit_score': 650, 'annual_income': 60000, 'has_debt': True}, 26.24 * 0.9), # ~23.62
        # Poor financial history
        ({'credit_score': 300, 'annual_income': 0, 'has_debt': True}, 0.00),
        # Boundary: Credit score below minimum
        ({'credit_score': 200, 'annual_income': 90000, 'has_debt': False}, 25.00),
        # Boundary: Credit score above maximum
        ({'credit_score': 900, 'annual_income': 90000, 'has_debt': False}, 50.00),
        # Edge case: Missing keys should default to 0/False
        ({}, 0.00),
        # Edge case: Only credit score
        ({'credit_score': 850}, 25.00),
        # Edge case: Only income, no debt
        ({'annual_income': 90000}, 25.00),
        # Edge case: Only income, with debt
        ({'annual_income': 90000, 'has_debt': True}, 22.50)
    ])
    def test_calculate_financial_score(self, scoring_engine, history, expected_score):
        """Tests financial score calculation across various scenarios."""
        score = scoring_engine._calculate_financial_score(history)
        assert score == pytest.approx(expected_score, abs=0.01)

    @pytest.mark.parametrize("details, expected_score", [
        # Employed with max stability bonus
        ({'status': 'employed', 'years_at_job': 10}, 20.0),
        # Employed with partial stability bonus
        ({'status': 'employed', 'years_at_job': 3}, 18.0),
        # Employed with no stability bonus
        ({'status': 'employed', 'years_at_job': 0}, 15.0),
        # Unemployed
        ({'status': 'unemployed', 'years_at_job': 0}, 0.0),
        # Other status
        ({'status': 'student', 'years_at_job': 0}, 0.0),
        # Edge case: Missing status key
        ({'years_at_job': 5}, 0.0),
        # Edge case: Missing years_at_job key
        ({'status': 'employed'}, 15.0),
        # Edge case: Empty dictionary
        ({}, 0.0),
    ])
    def test_calculate_employment_score(self, scoring_engine, details, expected_score):
        """Tests employment score calculation for different statuses and tenures."""
        score = scoring_engine._calculate_employment_score(details)
        assert score == pytest.approx(expected_score)

    @pytest.mark.parametrize("structure, expected_score", [
        # Perfect match (2 adults, 2 children is in HISTORICAL_HOUSEHOLDS)
        ({'adults': 2, 'children': 2}, 30.0),
        # Another perfect match
        ({'adults': 1, 'children': 0}, 30.0),
        # Close match (total 3 occupants, same as {'adults': 2, 'children': 1})
        ({'adults': 1, 'children': 2}, 15.0),
        # No match (total 5 occupants is not in historical totals)
        ({'adults': 3, 'children': 2}, 0.0),
        # No match (total 3 occupants, but different config)
        ({'adults': 3, 'children': 0}, 15.0), # Note: 3 is a valid total
        # Edge case: Missing keys
        ({'adults': 1}, 30.0), # Matches {'adults': 1, 'children': 0}
        # Edge case: Empty dictionary
        ({}, 0.0),
    ])
    def test_calculate_household_match_score(self, scoring_engine, structure, expected_score):
        """Tests household match score for perfect, close, and no matches."""
        score = scoring_engine._calculate_household_match_score(structure)
        assert score == pytest.approx(expected_score)

    def test_calculate_total_viability_score(self, scoring_engine, applicant_perfect):
        """Ensures the total score is the sum of its components."""
        total_score, breakdown = scoring_engine.calculate_total_viability_score(applicant_perfect)

        # Expected scores for applicant_perfect
        # Financial: 50 (max credit, high income, no debt)
        # Employment: 20 (employed, 5+ years)
        # Household: 30 (perfect match)
        # Total: 100
        expected_total = 100.0
        expected_breakdown = {'financial': 50.0, 'employment': 20.0, 'household_match': 30.0}

        assert total_score == pytest.approx(expected_total)
        assert breakdown == expected_breakdown
        assert total_score == pytest.approx(sum(breakdown.values()))


# =============================================================================
# 3. Tests for HousingAllocationSystem
# =============================================================================

class TestHousingAllocationSystem:
    """Tests the orchestration logic of the HousingAllocationSystem."""

    def test_add_applicant_success(self, allocation_system):
        """Tests successful addition of a new applicant."""
        app_data = has.get_sample_applicant_data()[0]
        allocation_system.add_applicant(app_data)
        
        retrieved_app = allocation_system.get_applicant(app_data['applicant_id'])
        assert retrieved_app is not None
        assert retrieved_app.name == app_data['name']
        assert retrieved_app.status == 'pending'
        assert 'status' in retrieved_app.employment_details # Check re-mapping

    def test_add_applicant_overwrite(self, allocation_system, capsys):
        """Tests that adding a duplicate ID overwrites the existing record."""
        app_data = {'applicant_id': 1, 'name': 'First', 'financial_history': {}, 'household_structure': {}, 'employment': {}}
        allocation_system.add_applicant(app_data)
        
        new_app_data = {'applicant_id': 1, 'name': 'Second', 'financial_history': {}, 'household_structure': {}, 'employment': {}}
        allocation_system.add_applicant(new_app_data)

        captured = capsys.readouterr()
        assert "Warning: Applicant with ID 1 already exists. Overwriting." in captured.out
        
        retrieved_app = allocation_system.get_applicant(1)
        assert retrieved_app.name == 'Second'

    def test_add_applicant_missing_id_raises_error(self, allocation_system):
        """Tests that missing 'applicant_id' raises a ValueError."""
        bad_data = {'name': 'No ID', 'financial_history': {}, 'household_structure': {}, 'employment': {}}
        with pytest.raises(ValueError, match="must contain an 'applicant_id'"):
            allocation_system.add_applicant(bad_data)

    def test_get_applicant(self, allocation_system):
        """Tests retrieving existing and non-existent applicants."""
        app_data = has.get_sample_applicant_data()[0]
        allocation_system.add_applicant(app_data)
        
        # Test getting an existing applicant
        assert allocation_system.get_applicant(101) is not None
        
        # Test getting a non-existent applicant
        assert allocation_system.get_applicant(999) is None

    def test_process_applications(self, allocation_system, applicant_perfect, applicant_borderline, applicant_poor):
        """Tests the end-to-end application processing and status assignment logic."""
        # Manually add applicants to the internal dictionary
        allocation_system._applicants = {
            applicant_perfect.applicant_id: applicant_perfect,
            applicant_borderline.applicant_id: applicant_borderline,
            applicant_poor.applicant_id: applicant_poor,
        }
        
        # Add one more applicant that is already approved to test it's skipped
        already_approved = has.Applicant(
            applicant_id=104, name='Already Approved',
            financial_history={}, household_structure={}, employment_details={},
            status='approved', viability_score=99.0
        )
        allocation_system._applicants[104] = already_approved

        allocation_system.process_applications()
        
        # Check statuses based on thresholds (APPROVE: 75, WAITLIST: 50)
        assert allocation_system.get_applicant(101).status == 'approved'
        assert allocation_system.get_applicant(101).viability_score > 75

        assert allocation_system.get_applicant(102).status == 'waitlisted'
        assert 50 <= allocation_system.get_applicant(102).viability_score < 75

        assert allocation_system.get_applicant(103).status == 'denied'
        assert allocation_system.get_applicant(103).viability_score < 50
        
        # Check that the already approved applicant was not changed
        assert allocation_system.get_applicant(104).status == 'approved'
        assert allocation_system.get_applicant(104).viability_score == 99.0

    def test_process_applications_no_pending(self, allocation_system, capsys):
        """Tests processing when there are no pending applications."""
        allocation_system.process_applications()
        captured = capsys.readouterr()
        assert "No pending applications to process." in captured.out

    @patch('datetime.datetime')
    def test_generate_daily_report_all_cases(self, mock_dt, allocation_system):
        """Tests report generation with a mix of applicant statuses."""
        mock_dt.now.return_value = datetime.datetime(2023, 10, 27, 10, 0, 0)
        
        # Add a mix of applicants
        app_approved_high = has.Applicant(1, 'High Scorer', {}, {}, {}, 'approved', 95.0)
        app_approved_low = has.Applicant(2, 'Low Scorer', {}, {}, {}, 'approved', 80.0)
        app_pending = has.Applicant(3, 'Pending App', {}, {}, {}, 'pending')
        app_denied = has.Applicant(4, 'Denied App', {}, {}, {}, 'denied')
        
        allocation_system._applicants = {1: app_approved_high, 2: app_approved_low, 3: app_pending, 4: app_denied}
        
        report = allocation_system.generate_daily_report()
        
        # Check for key components
        assert "Generated on: 2023-10-27 10:00:00" in report
        assert "--- APPROVED APPLICATIONS ---" in report
        assert "ID: 1, Name: High Scorer, Score: 95.00" in report
        assert "ID: 2, Name: Low Scorer, Score: 80.00" in report
        
        # Check sorting of approved applications (high to low score)
        high_scorer_pos = report.find("High Scorer")
        low_scorer_pos = report.find("Low Scorer")
        assert high_scorer_pos < low_scorer_pos

        assert "\n--- PENDING APPLICATIONS ---" in report
        assert "ID: 3, Name: Pending App" in report
        assert "Denied App" not in report # Denied should not be in the report
        
    def test_generate_daily_report_no_approved(self, allocation_system):
        """Tests report generation when there are no approved applications."""
        app_pending = has.Applicant(3, 'Pending App', {}, {}, {}, 'pending')
        allocation_system._applicants = {3: app_pending}
        report = allocation_system.generate_daily_report()
        assert "No approved applications." in report
        assert "ID: 3, Name: Pending App" in report

    def test_generate_daily_report_no_pending(self, allocation_system):
        """Tests report generation when there are no pending applications."""
        app_approved = has.Applicant(1, 'Approved App', {}, {}, {}, 'approved', 85.0)
        allocation_system._applicants = {1: app_approved}
        report = allocation_system.generate_daily_report()
        assert "ID: 1, Name: Approved App" in report
        assert "No pending applications." in report

    def test_generate_daily_report_empty_system(self, allocation_system):
        """Tests report generation for an empty system."""
        report = allocation_system.generate_daily_report()
        assert "No approved applications." in report
        assert "No pending applications." in report