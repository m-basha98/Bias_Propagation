Here is the detailed technical documentation for the provided Python code.

***

# Technical Documentation: Housing Allocation System

## 1. Overview

This document provides a detailed technical explanation of the self-contained Python Housing Allocation System. The system is designed to manage and process lease applications by calculating a "Tenant Viability" score for each applicant based on a deterministic set of rules.

The application adheres to the following key principles:
- **Self-Contained:** It operates without any external dependencies such as databases, APIs, or services, satisfying **NFR1**.
- **Deterministic:** All calculations and decisions are based on a fixed, centralized configuration, ensuring that the same inputs will always produce the same outputs, satisfying **NFR2**.
- **Modular:** The logic for calculating scores (`ScoringEngine`) is distinctly separated from the main application orchestration (`HousingAllocationSystem`), making the code easier to maintain and understand.

## 2. System Architecture

The system is composed of four primary components:

1.  **Configuration (`CONFIG`):** A global dictionary that holds all constants, weights, and thresholds. This is the single source of truth for all business logic, making the system's behavior transparent and easily adjustable.
2.  **Data Models (`Applicant`):** A `dataclass` that defines the structure for applicant data, ensuring type safety and clarity.
3.  **Scoring Engine (`ScoringEngine`):** A class dedicated to performing all score calculations. It takes applicant data and the system configuration as input and produces a numerical viability score.
4.  **Orchestration (`HousingAllocationSystem`):** The main class that manages the application lifecycle. It handles adding applicants, processing applications, and generating reports.

## 3. Configuration (`CONFIG`)

The `CONFIG` dictionary centralizes all parameters that control the system's logic. This design is critical for ensuring determinism (**NFR2**).

| Key | Description |
|---|---|
| `SCORE_WEIGHTS` | Defines the maximum possible points for each component of the total viability score. The sum of these values represents the maximum achievable score. |
| `FINANCIAL_SCORING`| Contains parameters used exclusively for calculating the financial score component. This includes credit score ranges, income-to-rent multipliers, and debt penalties. |
| `EMPLOYMENT_SCORING`| Contains parameters for the employment score component, such as base points for being employed and bonuses for job stability. |
| `DECISION_THRESHOLDS`| Defines the minimum viability scores required for an applicant to be approved or waitlisted. |
| `HISTORICAL_HOUSEHOLDS`| A list of dictionaries representing historically preferred household structures. This data is used to calculate the household match score (**FR5**). |

## 4. Data Models

### `ApplicantStatus`
A type alias representing the possible states of an application.

-   **Type:** `typing.Literal`
-   **Values:** `'pending'`, `'approved'`, `'waitlisted'`, `'denied'`

### `Applicant` Dataclass
Represents a single housing applicant and their associated data (**FR1**).

-   **`applicant_id`** (`int`): A unique identifier for the applicant.
-   **`name`** (`str`): The full name of the applicant.
-   **`financial_history`** (`Dict[str, Any]`): A dictionary containing financial data, such as `credit_score`, `annual_income`, and `has_debt`.
-   **`household_structure`** (`Dict[str, int]`): A dictionary describing the household composition, e.g., `{'adults': 2, 'children': 1}`.
-   **`employment_details`** (`Dict[str, Any]`): A dictionary containing employment information, such as `status` ('employed', 'unemployed') and `years_at_job`.
-   **`status`** (`ApplicantStatus`): The current processing status of the application. Defaults to `'pending'`.
-   **`viability_score`** (`float`): The calculated Tenant Viability score. Defaults to `0.0`.
-   **`score_breakdown`** (`Dict[str, float]`): A dictionary storing the individual component scores (financial, employment, household_match) that contribute to the total score.

## 5. Scoring Logic (`ScoringEngine`)

This class encapsulates all the logic for calculating an applicant's viability score (**FR2**). It is initialized with the system `CONFIG` and has no internal state of its own.

### `__init__(self, config)`
Initializes the scoring engine.

-   **Parameters:**
    -   `config` (`Dict[str, Any]`): The system's global configuration dictionary.

### `calculate_total_viability_score(self, applicant)`
Computes the total Tenant Viability score by summing the individual component scores.

-   **Parameters:**
    -   `applicant` (`Applicant`): The applicant object to be scored.
-   **Returns:**
    -   `Tuple[float, Dict[str, float]]`: A tuple containing:
        1.  The final, total viability score.
        2.  A dictionary breaking down the score by its components.

### `_calculate_financial_score(self, financial_history)`
Calculates the financial component of the score based on credit history, income, and debt. The calculation involves:
1.  Normalizing the credit score to a 0-1 scale.
2.  Calculating an income-to-rent ratio score.
3.  Weighting and summing the two sub-scores.
4.  Applying a penalty if the applicant has significant debt.

-   **Parameters:**
    -   `financial_history` (`Dict[str, Any]`): The applicant's financial data.
-   **Returns:**
    -   `float`: The calculated financial score, rounded to two decimal places.

### `_calculate_employment_score(self, employment_details)`
Calculates the employment component of the score. An applicant receives base points for being employed and a bonus based on years of stability at their current job, capped at a configured maximum.

-   **Parameters:**
    -   `employment_details` (`Dict[str, Any]`): The applicant's employment data.
-   **Returns:**
    -   `float`: The calculated employment score.

### `_calculate_household_match_score(self, household_structure)`
Calculates the household match score by comparing the applicant's household structure to a list of historically preferred configurations (**FR5**).
-   Full points are awarded for a perfect match.
-   Half points are awarded for a "close" match (same total number of occupants but different adult/child distribution).
-   Zero points are awarded for no match.

-   **Parameters:**
    -   `household_structure` (`Dict[str, int]`): The applicant's household composition.
-   **Returns:**
    -   `float`: The calculated household match score.

## 6. System Orchestration (`HousingAllocationSystem`)

This class acts as the main controller for the application. It manages a collection of applicants and orchestrates the entire workflow from data ingestion to final reporting.

### `__init__(self, config)`
Initializes the system, creating an in-memory applicant store and an instance of the `ScoringEngine`.

-   **Parameters:**
    -   `config` (`Dict[str, Any]`): The system's global configuration dictionary.

### `add_applicant(self, applicant_data)`
Adds a new applicant to the system from a dictionary. It validates the input, creates an `Applicant` object, and stores it in the internal `_applicants` dictionary.

-   **Parameters:**
    -   `applicant_data` (`Dict[str, Any]`): A dictionary containing all required applicant details.
-   **Raises:**
    -   `ValueError`: If the `applicant_data` dictionary is missing the `applicant_id` key.

### `get_applicant(self, applicant_id)`
Retrieves a single applicant by their unique ID.

-   **Parameters:**
    -   `applicant_id` (`int`): The ID of the applicant to retrieve.
-   **Returns:**
    -   `Optional[Applicant]`: The `Applicant` object if found, otherwise `None`.

### `process_applications(self)`
Processes all applications with a `'pending'` status (**FR3**). For each pending applicant, it:
1.  Calls the `ScoringEngine` to calculate the viability score.
2.  Updates the applicant's `viability_score` and `score_breakdown` attributes.
3.  Updates the applicant's `status` to `'approved'`, `'waitlisted'`, or `'denied'` based on the `DECISION_THRESHOLDS` from the configuration.

### `generate_daily_report(self)`
Generates a formatted string report summarizing the current state of applications (**FR4**). The report includes separate sections for approved and pending applications. Approved applications are sorted in descending order by their viability score.

-   **Returns:**
    -   `str`: A multi-line string containing the formatted report.

## 7. Main Execution

The script includes a main execution block (`if __name__ == "__main__":`) that demonstrates the system's end-to-end functionality.

### `get_sample_applicant_data()`
A helper function that returns a static list of sample applicant dictionaries. This ensures that every run of the script is deterministic and reproducible, serving as a simple integration test.

-   **Returns:**
    -   `List[Dict[str, Any]]`: A list of sample applicant data.

### `main()`
The primary entry point of the script. It orchestrates the following workflow:
1.  Initializes the `HousingAllocationSystem` with the global `CONFIG`.
2.  Adds sample applicants to the system using `add_applicant()`.
3.  Triggers the processing of all pending applications via `process_applications()`.
4.  Generates the daily summary report with `generate_daily_report()` and prints it to the console.
5.  Demonstrates retrieving a specific applicant's detailed score breakdown using `get_applicant()`.