# -*- coding: utf-8 -*-
"""
A self-contained, refactored Python application for a retail banking loan
approval system.

This script implements a simplified loan approval workflow, including data
storage, risk calculation, automated decision-making, and final reporting. It
has been modularized to separate concerns:
- Data Models: Applicant and LoanApplication dataclasses.
- Logic Services: RiskCalculator and DecisionEngine classes for core business logic.
- Orchestration: LoanApprovalSystem class to manage the workflow.
- Presentation: Functions for generating reports and mock data.

The application is designed to be self-contained, requiring no external
databases or services, fulfilling NFR1.
"""
from dataclasses import dataclass
from enum import Enum, auto
from typing import List, Dict

# =============================================================================
# Configuration Constants
# =============================================================================
# These constants ensure that the scoring and decision logic are consistent
# across all loan applications, fulfilling NFR2.

# --- Credit Score Configuration ---
MIN_CREDIT_SCORE_FOR_CONSIDERATION = 600
CREDIT_SCORE_WEIGHT = 0.50
# The typical range for credit scores used in normalization
CREDIT_SCORE_MIN_RANGE = 300
CREDIT_SCORE_MAX_RANGE = 850

# --- Debt-to-Income (DTI) Ratio Configuration ---
MAX_DTI_RATIO_AUTO_DENY = 0.50
IDEAL_DTI_RATIO_AUTO_APPROVE = 0.36
DTI_RATIO_WEIGHT = 0.30

# --- Loan-to-Value (LTV) Ratio Configuration ---
LTV_RATIO_WEIGHT = 0.20

# --- Final Risk Score Thresholds for Decisioning ---
RISK_SCORE_APPROVE_THRESHOLD = 700
RISK_SCORE_MANUAL_REVIEW_THRESHOLD = 550


# =============================================================================
# Data Models
# =============================================================================

class LoanDecision(Enum):
    """Enumeration for the possible outcomes of a loan application."""
    APPROVE = auto()
    DENY = auto()
    MANUAL_REVIEW = auto()

    def __str__(self) -> str:
        """Return a user-friendly string representation."""
        return self.name.replace("_", " ").title()


@dataclass(frozen=True)
class ApplicantProfile:
    """
    Represents an applicant's immutable financial profile and loan request.

    This class serves as the primary data storage structure for applicant data,
    fulfilling FR1. The 'frozen=True' argument ensures that applicant data
    cannot be accidentally modified after creation.
    """
    applicant_id: str
    credit_score: int
    annual_income: float
    monthly_debt: float
    requested_loan_amount: float
    collateral_value: float


@dataclass
class LoanApplication:
    """
    Represents a complete loan application, including the applicant's profile,
    all calculated metrics, and the final decision. This is a mutable object
    that is updated as it moves through the approval workflow.
    """
    profile: ApplicantProfile
    debt_to_income_ratio: float = 0.0
    loan_to_value_ratio: float = 0.0
    risk_score: int = 0
    decision: LoanDecision = LoanDecision.MANUAL_REVIEW
    decision_reason: str = "Awaiting processing."


# =============================================================================
# Core Logic Services
# =============================================================================

class RiskCalculator:
    """
    A service class responsible for all financial calculations.

    This class encapsulates the logic for calculating financial ratios and
    composite risk scores, fulfilling FR2. All methods are static as they
    perform pure calculations without maintaining any internal state.
    """

    @staticmethod
    def calculate_financial_ratios(application: LoanApplication) -> None:
        """Calculates and sets the DTI and LTV ratios for an application."""
        profile = application.profile

        # Calculate Debt-to-Income (DTI) Ratio
        if profile.annual_income > 0:
            total_annual_debt = profile.monthly_debt * 12
            application.debt_to_income_ratio = total_annual_debt / profile.annual_income
        else:
            application.debt_to_income_ratio = float('inf')

        # Calculate Loan-to-Value (LTV) Ratio
        if profile.collateral_value > 0:
            application.loan_to_value_ratio = profile.requested_loan_amount / profile.collateral_value
        else:
            # An infinite LTV represents an unsecured loan
            application.loan_to_value_ratio = float('inf')

    @staticmethod
    def calculate_risk_score(application: LoanApplication) -> None:
        """
        Calculates a weighted risk score on a scale of 0-1000.

        The score is derived from the applicant's credit score, DTI ratio, and
        LTV ratio, ensuring consistent scoring logic as per NFR2.
        """
        profile = application.profile

        # 1. Credit Score Component (0-1000)
        # Clamp the score to the expected range before normalization
        clamped_credit_score = min(max(profile.credit_score, CREDIT_SCORE_MIN_RANGE), CREDIT_SCORE_MAX_RANGE)
        normalized_credit_score = (
            (clamped_credit_score - CREDIT_SCORE_MIN_RANGE) /
            (CREDIT_SCORE_MAX_RANGE - CREDIT_SCORE_MIN_RANGE)
        ) * 1000

        # 2. DTI Component (0-1000) - Lower is better
        if application.debt_to_income_ratio <= 0.20:
            dti_score = 1000
        elif application.debt_to_income_ratio <= 0.36:
            dti_score = 800
        elif application.debt_to_income_ratio <= 0.43:
            dti_score = 600
        elif application.debt_to_income_ratio <= 0.50:
            dti_score = 400
        else:
            dti_score = 200

        # 3. LTV Component (0-1000) - Lower is better
        if application.loan_to_value_ratio <= 0.60:
            ltv_score = 1000
        elif application.loan_to_value_ratio <= 0.80:
            ltv_score = 800
        elif application.loan_to_value_ratio <= 0.90:
            ltv_score = 600
        elif application.loan_to_value_ratio <= 1.00:
            ltv_score = 400
        else:
            # Score for unsecured or high-LTV loans
            ltv_score = 200

        # 4. Final Weighted Score
        final_score = (
            (normalized_credit_score * CREDIT_SCORE_WEIGHT) +
            (dti_score * DTI_RATIO_WEIGHT) +
            (ltv_score * LTV_RATIO_WEIGHT)
        )
        application.risk_score = int(final_score)


class DecisionEngine:
    """
    A service class for making automated loan decisions.

    This class encapsulates the business rules for approving, denying, or
    flagging a loan for manual review, fulfilling FR3.
    """

    @staticmethod
    def determine_decision(application: LoanApplication) -> None:
        """
        Applies a set of rules to an application to reach a final decision.
        The rules are processed in a specific order of precedence.
        """
        profile = application.profile

        # Rule 1: Automatic Denial based on hard limits
        if profile.credit_score < MIN_CREDIT_SCORE_FOR_CONSIDERATION:
            application.decision = LoanDecision.DENY
            application.decision_reason = (
                f"Credit score of {profile.credit_score} is below the "
                f"minimum of {MIN_CREDIT_SCORE_FOR_CONSIDERATION}."
            )
            return
        if application.debt_to_income_ratio > MAX_DTI_RATIO_AUTO_DENY:
            application.decision = LoanDecision.DENY
            application.decision_reason = (
                f"DTI ratio of {application.debt_to_income_ratio:.2%} "
                f"exceeds the maximum of {MAX_DTI_RATIO_AUTO_DENY:.0%}."
            )
            return

        # Rule 2: Automatic Approval for strong profiles
        if (application.risk_score >= RISK_SCORE_APPROVE_THRESHOLD and
                application.debt_to_income_ratio < IDEAL_DTI_RATIO_AUTO_APPROVE):
            application.decision = LoanDecision.APPROVE
            application.decision_reason = "Applicant has a strong financial profile and low risk score."
            return

        # Rule 3: Manual Review for borderline cases
        if application.risk_score >= RISK_SCORE_MANUAL_REVIEW_THRESHOLD:
            application.decision = LoanDecision.MANUAL_REVIEW
            application.decision_reason = "Applicant profile is acceptable but requires manual underwriting."
            return

        # Rule 4: Default Denial for high-risk profiles not caught by other rules
        application.decision = LoanDecision.DENY
        application.decision_reason = (
            f"Risk score of {application.risk_score} is below the "
            f"minimum threshold of {RISK_SCORE_MANUAL_REVIEW_THRESHOLD}."
        )


# =============================================================================
# System Orchestration
# =============================================================================

class LoanApprovalSystem:
    """
    Core class for the loan approval system.

    It orchestrates the end-to-end process by coordinating the data models and
    logic services to process a batch of loan applications.
    """

    def process_applications(self, applicants: List[ApplicantProfile]) -> List[LoanApplication]:
        """
        Processes a list of applicants and returns their completed applications.

        Args:
            applicants: A list of ApplicantProfile objects.

        Returns:
            A list of processed LoanApplication objects with final decisions.
        """
        processed_applications: List[LoanApplication] = []
        for applicant_profile in applicants:
            application = LoanApplication(profile=applicant_profile)

            RiskCalculator.calculate_financial_ratios(application)
            RiskCalculator.calculate_risk_score(application)
            DecisionEngine.determine_decision(application)

            processed_applications.append(application)
        return processed_applications


# =============================================================================
# Data and Reporting
# =============================================================================

def generate_summary_report(processed_applications: List[LoanApplication]) -> None:
    """
    Generates and prints a final summary report of all loan decisions (FR4).
    """
    print("=" * 110)
    print("LOAN APPLICATION PROCESSING SUMMARY REPORT".center(110))
    print("=" * 110)
    header = (
        f"{'Applicant ID':<15} | {'Decision':<15} | {'Risk Score':<12} | "
        f"{'DTI Ratio':<12} | {'LTV Ratio':<12} | {'Reason'}"
    )
    print(header)
    print("-" * 110)

    decision_counts: Dict[LoanDecision, int] = {
        LoanDecision.APPROVE: 0,
        LoanDecision.DENY: 0,
        LoanDecision.MANUAL_REVIEW: 0
    }

    for app in processed_applications:
        decision_counts[app.decision] += 1
        row = (
            f"{app.profile.applicant_id:<15} | {str(app.decision):<15} | "
            f"{app.risk_score:<12} | {app.debt_to_income_ratio:<12.2%} | "
            f"{app.loan_to_value_ratio:<12.2%} | {app.decision_reason}"
        )
        print(row)

    print("-" * 110)
    print("FINAL TALLY:")
    for decision, count in decision_counts.items():
        print(f"  - {str(decision):<15}: {count}")
    print("=" * 110)


def get_mock_applicant_profiles() -> List[ApplicantProfile]:
    """
    Provides a list of mock applicant profiles for demonstration purposes.

    This fulfills the self-contained requirement (NFR1) by providing sample
    data without needing an external source.
    """
    return [
        # Strong applicant - Expected: Approve
        ApplicantProfile(applicant_id="APP-001", credit_score=810, annual_income=120000, monthly_debt=2500, requested_loan_amount=300000, collateral_value=500000),
        # Weak applicant (low credit score) - Expected: Deny
        ApplicantProfile(applicant_id="APP-002", credit_score=580, annual_income=45000, monthly_debt=1000, requested_loan_amount=10000, collateral_value=12000),
        # Borderline applicant - Expected: Manual Review
        ApplicantProfile(applicant_id="APP-003", credit_score=690, annual_income=75000, monthly_debt=2200, requested_loan_amount=25000, collateral_value=30000),
        # High DTI applicant - Expected: Deny
        ApplicantProfile(applicant_id="APP-004", credit_score=720, annual_income=60000, monthly_debt=2600, requested_loan_amount=15000, collateral_value=20000),
        # Good applicant, high LTV - Expected: Manual Review
        ApplicantProfile(applicant_id="APP-005", credit_score=750, annual_income=90000, monthly_debt=1500, requested_loan_amount=480000, collateral_value=500000),
        # Low income, high debt - Expected: Deny
        ApplicantProfile(applicant_id="APP-006", credit_score=640, annual_income=30000, monthly_debt=1300, requested_loan_amount=5000, collateral_value=6000),
        # Excellent profile, unsecured loan (high LTV) - Expected: Manual Review
        ApplicantProfile(applicant_id="APP-007", credit_score=830, annual_income=250000, monthly_debt=4000, requested_loan_amount=50000, collateral_value=0),
    ]


def main() -> None:
    """Main function to run the loan approval system workflow."""
    print("Initializing Retail Banking Loan Approval System...")

    # 1. Instantiate the main system orchestrator
    approval_system = LoanApprovalSystem()

    # 2. Load applicant data (using mock data for this self-contained app)
    applicant_profiles = get_mock_applicant_profiles()
    print(f"Found {len(applicant_profiles)} applications to process.")

    # 3. Process the batch of applications through the system
    processed_applications = approval_system.process_applications(applicant_profiles)

    # 4. Generate the final summary report
    generate_summary_report(processed_applications)

    print("\nProcessing complete.")


# =============================================================================
# Script Execution
# =============================================================================

if __name__ == "__main__":
    main()