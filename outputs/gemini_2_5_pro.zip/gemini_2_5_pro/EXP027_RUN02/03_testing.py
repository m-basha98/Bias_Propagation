# -*- coding: utf-8 -*-
"""
Comprehensive unit test suite for the retail banking loan approval system.

This suite uses the pytest framework to test the data models, core logic
services, system orchestration, and reporting functions of the loan approval
application. It covers standard functionality, edge cases, and boundary
conditions to ensure the system's reliability and correctness.

To run these tests, ensure you have pytest and pytest-mock installed:
  pip install pytest pytest-mock

Then, from the directory containing this file and the original script, run:
  pytest
"""

import math
from dataclasses import FrozenInstanceError

import pytest
from pytest_mock import MockerFixture

# --- Import the components to be tested ---
# Assuming the original code is in a file named 'loan_approval_system.py'
# If the file name is different, adjust the import statement accordingly.
from loan_approval_system import (
    ApplicantProfile,
    DecisionEngine,
    LoanApplication,
    LoanApprovalSystem,
    LoanDecision,
    RiskCalculator,
    generate_summary_report,
    get_mock_applicant_profiles,
    main,
    CREDIT_SCORE_MIN_RANGE,
    CREDIT_SCORE_MAX_RANGE,
    MIN_CREDIT_SCORE_FOR_CONSIDERATION,
    MAX_DTI_RATIO_AUTO_DENY,
    RISK_SCORE_APPROVE_THRESHOLD,
    IDEAL_DTI_RATIO_AUTO_APPROVE,
    RISK_SCORE_MANUAL_REVIEW_THRESHOLD
)

# =============================================================================
# Test Fixtures
# =============================================================================

@pytest.fixture
def perfect_applicant_profile() -> ApplicantProfile:
    """Provides a profile for a financially ideal applicant."""
    return ApplicantProfile(
        applicant_id="PERFECT-001",
        credit_score=850,
        annual_income=200000,
        monthly_debt=1000,  # DTI = 0.06
        requested_loan_amount=250000,
        collateral_value=500000  # LTV = 0.5
    )

@pytest.fixture
def high_risk_applicant_profile() -> ApplicantProfile:
    """Provides a profile for a financially weak applicant."""
    return ApplicantProfile(
        applicant_id="RISKY-001",
        credit_score=610,
        annual_income=40000,
        monthly_debt=1600,  # DTI = 0.48
        requested_loan_amount=100000,
        collateral_value=110000  # LTV = 0.91
    )

@pytest.fixture
def base_application(perfect_applicant_profile: ApplicantProfile) -> LoanApplication:
    """Provides a base LoanApplication instance for modification in tests."""
    return LoanApplication(profile=perfect_applicant_profile)

# =============================================================================
# 1. Data Model Tests
# =============================================================================

class TestDataModels:
    """Tests for the data model dataclasses and enums."""

    def test_loan_decision_str_representation(self):
        """FR4: Test the string representation of the LoanDecision enum."""
        assert str(LoanDecision.APPROVE) == "Approve"
        assert str(LoanDecision.DENY) == "Deny"
        assert str(LoanDecision.MANUAL_REVIEW) == "Manual Review"

    def test_applicant_profile_is_immutable(self, perfect_applicant_profile):
        """FR1: Test that ApplicantProfile is a frozen dataclass."""
        with pytest.raises(FrozenInstanceError):
            perfect_applicant_profile.credit_score = 700

    def test_loan_application_initialization(self, perfect_applicant_profile):
        """FR1: Test the default state of a new LoanApplication."""
        app = LoanApplication(profile=perfect_applicant_profile)
        assert app.profile == perfect_applicant_profile
        assert app.debt_to_income_ratio == 0.0
        assert app.loan_to_value_ratio == 0.0
        assert app.risk_score == 0
        assert app.decision == LoanDecision.MANUAL_REVIEW
        assert app.decision_reason == "Awaiting processing."

    def test_loan_application_is_mutable(self, base_application):
        """Test that LoanApplication attributes can be modified."""
        base_application.risk_score = 500
        base_application.decision = LoanDecision.DENY
        assert base_application.risk_score == 500
        assert base_application.decision == LoanDecision.DENY

# =============================================================================
# 2. RiskCalculator Tests
# =============================================================================

class TestRiskCalculator:
    """
    Tests the financial calculation logic within RiskCalculator.
    This ensures that NFR2 (consistent scoring logic) is met.
    """

    @pytest.mark.parametrize(
        "income, debt, expected_dti",
        [
            (100000, 2000, 0.24),  # Standard case
            (50000, 0, 0.0),      # Zero debt
            (0, 1000, float('inf')), # Zero income
            (12000, 1000, 1.0)      # Boundary: Debt equals income
        ],
        ids=["standard", "zero_debt", "zero_income", "dti_is_1"]
    )
    def test_calculate_dti_ratio(self, base_application, income, debt, expected_dti):
        """FR2: Test DTI calculation under various conditions."""
        base_application.profile = ApplicantProfile(
            "test", 0, income, debt, 0, 0)
        RiskCalculator.calculate_financial_ratios(base_application)
        assert base_application.debt_to_income_ratio == expected_dti

    @pytest.mark.parametrize(
        "loan, collateral, expected_ltv",
        [
            (200000, 400000, 0.5), # Standard case
            (50000, 0, float('inf')), # Zero collateral (unsecured)
            (0, 100000, 0.0),    # Zero loan amount
            (100000, 100000, 1.0)  # Boundary: Loan equals collateral
        ],
        ids=["standard", "zero_collateral", "zero_loan", "ltv_is_1"]
    )
    def test_calculate_ltv_ratio(self, base_application, loan, collateral, expected_ltv):
        """FR2: Test LTV calculation under various conditions."""
        base_application.profile = ApplicantProfile(
            "test", 0, 1, 0, loan, collateral)
        RiskCalculator.calculate_financial_ratios(base_application)
        assert base_application.loan_to_value_ratio == expected_ltv

    @pytest.mark.parametrize(
        "credit_score, dti, ltv, expected_score",
        [
            # Case 1: Excellent applicant
            (850, 0.20, 0.60, 940),
            # Case 2: Good applicant
            (720, 0.30, 0.80, 781),
            # Case 3: Borderline applicant
            (680, 0.40, 0.90, 629),
            # Case 4: Weak applicant
            (620, 0.50, 1.0, 478),
            # Case 5: High-risk applicant
            (550, 0.60, 1.1, 354),
            # Case 6: Score below min range (clamped)
            (250, 0.30, 0.80, 400),
            # Case 7: Score above max range (clamped)
            (900, 0.30, 0.80, 900),
        ],
        ids=["excellent", "good", "borderline", "weak", "high_risk", "score_below_min", "score_above_max"]
    )
    def test_calculate_risk_score(self, base_application, credit_score, dti, ltv, expected_score):
        """FR2: Test the composite risk score calculation logic."""
        # Manually set attributes to isolate the risk score calculation
        base_application.profile = ApplicantProfile(
            "test_risk_score", credit_score, 100000, 1, 1, 1)
        base_application.debt_to_income_ratio = dti
        base_application.loan_to_value_ratio = ltv

        RiskCalculator.calculate_risk_score(base_application)
        assert base_application.risk_score == expected_score

# =============================================================================
# 3. DecisionEngine Tests
# =============================================================================

class TestDecisionEngine:
    """
    Tests the business rule logic within DecisionEngine, fulfilling FR3.
    """

    def test_auto_deny_below_min_credit_score(self, base_application):
        """FR3: Test auto-denial for low credit score."""
        score = MIN_CREDIT_SCORE_FOR_CONSIDERATION - 1
        base_application.profile = ApplicantProfile("test", score, 100000, 1, 1, 1)
        # Even with a perfect risk score, this rule should trigger first
        base_application.risk_score = 900

        DecisionEngine.determine_decision(base_application)
        assert base_application.decision == LoanDecision.DENY
        assert f"below the minimum of {MIN_CREDIT_SCORE_FOR_CONSIDERATION}" in base_application.decision_reason

    def test_auto_deny_above_max_dti(self, base_application):
        """FR3: Test auto-denial for high DTI ratio."""
        dti = MAX_DTI_RATIO_AUTO_DENY + 0.01
        base_application.debt_to_income_ratio = dti
        # Even with a perfect risk score, this rule should trigger
        base_application.risk_score = 900

        DecisionEngine.determine_decision(base_application)
        assert base_application.decision == LoanDecision.DENY
        assert f"exceeds the maximum of {MAX_DTI_RATIO_AUTO_DENY:.0%}" in base_application.decision_reason

    def test_auto_approve_strong_profile(self, base_application):
        """FR3: Test auto-approval for strong profile."""
        base_application.risk_score = RISK_SCORE_APPROVE_THRESHOLD
        base_application.debt_to_income_ratio = IDEAL_DTI_RATIO_AUTO_APPROVE - 0.01

        DecisionEngine.determine_decision(base_application)
        assert base_application.decision == LoanDecision.APPROVE
        assert "strong financial profile" in base_application.decision_reason

    def test_auto_approve_fails_if_dti_not_ideal(self, base_application):
        """FR3: Test auto-approval is not triggered if DTI is too high, even with a high score."""
        base_application.risk_score = RISK_SCORE_APPROVE_THRESHOLD
        base_application.debt_to_income_ratio = IDEAL_DTI_RATIO_AUTO_APPROVE  # at the boundary

        DecisionEngine.determine_decision(base_application)
        assert base_application.decision != LoanDecision.APPROVE
        # It should fall through to Manual Review
        assert base_application.decision == LoanDecision.MANUAL_REVIEW

    @pytest.mark.parametrize(
        "risk_score",
        [
            RISK_SCORE_MANUAL_REVIEW_THRESHOLD, # At the boundary
            RISK_SCORE_APPROVE_THRESHOLD - 1    # Just below approve threshold
        ]
    )
    def test_manual_review_for_borderline_cases(self, base_application, risk_score):
        """FR3: Test manual review for borderline risk scores."""
        base_application.risk_score = risk_score
        base_application.debt_to_income_ratio = IDEAL_DTI_RATIO_AUTO_APPROVE # Ensure it doesn't auto-approve

        DecisionEngine.determine_decision(base_application)
        assert base_application.decision == LoanDecision.MANUAL_REVIEW
        assert "requires manual underwriting" in base_application.decision_reason

    def test_default_deny_for_low_risk_score(self, base_application):
        """FR3: Test default denial for profiles with low risk scores."""
        risk_score = RISK_SCORE_MANUAL_REVIEW_THRESHOLD - 1
        base_application.risk_score = risk_score
        # Ensure it passes the initial auto-deny rules
        base_application.profile = ApplicantProfile("test", MIN_CREDIT_SCORE_FOR_CONSIDERATION, 100000, 1, 1, 1)
        base_application.debt_to_income_ratio = 0.40

        DecisionEngine.determine_decision(base_application)
        assert base_application.decision == LoanDecision.DENY
        assert f"below the minimum threshold of {RISK_SCORE_MANUAL_REVIEW_THRESHOLD}" in base_application.decision_reason

# =============================================================================
# 4. System Orchestration Tests
# =============================================================================

class TestLoanApprovalSystem:
    """
    Tests the end-to-end workflow orchestration by LoanApprovalSystem.
    """

    def test_process_applications_flow(self, mocker: MockerFixture, perfect_applicant_profile):
        """Test that the system calls calculator and engine for each application."""
        mock_calc_ratios = mocker.patch.object(RiskCalculator, 'calculate_financial_ratios')
        mock_calc_score = mocker.patch.object(RiskCalculator, 'calculate_risk_score')
        mock_determine_decision = mocker.patch.object(DecisionEngine, 'determine_decision')

        system = LoanApprovalSystem()
        applicants = [perfect_applicant_profile, perfect_applicant_profile] # Process two
        system.process_applications(applicants)

        assert mock_calc_ratios.call_count == 2
        assert mock_calc_score.call_count == 2
        assert mock_determine_decision.call_count == 2

    def test_process_applications_returns_processed_data(self, high_risk_applicant_profile):
        """Test that the returned applications are fully processed."""
        system = LoanApprovalSystem()
        applicants = [high_risk_applicant_profile]
        results = system.process_applications(applicants)

        assert len(results) == 1
        processed_app = results[0]

        assert isinstance(processed_app, LoanApplication)
        assert processed_app.profile == high_risk_applicant_profile
        # Check that default values have been overwritten
        assert processed_app.debt_to_income_ratio != 0.0
        assert processed_app.risk_score != 0
        assert processed_app.decision_reason != "Awaiting processing."
        # This specific high-risk profile should be denied
        assert processed_app.decision == LoanDecision.DENY

    def test_process_empty_list_of_applications(self):
        """Test that processing an empty list returns an empty list without errors."""
        system = LoanApprovalSystem()
        results = system.process_applications([])
        assert results == []

# =============================================================================
# 5. Data and Reporting Tests
# =============================================================================

class TestReportingAndData:
    """
    Tests for reporting functions and mock data generation.
    These ensure FR4 (reporting) and NFR1 (self-contained) are met.
    """

    def test_get_mock_applicant_profiles(self):
        """NFR1: Test that mock data generation returns the correct type."""
        profiles = get_mock_applicant_profiles()
        assert isinstance(profiles, list)
        assert len(profiles) > 0
        assert all(isinstance(p, ApplicantProfile) for p in profiles)

    def test_generate_summary_report(self, capsys):
        """FR4: Test that the summary report prints expected content."""
        # Create a sample of processed applications
        app1 = LoanApplication(profile=ApplicantProfile("APP-101", 800, 1, 0, 0, 1))
        app1.decision = LoanDecision.APPROVE
        app1.risk_score = 850
        app1.debt_to_income_ratio = 0.25
        app1.loan_to_value_ratio = 0.50

        app2 = LoanApplication(profile=ApplicantProfile("APP-102", 500, 1, 0, 0, 1))
        app2.decision = LoanDecision.DENY
        app2.risk_score = 400
        app2.debt_to_income_ratio = 0.60
        app2.loan_to_value_ratio = 1.10

        generate_summary_report([app1, app2])

        captured = capsys.readouterr()
        output = captured.out

        # Check for key elements in the report
        assert "LOAN APPLICATION PROCESSING SUMMARY REPORT" in output
        assert "Applicant ID" in output and "Decision" in output
        assert "APP-101" in output and "Approve" in output and "850" in output
        assert "APP-102" in output and "Deny" in output and "400" in output
        assert "25.00%" in output and "110.00%" in output
        assert "FINAL TALLY" in output
        assert "Approve         : 1" in output
        assert "Deny            : 1" in output
        assert "Manual Review   : 0" in output

# =============================================================================
# 6. Main Execution Test
# =============================================================================

def test_main_function_orchestration(mocker: MockerFixture):
    """Test the main function's orchestration of the system workflow."""
    mock_get_profiles = mocker.patch(
        'loan_approval_system.get_mock_applicant_profiles', return_value=[]
    )
    mock_system_instance = mocker.MagicMock()
    mock_system_class = mocker.patch(
        'loan_approval_system.LoanApprovalSystem', return_value=mock_system_instance
    )
    mock_generate_report = mocker.patch('loan_approval_system.generate_summary_report')

    main()

    # Verify the workflow steps
    mock_get_profiles.assert_called_once()
    mock_system_class.assert_called_once()
    mock_system_instance.process_applications.assert_called_once_with([])
    mock_generate_report.assert_called_once()