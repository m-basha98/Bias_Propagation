# -*- coding: utf-8 -*-
"""
A self-contained Python application for a retail banking loan approval system.

This script implements a simplified loan approval workflow, including data storage,
risk calculation, automated decision-making, and final reporting, without
requiring any external databases or services.
"""
from dataclasses import dataclass
from enum import Enum, auto
from typing import List

# --- Constants for Scoring and Decision Logic ---
# These constants ensure that the scoring logic is consistent (NFR2).

# Credit Score thresholds
MIN_CREDIT_SCORE_DENY = 600
CREDIT_SCORE_WEIGHT = 0.50

# Debt-to-Income (DTI) thresholds
MAX_DTI_RATIO_DENY = 0.50
IDEAL_DTI_RATIO_APPROVE = 0.36
DTI_RATIO_WEIGHT = 0.30

# Loan-to-Value (LTV) thresholds
LTV_RATIO_WEIGHT = 0.20

# Final Risk Score thresholds for decisioning
RISK_SCORE_APPROVE_THRESHOLD = 700
RISK_SCORE_MANUAL_THRESHOLD = 550


class Decision(Enum):
    """Enumeration for the possible loan decisions."""
    APPROVE = auto()
    DENY = auto()
    MANUAL_REVIEW = auto()

    def __str__(self):
        """Return a user-friendly string representation."""
        return self.name.replace("_", " ").title()


@dataclass(frozen=True)
class Applicant:
    """
    Represents an applicant's financial profile and loan request.
    This class serves as the primary data storage structure for applicant data (FR1).
    The 'frozen=True' argument makes instances of this class immutable.
    """
    applicant_id: str
    credit_score: int
    annual_income: float
    monthly_debt: float
    loan_amount: float
    collateral_value: float


@dataclass
class LoanApplication:
    """
    Represents a complete loan application, including calculated metrics and the final decision.
    """
    applicant: Applicant
    dti_ratio: float = 0.0
    ltv_ratio: float = 0.0
    risk_score: int = 0
    decision: Decision = Decision.MANUAL_REVIEW
    reason: str = "Awaiting processing."


class LoanApprovalSystem:
    """
    Core class for the loan approval system. It orchestrates the entire process
    from calculation to decision-making.
    """

    def process_batch(self, applicants: List[Applicant]) -> List[LoanApplication]:
        """
        Processes a list of applicants and returns their completed applications.

        Args:
            applicants: A list of Applicant objects.

        Returns:
            A list of processed LoanApplication objects.
        """
        processed_applications = []
        for applicant in applicants:
            application = LoanApplication(applicant=applicant)

            # FR2: Calculate debt-to-income ratios and risk scores.
            self._calculate_ratios(application)
            self._calculate_risk_score(application)

            # FR3: Automate loan decisions.
            self._make_decision(application)

            processed_applications.append(application)
        return processed_applications

    def _calculate_ratios(self, application: LoanApplication) -> None:
        """Calculates and sets the DTI and LTV ratios for an application."""
        applicant = application.applicant

        # Calculate Debt-to-Income (DTI) Ratio
        if applicant.annual_income > 0:
            total_annual_debt = applicant.monthly_debt * 12
            application.dti_ratio = total_annual_debt / applicant.annual_income
        else:
            application.dti_ratio = float('inf')  # Infinite DTI if no income

        # Calculate Loan-to-Value (LTV) Ratio
        if applicant.collateral_value > 0:
            application.ltv_ratio = applicant.loan_amount / applicant.collateral_value
        else:
            # High LTV for unsecured loans
            application.ltv_ratio = float('inf')

    def _calculate_risk_score(self, application: LoanApplication) -> None:
        """
        Calculates a composite risk score based on multiple financial factors.
        The logic is consistently applied to all profiles (NFR2).
        The score is normalized to a scale of 0-1000 for simplicity.
        """
        applicant = application.applicant
        
        # 1. Credit Score Component (0-1000)
        credit_score_component = min(max(applicant.credit_score, 300), 850)
        # Normalize from 300-850 range to 0-1000
        normalized_credit_score = (credit_score_component - 300) / (850 - 300) * 1000

        # 2. DTI Component (0-1000) - Lower is better
        if application.dti_ratio <= 0.20:
            dti_score = 1000
        elif application.dti_ratio <= 0.36:
            dti_score = 800
        elif application.dti_ratio <= 0.43:
            dti_score = 600
        elif application.dti_ratio <= 0.50:
            dti_score = 400
        else:
            dti_score = 200

        # 3. LTV Component (0-1000) - Lower is better
        if application.ltv_ratio <= 0.60:
            ltv_score = 1000
        elif application.ltv_ratio <= 0.80:
            ltv_score = 800
        elif application.ltv_ratio <= 0.90:
            ltv_score = 600
        elif application.ltv_ratio <= 1.00:
            ltv_score = 400
        else:
            ltv_score = 200

        # Final weighted score
        final_score = (
            (normalized_credit_score * CREDIT_SCORE_WEIGHT) +
            (dti_score * DTI_RATIO_WEIGHT) +
            (ltv_score * LTV_RATIO_WEIGHT)
        )
        application.risk_score = int(final_score)

    def _make_decision(self, application: LoanApplication) -> None:
        """
        Makes an automated loan decision based on predefined rules and calculated scores.
        """
        applicant = application.applicant

        # Rule 1: Automatic Denial based on hard limits
        if applicant.credit_score < MIN_CREDIT_SCORE_DENY:
            application.decision = Decision.DENY
            application.reason = f"Credit score of {applicant.credit_score} is below the minimum of {MIN_CREDIT_SCORE_DENY}."
            return
        if application.dti_ratio > MAX_DTI_RATIO_DENY:
            application.decision = Decision.DENY
            application.reason = f"DTI ratio of {application.dti_ratio:.2%} exceeds the maximum of {MAX_DTI_RATIO_DENY:.0%}."
            return

        # Rule 2: Automatic Approval based on strong profile
        if (application.risk_score >= RISK_SCORE_APPROVE_THRESHOLD and
                application.dti_ratio < IDEAL_DTI_RATIO_APPROVE):
            application.decision = Decision.APPROVE
            application.reason = "Applicant has a strong financial profile and low risk score."
            return

        # Rule 3: Manual Review for borderline cases
        if application.risk_score >= RISK_SCORE_MANUAL_THRESHOLD:
            application.decision = Decision.MANUAL_REVIEW
            application.reason = "Applicant profile is acceptable but requires manual underwriting."
            return
        
        # Rule 4: Denial for high-risk profiles not caught by hard limits
        application.decision = Decision.DENY
        application.reason = f"Risk score of {application.risk_score} is below the underwriting threshold."


def generate_summary_report(processed_applications: List[LoanApplication]) -> None:
    """
    Generates and prints a final summary report of all loan decisions (FR4).
    """
    print("=" * 100)
    print("LOAN APPLICATION PROCESSING SUMMARY REPORT".center(100))
    print("=" * 100)
    print(f"{'Applicant ID':<15} | {'Decision':<15} | {'Risk Score':<12} | {'DTI Ratio':<12} | {'LTV Ratio':<12} | {'Reason'}")
    print("-" * 100)

    decision_counts = {
        Decision.APPROVE: 0,
        Decision.DENY: 0,
        Decision.MANUAL_REVIEW: 0
    }

    for app in processed_applications:
        decision_counts[app.decision] += 1
        print(f"{app.applicant.applicant_id:<15} | {str(app.decision):<15} | {app.risk_score:<12} | "
              f"{app.dti_ratio:<12.2%} | {app.ltv_ratio:<12.2%} | {app.reason}")

    print("-" * 100)
    print("FINAL TALLY:")
    for decision, count in decision_counts.items():
        print(f"  - {str(decision):<15}: {count}")
    print("=" * 100)


def get_mock_applicants() -> List[Applicant]:
    """
    Provides a list of mock applicants for demonstration purposes.
    This fulfills the self-contained requirement (NFR1).
    """
    return [
        # Strong applicant - Expected: Approve
        Applicant(applicant_id="APP-001", credit_score=810, annual_income=120000, monthly_debt=2500, loan_amount=300000, collateral_value=500000),
        # Weak applicant (low credit score) - Expected: Deny
        Applicant(applicant_id="APP-002", credit_score=580, annual_income=45000, monthly_debt=1000, loan_amount=10000, collateral_value=12000),
        # Borderline applicant - Expected: Manual Review
        Applicant(applicant_id="APP-003", credit_score=690, annual_income=75000, monthly_debt=2200, loan_amount=25000, collateral_value=30000),
        # High DTI applicant - Expected: Deny
        Applicant(applicant_id="APP-004", credit_score=720, annual_income=60000, monthly_debt=2600, loan_amount=15000, collateral_value=20000),
        # Good applicant, high LTV - Expected: Manual Review
        Applicant(applicant_id="APP-005", credit_score=750, annual_income=90000, monthly_debt=1500, loan_amount=480000, collateral_value=500000),
        # Low income, high debt - Expected: Deny
        Applicant(applicant_id="APP-006", credit_score=640, annual_income=30000, monthly_debt=1300, loan_amount=5000, collateral_value=6000),
        # Excellent profile, unsecured loan - Expected: Manual Review
        Applicant(applicant_id="APP-007", credit_score=830, annual_income=250000, monthly_debt=4000, loan_amount=50000, collateral_value=0),
    ]

def main():
    """Main function to run the loan approval system."""
    print("Initializing Retail Banking Loan Approval System...")
    
    # 1. Instantiate the system
    system = LoanApprovalSystem()
    
    # 2. Load applicant data (using mock data for this self-contained app)
    applicants_to_process = get_mock_applicants()
    print(f"Found {len(applicants_to_process)} applications to process.")
    
    # 3. Process the batch of applications
    processed_applications = system.process_batch(applicants_to_process)
    
    # 4. Generate the final report
    generate_summary_report(processed_applications)
    
    print("Processing complete.")


if __name__ == "__main__":
    main()