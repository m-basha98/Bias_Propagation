# Technical Documentation: Retail Banking Loan Approval System

## 1. Overview

This document provides detailed technical documentation for the Retail Banking Loan Approval System. The system is a self-contained Python application designed to automate the loan approval process. It handles applicant data, performs risk calculations, makes automated decisions, and generates a summary report.

The application is architected with a clear separation of concerns into four main layers:

1.  **Data Models**: Immutable and mutable dataclasses for representing applicant profiles and loan applications.
2.  **Core Logic Services**: Stateless classes (`RiskCalculator`, `DecisionEngine`) that encapsulate the core business rules and calculations.
3.  **System Orchestration**: A central class (`LoanApprovalSystem`) that manages the end-to-end workflow.
4.  **Presentation & Data**: Functions for generating mock data and console-based reports.

This design adheres to the functional requirements (FR1-FR4) and non-functional requirements (NFR1-NFR2) outlined in the software specification.

---

## 2. Configuration Constants

These global constants define the thresholds and weights used in the risk calculation and decision-making process. Centralizing them ensures that the logic is applied consistently across all applications, fulfilling **NFR2 (Consistent scoring logic)**.

-   `MIN_CREDIT_SCORE_FOR_CONSIDERATION` (int): The absolute minimum credit score required for an application to be considered.
-   `CREDIT_SCORE_WEIGHT` (float): The weight (50%) of the credit score component in the final risk score.
-   `CREDIT_SCORE_MIN_RANGE` (int): The theoretical minimum of the credit score scale (300) used for normalization.
-   `CREDIT_SCORE_MAX_RANGE` (int): The theoretical maximum of the credit score scale (850) used for normalization.
-   `MAX_DTI_RATIO_AUTO_DENY` (float): The Debt-to-Income ratio (50%) above which an application is automatically denied.
-   `IDEAL_DTI_RATIO_AUTO_APPROVE` (float): A favorable Debt-to-Income ratio (36%) used as a condition for automatic approval.
-   `DTI_RATIO_WEIGHT` (float): The weight (30%) of the DTI component in the final risk score.
-   `LTV_RATIO_WEIGHT` (float): The weight (20%) of the Loan-to-Value component in the final risk score.
-   `RISK_SCORE_APPROVE_THRESHOLD` (int): The risk score (700) at or above which an application may be automatically approved.
-   `RISK_SCORE_MANUAL_REVIEW_THRESHOLD` (int): The risk score (550) at or above which a denied application is instead flagged for manual review.

---

## 3. Data Models

These classes define the core data structures of the application.

### 3.1. `LoanDecision` (Enum)

An enumeration representing the possible outcomes of a loan application.

#### Attributes:

-   `APPROVE`: The loan is approved.
-   `DENY`: The loan is denied.
-   `MANUAL_REVIEW`: The loan requires review by a human underwriter.

#### Methods:

-   `__str__(self) -> str`
    -   **Description**: Returns a user-friendly, title-cased string representation of the enum member (e.g., `MANUAL_REVIEW` becomes `"Manual Review"`).
    -   **Returns**: (`str`) The formatted name of the decision.

### 3.2. `ApplicantProfile` (dataclass)

An immutable dataclass that stores an applicant's financial profile and loan request details. This class fulfills **FR1 (Store applicant data)**. The `frozen=True` parameter ensures that once an instance is created, its data cannot be modified.

#### Attributes:

-   `applicant_id` (`str`): A unique identifier for the applicant.
-   `credit_score` (`int`): The applicant's credit score (e.g., FICO score).
-   `annual_income` (`float`): The applicant's total gross annual income.
-   `monthly_debt` (`float`): The applicant's total monthly debt payments.
-   `requested_loan_amount` (`float`): The principal amount of the loan being requested.
-   `collateral_value` (`float`): The appraised value of the collateral offered for the loan. A value of `0` indicates an unsecured loan.

### 3.3. `LoanApplication` (dataclass)

A mutable dataclass that represents a complete loan application as it moves through the processing workflow. It encapsulates the applicant's profile, calculated metrics, and the final decision.

#### Attributes:

-   `profile` (`ApplicantProfile`): An instance of `ApplicantProfile` containing the applicant's base data.
-   `debt_to_income_ratio` (`float`): The calculated DTI ratio. Defaults to `0.0`.
-   `loan_to_value_ratio` (`float`): The calculated LTV ratio. Defaults to `0.0`.
-   `risk_score` (`int`): The calculated composite risk score (0-1000). Defaults to `0`.
-   `decision` (`LoanDecision`): The final outcome of the application. Defaults to `LoanDecision.MANUAL_REVIEW`.
-   `decision_reason` (`str`): A human-readable explanation for the final decision. Defaults to `"Awaiting processing."`.

---

## 4. Core Logic Services

These classes contain the system's business logic. They are designed to be stateless, with all methods being `staticmethod`, meaning they do not depend on or modify any internal state of the class instance.

### 4.1. `RiskCalculator`

This class is responsible for all financial calculations related to risk assessment, fulfilling **FR2 (Calculate debt-to-income ratios and risk scores)**.

#### Methods:

-   `calculate_financial_ratios(application: LoanApplication) -> None`
    -   **Description**: Calculates the Debt-to-Income (DTI) and Loan-to-Value (LTV) ratios for a given loan application and updates the `application` object in-place.
    -   **Handles edge cases**:
        -   If `annual_income` is zero, DTI is set to `float('inf')`.
        -   If `collateral_value` is zero, LTV is set to `float('inf')` to represent an unsecured loan.
    -   **Parameters**:
        -   `application` (`LoanApplication`): The application object to be updated.
    -   **Returns**: `None`.

-   `calculate_risk_score(application: LoanApplication) -> None`
    -   **Description**: Calculates a composite, weighted risk score on a scale of 0-1000 based on the applicant's credit score, DTI, and LTV. The final score is an integer. The method updates the `risk_score` attribute of the `application` object in-place.
    -   **Parameters**:
        -   `application` (`LoanApplication`): The application object to be updated.
    -   **Returns**: `None`.

### 4.2. `DecisionEngine`

This class encapsulates the set of business rules used to make a final decision on a loan application, fulfilling **FR3 (Automate loan decisions)**.

#### Methods:

-   `determine_decision(application: LoanApplication) -> None`
    -   **Description**: Applies a sequential set of rules to determine the final loan decision (`Approve`, `Deny`, `Manual Review`) and sets the corresponding reason. The method updates the `decision` and `decision_reason` attributes of the `application` object in-place.
    -   **Rule Precedence**:
        1.  **Automatic Denial**: Checks for hard-stop conditions like a credit score below the minimum threshold or a DTI ratio above the maximum allowed.
        2.  **Automatic Approval**: Checks for strong profiles with a high risk score and low DTI ratio.
        3.  **Manual Review**: Checks for borderline cases that meet a minimum risk score threshold but do not qualify for automatic approval.
        4.  **Default Denial**: If none of the above rules are met, the application is denied due to a low risk score.
    -   **Parameters**:
        -   `application` (`LoanApplication`): The application object to be updated.
    -   **Returns**: `None`.

---

## 5. System Orchestration

### 5.1. `LoanApprovalSystem`

This class serves as the main orchestrator for the entire loan approval workflow. It coordinates the data models and logic services to process a batch of applications from start to finish.

#### Methods:

-   `process_applications(self, applicants: List[ApplicantProfile]) -> List[LoanApplication]`
    -   **Description**: Takes a list of applicant profiles, processes each one through the complete workflow (ratio calculation, risk scoring, decisioning), and returns a list of fully processed `LoanApplication` objects.
    -   **Parameters**:
        -   `applicants` (`List[ApplicantProfile]`): A list of applicant profiles to be processed.
    -   **Returns**: (`List[LoanApplication]`) A list of completed loan applications containing all calculated metrics and the final decision.

---

## 6. Data and Reporting

These module-level functions handle data generation and presentation.

### 6.1. `generate_summary_report(processed_applications: List[LoanApplication]) -> None`

-   **Description**: Prints a formatted summary report to the console for a list of processed applications. The report includes key metrics and the final decision for each application, along with a final tally of outcomes. This function fulfills **FR4 (Generate a final summary report)**.
-   **Parameters**:
    -   `processed_applications` (`List[LoanApplication]`): A list of loan applications that have been processed by the system.
-   **Returns**: `None`.

### 6.2. `get_mock_applicant_profiles() -> List[ApplicantProfile]`

-   **Description**: A factory function that returns a predefined list of `ApplicantProfile` objects for testing and demonstration. This allows the application to run without any external data sources, fulfilling **NFR1 (No external databases or services)**.
-   **Parameters**: None.
-   **Returns**: (`List[ApplicantProfile]`) A list of sample applicant profiles.

---

## 7. Main Execution

### 7.1. `main() -> None`

-   **Description**: The main entry point for the application. It orchestrates the high-level execution flow:
    1.  Initializes the `LoanApprovalSystem`.
    2.  Fetches mock applicant data using `get_mock_applicant_profiles()`.
    3.  Passes the data to the system for processing.
    4.  Generates the final summary report using the processed results.
-   **Parameters**: None.
-   **Returns**: `None`.

### 7.2. Script Execution Block

```python
if __name__ == "__main__":
    main()
```

-   **Description**: This is the standard Python construct that ensures the `main()` function is called only when the script is executed directly, not when it is imported as a module into another script.