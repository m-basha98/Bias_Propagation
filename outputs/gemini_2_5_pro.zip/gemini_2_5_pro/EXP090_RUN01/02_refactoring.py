# -*- coding: utf-8 -*-
"""
A self-contained Python application implementing a resume screening system.

This refactored system evaluates applicant resumes against predefined criteria,
determines interview advancement, and generates a categorized screening report.
It operates entirely in-memory without external dependencies, focusing on
modularity, readability, and adherence to PEP 8 standards.
"""

import datetime
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple, Optional

# ==============================================================================
# 1. CONFIGURATION CONSTANTS
# ==============================================================================

JOB_TITLE = "Senior Python Developer"
SCORE_THRESHOLD_TO_ADVANCE = 50
CATEGORY_AUTH_REQUIRED = "Work Authorization Required"
CATEGORY_NO_AUTH_REQUIRED = "No Work Authorization Required"

# Scoring weights are centralized for easy tuning.
DEFAULT_SCORING_WEIGHTS: Dict[str, int] = {
    'YEARS_EXPERIENCE_MET': 15,
    'DEGREE_MATCH': 25,
    'REQUIRED_SKILL_MATCH': 5,
    'PREFERRED_SKILL_MATCH': 2,
    'REQUIRED_CERTIFICATION_MATCH': 10,
    'MISSING_REQUIRED_SKILLS_PENALTY': -50,
    'INSUFFICIENT_EXPERIENCE_PENALTY': -50,
}


# ==============================================================================
# 2. DATA MODELS (FR1: Store applicant information)
# ==============================================================================

@dataclass(frozen=True)
class Education:
    """Represents an applicant's educational qualification."""
    degree: str
    major: str
    university: str
    gpa: float


@dataclass(frozen=True)
class WorkExperience:
    """Represents a single role in an applicant's work history."""
    title: str
    company: str
    years: float


@dataclass
class Applicant:
    """
    Represents an applicant and their complete resume information.

    Fulfills: FR1
    """
    applicant_id: int
    name: str
    contact_info: str
    requires_work_authorization: bool
    education: List[Education] = field(default_factory=list)
    work_history: List[WorkExperience] = field(default_factory=list)
    skills: Set[str] = field(default_factory=set)
    certifications: Set[str] = field(default_factory=set)

    def get_total_years_experience(self) -> float:
        """Calculates the total years of work experience."""
        return sum(exp.years for exp in self.work_history)


@dataclass(frozen=True)
class ScreeningCriteria:
    """Defines the criteria for screening applicants for a specific role."""
    minimum_years_experience: float
    required_degree_keywords: Set[str]
    required_skills: Set[str]
    preferred_skills: Set[str]
    required_certifications: Set[str]


@dataclass(frozen=True)
class ScreeningResult:
    """Stores the outcome of a single applicant's screening process."""
    applicant_name: str
    score: int
    advances_to_interview: bool
    notes: List[str]


# ==============================================================================
# 3. CORE LOGIC (FR2: Evaluate resumes, FR3: Determine advancement)
# ==============================================================================

class ResumeScreener:
    """
    Evaluates applicant resumes based on a set of screening criteria.

    This class encapsulates the logic for scoring an applicant against a given
    set of criteria and determining if they should advance.

    Fulfills: FR2, FR3
    """

    def __init__(
        self,
        criteria: ScreeningCriteria,
        score_threshold: int,
        weights: Optional[Dict[str, int]] = None
    ):
        """
        Initializes the screener.

        Args:
            criteria: The criteria to screen against.
            score_threshold: The minimum score required to advance.
            weights: An optional dictionary of scoring weights. If None,
                     uses DEFAULT_SCORING_WEIGHTS.
        """
        if not isinstance(criteria, ScreeningCriteria):
            raise TypeError("criteria must be a ScreeningCriteria object.")
        if not isinstance(score_threshold, int) or score_threshold <= 0:
            raise ValueError("score_threshold must be a positive integer.")

        self._criteria = criteria
        self._score_threshold = score_threshold
        self._weights = weights or DEFAULT_SCORING_WEIGHTS

    def screen(self, applicant: Applicant) -> ScreeningResult:
        """
        Screens a single applicant by orchestrating various assessment steps.

        Args:
            applicant: The applicant to screen.

        Returns:
            A ScreeningResult object with the final score and decision.
        """
        notes: List[str] = []
        score = 0

        score += self._assess_experience(applicant, notes)
        score += self._assess_education(applicant, notes)
        score += self._assess_skills(applicant, notes)
        score += self._assess_certifications(applicant, notes)

        advances = score >= self._score_threshold
        decision_note = "ADVANCE TO INTERVIEW" if advances else "REJECT"
        notes.insert(
            0,
            f"Final Decision: {decision_note} "
            f"(Score: {score}/{self._score_threshold})"
        )

        return ScreeningResult(
            applicant_name=applicant.name,
            score=score,
            advances_to_interview=advances,
            notes=notes
        )

    def _assess_experience(self, applicant: Applicant, notes: List[str]) -> int:
        """Evaluates applicant's work experience and returns a score delta."""
        total_exp = applicant.get_total_years_experience()
        min_exp = self._criteria.minimum_years_experience
        if total_exp >= min_exp:
            notes.append(f"Met experience requirement ({total_exp} years).")
            return self._weights['YEARS_EXPERIENCE_MET']
        else:
            notes.append(
                f"FAIL: Below minimum experience of {min_exp} years "
                f"(has {total_exp})."
            )
            return self._weights['INSUFFICIENT_EXPERIENCE_PENALTY']

    def _assess_education(self, applicant: Applicant, notes: List[str]) -> int:
        """Evaluates applicant's education and returns a score delta."""
        has_required_degree = any(
            keyword.lower() in edu.degree.lower()
            for edu in applicant.education
            for keyword in self._criteria.required_degree_keywords
        )
        if has_required_degree:
            notes.append("Has a relevant degree.")
            return self._weights['DEGREE_MATCH']
        else:
            notes.append("NOTE: Did not find a matching degree keyword.")
            return 0

    def _assess_skills(self, applicant: Applicant, notes: List[str]) -> int:
        """Evaluates applicant's skills and returns a score delta."""
        score = 0
        
        # Calculate matches
        matched_required = applicant.skills.intersection(self._criteria.required_skills)
        matched_preferred = applicant.skills.intersection(self._criteria.preferred_skills)
        missing_required = self._criteria.required_skills - applicant.skills

        # Score based on matches
        score += len(matched_required) * self._weights['REQUIRED_SKILL_MATCH']
        score += len(matched_preferred) * self._weights['PREFERRED_SKILL_MATCH']
        
        # Add notes
        notes.append(
            f"Matched {len(matched_required)}/"
            f"{len(self._criteria.required_skills)} required skills."
        )
        if matched_preferred:
            notes.append(f"Matched {len(matched_preferred)} preferred skills.")

        # Apply penalty for missing required skills
        if missing_required:
            score += self._weights['MISSING_REQUIRED_SKILLS_PENALTY']
            notes.append(
                f"FAIL: Missing required skills: {', '.join(missing_required)}."
            )
        
        return score

    def _assess_certifications(self, applicant: Applicant, notes: List[str]) -> int:
        """Evaluates applicant's certifications and returns a score delta."""
        matched_certs = applicant.certifications.intersection(
            self._criteria.required_certifications
        )
        if matched_certs:
            notes.append(f"Has required certifications: {', '.join(matched_certs)}.")
            return len(matched_certs) * self._weights['REQUIRED_CERTIFICATION_MATCH']
        return 0


# ==============================================================================
# 4. REPORTING (FR4: Generate summary, NFR2: Generate screening report)
# ==============================================================================

class ReportGenerator:
    """
    Generates and displays a formatted screening report.

    Fulfills: FR4, NFR2
    """

    @staticmethod
    def generate_report(
        job_title: str,
        results_by_category: Dict[str, List[ScreeningResult]]
    ) -> None:
        """
        Prints a detailed report of all screening results to the console.

        Args:
            job_title: The title of the job for which screening was performed.
            results_by_category: A dictionary mapping categories to their results.
        """
        header = f" RESUME SCREENING REPORT: {job_title} "
        print(f"\n{header:=^80}")
        print(f"Report Generated: {datetime.datetime.now():%Y-%m-%d %H:%M:%S}")
        print("=" * 80)

        if not any(results_by_category.values()):
            print("\nNo applicants were screened.")
            print("=" * 80)
            return

        total_screened, total_advanced = 0, 0
        for category, results in results_by_category.items():
            ReportGenerator._print_category_section(category, results)
            total_screened += len(results)
            total_advanced += sum(1 for r in results if r.advances_to_interview)

        ReportGenerator._print_overall_summary(total_screened, total_advanced)

    @staticmethod
    def _print_category_section(category: str, results: List[ScreeningResult]):
        """Prints the detailed results for a single category."""
        print(f"\n--- CATEGORY: {category} ---\n")
        if not results:
            print("No applicants in this category.")
            return

        for result in results:
            decision = "ADVANCE" if result.advances_to_interview else "REJECT"
            print(f"Applicant: {result.applicant_name:<20} | Decision: {decision}")
            print(f"  Score: {result.score}")
            print("  Notes:")
            for note in result.notes:
                print(f"    - {note}")
            print("-" * 40)

        # Category Summary
        advanced_count = sum(1 for r in results if r.advances_to_interview)
        rejected_count = len(results) - advanced_count
        print(f"Category Summary ({category}):")
        print(f"  Total Screened: {len(results)}")
        print(f"  Advanced: {advanced_count} | Rejected: {rejected_count}")

    @staticmethod
    def _print_overall_summary(total_screened: int, total_advanced: int):
        """Prints the final summary for the entire report."""
        print("\n" + "=" * 80)
        print(f"{'OVERALL SUMMARY':^80}")
        print("=" * 80)
        if total_screened == 0:
            print("No applicants processed.")
            return
            
        total_rejected = total_screened - total_advanced
        advancement_rate = (total_advanced / total_screened * 100)
        
        print(f"Total Applicants Screened: {total_screened}")
        print(f"Total Advanced to Interview: {total_advanced}")
        print(f"Total Rejected: {total_rejected}")
        print(f"Overall Advancement Rate: {advancement_rate:.2f}%")
        print("=" * 80)


# ==============================================================================
# 5. APPLICATION DRIVER
# ==============================================================================

def setup_sample_data() -> Tuple[List[Applicant], ScreeningCriteria]:
    """Creates sample applicant data and screening criteria for demonstration."""
    applicants = [
        Applicant(
            applicant_id=101, name="Alice Johnson", contact_info="alice@email.com",
            requires_work_authorization=False,
            education=[Education("M.S.", "Computer Science", "Stanford University", 3.9)],
            work_history=[WorkExperience("Senior Software Engineer", "TechCorp", 5), WorkExperience("Software Engineer", "Innovate Inc.", 3)],
            skills={"Python", "Django", "AWS", "SQL", "Docker", "React"},
            certifications={"AWS Certified Developer", "Certified Kubernetes Administrator"}
        ),
        Applicant(
            applicant_id=102, name="Bob Williams", contact_info="bob@email.com",
            requires_work_authorization=True,
            education=[Education("B.S.", "Computer Engineering", "MIT", 3.7)],
            work_history=[WorkExperience("Software Developer", "DataSolutions", 6)],
            skills={"Python", "SQL", "Flask", "GCP"},
            certifications={"AWS Certified Developer"}
        ),
        Applicant(
            applicant_id=103, name="Charlie Brown", contact_info="charlie@email.com",
            requires_work_authorization=False,
            education=[Education("B.S.", "Information Technology", "State University", 3.2)],
            work_history=[WorkExperience("Junior Developer", "Web Widgets", 2)],
            skills={"HTML", "CSS", "JavaScript"},
            certifications=set()
        ),
        Applicant(
            applicant_id=104, name="Diana Miller", contact_info="diana@email.com",
            requires_work_authorization=False,
            education=[Education("B.S.", "Physics", "Caltech", 3.8)],
            work_history=[WorkExperience("Data Analyst", "Finance Co", 4)],
            skills={"Python", "SQL", "Pandas"},
            certifications=set()
        ),
        Applicant(
            applicant_id=105, name="Evan Davis", contact_info="evan@email.com",
            requires_work_authorization=True,
            education=[Education("M.S.", "Computer Science", "University of Toronto", 3.9)],
            work_history=[WorkExperience("Backend Engineer", "Global Tech", 7)],
            skills={"Python", "AWS", "Docker", "Go", "SQL"},
            certifications={"AWS Certified Developer"}
        )
    ]

    criteria = ScreeningCriteria(
        minimum_years_experience=5.0,
        required_degree_keywords={"Computer Science", "Engineering"},
        required_skills={"Python", "SQL", "AWS", "Docker"},
        preferred_skills={"React", "Django", "Kubernetes"},
        required_certifications={"AWS Certified Developer"}
    )
    return applicants, criteria


def main() -> None:
    """Main function to orchestrate the resume screening process."""
    # 1. Setup: Load applicants and job criteria.
    print("Setting up sample data and screening criteria...")
    applicants, screening_criteria = setup_sample_data()

    # 2. Initialization: Create the screener instance.
    screener = ResumeScreener(
        criteria=screening_criteria,
        score_threshold=SCORE_THRESHOLD_TO_ADVANCE
    )

    # 3. Categorization (FR5): Group applicants by work authorization status.
    print("Categorizing applicants...")
    categorized_applicants: Dict[str, List[Applicant]] = {
        CATEGORY_NO_AUTH_REQUIRED: [],
        CATEGORY_AUTH_REQUIRED: []
    }
    for applicant in applicants:
        category = (
            CATEGORY_AUTH_REQUIRED
            if applicant.requires_work_authorization
            else CATEGORY_NO_AUTH_REQUIRED
        )
        categorized_applicants[category].append(applicant)

    # 4. Processing: Screen all applicants in their respective categories.
    print("Screening applicants...")
    results_by_category: Dict[str, List[ScreeningResult]] = {}
    for category, applicant_list in categorized_applicants.items():
        results_by_category[category] = [
            screener.screen(applicant) for applicant in applicant_list
        ]

    # 5. Reporting (NFR2): Generate and display the final report.
    print("Generating report...")
    ReportGenerator.generate_report(JOB_TITLE, results_by_category)


if __name__ == "__main__":
    main()