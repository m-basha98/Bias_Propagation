# Technical Documentation: Resume Screening System

This document provides a detailed technical overview of the self-contained Resume Screening System. It covers the architecture, data models, core logic, and functionality of each component in the application.

## 1. Module Overview

The `resume_screening_system` module is a self-contained Python application designed to automate the initial stages of a hiring process. It evaluates applicant resumes against a predefined set of criteria for a specific job role, calculates a score for each applicant, determines if they should advance to the interview stage, and generates a comprehensive report summarizing the results.

The system is designed to be modular and operate entirely in-memory, fulfilling the non-functional requirement of having no external database or service dependencies.

---

## 2. Configuration Constants

These global constants provide centralized configuration for the application, making it easy to tune the screening parameters without modifying the core logic.

-   **`JOB_TITLE`**: `str`
    -   The title of the job for which applicants are being screened. Used for report headers.
-   **`SCORE_THRESHOLD_TO_ADVANCE`**: `int`
    -   The minimum score an applicant must achieve to be recommended for an interview.
-   **`CATEGORY_AUTH_REQUIRED`**: `str`
    -   A string constant representing the reporting category for applicants who require work authorization.
-   **`CATEGORY_NO_AUTH_REQUIRED`**: `str`
    -   A string constant representing the reporting category for applicants who do not require work authorization.
-   **`DEFAULT_SCORING_WEIGHTS`**: `Dict[str, int]`
    -   A dictionary that defines the points awarded or deducted for various criteria. This allows for flexible and easily adjustable scoring logic. Keys include:
        -   `YEARS_EXPERIENCE_MET`: Points for meeting the minimum years of experience.
        -   `DEGREE_MATCH`: Points for having a relevant degree.
        -   `REQUIRED_SKILL_MATCH`: Points awarded per matched required skill.
        -   `PREFERRED_SKILL_MATCH`: Points awarded per matched preferred skill.
        -   `REQUIRED_CERTIFICATION_MATCH`: Points awarded per matched required certification.
        -   `MISSING_REQUIRED_SKILLS_PENALTY`: A significant penalty for not possessing all required skills.
        -   `INSUFFICIENT_EXPERIENCE_PENALTY`: A significant penalty for not meeting the minimum years of experience.

---

## 3. Data Models

The system uses `dataclasses` to create simple, immutable (where appropriate), and self-documenting data structures for representing entities within the application.

### `Education`

Represents an applicant's educational qualification.

-   **`degree`**: `str` - The type of degree obtained (e.g., "M.S.", "B.S.").
-   **`major`**: `str` - The field of study (e.g., "Computer Science").
-   **`university`**: `str` - The name of the institution.
-   **`gpa`**: `float` - The Grade Point Average.

### `WorkExperience`

Represents a single role in an applicant's work history.

-   **`title`**: `str` - The job title for the role (e.g., "Senior Software Engineer").
-   **`company`**: `str` - The name of the employer.
-   **`years`**: `float` - The duration of employment in this role, in years.

### `Applicant`

Represents a job applicant and their complete resume information. This class is mutable to allow for dynamic creation.

-   **`applicant_id`**: `int` - A unique identifier for the applicant.
-   **`name`**: `str` - The full name of the applicant.
-   **`contact_info`**: `str` - Contact details (e.g., email or phone number).
-   **`requires_work_authorization`**: `bool` - A flag indicating if the applicant needs sponsorship or work authorization.
-   **`education`**: `List[Education]` - A list of the applicant's educational qualifications.
-   **`work_history`**: `List[WorkExperience]` - A list of the applicant's previous jobs.
-   **`skills`**: `Set[str]` - A set of the applicant's skills.
-   **`certifications`**: `Set[str]` - A set of the applicant's professional certifications.

#### Method: `get_total_years_experience()`

Calculates the cumulative years of work experience from the applicant's work history.

-   **Parameters**: None.
-   **Returns**: `float` - The total number of years of experience.

### `ScreeningCriteria`

Defines the criteria for screening applicants for a specific role. This is an immutable dataclass.

-   **`minimum_years_experience`**: `float` - The minimum required years of professional experience.
-   **`required_degree_keywords`**: `Set[str]` - A set of keywords to search for in an applicant's degree title (e.g., "Computer Science", "Engineering").
-   **`required_skills`**: `Set[str]` - A set of skills that are mandatory for the role.
-   **`preferred_skills`**: `Set[str]` - A set of skills that are desirable but not mandatory.
-   **`required_certifications`**: `Set[str]` - A set of professional certifications required for the role.

### `ScreeningResult`

Stores the outcome of a single applicant's screening process. This is an immutable dataclass.

-   **`applicant_name`**: `str` - The name of the applicant.
-   **`score`**: `int` - The final calculated score.
-   **`advances_to_interview`**: `bool` - `True` if the applicant's score meets or exceeds the threshold, `False` otherwise.
-   **`notes`**: `List[str]` - A list of detailed notes generated during the screening process, explaining the scoring decisions.

---

## 4. Core Logic: `ResumeScreener` Class

This class encapsulates the primary business logic for evaluating an applicant against the defined `ScreeningCriteria`.

### `__init__(self, criteria, score_threshold, weights=None)`

Initializes a new `ResumeScreener` instance.

-   **Parameters**:
    -   `criteria` (`ScreeningCriteria`): The criteria object to screen against.
    -   `score_threshold` (`int`): The minimum score required to advance.
    -   `weights` (`Optional[Dict[str, int]]`): An optional dictionary of scoring weights. If not provided, it defaults to `DEFAULT_SCORING_WEIGHTS`.
-   **Raises**:
    -   `TypeError`: If `criteria` is not a `ScreeningCriteria` object.
    -   `ValueError`: If `score_threshold` is not a positive integer.

### `screen(self, applicant)`

Orchestrates the screening process for a single applicant by calling various private assessment methods. It aggregates scores and notes to produce a final `ScreeningResult`.

-   **Parameters**:
    -   `applicant` (`Applicant`): The applicant object to be screened.
-   **Returns**: `ScreeningResult` - An object containing the applicant's final score, interview decision, and detailed evaluation notes.

### Private Assessment Methods

These helper methods are responsible for evaluating specific sections of an applicant's profile. Each method takes the `applicant` and a `notes` list as input, appends its findings to the notes list, and returns an integer score delta.

#### `_assess_experience(self, applicant, notes)`

Evaluates the applicant's total work experience against the minimum requirement.

-   **Returns**: `int` - A positive score from the weights if the requirement is met, or a penalty score if it is not.

#### `_assess_education(self, applicant, notes)`

Checks if the applicant's education matches any of the required degree keywords.

-   **Returns**: `int` - A positive score if a matching degree is found, otherwise 0.

#### `_assess_skills(self, applicant, notes)`

Evaluates the applicant's skills, scoring required and preferred skills separately and applying a large penalty if any required skills are missing.

-   **Returns**: `int` - The combined score from matched skills, potentially offset by a penalty for missing required skills.

#### `_assess_certifications(self, applicant, notes)`

Checks for and scores any required certifications held by the applicant.

-   **Returns**: `int` - A score based on the number of matched required certifications multiplied by the corresponding weight. Returns 0 if no required certifications are found.

---

## 5. Reporting: `ReportGenerator` Class

This class provides static methods for generating and displaying a formatted screening report to the console. It is designed to be stateless.

### `generate_report(job_title, results_by_category)` (static method)

The main public method that generates and prints the full screening report. It includes a header, a timestamp, detailed results for each category, and an overall summary.

-   **Parameters**:
    -   `job_title` (`str`): The job title for the report header.
    -   `results_by_category` (`Dict[str, List[ScreeningResult]]`): A dictionary where keys are category names (e.g., "Work Authorization Required") and values are lists of `ScreeningResult` objects for that category.
-   **Returns**: `None`. This method prints directly to standard output.

### `_print_category_section(category, results)` (static method)

A private helper method to format and print the results for a single applicant category. It lists each applicant's decision, score, and detailed notes, followed by a summary for that category.

-   **Parameters**:
    -   `category` (`str`): The name of the category to print.
    -   `results` (`List[ScreeningResult]`): The list of results for that category.
-   **Returns**: `None`.

### `_print_overall_summary(total_screened, total_advanced)` (static method)

A private helper method to print the final summary block of the report, including total numbers and the overall advancement rate.

-   **Parameters**:
    -   `total_screened` (`int`): The total number of applicants processed.
    -   `total_advanced` (`int`): The total number of applicants who advanced to an interview.
-   **Returns**: `None`.

---

## 6. Application Driver

These functions control the application's execution flow.

### `setup_sample_data()`

A factory function that creates and returns a pre-defined set of sample `Applicant` objects and a `ScreeningCriteria` object for demonstration purposes.

-   **Parameters**: None.
-   **Returns**: `Tuple[List[Applicant], ScreeningCriteria]` - A tuple containing the list of sample applicants and the screening criteria.

### `main()`

The main entry point and orchestrator for the application. It performs the following steps:
1.  Calls `setup_sample_data()` to get applicants and criteria.
2.  Initializes the `ResumeScreener`.
3.  Categorizes applicants based on their work authorization status.
4.  Iterates through each category, screening every applicant.
5.  Calls `ReportGenerator.generate_report()` to display the final results.

-   **Parameters**: None.
-   **Returns**: `None`.

### Execution Block

```python
if __name__ == "__main__":
    main()
```

This standard Python construct ensures that the `main()` function is called only when the script is executed directly, allowing the module's components (like its data classes) to be imported into other scripts without running the full screening process.