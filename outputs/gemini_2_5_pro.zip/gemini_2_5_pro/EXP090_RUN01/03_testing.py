# test_resume_screener_system.py

"""
A comprehensive suite of unit tests for the resume screening system using pytest.

This test suite covers:
- Data model integrity and methods.
- Core logic of the ResumeScreener, including all assessment methods.
- Edge cases, boundary conditions, and standard scenarios for applicant evaluation.
- ReportGenerator output verification using stdout capturing.
- Initialization and validation logic of the screener.
"""

import pytest
from typing import Dict, List, Set, Tuple

# Import the classes from the refactored code
# In a real project structure, this would be `from your_module import ...`
from resume_screener_refactored import (
    Applicant,
    Education,
    WorkExperience,
    ScreeningCriteria,
    ScreeningResult,
    ResumeScreener,
    ReportGenerator,
    DEFAULT_SCORING_WEIGHTS,
    SCORE_THRESHOLD_TO_ADVANCE,
    CATEGORY_AUTH_REQUIRED,
    CATEGORY_NO_AUTH_REQUIRED
)


# ==============================================================================
# 1. FIXTURES for reusable test data
# ==============================================================================

@pytest.fixture
def sample_criteria() -> ScreeningCriteria:
    """Provides a standard set of screening criteria for tests."""
    return ScreeningCriteria(
        minimum_years_experience=5.0,
        required_degree_keywords={"Computer Science", "Engineering"},
        required_skills={"Python", "SQL", "AWS"},
        preferred_skills={"React", "Django"},
        required_certifications={"AWS Certified Developer"}
    )

@pytest.fixture
def ideal_applicant() -> Applicant:
    """Provides an applicant who should easily pass screening."""
    return Applicant(
        applicant_id=1, name="Jane Doe", contact_info="jane@example.com",
        requires_work_authorization=False,
        education=[Education("M.S.", "Computer Science", "Top University", 4.0)],
        work_history=[WorkExperience("Senior Engineer", "Tech Giant", 6)],
        skills={"Python", "SQL", "AWS", "React", "Django"},
        certifications={"AWS Certified Developer"}
    )

@pytest.fixture
def unqualified_applicant() -> Applicant:
    """Provides an applicant who should be rejected."""
    return Applicant(
        applicant_id=2, name="John Smith", contact_info="john@example.com",
        requires_work_authorization=True,
        education=[Education("B.A.", "History", "Liberal Arts College", 3.0)],
        work_history=[WorkExperience("Intern", "Local Business", 1)],
        skills={"Microsoft Word", "Excel"},
        certifications=set()
    )

@pytest.fixture
def borderline_applicant() -> Applicant:
    """Provides an applicant whose score will be close to the threshold."""
    return Applicant(
        applicant_id=3, name="Sam Ray", contact_info="sam@example.com",
        requires_work_authorization=False,
        education=[Education("B.S.", "Computer Engineering", "State U", 3.5)],
        work_history=[WorkExperience("Developer", "Startup", 5)],
        skills={"Python", "SQL", "AWS"}, # Has required skills, no preferred
        certifications=set() # Missing certification
    )
    
@pytest.fixture
def empty_applicant() -> Applicant:
    """Provides an applicant with no details."""
    return Applicant(
        applicant_id=4, name="No Body", contact_info="none@example.com",
        requires_work_authorization=False
    )

@pytest.fixture
def default_screener(sample_criteria: ScreeningCriteria) -> ResumeScreener:
    """Provides a ResumeScreener instance with default settings."""
    return ResumeScreener(
        criteria=sample_criteria,
        score_threshold=SCORE_THRESHOLD_TO_ADVANCE
    )


# ==============================================================================
# 2. DATA MODEL TESTS (FR1)
# ==============================================================================

class TestDataModels:
    """Tests for the data model classes."""

    def test_applicant_creation(self):
        """Test basic instantiation of an Applicant object."""
        applicant = Applicant(
            applicant_id=100, name="Test Name", contact_info="test@test.com",
            requires_work_authorization=False
        )
        assert applicant.applicant_id == 100
        assert applicant.name == "Test Name"
        assert applicant.work_history == []
        assert applicant.skills == set()

    @pytest.mark.parametrize("work_history, expected_years", [
        ([], 0),
        ([WorkExperience("Dev", "A", 3)], 3),
        ([WorkExperience("Dev", "A", 3), WorkExperience("Sr. Dev", "B", 4.5)], 7.5),
        ([WorkExperience("Intern", "C", 0.5)], 0.5),
    ])
    def test_get_total_years_experience(self, work_history, expected_years):
        """Test the calculation of total work experience."""
        applicant = Applicant(
            applicant_id=101, name="Test Exp", contact_info="exp@test.com",
            requires_work_authorization=False,
            work_history=work_history
        )
        assert applicant.get_total_years_experience() == expected_years


# ==============================================================================
# 3. RESUME SCREENER TESTS (FR2, FR3)
# ==============================================================================

class TestResumeScreener:
    """Tests the core logic of the ResumeScreener class."""

    def test_initialization_success(self, sample_criteria):
        """Test successful initialization."""
        screener = ResumeScreener(criteria=sample_criteria, score_threshold=50)
        assert screener._criteria == sample_criteria
        assert screener._score_threshold == 50
        assert screener._weights == DEFAULT_SCORING_WEIGHTS

    def test_initialization_with_custom_weights(self, sample_criteria):
        """Test initialization with a custom weights dictionary."""
        custom_weights = {'DEGREE_MATCH': 100}
        screener = ResumeScreener(
            criteria=sample_criteria,
            score_threshold=50,
            weights=custom_weights
        )
        assert screener._weights == custom_weights

    @pytest.mark.parametrize("bad_criteria, bad_threshold, expected_exception", [
        (None, 50, TypeError),
        ("not criteria", 50, TypeError),
        (ScreeningCriteria(set(), set(), set(), set(), set()), 0, ValueError),
        (ScreeningCriteria(set(), set(), set(), set(), set()), -10, ValueError),
        (ScreeningCriteria(set(), set(), set(), set(), set()), 50.5, ValueError),
    ])
    def test_initialization_failure(self, bad_criteria, bad_threshold, expected_exception):
        """Test that initialization fails with invalid arguments."""
        with pytest.raises(expected_exception):
            ResumeScreener(criteria=bad_criteria, score_threshold=bad_threshold)

    # --- Tests for individual assessment methods ---

    @pytest.mark.parametrize("years_exp, expected_score_key, expected_note_part", [
        (5.0, 'YEARS_EXPERIENCE_MET', "Met experience requirement"),
        (10.0, 'YEARS_EXPERIENCE_MET', "Met experience requirement"),
        (4.9, 'INSUFFICIENT_EXPERIENCE_PENALTY', "FAIL: Below minimum experience"),
        (0, 'INSUFFICIENT_EXPERIENCE_PENALTY', "FAIL: Below minimum experience"),
    ])
    def test_assess_experience(self, years_exp, expected_score_key, expected_note_part, sample_criteria, default_screener):
        """Test experience assessment logic."""
        applicant = Applicant(1, "Test", "", False, work_history=[WorkExperience("Dev", "A", years_exp)])
        notes: List[str] = []
        score = default_screener._assess_experience(applicant, notes)
        
        assert score == DEFAULT_SCORING_WEIGHTS[expected_score_key]
        assert any(expected_note_part in note for note in notes)

    @pytest.mark.parametrize("education_list, expected_score_key, expected_note_part", [
        ([Education("M.S.", "Computer Science", "U", 4.0)], 'DEGREE_MATCH', "Has a relevant degree."),
        ([Education("B.S.", "Software Engineering", "U", 4.0)], 'DEGREE_MATCH', "Has a relevant degree."),
        ([Education("B.A.", "History", "U", 3.0)], None, "Did not find a matching degree"),
        ([], None, "Did not find a matching degree"),
    ])
    def test_assess_education(self, education_list, expected_score_key, expected_note_part, default_screener):
        """Test education assessment logic."""
        applicant = Applicant(1, "Test", "", False, education=education_list)
        notes: List[str] = []
        score = default_screener._assess_education(applicant, notes)
        
        expected_score = DEFAULT_SCORING_WEIGHTS.get(expected_score_key, 0)
        assert score == expected_score
        assert any(expected_note_part in note for note in notes)

    def test_assess_skills_ideal(self, default_screener):
        """Test skill assessment for an applicant with all required and preferred skills."""
        applicant = Applicant(1, "Test", "", False, skills={"Python", "SQL", "AWS", "React", "Django"})
        notes: List[str] = []
        score = default_screener._assess_skills(applicant, notes)

        expected_score = (3 * DEFAULT_SCORING_WEIGHTS['REQUIRED_SKILL_MATCH'] +
                          2 * DEFAULT_SCORING_WEIGHTS['PREFERRED_SKILL_MATCH'])
        assert score == expected_score
        assert "Matched 3/3 required skills." in notes
        assert "Matched 2 preferred skills." in notes
        assert not any("FAIL: Missing required skills" in note for note in notes)

    def test_assess_skills_missing_required(self, default_screener):
        """Test skill assessment when required skills are missing."""
        applicant = Applicant(1, "Test", "", False, skills={"Python", "Django"})
        notes: List[str] = []
        score = default_screener._assess_skills(applicant, notes)

        expected_score = (1 * DEFAULT_SCORING_WEIGHTS['REQUIRED_SKILL_MATCH'] +
                          1 * DEFAULT_SCORING_WEIGHTS['PREFERRED_SKILL_MATCH'] +
                          DEFAULT_SCORING_WEIGHTS['MISSING_REQUIRED_SKILLS_PENALTY'])
        assert score == expected_score
        assert "Matched 1/3 required skills." in notes
        assert any("FAIL: Missing required skills: " in note for note in notes)
        assert "SQL" in notes[-1] and "AWS" in notes[-1]

    def test_assess_certifications(self, default_screener):
        """Test certification assessment."""
        applicant_with_cert = Applicant(1, "Test", "", False, certifications={"AWS Certified Developer", "Other Cert"})
        applicant_no_cert = Applicant(2, "Test2", "", False, certifications=set())
        notes1: List[str] = []
        notes2: List[str] = []

        score1 = default_screener._assess_certifications(applicant_with_cert, notes1)
        score2 = default_screener._assess_certifications(applicant_no_cert, notes2)
        
        assert score1 == DEFAULT_SCORING_WEIGHTS['REQUIRED_CERTIFICATION_MATCH']
        assert "Has required certifications: AWS Certified Developer" in notes1[0]
        assert score2 == 0
        assert len(notes2) == 0

    # --- Full screening tests ---

    def test_screen_ideal_applicant(self, default_screener, ideal_applicant):
        """Test screening an ideal applicant who should pass."""
        result = default_screener.screen(ideal_applicant)
        
        assert result.advances_to_interview is True
        assert result.score >= SCORE_THRESHOLD_TO_ADVANCE
        assert "ADVANCE TO INTERVIEW" in result.notes[0]

    def test_screen_unqualified_applicant(self, default_screener, unqualified_applicant):
        """Test screening an unqualified applicant who should fail."""
        result = default_screener.screen(unqualified_applicant)
        
        assert result.advances_to_interview is False
        assert result.score < SCORE_THRESHOLD_TO_ADVANCE
        assert "REJECT" in result.notes[0]
        assert any("FAIL: Below minimum experience" in note for note in result.notes)
        assert any("FAIL: Missing required skills" in note for note in result.notes)

    def test_screen_borderline_applicant_pass(self, sample_criteria, borderline_applicant):
        """Test a borderline applicant who just meets the threshold."""
        # This applicant has:
        # Experience: MET -> +15
        # Degree: MATCH -> +25
        # Skills: 3/3 required, 0/2 preferred -> 3*5 = +15
        # Certs: Missing -> 0
        # Total = 15 + 25 + 15 = 55
        screener = ResumeScreener(criteria=sample_criteria, score_threshold=55)
        result = screener.screen(borderline_applicant)
        assert result.score == 55
        assert result.advances_to_interview is True

    def test_screen_borderline_applicant_fail(self, sample_criteria, borderline_applicant):
        """Test a borderline applicant who just misses the threshold."""
        screener = ResumeScreener(criteria=sample_criteria, score_threshold=56)
        result = screener.screen(borderline_applicant)
        assert result.score == 55
        assert result.advances_to_interview is False
        
    def test_screen_empty_applicant(self, default_screener, empty_applicant):
        """Test screening an applicant with no information."""
        result = default_screener.screen(empty_applicant)
        assert result.advances_to_interview is False
        assert result.score < 0 # Should have multiple penalties


# ==============================================================================
# 4. REPORT GENERATOR TESTS (FR4, NFR2)
# ==============================================================================

class TestReportGenerator:
    """Tests the console output of the ReportGenerator."""

    def test_generate_report_with_data(self, capsys):
        """Test report generation with typical data."""
        results = {
            CATEGORY_NO_AUTH_REQUIRED: [
                ScreeningResult("Alice", 80, True, ["Note 1"]),
                ScreeningResult("Bob", 40, False, ["Note 2"])
            ],
            CATEGORY_AUTH_REQUIRED: [
                ScreeningResult("Charlie", 60, True, ["Note 3"])
            ]
        }
        ReportGenerator.generate_report("Senior Dev", results)
        captured = capsys.readouterr()
        
        # Check header
        assert "RESUME SCREENING REPORT: Senior Dev" in captured.out
        # Check category sections
        assert f"--- CATEGORY: {CATEGORY_NO_AUTH_REQUIRED} ---" in captured.out
        assert f"--- CATEGORY: {CATEGORY_AUTH_REQUIRED} ---" in captured.out
        # Check applicant data
        assert "Applicant: Alice" in captured.out and "Decision: ADVANCE" in captured.out
        assert "Applicant: Bob" in captured.out and "Decision: REJECT" in captured.out
        assert "Applicant: Charlie" in captured.out and "Decision: ADVANCE" in captured.out
        # Check summaries
        assert "Category Summary (No Work Authorization Required):" in captured.out
        assert "Advanced: 1 | Rejected: 1" in captured.out
        assert "OVERALL SUMMARY" in captured.out
        assert "Total Applicants Screened: 3" in captured.out
        assert "Total Advanced to Interview: 2" in captured.out
        assert "Overall Advancement Rate: 66.67%" in captured.out

    def test_generate_report_no_applicants(self, capsys):
        """Test report generation when no applicants were screened."""
        results = {CATEGORY_NO_AUTH_REQUIRED: [], CATEGORY_AUTH_REQUIRED: []}
        ReportGenerator.generate_report("Job Title", results)
        captured = capsys.readouterr()

        assert "No applicants were screened." in captured.out
        assert "OVERALL SUMMARY" not in captured.out # The main summary prints a different message

    def test_generate_report_one_empty_category(self, capsys):
        """Test report when one category is empty."""
        results = {
            CATEGORY_NO_AUTH_REQUIRED: [ScreeningResult("Alice", 80, True, [])],
            CATEGORY_AUTH_REQUIRED: []
        }
        ReportGenerator.generate_report("Job Title", results)
        captured = capsys.readouterr()

        assert f"--- CATEGORY: {CATEGORY_NO_AUTH_REQUIRED} ---" in captured.out
        assert "Applicant: Alice" in captured.out
        assert f"--- CATEGORY: {CATEGORY_AUTH_REQUIRED} ---" in captured.out
        assert "No applicants in this category." in captured.out
        assert "Total Applicants Screened: 1" in captured.out
        assert "Overall Advancement Rate: 100.00%" in captured.out