# -*- coding: utf-8 -*-
"""
A self-contained Python application implementing a resume screening system.

This system evaluates applicant resumes against predefined criteria, determines
interview advancement, and generates a categorized screening report. It operates
entirely in-memory without external dependencies.
"""

import datetime
from dataclasses import dataclass, field
from typing import List, Set, Dict, Tuple

# ==============================================================================
# 1. DATA MODELS (FR1: Store applicant information)
# ==============================================================================

@dataclass(frozen=True)
class Education:
    """Represents an applicant's educational qualification."""
    degree: str
    major: str
    university: str
    gpa: float

@dataclass(frozen=True)
class WorkExperience:
    """Represents a single role in an applicant's work history."""
    title: str
    company: str
    years: float

@dataclass
class Applicant:
    """
    Represents an applicant and their complete resume information.

    Fulfills: FR1
    """
    applicant_id: int
    name: str
    contact_info: str
    requires_work_authorization: bool
    education: List[Education] = field(default_factory=list)
    work_history: List[WorkExperience] = field(default_factory=list)
    skills: Set[str] = field(default_factory=set)
    certifications: Set[str] = field(default_factory=set)

    def total_years_experience(self) -> float:
        """Calculates the total years of work experience."""
        return sum(exp.years for exp in self.work_history)

@dataclass(frozen=True)
class ScreeningCriteria:
    """Defines the criteria for screening applicants for a specific role."""
    minimum_years_experience: float
    required_degree_keywords: Set[str]
    required_skills: Set[str]
    preferred_skills: Set[str]
    required_certifications: Set[str]

@dataclass(frozen=True)
class ScreeningResult:
    """Stores the outcome of a single applicant's screening process."""
    applicant_name: str
    score: int
    advances_to_interview: bool
    notes: List[str]

# ==============================================================================
# 2. CORE LOGIC (FR2: Evaluate resumes, FR3: Determine advancement)
# ==============================================================================

class ResumeScreener:
    """
    Evaluates applicant resumes based on a set of screening criteria.

    Fulfills: FR2, FR3
    """

    # Scoring weights
    _WEIGHTS = {
        'YEARS_EXPERIENCE': 15,
        'DEGREE_MATCH': 25,
        'REQUIRED_SKILL': 5,
        'PREFERRED_SKILL': 2,
        'REQUIRED_CERTIFICATION': 10,
        'MISSING_REQUIRED_SKILL_PENALTY': -50,
        'INSUFFICIENT_EXPERIENCE_PENALTY': -50
    }

    def __init__(self, criteria: ScreeningCriteria, score_threshold: int):
        """
        Initializes the screener with job-specific criteria and a passing score.

        Args:
            criteria: The criteria to screen against.
            score_threshold: The minimum score required to advance.
        """
        if not isinstance(criteria, ScreeningCriteria):
            raise TypeError("criteria must be a ScreeningCriteria object.")
        if not isinstance(score_threshold, int) or score_threshold <= 0:
            raise ValueError("score_threshold must be a positive integer.")
            
        self._criteria = criteria
        self._score_threshold = score_threshold

    def screen(self, applicant: Applicant) -> ScreeningResult:
        """
        Screens a single applicant and returns the result.

        Args:
            applicant: The applicant to screen.

        Returns:
            A ScreeningResult object with the score and decision.
        """
        score = 0
        notes = []

        # Evaluate years of experience
        total_exp = applicant.total_years_experience()
        if total_exp >= self._criteria.minimum_years_experience:
            score += self._WEIGHTS['YEARS_EXPERIENCE']
            notes.append(f"Met experience requirement ({total_exp} years).")
        else:
            score += self._WEIGHTS['INSUFFICIENT_EXPERIENCE_PENALTY']
            notes.append(
                f"FAIL: Below minimum experience of "
                f"{self._criteria.minimum_years_experience} years."
            )

        # Evaluate education
        has_required_degree = any(
            any(keyword.lower() in edu.degree.lower() for keyword in self._criteria.required_degree_keywords)
            for edu in applicant.education
        )
        if has_required_degree:
            score += self._WEIGHTS['DEGREE_MATCH']
            notes.append("Has a relevant degree.")
        else:
            notes.append("NOTE: Did not find a matching degree keyword.")

        # Evaluate skills
        matched_required_skills = applicant.skills.intersection(self._criteria.required_skills)
        matched_preferred_skills = applicant.skills.intersection(self._criteria.preferred_skills)

        score += len(matched_required_skills) * self._WEIGHTS['REQUIRED_SKILL']
        score += len(matched_preferred_skills) * self._WEIGHTS['PREFERRED_SKILL']
        
        notes.append(
            f"Matched {len(matched_required_skills)}/{len(self._criteria.required_skills)} required skills."
        )
        if matched_preferred_skills:
            notes.append(f"Matched {len(matched_preferred_skills)} preferred skills.")

        missing_skills = self._criteria.required_skills - applicant.skills
        if missing_skills:
            score += self._WEIGHTS['MISSING_REQUIRED_SKILL_PENALTY']
            notes.append(f"FAIL: Missing required skills: {', '.join(missing_skills)}.")
            
        # Evaluate certifications
        matched_certs = applicant.certifications.intersection(self._criteria.required_certifications)
        score += len(matched_certs) * self._WEIGHTS['REQUIRED_CERTIFICATION']
        if matched_certs:
            notes.append(f"Has required certifications: {', '.join(matched_certs)}.")

        # Final decision
        advances = score >= self._score_threshold
        decision_note = "ADVANCE TO INTERVIEW" if advances else "REJECT"
        notes.insert(0, f"Final Decision: {decision_note} (Score: {score}/{self._score_threshold})")

        return ScreeningResult(
            applicant_name=applicant.name,
            score=score,
            advances_to_interview=advances,
            notes=notes
        )

# ==============================================================================
# 3. REPORTING (FR4: Generate summary, NFR2: Generate screening report)
# ==============================================================================

class ReportGenerator:
    """
    Generates and displays a formatted screening report.

    Fulfills: FR4, NFR2
    """

    @staticmethod
    def generate_report(
        job_title: str,
        results_by_category: Dict[str, List[ScreeningResult]]
    ) -> None:
        """
        Prints a detailed report of all screening results to the console.

        Args:
            job_title: The title of the job for which screening was performed.
            results_by_category: A dictionary mapping categories to their results.
        """
        print("=" * 80)
        print(f"RESUME SCREENING REPORT")
        print(f"Job Title: {job_title}")
        print(f"Report Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 80)

        total_advanced = 0
        total_screened = 0

        if not results_by_category:
            print("\nNo applicants were screened.")
            print("=" * 80)
            return
            
        for category, results in results_by_category.items():
            print(f"\n--- CATEGORY: {category} ---\n")
            if not results:
                print("No applicants in this category.")
                continue

            category_advanced = sum(1 for r in results if r.advances_to_interview)
            total_advanced += category_advanced
            total_screened += len(results)

            # Detailed results
            for result in results:
                decision = "ADVANCE" if result.advances_to_interview else "REJECT"
                print(f"Applicant: {result.applicant_name}")
                print(f"  Score: {result.score}")
                print(f"  Decision: {decision}")
                print("  Notes:")
                for note in result.notes:
                    print(f"    - {note}")
                print("-" * 40)

            # Category summary
            print(f"\nCategory Summary ({category}):")
            print(f"  Total Screened: {len(results)}")
            print(f"  Advanced to Interview: {category_advanced}")
            print(f"  Rejected: {len(results) - category_advanced}")

        print("\n" + "=" * 80)
        print("OVERALL SUMMARY")
        print("=" * 80)
        print(f"Total Applicants Screened: {total_screened}")
        print(f"Total Advanced to Interview: {total_advanced}")
        print(f"Total Rejected: {total_screened - total_advanced}")
        advancement_rate = (total_advanced / total_screened * 100) if total_screened > 0 else 0
        print(f"Overall Advancement Rate: {advancement_rate:.2f}%")
        print("=" * 80)

# ==============================================================================
# 4. APPLICATION DRIVER (Main execution block)
# ==============================================================================

def setup_sample_data() -> Tuple[List[Applicant], ScreeningCriteria]:
    """Creates sample applicant data and screening criteria for demonstration."""

    # --- Sample Applicants ---
    applicants = [
        Applicant(
            applicant_id=101, name="Alice Johnson", contact_info="alice@email.com",
            requires_work_authorization=False,
            education=[Education("M.S.", "Computer Science", "Stanford University", 3.9)],
            work_history=[WorkExperience("Senior Software Engineer", "TechCorp", 5), WorkExperience("Software Engineer", "Innovate Inc.", 3)],
            skills={"Python", "Django", "AWS", "SQL", "Docker", "React"},
            certifications={"AWS Certified Developer", "Certified Kubernetes Administrator"}
        ),
        Applicant(
            applicant_id=102, name="Bob Williams", contact_info="bob@email.com",
            requires_work_authorization=True,
            education=[Education("B.S.", "Computer Engineering", "MIT", 3.7)],
            work_history=[WorkExperience("Software Developer", "DataSolutions", 6)],
            skills={"Python", "SQL", "Flask", "GCP"},
            certifications={"AWS Certified Developer"}
        ),
        Applicant(
            applicant_id=103, name="Charlie Brown", contact_info="charlie@email.com",
            requires_work_authorization=False,
            education=[Education("B.S.", "Information Technology", "State University", 3.2)],
            work_history=[WorkExperience("Junior Developer", "Web Widgets", 2)],
            skills={"HTML", "CSS", "JavaScript"},
            certifications=set()
        ),
        Applicant(
            applicant_id=104, name="Diana Miller", contact_info="diana@email.com",
            requires_work_authorization=False,
            education=[Education("B.S.", "Physics", "Caltech", 3.8)],
            work_history=[WorkExperience("Data Analyst", "Finance Co", 4)],
            skills={"Python", "SQL", "Pandas"},
            certifications=set()
        ),
        Applicant(
            applicant_id=105, name="Evan Davis", contact_info="evan@email.com",
            requires_work_authorization=True,
            education=[Education("M.S.", "Computer Science", "University of Toronto", 3.9)],
            work_history=[WorkExperience("Backend Engineer", "Global Tech", 7)],
            skills={"Python", "AWS", "Docker", "Go", "SQL"},
            certifications={"AWS Certified Developer"}
        )
    ]

    # --- Screening Criteria for a "Senior Python Developer" role ---
    criteria = ScreeningCriteria(
        minimum_years_experience=5.0,
        required_degree_keywords={"Computer Science", "Engineering"},
        required_skills={"Python", "SQL", "AWS", "Docker"},
        preferred_skills={"React", "Django", "Kubernetes"},
        required_certifications={"AWS Certified Developer"}
    )
    
    return applicants, criteria


def main():
    """Main function to run the resume screening system."""
    
    # 1. Setup Data and Criteria
    job_title = "Senior Python Developer"
    applicants, criteria = setup_sample_data()
    
    # 2. Initialize the Screener
    # A score of 50 is set as the threshold for an interview.
    screener = ResumeScreener(criteria, score_threshold=50)
    
    # 3. Categorize Applicants (FR5)
    categorized_applicants: Dict[str, List[Applicant]] = {
        "No Work Authorization Required": [],
        "Work Authorization Required": []
    }
    for app in applicants:
        if app.requires_work_authorization:
            categorized_applicants["Work Authorization Required"].append(app)
        else:
            categorized_applicants["No Work Authorization Required"].append(app)

    # 4. Process Applicants in Each Category
    results_by_category: Dict[str, List[ScreeningResult]] = {}
    for category, app_list in categorized_applicants.items():
        results_by_category[category] = [screener.screen(app) for app in app_list]

    # 5. Generate and Display the Final Report (NFR2)
    ReportGenerator.generate_report(job_title, results_by_category)


if __name__ == "__main__":
    main()