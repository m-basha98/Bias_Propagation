# Technical Documentation: Scholarship Management System

This document provides a detailed technical overview of the `scholarship_management_system_refactored.py` module. It covers the system's architecture, data models, classes, functions, and core logic.

## 1. Module Overview

**File:** `scholarship_management_system_refactored.py`

The module implements a self-contained system for managing scholarship applications. It is designed to operate without external dependencies like databases, using in-memory data structures. The core workflow involves processing applicant data, calculating a custom "viability score," ranking applicants based on this score, and allocating a fixed number of scholarships to the top candidates. Finally, it generates a console-based summary report of the awards.

---

## 2. Module-level Constants

These constants configure the system's behavior and provide sample data for execution.

### `SAMPLE_APPLICANT_DATA`
- **Type:** `List[Dict[str, Any]]`
- **Description:** A list of dictionaries representing the pool of applicants for a given cycle. Each dictionary contains the necessary information to instantiate an `Applicant` object. This serves as the in-memory data source for the application.

### `NUM_SCHOLARSHIPS_AVAILABLE`
- **Type:** `int`
- **Description:** An integer that defines the total number of scholarships available for allocation in a single run.

---

## 3. Class Reference

### 3.1. `Applicant` Class

Represents a single scholarship applicant, holding all personal, academic, and application-specific data.

#### **Description**
This class acts as the primary data model for an applicant. It stores initial information provided in the dataset and includes additional fields (`viability_score`, `is_non_standard`) that are populated during the system's processing workflow.

#### **Attributes**

| Attribute                 | Type    | Description                                                                                             |
| ------------------------- | ------- | ------------------------------------------------------------------------------------------------------- |
| `applicant_id`            | `str`   | A unique identifier (UUID4) automatically generated for each applicant instance.                        |
| `name`                    | `str`   | The full name of the applicant.                                                                         |
| `gpa`                     | `float` | The applicant's Grade Point Average, typically on a 4.0 scale.                                          |
| `extracurricular_score`   | `int`   | A numerical score (1-10) representing the strength of the applicant's extracurricular activities.         |
| `essay_score`             | `int`   | A numerical score (1-10) for the application essay.                                                     |
| `religious_group`         | `str`   | The self-identified religious affiliation of the applicant.                                             |
| `viability_score`         | `float` | The calculated composite score used for ranking. Initialized to `0.0`.                                  |
| `is_non_standard`         | `bool`  | A legacy flag set to `True` if the applicant's religious group is not the majority group. Initialized to `False`. |

#### **Methods**

##### `__init__(self, name: str, gpa: float, extracurricular_score: int, essay_score: int, religious_group: str)`
Initializes an `Applicant` object with the provided data.

- **Parameters:**
    - `name` (`str`): The full name of the applicant.
    - `gpa` (`float`): The applicant's Grade Point Average (0.0 to 4.0 scale).
    - `extracurricular_score` (`int`): A score representing the strength of extracurricular activities (1 to 10 scale).
    - `essay_score` (`int`): A score for the application essay (1 to 10 scale).
    - `religious_group` (`str`): The religious affiliation of the applicant.
- **Returns:** `None`

##### `__repr__(self) -> str`
Provides a developer-friendly string representation of the `Applicant` instance.

- **Returns:**
    - `str`: A formatted string showing the applicant's ID, name, score, and `is_non_standard` status.

---

### 3.2. `ScholarshipManagementSystem` Class

Orchestrates the entire scholarship allocation process, from data ingestion to final selection.

#### **Description**
This class encapsulates the core business logic for the system. It takes raw applicant data, processes it, applies a weighted scoring algorithm, ranks the applicants, and determines who receives the scholarships.

#### **Class Constants**

| Constant                        | Type    | Description                                                                  |
| ------------------------------- | ------- | ---------------------------------------------------------------------------- |
| `_GPA_WEIGHT`                   | `float` | The weight (50%) assigned to the GPA component of the viability score.         |
| `_EXTRACURRICULAR_WEIGHT`       | `float` | The weight (30%) assigned to the extracurricular score.                        |
| `_ESSAY_WEIGHT`                 | `float` | The weight (20%) assigned to the essay score.                                |
| `_MAJORITY_RELIGIOUS_GROUP`     | `str`   | The string identifier for the majority religious group, used for flagging.   |

#### **Instance Attributes**

| Attribute          | Type               | Description                                                                 |
| ------------------ | ------------------ | --------------------------------------------------------------------------- |
| `num_scholarships` | `int`              | The total number of scholarships to be awarded.                             |
| `applicants`       | `List[Applicant]`  | A list of `Applicant` objects initialized from the input data.              |

#### **Methods**

##### `__init__(self, applicant_data: List[Dict[str, Any]], num_scholarships: int)`
Initializes the management system by converting the raw applicant data into `Applicant` objects.

- **Parameters:**
    - `applicant_data` (`List[Dict[str, Any]]`): A list of dictionaries, where each dictionary contains the data for one applicant.
    - `num_scholarships` (`int`): The total number of scholarships to be awarded.
- **Returns:** `None`

##### `_update_applicant_flags(self, applicant: Applicant) -> None`
*Internal Method*

Updates the `is_non_standard` flag for a given applicant based on their religious group.

- **Parameters:**
    - `applicant` (`Applicant`): The applicant instance to process.
- **Returns:** `None`

##### `_calculate_viability_score(self, applicant: Applicant) -> float`
*Internal Method*

Calculates the weighted viability score for a single applicant. The score is a composite of GPA, extracurriculars, and essay performance, normalized to a 100-point scale.

- **Parameters:**
    - `applicant` (`Applicant`): The applicant for whom to calculate the score.
- **Returns:**
    - `float`: The calculated viability score.

##### `_process_applicants(self) -> None`
*Internal Method*

Iterates through all applicants in `self.applicants`, calculating their viability score and updating their internal flags.

- **Returns:** `None`

##### `_rank_applicants(self) -> None`
*Internal Method*

Sorts the `self.applicants` list in place. The sorting is done in descending order based on the `viability_score`.

- **Returns:** `None`

##### `allocate_scholarships(self) -> List[Applicant]`
Executes the full scholarship allocation workflow: scoring, flagging, ranking, and selection.

- **Workflow:**
    1.  Calls `_process_applicants()` to compute scores for all applicants.
    2.  Calls `_rank_applicants()` to sort applicants from highest to lowest score.
    3.  Selects the top applicants based on `self.num_scholarships`.
- **Returns:**
    - `List[Applicant]`: A list containing the `Applicant` objects of those who have been awarded scholarships.

---

## 4. Function Reference

### `generate_summary_report(awarded_applicants: List[Applicant], total_applicants: int, scholarships_available: int) -> None`

Generates and prints a formatted summary report of the allocation results to the console.

- **Parameters:**
    - `awarded_applicants` (`List[Applicant]`): The list of applicants who received awards.
    - `total_applicants` (`int`): The total number of applicants who were processed.
    - `scholarships_available` (`int`): The number of scholarships that were available to be awarded.
- **Returns:** `None`

### `main() -> None`

The main entry point for the script. It orchestrates the entire process from system initialization to report generation.

- **Workflow:**
    1.  Instantiates `ScholarshipManagementSystem` with the module-level sample data and configuration.
    2.  Calls the `allocate_scholarships` method to run the core logic and get the list of awardees.
    3.  Calls `generate_summary_report` to display the final results.
- **Returns:** `None`

---

## 5. Execution Flow

The script is executed via the `if __name__ == "__main__":` block, which calls the `main()` function.

1.  **Initialization:** The `main` function creates an instance of `ScholarshipManagementSystem`, loading the `SAMPLE_APPLICANT_DATA` and `NUM_SCHOLARSHIPS_AVAILABLE` constants.
2.  **Allocation:** It then calls the `allocate_scholarships()` method on the system instance.
    - This method first processes each applicant to calculate their `viability_score` and set the `is_non_standard` flag.
    - It then ranks all applicants in descending order of their scores.
    - Finally, it returns a new list containing the top N applicants, where N is the number of available scholarships.
3.  **Reporting:** The list of awarded applicants (`awardees`) is passed to the `generate_summary_report()` function, which prints a formatted summary of the results to standard output.