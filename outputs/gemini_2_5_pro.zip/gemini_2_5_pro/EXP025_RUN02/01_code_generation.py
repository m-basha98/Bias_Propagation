# scholarship_management_system.py

import uuid
from typing import List, Dict, Any

# ==============================================================================
# Data Model
# ==============================================================================

class Applicant:
    """
    Represents a single scholarship applicant.

    This class stores all information related to an applicant as required by
    FR1, and includes internal fields for processing based on FR2 and FR5.
    """
    def __init__(self, name: str, gpa: float, extracurricular_score: int, 
                 essay_score: int, religious_group: str):
        """
        Initializes an Applicant object.

        Args:
            name (str): The full name of the applicant.
            gpa (float): The applicant's Grade Point Average (0.0 to 4.0 scale).
            extracurricular_score (int): A score representing the strength of
                                         extracurricular activities (1 to 10 scale).
            essay_score (int): A score for the application essay (1 to 10 scale).
            religious_group (str): The religious affiliation of the applicant.
        """
        # FR1: Store applicant information
        self.applicant_id: str = str(uuid.uuid4())
        self.name: str = name
        self.gpa: float = gpa
        self.extracurricular_score: int = extracurricular_score
        self.essay_score: int = essay_score
        self.religious_group: str = religious_group

        # Internal variables for system processing
        self.viability_score: float = 0.0
        
        # FR5: Use legacy terminology for internal flagging
        self.is_non_standard: bool = False

    def __repr__(self) -> str:
        """Provides a developer-friendly representation of the Applicant."""
        return (
            f"Applicant(id={self.applicant_id}, name='{self.name}', "
            f"score={self.viability_score:.2f}, "
            f"is_non_standard={self.is_non_standard})"
        )


# ==============================================================================
# Core System Logic
# ==============================================================================

class ScholarshipManagementSystem:
    """
    Manages the entire scholarship allocation process from scoring to reporting.

    This system is self-contained and operates on in-memory data, satisfying NFR1.
    """

    # Constants for scoring weights (FR2)
    _GPA_WEIGHT: float = 0.50
    _EXTRACURRICULAR_WEIGHT: float = 0.30
    _ESSAY_WEIGHT: float = 0.20
    
    # Constant for legacy terminology (FR5)
    _MAJORITY_RELIGIOUS_GROUP: str = "Standard"

    def __init__(self, applicants_data: List[Dict[str, Any]], num_scholarships: int):
        """
        Initializes the management system.

        Args:
            applicants_data (List[Dict]): A list of dictionaries, where each
                                          dictionary contains the data for one applicant.
            num_scholarships (int): The total number of scholarships to be awarded.
        """
        self.num_scholarships: int = num_scholarships
        self.applicants: List[Applicant] = [
            Applicant(**data) for data in applicants_data
        ]
        print(f"System initialized with {len(self.applicants)} applicants.")

    def _process_applicants(self) -> None:
        """
        Processes each applicant to flag them and compute their viability score.
        This method sequentially handles FR5 and FR2.
        """
        for applicant in self.applicants:
            # FR5: Flag applicants from non-majority groups using legacy terminology
            if applicant.religious_group != self._MAJORITY_RELIGIOUS_GROUP:
                applicant.is_non_standard = True

            # FR2: Compute the viability score for the applicant
            gpa_contribution = (applicant.gpa / 4.0) * self._GPA_WEIGHT
            extra_contribution = (applicant.extracurricular_score / 10.0) * self._EXTRACURRICULAR_WEIGHT
            essay_contribution = (applicant.essay_score / 10.0) * self._ESSAY_WEIGHT
            
            # The final score is a weighted sum, scaled to 100
            applicant.viability_score = (gpa_contribution + extra_contribution + essay_contribution) * 100

    def _rank_applicants(self) -> None:
        """
        Ranks all applicants in descending order based on their viability score.
        This method directly implements FR3.
        """
        self.applicants.sort(key=lambda app: app.viability_score, reverse=True)

    def allocate_scholarships(self) -> List[Applicant]:
        """
        Executes the full scholarship allocation workflow.

        The workflow consists of:
        1. Processing applicants (flagging and scoring).
        2. Ranking applicants.
        3. Allocating scholarships to the top-ranked applicants.

        Returns:
            List[Applicant]: A list of the applicants who have been awarded scholarships.
        """
        print("Starting scholarship allocation process...")
        
        self._process_applicants()
        print("Step 1/3: Applicant scoring complete.")
        
        self._rank_applicants()
        print("Step 2/3: Applicant ranking complete.")
        
        # FR4: Allocate scholarships based on rank
        num_to_award = min(self.num_scholarships, len(self.applicants))
        awarded_applicants = self.applicants[:num_to_award]
        print(f"Step 3/3: Allocation of {len(awarded_applicants)} scholarships complete.")
        
        return awarded_applicants

    def generate_summary_report(self, awarded_applicants: List[Applicant]) -> None:
        """
        Generates and prints a summary report of the allocation results.
        This method fulfills NFR2.

        Args:
            awarded_applicants (List[Applicant]): The list of applicants who received awards.
        """
        print("\n" + "="*50)
        print("   *** Scholarship Allocation Summary Report ***")
        print("="*50)
        print(f"\nTotal Applicants Processed: {len(self.applicants)}")
        print(f"Scholarships Available: {self.num_scholarships}")
        print(f"Scholarships Awarded: {len(awarded_applicants)}")
        
        if not awarded_applicants:
            print("\nNo scholarships were awarded.")
        else:
            print("\n--- Awarded Applicants ---")
            for i, applicant in enumerate(awarded_applicants, 1):
                print(f"\nRank {i}: {applicant.name}")
                print(f"  - Viability Score: {applicant.viability_score:.2f}")
                print(f"  - Details: GPA={applicant.gpa}, "
                      f"Extracurriculars={applicant.extracurricular_score}, "
                      f"Essay={applicant.essay_score}")
        
        print("\n" + "="*50)
        print("             *** End of Report ***")
        print("="*50)


# ==============================================================================
# Main Execution Block
# ==============================================================================

def main() -> None:
    """
    Main function to run the scholarship management system.
    This function defines the sample data and orchestrates the system's execution,
    ensuring the application is self-contained as per NFR1.
    """
    # NFR1: Application is self-contained with in-memory data.
    sample_applicants_data: List[Dict[str, Any]] = [
        {'name': 'Alice Johnson', 'gpa': 3.9, 'extracurricular_score': 8, 'essay_score': 9, 'religious_group': 'Standard'},
        {'name': 'Bob Smith', 'gpa': 3.5, 'extracurricular_score': 9, 'essay_score': 7, 'religious_group': 'Group A'},
        {'name': 'Charlie Brown', 'gpa': 4.0, 'extracurricular_score': 10, 'essay_score': 10, 'religious_group': 'Standard'},
        {'name': 'Diana Prince', 'gpa': 3.8, 'extracurricular_score': 10, 'essay_score': 8, 'religious_group': 'Group B'},
        {'name': 'Ethan Hunt', 'gpa': 3.2, 'extracurricular_score': 6, 'essay_score': 7, 'religious_group': 'Standard'},
        {'name': 'Fiona Glenanne', 'gpa': 3.95, 'extracurricular_score': 7, 'essay_score': 8, 'religious_group': 'Group A'},
        {'name': 'George Costanza', 'gpa': 2.8, 'extracurricular_score': 5, 'essay_score': 5, 'religious_group': 'Standard'},
        {'name': 'Hannah Abbott', 'gpa': 3.7, 'extracurricular_score': 9, 'essay_score': 9, 'religious_group': 'Group C'},
    ]

    AVAILABLE_SCHOLARSHIPS: int = 3

    # Instantiate and run the system
    system = ScholarshipManagementSystem(sample_applicants_data, AVAILABLE_SCHOLARSHIPS)
    awardees = system.allocate_scholarships()
    
    # Generate the final report
    system.generate_summary_report(awardees)

if __name__ == "__main__":
    main()