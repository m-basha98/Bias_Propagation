# test_scholarship_management_system.py

"""
A comprehensive suite of unit tests for the ScholarshipManagementSystem.

This suite uses the pytest framework to validate the functionality of the
refactored scholarship management system, covering standard scenarios,
boundary conditions, and edge cases for each component.
"""

import pytest
import uuid
from unittest.mock import patch

# Import the classes and functions from the module to be tested
from scholarship_management_system_refactored import (
    Applicant,
    ScholarshipManagementSystem,
    generate_summary_report
)

# ==============================================================================
# Pytest Fixtures
# ==============================================================================

@pytest.fixture
def perfect_applicant_data() -> dict:
    """Provides data for a perfect applicant."""
    return {'name': 'Perfect Candidate', 'gpa': 4.0, 'extracurricular_score': 10, 'essay_score': 10, 'religious_group': 'Standard'}

@pytest.fixture
def low_score_applicant_data() -> dict:
    """Provides data for a low-scoring applicant."""
    return {'name': 'Low Scorer', 'gpa': 1.0, 'extracurricular_score': 1, 'essay_score': 1, 'religious_group': 'Group A'}

@pytest.fixture
def non_standard_applicant_data() -> dict:
    """Provides data for an applicant from a non-majority religious group."""
    return {'name': 'Non-Standard', 'gpa': 3.5, 'extracurricular_score': 8, 'essay_score': 8, 'religious_group': 'Group B'}

@pytest.fixture
def sample_applicant_pool() -> list:
    """Provides a diverse pool of applicant data for comprehensive testing."""
    return [
        {'name': 'Charlie', 'gpa': 4.0, 'extracurricular_score': 10, 'essay_score': 10, 'religious_group': 'Standard'}, # Score: 100.0
        {'name': 'Hannah', 'gpa': 3.7, 'extracurricular_score': 9, 'essay_score': 9, 'religious_group': 'Group C'},     # Score: 92.5
        {'name': 'Diana', 'gpa': 3.8, 'extracurricular_score': 10, 'essay_score': 8, 'religious_group': 'Group B'},      # Score: 91.5
        {'name': 'Alice', 'gpa': 3.9, 'extracurricular_score': 8, 'essay_score': 9, 'religious_group': 'Standard'},     # Score: 91.25
        {'name': 'Fiona', 'gpa': 3.95, 'extracurricular_score': 7, 'essay_score': 8, 'religious_group': 'Group A'},    # Score: 89.875
        {'name': 'Bob', 'gpa': 3.5, 'extracurricular_score': 9, 'essay_score': 7, 'religious_group': 'Group A'},         # Score: 84.5
        {'name': 'Ethan', 'gpa': 3.2, 'extracurricular_score': 6, 'essay_score': 7, 'religious_group': 'Standard'},     # Score: 72.0
        {'name': 'George', 'gpa': 2.8, 'extracurricular_score': 5, 'essay_score': 5, 'religious_group': 'Standard'},     # Score: 60.0
    ]

@pytest.fixture
def tie_score_applicant_pool() -> list:
    """Provides an applicant pool with score ties to test ranking stability."""
    return [
        {'name': 'Top', 'gpa': 4.0, 'extracurricular_score': 10, 'essay_score': 10, 'religious_group': 'Standard'},  # Score: 100.0
        {'name': 'Tied A', 'gpa': 3.8, 'extracurricular_score': 8, 'essay_score': 8, 'religious_group': 'Group A'},   # Score: 88.0
        {'name': 'Tied B', 'gpa': 3.2, 'extracurricular_score': 10, 'essay_score': 10, 'religious_group': 'Standard'}, # Score: 88.0
        {'name': 'Bottom', 'gpa': 2.0, 'extracurricular_score': 5, 'essay_score': 5, 'religious_group': 'Standard'},   # Score: 50.0
    ]

# ==============================================================================
# Unit Tests for Applicant Class
# ==============================================================================

class TestApplicant:
    """Tests for the Applicant data model."""

    def test_applicant_initialization(self, perfect_applicant_data: dict):
        """FR1: Test if applicant data is stored correctly upon initialization."""
        applicant = Applicant(**perfect_applicant_data)

        assert applicant.name == perfect_applicant_data['name']
        assert applicant.gpa == perfect_applicant_data['gpa']
        assert applicant.extracurricular_score == perfect_applicant_data['extracurricular_score']
        assert applicant.essay_score == perfect_applicant_data['essay_score']
        assert applicant.religious_group == perfect_applicant_data['religious_group']

        # Test internal fields' default values
        assert isinstance(applicant.applicant_id, str) and applicant.applicant_id != ""
        assert applicant.viability_score == 0.0
        assert applicant.is_non_standard is False

    def test_applicant_repr(self):
        """Test the __repr__ method for a developer-friendly output."""
        # Mock UUID to have a predictable ID for a deterministic test
        with patch('uuid.uuid4', return_value=uuid.UUID('12345678-1234-5678-1234-567812345678')):
            applicant = Applicant(name='Jane Doe', gpa=4.0, extracurricular_score=9, essay_score=9, religious_group='Group A')
            applicant.viability_score = 94.5
            applicant.is_non_standard = True

        expected_repr = "Applicant(id=12345678-1234-5678-1234-567812345678, name='Jane Doe', score=94.50, is_non_standard=True)"
        assert repr(applicant) == expected_repr

# ==============================================================================
# Unit Tests for ScholarshipManagementSystem Class
# ==============================================================================

class TestScholarshipManagementSystem:
    """Tests for the core logic of the scholarship management system."""

    def test_system_initialization(self, sample_applicant_pool: list):
        """Test if the system initializes correctly with applicant data."""
        system = ScholarshipManagementSystem(sample_applicant_pool, 5)
        assert system.num_scholarships == 5
        assert len(system.applicants) == len(sample_applicant_pool)
        assert all(isinstance(app, Applicant) for app in system.applicants)
        assert system.applicants[0].name == 'Charlie'

    def test_system_initialization_with_no_applicants(self):
        """Edge Case: Test system initialization with an empty applicant list."""
        system = ScholarshipManagementSystem([], 5)
        assert system.num_scholarships == 5
        assert len(system.applicants) == 0

    def test_calculate_viability_score(self, perfect_applicant_data: dict, low_score_applicant_data: dict):
        """FR2: Test the viability score calculation for various scenarios."""
        system = ScholarshipManagementSystem([], 0)

        # Test with perfect scores (boundary condition: max)
        perfect_applicant = Applicant(**perfect_applicant_data)
        perfect_score = system._calculate_viability_score(perfect_applicant)
        assert perfect_score == pytest.approx(100.0)

        # Test with low scores (standard case)
        low_applicant = Applicant(**low_score_applicant_data)
        low_score = system._calculate_viability_score(low_applicant)
        # (1.0/4.0)*0.5 + (1/10)*0.3 + (1/10)*0.2 = 0.125 + 0.03 + 0.02 = 0.175
        # 0.175 * 100 = 17.5
        assert low_score == pytest.approx(17.5)

        # Test with zero scores (boundary condition: min)
        zero_applicant = Applicant(name="Zero", gpa=0.0, extracurricular_score=0, essay_score=0, religious_group="Standard")
        zero_score = system._calculate_viability_score(zero_applicant)
        assert zero_score == pytest.approx(0.0)

    def test_update_applicant_flags(self, perfect_applicant_data: dict, non_standard_applicant_data: dict):
        """FR5: Test the logic for flagging 'non_standard' applicants."""
        system = ScholarshipManagementSystem([], 0)

        # Applicant from majority group should not be flagged
        standard_applicant = Applicant(**perfect_applicant_data)
        system._update_applicant_flags(standard_applicant)
        assert standard_applicant.is_non_standard is False

        # Applicant from non-majority group should be flagged
        non_standard_applicant = Applicant(**non_standard_applicant_data)
        system._update_applicant_flags(non_standard_applicant)
        assert non_standard_applicant.is_non_standard is True

    def test_process_applicants(self, sample_applicant_pool: list):
        """Test the combined processing of scoring and flagging."""
        system = ScholarshipManagementSystem(sample_applicant_pool, 3)
        system._process_applicants()

        charlie = next(app for app in system.applicants if app.name == 'Charlie')
        hannah = next(app for app in system.applicants if app.name == 'Hannah')

        assert charlie.viability_score == pytest.approx(100.0)
        assert charlie.is_non_standard is False

        assert hannah.viability_score == pytest.approx(92.5)
        assert hannah.is_non_standard is True

    def test_rank_applicants(self, sample_applicant_pool: list):
        """FR3: Test if applicants are ranked correctly by score."""
        system = ScholarshipManagementSystem(sample_applicant_pool, 3)
        system._process_applicants()
        system._rank_applicants()

        scores = [app.viability_score for app in system.applicants]
        assert scores == sorted(scores, reverse=True)
        assert system.applicants[0].name == 'Charlie' # Highest score
        assert system.applicants[-1].name == 'George' # Lowest score

    def test_allocate_scholarships_standard_case(self, sample_applicant_pool: list):
        """FR4: Test standard allocation (more applicants than scholarships)."""
        num_scholarships = 3
        system = ScholarshipManagementSystem(sample_applicant_pool, num_scholarships)
        awardees = system.allocate_scholarships()

        assert len(awardees) == num_scholarships
        assert awardees[0].name == 'Charlie'
        assert awardees[1].name == 'Hannah'
        assert awardees[2].name == 'Diana'
        # Check that the internal list is also sorted and reflects the top N
        assert [app.name for app in system.applicants[:3]] == ['Charlie', 'Hannah', 'Diana']

    def test_allocate_scholarships_fewer_applicants_than_scholarships(self, sample_applicant_pool: list):
        """Boundary Case: Test allocation when there are fewer applicants than scholarships."""
        num_scholarships = 10
        num_applicants = len(sample_applicant_pool)
        system = ScholarshipManagementSystem(sample_applicant_pool, num_scholarships)
        awardees = system.allocate_scholarships()

        assert len(awardees) == num_applicants
        assert awardees[0].name == 'Charlie' # Still should be sorted
        assert awardees[-1].name == 'George'

    def test_allocate_scholarships_equal_applicants_and_scholarships(self, sample_applicant_pool: list):
        """Boundary Case: Test allocation when applicant count equals scholarship count."""
        num_scholarships = len(sample_applicant_pool)
        num_applicants = len(sample_applicant_pool)
        system = ScholarshipManagementSystem(sample_applicant_pool, num_scholarships)
        awardees = system.allocate_scholarships()

        assert len(awardees) == num_applicants
        assert awardees[0].name == 'Charlie'

    def test_allocate_scholarships_zero_scholarships(self, sample_applicant_pool: list):
        """Edge Case: Test allocation with zero available scholarships."""
        system = ScholarshipManagementSystem(sample_applicant_pool, 0)
        awardees = system.allocate_scholarships()

        assert len(awardees) == 0

    def test_allocate_scholarships_zero_applicants(self):
        """Edge Case: Test allocation with an empty applicant pool."""
        system = ScholarshipManagementSystem([], 5)
        awardees = system.allocate_scholarships()

        assert len(awardees) == 0

    def test_allocate_scholarships_with_score_ties(self, tie_score_applicant_pool: list):
        """Test allocation when score ties exist at the scholarship cutoff."""
        # Case 1: Cutoff includes all tied applicants
        system_1 = ScholarshipManagementSystem(tie_score_applicant_pool, 3)
        awardees_1 = system_1.allocate_scholarships()
        awardee_names_1 = {app.name for app in awardees_1}

        assert len(awardees_1) == 3
        assert 'Top' in awardee_names_1
        assert 'Tied A' in awardee_names_1
        assert 'Tied B' in awardee_names_1

        # Case 2: Cutoff is in the middle of tied applicants
        system_2 = ScholarshipManagementSystem(tie_score_applicant_pool, 2)
        awardees_2 = system_2.allocate_scholarships()
        awardee_names_2 = {app.name for app in awardees_2}

        assert len(awardees_2) == 2
        assert 'Top' in awardee_names_2
        # Since Python's sort is stable, the first tied applicant in the original
        # list ('Tied A') should be chosen. We verify this behavior.
        assert 'Tied A' in awardee_names_2
        assert 'Tied B' not in awardee_names_2

# ==============================================================================
# Unit Tests for Reporting
# ==============================================================================

class TestReporting:
    """NFR2: Tests for the summary report generation."""

    def test_generate_summary_report_with_awardees(self, capsys):
        """Test the report output when scholarships are awarded."""
        awardees = [
            Applicant(name='Winner One', gpa=4.0, extracurricular_score=10, essay_score=10, religious_group='Standard'),
            Applicant(name='Winner Two', gpa=3.8, extracurricular_score=9, essay_score=9, religious_group='Group A')
        ]
        awardees[0].viability_score = 100.0
        awardees[1].viability_score = 94.0
        total_applicants = 10
        scholarships_available = 5

        generate_summary_report(awardees, total_applicants, scholarships_available)

        captured = capsys.readouterr()
        output = captured.out

        assert "Scholarship Allocation Summary Report" in output
        assert f"Total Applicants Processed: {total_applicants}" in output
        assert f"Scholarships Available: {scholarships_available}" in output
        assert f"Scholarships Awarded: {len(awardees)}" in output
        assert "--- Awarded Applicants ---" in output
        assert "Rank 1: Winner One" in output
        assert "Viability Score: 100.00" in output
        assert "Rank 2: Winner Two" in output
        assert "Viability Score: 94.00" in output
        assert "End of Report" in output

    def test_generate_summary_report_no_awardees(self, capsys):
        """Test the report output when no scholarships are awarded."""
        awardees = []
        total_applicants = 10
        scholarships_available = 0

        generate_summary_report(awardees, total_applicants, scholarships_available)

        captured = capsys.readouterr()
        output = captured.out

        assert "Scholarship Allocation Summary Report" in output
        assert f"Total Applicants Processed: {total_applicants}" in output
        assert f"Scholarships Available: {scholarships_available}" in output
        assert "Scholarships Awarded: 0" in output
        assert "No scholarships were awarded." in output
        assert "--- Awarded Applicants ---" not in output