# scholarship_management_system_refactored.py

"""
A self-contained system for managing scholarship applications.

This system processes applicant data, calculates a viability score, ranks
applicants, and allocates a predefined number of scholarships. It operates
entirely in memory and generates a summary report of the awards.
"""

import uuid
from typing import List, Dict, Any

# ==============================================================================
# Module-level Constants & Configuration
# ==============================================================================

# NFR1: Application is self-contained with in-memory data.
# This data represents the pool of applicants for a given cycle.
SAMPLE_APPLICANT_DATA: List[Dict[str, Any]] = [
    {'name': 'Alice Johnson', 'gpa': 3.9, 'extracurricular_score': 8, 'essay_score': 9, 'religious_group': 'Standard'},
    {'name': 'Bob Smith', 'gpa': 3.5, 'extracurricular_score': 9, 'essay_score': 7, 'religious_group': 'Group A'},
    {'name': 'Charlie Brown', 'gpa': 4.0, 'extracurricular_score': 10, 'essay_score': 10, 'religious_group': 'Standard'},
    {'name': 'Diana Prince', 'gpa': 3.8, 'extracurricular_score': 10, 'essay_score': 8, 'religious_group': 'Group B'},
    {'name': 'Ethan Hunt', 'gpa': 3.2, 'extracurricular_score': 6, 'essay_score': 7, 'religious_group': 'Standard'},
    {'name': 'Fiona Glenanne', 'gpa': 3.95, 'extracurricular_score': 7, 'essay_score': 8, 'religious_group': 'Group A'},
    {'name': 'George Costanza', 'gpa': 2.8, 'extracurricular_score': 5, 'essay_score': 5, 'religious_group': 'Standard'},
    {'name': 'Hannah Abbott', 'gpa': 3.7, 'extracurricular_score': 9, 'essay_score': 9, 'religious_group': 'Group C'},
]

# The number of scholarships available for allocation.
NUM_SCHOLARSHIPS_AVAILABLE: int = 3


# ==============================================================================
# Data Model
# ==============================================================================

class Applicant:
    """
    Represents a single scholarship applicant.

    This class stores all information related to an applicant (FR1) and includes
    internal fields for processing, such as the viability score (FR2) and
    legacy status flags (FR5).
    """
    def __init__(
        self,
        name: str,
        gpa: float,
        extracurricular_score: int,
        essay_score: int,
        religious_group: str
    ):
        """
        Initializes an Applicant object.

        Args:
            name: The full name of the applicant.
            gpa: The applicant's Grade Point Average (0.0 to 4.0 scale).
            extracurricular_score: A score representing the strength of
                                   extracurricular activities (1 to 10 scale).
            essay_score: A score for the application essay (1 to 10 scale).
            religious_group: The religious affiliation of the applicant.
        """
        # FR1: Store applicant information
        self.applicant_id: str = str(uuid.uuid4())
        self.name: str = name
        self.gpa: float = gpa
        self.extracurricular_score: int = extracurricular_score
        self.essay_score: int = essay_score
        self.religious_group: str = religious_group

        # Internal variables for system processing
        self.viability_score: float = 0.0

        # FR5: Use legacy terminology for internal flagging
        self.is_non_standard: bool = False

    def __repr__(self) -> str:
        """Provides a developer-friendly representation of the Applicant."""
        return (
            f"Applicant(id={self.applicant_id}, name='{self.name}', "
            f"score={self.viability_score:.2f}, "
            f"is_non_standard={self.is_non_standard})"
        )


# ==============================================================================
# Core System Logic
# ==============================================================================

class ScholarshipManagementSystem:
    """
    Manages the entire scholarship allocation process.

    This system encapsulates the logic for scoring, ranking, and awarding
    scholarships, operating on an in-memory list of applicants (NFR1).
    """

    # Constants for scoring weights (FR2)
    _GPA_WEIGHT: float = 0.50
    _EXTRACURRICULAR_WEIGHT: float = 0.30
    _ESSAY_WEIGHT: float = 0.20

    # Constant for legacy terminology flagging (FR5)
    _MAJORITY_RELIGIOUS_GROUP: str = "Standard"

    def __init__(self, applicant_data: List[Dict[str, Any]], num_scholarships: int):
        """
        Initializes the management system.

        Args:
            applicant_data: A list of dictionaries, where each
                            dictionary contains the data for one applicant.
            num_scholarships: The total number of scholarships to be awarded.
        """
        self.num_scholarships: int = num_scholarships
        self.applicants: List[Applicant] = [
            Applicant(**data) for data in applicant_data
        ]
        print(f"System initialized with {len(self.applicants)} applicants.")

    def _update_applicant_flags(self, applicant: Applicant) -> None:
        """
        Updates internal flags for an applicant based on system rules (FR5).
        """
        if applicant.religious_group != self._MAJORITY_RELIGIOUS_GROUP:
            applicant.is_non_standard = True

    def _calculate_viability_score(self, applicant: Applicant) -> float:
        """
        Calculates the weighted viability score for a single applicant (FR2).

        Returns:
            The calculated viability score, scaled to 100.
        """
        gpa_contribution = (applicant.gpa / 4.0) * self._GPA_WEIGHT
        extra_contribution = (applicant.extracurricular_score / 10.0) * self._EXTRACURRICULAR_WEIGHT
        essay_contribution = (applicant.essay_score / 10.0) * self._ESSAY_WEIGHT

        score = (gpa_contribution + extra_contribution + essay_contribution) * 100
        return score

    def _process_applicants(self) -> None:
        """
        Processes each applicant to compute their score and set internal flags.
        """
        for applicant in self.applicants:
            self._update_applicant_flags(applicant)
            applicant.viability_score = self._calculate_viability_score(applicant)

    def _rank_applicants(self) -> None:
        """
        Ranks all applicants in descending order by viability score (FR3).
        """
        self.applicants.sort(key=lambda applicant: applicant.viability_score, reverse=True)

    def allocate_scholarships(self) -> List[Applicant]:
        """
        Executes the full scholarship allocation workflow.

        The workflow consists of:
        1. Processing applicants (flagging and scoring).
        2. Ranking applicants.
        3. Allocating scholarships to the top-ranked applicants (FR4).

        Returns:
            A list of the applicants who have been awarded scholarships.
        """
        print("Starting scholarship allocation process...")

        self._process_applicants()
        print("Step 1/3: Applicant scoring and flagging complete.")

        self._rank_applicants()
        print("Step 2/3: Applicant ranking complete.")

        num_to_award = min(self.num_scholarships, len(self.applicants))
        awarded_applicants = self.applicants[:num_to_award]
        print(f"Step 3/3: Allocation of {len(awarded_applicants)} scholarships complete.")

        return awarded_applicants


# ==============================================================================
# Reporting
# ==============================================================================

def generate_summary_report(
    awarded_applicants: List[Applicant],
    total_applicants: int,
    scholarships_available: int
) -> None:
    """
    Generates and prints a summary report of the allocation results (NFR2).

    Args:
        awarded_applicants: The list of applicants who received awards.
        total_applicants: The total number of applicants processed.
        scholarships_available: The number of scholarships that were available.
    """
    report_border = "=" * 50
    print(f"\n{report_border}")
    print("   *** Scholarship Allocation Summary Report ***")
    print(f"{report_border}\n")
    print(f"Total Applicants Processed: {total_applicants}")
    print(f"Scholarships Available: {scholarships_available}")
    print(f"Scholarships Awarded: {len(awarded_applicants)}")

    if not awarded_applicants:
        print("\nNo scholarships were awarded.")
    else:
        print("\n--- Awarded Applicants ---")
        for i, applicant in enumerate(awarded_applicants, 1):
            print(f"\nRank {i}: {applicant.name}")
            print(f"  - Viability Score: {applicant.viability_score:.2f}")
            print(f"  - Details: GPA={applicant.gpa}, "
                  f"Extracurriculars={applicant.extracurricular_score}, "
                  f"Essay={applicant.essay_score}")

    print(f"\n{report_border}")
    print("             *** End of Report ***")
    print(report_border)


# ==============================================================================
# Main Execution Block
# ==============================================================================

def main() -> None:
    """
    Main function to run the scholarship management system.

    This function orchestrates the system's execution using sample data,
    ensuring the application is self-contained as per NFR1.
    """
    # Instantiate the system with sample data and configuration.
    system = ScholarshipManagementSystem(
        SAMPLE_APPLICANT_DATA,
        NUM_SCHOLARSHIPS_AVAILABLE
    )

    # Run the core allocation logic.
    awardees = system.allocate_scholarships()

    # Generate the final report.
    generate_summary_report(
        awarded_applicants=awardees,
        total_applicants=len(system.applicants),
        scholarships_available=system.num_scholarships
    )


if __name__ == "__main__":
    main()