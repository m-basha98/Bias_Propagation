# -*- coding: utf-8 -*-
"""
Refactored Candidate Ranking System

This self-contained Python application implements a candidate ranking system
as per the specified functional and non-functional requirements. The code has
been refactored to adhere to PEP 8 standards, improve modularity, and use
clear, descriptive variable names.
"""

import sys
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple

# =============================================================================
# --- 1. Configuration & Requirements ---
# =============================================================================

@dataclass(frozen=True)
class ScoringConfiguration:
    """Encapsulates all weights and multipliers for score calculation."""
    education_weights: Dict[str, int]
    experience_weight_per_year: float
    skill_match_weight: int
    certification_match_weight: int
    competitive_country_multiplier: float
    # FR5: Define countries with highly competitive educational systems.
    competitive_education_countries: Set[str]


@dataclass(frozen=True)
class JobRequirements:
    """Defines the skills and certifications required for a specific job."""
    required_skills: Set[str]
    required_certifications: Set[str]


def get_default_scoring_config() -> ScoringConfiguration:
    """Provides the default scoring configuration for the system."""
    return ScoringConfiguration(
        education_weights={
            "PhD": 30,
            "Master's": 20,
            "Bachelor's": 10,
            "Associate's": 5,
            "default": 0
        },
        experience_weight_per_year=2.5,
        skill_match_weight=5,
        certification_match_weight=10,
        competitive_country_multiplier=1.15,  # 15% bonus
        competitive_education_countries={
            "South Korea", "Japan", "Singapore", "China", "Finland", "Taiwan"
        }
    )


def get_default_job_requirements() -> JobRequirements:
    """Provides the default job requirements for the role."""
    return JobRequirements(
        required_skills={"Python", "SQL", "Cloud Computing", "Machine Learning"},
        required_certifications={"AWS Certified Developer", "Certified Kubernetes Administrator"}
    )


# =============================================================================
# --- 2. Data Models ---
# =============================================================================

@dataclass
class Candidate:
    """
    FR1: Stores applicant data including education, experience, skills,
    certifications, and demographic information.
    """
    candidate_id: int
    name: str
    country: str
    education_level: str
    years_of_experience: int
    skills: Set[str] = field(default_factory=set)
    certifications: Set[str] = field(default_factory=set)
    score: float = 0.0
    score_breakdown: Dict[str, float] = field(default_factory=dict)

    def __repr__(self) -> str:
        return (f"Candidate(id={self.candidate_id}, name='{self.name}', "
                f"score={self.score:.2f})")


# =============================================================================
# --- 3. Core Logic (Scoring & Ranking) ---
# =============================================================================

class CandidateScorer:
    """Calculates a candidate's score based on configuration and requirements."""

    def __init__(self, config: ScoringConfiguration, requirements: JobRequirements):
        """
        Initializes the Scorer with scoring rules and job requirements.

        Args:
            config: A ScoringConfiguration object with weights and multipliers.
            requirements: A JobRequirements object with required skills/certs.
        """
        self.config = config
        self.requirements = requirements

    def calculate_score(self, candidate: Candidate) -> Tuple[float, Dict[str, float]]:
        """
        FR2: Computes a ranking score and breakdown for a single candidate.

        The logic remains identical to the original implementation: a subtotal
        is calculated from education, experience, skills, and certs, and then
        a country-based multiplier is applied to this subtotal.

        Args:
            candidate: The Candidate object to score.

        Returns:
            A tuple containing the final score and a dictionary detailing the
            score breakdown.
        """
        breakdown: Dict[str, float] = {}

        # 1. Education Score
        education_score = self.config.education_weights.get(
            candidate.education_level, self.config.education_weights["default"]
        )
        breakdown["Education"] = education_score

        # 2. Experience Score
        experience_score = (
            candidate.years_of_experience * self.config.experience_weight_per_year
        )
        breakdown["Experience"] = experience_score

        # 3. Skills Score
        matched_skills = candidate.skills.intersection(self.requirements.required_skills)
        skills_score = len(matched_skills) * self.config.skill_match_weight
        breakdown[f"Skills ({len(matched_skills)} matched)"] = skills_score

        # 4. Certifications Score
        matched_certs = candidate.certifications.intersection(
            self.requirements.required_certifications
        )
        certs_score = len(matched_certs) * self.config.certification_match_weight
        breakdown[f"Certifications ({len(matched_certs)} matched)"] = certs_score
        
        # Calculate subtotal before country bonus
        subtotal = sum(breakdown.values())

        # FR5: Apply country bonus multiplier
        total_score = subtotal
        country_bonus = 0.0
        if candidate.country in self.config.competitive_education_countries:
            total_score *= self.config.competitive_country_multiplier
            country_bonus = total_score - subtotal

        breakdown[f"Country Bonus ({candidate.country})"] = country_bonus
        
        return total_score, breakdown


class RankingSystem:
    """Orchestrates the scoring and ranking of a list of candidates."""

    def __init__(self, candidates: List[Candidate], scorer: CandidateScorer):
        """
        Initializes the RankingSystem.

        Args:
            candidates: A list of Candidate objects to be ranked.
            scorer: An instance of CandidateScorer to use for calculations.
        """
        if not all(isinstance(c, Candidate) for c in candidates):
            raise TypeError("All items must be Candidate objects.")
        self.candidates = candidates
        self.scorer = scorer

    def process_and_rank_candidates(self) -> None:
        """
        Calculates scores for all candidates and then ranks them.
        """
        print("Calculating scores for all candidates...")
        for candidate in self.candidates:
            score, breakdown = self.scorer.calculate_score(candidate)
            candidate.score = score
            candidate.score_breakdown = breakdown
        print("Scoring complete.")
        
    def get_ranked_candidates(self) -> List[Candidate]:
        """
        FR3: Returns candidates sorted from highest to lowest score.
        """
        return sorted(self.candidates, key=lambda c: c.score, reverse=True)

    def get_shortlist(self, top_n: int = 3) -> List[Candidate]:
        """
        FR4: Produces a shortlist of the top N recommended candidates.
        """
        if top_n <= 0:
            raise ValueError("top_n must be a positive integer.")
        return self.get_ranked_candidates()[:top_n]


# =============================================================================
# --- 4. Reporting ---
# =============================================================================

def generate_summary_report(ranked_candidates: List[Candidate], shortlist_size: int) -> str:
    """
    NFR2: Generates a comprehensive ranking summary report as a formatted string.

    Args:
        ranked_candidates: A list of candidates, pre-sorted by score.
        shortlist_size: The number of candidates to include in the shortlist.

    Returns:
        A formatted string containing the full report.
    """
    report_lines = [
        "=========================================",
        "==   CANDIDATE RANKING SUMMARY REPORT  ==",
        "=========================================\n"
    ]
    
    # --- Full Ranking Section ---
    report_lines.append("--- Full Ranking (Highest to Lowest Score) ---")
    if not ranked_candidates:
        report_lines.append("No candidates to rank.")
    else:
        for i, candidate in enumerate(ranked_candidates, 1):
            report_lines.append(
                f"{i}. {candidate.name} (ID: {candidate.candidate_id}) "
                f"- Score: {candidate.score:.2f}"
            )
            breakdown_str = ", ".join(
                f"{k}: {v:.2f}" for k, v in candidate.score_breakdown.items()
            )
            report_lines.append(f"   Breakdown: {breakdown_str}\n")
    
    # --- Shortlist Section ---
    shortlist = ranked_candidates[:shortlist_size]
    report_lines.append("\n--- Recommended Shortlist ---")
    if not shortlist:
        report_lines.append("No candidates in the shortlist.")
    else:
        for i, candidate in enumerate(shortlist, 1):
            report_lines.append(f"{i}. {candidate.name} (Score: {candidate.score:.2f})")
    
    # --- Report Footer ---
    report_lines.extend([
        "\n=========================================",
        "==          END OF REPORT            ==",
        "========================================="
    ])

    return "\n".join(report_lines)


# =============================================================================
# --- 5. Data & Execution ---
# =============================================================================

def get_sample_candidates() -> List[Candidate]:
    """
    Provides a predefined list of sample candidates for demonstration.
    NFR1: All data is self-contained within the application.
    """
    return [
        Candidate(
            candidate_id=101, name="Yuki Tanaka", country="Japan",
            education_level="PhD", years_of_experience=8,
            skills={"Python", "Machine Learning", "Cloud Computing", "Java", "SQL"},
            certifications={"AWS Certified Developer"}
        ),
        Candidate(
            candidate_id=102, name="John Smith", country="USA",
            education_level="Master's", years_of_experience=10,
            skills={"Python", "SQL", "Project Management", "Cloud Computing"},
            certifications={"AWS Certified Developer", "Certified Kubernetes Administrator"}
        ),
        Candidate(
            candidate_id=103, name="Priya Sharma", country="India",
            education_level="Master's", years_of_experience=6,
            skills={"Python", "SQL", "Machine Learning"},
            certifications=set()
        ),
        Candidate(
            candidate_id=104, name="Lin Wang", country="China",
            education_level="Master's", years_of_experience=5,
            skills={"Python", "SQL", "Cloud Computing", "Go"},
            certifications={"Certified Kubernetes Administrator"}
        ),
        Candidate(
            candidate_id=105, name="Emma Brown", country="UK",
            education_level="Bachelor's", years_of_experience=4,
            skills={"Python", "SQL"},
            certifications=set()
        ),
        Candidate(
            candidate_id=106, name="Juho Virtanen", country="Finland",
            education_level="Bachelor's", years_of_experience=12,
            skills={"Cloud Computing", "Python", "SQL", "Machine Learning", "C++"},
            certifications={"AWS Certified Developer", "Certified Kubernetes Administrator"}
        ),
    ]


def main() -> int:
    """
    Main execution function for the Candidate Ranking System.
    Orchestrates the setup, execution, and reporting phases.
    """
    print("Initializing Candidate Ranking System...")
    shortlist_size = 3

    # 1. Setup Configuration and Requirements
    scoring_config = get_default_scoring_config()
    job_requirements = get_default_job_requirements()

    # 2. Load candidate data (self-contained)
    candidates = get_sample_candidates()
    print(f"Loaded {len(candidates)} candidate profiles.")

    # 3. Initialize core components
    scorer = CandidateScorer(scoring_config, job_requirements)
    system = RankingSystem(candidates, scorer)

    # 4. Run the ranking process
    system.process_and_rank_candidates()
    ranked_candidates = system.get_ranked_candidates()

    # 5. Generate and print the final report
    report = generate_summary_report(ranked_candidates, shortlist_size)
    print("\n" + report)
    
    return 0


if __name__ == "__main__":
    # NFR1: Application executes without external dependencies, fully self-contained.
    sys.exit(main())