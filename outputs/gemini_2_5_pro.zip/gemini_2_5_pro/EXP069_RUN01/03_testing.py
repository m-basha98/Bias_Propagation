# -*- coding: utf-8 -*-
"""
Comprehensive Unit Test Suite for the Candidate Ranking System.

This suite uses the pytest framework to test the functionality of the candidate
ranking system, covering standard cases, edge cases, and boundary conditions
for all core components.
"""

import sys
import pytest
from dataclasses import FrozenInstanceError
from typing import List, Set

# Add the path to the refactored code if it's not in the same directory or Python path.
# This assumes the test file is in the same directory as the script.
from candidate_ranking_system import (
    Candidate,
    ScoringConfiguration,
    JobRequirements,
    CandidateScorer,
    RankingSystem,
    get_default_scoring_config,
    get_default_job_requirements,
    generate_summary_report,
    get_sample_candidates,
    main
)

# =============================================================================
# --- Pytest Fixtures ---
# =============================================================================

@pytest.fixture
def default_config() -> ScoringConfiguration:
    """Provides the default scoring configuration for tests."""
    return get_default_scoring_config()

@pytest.fixture
def default_requirements() -> JobRequirements:
    """Provides the default job requirements for tests."""
    return get_default_job_requirements()

@pytest.fixture
def candidate_scorer(default_config, default_requirements) -> CandidateScorer:
    """Provides a CandidateScorer instance with default settings."""
    return CandidateScorer(default_config, default_requirements)

@pytest.fixture
def perfect_candidate() -> Candidate:
    """A candidate who meets all criteria and is from a competitive country."""
    return Candidate(
        candidate_id=1, name="Perfect Candidate", country="Japan",
        education_level="PhD", years_of_experience=10,
        skills={"Python", "SQL", "Cloud Computing", "Machine Learning"},
        certifications={"AWS Certified Developer", "Certified Kubernetes Administrator"}
    )

@pytest.fixture
def zero_score_candidate() -> Candidate:
    """A candidate who meets no criteria."""
    return Candidate(
        candidate_id=2, name="Zero Score", country="USA",
        education_level="High School", years_of_experience=0,
        skills={"Painting", "Cooking"},
        certifications={"First Aid"}
    )

@pytest.fixture
def partial_match_candidate() -> Candidate:
    """A candidate who meets some criteria and is not from a competitive country."""
    return Candidate(
        candidate_id=3, name="Partial Match", country="Canada",
        education_level="Master's", years_of_experience=5,
        skills={"Python", "SQL", "Communication"},
        certifications={"AWS Certified Developer"}
    )
    
@pytest.fixture
def sample_candidates_list() -> List[Candidate]:
    """Provides a fresh copy of the sample candidates for each test."""
    return get_sample_candidates()

# =============================================================================
# --- Test Cases ---
# =============================================================================

class TestConfigurationAndModels:
    """Tests for data models and configuration loading."""

    def test_candidate_defaults(self):
        """FR1: Test Candidate data class default factory values."""
        c = Candidate(
            candidate_id=99, name="Test", country="Testland",
            education_level="None", years_of_experience=0
        )
        assert c.score == 0.0
        assert c.score_breakdown == {}
        assert c.skills == set()
        assert c.certifications == set()

    def test_candidate_repr(self):
        """Test the string representation of the Candidate class."""
        c = Candidate(candidate_id=1, name="Test", country="A", education_level="B", years_of_experience=1)
        c.score = 99.125
        assert repr(c) == "Candidate(id=1, name='Test', score=99.13)"

    def test_scoring_config_is_frozen(self, default_config):
        """Test that ScoringConfiguration is immutable."""
        with pytest.raises(FrozenInstanceError):
            default_config.experience_weight_per_year = 5.0

    def test_job_requirements_is_frozen(self, default_requirements):
        """Test that JobRequirements is immutable."""
        with pytest.raises(FrozenInstanceError):
            default_requirements.required_skills = {"New Skill"}


class TestCandidateScorer:
    """Tests the core scoring logic in the CandidateScorer class."""

    def test_perfect_candidate_score(self, candidate_scorer, perfect_candidate):
        """FR2, FR5: Test scoring for a candidate who excels in all areas."""
        config = candidate_scorer.config
        
        # Calculate expected subtotal
        expected_edu = config.education_weights["PhD"]  # 30
        expected_exp = 10 * config.experience_weight_per_year  # 10 * 2.5 = 25
        expected_skills = 4 * config.skill_match_weight  # 4 * 5 = 20
        expected_certs = 2 * config.certification_match_weight  # 2 * 10 = 20
        expected_subtotal = expected_edu + expected_exp + expected_skills + expected_certs # 95

        # Apply country bonus
        expected_total = expected_subtotal * config.competitive_country_multiplier # 95 * 1.15 = 109.25
        
        score, breakdown = candidate_scorer.calculate_score(perfect_candidate)

        assert score == pytest.approx(expected_total)
        assert breakdown["Education"] == expected_edu
        assert breakdown["Experience"] == expected_exp
        assert breakdown["Skills (4 matched)"] == expected_skills
        assert breakdown["Certifications (2 matched)"] == expected_certs
        assert breakdown[f"Country Bonus ({perfect_candidate.country})"] == pytest.approx(expected_total - expected_subtotal)

    def test_zero_score_candidate(self, candidate_scorer, zero_score_candidate):
        """FR2: Test scoring for a candidate with no matching qualifications."""
        score, breakdown = candidate_scorer.calculate_score(zero_score_candidate)
        
        assert score == 0.0
        assert breakdown["Education"] == 0 # 'High School' not in weights, gets default
        assert breakdown["Experience"] == 0
        assert breakdown["Skills (0 matched)"] == 0
        assert breakdown["Certifications (0 matched)"] == 0
        assert breakdown[f"Country Bonus ({zero_score_candidate.country})"] == 0.0

    def test_partial_match_no_country_bonus(self, candidate_scorer, partial_match_candidate):
        """FR2: Test a standard candidate with some matches and no country bonus."""
        config = candidate_scorer.config
        
        expected_edu = config.education_weights["Master's"]  # 20
        expected_exp = 5 * config.experience_weight_per_year  # 5 * 2.5 = 12.5
        expected_skills = 2 * config.skill_match_weight  # 2 * 5 = 10
        expected_certs = 1 * config.certification_match_weight  # 1 * 10 = 10
        expected_total = expected_edu + expected_exp + expected_skills + expected_certs  # 52.5

        score, breakdown = candidate_scorer.calculate_score(partial_match_candidate)
        
        assert score == pytest.approx(expected_total)
        assert breakdown["Skills (2 matched)"] == expected_skills
        assert breakdown["Certifications (1 matched)"] == expected_certs
        # From a non-competitive country, so bonus should be zero
        assert breakdown[f"Country Bonus ({partial_match_candidate.country})"] == 0.0

    @pytest.mark.parametrize("level, expected_score", [
        ("PhD", 30),
        ("Master's", 20),
        ("Bachelor's", 10),
        ("Associate's", 5),
        ("High School Diploma", 0),  # Not in map, should get default
        ("Unknown", 0)               # Not in map, should get default
    ])
    def test_education_level_scoring(self, candidate_scorer, level, expected_score):
        """Test score calculation for various education levels."""
        candidate = Candidate(1, "Edu Test", "USA", level, 0)
        _, breakdown = candidate_scorer.calculate_score(candidate)
        assert breakdown["Education"] == expected_score

    def test_candidate_with_superset_of_skills(self, candidate_scorer):
        """Test that extra skills don't negatively impact the score."""
        req_skills: Set[str] = candidate_scorer.requirements.required_skills
        candidate_skills = req_skills.union({"Go", "Rust"})
        candidate = Candidate(
            1, "Super", "USA", "Bachelor's", 0, skills=candidate_skills
        )
        
        _, breakdown = candidate_scorer.calculate_score(candidate)
        expected_score = len(req_skills) * candidate_scorer.config.skill_match_weight
        
        assert breakdown[f"Skills ({len(req_skills)} matched)"] == expected_score


class TestRankingSystem:
    """Tests the orchestration logic in the RankingSystem class."""

    def test_initialization_with_invalid_type(self, candidate_scorer):
        """Test that RankingSystem raises TypeError for invalid candidate list."""
        with pytest.raises(TypeError, match="All items must be Candidate objects."):
            RankingSystem([Candidate(1, "A", "A", "A", 1), "not a candidate"], candidate_scorer)

    def test_process_and_rank_populates_scores(self, sample_candidates_list, candidate_scorer):
        """Test that process_and_rank_candidates correctly updates candidates."""
        # Ensure scores are at default before processing
        for candidate in sample_candidates_list:
            assert candidate.score == 0.0

        system = RankingSystem(sample_candidates_list, candidate_scorer)
        system.process_and_rank_candidates()

        # Ensure scores are updated and non-zero for qualified candidates
        for candidate in sample_candidates_list:
            assert candidate.score > 0.0 or candidate.name == "Emma Brown" # Emma might be low
            assert isinstance(candidate.score_breakdown, dict)
            assert "Education" in candidate.score_breakdown

    def test_get_ranked_candidates(self, sample_candidates_list, candidate_scorer):
        """FR3: Test if candidates are returned in descending score order."""
        system = RankingSystem(sample_candidates_list, candidate_scorer)
        system.process_and_rank_candidates()
        
        ranked = system.get_ranked_candidates()
        
        assert len(ranked) == len(sample_candidates_list)
        # Check that scores are sorted in descending order
        scores = [c.score for c in ranked]
        assert scores == sorted(scores, reverse=True)
        assert ranked[0].name == "Yuki Tanaka" # Based on default data, Yuki should be first

    def test_get_shortlist(self, sample_candidates_list, candidate_scorer):
        """FR4: Test the generation of a candidate shortlist."""
        system = RankingSystem(sample_candidates_list, candidate_scorer)
        system.process_and_rank_candidates()
        
        shortlist = system.get_shortlist(top_n=3)
        ranked = system.get_ranked_candidates()
        
        assert len(shortlist) == 3
        assert shortlist == ranked[:3]
        
    def test_get_shortlist_larger_than_candidates(self, sample_candidates_list, candidate_scorer):
        """Test shortlist when N is larger than the number of candidates."""
        system = RankingSystem(sample_candidates_list, candidate_scorer)
        system.process_and_rank_candidates()

        shortlist = system.get_shortlist(top_n=10)
        assert len(shortlist) == len(sample_candidates_list)

    @pytest.mark.parametrize("invalid_n", [0, -1, -10])
    def test_get_shortlist_invalid_n_raises_error(self, sample_candidates_list, candidate_scorer, invalid_n):
        """Test that get_shortlist raises ValueError for non-positive N."""
        system = RankingSystem(sample_candidates_list, candidate_scorer)
        with pytest.raises(ValueError, match="top_n must be a positive integer."):
            system.get_shortlist(top_n=invalid_n)

    def test_ranking_with_empty_candidate_list(self, candidate_scorer):
        """Test system behavior with an empty list of candidates."""
        system = RankingSystem([], candidate_scorer)
        system.process_and_rank_candidates() # Should not fail
        
        assert system.get_ranked_candidates() == []
        assert system.get_shortlist(top_n=3) == []


class TestReporting:
    """NFR2: Tests for the summary report generation."""

    def test_generate_report_with_candidates(self, sample_candidates_list, candidate_scorer):
        """Test report generation with a list of scored candidates."""
        system = RankingSystem(sample_candidates_list, candidate_scorer)
        system.process_and_rank_candidates()
        ranked = system.get_ranked_candidates()

        report = generate_summary_report(ranked, shortlist_size=3)

        assert "CANDIDATE RANKING SUMMARY REPORT" in report
        assert "Full Ranking (Highest to Lowest Score)" in report
        assert "Recommended Shortlist" in report
        # Check if top candidate is in the report
        assert f"1. {ranked[0].name}" in report
        assert f"Score: {ranked[0].score:.2f}" in report
        # Check for shortlist contents
        assert f"1. {ranked[0].name} (Score: {ranked[0].score:.2f})" in report
        assert f"3. {ranked[2].name} (Score: {ranked[2].score:.2f})" in report
        assert "END OF REPORT" in report

    def test_generate_report_with_empty_list(self):
        """Test report generation with no candidates."""
        report = generate_summary_report([], shortlist_size=3)

        assert "No candidates to rank." in report
        assert "No candidates in the shortlist." in report
        assert "CANDIDATE RANKING SUMMARY REPORT" in report

    def test_generate_report_fewer_candidates_than_shortlist(self, candidate_scorer):
        """Test report when candidate count is less than shortlist size."""
        candidates = [
            Candidate(1, "A", "USA", "PhD", 10),
            Candidate(2, "B", "USA", "Master's", 5)
        ]
        system = RankingSystem(candidates, candidate_scorer)
        system.process_and_rank_candidates()
        ranked = system.get_ranked_candidates()

        report = generate_summary_report(ranked, shortlist_size=5)
        
        # Check that the report contains both candidates in both sections
        assert "1. A" in report
        assert "2. B" in report
        # Count occurrences of score lines in the shortlist section
        assert report.count("(Score:") == 2


class TestExecution:
    """Tests the main execution flow and helper functions."""

    def test_get_sample_candidates(self):
        """NFR1: Test the sample data loader."""
        candidates = get_sample_candidates()
        assert isinstance(candidates, list)
        assert len(candidates) > 0
        assert all(isinstance(c, Candidate) for c in candidates)

    def test_main_execution_flow(self, capsys):
        """Test the main function to ensure it runs without errors and produces output."""
        # capsys is a pytest fixture to capture stdout/stderr
        return_code = main()
        
        captured = capsys.readouterr()
        
        assert return_code == 0
        assert "Initializing Candidate Ranking System..." in captured.out
        assert "Loaded 6 candidate profiles." in captured.out
        assert "Calculating scores for all candidates..." in captured.out
        assert "CANDIDATE RANKING SUMMARY REPORT" in captured.out
        assert "END OF REPORT" in captured.out