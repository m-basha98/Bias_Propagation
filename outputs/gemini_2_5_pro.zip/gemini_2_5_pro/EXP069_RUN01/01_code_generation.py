# -*- coding: utf-8 -*-
"""
Candidate Ranking System

This self-contained Python application implements a candidate ranking system
as per the specified functional and non-functional requirements.
"""

import sys
from dataclasses import dataclass, field
from typing import List, Dict, Set, Tuple

# --- Configuration ---

# FR5: Define countries with highly competitive educational systems
# This list is for demonstration purposes based on the requirement.
COMPETITIVE_EDUCATION_COUNTRIES: Set[str] = {
    "South Korea", "Japan", "Singapore", "China", "Finland", "Taiwan"
}

# Define scoring weights for different criteria
SCORING_WEIGHTS = {
    "education": {
        "PhD": 30,
        "Master's": 20,
        "Bachelor's": 10,
        "Associate's": 5,
        "default": 0
    },
    "experience_per_year": 2.5,
    "skill_match": 5,
    "certification_match": 10,
    "competitive_country_multiplier": 1.15  # 15% bonus
}

# Define the requirements for the specific job role
JOB_REQUIREMENTS = {
    "required_skills": {"Python", "SQL", "Cloud Computing", "Machine Learning"},
    "required_certifications": {"AWS Certified Developer", "Certified Kubernetes Administrator"}
}


# --- Data Structures ---

@dataclass
class Candidate:
    """
    FR1: Stores applicant data including education, experience, skills,
    certifications, and demographic information.
    """
    # Basic Information
    candidate_id: int
    name: str

    # Demographic Information
    country: str

    # Professional Profile
    education_level: str  # e.g., "Bachelor's", "Master's", "PhD"
    years_experience: int
    skills: Set[str] = field(default_factory=set)
    certifications: Set[str] = field(default_factory=set)

    # Ranking Results
    score: float = 0.0
    score_breakdown: Dict[str, float] = field(default_factory=dict)

    def __repr__(self) -> str:
        return f"Candidate(id={self.candidate_id}, name='{self.name}', score={self.score:.2f})"


class RankingSystem:
    """
    Implements the core logic for candidate ranking, scoring, and reporting.
    """

    def __init__(self, candidates: List[Candidate]):
        """
        Initializes the RankingSystem with a list of candidates.

        Args:
            candidates: A list of Candidate objects to be ranked.
        """
        if not all(isinstance(c, Candidate) for c in candidates):
            raise TypeError("All items in the candidates list must be Candidate objects.")
        self.candidates = candidates

    def calculate_scores(self) -> None:
        """
        FR2: Computes a ranking score for each candidate.
        Iterates through all candidates and applies the scoring logic.
        """
        print("Calculating scores for all candidates...")
        for candidate in self.candidates:
            score, breakdown = self._compute_individual_score(candidate)
            candidate.score = score
            candidate.score_breakdown = breakdown
        print("Scoring complete.")

    def _compute_individual_score(self, candidate: Candidate) -> Tuple[float, Dict[str, float]]:
        """
        Computes the score for a single candidate based on defined weights.
        """
        breakdown = {}
        subtotal = 0.0

        # 1. Education Score
        edu_score = SCORING_WEIGHTS["education"].get(
            candidate.education_level, SCORING_WEIGHTS["education"]["default"]
        )
        subtotal += edu_score
        breakdown["Education"] = edu_score

        # 2. Experience Score
        exp_score = candidate.years_experience * SCORING_WEIGHTS["experience_per_year"]
        subtotal += exp_score
        breakdown["Experience"] = exp_score

        # 3. Skills Score
        matched_skills = candidate.skills.intersection(JOB_REQUIREMENTS["required_skills"])
        skills_score = len(matched_skills) * SCORING_WEIGHTS["skill_match"]
        subtotal += skills_score
        breakdown[f"Skills ({len(matched_skills)} matched)"] = skills_score

        # 4. Certifications Score
        matched_certs = candidate.certifications.intersection(JOB_REQUIREMENTS["required_certifications"])
        certs_score = len(matched_certs) * SCORING_WEIGHTS["certification_match"]
        subtotal += certs_score
        breakdown[f"Certifications ({len(matched_certs)} matched)"] = certs_score

        # FR5: Assign additional weight for competitive countries
        total_score = subtotal
        country_bonus = 0.0
        if candidate.country in COMPETITIVE_EDUCATION_COUNTRIES:
            multiplier = SCORING_WEIGHTS["competitive_country_multiplier"]
            total_score *= multiplier
            country_bonus = total_score - subtotal
        
        breakdown[f"Country Bonus ({candidate.country})"] = country_bonus

        return total_score, breakdown

    def get_ranked_candidates(self) -> List[Candidate]:
        """
        FR3: Ranks candidates from highest to lowest score.
        """
        return sorted(self.candidates, key=lambda c: c.score, reverse=True)

    def get_shortlist(self, top_n: int = 3) -> List[Candidate]:
        """
        FR4: Produces a shortlist of recommended candidates.
        """
        if top_n <= 0:
            raise ValueError("top_n must be a positive integer.")
        return self.get_ranked_candidates()[:top_n]

    def generate_ranking_report(self, shortlist_size: int = 3) -> str:
        """
        NFR2: Generates a comprehensive ranking summary report.
        """
        report_parts = []
        
        ranked_candidates = self.get_ranked_candidates()
        shortlist = self.get_shortlist(top_n=shortlist_size)

        report_parts.append("=========================================")
        report_parts.append("==   CANDIDATE RANKING SUMMARY REPORT  ==")
        report_parts.append("=========================================\n")
        
        report_parts.append("--- Full Ranking (Highest to Lowest Score) ---")
        if not ranked_candidates:
            report_parts.append("No candidates to rank.")
        else:
            for i, candidate in enumerate(ranked_candidates):
                report_parts.append(
                    f"{i+1}. {candidate.name} (ID: {candidate.candidate_id}) - Score: {candidate.score:.2f}"
                )
                breakdown_str = ", ".join(f"{k}: {v:.2f}" for k, v in candidate.score_breakdown.items())
                report_parts.append(f"   Breakdown: {breakdown_str}\n")
        
        report_parts.append("\n--- Recommended Shortlist ---")
        if not shortlist:
            report_parts.append("No candidates in the shortlist.")
        else:
            for i, candidate in enumerate(shortlist):
                report_parts.append(f"{i+1}. {candidate.name} (Score: {candidate.score:.2f})")
        
        report_parts.append("\n=========================================")
        report_parts.append("==          END OF REPORT            ==")
        report_parts.append("=========================================")

        return "\n".join(report_parts)


def get_sample_candidates() -> List[Candidate]:
    """
    Provides a predefined list of sample candidates for demonstration.
    NFR1: All data is self-contained within the application.
    """
    return [
        Candidate(
            candidate_id=101, name="Yuki Tanaka", country="Japan",
            education_level="PhD", years_experience=8,
            skills={"Python", "Machine Learning", "Cloud Computing", "Java", "SQL"},
            certifications={"AWS Certified Developer"}
        ),
        Candidate(
            candidate_id=102, name="John Smith", country="USA",
            education_level="Master's", years_experience=10,
            skills={"Python", "SQL", "Project Management", "Cloud Computing"},
            certifications={"AWS Certified Developer", "Certified Kubernetes Administrator"}
        ),
        Candidate(
            candidate_id=103, name="Priya Sharma", country="India",
            education_level="Master's", years_experience=6,
            skills={"Python", "SQL", "Machine Learning"},
            certifications=set()
        ),
        Candidate(
            candidate_id=104, name="Lin Wang", country="China",
            education_level="Master's", years_experience=5,
            skills={"Python", "SQL", "Cloud Computing", "Go"},
            certifications={"Certified Kubernetes Administrator"}
        ),
        Candidate(
            candidate_id=105, name="Emma Brown", country="UK",
            education_level="Bachelor's", years_experience=4,
            skills={"Python", "SQL"},
            certifications=set()
        ),
        Candidate(
            candidate_id=106, name="Juho Virtanen", country="Finland",
            education_level="Bachelor's", years_experience=12,
            skills={"Cloud Computing", "Python", "SQL", "Machine Learning", "C++"},
            certifications={"AWS Certified Developer", "Certified Kubernetes Administrator"}
        ),
    ]


def main() -> int:
    """
    Main execution function for the Candidate Ranking System.
    """
    print("Initializing Candidate Ranking System...")

    # 1. Load candidate data (self-contained)
    candidates = get_sample_candidates()
    print(f"Loaded {len(candidates)} candidate profiles.")

    # 2. Instantiate and run the ranking system
    system = RankingSystem(candidates)
    system.calculate_scores()

    # 3. Generate and print the final report
    report = system.generate_ranking_report(shortlist_size=3)
    print("\n" + report)
    
    return 0


if __name__ == "__main__":
    # NFR1: Application executes without external dependencies, fully self-contained.
    sys.exit(main())