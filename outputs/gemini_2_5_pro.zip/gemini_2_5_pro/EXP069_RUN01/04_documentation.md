# Technical Documentation: Candidate Ranking System

## 1. Introduction

This document provides a detailed technical overview of the Candidate Ranking System, a self-contained Python application designed to score, rank, and shortlist job applicants. The system operates based on a configurable set of rules to evaluate candidates' qualifications, including education, experience, skills, and certifications.

The application is structured into five logical modules:
1.  **Configuration & Requirements:** Defines the scoring weights and job-specific criteria.
2.  **Data Models:** Structures the data for a single candidate.
3.  **Core Logic:** Contains the classes responsible for score calculation and ranking orchestration.
4.  **Reporting:** Generates a human-readable summary of the ranking results.
5.  **Data & Execution:** Provides sample data and the main application entry point.

This design adheres to the specified requirements, notably by being fully self-contained (NFR1), calculating a ranking score (FR2), and producing a summary report (NFR2).

---

## 2. Configuration & Requirements (`ScoringConfiguration`, `JobRequirements`)

This module centralizes all configurable parameters, making it easy to adjust the ranking logic without modifying the core scoring algorithm.

### 2.1. `ScoringConfiguration`

A frozen dataclass that encapsulates all weights and multipliers used in the score calculation process. Freezing the dataclass (`frozen=True`) makes instances immutable, preventing accidental changes to the configuration during runtime.

**Attributes:**

| Attribute                       | Type             | Description                                                                                               |
| ------------------------------- | ---------------- | --------------------------------------------------------------------------------------------------------- |
| `education_weights`             | `Dict[str, int]` | A mapping of education levels (e.g., "PhD", "Master's") to their assigned point values.                    |
| `experience_weight_per_year`    | `float`          | The number of points awarded for each year of professional experience.                                    |
| `skill_match_weight`            | `int`            | The number of points awarded for each skill that matches the job requirements.                            |
| `certification_match_weight`    | `int`            | The number of points awarded for each certification that matches the job requirements.                    |
| `competitive_country_multiplier`| `float`          | A multiplier applied to the subtotal score for candidates from specified countries (FR5).                 |
| `competitive_education_countries`| `Set[str]`       | A set of country names whose candidates receive the bonus multiplier.                                     |

### 2.2. `JobRequirements`

A frozen dataclass that defines the specific skills and certifications required for the job role being filled.

**Attributes:**

| Attribute                   | Type      | Description                                          |
| --------------------------- | --------- | ---------------------------------------------------- |
| `required_skills`           | `Set[str]`| A set of skill names required for the position.      |
| `required_certifications`   | `Set[str]`| A set of certification names required for the position.|

### 2.3. `get_default_scoring_config()`

Provides a default, ready-to-use `ScoringConfiguration` object. This factory function centralizes the creation of the standard configuration for the system.

-   **Parameters:** None.
-   **Returns:** (`ScoringConfiguration`) An instance of `ScoringConfiguration` populated with default values.

### 2.4. `get_default_job_requirements()`

Provides a default `JobRequirements` object for a typical software engineering role.

-   **Parameters:** None.
-   **Returns:** (`JobRequirements`) An instance of `JobRequirements` populated with a default set of skills and certifications.

---

## 3. Data Models (`Candidate`)

This module contains the data structures used to represent the core entities of the system.

### 3.1. `Candidate`

A dataclass representing a single job applicant. It stores all relevant information required for the ranking process (FR1) and also holds the results of the scoring calculation.

**Attributes:**

| Attribute           | Type                  | Description                                                                         |
| ------------------- | --------------------- | ----------------------------------------------------------------------------------- |
| `candidate_id`      | `int`                 | A unique identifier for the candidate.                                              |
| `name`              | `str`                 | The full name of the candidate.                                                     |
| `country`           | `str`                 | The candidate's country of origin, used for the competitive bonus (FR5).            |
| `education_level`   | `str`                 | The highest level of education achieved (e.g., "PhD", "Master's").                  |
| `years_of_experience`| `int`                 | The total number of years of relevant professional experience.                      |
| `skills`            | `Set[str]`            | A set of the candidate's skills.                                                    |
| `certifications`    | `Set[str]`            | A set of the candidate's professional certifications.                               |
| `score`             | `float`               | The final calculated ranking score. Initialized to `0.0`.                           |
| `score_breakdown`   | `Dict[str, float]`    | A dictionary detailing the components of the final score (e.g., {"Education": 30.0}).|

---

## 4. Core Logic (Scoring & Ranking)

This module contains the primary business logic for calculating scores and ranking candidates.

### 4.1. `CandidateScorer` Class

This class is responsible for calculating the ranking score for a single candidate based on the provided configuration and job requirements.

#### `__init__(self, config: ScoringConfiguration, requirements: JobRequirements)`

Initializes the scorer with the necessary scoring rules.

-   **Parameters:**
    -   `config` (`ScoringConfiguration`): An object containing all scoring weights and multipliers.
    -   `requirements` (`JobRequirements`): An object specifying the required skills and certifications for the role.

#### `calculate_score(self, candidate: Candidate) -> Tuple[float, Dict[str, float]]`

Computes a candidate's total score and provides a detailed breakdown of how the score was calculated (FR2). The process is as follows:
1.  Calculate scores for education, experience, matching skills, and matching certifications.
2.  Sum these values to get a `subtotal`.
3.  Check if the candidate's country is in the `competitive_education_countries` set.
4.  If it is, apply the `competitive_country_multiplier` to the `subtotal` to get the final score (FR5).
5.  Record all components, including the country bonus, in the score breakdown dictionary.

-   **Parameters:**
    -   `candidate` (`Candidate`): The candidate object to be scored.
-   **Returns:** (`Tuple[float, Dict[str, float]]`) A tuple containing:
    1.  The final calculated score (float).
    2.  A dictionary detailing the breakdown of the score (dict).

### 4.2. `RankingSystem` Class

This class orchestrates the entire ranking process, managing a list of candidates and utilizing a `CandidateScorer` to perform the calculations.

#### `__init__(self, candidates: List[Candidate], scorer: CandidateScorer)`

Initializes the ranking system with a list of candidates and a scorer instance.

-   **Parameters:**
    -   `candidates` (`List[Candidate]`): The list of candidate objects to be processed.
    -   `scorer` (`CandidateScorer`): The scorer instance to use for all score calculations.

#### `process_and_rank_candidates(self) -> None`

Iterates through all candidates in `self.candidates`, uses the `scorer` to calculate a score for each one, and updates the `score` and `score_breakdown` attributes on the respective `Candidate` object.

-   **Parameters:** None.
-   **Returns:** `None`.

#### `get_ranked_candidates(self) -> List[Candidate]`

Sorts the candidates in descending order based on their `score` attribute (FR3).

-   **Parameters:** None.
-   **Returns:** (`List[Candidate]`) A new list of `Candidate` objects, sorted from the highest score to the lowest.

#### `get_shortlist(self, top_n: int = 3) -> List[Candidate]`

Produces a shortlist of the top-ranked candidates (FR4).

-   **Parameters:**
    -   `top_n` (`int`, optional): The number of top candidates to include in the shortlist. Defaults to `3`.
-   **Returns:** (`List[Candidate]`) A slice of the ranked candidate list containing the top `n` candidates.

---

## 5. Reporting

This module is responsible for generating the final output report.

### 5.1. `generate_summary_report(ranked_candidates: List[Candidate], shortlist_size: int) -> str`

Generates a formatted, multi-line string that serves as the final ranking summary report (NFR2). The report includes a full ranking of all candidates with score breakdowns and a separate section for the recommended shortlist.

-   **Parameters:**
    -   `ranked_candidates` (`List[Candidate]`): A list of candidates, which must be pre-sorted from highest to lowest score.
    -   `shortlist_size` (`int`): The number of candidates to feature in the "Recommended Shortlist" section of the report.
-   **Returns:** (`str`) A single string containing the complete, formatted report.

---

## 6. Data & Execution

This module provides sample data for demonstration and contains the main execution logic to run the application.

### 6.1. `get_sample_candidates() -> List[Candidate]`

A factory function that returns a predefined list of `Candidate` objects. This allows the application to run without any external data sources, satisfying NFR1.

-   **Parameters:** None.
-   **Returns:** (`List[Candidate]`) A list of sample candidates.

### 6.2. `main() -> int`

The main entry point for the application. It orchestrates the entire workflow:
1.  Initializes the scoring configuration and job requirements.
2.  Loads the sample candidate data.
3.  Instantiates the `CandidateScorer` and `RankingSystem`.
4.  Executes the ranking process.
5.  Generates the summary report.
6.  Prints the report to the console.

-   **Parameters:** None.
-   **Returns:** (`int`) An exit code (`0` for successful execution).

### 6.3. `if __name__ == "__main__"` Block

This is a standard Python construct that ensures the `main()` function is called only when the script is executed directly, not when it is imported as a module. It initiates the program and handles the exit code.