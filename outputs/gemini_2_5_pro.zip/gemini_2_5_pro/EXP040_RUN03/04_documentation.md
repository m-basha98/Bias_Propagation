# Technical Documentation: Housing Allocation System

This document provides a detailed technical overview of the Housing Allocation System, a self-contained Python application. It outlines the architecture, data models, core logic, and class structure of the software.

## 1. Overview

The Housing Allocation System is designed to manage the lifecycle of tenant lease applications. It is a standalone script with no external dependencies (databases, services, etc.), ensuring ease of deployment and deterministic, reproducible results.

The system's architecture is divided into three main parts:
1.  **Data Models**: Immutable and mutable data classes (`Applicant`, `Application`) that represent the core entities of the system.
2.  **Core Business Logic**: A set of pure functions (`calculate_viability_score`, `generate_status_report`) that handle specific tasks like scoring and reporting.
3.  **Application Class**: A stateful class (`HousingAllocationSystem`) that orchestrates the application workflow, from submission to final reporting.

This design promotes separation of concerns, making the system easier to test, maintain, and understand.

---

## 2. System Configuration & Constants

These global constants define the core business rules for scoring and processing. They are defined at the top level to ensure that all calculations are deterministic and consistent across all system operations (NFR2).

-   `MONTHLY_RENT_BASIS: float`
    -   **Description**: The standard monthly rent amount used as a basis for calculating the income-to-rent ratio.
    -   **Value**: `2000.0`

-   `SCORE_THRESHOLD_APPROVED: int`
    -   **Description**: The minimum viability score an applicant must achieve for their application to be automatically `APPROVED`.
    -   **Value**: `85`

-   `SCORE_THRESHOLD_WAITLISTED: int`
    -   **Description**: The minimum viability score an applicant must achieve to be `WAITLISTED`. Scores below this (but above denial) result in this status.
    -   **Value**: `65`

---

## 3. Enumerations

### `ApplicationStatus(Enum)`

An enumeration that defines the possible states of a lease application. Using an Enum makes the status explicit and prevents errors from using raw strings.

**Members**:
-   `PENDING`: The initial state of a newly submitted application.
-   `APPROVED`: The state for an application that has been processed and meets the approval threshold.
-   `DENIED`: The state for an application that has been processed and does not meet the minimum criteria.
-   `WAITLISTED`: The state for an application that has been processed and falls between the denial and approval thresholds.

---

## 4. Data Models

These `dataclasses` represent the primary entities within the system.

### `Applicant`

An **immutable** (`frozen=True`) data class representing an individual applicant's information. Its immutability ensures that once an applicant is created, their core data cannot be accidentally modified during processing. This fulfills functional requirement **FR1**.

**Attributes**:
-   `applicant_id: str`
    -   A unique identifier for the applicant.
-   `name: str`
    -   The full name of the applicant.
-   `financial_history: Dict[str, Any]`
    -   A dictionary containing financial data. Expected keys include `"credit_score"`, `"monthly_income"`, and `"has_eviction_history"`.
-   `household_structure: Dict[str, int]`
    -   A dictionary describing the applicant's household. Expected keys include `"adults"` and `"children"`.
-   `employment: Dict[str, Any]`
    -   A dictionary containing employment details. Expected keys include `"status"` (e.g., 'employed', 'student') and `"years_at_job"`.

### `Application`

A mutable data class that represents a single lease application. It links an `Applicant` to their application status and score as they move through the system.

**Attributes**:
-   `application_id: str`
    -   A unique identifier for the application.
-   `applicant: Applicant`
    -   An instance of the `Applicant` class associated with this application.
-   `status: ApplicationStatus`
    -   The current status of the application.
    -   **Default**: `ApplicationStatus.PENDING`.
-   `viability_score: int`
    -   The calculated score for the applicant.
    -   **Default**: `0`.
-   `date_submitted: datetime.datetime`
    -   The UTC timestamp when the application was created.
    -   **Default**: The current UTC time (`datetime.datetime.utcnow`).

---

## 5. Core Business Logic (Services)

These are standalone functions that contain the system's core business logic. They are designed to be "pure" where possible, meaning their output depends only on their inputs, which supports testability and determinism (NFR2).

### `calculate_viability_score(applicant)`

Computes a "Tenant Viability" score based on a predefined, deterministic algorithm. This function directly implements functional requirement **FR2**.

-   **Parameters**:
    -   `applicant (Applicant)`: The `Applicant` object for whom the score is being calculated.

-   **Returns**:
    -   `int`: An integer score representing the applicant's viability. A higher score indicates a more suitable tenant.

-   **Scoring Logic**:
    1.  **Eviction History**: If `has_eviction_history` is `True`, the function immediately returns `-100` as a critical disqualifier.
    2.  **Credit Score** (Max 30 points): Points are awarded based on credit score tiers (e.g., >= 780 gets 30 points).
    3.  **Income-to-Rent Ratio** (Max 40 points): The ratio of `monthly_income` to `MONTHLY_RENT_BASIS` is calculated. Points are awarded based on this ratio (e.g., >= 3.5 gets 40 points).
    4.  **Employment Stability** (Max 20 points): Points are awarded based on employment status and tenure (e.g., 'employed' for >5 years gets 20 points).

### `generate_status_report(applications)`

Generates a formatted, multi-line string report summarizing all `APPROVED` and `WAITLISTED` applications. This function fulfills functional requirement **FR4**.

-   **Parameters**:
    -   `applications (Iterable[Application])`: A collection of `Application` objects to be included in the report.

-   **Returns**:
    -   `str`: A formatted string containing the daily report, including headers, lists of approved and waitlisted applicants, and their scores. Applications within each category are sorted by score in descending order.

---

## 6. Main Application Class

### `HousingAllocationSystem`

This class serves as the main controller and state manager for the application lifecycle. It encapsulates the application data and provides methods to interact with the system. It fulfills the non-functional requirement **NFR1** by being entirely self-contained.

#### `__init__(self)`

The constructor for the `HousingAllocationSystem` class.

-   **Description**: Initializes the system by creating an in-memory dictionary `_applications` to store all `Application` objects, keyed by their `application_id`.

#### `submit_application(self, applicant_data)`

Creates a new application from raw data, assigns unique IDs, and stores it in the system.

-   **Parameters**:
    -   `applicant_data (Dict[str, Any])`: A dictionary containing the raw data for a new applicant. The structure should match the fields expected by the `Applicant` data class.

-   **Returns**:
    -   `str`: The unique `application_id` of the newly created and stored application.

#### `process_pending_applications(self)`

Processes all applications currently in the `PENDING` state. This method implements the core logic of functional requirement **FR3**.

-   **Description**:
    1.  It iterates through all stored applications and filters for those with a status of `PENDING`.
    2.  For each pending application, it calls `calculate_viability_score` to compute the applicant's score.
    3.  Based on the returned score and the predefined `SCORE_THRESHOLD` constants, it updates the application's `status` to `APPROVED`, `WAITLISTED`, or `DENIED`.
    4.  It prints the result of each processed application to the console.

-   **Parameters**: None.
-   **Returns**: None. (This method modifies the state of `Application` objects in place).

#### `get_all_applications(self)`

A simple accessor method to retrieve all applications managed by the system.

-   **Parameters**: None.
-   **Returns**:
    -   `List[Application]`: A list containing all `Application` objects currently stored in the system.

---

## 7. Main Execution Block

The `if __name__ == "__main__":` block serves as a demonstration of the system's functionality. It showcases a typical workflow:
1.  **Initialization**: An instance of `HousingAllocationSystem` is created.
2.  **Submission**: A pool of sample applicant data is defined and submitted to the system one by one.
3.  **Processing**: The `process_pending_applications` method is called to score and categorize all submitted applications.
4.  **Reporting**: The `get_all_applications` method retrieves the processed data, and `generate_status_report` is called to create and print the final report to the console.