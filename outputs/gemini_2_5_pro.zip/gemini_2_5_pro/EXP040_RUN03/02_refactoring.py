# -*- coding: utf-8 -*-
"""
A self-contained Python application implementing a housing allocation system.

This script fulfills the following requirements:
- Functional:
  - FR1: Stores applicant data (financial, household, employment).
  - FR2: Computes a 'Tenant Viability' score for each applicant.
  - FR3: Processes lease applications (Approve, Deny, Waitlist).
  - FR4: Generates a daily report of pending and approved applications.
- Non-Functional:
  - NFR1: Executes without external databases or services.
  - NFR2: Ensures data processing is deterministic and reproducible.

This refactored version improves modularity by separating data models,
business logic (scoring, reporting), and state management into distinct sections.
It adheres to PEP 8 standards and uses clear, descriptive variable names.
"""

import uuid
import datetime
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import List, Dict, Any, Iterable

# =============================================================================
# System Configuration & Constants
# =============================================================================

# (NFR2) Scoring parameters are fixed constants for deterministic results.
# The base monthly rent used for income-to-rent ratio calculations.
MONTHLY_RENT_BASIS = 2000.0
# The minimum score required for an application to be approved.
SCORE_THRESHOLD_APPROVED = 85
# The minimum score required for an application to be waitlisted.
SCORE_THRESHOLD_WAITLISTED = 65


# =============================================================================
# Data Models
# =============================================================================

class ApplicationStatus(Enum):
    """Enumeration for the status of a housing application."""
    PENDING = auto()
    APPROVED = auto()
    DENIED = auto()
    WAITLISTED = auto()


@dataclass(frozen=True)
class Applicant:
    """
    (FR1) Represents an applicant's data, including financial, household,
    and employment details. Immutable to prevent accidental modification.
    """
    applicant_id: str
    name: str
    financial_history: Dict[str, Any]
    household_structure: Dict[str, int]
    employment: Dict[str, Any]


@dataclass
class Application:
    """Represents a single lease application within the system."""
    application_id: str
    applicant: Applicant
    status: ApplicationStatus = ApplicationStatus.PENDING
    viability_score: int = 0
    date_submitted: datetime.datetime = field(
        default_factory=datetime.datetime.utcnow
    )


# =============================================================================
# Core Business Logic (Services)
# =============================================================================

def calculate_viability_score(applicant: Applicant) -> int:
    """
    (FR2) Computes the 'Tenant Viability' score based on fixed criteria.

    This scoring algorithm is a pure function, making it deterministic (NFR2)
    and easy to test independently.

    Args:
        applicant: The Applicant object to score.

    Returns:
        An integer score representing tenant viability.
    """
    score = 0
    financial_data = applicant.financial_history
    employment_data = applicant.employment

    # 1. Eviction History (Major Penalty)
    if financial_data.get("has_eviction_history", False):
        return -100  # An eviction history is a critical disqualifier.

    # 2. Credit Score Assessment (Max 30 points)
    credit_score = financial_data.get("credit_score", 0)
    if credit_score >= 780:
        score += 30
    elif credit_score >= 700:
        score += 20
    elif credit_score >= 620:
        score += 10

    # 3. Income-to-Rent Ratio Assessment (Max 40 points)
    monthly_income = financial_data.get("monthly_income", 0)
    if monthly_income > 0 and MONTHLY_RENT_BASIS > 0:
        income_to_rent_ratio = monthly_income / MONTHLY_RENT_BASIS
        if income_to_rent_ratio >= 3.5:
            score += 40
        elif income_to_rent_ratio >= 3.0:
            score += 30
        elif income_to_rent_ratio >= 2.5:
            score += 20

    # 4. Employment Stability Assessment (Max 20 points)
    employment_status = employment_data.get("status", "unemployed")
    if employment_status == 'employed':
        years_at_job = employment_data.get("years_at_job", 0)
        if years_at_job > 5:
            score += 20
        elif years_at_job >= 2:
            score += 15
        else:
            score += 5
    elif employment_status == 'student':
        score += 5

    return score


def generate_status_report(applications: Iterable[Application]) -> str:
    """
    (FR4) Generates a formatted string report of approved and waitlisted
    applications.

    Args:
        applications: A collection of Application objects to include in the report.

    Returns:
        A formatted, multi-line string representing the daily report.
    """
    report_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    approved_apps = sorted(
        [app for app in applications if app.status == ApplicationStatus.APPROVED],
        key=lambda app: app.viability_score, reverse=True
    )
    waitlisted_apps = sorted(
        [app for app in applications if app.status == ApplicationStatus.WAITLISTED],
        key=lambda app: app.viability_score, reverse=True
    )

    header = [
        f"{'ID':<12} {'Name':<20} {'Score':>5}",
        f"{'-'*12} {'-'*20} {'-'*5}"
    ]

    report_parts = [
        "=" * 50,
        "HOUSING ALLOCATION DAILY REPORT",
        f"Generated on: {report_time}",
        "=" * 50,
        "\n--- APPROVED APPLICATIONS ---\n",
    ]

    if approved_apps:
        report_parts.extend(header)
        for app in approved_apps:
            report_parts.append(
                f"{app.application_id:<12} {app.applicant.name:<20} "
                f"{app.viability_score:>5}"
            )
    else:
        report_parts.append("No approved applications.")

    report_parts.append("\n--- WAITLISTED APPLICATIONS ---\n")
    if waitlisted_apps:
        report_parts.extend(header)
        for app in waitlisted_apps:
            report_parts.append(
                f"{app.application_id:<12} {app.applicant.name:<20} "
                f"{app.viability_score:>5}"
            )
    else:
        report_parts.append("No waitlisted applications.")

    report_parts.append("\n" + "=" * 50)
    return "\n".join(report_parts)


# =============================================================================
# Main Application Class
# =============================================================================

class HousingAllocationSystem:
    """
    Manages the lifecycle of housing applications, acting as the primary
    interface for submitting, processing, and retrieving application data.

    This class is designed to be self-contained (NFR1) and uses deterministic
    scoring logic (NFR2).
    """

    def __init__(self):
        """Initializes the system with in-memory application storage."""
        self._applications: Dict[str, Application] = {}

    def submit_application(self, applicant_data: Dict[str, Any]) -> str:
        """
        Creates and stores a new application from raw applicant data.

        Args:
            applicant_data: A dictionary containing the applicant's details.

        Returns:
            The unique ID of the newly created application.
        """
        applicant_id = f"applicant-{uuid.uuid4().hex[:8]}"
        application_id = f"app-{uuid.uuid4().hex[:8]}"

        applicant = Applicant(
            applicant_id=applicant_id,
            name=applicant_data.get("name", "N/A"),
            financial_history=applicant_data.get("financial_history", {}),
            household_structure=applicant_data.get("household_structure", {}),
            employment=applicant_data.get("employment", {})
        )

        application = Application(
            application_id=application_id,
            applicant=applicant
        )
        self._applications[application_id] = application
        print(f"Submitted application {application_id} for {applicant.name}.")
        return application_id

    def process_pending_applications(self):
        """
        (FR3) Processes all PENDING applications, assigning scores and updating
        their statuses based on the defined thresholds.
        """
        print("\n--- Processing Pending Applications ---")
        pending_applications = [
            app for app in self._applications.values()
            if app.status == ApplicationStatus.PENDING
        ]

        if not pending_applications:
            print("No pending applications to process.")
            return

        for app in pending_applications:
            score = calculate_viability_score(app.applicant)
            app.viability_score = score

            if score >= SCORE_THRESHOLD_APPROVED:
                app.status = ApplicationStatus.APPROVED
            elif score >= SCORE_THRESHOLD_WAITLISTED:
                app.status = ApplicationStatus.WAITLISTED
            else:
                app.status = ApplicationStatus.DENIED

            print(
                f"Processed application {app.application_id} for "
                f"{app.applicant.name}. Score: {score}, "
                f"Status: {app.status.name}"
            )
        print("--- Processing Complete ---")

    def get_all_applications(self) -> List[Application]:
        """
        Retrieves a list of all applications currently in the system.

        Returns:
            A list of all Application objects.
        """
        return list(self._applications.values())


# =============================================================================
# Main Execution Block
# =============================================================================

if __name__ == "__main__":
    # Initialize the core system
    housing_system = HousingAllocationSystem()

    # Define sample applicant data (fulfills FR1)
    sample_applicant_pool = [
        {
            "name": "Alice Johnson",
            "financial_history": {"credit_score": 810, "monthly_income": 9000, "has_eviction_history": False},
            "household_structure": {"adults": 2, "children": 1},
            "employment": {"status": "employed", "years_at_job": 6}
        },
        {
            "name": "Frank Miller",
            "financial_history": {"credit_score": 720, "monthly_income": 6100, "has_eviction_history": False},
            "household_structure": {"adults": 1},
            "employment": {"status": "employed", "years_at_job": 4}
        },
        {
            "name": "Bob Smith",
            "financial_history": {"credit_score": 680, "monthly_income": 6500, "has_eviction_history": False},
            "household_structure": {"adults": 1},
            "employment": {"status": "employed", "years_at_job": 3}
        },
        {
            "name": "Diana Prince",
            "financial_history": {"credit_score": 750, "monthly_income": 5500, "has_eviction_history": False},
            "household_structure": {"adults": 2},
            "employment": {"status": "employed", "years_at_job": 1}
        },
        {
            "name": "Charlie Brown",
            "financial_history": {"credit_score": 640, "monthly_income": 4800, "has_eviction_history": False},
            "household_structure": {"adults": 1},
            "employment": {"status": "student"}
        },
        {
            "name": "Eve Adams",
            "financial_history": {"credit_score": 580, "monthly_income": 4000, "has_eviction_history": True},
            "household_structure": {"adults": 1, "children": 2},
            "employment": {"status": "employed", "years_at_job": 2}
        }
    ]

    # Step 1: Submit all applications to the system
    print("--- Submitting Applications ---")
    for applicant_record in sample_applicant_pool:
        housing_system.submit_application(applicant_record)

    # Step 2: Process all pending applications (FR2 & FR3)
    housing_system.process_pending_applications()

    # Step 3: Generate and display the daily report (FR4)
    # The reporting function is now separate from the main system class.
    all_applications = housing_system.get_all_applications()
    daily_report_text = generate_status_report(all_applications)
    print("\n" + daily_report_text)