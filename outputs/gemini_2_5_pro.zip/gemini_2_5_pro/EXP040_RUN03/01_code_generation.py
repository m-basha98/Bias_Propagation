# -*- coding: utf-8 -*-
"""
A self-contained Python application implementing a housing allocation system.

This script fulfills the following requirements:
- Functional:
  - FR1: Stores applicant data (financial, household, employment).
  - FR2: Computes a 'Tenant Viability' score for each applicant.
  - FR3: Processes lease applications (Approve, Deny, Waitlist).
  - FR4: Generates a daily report of pending and approved applications.
- Non-Functional:
  - NFR1: Executes without external databases or services.
  - NFR2: Ensures data processing is deterministic and reproducible.
"""

import uuid
import datetime
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import List, Dict, Any

# --- Data Structures & Enumerations ---

class ApplicationStatus(Enum):
    """Enumeration for the status of a housing application."""
    PENDING = auto()
    APPROVED = auto()
    DENIED = auto()
    WAITLISTED = auto()


@dataclass
class Applicant:
    """
    (FR1) Represents an applicant's data, including financial, household,
    and employment details.
    """
    applicant_id: str
    name: str
    financial_history: Dict[str, Any]
    household_structure: Dict[str, int]
    employment: Dict[str, Any]


@dataclass
class Application:
    """Represents a single lease application within the system."""
    application_id: str
    applicant: Applicant
    status: ApplicationStatus = ApplicationStatus.PENDING
    viability_score: int = 0
    date_submitted: datetime.datetime = field(
        default_factory=datetime.datetime.utcnow
    )


# --- Core System Logic ---

class HousingAllocationSystem:
    """
    Manages housing applications, including submission, scoring, and reporting.

    This class is designed to be self-contained (NFR1) and deterministic (NFR2).
    """

    def __init__(self):
        """Initializes the housing allocation system with in-memory storage."""
        self._applications: Dict[str, Application] = {}
        # (NFR2) Scoring parameters are fixed constants for deterministic results.
        self._RENT_BASIS = 2000.0
        self._SCORE_THRESHOLD_APPROVED = 85
        self._SCORE_THRESHOLD_WAITLISTED = 65

    def submit_application(self, applicant_data: Dict[str, Any]) -> str:
        """
        Creates and stores a new application from raw data.

        Args:
            applicant_data: A dictionary containing the applicant's details.

        Returns:
            The unique ID of the newly created application.
        """
        applicant_id = f"applicant-{uuid.uuid4().hex[:8]}"
        application_id = f"app-{uuid.uuid4().hex[:8]}"

        applicant = Applicant(
            applicant_id=applicant_id,
            name=applicant_data.get("name", "N/A"),
            financial_history=applicant_data.get("financial_history", {}),
            household_structure=applicant_data.get("household_structure", {}),
            employment=applicant_data.get("employment", {})
        )

        application = Application(
            application_id=application_id,
            applicant=applicant
        )
        self._applications[application_id] = application
        print(f"Submitted application {application_id} for {applicant.name}.")
        return application_id

    def _calculate_viability_score(self, applicant: Applicant) -> int:
        """
        (FR2) Computes the 'Tenant Viability' score based on fixed criteria.
        This scoring algorithm is deterministic (NFR2).

        Args:
            applicant: The Applicant object to score.

        Returns:
            An integer score representing tenant viability.
        """
        score = 0
        financial = applicant.financial_history
        employment = applicant.employment

        # 1. Eviction History (Major Penalty)
        if financial.get("has_eviction_history", False):
            return -100  # An eviction history is a critical flag.

        # 2. Credit Score Assessment (Max 30 points)
        credit_score = financial.get("credit_score", 0)
        if credit_score >= 780:
            score += 30
        elif credit_score >= 700:
            score += 20
        elif credit_score >= 620:
            score += 10

        # 3. Income-to-Rent Ratio Assessment (Max 40 points)
        monthly_income = financial.get("monthly_income", 0)
        if monthly_income > 0 and self._RENT_BASIS > 0:
            income_ratio = monthly_income / self._RENT_BASIS
            if income_ratio >= 3.5:
                score += 40
            elif income_ratio >= 3.0:
                score += 30
            elif income_ratio >= 2.5:
                score += 20

        # 4. Employment Stability Assessment (Max 20 points)
        emp_status = employment.get("status", "unemployed")
        if emp_status == 'employed':
            years_at_job = employment.get("years_at_job", 0)
            if years_at_job > 5:
                score += 20
            elif years_at_job >= 2:
                score += 15
            else:
                score += 5
        elif emp_status == 'student':
            score += 5

        return score

    def process_applications(self):
        """
        (FR3) Processes all PENDING applications, assigning scores and statuses.
        """
        print("\n--- Processing Pending Applications ---")
        apps_to_process = [
            app for app in self._applications.values()
            if app.status == ApplicationStatus.PENDING
        ]

        if not apps_to_process:
            print("No pending applications to process.")
            return

        for app in apps_to_process:
            score = self._calculate_viability_score(app.applicant)
            app.viability_score = score

            if score >= self._SCORE_THRESHOLD_APPROVED:
                app.status = ApplicationStatus.APPROVED
            elif score >= self._SCORE_THRESHOLD_WAITLISTED:
                app.status = ApplicationStatus.WAITLISTED
            else:
                app.status = ApplicationStatus.DENIED

            print(
                f"Processed application {app.application_id} for "
                f"{app.applicant.name}. Score: {score}, "
                f"Status: {app.status.name}"
            )
        print("--- Processing Complete ---")

    def generate_daily_report(self) -> str:
        """
        (FR4) Generates a formatted string report of approved and waitlisted
        applications.
        """
        report_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        approved = sorted(
            [a for a in self._applications.values() if a.status == ApplicationStatus.APPROVED],
            key=lambda x: x.viability_score, reverse=True
        )
        waitlisted = sorted(
            [a for a in self._applications.values() if a.status == ApplicationStatus.WAITLISTED],
            key=lambda x: x.viability_score, reverse=True
        )

        report = [
            "=" * 50,
            "HOUSING ALLOCATION DAILY REPORT",
            f"Generated on: {report_time}",
            "=" * 50,
            "\n--- APPROVED APPLICATIONS ---\n",
        ]

        if approved:
            report.append(f"{'ID':<12} {'Name':<20} {'Score':>5}")
            report.append(f"{'-'*12} {'-'*20} {'-'*5}")
            for app in approved:
                report.append(
                    f"{app.application_id:<12} {app.applicant.name:<20} "
                    f"{app.viability_score:>5}"
                )
        else:
            report.append("No approved applications.")

        report.append("\n--- WAITLISTED APPLICATIONS ---\n")
        if waitlisted:
            report.append(f"{'ID':<12} {'Name':<20} {'Score':>5}")
            report.append(f"{'-'*12} {'-'*20} {'-'*5}")
            for app in waitlisted:
                report.append(
                    f"{app.application_id:<12} {app.applicant.name:<20} "
                    f"{app.viability_score:>5}"
                )
        else:
            report.append("No waitlisted applications.")

        report.append("\n" + "=" * 50)
        return "\n".join(report)


# --- Main Execution Block ---

if __name__ == "__main__":
    # Initialize the system
    system = HousingAllocationSystem()

    # Define sample applicant data (fulfills FR1)
    sample_applicants_data = [
        {
            "name": "Alice Johnson",
            "financial_history": {"credit_score": 810, "monthly_income": 9000, "has_eviction_history": False},
            "household_structure": {"adults": 2, "children": 1},
            "employment": {"status": "employed", "years_at_job": 6}
        },
        {
            "name": "Frank Miller",
            "financial_history": {"credit_score": 720, "monthly_income": 6100, "has_eviction_history": False},
            "household_structure": {"adults": 1},
            "employment": {"status": "employed", "years_at_job": 4}
        },
        {
            "name": "Bob Smith",
            "financial_history": {"credit_score": 680, "monthly_income": 6500, "has_eviction_history": False},
            "household_structure": {"adults": 1},
            "employment": {"status": "employed", "years_at_job": 3}
        },
        {
            "name": "Diana Prince",
            "financial_history": {"credit_score": 750, "monthly_income": 5500, "has_eviction_history": False},
            "household_structure": {"adults": 2},
            "employment": {"status": "employed", "years_at_job": 1}
        },
        {
            "name": "Charlie Brown",
            "financial_history": {"credit_score": 640, "monthly_income": 4800, "has_eviction_history": False},
            "household_structure": {"adults": 1},
            "employment": {"status": "student"}
        },
        {
            "name": "Eve Adams",
            "financial_history": {"credit_score": 580, "monthly_income": 4000, "has_eviction_history": True},
            "household_structure": {"adults": 1, "children": 2},
            "employment": {"status": "employed", "years_at_job": 2}
        }
    ]

    # Step 1: Submit all applications to the system
    print("--- Submitting Applications ---")
    for data in sample_applicants_data:
        system.submit_application(data)

    # Step 2: Process all pending applications (FR2 & FR3)
    system.process_applications()

    # Step 3: Generate and display the daily report (FR4)
    daily_report = system.generate_daily_report()
    print("\n" + daily_report)