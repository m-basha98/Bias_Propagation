# -*- coding: utf-8 -*-
"""
Comprehensive unit test suite for the housing allocation system.

This suite uses the pytest framework to validate the functionality, edge cases,
and boundary conditions of the housing allocation application.

Tests are organized into classes corresponding to the main components of the system:
- TestDataModels: Validates the Applicant and Application dataclasses.
- TestCalculateViabilityScore: Thoroughly tests the scoring logic.
- TestGenerateStatusReport: Checks the formatting and content of the report.
- TestHousingAllocationSystem: Verifies the state management and orchestration logic.

To run these tests, ensure you have pytest installed (`pip install pytest`) and
execute `pytest` in the directory containing this file and the original script.
"""

import pytest
import datetime
from dataclasses import FrozenInstanceError
from unittest.mock import patch, MagicMock

# Assuming the original script is saved as 'housing_system.py'
from housing_system import (
    Applicant,
    Application,
    ApplicationStatus,
    HousingAllocationSystem,
    calculate_viability_score,
    generate_status_report,
    SCORE_THRESHOLD_APPROVED,
    SCORE_THRESHOLD_WAITLISTED,
    MONTHLY_RENT_BASIS
)


# =============================================================================
# Test Fixtures for Reusable Data
# =============================================================================

@pytest.fixture
def perfect_applicant() -> Applicant:
    """An applicant who should easily be approved.
    Score: 30 (credit) + 40 (income) + 20 (job) = 90
    """
    return Applicant(
        applicant_id="perfect-1", name="Perfect Candidate",
        financial_history={"credit_score": 800, "monthly_income": 8000, "has_eviction_history": False},
        household_structure={"adults": 1},
        employment={"status": "employed", "years_at_job": 6}
    )


@pytest.fixture
def waitlist_applicant() -> Applicant:
    """An applicant who should be on the waitlist boundary.
    Score: 20 (credit) + 30 (income) + 15 (job) = 65
    """
    return Applicant(
        applicant_id="waitlist-1", name="Waitlist Candidate",
        financial_history={"credit_score": 700, "monthly_income": 6000, "has_eviction_history": False},
        household_structure={"adults": 1},
        employment={"status": "employed", "years_at_job": 2}
    )


@pytest.fixture
def denied_applicant() -> Applicant:
    """An applicant who should be denied.
    Score: 10 (credit) + 20 (income) + 5 (job) = 35
    """
    return Applicant(
        applicant_id="denied-1", name="Denied Candidate",
        financial_history={"credit_score": 620, "monthly_income": 5000, "has_eviction_history": False},
        household_structure={"adults": 1},
        employment={"status": "employed", "years_at_job": 1}
    )


@pytest.fixture
def eviction_applicant() -> Applicant:
    """An applicant with an eviction history, which is an automatic disqualifier."""
    return Applicant(
        applicant_id="eviction-1", name="Eviction History",
        financial_history={"credit_score": 900, "monthly_income": 10000, "has_eviction_history": True},
        household_structure={"adults": 1},
        employment={"status": "employed", "years_at_job": 10}
    )


@pytest.fixture
def student_applicant() -> Applicant:
    """A student applicant with minimal other qualifications.
    Score: 0 (credit) + 0 (income) + 5 (job) = 5
    """
    return Applicant(
        applicant_id="student-1", name="Student Candidate",
        financial_history={"credit_score": 500, "monthly_income": 1000, "has_eviction_history": False},
        household_structure={"adults": 1},
        employment={"status": "student"}
    )


# =============================================================================
# Tests for Data Models
# =============================================================================

class TestDataModels:
    """Tests for the Applicant and Application data models."""

    def test_applicant_is_immutable(self, perfect_applicant):
        """FR1: Verifies that the Applicant dataclass is frozen."""
        with pytest.raises(FrozenInstanceError):
            perfect_applicant.name = "A New Name"

    def test_application_defaults(self, perfect_applicant):
        """Verifies the default values of a new Application."""
        app = Application(application_id="app-1", applicant=perfect_applicant)
        assert app.status == ApplicationStatus.PENDING
        assert app.viability_score == 0
        assert isinstance(app.date_submitted, datetime.datetime)
        # Check if the timestamp is recent
        assert (datetime.datetime.utcnow() - app.date_submitted).total_seconds() < 5


# =============================================================================
# Tests for Core Business Logic (Scoring)
# =============================================================================

class TestCalculateViabilityScore:
    """FR2: Comprehensive tests for the scoring algorithm."""

    def test_eviction_history_is_automatic_fail(self, eviction_applicant):
        """An eviction history should result in a score of -100, ignoring all else."""
        assert calculate_viability_score(eviction_applicant) == -100

    @pytest.mark.parametrize("credit_score, expected_points", [
        (800, 30), (780, 30),  # Top tier
        (779, 20), (700, 20),  # Second tier
        (699, 10), (620, 10),  # Third tier
        (619, 0), (500, 0),   # No points
    ])
    def test_credit_score_boundaries(self, credit_score, expected_points):
        """Tests credit score point allocation at boundaries."""
        applicant = Applicant("id", "name", {"credit_score": credit_score}, {}, {})
        assert calculate_viability_score(applicant) == expected_points

    @pytest.mark.parametrize("monthly_income, expected_points", [
        (MONTHLY_RENT_BASIS * 3.5, 40),   # Top tier (>= 3.5)
        (MONTHLY_RENT_BASIS * 4.0, 40),
        (MONTHLY_RENT_BASIS * 3.49, 30),  # Second tier (>= 3.0)
        (MONTHLY_RENT_BASIS * 3.0, 30),
        (MONTHLY_RENT_BASIS * 2.99, 20),  # Third tier (>= 2.5)
        (MONTHLY_RENT_BASIS * 2.5, 20),
        (MONTHLY_RENT_BASIS * 2.49, 0),   # No points
        (0, 0),                           # Zero income
    ])
    def test_income_to_rent_ratio_boundaries(self, monthly_income, expected_points):
        """Tests income-to-rent ratio point allocation at boundaries."""
        applicant = Applicant("id", "name", {"monthly_income": monthly_income}, {}, {})
        assert calculate_viability_score(applicant) == expected_points

    @pytest.mark.parametrize("status, years, expected_points", [
        ("employed", 6, 20),  # Top tier (> 5 years)
        ("employed", 5, 15),  # Second tier (>= 2 years)
        ("employed", 2, 15),
        ("employed", 1, 5),   # Third tier (< 2 years)
        ("student", 10, 5),   # Student status
        ("unemployed", 10, 0),# Unemployed status
        ("self-employed", 5, 0) # Other status
    ])
    def test_employment_stability(self, status, years, expected_points):
        """Tests employment status and stability point allocation."""
        applicant = Applicant("id", "name", {}, {}, {"status": status, "years_at_job": years})
        assert calculate_viability_score(applicant) == expected_points

    def test_missing_data_is_handled_gracefully(self):
        """NFR2: Ensures missing keys in data dicts don't cause crashes."""
        applicant_no_data = Applicant("id", "name", {}, {}, {})
        score = calculate_viability_score(applicant_no_data)
        assert score == 0

        applicant_partial_data = Applicant("id", "name", {"credit_score": 710}, {}, {"status": "employed"})
        # Score: 20 (credit) + 0 (income) + 5 (job years defaults to 0) = 25
        assert calculate_viability_score(applicant_partial_data) == 25

    def test_full_applicant_scores(self, perfect_applicant, waitlist_applicant, denied_applicant, student_applicant):
        """Validates the combined score for realistic applicant profiles."""
        assert calculate_viability_score(perfect_applicant) == 90
        assert calculate_viability_score(waitlist_applicant) == 65
        assert calculate_viability_score(denied_applicant) == 35
        assert calculate_viability_score(student_applicant) == 5


# =============================================================================
# Tests for Reporting Logic
# =============================================================================

class TestGenerateStatusReport:
    """FR4: Tests for the report generation functionality."""

    def test_report_with_all_statuses(self, perfect_applicant, waitlist_applicant, denied_applicant):
        """Tests a report with a mix of approved, waitlisted, and other statuses."""
        app1 = Application("app-approve", perfect_applicant, status=ApplicationStatus.APPROVED, viability_score=90)
        app2 = Application("app-wait", waitlist_applicant, status=ApplicationStatus.WAITLISTED, viability_score=70)
        app3 = Application("app-deny", denied_applicant, status=ApplicationStatus.DENIED, viability_score=35)
        app4 = Application("app-pend", perfect_applicant, status=ApplicationStatus.PENDING, viability_score=0)

        report = generate_status_report([app1, app2, app3, app4])

        assert "HOUSING ALLOCATION DAILY REPORT" in report
        assert "--- APPROVED APPLICATIONS ---" in report
        assert "app-approve" in report
        assert "Perfect Candidate" in report
        assert "90" in report
        assert "--- WAITLISTED APPLICATIONS ---" in report
        assert "app-wait" in report
        assert "Waitlist Candidate" in report
        assert "70" in report
        assert "app-deny" not in report  # Denied applications are not in the report
        assert "app-pend" not in report  # Pending applications are not in the report

    def test_report_is_sorted_by_score(self):
        """Tests that applications within categories are sorted by score descending."""
        app1 = Application("app-A1", Applicant("id1", "A1", {}, {}, {}), ApplicationStatus.APPROVED, 88)
        app2 = Application("app-A2", Applicant("id2", "A2", {}, {}, {}), ApplicationStatus.APPROVED, 95)
        app3 = Application("app-W1", Applicant("id3", "W1", {}, {}, {}), ApplicationStatus.WAITLISTED, 70)
        app4 = Application("app-W2", Applicant("id4", "W2", {}, {}, {}), ApplicationStatus.WAITLISTED, 65)

        report = generate_status_report([app1, app2, app3, app4])

        approved_section_index = report.find("--- APPROVED APPLICATIONS ---")
        waitlisted_section_index = report.find("--- WAITLISTED APPLICATIONS ---")

        # Check order in approved section
        assert report.find("app-A2") > approved_section_index
        assert report.find("app-A1") > report.find("app-A2")

        # Check order in waitlisted section
        assert report.find("app-W1") > waitlisted_section_index
        assert report.find("app-W2") > report.find("app-W1")

    def test_report_with_no_applications(self):
        """Tests report generation with an empty list of applications."""
        report = generate_status_report([])
        assert "No approved applications." in report
        assert "No waitlisted applications." in report

    def test_report_with_no_relevant_applications(self, denied_applicant):
        """Tests report when only denied/pending applications exist."""
        app1 = Application("app-deny", denied_applicant, status=ApplicationStatus.DENIED, viability_score=35)
        app2 = Application("app-pend", denied_applicant, status=ApplicationStatus.PENDING, viability_score=0)
        report = generate_status_report([app1, app2])
        assert "No approved applications." in report
        assert "No waitlisted applications." in report


# =============================================================================
# Tests for the Main Application Class
# =============================================================================

class TestHousingAllocationSystem:
    """Tests the state management and orchestration of the HousingAllocationSystem."""

    @pytest.fixture
    def system(self):
        """Provides a fresh instance of the system for each test."""
        return HousingAllocationSystem()

    def test_initialization(self, system):
        """NFR1: Tests the initial state of the system."""
        assert system.get_all_applications() == []
        assert isinstance(system._applications, dict)

    @patch('uuid.uuid4')
    def test_submit_application(self, mock_uuid, system):
        """Tests the application submission process."""
        # Mock UUID to get predictable IDs
        mock_uuid.return_value = MagicMock(hex='12345678')
        
        applicant_data = {"name": "Test User", "financial_history": {"credit_score": 750}}
        app_id = system.submit_application(applicant_data)

        assert app_id == "app-12345678"
        apps = system.get_all_applications()
        assert len(apps) == 1
        
        submitted_app = apps[0]
        assert submitted_app.application_id == "app-12345678"
        assert submitted_app.applicant.name == "Test User"
        assert submitted_app.applicant.financial_history["credit_score"] == 750
        assert submitted_app.status == ApplicationStatus.PENDING

    def test_process_pending_applications(self, system, perfect_applicant, waitlist_applicant, denied_applicant):
        """FR3: Tests the status updates after processing applications."""
        # Manually add applications to control their IDs and data
        app_approve = Application("app-approve", perfect_applicant)
        app_waitlist = Application("app-waitlist", waitlist_applicant)
        app_deny = Application("app-deny", denied_applicant)
        app_already_processed = Application("app-done", perfect_applicant, status=ApplicationStatus.APPROVED, viability_score=90)

        system._applications = {
            app_approve.application_id: app_approve,
            app_waitlist.application_id: app_waitlist,
            app_deny.application_id: app_deny,
            app_already_processed.application_id: app_already_processed
        }

        system.process_pending_applications()

        # Check statuses of originally pending applications
        assert system._applications["app-approve"].status == ApplicationStatus.APPROVED
        assert system._applications["app-approve"].viability_score == 90
        
        assert system._applications["app-waitlist"].status == ApplicationStatus.WAITLISTED
        assert system._applications["app-waitlist"].viability_score == 65
        
        assert system._applications["app-deny"].status == ApplicationStatus.DENIED
        assert system._applications["app-deny"].viability_score == 35

        # Check that the already processed application was not changed
        assert system._applications["app-done"].status == ApplicationStatus.APPROVED
        assert system._applications["app-done"].viability_score == 90

    def test_process_with_no_pending_applications(self, system, capsys):
        """Tests processing when there are no pending applications."""
        app = Application("app-1", perfect_applicant, status=ApplicationStatus.APPROVED)
        system._applications[app.application_id] = app

        system.process_pending_applications()

        captured = capsys.readouterr()
        assert "No pending applications to process." in captured.out
        # Ensure the existing application remains unchanged
        assert system._applications["app-1"].status == ApplicationStatus.APPROVED

    def test_get_all_applications(self, system):
        """Tests retrieval of all applications."""
        assert system.get_all_applications() == []
        
        app_data = {"name": "User 1"}
        system.submit_application(app_data)
        
        apps = system.get_all_applications()
        assert len(apps) == 1
        assert isinstance(apps[0], Application)
        assert apps[0].applicant.name == "User 1"