# Technical Documentation: University Admissions Screening System

This document provides a detailed technical overview of the University Admissions Screening System. It describes the system's architecture, classes, methods, and data structures.

## 1. Module Overview

The `university_admissions.py` script is a self-contained Python application designed to model a university admissions screening process. It operates without external databases or services, fulfilling `NFR1`. The system takes a list of applicant data, calculates a holistic score for each, makes an automated admission decision, and generates a comprehensive summary report.

The architecture is designed with a clear separation of concerns, divided into four main components:
1.  **Data Models (`AdmissionsConfig`, `Applicant`):** Dataclasses that define the structure of configuration parameters and applicant information.
2.  **Service Layer (`ScoringService`):** A class that encapsulates all business logic related to score calculation.
3.  **Reporting Layer (`ReportGenerator`):** A class dedicated to creating the final, formatted text report.
4.  **Orchestrator (`AdmissionsSystem`):** The main class that coordinates the workflow, from data ingestion to report generation.

This design adheres to the Single Responsibility Principle, making the system modular, maintainable, and easy to understand.

---

## 2. Data Models and Configuration

### Class `AdmissionsConfig`
A frozen dataclass that encapsulates all configuration parameters for the admissions process. Centralizing these values makes the system's rules explicit (`NFR2`) and easy to modify without changing the core logic.

```python
@dataclasses.dataclass(frozen=True)
class AdmissionsConfig:
```

**Attributes:**

| Attribute                       | Type                          | Description                                                                                             |
| ------------------------------- | ----------------------------- | ------------------------------------------------------------------------------------------------------- |
| `weight_academic`               | `float`                       | The weight (percentage) of the academic score in the final holistic score. Default: `0.70`.               |
| `weight_context`                | `float`                       | The weight (percentage) of the contextual score in the final holistic score. Default: `0.30`.             |
| `weight_gpa`                    | `float`                       | The weight of the GPA within the academic score component. Default: `0.60`.                             |
| `weight_test_score`             | `float`                       | The weight of the test score within the academic score component. Default: `0.40`.                      |
| `gpa_range`                     | `Tuple[float, float]`         | The expected minimum and maximum range for GPA values, used for normalization. Default: `(0.0, 4.0)`.    |
| `test_score_range`              | `Tuple[int, int]`             | The expected minimum and maximum range for test scores, used for normalization. Default: `(400, 1600)`. |
| `normalized_score_range`        | `Tuple[int, int]`             | The target range (e.g., 0-100) to which raw scores are normalized. Default: `(0, 100)`.                  |
| `bonus_first_generation`        | `int`                         | Bonus points added to the context score if an applicant is first-generation. Default: `15`.             |
| `state_bonus_points`            | `Dict[str, int]`              | A dictionary mapping state abbreviations to bonus points for geographic diversity.                      |
| `context_score_cap`             | `float`                       | The maximum possible value for the contextual score component. Default: `100.0`.                        |
| `admit_threshold`               | `float`                       | The minimum holistic score required for an "Admit" decision. Default: `80.0`.                           |
| `waitlist_threshold`            | `float`                       | The minimum holistic score required for a "Waitlist" decision. Default: `65.0`.                         |
| `community_practices_for_review` | `Set[str]`                    | A set of community affiliations that trigger an internal review flag (`FR5`). Default: `{'Athlete', 'Legacy'}`. |

### Class `Applicant`
A dataclass that represents a single university applicant and their associated data. It stores both the initial input data (`FR1`) and the results calculated by the system.

```python
@dataclasses.dataclass
class Applicant:
```

**Attributes:**

| Attribute                   | Type                                           | Description                                                                                           |
| --------------------------- | ---------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| `applicant_id`              | `str`                                          | A unique identifier for the applicant.                                                                |
| `gpa`                       | `float`                                        | The applicant's Grade Point Average.                                                                  |
| `test_score`                | `int`                                          | The applicant's standardized test score.                                                              |
| `state`                     | `str`                                          | The applicant's home state (two-letter abbreviation).                                                 |
| `is_first_generation`       | `bool`                                         | A boolean flag indicating if the applicant is a first-generation college student.                     |
| `community_affiliation`     | `str`                                          | Any special community affiliation (e.g., 'Legacy', 'Athlete').                                        |
| `holistic_score`            | `float`                                        | **(Calculated)** The final holistic score computed by the system. Default: `0.0`.                     |
| `decision`                  | `Literal["Admit", "Waitlist", "Reject", "Pending"]` | **(Calculated)** The admission decision made by the system. Initial state: `"Pending"`.             |
| `requires_internal_review` | `bool`                                         | **(Calculated)** A flag set to `True` if the applicant requires manual review (`FR5`). Default: `False`. |

---

## 3. Service Layer

### Class `ScoringService`
This class contains all the business logic for calculating an applicant's holistic score (`FR2`). It is initialized with an `AdmissionsConfig` object to ensure its calculations are based on the current cycle's rules.

```python
class ScoringService:
```

#### `__init__(self, config: AdmissionsConfig)`
Initializes the scoring service.

*   **Parameters:**
    *   `config` (`AdmissionsConfig`): An instance of `AdmissionsConfig` containing all scoring weights, bonuses, and thresholds.

#### `calculate_holistic_score(self, applicant: Applicant) -> float`
Computes the final holistic admission score for a given applicant by combining weighted academic and contextual scores.

*   **Parameters:**
    *   `applicant` (`Applicant`): The applicant object to be scored.
*   **Returns:**
    *   `float`: The calculated holistic score.

#### `_normalize(value: float, old_min: float, old_max: float, new_min: float, new_max: float) -> float`
A static helper method that scales a numeric value from its original range to a new, specified range. For example, it converts a GPA from a 0.0-4.0 scale to a 0-100 scale.

*   **Parameters:**
    *   `value` (`float`): The number to be normalized.
    *   `old_min` (`float`): The minimum value of the original range.
    *   `old_max` (`float`): The maximum value of the original range.
    *   `new_min` (`float`): The minimum value of the target range.
    *   `new_max` (`float`): The maximum value of the target range.
*   **Returns:**
    *   `float`: The value scaled to the new range.

#### `_calculate_academic_score(self, applicant: Applicant) -> float`
An internal method to calculate the academic component of the holistic score. It normalizes the GPA and test score to a 0-100 scale and then combines them using the configured weights.

*   **Parameters:**
    *   `applicant` (`Applicant`): The applicant object.
*   **Returns:**
    *   `float`: The academic score component (on a 0-100 scale).

#### `_calculate_context_score(self, applicant: Applicant) -> float`
An internal method to calculate the contextual component of the holistic score. It aggregates bonus points for factors like first-generation status and geographic origin. The final score is capped by `config.context_score_cap`.

*   **Parameters:**
    *   `applicant` (`Applicant`): The applicant object.
*   **Returns:**
    *   `float`: The contextual score component (capped at 100).

---

## 4. Reporting Layer

### Class `ReportGenerator`
This class is responsible for generating a formatted, multi-section summary report of the entire admissions cohort (`FR4`).

```python
class ReportGenerator:
```

#### `__init__(self, applicants: List[Applicant], config: AdmissionsConfig)`
Initializes the report generator.

*   **Parameters:**
    *   `applicants` (`List[Applicant]`): A list of all processed `Applicant` objects.
    *   `config` (`AdmissionsConfig`): The configuration object used during processing, needed to display scoring methodology (`NFR2`).

#### `generate(self) -> str`
Constructs and returns the complete summary report as a single formatted string. The report includes:
1.  **Scoring Methodology:** A transparent summary of the rules, weights, and thresholds used.
2.  **Overall Cohort Summary:** High-level statistics on the number and percentage of admitted, waitlisted, and rejected applicants.
3.  **Internal Review Queue:** A list of applicant IDs flagged for further review (`FR5`).
4.  **Detailed Statistics:** A table with average GPA, test score, and holistic score, broken down by decision category.

*   **Returns:**
    *   `str`: The fully formatted report.

#### `_get_cohort_stats(self, cohort: List[Applicant]) -> Tuple[int, float, float, float]`
An internal helper method that computes aggregate statistics for a given sub-list of applicants.

*   **Parameters:**
    *   `cohort` (`List[Applicant]`): A list of `Applicant` objects (e.g., all admitted students).
*   **Returns:**
    *   `Tuple[int, float, float, float]`: A tuple containing the count, average GPA, average test score, and average holistic score for the cohort. Returns `(0, 0.0, 0.0, 0.0)` for an empty cohort.

---

## 5. Main Application Orchestrator

### Class `AdmissionsSystem`
This is the main orchestrator class. It ties all the other components together to manage the end-to-end admissions screening process.

```python
class AdmissionsSystem:
```

#### `__init__(self, applicants_data: List[Dict[str, Any]], config: AdmissionsConfig)`
Initializes the admissions system. It takes raw applicant data (as a list of dictionaries), converts it into a list of `Applicant` objects, and sets up the `ScoringService`.

*   **Parameters:**
    *   `applicants_data` (`List[Dict[str, Any]]`): A list of dictionaries, where each dictionary contains the data for one applicant.
    *   `config` (`AdmissionsConfig`): The configuration object for the admissions cycle.

#### `process_applicants(self) -> None`
Executes the full screening process for every applicant in the system. It iterates through the list of applicants, and for each one, it:
1.  Calculates the holistic score using the `ScoringService`.
2.  Assigns an admission decision based on the score (`FR3`).
3.  Flags the applicant for internal review if their affiliation matches the criteria (`FR5`).

This method modifies the `Applicant` objects in place.

*   **Returns:**
    *   `None`

#### `generate_summary_report(self) -> str`
Creates and returns the final summary report by instantiating and using the `ReportGenerator`.

*   **Returns:**
    *   `str`: The formatted summary report.

#### `_make_decision(self, score: float) -> Literal["Admit", "Waitlist", "Reject"]`
An internal helper method that determines an admission decision based on a holistic score and the configured thresholds (`FR3`).

*   **Parameters:**
    *   `score` (`float`): The applicant's holistic score.
*   **Returns:**
    *   `Literal["Admit", "Waitlist", "Reject"]`: The calculated admission decision string.

---

## 6. Module-Level Functions and Execution

### `get_sample_applicant_data() -> List[Dict[str, Any]]`
A standalone function that provides a sample dataset of applicants. This allows the system to run without any external data files, fulfilling `NFR1`.

*   **Returns:**
    *   `List[Dict[str, Any]]`: A list of dictionaries, each representing an applicant with their initial data.

### Main Execution Block (`if __name__ == "__main__":`)
The script's entry point when run directly. It demonstrates the standard workflow of the system:
1.  An `AdmissionsConfig` object is instantiated.
2.  Sample applicant data is loaded using `get_sample_applicant_data()`.
3.  The `AdmissionsSystem` is initialized with the data and configuration.
4.  The `process_applicants()` method is called to run the screening.
5.  The final report is generated via `generate_summary_report()` and printed to the console.