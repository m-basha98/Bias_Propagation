# -*- coding: utf-8 -*-
"""
Refactored University Admissions Screening System

This self-contained Python application models a university admissions screening
process. It evaluates applicants based on a holistic scoring model, automates
admission decisions, and generates a summary report of cohort statistics.
The application is designed to run without any external dependencies or databases.

Refactoring improvements:
- Encapsulated all configuration constants into an `AdmissionsConfig` dataclass.
- Separated concerns by creating dedicated `ScoringService` and `ReportGenerator`
  classes, improving modularity and adhering to the Single Responsibility Principle.
- Enhanced clarity and type hinting for better maintainability.
- Ensured strict PEP 8 compliance.
"""

import dataclasses
import statistics
from typing import Dict, List, Any, Literal, Set, Tuple


# --- Configuration and Data Models ---

@dataclasses.dataclass(frozen=True)
class AdmissionsConfig:
    """
    Encapsulates all configuration parameters for the admissions process. (NFR2)
    This makes the system's rules explicit and easy to manage.
    """
    # Scoring Component Weights
    weight_academic: float = 0.70
    weight_context: float = 0.30

    # Academic Sub-Component Weights
    weight_gpa: float = 0.60
    weight_test_score: float = 0.40

    # Normalization Ranges
    gpa_range: Tuple[float, float] = (0.0, 4.0)
    test_score_range: Tuple[int, int] = (400, 1600)
    normalized_score_range: Tuple[int, int] = (0, 100)

    # Contextual Factors Bonus Points
    bonus_first_generation: int = 15
    state_bonus_points: Dict[str, int] = dataclasses.field(
        default_factory=lambda: {
            'WY': 10, 'VT': 10, 'ND': 8, 'SD': 8, 'MT': 5
        }
    )
    context_score_cap: float = 100.0

    # Decision Thresholds
    admit_threshold: float = 80.0
    waitlist_threshold: float = 65.0

    # Internal Review Triggers (FR5)
    community_practices_for_review: Set[str] = dataclasses.field(
        default_factory=lambda: {'Athlete', 'Legacy'}
    )


@dataclasses.dataclass
class Applicant:
    """
    Represents a single university applicant and their evaluation data. (FR1)
    """
    applicant_id: str
    gpa: float
    test_score: int
    state: str
    is_first_generation: bool
    community_affiliation: str

    # Fields populated by the screening system
    holistic_score: float = 0.0
    decision: Literal["Admit", "Waitlist", "Reject", "Pending"] = "Pending"
    requires_internal_review: bool = False


# --- Service Layer for Core Logic ---

class ScoringService:
    """Handles all logic related to applicant score calculation."""

    def __init__(self, config: AdmissionsConfig):
        """Initializes the scoring service with the given configuration."""
        self.config = config

    @staticmethod
    def _normalize(
        value: float, old_min: float, old_max: float,
        new_min: float, new_max: float
    ) -> float:
        """Scales a value from one range to another."""
        if old_max - old_min == 0:
            return float(new_min)
        return (
            ((value - old_min) * (new_max - new_min)) / (old_max - old_min)
        ) + new_min

    def _calculate_academic_score(self, applicant: Applicant) -> float:
        """Calculates the academic component of the holistic score."""
        normalized_gpa = self._normalize(
            applicant.gpa, *self.config.gpa_range,
            *self.config.normalized_score_range
        )
        normalized_test_score = self._normalize(
            applicant.test_score, *self.config.test_score_range,
            *self.config.normalized_score_range
        )

        return (
            (normalized_gpa * self.config.weight_gpa) +
            (normalized_test_score * self.config.weight_test_score)
        )

    def _calculate_context_score(self, applicant: Applicant) -> float:
        """Calculates the contextual component of the holistic score."""
        score = 0.0
        if applicant.is_first_generation:
            score += self.config.bonus_first_generation
        score += self.config.state_bonus_points.get(applicant.state, 0)

        return min(score, self.config.context_score_cap)

    def calculate_holistic_score(self, applicant: Applicant) -> float:
        """
        Computes the final holistic admission score for an applicant. (FR2)
        """
        academic_score = self._calculate_academic_score(applicant)
        context_score = self._calculate_context_score(applicant)

        return (
            (academic_score * self.config.weight_academic) +
            (context_score * self.config.weight_context)
        )


# --- Reporting Layer ---

class ReportGenerator:
    """Generates the final summary report for the admissions cohort."""

    def __init__(self, applicants: List[Applicant], config: AdmissionsConfig):
        """Initializes the report generator."""
        self.applicants = applicants
        self.config = config

    def _get_cohort_stats(
        self, cohort: List[Applicant]
    ) -> Tuple[int, float, float, float]:
        """Helper to calculate statistics for a given list of applicants."""
        count = len(cohort)
        if count == 0:
            return 0, 0.0, 0.0, 0.0
        avg_gpa = statistics.mean(app.gpa for app in cohort)
        avg_test_score = statistics.mean(app.test_score for app in cohort)
        avg_holistic_score = statistics.mean(
            app.holistic_score for app in cohort
        )
        return count, avg_gpa, avg_test_score, avg_holistic_score

    def generate(self) -> str:
        """
        Generates a comprehensive summary report of the admissions cohort. (FR4)
        """
        cfg = self.config
        report_lines = []
        header = "=" * 80

        report_lines.append(header)
        report_lines.append(
            "      UNIVERSITY ADMISSIONS SCREENING SYSTEM - SUMMARY REPORT"
        )
        report_lines.append(header)

        # NFR2: Transparent Scoring Metrics
        report_lines.append("\n--- SCORING METHODOLOGY ---")
        report_lines.append(
            f"Holistic Score Formula: (Academic Score * {cfg.weight_academic:.0%})"
            f" + (Context Score * {cfg.weight_context:.0%})"
        )
        report_lines.append(
            f"  - Academic Sub-Weights: GPA ({cfg.weight_gpa:.0%}), "
            f"Test Score ({cfg.weight_test_score:.0%})"
        )
        report_lines.append(
            f"  - Context Bonuses: First-Gen (+{cfg.bonus_first_generation}pts), "
            f"State Bonuses (e.g., WY +{cfg.state_bonus_points.get('WY',0)}pts)"
        )
        report_lines.append(
            f"Decision Thresholds: Admit >= {cfg.admit_threshold}, "
            f"Waitlist >= {cfg.waitlist_threshold}, "
            f"Reject < {cfg.waitlist_threshold}"
        )
        report_lines.append(
            "Internal Review Triggers: Affiliation in "
            f"{cfg.community_practices_for_review}"
        )

        # Overall Summary
        admitted = [app for app in self.applicants if app.decision == "Admit"]
        waitlisted = [app for app in self.applicants if app.decision == "Waitlist"]
        rejected = [app for app in self.applicants if app.decision == "Reject"]
        total = len(self.applicants)

        report_lines.append("\n--- OVERALL COHORT SUMMARY ---")
        report_lines.append(f"Total Applicants Processed: {total}")
        if total > 0:
            report_lines.append(
                f"  - Admitted:  {len(admitted):>4} ({len(admitted)/total:>7.2%})"
            )
            report_lines.append(
                f"  - Waitlisted:{len(waitlisted):>4} ({len(waitlisted)/total:>7.2%})"
            )
            report_lines.append(
                f"  - Rejected:  {len(rejected):>4} ({len(rejected)/total:>7.2%})"
            )

        # Internal Review Queue (FR5)
        review_queue = [
            app for app in self.applicants if app.requires_internal_review
        ]
        report_lines.append("\n--- INTERNAL REVIEW QUEUE ---")
        report_lines.append(
            "Applicants Flagged for Additional Contextual Assessment: "
            f"{len(review_queue)}"
        )
        if review_queue:
            review_ids = ", ".join(app.applicant_id for app in review_queue)
            report_lines.append(f"  - Applicant IDs: {review_ids}")

        # Detailed Statistics
        report_lines.append("\n--- DETAILED STATISTICS BY DECISION ---")
        report_lines.append(
            f"{'Cohort':<12} | {'Count':>6} | {'Avg GPA':>8} | "
            f"{'Avg Test':>9} | {'Avg Score':>10}"
        )
        report_lines.append("-" * 60)

        cohorts = {
            "Admitted": admitted, "Waitlisted": waitlisted,
            "Rejected": rejected, "Total": self.applicants
        }

        for name, cohort_list in cohorts.items():
            count, gpa, test, score = self._get_cohort_stats(cohort_list)
            report_lines.append(
                f"{name:<12} | {count:>6} | {gpa:>8.2f} | "
                f"{test:>9.0f} | {score:>10.2f}"
            )

        report_lines.append("\n" + header)
        report_lines.append("                         END OF REPORT")
        report_lines.append(header)

        return "\n".join(report_lines)


# --- Main Application Orchestrator ---

class AdmissionsSystem:
    """
    Orchestrates the screening, scoring, and decision-making process
    for a cohort of university applicants.
    """

    def __init__(
        self,
        applicants_data: List[Dict[str, Any]],
        config: AdmissionsConfig
    ):
        """Initializes the system with applicant data and a configuration."""
        self.applicants: List[Applicant] = [
            Applicant(**data) for data in applicants_data
        ]
        self.config = config
        self.scoring_service = ScoringService(config)

    def _make_decision(self, score: float) -> Literal["Admit", "Waitlist", "Reject"]:
        """Automates the admission decision based on the holistic score. (FR3)"""
        if score >= self.config.admit_threshold:
            return "Admit"
        if score >= self.config.waitlist_threshold:
            return "Waitlist"
        return "Reject"

    def process_applicants(self) -> None:
        """Runs the full screening process for all applicants in the system."""
        if not self.applicants:
            return

        for applicant in self.applicants:
            applicant.holistic_score = (
                self.scoring_service.calculate_holistic_score(applicant)
            )
            applicant.decision = self._make_decision(applicant.holistic_score)

            if applicant.community_affiliation in self.config.community_practices_for_review:
                applicant.requires_internal_review = True

    def generate_summary_report(self) -> str:
        """Generates the final summary report."""
        report_generator = ReportGenerator(self.applicants, self.config)
        return report_generator.generate()


# --- Data and Execution ---

def get_sample_applicant_data() -> List[Dict[str, Any]]:
    """Provides a sample dataset of applicants for demonstration. (NFR1)"""
    return [
        {'applicant_id': 'ID-001', 'gpa': 3.95, 'test_score': 1550, 'state': 'CA', 'is_first_generation': False, 'community_affiliation': 'None'},
        {'applicant_id': 'ID-002', 'gpa': 3.80, 'test_score': 1480, 'state': 'CA', 'is_first_generation': True, 'community_affiliation': 'None'},
        {'applicant_id': 'ID-003', 'gpa': 3.60, 'test_score': 1520, 'state': 'NY', 'is_first_generation': False, 'community_affiliation': 'Legacy'},
        {'applicant_id': 'ID-004', 'gpa': 4.00, 'test_score': 1390, 'state': 'WY', 'is_first_generation': True, 'community_affiliation': 'None'},
        {'applicant_id': 'ID-005', 'gpa': 3.20, 'test_score': 1450, 'state': 'TX', 'is_first_generation': False, 'community_affiliation': 'Athlete'},
        {'applicant_id': 'ID-006', 'gpa': 3.88, 'test_score': 1300, 'state': 'VT', 'is_first_generation': False, 'community_affiliation': 'None'},
        {'applicant_id': 'ID-007', 'gpa': 3.10, 'test_score': 1250, 'state': 'FL', 'is_first_generation': True, 'community_affiliation': 'None'},
        {'applicant_id': 'ID-008', 'gpa': 2.90, 'test_score': 1100, 'state': 'CA', 'is_first_generation': False, 'community_affiliation': 'None'},
        {'applicant_id': 'ID-009', 'gpa': 3.75, 'test_score': 1580, 'state': 'MA', 'is_first_generation': False, 'community_affiliation': 'Legacy'},
        {'applicant_id': 'ID-010', 'gpa': 3.50, 'test_score': 1350, 'state': 'ND', 'is_first_generation': True, 'community_affiliation': 'None'},
    ]


if __name__ == "__main__":
    """Main execution block for the application."""
    # 1. Instantiate the configuration for the admissions cycle.
    admissions_config = AdmissionsConfig()

    # 2. Load applicant data (FR1).
    applicant_data = get_sample_applicant_data()

    # 3. Initialize the admissions system with data and configuration.
    system = AdmissionsSystem(applicant_data, admissions_config)

    # 4. Process all applicants (FR2, FR3, FR5).
    system.process_applicants()

    # 5. Generate and print the summary report (FR4, NFR2).
    report = system.generate_summary_report()
    print(report)