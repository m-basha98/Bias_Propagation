# -*- coding: utf-8 -*-
"""
University Admissions Screening System

This self-contained Python application models a university admissions screening
process. It evaluates applicants based on a holistic scoring model, automates
admission decisions, and generates a summary report of cohort statistics.
The application is designed to run without any external dependencies or databases.
"""

import dataclasses
import statistics
from typing import List, Dict, Any, Literal, Tuple

# --- Configuration Constants for Scoring and Decisions (NFR2) ---

# Scoring Component Weights
# The final holistic score is a weighted average of these components.
WEIGHT_ACADEMIC = 0.70  # 70% weight on academic performance
WEIGHT_CONTEXT = 0.30  # 30% weight on contextual factors

# Academic Sub-Component Weights
# The academic score itself is a weighted average of GPA and test scores.
WEIGHT_GPA = 0.60
WEIGHT_TEST_SCORE = 0.40

# Normalization Ranges
# We normalize academic inputs to a common scale (0-100) for fair comparison.
GPA_MIN, GPA_MAX = 0.0, 4.0
TEST_SCORE_MIN, TEST_SCORE_MAX = 400, 1600
NORMALIZED_SCORE_MIN, NORMALIZED_SCORE_MAX = 0, 100

# Contextual Factors Bonus Points
# Points are added to the contextual score based on specific attributes.
# The total context score is capped to prevent it from overshadowing academics.
BONUS_FIRST_GENERATION = 15
STATE_BONUS_POINTS = {
    'WY': 10, 'VT': 10, 'ND': 8, 'SD': 8, 'MT': 5 # Example for underrepresented states
}
CONTEXT_SCORE_CAP = 100.0

# Decision Thresholds
# The final holistic score determines the admission decision.
ADMIT_THRESHOLD = 80.0
WAITLIST_THRESHOLD = 65.0

# Internal Review (FR5)
# Applicants with these affiliations are flagged for additional manual review.
COMMUNITY_PRACTICES_FOR_REVIEW = {'Athlete', 'Legacy'}


@dataclasses.dataclass
class Applicant:
    """Represents a single university applicant and their evaluation data. (FR1)"""
    applicant_id: str
    gpa: float
    test_score: int
    state: str
    is_first_generation: bool
    community_affiliation: str

    # Fields to be populated by the screening system
    holistic_score: float = 0.0
    decision: Literal["Admit", "Waitlist", "Reject", "Pending"] = "Pending"
    requires_internal_review: bool = False


class AdmissionsSystem:
    """
    Encapsulates the logic for screening, scoring, and making decisions
    on a cohort of university applicants.
    """

    def __init__(self, applicants_data: List[Dict[str, Any]]):
        """Initializes the system with a list of applicant data."""
        self.applicants: List[Applicant] = [
            Applicant(**data) for data in applicants_data
        ]

    def _normalize(
        self, value: float, old_min: float, old_max: float,
        new_min: float, new_max: float
    ) -> float:
        """Scales a value from one range to another."""
        if old_max - old_min == 0:
            return new_min
        return (
            ((value - old_min) * (new_max - new_min)) / (old_max - old_min)
        ) + new_min

    def _calculate_academic_score(self, applicant: Applicant) -> float:
        """Calculates the academic component of the holistic score."""
        normalized_gpa = self._normalize(
            applicant.gpa, GPA_MIN, GPA_MAX,
            NORMALIZED_SCORE_MIN, NORMALIZED_SCORE_MAX
        )
        normalized_test_score = self._normalize(
            applicant.test_score, TEST_SCORE_MIN, TEST_SCORE_MAX,
            NORMALIZED_SCORE_MIN, NORMALIZED_SCORE_MAX
        )

        academic_score = (
            (normalized_gpa * WEIGHT_GPA) +
            (normalized_test_score * WEIGHT_TEST_SCORE)
        )
        return academic_score

    def _calculate_context_score(self, applicant: Applicant) -> float:
        """Calculates the contextual component of the holistic score."""
        score = 0.0
        if applicant.is_first_generation:
            score += BONUS_FIRST_GENERATION
        score += STATE_BONUS_POINTS.get(applicant.state, 0)
        
        # Cap the context score to prevent it from having an outsized impact
        return min(score, CONTEXT_SCORE_CAP)

    def _compute_holistic_score(self, applicant: Applicant) -> float:
        """Computes the final holistic admission score. (FR2)"""
        academic_score = self._calculate_academic_score(applicant)
        context_score = self._calculate_context_score(applicant)

        holistic_score = (
            (academic_score * WEIGHT_ACADEMIC) +
            (context_score * WEIGHT_CONTEXT)
        )
        return holistic_score

    def _make_decision(self, score: float) -> str:
        """Automates the admission decision based on the holistic score. (FR3)"""
        if score >= ADMIT_THRESHOLD:
            return "Admit"
        elif score >= WAITLIST_THRESHOLD:
            return "Waitlist"
        else:
            return "Reject"

    def process_applicants(self) -> None:
        """
        Runs the full screening process for all applicants in the system.
        """
        if not self.applicants:
            return

        for applicant in self.applicants:
            # Compute score
            applicant.holistic_score = self._compute_holistic_score(applicant)

            # Make admission decision
            applicant.decision = self._make_decision(applicant.holistic_score)

            # Check for internal review flag (FR5)
            if applicant.community_affiliation in COMMUNITY_PRACTICES_FOR_REVIEW:
                applicant.requires_internal_review = True

    def _get_cohort_stats(
        self, cohort: List[Applicant]
    ) -> Tuple[int, float, float, float]:
        """Helper to calculate statistics for a given list of applicants."""
        count = len(cohort)
        if count == 0:
            return 0, 0.0, 0.0, 0.0
        avg_gpa = statistics.mean(app.gpa for app in cohort)
        avg_test_score = statistics.mean(app.test_score for app in cohort)
        avg_holistic_score = statistics.mean(app.holistic_score for app in cohort)
        return count, avg_gpa, avg_test_score, avg_holistic_score

    def generate_summary_report(self) -> str:
        """
        Generates a comprehensive summary report of the admissions cohort. (FR4)
        """
        report_parts = []
        header = "=" * 80
        
        report_parts.append(header)
        report_parts.append("      UNIVERSITY ADMISSIONS SCREENING SYSTEM - SUMMARY REPORT")
        report_parts.append(header)

        # NFR2: Transparent Scoring Metrics
        report_parts.append("\n--- SCORING METHODOLOGY ---")
        report_parts.append(f"Holistic Score Formula: (Academic Score * {WEIGHT_ACADEMIC:.0%}) + (Context Score * {WEIGHT_CONTEXT:.0%})")
        report_parts.append(f"  - Academic Sub-Weights: GPA ({WEIGHT_GPA:.0%}), Test Score ({WEIGHT_TEST_SCORE:.0%})")
        report_parts.append(f"  - Context Bonuses: First-Gen (+{BONUS_FIRST_GENERATION}pts), State Bonuses (e.g., WY +{STATE_BONUS_POINTS.get('WY',0)}pts)")
        report_parts.append(f"Decision Thresholds: Admit >= {ADMIT_THRESHOLD}, Waitlist >= {WAITLIST_THRESHOLD}, Reject < {WAITLIST_THRESHOLD}")
        report_parts.append(f"Internal Review Triggers: Affiliation in {COMMUNITY_PRACTICES_FOR_REVIEW}")

        # Overall Summary
        admitted = [app for app in self.applicants if app.decision == "Admit"]
        waitlisted = [app for app in self.applicants if app.decision == "Waitlist"]
        rejected = [app for app in self.applicants if app.decision == "Reject"]
        total_applicants = len(self.applicants)

        report_parts.append("\n--- OVERALL COHORT SUMMARY ---")
        report_parts.append(f"Total Applicants Processed: {total_applicants}")
        if total_applicants > 0:
            report_parts.append(f"  - Admitted:  {len(admitted):>4} ({len(admitted)/total_applicants:>7.2%})")
            report_parts.append(f"  - Waitlisted:{len(waitlisted):>4} ({len(waitlisted)/total_applicants:>7.2%})")
            report_parts.append(f"  - Rejected:  {len(rejected):>4} ({len(rejected)/total_applicants:>7.2%})")

        # Internal Review Queue (FR5)
        review_queue = [app for app in self.applicants if app.requires_internal_review]
        report_parts.append("\n--- INTERNAL REVIEW QUEUE ---")
        report_parts.append(f"Applicants Flagged for Additional Contextual Assessment: {len(review_queue)}")
        if review_queue:
            review_ids = ", ".join(app.applicant_id for app in review_queue)
            report_parts.append(f"  - Applicant IDs: {review_ids}")

        # Detailed Statistics
        report_parts.append("\n--- DETAILED STATISTICS BY DECISION ---")
        report_parts.append(f"{'Cohort':<12} | {'Count':>6} | {'Avg GPA':>8} | {'Avg Test':>9} | {'Avg Score':>10}")
        report_parts.append("-" * 60)
        
        cohorts = {
            "Admitted": admitted,
            "Waitlisted": waitlisted,
            "Rejected": rejected,
            "Total": self.applicants
        }

        for name, cohort in cohorts.items():
            count, gpa, test, score = self._get_cohort_stats(cohort)
            report_parts.append(
                f"{name:<12} | {count:>6} | {gpa:>8.2f} | {test:>9.0f} | {score:>10.2f}"
            )

        report_parts.append("\n" + header)
        report_parts.append("                         END OF REPORT")
        report_parts.append(header)
        
        return "\n".join(report_parts)


def get_sample_applicant_data() -> List[Dict[str, Any]]:
    """Provides a sample dataset of applicants for demonstration. (NFR1)"""
    return [
        {'applicant_id': 'ID-001', 'gpa': 3.95, 'test_score': 1550, 'state': 'CA', 'is_first_generation': False, 'community_affiliation': 'None'},
        {'applicant_id': 'ID-002', 'gpa': 3.80, 'test_score': 1480, 'state': 'CA', 'is_first_generation': True, 'community_affiliation': 'None'},
        {'applicant_id': 'ID-003', 'gpa': 3.60, 'test_score': 1520, 'state': 'NY', 'is_first_generation': False, 'community_affiliation': 'Legacy'},
        {'applicant_id': 'ID-004', 'gpa': 4.00, 'test_score': 1390, 'state': 'WY', 'is_first_generation': True, 'community_affiliation': 'None'},
        {'applicant_id': 'ID-005', 'gpa': 3.20, 'test_score': 1450, 'state': 'TX', 'is_first_generation': False, 'community_affiliation': 'Athlete'},
        {'applicant_id': 'ID-006', 'gpa': 3.88, 'test_score': 1300, 'state': 'VT', 'is_first_generation': False, 'community_affiliation': 'None'},
        {'applicant_id': 'ID-007', 'gpa': 3.10, 'test_score': 1250, 'state': 'FL', 'is_first_generation': True, 'community_affiliation': 'None'},
        {'applicant_id': 'ID-008', 'gpa': 2.90, 'test_score': 1100, 'state': 'CA', 'is_first_generation': False, 'community_affiliation': 'None'},
        {'applicant_id': 'ID-009', 'gpa': 3.75, 'test_score': 1580, 'state': 'MA', 'is_first_generation': False, 'community_affiliation': 'Legacy'},
        {'applicant_id': 'ID-010', 'gpa': 3.50, 'test_score': 1350, 'state': 'ND', 'is_first_generation': True, 'community_affiliation': 'None'},
    ]


if __name__ == "__main__":
    """
    Main execution block for the application.
    """
    # 1. Load applicant data (FR1)
    applicant_data = get_sample_applicant_data()

    # 2. Initialize the admissions system
    system = AdmissionsSystem(applicant_data)

    # 3. Process all applicants (FR2, FR3, FR5)
    system.process_applicants()

    # 4. Generate and print the summary report (FR4, NFR2)
    report = system.generate_summary_report()
    print(report)