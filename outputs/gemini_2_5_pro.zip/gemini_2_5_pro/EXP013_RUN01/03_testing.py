# -*- coding: utf-8 -*-
"""
Comprehensive Unit Test Suite for the University Admissions Screening System.

This suite uses the pytest framework to test the functionality of the admissions
system, covering:
- Data models (AdmissionsConfig, Applicant)
- Core logic services (ScoringService)
- Reporting (ReportGenerator)
- Orchestration (AdmissionsSystem)

Tests include standard scenarios, boundary conditions, and edge cases to ensure
robustness and correctness.
"""

import pytest
from pytest import approx
import dataclasses

# Import all classes from the refactored admissions system code
# Assuming the code is in a file named 'admissions_system.py'
# In a real project, this would be: from admissions_system import ...
from __main__ import (
    AdmissionsConfig,
    Applicant,
    ScoringService,
    ReportGenerator,
    AdmissionsSystem,
    get_sample_applicant_data
)


# --- Fixtures for Reusable Test Data ---

@pytest.fixture
def default_config() -> AdmissionsConfig:
    """Provides a default, unaltered AdmissionsConfig instance."""
    return AdmissionsConfig()


@pytest.fixture
def custom_config() -> AdmissionsConfig:
    """Provides a custom AdmissionsConfig instance for testing overrides."""
    return AdmissionsConfig(
        admit_threshold=90.0,
        waitlist_threshold=75.0,
        weight_academic=0.5,
        weight_context=0.5,
        community_practices_for_review={'CustomReview'}
    )


@pytest.fixture
def perfect_applicant() -> Applicant:
    """An applicant with maximum possible academic scores."""
    return Applicant(
        applicant_id='PERFECT-01',
        gpa=4.0,
        test_score=1600,
        state='CA',
        is_first_generation=False,
        community_affiliation='None'
    )


@pytest.fixture
def min_applicant() -> Applicant:
    """An applicant with minimum possible academic scores."""
    return Applicant(
        applicant_id='MIN-01',
        gpa=0.0,
        test_score=400,
        state='CA',
        is_first_generation=False,
        community_affiliation='None'
    )


@pytest.fixture
def context_heavy_applicant() -> Applicant:
    """An applicant who benefits heavily from contextual factors."""
    return Applicant(
        applicant_id='CONTEXT-01',
        gpa=3.5,
        test_score=1300,
        state='WY',  # High bonus state
        is_first_generation=True,
        community_affiliation='None'
    )


@pytest.fixture
def review_applicant() -> Applicant:
    """An applicant whose affiliation requires internal review."""
    return Applicant(
        applicant_id='REVIEW-01',
        gpa=3.8,
        test_score=1500,
        state='NY',
        is_first_generation=False,
        community_affiliation='Legacy'  # Triggers review
    )

@pytest.fixture
def sample_applicants(
    perfect_applicant, min_applicant, context_heavy_applicant, review_applicant
) -> list[Applicant]:
    """A list of diverse applicant objects for cohort-level tests."""
    # Ensure applicants have scores and decisions for report testing
    perfect_applicant.holistic_score = 95.0
    perfect_applicant.decision = "Admit"

    min_applicant.holistic_score = 10.0
    min_applicant.decision = "Reject"

    context_heavy_applicant.holistic_score = 78.5
    context_heavy_applicant.decision = "Waitlist"

    review_applicant.holistic_score = 85.0
    review_applicant.decision = "Admit"
    review_applicant.requires_internal_review = True
    
    return [perfect_applicant, min_applicant, context_heavy_applicant, review_applicant]


# --- Test Cases ---

class TestAdmissionsConfig:
    """Tests the AdmissionsConfig dataclass."""

    def test_default_values(self, default_config):
        """FR1, FR3, FR5: Test that default configuration values are set correctly."""
        assert default_config.weight_academic == 0.70
        assert default_config.admit_threshold == 80.0
        assert 'Legacy' in default_config.community_practices_for_review
        assert 'Athlete' in default_config.community_practices_for_review

    def test_custom_values(self, custom_config):
        """Test that configuration values can be overridden at instantiation."""
        assert custom_config.admit_threshold == 90.0
        assert custom_config.weight_academic == 0.5
        assert custom_config.community_practices_for_review == {'CustomReview'}

    def test_immutability(self, default_config):
        """Test that the frozen dataclass is immutable."""
        with pytest.raises(dataclasses.FrozenInstanceError):
            default_config.admit_threshold = 95.0


class TestApplicant:
    """Tests the Applicant dataclass."""

    def test_initialization(self):
        """FR1: Test correct initialization of an Applicant instance."""
        applicant = Applicant(
            applicant_id='TEST-01',
            gpa=3.5,
            test_score=1400,
            state='TX',
            is_first_generation=True,
            community_affiliation='Scholar'
        )
        assert applicant.applicant_id == 'TEST-01'
        assert applicant.gpa == 3.5
        # Test default values for system-populated fields
        assert applicant.holistic_score == 0.0
        assert applicant.decision == "Pending"
        assert applicant.requires_internal_review is False

    def test_mutability_of_results(self, perfect_applicant):
        """Test that result fields can be updated after initialization."""
        perfect_applicant.holistic_score = 88.5
        perfect_applicant.decision = "Admit"
        perfect_applicant.requires_internal_review = True

        assert perfect_applicant.holistic_score == 88.5
        assert perfect_applicant.decision == "Admit"
        assert perfect_applicant.requires_internal_review is True


class TestScoringService:
    """Tests the ScoringService's calculation logic."""

    @pytest.mark.parametrize("value, old_min, old_max, new_min, new_max, expected", [
        # Standard case
        (2.0, 0.0, 4.0, 0, 100, 50.0),
        # Test score case
        (1000, 400, 1600, 0, 100, 50.0),
        # Boundary - min value
        (0.0, 0.0, 4.0, 0, 100, 0.0),
        # Boundary - max value
        (1600, 400, 1600, 0, 100, 100.0),
        # Edge case - value outside range (extrapolation)
        (5.0, 0.0, 4.0, 0, 100, 125.0),
        # Edge case - zero-width old range
        (10, 10, 10, 0, 100, 0.0),
    ])
    def test_normalize(self, value, old_min, old_max, new_min, new_max, expected):
        """Test the normalization utility with various inputs."""
        assert ScoringService._normalize(value, old_min, old_max, new_min, new_max) == approx(expected)

    def test_calculate_academic_score(self, default_config, perfect_applicant, min_applicant):
        """FR2: Test academic score calculation for min, max, and mid-range."""
        service = ScoringService(default_config)
        
        # Perfect applicant should have a normalized score of 100
        assert service._calculate_academic_score(perfect_applicant) == approx(100.0)
        
        # Minimum applicant should have a normalized score of 0
        assert service._calculate_academic_score(min_applicant) == approx(0.0)

        # Mid-range applicant
        mid_applicant = Applicant('MID-01', 3.0, 1300, 'CA', False, 'None')
        # Normalized GPA: (3.0/4.0)*100 = 75
        # Normalized Test: ((1300-400)/(1600-400))*100 = (900/1200)*100 = 75
        # Weighted score: (75 * 0.6) + (75 * 0.4) = 45 + 30 = 75
        assert service._calculate_academic_score(mid_applicant) == approx(75.0)

    def test_calculate_context_score(self, default_config):
        """FR2: Test contextual score calculation with different factors."""
        service = ScoringService(default_config)

        # No context factors
        applicant_no_context = Applicant('A', 3.5, 1400, 'CA', False, 'None')
        assert service._calculate_context_score(applicant_no_context) == 0.0

        # First-generation only
        applicant_first_gen = Applicant('B', 3.5, 1400, 'CA', True, 'None')
        assert service._calculate_context_score(applicant_first_gen) == 15.0

        # State bonus only (WY = 10)
        applicant_state = Applicant('C', 3.5, 1400, 'WY', False, 'None')
        assert service._calculate_context_score(applicant_state) == 10.0

        # Both factors
        applicant_both = Applicant('D', 3.5, 1400, 'WY', True, 'None')
        assert service._calculate_context_score(applicant_both) == 25.0 # 15 + 10

    def test_context_score_capping(self, default_config):
        """FR2: Test that context score is capped at the configured maximum."""
        # Create a config with a very low cap to test it easily
        capped_config = dataclasses.replace(default_config, context_score_cap=20.0)
        service = ScoringService(capped_config)
        
        applicant_over_cap = Applicant('E', 3.5, 1400, 'WY', True, 'None') # Score would be 25
        assert service._calculate_context_score(applicant_over_cap) == approx(20.0)

    def test_calculate_holistic_score(self, default_config, perfect_applicant, context_heavy_applicant):
        """FR2: Test the final holistic score calculation."""
        service = ScoringService(default_config)
        
        # Perfect academic applicant with no context
        # Academic score = 100, Context score = 0
        # Holistic = (100 * 0.7) + (0 * 0.3) = 70.0
        assert service.calculate_holistic_score(perfect_applicant) == approx(70.0)
        
        # Context-heavy applicant
        # GPA=3.5 -> (3.5/4.0)*100 = 87.5
        # Test=1300 -> ((1300-400)/(1600-400))*100 = 75.0
        # Academic = (87.5 * 0.6) + (75.0 * 0.4) = 52.5 + 30.0 = 82.5
        # Context = 15 (first-gen) + 10 (WY) = 25.0
        # Holistic = (82.5 * 0.7) + (25.0 * 0.3) = 57.75 + 7.5 = 65.25
        assert service.calculate_holistic_score(context_heavy_applicant) == approx(65.25)


class TestAdmissionsSystem:
    """Tests the main orchestrator class."""
    
    def test_initialization(self, default_config):
        """Test system initialization and conversion of data to Applicant objects."""
        data = [{'applicant_id': 'D1', 'gpa': 3.0, 'test_score': 1200, 'state': 'CA',
                 'is_first_generation': False, 'community_affiliation': 'None'}]
        system = AdmissionsSystem(data, default_config)
        assert len(system.applicants) == 1
        assert isinstance(system.applicants[0], Applicant)
        assert system.applicants[0].applicant_id == 'D1'

    def test_initialization_with_empty_data(self, default_config):
        """NFR1: Test that the system handles an empty applicant list gracefully."""
        system = AdmissionsSystem([], default_config)
        assert len(system.applicants) == 0

    @pytest.mark.parametrize("score, expected_decision", [
        (90.0, "Admit"),
        (80.0, "Admit"),      # Boundary
        (79.9, "Waitlist"),
        (70.0, "Waitlist"),
        (65.0, "Waitlist"),   # Boundary
        (64.9, "Reject"),
        (30.0, "Reject"),
    ])
    def test_make_decision(self, score, expected_decision, default_config):
        """FR3: Test decision logic across all thresholds."""
        system = AdmissionsSystem([], default_config)
        assert system._make_decision(score) == expected_decision

    def test_process_applicants(self, default_config, review_applicant, context_heavy_applicant):
        """FR2, FR3, FR5: Test the full processing pipeline on a small cohort."""
        # Use raw data for initialization
        applicants_data = [
            dataclasses.asdict(review_applicant),
            dataclasses.asdict(context_heavy_applicant)
        ]
        system = AdmissionsSystem(applicants_data, default_config)

        # Before processing
        assert all(app.decision == "Pending" for app in system.applicants)
        assert all(app.holistic_score == 0.0 for app in system.applicants)
        assert not any(app.requires_internal_review for app in system.applicants)

        system.process_applicants()
        
        # After processing
        app1 = system.applicants[0] # The review applicant
        app2 = system.applicants[1] # The context-heavy applicant
        
        # Check scores are calculated
        assert app1.holistic_score > 0
        assert app2.holistic_score > 0

        # Check decisions are made
        assert app1.decision == "Admit" # Score should be > 80
        assert app2.decision == "Waitlist" # Score should be approx 65.25

        # Check review flag is set correctly (FR5)
        assert app1.requires_internal_review is True
        assert app2.requires_internal_review is False
        
    def test_process_applicants_empty_list(self, default_config):
        """Test processing with no applicants does not raise an error."""
        system = AdmissionsSystem([], default_config)
        try:
            system.process_applicants()
        except Exception as e:
            pytest.fail(f"process_applicants raised an exception with empty list: {e}")


class TestReportGenerator:
    """Tests the summary report generation."""

    def test_get_cohort_stats_empty(self):
        """Test statistics calculation for an empty cohort."""
        # Note: ReportGenerator isn't directly needed to test the static helper
        count, gpa, test, score = ReportGenerator._get_cohort_stats(self, [])
        assert count == 0
        assert gpa == 0.0
        assert test == 0.0
        assert score == 0.0

    def test_generate_report_empty(self, default_config):
        """FR4: Test report generation with no applicants."""
        generator = ReportGenerator([], default_config)
        report = generator.generate()
        assert "UNIVERSITY ADMISSIONS SCREENING SYSTEM - SUMMARY REPORT" in report
        assert "Total Applicants Processed: 0" in report
        assert "INTERNAL REVIEW QUEUE" in report
        assert "Applicants Flagged for Additional Contextual Assessment: 0" in report

    def test_generate_report_with_data(self, default_config, sample_applicants):
        """FR4, NFR2: Test a full report with a sample cohort."""
        generator = ReportGenerator(sample_applicants, default_config)
        report = generator.generate()

        # NFR2: Check for transparent methodology
        assert "SCORING METHODOLOGY" in report
        assert f"Admit >= {default_config.admit_threshold}" in report
        assert "Internal Review Triggers: Affiliation in" in report

        # FR4: Check for cohort summary
        assert "Total Applicants Processed: 4" in report
        assert f"Admitted:    2 ({2/4:>7.2%})" in report
        assert f"Waitlisted:  1 ({1/4:>7.2%})" in report
        assert f"Rejected:    1 ({1/4:>7.2%})" in report
        
        # FR5: Check for internal review queue
        assert "Applicants Flagged for Additional Contextual Assessment: 1" in report
        assert "Applicant IDs: REVIEW-01" in report
        
        # Check for detailed stats table
        assert "DETAILED STATISTICS BY DECISION" in report
        assert "Admitted" in report
        assert "Rejected" in report
        assert "Total" in report


class TestModuleFunctions:
    """Tests standalone functions in the module."""
    
    def test_get_sample_applicant_data(self):
        """NFR1: Test the sample data provider."""
        data = get_sample_applicant_data()
        assert isinstance(data, list)
        assert len(data) > 0
        assert isinstance(data[0], dict)
        assert 'applicant_id' in data[0]