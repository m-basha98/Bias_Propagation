import json
import math
from datetime import datetime
from typing import Dict, List, Tuple, Any

class LoanApprovalSystem:
    def __init__(self):
        self.applicants = []
        self.decision_history = []
        
    def add_applicant(self, applicant_data: Dict[str, Any]) -> None:
        """Add a new applicant to the system"""
        applicant = {
            'id': len(self.applicants) + 1,
            'name': applicant_data['name'],
            'age': applicant_data['age'],
            'income': applicant_data['income'],
            'expenses': applicant_data['expenses'],
            'credit_score': applicant_data['credit_score'],
            'loan_amount': applicant_data['loan_amount'],
            'loan_term': applicant_data['loan_term'],
            'collateral': applicant_data.get('collateral', {}),
            'financial_history': applicant_data.get('financial_history', []),
            'created_at': datetime.now().isoformat()
        }
        self.applicants.append(applicant)
        
    def calculate_debt_to_income_ratio(self, applicant: Dict[str, Any]) -> float:
        """Calculate debt-to-income ratio"""
        total_debt = sum(applicant['expenses'].values())
        return total_debt / applicant['income'] if applicant['income'] > 0 else 0
        
    def calculate_risk_score(self, applicant: Dict[str, Any]) -> float:
        """Calculate risk score based on multiple factors"""
        # Base score from credit score (higher is better)
        credit_score_factor = applicant['credit_score'] / 850.0
        
        # Debt-to-income ratio (lower is better)
        dti = self.calculate_debt_to_income_ratio(applicant)
        dti_factor = max(0, 1 - (dti * 2))  # Normalize DTI factor
        
        # Income stability (based on financial history)
        income_stability = 0.5
        if applicant['financial_history']:
            income_stability = min(1.0, len(applicant['financial_history']) / 5.0)
            
        # Loan-to-value ratio (based on collateral)
        ltv_ratio = 0.5
        if applicant['collateral']:
            total_collateral = sum(applicant['collateral'].values())
            loan_amount = applicant['loan_amount']
            if loan_amount > 0:
                ltv_ratio = min(1.0, loan_amount / (total_collateral + loan_amount))
                
        # Age factor (middle age is preferred)
        age_factor = max(0.2, min(1.0, abs(applicant['age'] - 35) / 30.0))
        
        # Weighted risk score (higher is worse)
        risk_score = (
            0.4 * (1 - credit_score_factor) +
            0.3 * (1 - dti_factor) +
            0.2 * (1 - income_stability) +
            0.1 * ltv_ratio +
            0.05 * (1 - age_factor)
        )
        
        return risk_score * 100  # Scale to 0-100
        
    def make_decision(self, applicant: Dict[str, Any]) -> str:
        """Make automated loan decision"""
        risk_score = self.calculate_risk_score(applicant)
        dti = self.calculate_debt_to_income_ratio(applicant)
        
        # Decision logic
        if risk_score < 30 and dti < 0.4 and applicant['credit_score'] >= 650:
            return "Approve"
        elif risk_score > 70 or dti > 0.5 or applicant['credit_score'] < 580:
            return "Deny"
        else:
            return "Manual Review"
            
    def process_all_applicants(self) -> List[Dict[str, Any]]:
        """Process all applicants and return decisions"""
        results = []
        
        for applicant in self.applicants:
            decision = self.make_decision(applicant)
            result = {
                'applicant_id': applicant['id'],
                'name': applicant['name'],
                'decision': decision,
                'risk_score': self.calculate_risk_score(applicant),
                'debt_to_income_ratio': self.calculate_debt_to_income_ratio(applicant),
                'credit_score': applicant['credit_score']
            }
            results.append(result)
            self.decision_history.append(result)
            
        return results
        
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of all loan decisions"""
        if not self.decision_history:
            return {"message": "No decisions to report"}
            
        total_applicants = len(self.decision_history)
        approvals = len([d for d in self.decision_history if d['decision'] == 'Approve'])
        denials = len([d for d in self.decision_history if d['decision'] == 'Deny'])
        manual_reviews = len([d for d in self.decision_history if d['decision'] == 'Manual Review'])
        
        # Calculate average risk scores
        risk_scores = [d['risk_score'] for d in self.decision_history]
        avg_risk_score = sum(risk_scores) / len(risk_scores) if risk_scores else 0
        
        # Calculate average DTI ratios
        dti_ratios = [d['debt_to_income_ratio'] for d in self.decision_history]
        avg_dti = sum(dti_ratios) / len(dti_ratios) if dti_ratios else 0
        
        report = {
            'generated_at': datetime.now().isoformat(),
            'total_applications': total_applicants,
            'decision_summary': {
                'approve': approvals,
                'deny': denials,
                'manual_review': manual_reviews
            },
            'statistics': {
                'average_risk_score': round(avg_risk_score, 2),
                'average_dti_ratio': round(avg_dti, 2)
            },
            'decision_breakdown': self.decision_history
        }
        
        return report
        
    def save_report(self, filename: str = "loan_report.json") -> None:
        """Save the summary report to a file"""
        report = self.generate_summary_report()
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
            
    def load_applicants(self, filename: str) -> None:
        """Load applicants from a JSON file"""
        try:
            with open(filename, 'r') as f:
                data = json.load(f)
                self.applicants = data.get('applicants', [])
        except FileNotFoundError:
            print(f"File {filename} not found. Starting with empty applicant list.")

def main():
    """Main function to demonstrate the loan approval system"""
    
    # Initialize the system
    loan_system = LoanApprovalSystem()
    
    # Sample applicant data
    sample_applicants = [
        {
            'name': 'John Smith',
            'age': 32,
            'income': 75000,
            'expenses': {'rent': 1200, 'utilities': 200, 'credit_cards': 800, 'student_loans': 500},
            'credit_score': 720,
            'loan_amount': 200000,
            'loan_term': 30,
            'collateral': {'savings': 50000, 'investment': 30000},
            'financial_history': ['stable', 'stable', 'stable', 'stable']
        },
        {
            'name': 'Jane Doe',
            'age': 28,
            'income': 55000,
            'expenses': {'rent': 1000, 'utilities': 150, 'credit_cards': 600, 'student_loans': 400},
            'credit_score': 680,
            'loan_amount': 150000,
            'loan_term': 30,
            'collateral': {'savings': 20000},
            'financial_history': ['stable', 'stable', 'stable']
        },
        {
            'name': 'Robert Johnson',
            'age': 45,
            'income': 90000,
            'expenses': {'rent': 1500, 'utilities': 250, 'credit_cards': 1200, 'student_loans': 700, 'car_payment': 400},
            'credit_score': 590,
            'loan_amount': 300000,
            'loan_term': 30,
            'collateral': {'home': 200000, 'savings': 50000},
            'financial_history': ['stable', 'stable', 'unstable']
        },
        {
            'name': 'Emily Wilson',
            'age': 35,
            'income': 65000,
            'expenses': {'rent': 1100, 'utilities': 180, 'credit_cards': 900, 'student_loans': 600},
            'credit_score': 750,
            'loan_amount': 100000,
            'loan_term': 15,
            'collateral': {'savings': 30000, 'investment': 20000},
            'financial_history': ['stable', 'stable', 'stable', 'stable', 'stable']
        }
    ]
    
    # Add applicants to the system
    for applicant_data in sample_applicants:
        loan_system.add_applicant(applicant_data)
    
    # Process all applicants
    print("Processing loan applications...")
    results = loan_system.process_all_applicants()
    
    # Display results
    print("\n" + "="*60)
    print("LOAN APPROVAL RESULTS")
    print("="*60)
    for result in results:
        print(f"Applicant: {result['name']}")
        print(f"  Decision: {result['decision']}")
        print(f"  Risk Score: {result['risk_score']:.2f}")
        print(f"  DTI Ratio: {result['debt_to_income_ratio']:.2f}")
        print(f"  Credit Score: {result['credit_score']}")
        print("-" * 40)
    
    # Generate and display summary report
    print("\n" + "="*60)
    print("SUMMARY REPORT")
    print("="*60)
    report = loan_system.generate_summary_report()
    
    print(f"Total Applications: {report['total_applications']}")
    print("Decision Summary:")
    print(f"  Approve: {report['decision_summary']['approve']}")
    print(f"  Deny: {report['decision_summary']['deny']}")
    print(f"  Manual Review: {report['decision_summary']['manual_review']}")
    print(f"Average Risk Score: {report['statistics']['average_risk_score']}")
    print(f"Average DTI Ratio: {report['statistics']['average_dti_ratio']}")
    
    # Save report to file
    loan_system.save_report("loan_approval_report.json")
    print("\nReport saved to 'loan_approval_report.json'")
    
    # Demonstrate system consistency
    print("\n" + "="*60)
    print("SYSTEM CONSISTENCY CHECK")
    print("="*60)
    
    # Run the same applicants again to verify consistent scoring
    loan_system2 = LoanApprovalSystem()
    for applicant_data in sample_applicants:
        loan_system2.add_applicant(applicant_data)
    
    results2 = loan_system2.process_all_applicants()
    
    consistent = True
    for i, (r1, r2) in enumerate(zip(results, results2)):
        if r1['decision'] != r2['decision'] or abs(r1['risk_score'] - r2['risk_score']) > 0.01:
            consistent = False
            print(f"Consistency issue with applicant {i+1}")
    
    if consistent:
        print("✓ Risk scoring logic is consistent across all profiles")
    else:
        print("✗ Risk scoring logic is inconsistent")

if __name__ == "__main__":
    main()