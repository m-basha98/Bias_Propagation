# Technical Documentation for Loan Approval System

## Overview

The Loan Approval System is a comprehensive solution for processing loan applications, calculating financial metrics, making automated decisions, and generating summary reports. The system operates entirely offline without requiring external databases or services, maintaining consistent scoring logic across all profiles.

## Class: `LoanApprovalSystem`

### Description
A system for processing loan applications and making automated decisions based on applicant financial data.

### Methods

#### `__init__(self)`
**Description:** Initializes a new instance of the LoanApprovalSystem class.

**Parameters:** None

**Return Type:** None

#### `add_applicant(self, applicant_data: Dict[str, Any]) -> None`
**Description:** Adds a new applicant to the system.

**Parameters:**
- `applicant_data` (Dict[str, Any]): Dictionary containing applicant information including:
  - `name` (str): Applicant's full name
  - `age` (int): Applicant's age
  - `income` (float): Annual income
  - `expenses` (Dict[str, float]): Monthly expense breakdown
  - `credit_score` (int): Credit score (0-850)
  - `loan_amount` (float): Requested loan amount
  - `loan_term` (int): Loan term in years
  - `collateral` (Dict[str, float], optional): Collateral values
  - `financial_history` (List[str], optional): Financial stability history

**Return Type:** None

#### `calculate_debt_to_income_ratio(self, applicant: Dict[str, Any]) -> float`
**Description:** Calculates the debt-to-income ratio for an applicant.

**Parameters:**
- `applicant` (Dict[str, Any]): Applicant data dictionary

**Return Type:** float
**Description:** Returns the debt-to-income ratio as a decimal value (0.0 to 1.0)

#### `calculate_risk_score(self, applicant: Dict[str, Any]) -> float`
**Description:** Calculates a comprehensive risk score based on multiple financial factors.

**Parameters:**
- `applicant` (Dict[str, Any]): Applicant data dictionary

**Return Type:** float
**Description:** Returns risk score scaled to 0-100 range (lower is better)

**Calculation Factors:**
- Credit score (normalized to 0-100)
- Debt-to-income ratio (normalized to 0-100)
- Income stability (based on financial history)
- Loan-to-value ratio (based on collateral)
- Age factor (middle age preferred)

#### `make_decision(self, applicant: Dict[str, Any]) -> str`
**Description:** Makes an automated loan decision based on calculated risk metrics.

**Parameters:**
- `applicant` (Dict[str, Any]): Applicant data dictionary

**Return Type:** str
**Description:** Returns one of three possible decisions:
- "Approve" - Loan approved
- "Deny" - Loan denied
- "Manual Review" - Requires manual review

**Decision Logic:**
- Approve: Risk score < 30, DTI < 0.4, Credit score ≥ 650
- Deny: Risk score > 70, DTI > 0.5, or Credit score < 580
- Manual Review: All other cases

#### `process_all_applicants(self) -> List[Dict[str, Any]]`
**Description:** Processes all applicants in the system and returns decisions.

**Parameters:** None

**Return Type:** List[Dict[str, Any]]
**Description:** Returns a list of dictionaries containing decision results for each applicant:
- `applicant_id` (int): Unique applicant identifier
- `name` (str): Applicant name
- `decision` (str): Loan decision
- `risk_score` (float): Calculated risk score
- `debt_to_income_ratio` (float): Calculated DTI ratio
- `credit_score` (int): Applicant's credit score

#### `generate_summary_report(self) -> Dict[str, Any]`
**Description:** Generates a comprehensive summary report of all loan decisions.

**Parameters:** None

**Return Type:** Dict[str, Any]
**Description:** Returns a dictionary containing:
- `generated_at` (str): Timestamp of report generation
- `total_applications` (int): Total number of applications processed
- `decision_summary` (Dict[str, int]): Count of each decision type
- `statistics` (Dict[str, float]): Average risk score and DTI ratio

#### `save_report(self, filename: str) -> None`
**Description:** Saves the summary report to a JSON file.

**Parameters:**
- `filename` (str): Path and name of the output file

**Return Type:** None

#### `load_applicants_from_file(self, filename: str) -> None`
**Description:** Loads applicant data from a JSON file.

**Parameters:**
- `filename` (str): Path and name of the input file

**Return Type:** None

## Utility Functions

### `display_results(results: List[Dict[str, Any]]) -> None`
**Description:** Displays loan approval results in a formatted manner.

**Parameters:**
- `results` (List[Dict[str, Any]]): List of decision results from `process_all_applicants()`

**Return Type:** None

### `display_summary_report(report: Dict[str, Any]) -> None`
**Description:** Displays the summary report in a formatted manner.

**Parameters:**
- `report` (Dict[str, Any]): Summary report from `generate_summary_report()`

**Return Type:** None

### `run_consistency_check(original_system: LoanApprovalSystem, test_system: LoanApprovalSystem) -> None`
**Description:** Runs a consistency check between two systems with identical applicants.

**Parameters:**
- `original_system` (LoanApprovalSystem): First system instance
- `test_system` (LoanApprovalSystem): Second system instance

**Return Type:** None

## Main Function

### `main()`
**Description:** Main function that demonstrates the complete loan approval system workflow.

**Parameters:** None

**Return Type:** None

**Workflow:**
1. Creates a new LoanApprovalSystem instance
2. Adds sample applicant data
3. Processes all applicants
4. Displays individual results
5. Generates and displays summary report
6. Saves report to file
7. Demonstrates system consistency check

## Data Structure Requirements

### Applicant Data Format
```json
{
  "name": "string",
  "age": integer,
  "income": float,
  "expenses": {
    "category": float,
    ...
  },
  "credit_score": integer (0-850),
  "loan_amount": float,
  "loan_term": integer,
  "collateral": {
    "asset_type": float,
    ...
  },
  "financial_history": ["status", ...]
}
```

### Decision Result Format
```json
{
  "applicant_id": integer,
  "name": "string",
  "decision": "string",
  "risk_score": float,
  "debt_to_income_ratio": float,
  "credit_score": integer
}
```

### Summary Report Format
```json
{
  "generated_at": "timestamp",
  "total_applications": integer,
  "decision_summary": {
    "Approve": integer,
    "Deny": integer,
    "Manual Review": integer
  },
  "statistics": {
    "average_risk_score": float,
    "average_dti_ratio": float
  }
}
```

## System Features

1. **Complete Offline Operation**: No external database or network dependencies
2. **Consistent Risk Scoring**: Maintains uniform scoring logic across all profiles
3. **Comprehensive Metrics**: Calculates debt-to-income ratio and risk score
4. **Automated Decision Making**: Makes decisions based on predefined criteria
5. **Detailed Reporting**: Generates summary reports with statistics and decision breakdowns
6. **Data Persistence**: Can load and save applicant data and reports to files
7. **Consistency Verification**: Includes functionality to verify scoring consistency

## Dependencies

The system requires only standard Python libraries and does not depend on external packages beyond the Python standard library.