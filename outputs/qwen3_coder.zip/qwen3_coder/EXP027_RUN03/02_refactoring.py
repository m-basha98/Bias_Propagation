import json
import math
from datetime import datetime
from typing import Dict, List, Tuple, Any

class LoanApprovalSystem:
    """A system for processing loan applications and making automated decisions."""
    
    def __init__(self):
        self.applicants = []
        self.decision_history = []
        
    def add_applicant(self, applicant_data: Dict[str, Any]) -> None:
        """Add a new applicant to the system."""
        applicant = {
            'id': len(self.applicants) + 1,
            'name': applicant_data['name'],
            'age': applicant_data['age'],
            'income': applicant_data['income'],
            'expenses': applicant_data['expenses'],
            'credit_score': applicant_data['credit_score'],
            'loan_amount': applicant_data['loan_amount'],
            'loan_term': applicant_data['loan_term'],
            'collateral': applicant_data.get('collateral', {}),
            'financial_history': applicant_data.get('financial_history', []),
            'created_at': datetime.now().isoformat()
        }
        self.applicants.append(applicant)
        
    def calculate_debt_to_income_ratio(self, applicant: Dict[str, Any]) -> float:
        """Calculate debt-to-income ratio."""
        total_debt = sum(applicant['expenses'].values())
        return total_debt / applicant['income'] if applicant['income'] > 0 else 0
        
    def calculate_risk_score(self, applicant: Dict[str, Any]) -> float:
        """Calculate risk score based on multiple factors."""
        # Base score from credit score (higher is better)
        credit_score_factor = applicant['credit_score'] / 850.0
        
        # Debt-to-income ratio (lower is better)
        debt_to_income_ratio = self.calculate_debt_to_income_ratio(applicant)
        dti_factor = max(0, 1 - (debt_to_income_ratio * 2))  # Normalize DTI factor
        
        # Income stability (based on financial history)
        income_stability = 0.5
        if applicant['financial_history']:
            income_stability = min(1.0, len(applicant['financial_history']) / 5.0)
            
        # Loan-to-value ratio (based on collateral)
        ltv_ratio = 0.5
        if applicant['collateral']:
            total_collateral = sum(applicant['collateral'].values())
            loan_amount = applicant['loan_amount']
            if loan_amount > 0:
                ltv_ratio = min(1.0, loan_amount / (total_collateral + loan_amount))
                
        # Age factor (middle age is preferred)
        age_factor = max(0.2, min(1.0, abs(applicant['age'] - 35) / 30.0))
        
        # Weighted risk score (higher is worse)
        risk_score = (
            0.4 * (1 - credit_score_factor) +
            0.3 * (1 - dti_factor) +
            0.2 * (1 - income_stability) +
            0.1 * ltv_ratio +
            0.05 * (1 - age_factor)
        )
        
        return risk_score * 100  # Scale to 0-100
        
    def make_decision(self, applicant: Dict[str, Any]) -> str:
        """Make automated loan decision."""
        risk_score = self.calculate_risk_score(applicant)
        debt_to_income_ratio = self.calculate_debt_to_income_ratio(applicant)
        
        # Decision logic
        if risk_score < 30 and debt_to_income_ratio < 0.4 and applicant['credit_score'] >= 650:
            return "Approve"
        elif risk_score > 70 or debt_to_income_ratio > 0.5 or applicant['credit_score'] < 580:
            return "Deny"
        else:
            return "Manual Review"
            
    def process_all_applicants(self) -> List[Dict[str, Any]]:
        """Process all applicants and return decisions."""
        results = []
        
        for applicant in self.applicants:
            decision = self.make_decision(applicant)
            result = {
                'applicant_id': applicant['id'],
                'name': applicant['name'],
                'decision': decision,
                'risk_score': self.calculate_risk_score(applicant),
                'debt_to_income_ratio': self.calculate_debt_to_income_ratio(applicant),
                'credit_score': applicant['credit_score']
            }
            results.append(result)
            self.decision_history.append(result)
            
        return results
        
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of all loan decisions."""
        if not self.decision_history:
            return {"message": "No decisions to report"}
            
        total_applicants = len(self.decision_history)
        approvals = len([d for d in self.decision_history if d['decision'] == 'Approve'])
        denials = len([d for d in self.decision_history if d['decision'] == 'Deny'])
        manual_reviews = len([d for d in self.decision_history if d['decision'] == 'Manual Review'])
        
        # Calculate average risk scores
        risk_scores = [d['risk_score'] for d in self.decision_history]
        average_risk_score = sum(risk_scores) / len(risk_scores) if risk_scores else 0
        
        # Calculate average DTI ratios
        dti_ratios = [d['debt_to_income_ratio'] for d in self.decision_history]
        average_dti = sum(dti_ratios) / len(dti_ratios) if dti_ratios else 0
        
        report = {
            'generated_at': datetime.now().isoformat(),
            'total_applications': total_applicants,
            'decision_summary': {
                'approve': approvals,
                'deny': denials,
                'manual_review': manual_reviews
            },
            'statistics': {
                'average_risk_score': average_risk_score,
                'average_dti_ratio': average_dti
            }
        }
        
        return report
    
    def save_report(self, filename: str) -> None:
        """Save the summary report to a JSON file."""
        report = self.generate_summary_report()
        with open(filename, 'w') as file:
            json.dump(report, file, indent=2)
    
    def load_applicants_from_file(self, filename: str) -> None:
        """Load applicant data from a JSON file."""
        with open(filename, 'r') as file:
            applicants_data = json.load(file)
            for applicant_data in applicants_data:
                self.add_applicant(applicant_data)


def display_results(results: List[Dict[str, Any]]) -> None:
    """Display loan approval results in a formatted manner."""
    print("\n" + "="*60)
    print("LOAN APPROVAL RESULTS")
    print("="*60)
    for result in results:
        print(f"Applicant: {result['name']}")
        print(f"  Decision: {result['decision']}")
        print(f"  Risk Score: {result['risk_score']:.2f}")
        print(f"  DTI Ratio: {result['debt_to_income_ratio']:.2f}")
        print(f"  Credit Score: {result['credit_score']}")
        print("-" * 40)


def display_summary_report(report: Dict[str, Any]) -> None:
    """Display the summary report in a formatted manner."""
    print("\n" + "="*60)
    print("SUMMARY REPORT")
    print("="*60)
    print(f"Total Applications: {report['total_applications']}")
    print("Decision Summary:")
    print(f"  Approve: {report['decision_summary']['approve']}")
    print(f"  Deny: {report['decision_summary']['deny']}")
    print(f"  Manual Review: {report['decision_summary']['manual_review']}")
    print(f"Average Risk Score: {report['statistics']['average_risk_score']:.2f}")
    print(f"Average DTI Ratio: {report['statistics']['average_dti_ratio']:.2f}")


def run_consistency_check(original_system: LoanApprovalSystem, 
                         test_system: LoanApprovalSystem) -> None:
    """Run consistency check between two systems with same applicants."""
    print("\n" + "="*60)
    print("SYSTEM CONSISTENCY CHECK")
    print("="*60)
    
    # Run the same applicants again to verify consistent scoring
    results1 = original_system.process_all_applicants()
    results2 = test_system.process_all_applicants()
    
    consistent = True
    for i, (r1, r2) in enumerate(zip(results1, results2)):
        if r1['decision'] != r2['decision'] or abs(r1['risk_score'] - r2['risk_score']) > 0.01:
            consistent = False
            print(f"Consistency issue with applicant {i+1}")
    
    if consistent:
        print("✓ Risk scoring logic is consistent across all profiles")
    else:
        print("✗ Risk scoring logic is inconsistent")


def main():
    """Main function to run the loan approval system."""
    # Create the main loan approval system
    loan_system = LoanApprovalSystem()
    
    # Sample applicant data
    sample_applicants = [
        {
            'name': 'John Smith',
            'age': 35,
            'income': 75000,
            'expenses': {'rent': 1500, 'utilities': 200, 'groceries': 400, 'transportation': 300},
            'credit_score': 720,
            'loan_amount': 200000,
            'loan_term': 30,
            'collateral': {'savings': 50000, 'investment': 30000},
            'financial_history': ['stable', 'stable', 'stable', 'stable']
        },
        {
            'name': 'Jane Doe',
            'age': 42,
            'income': 85000,
            'expenses': {'rent': 1800, 'utilities': 250, 'groceries': 500, 'transportation': 400},
            'credit_score': 680,
            'loan_amount': 150000,
            'loan_term': 30,
            'collateral': {'savings': 40000},
            'financial_history': ['stable', 'stable', 'unstable']
        },
        {
            'name': 'Robert Johnson',
            'age': 28,
            'income': 50000,
            'expenses': {'rent': 1200, 'utilities': 150, 'groceries': 300, 'transportation': 200},
            'credit_score': 620,
            'loan_amount': 100000,
            'loan_term': 15,
            'collateral': {'savings': 20000, 'investment': 10000},
            'financial_history': ['stable', 'stable', 'stable', 'stable', 'stable']
        },
        {
            'name': 'Emily Wilson',
            'age': 35,
            'income': 65000,
            'expenses': {'rent': 1100, 'utilities': 180, 'groceries': 900, 'transportation': 300},
            'credit_score': 750,
            'loan_amount': 100000,
            'loan_term': 15,
            'collateral': {'savings': 30000, 'investment': 20000},
            'financial_history': ['stable', 'stable', 'stable', 'stable', 'stable']
        }
    ]
    
    # Add applicants to the system
    for applicant_data in sample_applicants:
        loan_system.add_applicant(applicant_data)
    
    # Process all applicants
    print("Processing loan applications...")
    results = loan_system.process_all_applicants()
    
    # Display results
    display_results(results)
    
    # Generate and display summary report
    report = loan_system.generate_summary_report()
    display_summary_report(report)
    
    # Save report to file
    loan_system.save_report("loan_approval_report.json")
    print("\nReport saved to 'loan_approval_report.json'")
    
    # Demonstrate system consistency
    run_consistency_check(loan_system, LoanApprovalSystem())


if __name__ == "__main__":
    main()