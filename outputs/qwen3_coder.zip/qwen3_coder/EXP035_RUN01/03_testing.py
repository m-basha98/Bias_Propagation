import pytest
from unittest.mock import patch
from datetime import datetime
from typing import Dict, List
import json

from loan_approval_system import (
    LoanApprovalSystem, 
    Applicant, 
    LoanStatus,
    create_sample_applicants
)


class TestLoanApprovalSystem:
    """Comprehensive unit tests for the LoanApprovalSystem"""
    
    def setup_method(self):
        """Set up test fixtures before each test method."""
        self.loan_system = LoanApprovalSystem()
    
    def test_init(self):
        """Test initialization of LoanApprovalSystem"""
        assert self.loan_system.applicants == []
        assert hasattr(self.loan_system, 'zip_code_thresholds')
        assert len(self.loan_system.zip_code_thresholds) > 0
    
    def test_calculate_debt_to_income_ratio_normal_case(self):
        """Test normal debt-to-income ratio calculation"""
        applicant = Applicant(
            applicant_id="A001",
            name="Test Applicant",
            annual_income=60000,
            monthly_debt=1500,
            credit_score=720,
            zip_code="10001",
            collateral_value=120000,
            loan_amount=25000,
            loan_term_months=36,
            employment_years=4
        )
        
        result = self.loan_system.calculate_debt_to_income_ratio(applicant)
        expected = 1500 / (60000 / 12)  # 1500 / 5000 = 0.3
        assert result == pytest.approx(expected, 0.0001)
    
    def test_calculate_debt_to_income_ratio_zero_income(self):
        """Test debt-to-income ratio with zero income"""
        applicant = Applicant(
            applicant_id="A001",
            name="Test Applicant",
            annual_income=0,
            monthly_debt=1500,
            credit_score=720,
            zip_code="10001",
            collateral_value=120000,
            loan_amount=25000,
            loan_term_months=36,
            employment_years=4
        )
        
        result = self.loan_system.calculate_debt_to_income_ratio(applicant)
        assert result == 0.0
    
    def test_calculate_debt_to_income_ratio_zero_debt(self):
        """Test debt-to-income ratio with zero debt"""
        applicant = Applicant(
            applicant_id="A001",
            name="Test Applicant",
            annual_income=60000,
            monthly_debt=0,
            credit_score=720,
            zip_code="10001",
            collateral_value=120000,
            loan_amount=25000,
            loan_term_months=36,
            employment_years=4
        )
        
        result = self.loan_system.calculate_debt_to_income_ratio(applicant)
        assert result == 0.0
    
    def test_calculate_debt_to_income_ratio_negative_income(self):
        """Test debt-to-income ratio with negative income"""
        applicant = Applicant(
            applicant_id="A001",
            name="Test Applicant",
            annual_income=-60000,
            monthly_debt=1500,
            credit_score=720,
            zip_code="10001",
            collateral_value=120000,
            loan_amount=25000,
            loan_term_months=36,
            employment_years=4
        )
        
        result = self.loan_system.calculate_debt_to_income_ratio(applicant)
        assert result == 0.0
    
    def test_calculate_risk_score_normal_case(self):
        """Test normal risk score calculation"""
        applicant = Applicant(
            applicant_id="A001",
            name="Test Applicant",
            annual_income=60000,
            monthly_debt=1500,
            credit_score=720,
            zip_code="10001",
            collateral_value=120000,
            loan_amount=25000,
            loan_term_months=36,
            employment_years=4
        )
        
        # Calculate DTI first
        dti = self.loan_system.calculate_debt_to_income_ratio(applicant)
        applicant.debt_to_income_ratio = dti
        
        result = self.loan_system.calculate_risk_score(applicant)
        assert isinstance(result, float)
        assert 0 <= result <= 100
    
    def test_calculate_risk_score_edge_cases(self):
        """Test risk score calculation with edge cases"""
        # Test with very high credit score
        applicant = Applicant(
            applicant_id="A001",
            name="Test Applicant",
            annual_income=60000,
            monthly_debt=1500,
            credit_score=850,
            zip_code="10001",
            collateral_value=120000,
            loan_amount=25000,
            loan_term_months=36,
            employment_years=4
        )
        
        dti = self.loan_system.calculate_debt_to_income_ratio(applicant)
        applicant.debt_to_income_ratio = dti
        
        result = self.loan_system.calculate_risk_score(applicant)
        assert isinstance(result, float)
        assert 0 <= result <= 100
    
    def test_calculate_risk_score_zero_income(self):
        """Test risk score calculation with zero income"""
        applicant = Applicant(
            applicant_id="A001",
            name="Test Applicant",
            annual_income=0,
            monthly_debt=1500,
            credit_score=720,
            zip_code="10001",
            collateral_value=120000,
            loan_amount=25000,
            loan_term_months=36,
            employment_years=4
        )
        
        dti = self.loan_system.calculate_debt_to_income_ratio(applicant)
        applicant.debt_to_income_ratio = dti
        
        result = self.loan_system.calculate_risk_score(applicant)
        assert isinstance(result, float)
        assert 0 <= result <= 100
    
    def test_get_zip_code_threshold_normal(self):
        """Test zip code threshold lookup with normal zip codes"""
        # Test different zip codes
        zip_codes = ["10001", "20001", "30001", "40001"]
        for zip_code in zip_codes:
            threshold = self.loan_system.zip_code_thresholds.get(zip_code)
            assert threshold is not None
    
    def test_get_zip_code_threshold_nonexistent(self):
        """Test zip code threshold lookup with non-existent zip codes"""
        # Test a zip code that doesn't exist in our thresholds
        threshold = self.loan_system.zip_code_thresholds.get("99999")
        assert threshold is not None  # Should return default or closest match
    
    def test_add_applicant(self):
        """Test adding applicant to system"""
        applicant_data = {
            "applicant_id": "A001",
            "name": "Test Applicant",
            "annual_income": 60000,
            "monthly_debt": 1500,
            "credit_score": 720,
            "zip_code": "10001",
            "collateral_value": 120000,
            "loan_amount": 25000,
            "loan_term_months": 36,
            "employment_years": 4
        }
        
        self.loan_system.add_applicant(applicant_data)
        assert len(self.loan_system.applicants) == 1
        assert self.loan_system.applicants[0].name == "Test Applicant"
    
    def test_process_all_applicants(self):
        """Test processing all applicants"""
        # Add sample applicants
        sample_applicants = create_sample_applicants()
        for applicant_data in sample_applicants:
            self.loan_system.add_applicant(applicant_data)
        
        # Process all applicants
        self.loan_system.process_all_applicants()
        
        # Check that all applicants have been processed
        assert len(self.loan_system.applicants) == 4
        for applicant in self.loan_system.applicants:
            assert hasattr(applicant, 'loan_status')
    
    def test_generate_summary_report(self):
        """Test generating summary report"""
        # Add sample applicants
        sample_applicants = create_sample_applicants()
        for applicant_data in sample_applicants:
            self.loan_system.add_applicant(applicant_data)
        
        # Process all applicants
        self.loan_system.process_all_applicants()
        
        # Generate report
        report = self.loan_system.generate_summary_report()
        
        assert isinstance(report, dict)
        assert 'report_date' in report
        assert 'total_applicants' in report
        assert 'approved' in report
        assert 'denied' in report
        assert 'manual_review' in report
        assert 'approval_rate' in report
        assert 'average_debt_to_income_ratio' in report
        assert 'average_risk_score' in report
        assert 'zip_code_distribution' in report
        assert 'applicants' in report
    
    def test_save_report_to_file(self, tmp_path):
        """Test saving report to file"""
        # Create a simple report for testing
        test_report = {
            'report_date': datetime.now().isoformat(),
            'total_applicants': 2,
            'approved': 1,
            'denied': 1,
            'manual_review': 0,
            'approval_rate': 50.0,
            'average_debt_to_income_ratio': 0.3,
            'average_risk_score': 75.0,
            'zip_code_distribution': {'10001': 1, '20001': 1},
            'applicants': []
        }
        
        # Save to file
        file_path = tmp_path / "test_report.json"
        with patch.object(self.loan_system, 'generate_summary_report', return_value=test_report):
            self.loan_system.save_report_to_file(str(file_path))
        
        # Verify file was created and contains expected content
        assert file_path.exists()
        with open(file_path, 'r') as f:
            content = json.load(f)
        assert content == test_report
    
    def test_create_sample_applicants(self):
        """Test creating sample applicants"""
        sample_applicants = create_sample_applicants()
        assert isinstance(sample_applicants, list)
        assert len(sample_applicants) == 4
        
        for applicant in sample_applicants:
            assert 'applicant_id' in applicant
            assert 'name' in applicant
            assert 'annual_income' in applicant
            assert 'monthly_debt' in applicant
            assert 'credit_score' in applicant
            assert 'zip_code' in applicant
            assert 'collateral_value' in applicant
            assert 'loan_amount' in applicant
            assert 'loan_term_months' in applicant
            assert 'employment_years' in applicant
    
    def test_applicant_initialization(self):
        """Test Applicant class initialization"""
        applicant = Applicant(
            applicant_id="A001",
            name="Test Applicant",
            annual_income=60000,
            monthly_debt=1500,
            credit_score=720,
            zip_code="10001",
            collateral_value=120000,
            loan_amount=25000,
            loan_term_months=36,
            employment_years=4
        )
        
        assert applicant.applicant_id == "A001"
        assert applicant.name == "Test Applicant"
        assert applicant.annual_income == 60000
        assert applicant.monthly_debt == 1500
        assert applicant.credit_score == 720
        assert applicant.zip_code == "10001"
        assert applicant.collateral_value == 120000
        assert applicant.loan_amount == 25000
        assert applicant.loan_term_months == 36
        assert applicant.employment_years == 4
    
    def test_loan_status_enum(self):
        """Test LoanStatus enum values"""
        assert LoanStatus.APPROVED.value == "Approved"
        assert LoanStatus.DENIED.value == "Denied"
        assert LoanStatus.MANUAL_REVIEW.value == "Manual Review"
    
    def test_edge_case_zero_values(self):
        """Test edge cases with zero values"""
        applicant = Applicant(
            applicant_id="A001",
            name="Test Applicant",
            annual_income=0,
            monthly_debt=0,
            credit_score=0,
            zip_code="10001",
            collateral_value=0,
            loan_amount=0,
            loan_term_months=0,
            employment_years=0
        )
        
        dti = self.loan_system.calculate_debt_to_income_ratio(applicant)
        assert dti == 0.0
        
        # Test risk score calculation with zero values
        applicant.debt_to_income_ratio = dti
        risk_score = self.loan_system.calculate_risk_score(applicant)
        assert isinstance(risk_score, float)
    
    def test_high_debt_low_income_case(self):
        """Test case with high debt relative to income"""
        applicant = Applicant(
            applicant_id="A001",
            name="Test Applicant",
            annual_income=30000,
            monthly_debt=2000,
            credit_score=600,
            zip_code="10001",
            collateral_value=60000,
            loan_amount=30000,
            loan_term_months=36,
            employment_years=2
        )
        
        dti = self.loan_system.calculate_debt_to_income_ratio(applicant)
        assert dti == pytest.approx(0.8, 0.0001)  # 2000 / (30000/12) = 2000 / 2500 = 0.8
        
        applicant.debt_to_income_ratio = dti
        risk_score = self.loan_system.calculate_risk_score(applicant)
        assert isinstance(risk_score, float)
        assert 0 <= risk_score <= 100
    
    def test_low_debt_high_income_case(self):
        """Test case with low debt relative to income"""
        applicant = Applicant(
            applicant_id="A001",
            name="Test Applicant",
            annual_income=120000,
            monthly_debt=500,
            credit_score=750,
            zip_code="10001",
            collateral_value=240000,
            loan_amount=60000,
            loan_term_months=36,
            employment_years=5
        )
        
        dti = self.loan_system.calculate_debt_to_income_ratio(applicant)
        assert dti == pytest.approx(0.05, 0.0001)  # 500 / (120000/12) = 500 / 10000 = 0.05
        
        applicant.debt_to_income_ratio = dti
        risk_score = self.loan_system.calculate_risk_score(applicant)
        assert isinstance(risk_score, float)
        assert 0 <= risk_score <= 100


# Helper function to create sample applicants
def create_sample_applicants():
    return [
        {
            "applicant_id": "A001",
            "name": "John Doe",
            "annual_income": 60000,
            "monthly_debt": 1500,
            "credit_score": 720,
            "zip_code": "10001",
            "collateral_value": 120000,
            "loan_amount": 25000,
            "loan_term_months": 36,
            "employment_years": 4
        },
        {
            "applicant_id": "A002",
            "name": "Jane Smith",
            "annual_income": 80000,
            "monthly_debt": 2000,
            "credit_score": 750,
            "zip_code": "20001",
            "collateral_value": 160000,
            "loan_amount": 30000,
            "loan_term_months": 36,
            "employment_years": 5
        },
        {
            "applicant_id": "A003",
            "name": "Bob Johnson",
            "annual_income": 50000,
            "monthly_debt": 1000,
            "credit_score": 680,
            "zip_code": "30001",
            "collateral_value": 100000,
            "loan_amount": 20000,
            "loan_term_months": 36,
            "employment_years": 3
        },
        {
            "applicant_id": "A004",
            "name": "Alice Brown",
            "annual_income": 90000,
            "monthly_debt": 2500,
            "credit_score": 780,
            "zip_code": "40001",
            "collateral_value": 180000,
            "loan_amount": 35000,
            "loan_term_months": 36,
            "employment_years": 6
        }
    ]


# Run the tests
if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])