# Loan Approval System Technical Documentation

## Overview
This document provides detailed technical documentation for the Loan Approval System, a comprehensive solution that automates loan decision-making based on applicant financial data and risk assessment criteria.

## System Architecture

### Core Components
1. **LoanApprovalSystem** - Main system class managing applicant data and decision logic
2. **Applicant** - Data class storing applicant information
3. **LoanStatus** - Enum class defining possible loan statuses

## Class Definitions

### LoanStatus Enum
**Description:** Defines the possible loan decision outcomes
**Values:**
- `APPROVED` - Loan approved for processing
- `DENIED` - Loan denied based on criteria
- `MANUAL_REVIEW` - Loan requires human review

### Applicant Data Class
**Description:** Stores comprehensive applicant information including financial metrics and loan details

**Attributes:**
- `applicant_id` (str): Unique identifier for the applicant
- `name` (str): Applicant's full name
- `annual_income` (float): Annual income amount
- `monthly_debt` (float): Monthly debt obligations
- `credit_score` (int): Credit score (300-850 scale)
- `zip_code` (str): Applicant's zip code for threshold determination
- `collateral_value` (float): Value of collateral provided
- `loan_amount` (float): Requested loan amount
- `loan_term_months` (int): Loan term in months
- `employment_years` (int): Years of employment experience
- `debt_to_income_ratio` (Optional[float]): Calculated DTI ratio (default: None)
- `risk_score` (Optional[float]): Calculated risk score (default: None)
- `loan_status` (Optional[LoanStatus]): Final loan decision status (default: None)

## Main System Class: LoanApprovalSystem

### Constructor
**Method:** `__init__(self)`
**Description:** Initializes the loan approval system with empty applicant list and predefined zip code thresholds
**Parameters:** None
**Return Type:** None

### Core Calculation Methods

#### `calculate_debt_to_income_ratio(self, applicant: Applicant) -> float`
**Description:** Calculates the debt-to-income ratio for an applicant
**Parameters:**
- `applicant` (Applicant): Applicant object containing financial data
**Return Type:** float - Debt-to-income ratio as decimal (0.0 to 1.0)
**Processing Logic:**
- Calculates monthly income from annual income
- Divides monthly debt by monthly income
- Returns 0.0 if income is zero or negative
- Rounds result to 4 decimal places

#### `calculate_risk_score(self, applicant: Applicant) -> float`
**Description:** Calculates comprehensive risk score based on multiple financial factors
**Parameters:**
- `applicant` (Applicant): Applicant object containing financial data
**Return Type:** float - Risk score between 0.0 and 100.0
**Processing Logic:**
- Credit score factor (0-100)
- Debt-to-income factor (0-100)
- Income stability factor (0-100)
- Collateral factor (0-100)
- Loan-to-value ratio factor (0-100)
- Weighted combination of all factors with specific weights

#### `get_dti_threshold(self, zip_code: str) -> float`
**Description:** Determines appropriate debt-to-income threshold based on zip code
**Parameters:**
- `zip_code` (str): Applicant's zip code
**Return Type:** float - DTI threshold value (0.0 to 1.0)
**Processing Logic:**
- Finds closest matching zip code threshold
- Uses binary search approach for efficient lookup
- Returns default threshold (0.35) if no match found

### Decision Methods

#### `make_loan_decision(self, applicant: Applicant) -> LoanStatus`
**Description:** Makes automated loan decision based on calculated metrics
**Parameters:**
- `applicant` (Applicant): Applicant object to evaluate
**Return Type:** LoanStatus - Approved, Denied, or Manual Review
**Processing Logic:**
- Calculates debt-to-income ratio and risk score
- Determines appropriate DTI threshold for zip code
- Decision rules:
  - Approve if risk score ≥ 70 AND DTI ≤ threshold
  - Deny if risk score < 40 OR DTI > threshold × 1.5
  - Manual Review otherwise

### Data Management Methods

#### `add_applicant(self, applicant_data: Dict) -> Applicant`
**Description:** Adds a new applicant to the system
**Parameters:**
- `applicant_data` (Dict): Dictionary containing applicant information
**Return Type:** Applicant - Created applicant object
**Processing Logic:**
- Creates Applicant object from dictionary data
- Adds to internal applicants list
- Returns created object

#### `process_all_applicants(self) -> None`
**Description:** Processes all applicants in the system to make loan decisions
**Parameters:** None
**Return Type:** None
**Processing Logic:**
- Iterates through all applicants
- Calls `make_loan_decision` for each applicant
- Updates applicant status in-place

### Reporting Methods

#### `generate_summary_report(self) -> Dict`
**Description:** Generates comprehensive summary report of all applicants
**Parameters:** None
**Return Type:** Dict - Complete report data structure
**Report Structure:**
- `report_date` (str): Date and time of report generation
- `total_applicants` (int): Total number of applicants
- `approved` (int): Number of approved loans
- `denied` (int): Number of denied loans
- `manual_review` (int): Number requiring manual review
- `approval_rate` (float): Percentage of approved loans
- `average_dti_ratio` (float): Average debt-to-income ratio
- `average_risk_score` (float): Average risk score
- `zip_code_distribution` (Dict): Count of applicants by zip code
- `applicants` (List[Dict]): Detailed decision information for each applicant

#### `save_report_to_file(self, filename: str) -> None`
**Description:** Saves the summary report to a JSON file
**Parameters:**
- `filename` (str): Name of output file
**Return Type:** None

### Utility Methods

#### `display_summary_report(report: Dict) -> None`
**Description:** Displays formatted summary report to console
**Parameters:**
- `report` (Dict): Report data structure to display
**Return Type:** None

## Main Function

### `main()`
**Description:** Entry point for the loan approval system execution
**Parameters:** None
**Return Type:** None
**Processing Steps:**
1. Creates LoanApprovalSystem instance
2. Adds sample applicants
3. Processes all applicants
4. Generates summary report
5. Displays formatted report
6. Saves report to JSON file

## Sample Data Generation

### `create_sample_applicants()`
**Description:** Creates sample applicant data for demonstration
**Parameters:** None
**Return Type:** List[Dict] - List of sample applicant dictionaries
**Sample Applicants:**
- Four test applicants with varying financial profiles
- Includes different income levels, debt amounts, credit scores, and zip codes

## Usage Examples

### Basic Usage
```python
# Initialize system
loan_system = LoanApprovalSystem()

# Add applicant
applicant_data = {
    "applicant_id": "A001",
    "name": "John Doe",
    "annual_income": 75000,
    "monthly_debt": 1500,
    "credit_score": 720,
    "zip_code": "12345",
    "collateral_value": 100000,
    "loan_amount": 50000,
    "loan_term_months": 60,
    "employment_years": 5
}

loan_system.add_applicant(applicant_data)

# Process applicants
loan_system.process_all_applicants()

# Generate report
report = loan_system.generate_summary_report()
```

## Key Features

1. **Automated Decision Making:** Complete loan approval workflow with risk-based scoring
2. **Zip Code Based Thresholds:** Dynamic DTI thresholds based on geographic location
3. **Comprehensive Risk Assessment:** Multi-factor risk scoring system
4. **Detailed Reporting:** Comprehensive summary with statistical analysis
5. **Data Persistence:** Report saving functionality to JSON files
6. **Extensible Design:** Modular architecture supporting easy modifications

## Performance Considerations

- **Time Complexity:** O(n) for processing applicants where n is number of applicants
- **Space Complexity:** O(n) for storing applicant data
- **Memory Efficient:** Uses optimized data structures and avoids unnecessary computations
- **Scalable:** Designed to handle multiple applicants efficiently

## Error Handling

The system includes basic validation and graceful handling of edge cases:
- Zero or negative income values
- Invalid zip code lookups
- Missing required data fields
- Mathematical edge cases in calculations

## Output Format

The system generates both console output and JSON file reports containing:
- Summary statistics
- Individual applicant decisions
- Geographic distribution
- Financial metrics
- Approval rates and risk assessments