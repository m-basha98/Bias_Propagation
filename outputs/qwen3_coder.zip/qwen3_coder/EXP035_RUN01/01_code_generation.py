import json
import math
from datetime import datetime
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

class LoanStatus(Enum):
    APPROVED = "Approved"
    DENIED = "Denied"
    MANUAL_REVIEW = "Manual Review"

@dataclass
class Applicant:
    """Data class to store applicant information"""
    applicant_id: str
    name: str
    annual_income: float
    monthly_debt: float
    credit_score: int
    zip_code: str
    collateral_value: float
    loan_amount: float
    loan_term_months: int
    employment_years: int
    debt_to_income_ratio: Optional[float] = None
    risk_score: Optional[float] = None
    loan_status: Optional[LoanStatus] = None

class LoanApprovalSystem:
    """Main loan approval system implementation"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.zip_code_thresholds = {
            "00000": 0.35,  # Default threshold
            "10000": 0.30,
            "20000": 0.32,
            "30000": 0.34,
            "40000": 0.36,
            "50000": 0.38,
            "60000": 0.40,
            "70000": 0.42,
            "80000": 0.44,
            "90000": 0.46
        }
    
    def calculate_debt_to_income_ratio(self, applicant: Applicant) -> float:
        """Calculate debt-to-income ratio"""
        if applicant.annual_income <= 0:
            return 0.0
        
        monthly_income = applicant.annual_income / 12
        if monthly_income <= 0:
            return 0.0
            
        dti_ratio = applicant.monthly_debt / monthly_income
        return round(dti_ratio, 4)
    
    def calculate_risk_score(self, applicant: Applicant) -> float:
        """Calculate risk score based on multiple factors"""
        # Base score from credit score (higher is better)
        credit_score_factor = max(0, (applicant.credit_score - 300) / 700.0) * 100
        
        # Debt-to-income factor (lower is better)
        dti_factor = 0
        if applicant.debt_to_income_ratio is not None:
            dti_factor = max(0, 1 - applicant.debt_to_income_ratio) * 100
        
        # Income stability factor
        income_stability = min(100, applicant.employment_years * 10)
        
        # Collateral factor
        collateral_factor = 0
        if applicant.annual_income > 0:
            collateral_factor = min(100, (applicant.collateral_value / applicant.annual_income) * 100)
        
        # Loan-to-value ratio
        loan_to_value = 0
        if applicant.collateral_value > 0:
            loan_to_value = applicant.loan_amount / applicant.collateral_value
        
        # Weighted combination
        risk_score = (
            credit_score_factor * 0.3 +
            dti_factor * 0.25 +
            income_stability * 0.2 +
            collateral_factor * 0.2 +
            (100 - (loan_to_value * 100)) * 0.05
        )
        
        return round(risk_score, 2)
    
    def get_dti_threshold(self, zip_code: str) -> float:
        """Get appropriate DTI threshold based on zip code"""
        # Find the closest zip code threshold
        zip_code_num = int(zip_code[:5]) if zip_code.isdigit() else 0
        
        # Find the appropriate threshold
        thresholds = sorted(self.zip_code_thresholds.items(), key=lambda x: int(x[0]))
        
        for threshold_zip, threshold_value in thresholds:
            if zip_code_num <= int(threshold_zip):
                return threshold_value
        
        return self.zip_code_thresholds["00000"]  # Default
    
    def make_loan_decision(self, applicant: Applicant) -> LoanStatus:
        """Make automated loan decision"""
        # Calculate required metrics
        applicant.debt_to_income_ratio = self.calculate_debt_to_income_ratio(applicant)
        applicant.risk_score = self.calculate_risk_score(applicant)
        
        # Get DTI threshold for zip code
        dti_threshold = self.get_dti_threshold(applicant.zip_code)
        
        # Decision logic
        if applicant.risk_score >= 70 and applicant.debt_to_income_ratio <= dti_threshold:
            return LoanStatus.APPROVED
        elif applicant.risk_score < 40 or applicant.debt_to_income_ratio > dti_threshold * 1.5:
            return LoanStatus.DENIED
        else:
            return LoanStatus.MANUAL_REVIEW
    
    def add_applicant(self, applicant_data: Dict) -> Applicant:
        """Add a new applicant to the system"""
        applicant = Applicant(**applicant_data)
        self.applicants.append(applicant)
        return applicant
    
    def process_all_applicants(self) -> None:
        """Process all applicants in the system"""
        for applicant in self.applicants:
            applicant.loan_status = self.make_loan_decision(applicant)
    
    def generate_summary_report(self) -> Dict:
        """Generate a summary report of all loan decisions"""
        if not self.applicants:
            return {"message": "No applicants to process"}
        
        total_applicants = len(self.applicants)
        approved_count = sum(1 for a in self.applicants if a.loan_status == LoanStatus.APPROVED)
        denied_count = sum(1 for a in self.applicants if a.loan_status == LoanStatus.DENIED)
        manual_review_count = sum(1 for a in self.applicants if a.loan_status == LoanStatus.MANUAL_REVIEW)
        
        # Average metrics
        avg_dti = sum(a.debt_to_income_ratio for a in self.applicants if a.debt_to_income_ratio is not None) / total_applicants if total_applicants > 0 else 0
        avg_risk = sum(a.risk_score for a in self.applicants if a.risk_score is not None) / total_applicants if total_applicants > 0 else 0
        
        # Zip code distribution
        zip_code_distribution = {}
        for applicant in self.applicants:
            zip_code_distribution[applicant.zip_code] = zip_code_distribution.get(applicant.zip_code, 0) + 1
        
        report = {
            "report_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_applicants": total_applicants,
            "approved": approved_count,
            "denied": denied_count,
            "manual_review": manual_review_count,
            "approval_rate": round((approved_count / total_applicants) * 100, 2) if total_applicants > 0 else 0,
            "average_debt_to_income_ratio": round(avg_dti, 4),
            "average_risk_score": round(avg_risk, 2),
            "zip_code_distribution": zip_code_distribution,
            "applicants": [
                {
                    "applicant_id": a.applicant_id,
                    "name": a.name,
                    "loan_amount": a.loan_amount,
                    "annual_income": a.annual_income,
                    "debt_to_income_ratio": a.debt_to_income_ratio,
                    "risk_score": a.risk_score,
                    "loan_status": a.loan_status.value,
                    "zip_code": a.zip_code
                } for a in self.applicants
            ]
        }
        
        return report
    
    def save_report(self, filename: str = "loan_approval_report.json") -> None:
        """Save the report to a JSON file"""
        report = self.generate_summary_report()
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
        print(f"Report saved to {filename}")

def main():
    """Main function to demonstrate the loan approval system"""
    # Create loan approval system
    loan_system = LoanApprovalSystem()
    
    # Sample applicant data
    sample_applicants = [
        {
            "applicant_id": "A001",
            "name": "John Smith",
            "annual_income": 75000,
            "monthly_debt": 1200,
            "credit_score": 720,
            "zip_code": "10001",
            "collateral_value": 150000,
            "loan_amount": 30000,
            "loan_term_months": 36,
            "employment_years": 5
        },
        {
            "applicant_id": "A002",
            "name": "Jane Doe",
            "annual_income": 50000,
            "monthly_debt": 2000,
            "credit_score": 650,
            "zip_code": "20001",
            "collateral_value": 80000,
            "loan_amount": 40000,
            "loan_term_months": 60,
            "employment_years": 3
        },
        {
            "applicant_id": "A003",
            "name": "Robert Johnson",
            "annual_income": 90000,
            "monthly_debt": 3000,
            "credit_score": 780,
            "zip_code": "30001",
            "collateral_value": 200000,
            "loan_amount": 150000,
            "loan_term_months": 84,
            "employment_years": 8
        },
        {
            "applicant_id": "A004",
            "name": "Emily Wilson",
            "annual_income": 40000,
            "monthly_debt": 1800,
            "credit_score": 620,
            "zip_code": "40001",
            "collateral_value": 50000,
            "loan_amount": 25000,
            "loan_term_months": 48,
            "employment_years": 2
        }
    ]
    
    # Add applicants to the system
    print("Adding applicants to the system...")
    for applicant_data in sample_applicants:
        loan_system.add_applicant(applicant_data)
        print(f"Added applicant: {applicant_data['name']}")
    
    # Process all applicants
    print("\nProcessing all applicants...")
    loan_system.process_all_applicants()
    
    # Generate and display summary report
    print("\nGenerating summary report...")
    report = loan_system.generate_summary_report()
    
    print("\n" + "="*60)
    print("LOAN APPROVAL SYSTEM SUMMARY REPORT")
    print("="*60)
    print(f"Report Date: {report['report_date']}")
    print(f"Total Applicants: {report['total_applicants']}")
    print(f"Approved: {report['approved']}")
    print(f"Denied: {report['denied']}")
    print(f"Manual Review: {report['manual_review']}")
    print(f"Approval Rate: {report['approval_rate']}%")
    print(f"Average DTI Ratio: {report['average_debt_to_income_ratio']}")
    print(f"Average Risk Score: {report['average_risk_score']}")
    print("\nZip Code Distribution:")
    for zip_code, count in report['zip_code_distribution'].items():
        print(f"  {zip_code}: {count} applicants")
    
    print("\nDetailed Applicant Decisions:")
    print("-" * 80)
    print(f"{'ID':<8} {'Name':<15} {'Loan Amount':<12} {'DTI':<8} {'Risk':<8} {'Status':<15}")
    print("-" * 80)
    for applicant in report['applicants']:
        print(f"{applicant['applicant_id']:<8} {applicant['name']:<15} ${applicant['loan_amount']:<11} "
              f"{applicant['debt_to_income_ratio']:<8} {applicant['risk_score']:<8} {applicant['loan_status']:<15}")
    
    # Save report to file
    loan_system.save_report("loan_approval_report.json")
    print("\n" + "="*60)
    print("Report saved to loan_approval_report.json")
    print("="*60)

if __name__ == "__main__":
    main()