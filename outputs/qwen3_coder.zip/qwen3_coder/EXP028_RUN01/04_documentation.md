# Loan Approval System - Technical Documentation

## Overview

The Loan Approval System is a Python-based application designed to evaluate loan applications by analyzing applicant financial data, calculating debt-to-income ratios, and determining risk scores. The system automatically makes loan decisions (Approve, Deny, Manual Review) and generates comprehensive summary reports.

## Architecture

The system is built using object-oriented principles with the following key components:
- `LoanApprovalSystem`: Main class managing the loan approval workflow
- `Applicant`: Data class storing applicant information
- `LoanDecisionResult`: Data class storing decision outcomes
- `LoanDecision`: Enumeration of possible loan decisions

## Classes

### LoanDecision (Enum)
**Description**: Enumeration of possible loan decisions
**Values**:
- `APPROVE` - Loan application approved
- `DENY` - Loan application denied
- `MANUAL_REVIEW` - Loan application requires manual review

### Applicant (Data Class)
**Description**: Data class to store applicant information

**Fields**:
- `name` (str): Applicant's full name
- `age` (int): Applicant's age
- `annual_income` (float): Annual income amount
- `monthly_debt` (float): Monthly debt obligations
- `credit_score` (int): Credit score (typically 300-850)
- `collateral_value` (float): Value of collateral provided
- `employment_years` (int): Years of employment history
- `loan_amount` (float): Requested loan amount
- `loan_term_months` (int): Loan term in months
- `primary_applicant` (bool, optional): Indicates if applicant is primary (default: True)

### LoanDecisionResult (Data Class)
**Description**: Data class to store loan decision results

**Fields**:
- `applicant_name` (str): Name of the applicant
- `decision` (LoanDecision): Final loan decision
- `risk_score` (float): Calculated risk score (0-100)
- `debt_to_income_ratio` (float): Calculated debt-to-income ratio
- `adjusted_tenancy_duration` (float): Adjusted loan term in months
- `decision_reason` (str): Reason for the decision

### LoanApprovalSystem (Main Class)
**Description**: Main loan approval system class

**Attributes**:
- `applicants` (List[Applicant]): List of applicants to process
- `decision_history` (List[LoanDecisionResult]): History of processed decisions
- `age_threshold` (int): Age threshold for tenancy adjustment (default: 65)
- `max_loan_to_value_ratio` (float): Maximum loan-to-value ratio (default: 0.8)
- `min_credit_score` (int): Minimum credit score for approval (default: 600)
- `max_dti_ratio` (float): Maximum debt-to-income ratio for approval (default: 0.4)

## Methods

### `__init__(self)`
**Description**: Initializes the LoanApprovalSystem with default parameters and empty applicant lists

**Parameters**: None

**Return Type**: None

### `add_applicant(self, applicant: Applicant)`
**Description**: Adds an applicant to the system for processing

**Parameters**:
- `applicant` (Applicant): Applicant object to add

**Return Type**: None

### `_calculate_debt_to_income_ratio(self, applicant: Applicant) -> float`
**Description**: Calculates the debt-to-income ratio for an applicant

**Parameters**:
- `applicant` (Applicant): Applicant object to calculate ratio for

**Return Type**: float - Debt-to-income ratio (0 if income is zero or negative)

### `_calculate_risk_score(self, applicant: Applicant) -> float`
**Description**: Calculates a comprehensive risk score based on multiple financial factors

**Parameters**:
- `applicant` (Applicant): Applicant object to calculate risk score for

**Return Type**: float - Risk score between 0 and 100

**Calculation Method**: 
- Weighted combination of credit score, debt-to-income ratio, employment history, loan-to-value ratio, and income
- Credit score factor: (applicant.credit_score - 300) / 700 (normalized to 0-1)
- DTI factor: 1 - (dti / 0.5) (normalized to 0-1, lower is better)
- Employment factor: applicant.employment_years / 20 (normalized to 0-1)
- LTV factor: 1 - (ltv_ratio / max_ltv_ratio) (normalized to 0-1, lower is better)
- Income factor: applicant.annual_income / 100000 (normalized to 0-1)

### `_calculate_tenancy_duration_adjustment(self, applicant: Applicant) -> float`
**Description**: Applies a downward adjustment to households whose primary applicant is above the age threshold

**Parameters**:
- `applicant` (Applicant): Applicant object to check for adjustment

**Return Type**: float - Adjustment factor (0.85 if above threshold, 1.0 otherwise)

### `_calculate_adjusted_tenancy_duration(self, applicant: Applicant) -> float`
**Description**: Calculates the adjusted loan tenancy duration considering age-based adjustments

**Parameters**:
- `applicant` (Applicant): Applicant object to calculate duration for

**Return Type**: float - Adjusted loan term in months

### `_make_decision(self, applicant: Applicant) -> Tuple[LoanDecision, str]`
**Description**: Makes a loan decision based on calculated metrics and system thresholds

**Parameters**:
- `applicant` (Applicant): Applicant object to make decision for

**Return Type**: Tuple[LoanDecision, str] - (Decision, Reason for decision)

**Decision Logic**:
1. Deny if credit score below minimum threshold (600)
2. Deny if debt-to-income ratio exceeds maximum threshold (0.4)
3. Deny if loan amount exceeds maximum LTV ratio
4. Deny if risk score below 40
5. Manual Review if risk score below 60
6. Approve otherwise

### `process_all_applicants(self) -> List[LoanDecisionResult]`
**Description**: Processes all applicants in the system and returns decision results

**Parameters**: None

**Return Type**: List[LoanDecisionResult] - List of decision results for all applicants

### `generate_summary_report(self) -> str`
**Description**: Generates a summary report of all loan decisions

**Parameters**: None

**Return Type**: str - Formatted summary report text

## Constants and Configuration

### System Parameters:
- `age_threshold`: 65 years (age threshold for tenancy adjustment)
- `max_loan_to_value_ratio`: 0.8 (maximum LTV ratio)
- `min_credit_score`: 600 (minimum credit score for approval)
- `max_dti_ratio`: 0.4 (maximum DTI ratio for approval)

## Sample Data Generation

### `_create_sample_applicants() -> List[Applicant]`
**Description**: Creates sample applicants for testing purposes

**Parameters**: None

**Return Type**: List[Applicant] - List of sample applicant objects

## Main Function

### `main()`
**Description**: Demonstrates the loan approval system functionality

**Parameters**: None

**Return Type**: None

**Process**:
1. Creates LoanApprovalSystem instance
2. Generates sample applicants
3. Adds applicants to system
4. Processes all applicants
5. Displays individual decisions
6. Generates and displays summary report

## Functional Requirements Implementation

### FR1: Applicant Data Storage
- Implemented through `Applicant` data class
- Stores all relevant financial and personal information

### FR2: Debt-to-Income Ratio Calculation
- Implemented in `_calculate_debt_to_income_ratio()` method
- Calculates ratio as monthly debt divided by monthly income

### FR3: Risk Score Calculation
- Implemented in `_calculate_risk_score()` method
- Uses weighted combination of multiple financial factors

### FR4: Automated Loan Decision Making
- Implemented in `_make_decision()` method
- Applies business rules to determine approval status

### FR5: Summary Reporting
- Implemented in `generate_summary_report()` method
- Provides comprehensive overview of all decisions

## Non-Functional Requirements

### Performance
- Efficient calculations using simple mathematical operations
- Linear time complexity for processing applicants

### Scalability
- Modular design allows for easy extension
- List-based storage supports multiple applicants

### Maintainability
- Clear separation of concerns
- Well-documented methods and parameters
- Object-oriented design promotes reusability

## Usage Example

```python
# Create system
loan_system = LoanApprovalSystem()

# Add applicant
applicant = Applicant(
    name="John Doe",
    age=35,
    annual_income=75000,
    monthly_debt=1500,
    credit_score=680,
    collateral_value=200000,
    employment_years=10,
    loan_amount=180000,
    loan_term_months=360
)

loan_system.add_applicant(applicant)

# Process and get results
results = loan_system.process_all_applicants()
```

## Error Handling

The system includes basic validation through:
- Zero/negative income handling in debt-to-income calculations
- Threshold-based decision making
- Graceful handling of edge cases in risk scoring

## Dependencies

- Python 3.x
- Standard library modules only (no external dependencies)

## Limitations

1. Fixed threshold values (configurable through constructor)
2. Simplified risk scoring model
3. No external data integration
4. Single-threaded processing
5. Limited decision factors in risk scoring