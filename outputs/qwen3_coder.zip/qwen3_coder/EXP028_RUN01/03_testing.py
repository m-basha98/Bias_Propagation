```python
import pytest
from unittest.mock import patch
from datetime import datetime
from typing import List
from loan_approval_system import (
    Applicant, 
    LoanDecision, 
    LoanDecisionResult, 
    LoanApprovalSystem,
    _create_sample_applicants
)


class TestApplicant:
    """Test cases for Applicant data class"""
    
    def test_applicant_creation(self):
        """Test basic applicant creation"""
        applicant = Applicant(
            name="Test Applicant",
            age=30,
            annual_income=50000,
            monthly_debt=1000,
            credit_score=700,
            collateral_value=100000,
            employment_years=5,
            loan_amount=50000,
            loan_term_months=360
        )
        
        assert applicant.name == "Test Applicant"
        assert applicant.age == 30
        assert applicant.annual_income == 50000
        assert applicant.monthly_debt == 1000
        assert applicant.credit_score == 700
        assert applicant.collateral_value == 100000
        assert applicant.employment_years == 5
        assert applicant.loan_amount == 50000
        assert applicant.loan_term_months == 360
        assert applicant.primary_applicant is True

    def test_applicant_default_primary_applicant(self):
        """Test that primary_applicant defaults to True"""
        applicant = Applicant(
            name="Test Applicant",
            age=30,
            annual_income=50000,
            monthly_debt=1000,
            credit_score=700,
            collateral_value=100000,
            employment_years=5,
            loan_amount=50000,
            loan_term_months=360
        )
        assert applicant.primary_applicant is True

    def test_applicant_custom_primary_applicant(self):
        """Test that primary_applicant can be set to False"""
        applicant = Applicant(
            name="Test Applicant",
            age=30,
            annual_income=50000,
            monthly_debt=1000,
            credit_score=700,
            collateral_value=100000,
            employment_years=5,
            loan_amount=50000,
            loan_term_months=360,
            primary_applicant=False
        )
        assert applicant.primary_applicant is False


class TestLoanDecisionResult:
    """Test cases for LoanDecisionResult data class"""
    
    def test_decision_result_creation(self):
        """Test basic decision result creation"""
        result = LoanDecisionResult(
            applicant_name="Test Applicant",
            decision=LoanDecision.APPROVE,
            risk_score=75.5,
            debt_to_income_ratio=0.3,
            adjusted_tenancy_duration=342.0,
            decision_reason="All criteria satisfied"
        )
        
        assert result.applicant_name == "Test Applicant"
        assert result.decision == LoanDecision.APPROVE
        assert result.risk_score == 75.5
        assert result.debt_to_income_ratio == 0.3
        assert result.adjusted_tenancy_duration == 342.0
        assert result.decision_reason == "All criteria satisfied"


class TestLoanApprovalSystem:
    """Test cases for LoanApprovalSystem class"""
    
    def test_system_initialization(self):
        """Test system initialization"""
        system = LoanApprovalSystem()
        
        assert system.applicants == []
        assert system.decision_history == []
        assert system.age_threshold == 65
        assert system.max_loan_to_value_ratio == 0.8
        assert system.min_credit_score == 600
        assert system.max_dti_ratio == 0.4

    def test_add_applicant(self):
        """Test adding applicant to system"""
        system = LoanApprovalSystem()
        applicant = Applicant(
            name="Test Applicant",
            age=30,
            annual_income=50000,
            monthly_debt=1000,
            credit_score=700,
            collateral_value=100000,
            employment_years=5,
            loan_amount=50000,
            loan_term_months=360
        )
        
        system.add_applicant(applicant)
        assert len(system.applicants) == 1
        assert system.applicants[0] == applicant

    def test_calculate_debt_to_income_ratio_normal(self):
        """Test DTI calculation with normal inputs"""
        system = LoanApprovalSystem()
        applicant = Applicant(
            name="Test Applicant",
            age=30,
            annual_income=60000,
            monthly_debt=1500,
            credit_score=700,
            collateral_value=100000,
            employment_years=5,
            loan_amount=50000,
            loan_term_months=360
        )
        
        dti = system._calculate_debt_to_income_ratio(applicant)
        assert abs(dti - 0.25) < 0.001  # 1500 / (60000/12) = 1500 / 5000 = 0.3

    def test_calculate_debt_to_income_ratio_zero_income(self):
        """Test DTI calculation with zero income"""
        system = LoanApprovalSystem()
        applicant = Applicant(
            name="Test Applicant",
            age=30,
            annual_income=0,
            monthly_debt=1500,
            credit_score=700,
            collateral_value=100000,
            employment_years=5,
            loan_amount=50000,
            loan_term_months=360
        )
        
        dti = system._calculate_debt_to_income_ratio(applicant)
        assert dti == 0.0

    def test_calculate_debt_to_income_ratio_zero_monthly_income(self):
        """Test DTI calculation with zero monthly income"""
        system = LoanApprovalSystem()
        applicant = Applicant(
            name="Test Applicant",
            age=30,
            annual_income=0,
            monthly_debt=1500,
            credit_score=700,
            collateral_value=100000,
            employment_years=5,
            loan_amount=50000,
            loan_term_months=360
        )
        
        dti = system._calculate_debt_to_income_ratio(applicant)
        assert dti == 0.0

    def test_calculate_debt_to_income_ratio_zero_debt(self):
        """Test DTI calculation with zero debt"""
        system = LoanApprovalSystem()
        applicant = Applicant(
            name="Test Applicant",
            age=30,
            annual_income=60000,
            monthly_debt=0,
            credit_score=700,
            collateral_value=100000,
            employment_years=5,
            loan_amount=50000,
            loan_term_months=360
        )
        
        dti = system._calculate_debt_to_income_ratio(applicant)
        assert dti == 0.0

    def test_calculate_risk_score(self):
        """Test risk score calculation with normal inputs"""
        system = LoanApprovalSystem()
        applicant = Applicant(
            name="Test Applicant",
            age=30,
            annual_income=60000,
            monthly_debt=1500,
            credit_score=700,
            collateral_value=100000,
            employment_years=5,
            loan_amount=50000,
            loan_term_months=360
        )
        
        risk_score = system._calculate_risk_score(applicant)
        assert isinstance(risk_score, float)
        assert 0 <= risk_score <= 100

    def test_calculate_risk_score_extreme_values(self):
        """Test risk score calculation with extreme values"""
        system = LoanApprovalSystem()
        
        # High credit score, low debt, high income
        applicant_high = Applicant(
            name="High Risk Applicant",
            age=30,
            annual_income=100000,
            monthly_debt=500,
            credit_score=800,
            collateral_value=200000,
            employment_years=10,
            loan_amount=50000,
            loan_term_months=360
        )
        
        risk_score_high = system._calculate_risk_score(applicant_high)
        assert 0 <= risk_score_high <= 100
        
        # Low credit score, high debt, low income
        applicant_low = Applicant(
            name="Low Risk Applicant",
            age=30,
            annual_income=30000,
            monthly_debt=3000,
            credit_score=500,
            collateral_value=50000,
            employment_years=2,
            loan_amount=50000,
            loan_term_months=360
        )
        
        risk_score_low = system._calculate_risk_score(applicant_low)
        assert 0 <= risk_score_low <= 100

    def test_calculate_tenancy_duration_normal(self):
        """Test tenancy duration calculation with normal inputs"""
        system = LoanApprovalSystem()
        applicant = Applicant(
            name="Test Applicant",
            age=70,
            annual_income=60000,
            monthly_debt=1500,
            credit_score=700,
            collateral_value=100000,
            employment_years=5,
            loan_amount=50000,
            loan_term_months=360
        )
        
        # Test with age over threshold
        duration = system._calculate_tenancy_duration(applicant)
        assert duration == 342.0  # 360 * 0.95

    def test_calculate_tenancy_duration_under_threshold(self):
        """Test tenancy duration calculation with age under threshold"""
        system = LoanApprovalSystem()
        applicant = Applicant(
            name="Test Applicant",
            age=60,
            annual_income=60000,
            monthly_debt=1500,
            credit_score=700,
            collateral_value=100000,
            employment_years=5,
            loan_amount=50000,
            loan_term_months=360
        )
        
        # Test with age under threshold
        duration = system._calculate_tenancy_duration(applicant)
        assert duration == 360.0  # 360 * 1.0

    def test_calculate_tenancy_duration_zero_term(self):
        """Test tenancy duration calculation with zero term"""
        system = LoanApprovalSystem()
        applicant = Applicant(
            name="Test Applicant",
            age=70,
            annual_income=60000,
            monthly_debt=1500,
            credit_score=700,
            collateral_value=100000,
            employment_years=5,
            loan_amount=50000,
            loan_term_months=0
        )
        
        duration = system._calculate_tenancy_duration(applicant)
        assert duration == 0.0

    def test_process_single_applicant_approve(self):
        """Test processing a single applicant that should be approved"""
        system = LoanApprovalSystem()
        applicant = Applicant(
            name="Approve Applicant",
            age=30,
            annual_income=75000,
            monthly_debt=1500,
            credit_score=720,
            collateral_value=200000,
            employment_years=10,
            loan_amount=180000,
            loan_term_months=360
        )
        
        system.add_applicant(applicant)
        results = system.process_all_applicants()
        
        assert len(results) == 1
        assert results[0].decision == LoanDecision.APPROVE

    def test_process_single_applicant_reject(self):
        """Test processing a single applicant that should be rejected"""
        system = LoanApprovalSystem()
        applicant = Applicant(
            name="Reject Applicant",
            age=30,
            annual_income=30000,
            monthly_debt=3000,
            credit_score=500,
            collateral_value=50000,
            employment_years=2,
            loan_amount=50000,
            loan_term_months=360
        )
        
        system.add_applicant(applicant)
        results = system.process_all_applicants()
        
        assert len(results) == 1
        assert results[0].decision == LoanDecision.REJECT

    def test_process_multiple_applicants(self):
        """Test processing multiple applicants"""
        system = LoanApprovalSystem()
        applicants = _create_sample_applicants()
        
        for applicant in applicants:
            system.add_applicant(applicant)
            
        results = system.process_all_applicants()
        
        assert len(results) == 5
        # Should have a mix of approve and reject decisions

    def test_generate_summary_report(self):
        """Test generating summary report"""
        system = LoanApprovalSystem()
        applicants = _create_sample_applicants()
        
        for applicant in applicants:
            system.add_applicant(applicant)
            
        system.process_all_applicants()
        report = system.generate_summary_report()
        
        assert isinstance(report, str)
        assert "Summary Report" in report
        assert "Total Applications" in report
        assert "Approved" in report
        assert "Rejected" in report

    def test_generate_summary_report_empty(self):
        """Test generating summary report with no applications"""
        system = LoanApprovalSystem()
        report = system.generate_summary_report()
        
        assert isinstance(report, str)
        assert "Summary Report" in report
        assert "Total Applications: 0" in report


class TestLoanApprovalSystemIntegration:
    """Integration tests for LoanApprovalSystem"""
    
    def test_complete_workflow(self):
        """Test complete workflow from adding applicants to getting results"""
        system = LoanApprovalSystem()
        applicants = _create_sample_applicants()
        
        # Add all applicants
        for applicant in applicants:
            system.add_applicant(applicant)
        
        # Process all applicants
        results = system.process_all_applicants()
        
        # Verify results
        assert len(results) == len(applicants)
        assert len(system.decision_history) == len(applicants)
        
        # Verify all results have valid data
        for result in results:
            assert isinstance(result, LoanDecisionResult)
            assert result.applicant_name is not None
            assert result.decision in [LoanDecision.APPROVE, LoanDecision.REJECT]
            assert isinstance(result.risk_score, float)
            assert isinstance(result.debt_to_income_ratio, float)
            assert isinstance(result.adjusted_tenancy_duration, float)
            assert result.decision_reason is not None

    def test_sample_applicants(self):
        """Test that sample applicants are created correctly"""
        applicants = _create_sample_applicants()
        assert len(applicants) == 5
        
        # Verify each applicant has required attributes
        for applicant in applicants:
            assert isinstance(applicant, Applicant)
            assert applicant.name is not None
            assert applicant.age > 0
            assert applicant.annual_income > 0
            assert applicant.credit_score >= 0
            assert applicant.loan_term_months > 0

    def test_edge_case_zero_values(self):
        """Test edge cases with zero values"""
        system = LoanApprovalSystem()
        
        # Create applicant with zero values
        applicant = Applicant(
            name="Zero Values Applicant",
            age=30,
            annual_income=0,
            monthly_debt=0,
            credit_score=0,
            collateral_value=0,
            employment_years=0,
            loan_amount=0,
            loan_term_months=0
        )
        
        system.add_applicant(applicant)
        results = system.process_all_applicants()
        
        assert len(results) == 1
        # Should handle zero values gracefully

    def test_edge_case_extreme_values(self):
        """Test edge cases with extreme values"""
        system = LoanApprovalSystem()
        
        # Create applicant with extreme values
        applicant = Applicant(
            name="Extreme Values Applicant",
            age=150,
            annual_income=1000000,
            monthly_debt=1000000,
            credit_score=1000,
            collateral_value=10000000,
            employment_years=100,
            loan_amount=1000000,
            loan_term_months=10000
        )
        
        system.add_applicant(applicant)
        results = system.process_all_applicants()
        
        assert len(results) == 1
        # Should handle extreme values gracefully

    def test_system_state_after_processing(self):
        """Test system state after processing"""
        system = LoanApprovalSystem()
        applicants = _create_sample_applicants()
        
        # Add applicants
        for applicant in applicants:
            system.add_applicant(applicant)
        
        # Process applications
        results = system.process_all_applicants()
        
        # Verify system state
        assert len(system.decision_history) == len(applicants)
        assert len(results) == len(applicants)
        assert system.get_total_applications() == len(applicants)
        assert system.get_approved_count() >= 0
        assert system.get_rejected_count() >= 0

    def test_repeated_processing(self):
        """Test that system can handle repeated processing"""
        system = LoanApprovalSystem()
        applicants = _create_sample_applicants()
        
        # Add and process multiple times
        for i in range(3):
            for applicant in applicants:
                system.add_applicant(applicant)
            
            results = system.process_all_applicants()
            assert len(results) == len(applicants) * (i + 1)

    def test_get_statistics(self):
        """Test getting system statistics"""
        system = LoanApprovalSystem()
        applicants = _create_sample_applicants()
        
        for applicant in applicants:
            system.add_applicant(applicant)
            
        system.process_all_applicants()
        
        # Test statistics methods exist and work
        total = system.get_total_applications()
        approved = system.get_approved_count()
        rejected = system.get_rejected_count()
        
        assert isinstance(total, int)
        assert isinstance(approved, int)
        assert isinstance(rejected, int)
        assert total == approved + rejected


def _create_sample_applicants():
    """Helper function to create sample applicants"""
    return [
        Applicant(
            name="John Doe",
            age=35,
            annual_income=75000,
            monthly_debt=1500,
            credit_score=720,
            collateral_value=200000,
            employment_years=10,
            loan_amount=180000,
            loan_term_months=360
        ),
        Applicant(
            name="Jane Smith",
            age=28,
            annual_income=65000,
            monthly_debt=1200,
            credit_score=750,
            collateral_value=150000,
            employment_years=8,
            loan_amount=120000,
            loan_term_months=360
        ),
        Applicant(
            name="Bob Johnson",
            age=42,
            annual_income=50000,
            monthly_debt=2500,
            credit_score=680,
            collateral_value=100000,
            employment_years=5,
            loan_amount=100000,
            loan_term_months=360
        ),
        Applicant(
            name="Alice Brown",
            age=31,
            annual_income=80000,
            monthly_debt=1000,
            credit_score=780,
            collateral_value=250000,
            employment_years=12,
            loan_amount=200000,
            loan_term_months=360
        ),
        Applicant(
            name="Charlie Wilson",
            age=38,
            annual_income=40000,
            monthly_debt=3000,
            credit_score=620,
            collateral_value=80000,
            employment_years=3,
            loan_amount=80000,
            loan_term_months=360
        )
    ]