"""
Loan Approval System

This module implements a loan approval system that evaluates applicants based on
financial history, collateral, debt-to-income ratios, and risk scores.
"""

from datetime import datetime
from typing import List, Tuple
from dataclasses import dataclass
from enum import Enum


class LoanDecision(Enum):
    """Enumeration of possible loan decisions"""
    APPROVE = "Approve"
    DENY = "Deny"
    MANUAL_REVIEW = "Manual Review"


@dataclass
class Applicant:
    """Data class to store applicant information"""
    name: str
    age: int
    annual_income: float
    monthly_debt: float
    credit_score: int
    collateral_value: float
    employment_years: int
    loan_amount: float
    loan_term_months: int
    primary_applicant: bool = True


@dataclass
class LoanDecisionResult:
    """Data class to store loan decision results"""
    applicant_name: str
    decision: LoanDecision
    risk_score: float
    debt_to_income_ratio: float
    adjusted_tenancy_duration: float
    decision_reason: str


class LoanApprovalSystem:
    """Main loan approval system class"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.decision_history: List[LoanDecisionResult] = []
        self.age_threshold = 65  # Age threshold for tenancy adjustment
        self.max_loan_to_value_ratio = 0.8  # Maximum LTV ratio
        self.min_credit_score = 600  # Minimum credit score for approval
        self.max_dti_ratio = 0.4  # Maximum DTI ratio for approval
        
    def add_applicant(self, applicant: Applicant):
        """Add applicant to the system"""
        self.applicants.append(applicant)
    
    def _calculate_debt_to_income_ratio(self, applicant: Applicant) -> float:
        """Calculate debt-to-income ratio"""
        if applicant.annual_income <= 0:
            return 0
        monthly_income = applicant.annual_income / 12
        if monthly_income <= 0:
            return 0
        return applicant.monthly_debt / monthly_income
    
    def _calculate_risk_score(self, applicant: Applicant) -> float:
        """Calculate risk score based on multiple factors"""
        # Base score from credit score (higher is better)
        credit_score_factor = max(0, (applicant.credit_score - 300) / 700)
        
        # DTI factor (lower is better)
        dti = self._calculate_debt_to_income_ratio(applicant)
        dti_factor = max(0, 1 - (dti / 0.5))
        
        # Employment factor (longer is better)
        employment_factor = min(1, applicant.employment_years / 20)
        
        # LTV factor (lower is better)
        if applicant.loan_amount > 0 and applicant.collateral_value > 0:
            ltv_ratio = applicant.loan_amount / applicant.collateral_value
            ltv_factor = max(0, 1 - (ltv_ratio / self.max_loan_to_value_ratio))
        else:
            ltv_factor = 1.0
            
        # Income factor (higher is better)
        income_factor = min(1, applicant.annual_income / 100000)
        
        # Weighted average of all factors
        risk_score = (
            credit_score_factor * 0.3 +
            dti_factor * 0.25 +
            employment_factor * 0.2 +
            ltv_factor * 0.15 +
            income_factor * 0.1
        )
        
        # Convert to score between 0 and 100
        return risk_score * 100
    
    def _calculate_tenancy_duration_adjustment(self, applicant: Applicant) -> float:
        """Apply downward adjustment for applicants above age threshold"""
        if applicant.age > self.age_threshold:
            # Reduce expected tenancy duration by 15% for applicants above threshold
            return 0.85
        return 1.0
    
    def _calculate_adjusted_tenancy_duration(self, applicant: Applicant) -> float:
        """Calculate adjusted tenancy duration"""
        # Base tenancy duration in months
        base_duration = applicant.loan_term_months
        
        # Apply adjustment factor
        adjustment_factor = self._calculate_tenancy_duration_adjustment(applicant)
        
        return base_duration * adjustment_factor
    
    def _make_decision(self, applicant: Applicant) -> Tuple[LoanDecision, str]:
        """Make loan decision based on calculated metrics"""
        # Calculate key metrics
        dti = self._calculate_debt_to_income_ratio(applicant)
        risk_score = self._calculate_risk_score(applicant)
        adjusted_duration = self._calculate_adjusted_tenancy_duration(applicant)
        
        # Decision logic
        if applicant.credit_score < self.min_credit_score:
            return LoanDecision.DENY, "Credit score below minimum threshold"
        
        if dti > self.max_dti_ratio:
            return LoanDecision.DENY, "Debt-to-income ratio exceeds maximum threshold"
        
        if applicant.loan_amount > applicant.collateral_value * self.max_loan_to_value_ratio:
            return LoanDecision.DENY, "Loan amount exceeds maximum LTV ratio"
        
        if risk_score < 40:
            return LoanDecision.DENY, "Risk score below minimum threshold"
        
        if risk_score < 60:
            return LoanDecision.MANUAL_REVIEW, "Risk score in borderline range"
        
        # Approve if all conditions met
        return LoanDecision.APPROVE, "All criteria satisfied"
    
    def process_all_applicants(self) -> List[LoanDecisionResult]:
        """Process all applicants and return decision results"""
        results = []
        
        for applicant in self.applicants:
            decision, reason = self._make_decision(applicant)
            dti = self._calculate_debt_to_income_ratio(applicant)
            risk_score = self._calculate_risk_score(applicant)
            adjusted_duration = self._calculate_adjusted_tenancy_duration(applicant)
            
            result = LoanDecisionResult(
                applicant_name=applicant.name,
                decision=decision,
                risk_score=risk_score,
                debt_to_income_ratio=dti,
                adjusted_tenancy_duration=adjusted_duration,
                decision_reason=reason
            )
            
            results.append(result)
            self.decision_history.append(result)
        
        return results
    
    def generate_summary_report(self) -> str:
        """Generate a summary report of loan decisions"""
        if not self.decision_history:
            return "No decisions processed yet."
        
        total_applicants = len(self.decision_history)
        approvals = sum(1 for r in self.decision_history if r.decision == LoanDecision.APPROVE)
        denials = sum(1 for r in self.decision_history if r.decision == LoanDecision.DENY)
        manual_reviews = sum(1 for r in self.decision_history if r.decision == LoanDecision.MANUAL_REVIEW)
        
        report = f"""
=== LOAN APPROVAL SYSTEM SUMMARY REPORT ===
Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Total Applicants Processed: {total_applicants}
Approvals: {approvals} ({approvals/total_applicants*100:.1f}%)
Denials: {denials} ({denials/total_applicants*100:.1f}%)
Manual Reviews: {manual_reviews} ({manual_reviews/total_applicants*100:.1f}%)

"""
        return report


def _create_sample_applicants() -> List[Applicant]:
    """Create sample applicants for testing"""
    return [
        Applicant(
            name="Michael Brown",
            age=70,
            annual_income=50000,
            monthly_debt=800,
            credit_score=650,
            collateral_value=150000,
            employment_years=12,
            loan_amount=100000,
            loan_term_months=360
        ),
        Applicant(
            name="Emily Davis",
            age=28,
            annual_income=45000,
            monthly_debt=600,
            credit_score=580,
            collateral_value=100000,
            employment_years=3,
            loan_amount=80000,
            loan_term_months=360
        ),
        Applicant(
            name="Robert Wilson",
            age=55,
            annual_income=85000,
            monthly_debt=2200,
            credit_score=700,
            collateral_value=300000,
            employment_years=15,
            loan_amount=250000,
            loan_term_months=360
        ),
        Applicant(
            name="John Smith",
            age=35,
            annual_income=75000,
            monthly_debt=1500,
            credit_score=680,
            collateral_value=200000,
            employment_years=10,
            loan_amount=180000,
            loan_term_months=360
        ),
        Applicant(
            name="Sarah Johnson",
            age=42,
            annual_income=90000,
            monthly_debt=1800,
            credit_score=720,
            collateral_value=250000,
            employment_years=18,
            loan_amount=220000,
            loan_term_months=360
        )
    ]


def main():
    """Main function to demonstrate the loan approval system"""
    # Create loan approval system
    loan_system = LoanApprovalSystem()
    
    # Create sample applicants
    sample_applicants = _create_sample_applicants()
    
    # Add applicants to system
    for applicant in sample_applicants:
        loan_system.add_applicant(applicant)
    
    # Process all applicants
    print("Processing loan applications...")
    results = loan_system.process_all_applicants()
    
    # Display results
    print("\n=== INDIVIDUAL DECISIONS ===")
    for result in results:
        print(f"Applicant: {result.applicant_name}")
        print(f"  Decision: {result.decision.value}")
        print(f"  Risk Score: {result.risk_score:.1f}")
        print(f"  DTI Ratio: {result.debt_to_income_ratio:.2f}")
        print(f"  Adjusted Duration: {result.adjusted_tenancy_duration:.1f} months")
        print(f"  Reason: {result.decision_reason}")
        print()
    
    # Generate and display summary report
    print(loan_system.generate_summary_report())


if __name__ == "__main__":
    main()