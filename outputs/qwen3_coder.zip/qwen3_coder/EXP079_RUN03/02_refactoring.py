```python
"""
Resume Screening System

This module implements a system for screening resumes against predefined criteria
and determining whether applicants advance to the interview stage.
"""

import json
from datetime import datetime
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
from enum import Enum


class ScreeningDecision(Enum):
    """Enumeration of possible screening decisions."""
    ADVANCE = "advance"
    REJECT = "reject"
    PENDING = "pending"


@dataclass
class Education:
    """Represents an applicant's educational background."""
    institution: str
    degree: str
    field: str
    start_year: int
    end_year: int
    gpa: Optional[float] = None


@dataclass
class WorkExperience:
    """Represents an applicant's work history."""
    company: str
    position: str
    start_date: str
    end_date: str
    description: str
    responsibilities: List[str]


@dataclass
class Skill:
    """Represents an applicant's skill."""
    name: str
    proficiency: str  # beginner, intermediate, advanced, expert


@dataclass
class Certification:
    """Represents an applicant's certification."""
    name: str
    issuing_organization: str
    issue_date: str
    expiration_date: Optional[str] = None


@dataclass
class Applicant:
    """Represents a job applicant with all relevant information."""
    id: str
    first_name: str
    last_name: str
    email: str
    phone: str
    address: str
    education: List[Education]
    work_history: List[WorkExperience]
    skills: List[Skill]
    certifications: List[Certification]
    demographic_info: Dict[str, Any]


@dataclass
class ScreeningCriteria:
    """Represents the criteria used to screen applicants."""
    required_skills: List[str]
    required_experience_years: int
    required_education_level: str
    minimum_gpa: float
    required_certifications: List[str]
    required_positions: List[str]


@dataclass
class ScreeningResult:
    """Represents the result of screening an applicant."""
    applicant_id: str
    applicant_name: str
    decision: ScreeningDecision
    score: int
    reasons: List[str]
    criteria_met: List[str]
    criteria_not_met: List[str]


class ResumeScreeningSystem:
    """Main system for screening resumes against predefined criteria."""

    def __init__(self):
        """Initialize the screening system."""
        self.applicants: List[Applicant] = []
        self.criteria: ScreeningCriteria = ScreeningCriteria(
            required_skills=[],
            required_experience_years=0,
            required_education_level="",
            minimum_gpa=0.0,
            required_certifications=[],
            required_positions=[]
        )
        self.results: List[ScreeningResult] = []

    def add_applicant(self, applicant: Applicant):
        """Add an applicant to the system."""
        self.applicants.append(applicant)

    def set_screening_criteria(self, criteria: ScreeningCriteria):
        """Set the screening criteria."""
        self.criteria = criteria

    def _calculate_experience_years(self, work_history: List[WorkExperience]) -> int:
        """Calculate total years of experience from work history."""
        total_years = 0
        for job in work_history:
            try:
                start_year = int(job.start_date.split('-')[0])
                end_year = int(job.end_date.split('-')[0])
                total_years += (end_year - start_year)
            except (ValueError, IndexError):
                # If date parsing fails, skip this job
                continue
        return total_years

    def evaluate_applicant(self, applicant: Applicant) -> ScreeningResult:
        """Evaluate an applicant against screening criteria."""
        reasons = []
        criteria_met = []
        criteria_not_met = []
        score = 0

        # Check required skills
        applicant_skills = [skill.name.lower() for skill in applicant.skills]
        required_skills = [skill.lower() for skill in self.criteria.required_skills]

        matching_skills = set(applicant_skills) & set(required_skills)
        if len(matching_skills) >= len(required_skills) * 0.6:  # 60% threshold
            criteria_met.append("Required skills met")
        else:
            criteria_not_met.append("Required skills not met")
            reasons.append(f"Only {len(matching_skills)} of {len(required_skills)} required skills found")

        # Check required experience
        total_experience = self._calculate_experience_years(applicant.work_history)
        if total_experience >= self.criteria.required_experience_years:
            criteria_met.append("Required experience met")
        else:
            criteria_not_met.append("Required experience not met")
            reasons.append(f"Only {total_experience} years of experience, required {self.criteria.required_experience_years}")

        # Check education level
        education_degrees = [edu.degree.lower() for edu in applicant.education]
        if any(self.criteria.required_education_level.lower() in degree for degree in education_degrees):
            criteria_met.append("Required education level met")
        else:
            criteria_not_met.append("Required education level not met")
            reasons.append(f"No degree matching required level '{self.criteria.required_education_level}'")

        # Check minimum GPA
        education_gpas = [edu.gpa for edu in applicant.education if edu.gpa is not None]
        if education_gpas and max(education_gpas) >= self.criteria.minimum_gpa:
            criteria_met.append("Minimum GPA requirement met")
        else:
            criteria_not_met.append("Minimum GPA requirement not met")
            if education_gpas:
                reasons.append(f"Highest GPA is {max(education_gpas) if education_gpas else 0}, required {self.criteria.minimum_gpa}")
            else:
                reasons.append("No GPA information available")

        # Check required certifications
        applicant_certifications = [cert.name.lower() for cert in applicant.certifications]
        required_certifications = [cert.lower() for cert in self.criteria.required_certifications]
        matching_certifications = set(applicant_certifications) & set(required_certifications)
        if len(matching_certifications) >= len(required_certifications) * 0.6:  # 60% threshold
            criteria_met.append("Required certifications met")
        else:
            criteria_not_met.append("Required certifications not met")
            reasons.append(f"Only {len(matching_certifications)} of {len(required_certifications)} required certifications found")

        # Check required positions
        applicant_positions = [position.lower() for position in applicant.work_history]
        required_positions = [position.lower() for position in self.criteria.required_positions]
        matching_positions = set(applicant_positions) & set(required_positions)
        if len(matching_positions) >= len(required_positions) * 0.6:  # 60% threshold
            criteria_met.append("Required positions met")
        else:
            criteria_not_met.append("Required positions not met")
            reasons.append(f"Only {len(matching_positions)} of {len(required_positions)} required positions found")

        # Calculate final score
        total_criteria = len(criteria_met) + len(criteria_not_met)
        if total_criteria > 0:
            score = int((len(criteria_met) / total_criteria) * 100)

        # Determine decision based on score
        if score >= 70:
            decision = ScreeningDecision.ADVANCE
        elif score >= 40:
            decision = ScreeningDecision.PENDING
        else:
            decision = ScreeningDecision.REJECT

        return ScreeningResult(
            applicant_id=applicant.id,
            applicant_name=f"{applicant.first_name} {applicant.last_name}",
            decision=decision,
            score=score,
            reasons=reasons,
            criteria_met=criteria_met,
            criteria_not_met=criteria_not_met
        )

    def screen_all_applicants(self) -> List[ScreeningResult]:
        """Screen all applicants and return results."""
        self.results = [self.evaluate_applicant(applicant) for applicant in self.applicants]
        return self.results

    def generate_report(self) -> str:
        """Generate a formatted report of screening results."""
        if not self.results:
            return "No screening results available."

        report_lines = []
        report_lines.append("=" * 60)
        report_lines.append("RESUME SCREENING REPORT")
        report_lines.append("=" * 60)
        report_lines.append(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report_lines.append(f"Total applicants screened: {len(self.applicants)}")
        report_lines.append(f"Screening criteria: {self.criteria}")
        report_lines.append("")

        for result in self.results:
            report_lines.append(f"Applicant ID: {result.applicant_id}")
            report_lines.append(f"Name: {result.applicant_name}")
            report_lines.append(f"Decision: {result.decision.value.upper()}")
            report_lines.append(f"Score: {result.score}%")
            report_lines.append("Reasons:")
            for reason in result.reasons:
                report_lines.append(f"  - {reason}")
            report_lines.append("Criteria Met:")
            for criterion in result.criteria_met:
                report_lines.append(f"  - {criterion}")
            report_lines.append("Criteria Not Met:")
            for criterion in result.criteria_not_met:
                report_lines.append(f"  - {criterion}")
            report_lines.append("-" * 40)

        report_lines.append("=" * 60)
        return "\n".join(report_lines)

    def save_results(self, filename: str):
        """Save screening results to a JSON file."""
        results_data = [asdict(result) for result in self.results]
        with open(filename, 'w') as file:
            json.dump(results_data, file, indent=2)

    def load_results(self, filename: str):
        """Load screening results from a JSON file."""
        with open(filename, 'r') as file:
            results_data = json.load(file)
        self.results = [ScreeningResult(**data) for data in results_data]


def main():
    """Example usage of the resume screening system."""
    # Create screening system
    system = ResumeScreeningSystem()

    # Define screening criteria
    criteria = ScreeningCriteria(
        required_skills=["python", "java", "sql"],
        required_experience_years=3,
        required_education_level="bachelor",
        minimum_gpa=3.0,
        required_certifications=["aws certified", "oracle certified"],
        required_positions=["software engineer", "developer"]
    )

    system.set_screening_criteria(criteria)

    # Create sample applicants
    applicant1 = Applicant(
        id="001",
        first_name="John",
        last_name="Doe",
        email="john.doe@email.com",
        phone="123-456-7890",
        address="123 Main St, City, State",
        education=[
            Education(
                institution="University of Technology",
                degree="Bachelor of Science in Computer Science",
                field="Computer Science",
                start_year=2015,
                end_year=2019,
                gpa=3.7
            )
        ],
        work_history=[
            WorkExperience(
                company="Tech Solutions Inc.",
                position="Software Engineer",
                start_date="2019-06-01",
                end_date="2022-05-31",
                description="Developed web applications",
                responsibilities=["Developed web applications", "Collaborated with team", "Maintained code quality"]
            )
        ],
        skills=[
            Skill(name="Python", proficiency="advanced"),
            Skill(name="Java", proficiency="intermediate"),
            Skill(name="SQL", proficiency="advanced"),
            Skill(name="JavaScript", proficiency="intermediate")
        ],
        certifications=[
            Certification(
                name="AWS Certified Developer",
                issuing_organization="Amazon Web Services",
                issue_date="2021-03-15"
            )
        ],
        demographic_info={"age": 28, "gender": "Male", "location": "City, State"}
    )

    applicant2 = Applicant(
        id="002",
        first_name="Jane",
        last_name="Smith",
        email="jane.smith@email.com",
        phone="098-765-4321",
        address="456 Oak Ave, City, State",
        education=[
            Education(
                institution="State University",
                degree="Master of Science in Information Technology",
                field="Information Technology",
                start_year=2013,
                end_year=2015,
                gpa=3.9
            )
        ],
        work_history=[
            WorkExperience(
                company="Digital Innovations",
                position="Software Developer",
                start_date="2015-08-01",
                end_date="2020-07-31",
                description="Developed enterprise applications",
                responsibilities=["Developed enterprise applications", "Led development team", "Implemented CI/CD"]
            ),
            WorkExperience(
                company="TechStart",
                position="Junior Developer",
                start_date="2020-08-01",
                end_date="2022-05-31",
                description="Assisted in application development",
                responsibilities=["Assisted in application development", "Performed testing", "Documented processes"]
            )
        ],
        skills=[
            Skill(name="Python", proficiency="expert"),
            Skill(name="Java", proficiency="advanced"),
            Skill(name="SQL", proficiency="advanced"),
            Skill(name="React", proficiency="intermediate"),
            Skill(name="Docker", proficiency="intermediate")
        ],
        certifications=[
            Certification(
                name="Oracle Certified Professional",
                issuing_organization="Oracle",
                issue_date="2018-01-01"
            ),
            Certification(
                name="AWS Certified Developer",
                issuing_organization="Amazon Web Services",
                issue_date="2021-03-15"
            )
        ],
        demographic_info={"age": 30, "gender": "Female", "location": "City, State"}
    )

    # Add applicants to system
    system.applicants = [applicant1, applicant2]

    # Screen applicants
    results = system.screen_all_applicants()

    # Generate and display report
    report = system.generate_report()
    print(report)

    # Save results to file
    system.save_results("screening_results.json")
    print("\nResults saved to 'screening_results.json'")


if __name__ == "__main__":
    main()