# Resume Screening System - Technical Documentation

## Overview
This document provides detailed technical documentation for the Resume Screening System, a Python-based application designed to evaluate job applicants against predefined screening criteria and determine their eligibility for the interview stage.

## System Architecture

The system is built using object-oriented programming principles with the following core components:

- **Data Models**: Representing applicant information, screening criteria, and results
- **Core Logic**: Evaluation algorithms for screening applicants
- **Reporting**: Generation of screening summaries
- **Persistence**: Saving and loading of screening results

## Data Models

### 1. ScreeningDecision (Enum)
**Description**: Enumeration of possible screening decisions
**Values**:
- `ADVANCE`: Applicant should advance to interview stage
- `REJECT`: Applicant should be rejected
- `PENDING`: Screening decision is pending further review

### 2. Education (Dataclass)
**Description**: Represents an applicant's educational background
**Fields**:
- `institution` (str): Name of educational institution
- `degree` (str): Degree earned
- `field` (str): Field of study
- `start_year` (int): Year of enrollment
- `end_year` (int): Year of graduation
- `gpa` (Optional[float]): Grade Point Average (default: None)

### 3. WorkExperience (Dataclass)
**Description**: Represents an applicant's work history
**Fields**:
- `company` (str): Name of employer
- `position` (str): Job position held
- `start_date` (str): Start date in YYYY-MM-DD format
- `end_date` (str): End date in YYYY-MM-DD format
- `description` (str): Job description
- `responsibilities` (List[str]): List of job responsibilities

### 4. Skill (Dataclass)
**Description**: Represents an applicant's skill
**Fields**:
- `name` (str): Name of skill
- `proficiency` (str): Proficiency level (beginner, intermediate, advanced, expert)

### 5. Certification (Dataclass)
**Description**: Represents an applicant's certification
**Fields**:
- `name` (str): Certification name
- `issuing_organization` (str): Organization that issued certification
- `issue_date` (str): Issue date in YYYY-MM-DD format
- `expiration_date` (Optional[str]): Expiration date in YYYY-MM-DD format (default: None)

### 6. Applicant (Dataclass)
**Description**: Represents a job applicant with all relevant information
**Fields**:
- `id` (str): Unique applicant identifier
- `first_name` (str): Applicant's first name
- `last_name` (str): Applicant's last name
- `email` (str): Contact email address
- `phone` (str): Contact phone number
- `address` (str): Physical address
- `education` (List[Education]): List of educational backgrounds
- `work_history` (List[WorkExperience]): List of work experiences
- `skills` (List[Skill]): List of applicant skills
- `certifications` (List[Certification]): List of certifications
- `demographic_info` (Dict[str, Any]): Dictionary containing demographic information

### 7. ScreeningCriteria (Dataclass)
**Description**: Represents the criteria used to screen applicants
**Fields**:
- `required_skills` (List[str]): List of required technical skills
- `required_experience_years` (int): Minimum years of relevant experience required
- `required_education_level` (str): Required education level (e.g., "bachelor")
- `minimum_gpa` (float): Minimum GPA requirement
- `required_certifications` (List[str]): List of required certifications
- `required_positions` (List[str]): List of required job positions

### 8. ScreeningResult (Dataclass)
**Description**: Represents the result of screening an applicant
**Fields**:
- `applicant_id` (str): Unique identifier of applicant
- `applicant_name` (str): Full name of applicant
- `reasons` (List[str]): List of reasons for the screening decision
- `criteria_met` (List[str]): List of screening criteria that were met
- `criteria_not_met` (List[str]): List of screening criteria that were not met

## Core Classes

### ResumeScreeningSystem Class

**Description**: Main class implementing the resume screening functionality

#### Methods:

##### `__init__(self)`
**Description**: Initializes the screening system
**Parameters**: None
**Returns**: None

##### `set_screening_criteria(self, criteria: ScreeningCriteria)`
**Description**: Sets the screening criteria for evaluating applicants
**Parameters**:
- `criteria` (ScreeningCriteria): Screening criteria to be used
**Returns**: None

##### `screen_all_applicants(self) -> List[ScreeningResult]`
**Description**: Evaluates all applicants against the current screening criteria
**Parameters**: None
**Returns**: List[ScreeningResult]: List of screening results for all applicants

##### `generate_report(self) -> str`
**Description**: Generates a formatted text report of all screening results
**Parameters**: None
**Returns**: str: Formatted report string

##### `save_results(self, filename: str)`
**Description**: Saves screening results to a JSON file
**Parameters**:
- `filename` (str): Name of the file to save results to
**Returns**: None

##### `load_results(self, filename: str)`
**Description**: Loads screening results from a JSON file
**Parameters**:
- `filename` (str): Name of the file to load results from
**Returns**: None

## Algorithm Details

### Screening Evaluation Logic

The system evaluates applicants using the following algorithm:

1. **Experience Calculation**: 
   - Calculates total years of relevant experience based on work history
   - Compares against required experience years

2. **Education Evaluation**:
   - Checks if applicant has education matching required level
   - Verifies minimum GPA requirement

3. **Skill Assessment**:
   - Counts how many required skills the applicant possesses
   - Uses partial matching (skills can be matched even if not exactly identical)

4. **Certification Verification**:
   - Checks if applicant holds required certifications
   - Uses partial matching for certification names

5. **Position Matching**:
   - Verifies if applicant has experience in required job positions
   - Uses partial matching for position titles

### Decision Making

The system determines screening decisions based on:
- **ADVANCE**: Applicant meets all required criteria
- **REJECT**: Applicant fails to meet minimum requirements
- **PENDING**: Applicant meets most criteria but has minor deficiencies

## Usage Examples

### Basic Usage

```python
# Create system instance
system = ResumeScreeningSystem()

# Define screening criteria
criteria = ScreeningCriteria(
    required_skills=["python", "java", "sql"],
    required_experience_years=3,
    required_education_level="bachelor",
    minimum_gpa=3.0,
    required_certifications=["aws certified", "oracle certified"],
    required_positions=["software engineer", "developer"]
)

# Set criteria
system.set_screening_criteria(criteria)

# Add applicants
system.applicants = [applicant1, applicant2]

# Screen applicants
results = system.screen_all_applicants()

# Generate report
report = system.generate_report()
print(report)

# Save results
system.save_results("screening_results.json")
```

### Loading Results

```python
# Load previously saved results
system.load_results("screening_results.json")
```

## File Format Specifications

### JSON Output Format

Results are saved in JSON format with the following structure:
```json
[
  {
    "applicant_id": "001",
    "applicant_name": "John Doe",
    "reasons": ["Met experience requirement", "Met skill requirements"],
    "criteria_met": ["Experience requirement", "Skill requirements"],
    "criteria_not_met": []
  }
]
```

### Report Format

The generated report follows a structured text format with:
- Header with system information
- Individual applicant sections
- Detailed reasons for each decision
- Criteria evaluation results
- Footer with summary information

## Error Handling

The system implements basic error handling for:
- File I/O operations (save/load)
- Data validation during loading
- Invalid date formats in work history
- Missing required fields in data models

## Performance Considerations

- **Time Complexity**: O(n × m) where n is number of applicants and m is average number of criteria
- **Space Complexity**: O(n × m) for storing results
- **Memory Usage**: Minimal memory overhead for data models
- **Scalability**: Can handle large numbers of applicants efficiently

## Dependencies

This system requires Python 3.6+ and has no external dependencies beyond standard library modules.

## System Requirements

### Functional Requirements
1. Evaluate applicants against configurable screening criteria
2. Generate detailed screening reports
3. Save and load screening results
4. Support various data models (education, work history, skills, certifications)
5. Provide clear decision-making logic

### Non-Functional Requirements
1. **Reliability**: System should handle edge cases gracefully
2. **Maintainability**: Clean, well-documented code structure
3. **Extensibility**: Easy to add new criteria or evaluation methods
4. **Usability**: Simple API for integration and use

## Security Considerations

- No sensitive data processing beyond applicant information
- File I/O operations follow standard security practices
- No network connectivity required
- Data is handled in memory during processing

## Future Enhancements

Potential improvements include:
- Integration with external databases
- Web interface for easier use
- Advanced matching algorithms for skills and certifications
- Machine learning-based scoring system
- Multi-language support
- Export to various formats (PDF, Excel)