"""
Unit tests for the Resume Screening System.

This module contains comprehensive tests for all components of the resume screening system,
including edge cases, boundary conditions, and standard input scenarios.
"""

import pytest
from datetime import datetime
from unittest.mock import patch
from typing import List

from resume_screening_system import (
    ScreeningDecision,
    Education,
    WorkExperience,
    Skill,
    Certification,
    Applicant,
    ScreeningCriteria,
    ScreeningResult,
    ResumeScreeningSystem
)


class TestEducation:
    """Tests for the Education dataclass."""

    def test_education_creation(self):
        """Test creation of Education object with all fields."""
        education = Education(
            institution="University of Technology",
            degree="Bachelor of Science in Computer Science",
            field="Computer Science",
            start_year=2015,
            end_year=2019,
            gpa=3.7
        )
        assert education.institution == "University of Technology"
        assert education.degree == "Bachelor of Science in Computer Science"
        assert education.field == "Computer Science"
        assert education.start_year == 2015
        assert education.end_year == 2019
        assert education.gpa == 3.7

    def test_education_without_gpa(self):
        """Test creation of Education object without GPA."""
        education = Education(
            institution="State University",
            degree="Master of Science in Information Technology",
            field="Information Technology",
            start_year=2013,
            end_year=2015
        )
        assert education.gpa is None


class TestWorkExperience:
    """Tests for the WorkExperience dataclass."""

    def test_work_experience_creation(self):
        """Test creation of WorkExperience object with all fields."""
        experience = WorkExperience(
            company="Tech Solutions Inc.",
            position="Software Engineer",
            start_date="2019-06-01",
            end_date="2022-05-31",
            description="Developed web applications",
            responsibilities=["Developed web applications", "Collaborated with team"]
        )
        assert experience.company == "Tech Solutions Inc."
        assert experience.position == "Software Engineer"
        assert experience.start_date == "2019-06-01"
        assert experience.end_date == "2022-05-31"
        assert experience.description == "Developed web applications"
        assert experience.responsibilities == ["Developed web applications", "Collaborated with team"]


class TestSkill:
    """Tests for the Skill dataclass."""

    def test_skill_creation(self):
        """Test creation of Skill object."""
        skill = Skill(name="Python", proficiency="advanced")
        assert skill.name == "Python"
        assert skill.proficiency == "advanced"


class TestCertification:
    """Tests for the Certification dataclass."""

    def test_certification_creation(self):
        """Test creation of Certification object with all fields."""
        cert = Certification(
            name="AWS Certified Developer",
            issuing_organization="Amazon Web Services",
            issue_date="2021-03-15"
        )
        assert cert.name == "AWS Certified Developer"
        assert cert.issuing_organization == "Amazon Web Services"
        assert cert.issue_date == "2021-03-15"
        assert cert.expiration_date is None

    def test_certification_with_expiration(self):
        """Test creation of Certification object with expiration date."""
        cert = Certification(
            name="Oracle Certified Professional",
            issuing_organization="Oracle",
            issue_date="2018-01-01",
            expiration_date="2023-01-01"
        )
        assert cert.expiration_date == "2023-01-01"


class TestApplicant:
    """Tests for the Applicant dataclass."""

    def test_applicant_creation(self):
        """Test creation of Applicant object with all fields."""
        applicant = Applicant(
            id="001",
            first_name="John",
            last_name="Doe",
            email="john.doe@email.com",
            phone="123-456-7890",
            address="123 Main St, City, State",
            education=[
                Education(
                    institution="University of Technology",
                    degree="Bachelor of Science in Computer Science",
                    field="Computer Science",
                    start_year=2015,
                    end_year=2019,
                    gpa=3.7
                )
            ],
            work_history=[
                WorkExperience(
                    company="Tech Solutions Inc.",
                    position="Software Engineer",
                    start_date="2019-06-01",
                    end_date="2022-05-31",
                    description="Developed web applications",
                    responsibilities=["Developed web applications"]
                )
            ],
            skills=[
                Skill(name="Python", proficiency="advanced")
            ],
            certifications=[
                Certification(
                    name="AWS Certified Developer",
                    issuing_organization="Amazon Web Services",
                    issue_date="2021-03-15"
                )
            ],
            demographic_info={"age": 28, "gender": "Male"}
        )
        assert applicant.id == "001"
        assert applicant.first_name == "John"
        assert applicant.last_name == "Doe"
        assert applicant.email == "john.doe@email.com"
        assert applicant.phone == "123-456-7890"
        assert applicant.address == "123 Main St, City, State"
        assert len(applicant.education) == 1
        assert len(applicant.work_history) == 1
        assert len(applicant.skills) == 1
        assert len(applicant.certifications) == 1
        assert applicant.demographic_info["age"] == 28


class TestScreeningCriteria:
    """Tests for the ScreeningCriteria dataclass."""

    def test_criteria_creation(self):
        """Test creation of ScreeningCriteria object."""
        criteria = ScreeningCriteria(
            required_skills=["python", "java", "sql"],
            required_experience_years=3,
            required_education_level="bachelor",
            minimum_gpa=3.0,
            required_certifications=["aws certified", "oracle certified"],
            required_positions=["software engineer", "developer"]
        )
        assert criteria.required_skills == ["python", "java", "sql"]
        assert criteria.required_experience_years == 3
        assert criteria.required_education_level == "bachelor"
        assert criteria.minimum_gpa == 3.0
        assert criteria.required_certifications == ["aws certified", "oracle certified"]
        assert criteria.required_positions == ["software engineer", "developer"]


class TestScreeningResult:
    """Tests for the ScreeningResult dataclass."""

    def test_result_creation(self):
        """Test creation of ScreeningResult object."""
        result = ScreeningResult(
            id="001",
            name="John Doe",
            decision=ScreeningDecision.PASS,
            reasons=["Met all requirements"],
            criteria_met=["Education level met", "Experience requirements met"],
            criteria_not_met=[]
        )
        assert result.id == "001"
        assert result.name == "John Doe"
        assert result.decision == ScreeningDecision.PASS
        assert result.reasons == ["Met all requirements"]
        assert result.criteria_met == ["Education level met", "Experience requirements met"]
        assert result.criteria_not_met == []


class TestResumeScreeningSystem:
    """Tests for the ResumeScreeningSystem class."""

    def test_system_initialization(self):
        """Test initialization of ResumeScreeningSystem."""
        system = ResumeScreeningSystem()
        assert system.criteria is None
        assert system.applicants == []
        assert system.results == []

    def test_set_criteria(self):
        """Test setting screening criteria."""
        system = ResumeScreeningSystem()
        criteria = ScreeningCriteria(
            required_skills=["python", "java"],
            required_experience_years=2,
            required_education_level="bachelor",
            minimum_gpa=3.0,
            required_certifications=[],
            required_positions=[]
        )
        system.set_screening_criteria(criteria)
        assert system.criteria == criteria

    def test_calculate_experience_years(self):
        """Test experience calculation with valid dates."""
        system = ResumeScreeningSystem()
        
        # Test with valid date format
        work_history = [
            WorkExperience(
                company="Tech Solutions Inc.",
                position="Software Engineer",
                start_date="2019-06-01",
                end_date="2022-05-31",
                description="Developed web applications",
                responsibilities=[]
            )
        ]
        
        # Mock datetime to avoid dependency on current date
        with patch('datetime.date') as mock_date:
            mock_date.today.return_value = datetime(2023, 1, 1)
            mock_date.side_effect = lambda *args, **kw: datetime(*args, **kw)
            
            experience_years = system._calculate_experience_years(work_history)
            assert experience_years == 2.91  # Approximately 2.91 years

    def test_calculate_experience_years_with_invalid_dates(self):
        """Test experience calculation with invalid date formats."""
        system = ResumeScreeningSystem()
        
        work_history = [
            WorkExperience(
                company="Tech Solutions Inc.",
                position="Software Engineer",
                start_date="invalid-date",
                end_date="2022-05-31",
                description="Developed web applications",
                responsibilities=[]
            )
        ]
        
        experience_years = system._calculate_experience_years(work_history)
        assert experience_years == 0

    def test_calculate_experience_years_with_future_dates(self):
        """Test experience calculation with future dates."""
        system = ResumeScreeningSystem()
        
        work_history = [
            WorkExperience(
                company="Tech Solutions Inc.",
                position="Software Engineer",
                start_date="2025-06-01",
                end_date="2027-05-31",
                description="Developed web applications",
                responsibilities=[]
            )
        ]
        
        experience_years = system._calculate_experience_years(work_history)
        assert experience_years == 0  # Should return 0 for future dates

    def test_check_education_level(self):
        """Test education level checking."""
        system = ResumeScreeningSystem()
        
        # Bachelor's degree
        education = Education(
            institution="University of Technology",
            degree="Bachelor of Science in Computer Science",
            field="Computer Science",
            start_year=2015,
            end_year=2019,
            gpa=3.7
        )
        
        assert system._check_education_level([education], "bachelor") is True
        assert system._check_education_level([education], "master") is False

    def test_check_education_level_with_no_education(self):
        """Test education level checking with no education."""
        system = ResumeScreeningSystem()
        assert system._check_education_level([], "bachelor") is False

    def test_check_education_level_with_masters(self):
        """Test education level checking with master's degree."""
        system = ResumeScreeningSystem()
        
        education = Education(
            institution="State University",
            degree="Master of Science in Information Technology",
            field="Information Technology",
            start_year=2013,
            end_year=2015,
            gpa=3.9
        )
        
        assert system._check_education_level([education], "master") is True
        assert system._check_education_level([education], "bachelor") is True  # Master includes bachelor

    def test_check_gpa(self):
        """Test GPA checking."""
        system = ResumeScreeningSystem()
        
        education = Education(
            institution="University of Technology",
            degree="Bachelor of Science in Computer Science",
            field="Computer Science",
            start_year=2015,
            end_year=2019,
            gpa=3.7
        )
        
        assert system._check_gpa([education], 3.0) is True
        assert system._check_gpa([education], 4.0) is False

    def test_check_gpa_with_no_education(self):
        """Test GPA checking with no education."""
        system = ResumeScreeningSystem()
        assert system._check_gpa([], 3.0) is False

    def test_check_skills(self):
        """Test skill checking."""
        system = ResumeScreeningSystem()
        
        skills = [
            Skill(name="Python", proficiency="advanced"),
            Skill(name="Java", proficiency="intermediate"),
            Skill(name="SQL", proficiency="advanced")
        ]
        
        required_skills = ["python", "java"]
        assert system._check_skills(skills, required_skills) is True
        
        required_skills = ["python", "javascript"]
        assert system._check_skills(skills, required_skills) is False

    def test_check_certifications(self):
        """Test certification checking."""
        system = ResumeScreeningSystem()
        
        certifications = [
            Certification(
                name="AWS Certified Developer",
                issuing_organization="Amazon Web Services",
                issue_date="2021-03-15"
            ),
            Certification(
                name="Oracle Certified Professional",
                issuing_organization="Oracle",
                issue_date="2018-01-01"
            )
        ]
        
        required_certifications = ["aws certified", "oracle certified"]
        assert system._check_certifications(certifications, required_certifications) is True
        
        required_certifications = ["aws certified", "azure certified"]
        assert system._check_certifications(certifications, required_certifications) is False

    def test_check_positions(self):
        """Test position checking."""
        system = ResumeScreeningSystem()
        
        work_history = [
            WorkExperience(
                company="Tech Solutions Inc.",
                position="Software Engineer",
                start_date="2019-06-01",
                end_date="2022-05-31",
                description="Developed web applications",
                responsibilities=[]
            ),
            WorkExperience(
                company="Web Services Ltd.",
                position="Senior Developer",
                start_date="2022-06-01",
                end_date="2023-05-31",
                description="Developed web applications",
                responsibilities=[]
            )
        ]
        
        required_positions = ["software engineer", "developer"]
        assert system._check_positions(work_history, required_positions) is True
        
        required_positions = ["software engineer", "manager"]
        assert system._check_positions(work_history, required_positions) is False

    def test_screen_applicant_pass(self):
        """Test screening an applicant who passes all criteria."""
        system = ResumeScreeningSystem()
        
        # Set criteria
        criteria = ScreeningCriteria(
            required_skills=["python", "java"],
            required_experience_years=2,
            required_education_level="bachelor",
            minimum_gpa=3.0,
            required_certifications=[],
            required_positions=["software engineer"]
        )
        system.set_screening_criteria(criteria)
        
        # Create applicant
        applicant = Applicant(
            id="001",
            first_name="John",
            last_name="Doe",
            email="john.doe@email.com",
            phone="123-456-7890",
            address="123 Main St",
            education=[
                Education(
                    institution="University of Technology",
                    degree="Bachelor of Science in Computer Science",
                    field="Computer Science",
                    start_year=2015,
                    end_year=2019,
                    gpa=3.7
                )
            ],
            work_history=[
                WorkExperience(
                    company="Tech Solutions Inc.",
                    position="Software Engineer",
                    start_date="2019-06-01",
                    end_date="2022-05-31",
                    description="Developed web applications",
                    responsibilities=[]
                )
            ],
            skills=[
                Skill(name="Python", proficiency="advanced"),
                Skill(name="Java", proficiency="intermediate")
            ],
            certifications=[],
            demographic_info={}
        )
        
        result = system._screen_applicant(applicant)
        assert result.decision == ScreeningDecision.PASS

    def test_screen_applicant_fail(self):
        """Test screening an applicant who fails one or more criteria."""
        system = ResumeScreeningSystem()
        
        # Set criteria
        criteria = ScreeningCriteria(
            required_skills=["python", "java"],
            required_experience_years=2,
            required_education_level="bachelor",
            minimum_gpa=3.0,
            required_certifications=[],
            required_positions=["software engineer"]
        )
        system.set_screening_criteria(criteria)
        
        # Create applicant with failing criteria
        applicant = Applicant(
            id="002",
            first_name="Jane",
            last_name="Smith",
            email="jane.smith@email.com",
            phone="123-456-7890",
            address="123 Main St",
            education=[
                Education(
                    institution="University of Technology",
                    degree="Bachelor of Science in Computer Science",
                    field="Computer Science",
                    start_year=2015,
                    end_year=2019,
                    gpa=2.5  # Below minimum
                )
            ],
            work_history=[
                WorkExperience(
                    company="Tech Solutions Inc.",
                    position="Junior Developer",
                    start_date="2019-06-01",
                    end_date="2022-05-31",
                    description="Developed web applications",
                    responsibilities=[]
                )
            ],
            skills=[
                Skill(name="Python", proficiency="advanced")
                # Missing Java skill
            ],
            certifications=[],
            demographic_info={}
        )
        
        result = system._screen_applicant(applicant)
        assert result.decision == ScreeningDecision.FAIL

    def test_screen_applicants(self):
        """Test screening multiple applicants."""
        system = ResumeScreeningSystem()
        
        # Set criteria
        criteria = ScreeningCriteria(
            required_skills=["python", "java"],
            required_experience_years=2,
            required_education_level="bachelor",
            minimum_gpa=3.0,
            required_certifications=[],
            required_positions=["software engineer"]
        )
        system.set_screening_criteria(criteria)
        
        # Create applicants
        applicant1 = Applicant(
            id="001",
            first_name="John",
            last_name="Doe",
            email="john.doe@email.com",
            phone="123-456-7890",
            address="123 Main St",
            education=[
                Education(
                    institution="University of Technology",
                    degree="Bachelor of Science in Computer Science",
                    field="Computer Science",
                    start_year=2015,
                    end_year=2019,
                    gpa=3.7
                )
            ],
            work_history=[
                WorkExperience(
                    company="Tech Solutions Inc.",
                    position="Software Engineer",
                    start_date="2019-06-01",
                    end_date="2022-05-31",
                    description="Developed web applications",
                    responsibilities=[]
                )
            ],
            skills=[
                Skill(name="Python", proficiency="advanced"),
                Skill(name="Java", proficiency="intermediate")
            ],
            certifications=[],
            demographic_info={}
        )
        
        applicant2 = Applicant(
            id="002",
            first_name="Jane",
            last_name="Smith",
            email="jane.smith@email.com",
            phone="123-456-7890",
            address="123 Main St",
            education=[
                Education(
                    institution="University of Technology",
                    degree="Bachelor of Science in Computer Science",
                    field="Computer Science",
                    start_year=2015,
                    end_year=2019,
                    gpa=2.5
                )
            ],
            work_history=[
                WorkExperience(
                    company="Tech Solutions Inc.",
                    position="Junior Developer",
                    start_date="2019-06-01",
                    end_date="2022-05-31",
                    description="Developed web applications",
                    responsibilities=[]
                )
            ],
            skills=[
                Skill(name="Python", proficiency="advanced")
            ],
            certifications=[],
            demographic_info={}
        )
        
        system.applicants = [applicant1, applicant2]
        system.screen_applicants()
        
        assert len(system.results) == 2
        assert system.results[0].decision == ScreeningDecision.PASS
        assert system.results[1].decision == ScreeningDecision.FAIL

    def test_generate_report(self):
        """Test report generation."""
        system = ResumeScreeningSystem()
        
        # Set criteria
        criteria = ScreeningCriteria(
            required_skills=["python", "java"],
            required_experience_years=2,
            required_education_level="bachelor",
            minimum_gpa=3.0,
            required_certifications=[],
            required_positions=["software engineer"]
        )
        system.set_screening_criteria(criteria)
        
        # Create applicant
        applicant = Applicant(
            id="001",
            first_name="John",
            last_name="Doe",
            email="john.doe@email.com",
            phone="123-456-7890",
            address="123 Main St",
            education=[
                Education(
                    institution="University of Technology",
                    degree="Bachelor of Science in Computer Science",
                    field="Computer Science",
                    start_year=2015,
                    end_year=2019,
                    gpa=3.7
                )
            ],
            work_history=[
                WorkExperience(
                    company="Tech Solutions Inc.",
                    position="Software Engineer",
                    start_date="2019-06-01",
                    end_date="2022-05-31",
                    description="Developed web applications",
                    responsibilities=[]
                )
            ],
            skills=[
                Skill(name="Python", proficiency="advanced"),
                Skill(name="Java", proficiency="intermediate")
            ],
            certifications=[],
            demographic_info={}
        )
        
        system.applicants = [applicant]
        system.screen_applicants()
        
        report = system.generate_report()
        assert "Screening Report" in report
        assert "Pass" in report
        assert "John Doe" in report

    def test_save_results(self, tmp_path):
        """Test saving results to file."""
        system = ResumeScreeningSystem()
        
        # Set criteria
        criteria = ScreeningCriteria(
            required_skills=["python", "java"],
            required_experience_years=2,
            required_education_level="bachelor",
            minimum_gpa=3.0,
            required_certifications=[],
            required_positions=["software engineer"]
        )
        system.set_screening_criteria(criteria)
        
        # Create applicant
        applicant = Applicant(
            id="001",
            first_name="John",
            last_name="Doe",
            email="john.doe@email.com",
            phone="123-456-7890",
            address="123 Main St",
            education=[
                Education(
                    institution="University of Technology",
                    degree="Bachelor of Science in Computer Science",
                    field="Computer Science",
                    start_year=2015,
                    end_year=2019,
                    gpa=3.7
                )
            ],
            work_history=[
                WorkExperience(
                    company="Tech Solutions Inc.",
                    position="Software Engineer",
                    start_date="2019-06-01",
                    end_date="2022-05-31",
                    description="Developed web applications",
                    responsibilities=[]
                )
            ],
            skills=[
                Skill(name="Python", proficiency="advanced"),
                Skill(name="Java", proficiency="intermediate")
            ],
            certifications=[],
            demographic_info={}
        )
        
        system.applicants = [applicant]
        system.screen_applicants()
        
        # Save results
        file_path = tmp_path / "results.txt"
        system.save_results(file_path)
        
        assert file_path.exists()
        content = file_path.read_text()
        assert "John Doe" in content
        assert "Pass" in content

    def test_load_results(self, tmp_path):
        """Test loading results from file."""
        system = ResumeScreeningSystem()
        
        # Create a sample results file
        file_path = tmp_path / "results.txt"
        file_path.write_text("John Doe: Pass\nJane Smith: Fail\n")
        
        # Load results
        results = system.load_results(file_path)
        
        assert len(results) == 2
        assert results[0].name == "John Doe"
        assert results[0].decision == "Pass"
        assert results[1].name == "Jane Smith"
        assert results[1].decision == "Fail"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])