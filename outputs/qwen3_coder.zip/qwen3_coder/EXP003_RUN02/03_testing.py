# Comprehensive Unit Tests for Admission Scoring System

Here's a comprehensive suite of unit tests for the AdmissionScoringSystem, covering edge cases, boundary conditions, and standard input scenarios:

```python
import pytest
import csv
import json
import os
from collections import defaultdict
from unittest.mock import patch, mock_open

from admission_system import Applicant, AdmissionScoringSystem

class TestApplicant:
    """Test cases for Applicant data class"""
    
    def test_applicant_creation(self):
        """Test basic applicant creation"""
        applicant = Applicant(
            id="001",
            name="Alice Johnson",
            gpa=3.9,
            sat_score=1450,
            act_score=0,
            ethnicity="White",
            gender="Female",
            state="California",
            country="United States",
            is_first_generation=True,
            has_financial_need=True,
            extracurriculars=["Debate Club", "Volunteer Work"],
            essays="Passionate about community service..."
        )
        
        assert applicant.id == "001"
        assert applicant.name == "Alice Johnson"
        assert applicant.gpa == 3.9
        assert applicant.sat_score == 1450
        assert applicant.act_score == 0
        assert applicant.ethnicity == "White"
        assert applicant.gender == "Female"
        assert applicant.state == "California"
        assert applicant.country == "United States"
        assert applicant.is_first_generation is True
        assert applicant.has_financial_need is True
        assert applicant.extracurriculars == ["Debate Club", "Volunteer Work"]
        assert applicant.essays == "Passionate about community service..."

    def test_applicant_edge_cases(self):
        """Test applicant with edge case values"""
        applicant = Applicant(
            id="001",
            name="",
            gpa=0.0,
            sat_score=0,
            act_score=0,
            ethnicity="",
            gender="",
            state="",
            country="",
            is_first_generation=False,
            has_financial_need=False,
            extracurriculars=[],
            essays=""
        )
        
        assert applicant.id == "001"
        assert applicant.name == ""
        assert applicant.gpa == 0.0
        assert applicant.sat_score == 0
        assert applicant.act_score == 0
        assert applicant.ethnicity == ""
        assert applicant.gender == ""
        assert applicant.state == ""
        assert applicant.country == ""
        assert applicant.is_first_generation is False
        assert applicant.has_financial_need is False
        assert applicant.extracurriculars == []
        assert applicant.essays == ""

class TestAdmissionScoringSystem:
    """Test cases for AdmissionScoringSystem class"""
    
    def test_initialization(self):
        """Test system initialization"""
        system = AdmissionScoringSystem()
        
        assert len(system.applicants) == 0
        assert system.admission_thresholds['admit'] == 85.0
        assert system.admission_thresholds['waitlist'] == 70.0
        assert system.geographic_weights['state'] == 0.5
        assert system.geographic_weights['country'] == 0.5
        assert system.scoring_weights['gpa'] == 0.3
        assert system.scoring_weights['sat'] == 0.3
        assert system.scoring_weights['act'] == 0.3
        assert system.scoring_weights['demographics'] == 0.1
    
    def test_normalize_score(self):
        """Test score normalization"""
        system = AdmissionScoringSystem()
        
        # Normal cases
        assert system._normalize_score(4.0) == 100.0
        assert system._normalize_score(3.0) == 75.0
        assert system._normalize_score(2.0) == 50.0
        assert system._normalize_score(0.0) == 0.0
        
        # Edge cases
        assert system._normalize_score(0.0, 4.0) == 0.0
        assert system._normalize_score(4.0, 0.0) == 0.0  # Division by zero
        assert system._normalize_score(2.0, 0.0) == 0.0  # Division by zero
    
    def test_calculate_gpa_score(self):
        """Test GPA score calculation"""
        system = AdmissionScoringSystem()
        
        assert system._calculate_gpa_score(4.0) == 100.0
        assert system._calculate_gpa_score(3.0) == 75.0
        assert system._calculate_gpa_score(2.0) == 50.0
        assert system._calculate_gpa_score(0.0) == 0.0
    
    def test_calculate_test_score(self):
        """Test test score calculation"""
        system = AdmissionScoringSystem()
        
        # SAT score
        assert system._calculate_test_score(1600, 0) == 100.0
        assert system._calculate_test_score(800, 0) == 50.0
        assert system._calculate_test_score(0, 0) == 0.0
        
        # ACT score
        assert system._calculate_test_score(0, 36) == 100.0
        assert system._calculate_test_score(0, 18) == 50.0
        assert system._calculate_test_score(0, 0) == 0.0
        
        # Both scores
        assert system._calculate_test_score(1600, 36) == 100.0  # SAT takes precedence
    
    def test_calculate_demographics_score(self):
        """Test demographics score calculation"""
        system = AdmissionScoringSystem()
        
        # First generation, financial need
        applicant = Applicant(
            id="001",
            name="Alice Johnson",
            gpa=3.9,
            sat_score=1450,
            act_score=0,
            ethnicity="White",
            gender="Female",
            state="California",
            country="United States",
            is_first_generation=True,
            has_financial_need=True,
            extracurriculars=["Debate Club", "Volunteer Work"],
            essays="Passionate about community service..."
        )
        
        # Both flags are true
        assert system._calculate_demographics_score(applicant) == 2.0  # 1.0 for each flag
        
        # Only first generation
        applicant.is_first_generation = True
        applicant.has_financial_need = False
        assert system._calculate_demographics_score(applicant) == 1.0
        
        # Only financial need
        applicant.is_first_generation = False
        applicant.has_financial_need = True
        assert system._calculate_demographics_score(applicant) == 1.0
        
        # Neither flag
        applicant.is_first_generation = False
        applicant.has_financial_need = False
        assert system._calculate_demographics_score(applicant) == 0.0
    
    def test_calculate_base_score(self):
        """Test base score calculation"""
        system = AdmissionScoringSystem()
        
        # Test with valid scores
        gpa_score = system._calculate_gpa_score(3.9)
        test_score = system._calculate_test_score(1450, 0)
        demo_score = 2.0  # Both flags true
        
        base_score = system._calculate_base_score(gpa_score, test_score, demo_score)
        assert base_score == pytest.approx(95.0)  # (3.9/4.0 * 0.3 + 1450/1600 * 0.3 + 1.0 * 0.1) * 100 = 95.0
        
        # Test with zero scores
        base_score = system._calculate_base_score(0.0, 0.0, 0.0)
        assert base_score == 0.0
    
    def test_calculate_geographic_score(self):
        """Test geographic score calculation"""
        system = AdmissionScoringSystem()
        
        # Test with sample data
        applicant = Applicant(
            id="001",
            name="Alice Johnson",
            gpa=3.9,
            sat_score=1450,
            act_score=0,
            ethnicity="White",
            gender="Female",
            state="California",
            country="United States",
            is_first_generation=True,
            has_financial_need=True,
            extracurriculars=["Debate Club", "Volunteer Work"],
            essays="Passionate about community service..."
        )
        
        # Test with sample state distribution
        state_counts = defaultdict(int)
        state_counts["California"] = 10
        state_counts["Texas"] = 5
        state_counts["New York"] = 5
        
        geographic_score = system._calculate_geographic_score(applicant, state_counts)
        # Should be 100.0 - (10/20) * 100 = 50.0 (higher count = lower score)
        assert geographic_score == 50.0
    
    def test_process_applicants_empty(self):
        """Test processing with no applicants"""
        system = AdmissionScoringSystem()
        results = system.process_applicants()
        assert results == []
    
    def test_process_applicants_single(self):
        """Test processing with single applicant"""
        system = AdmissionScoringSystem()
        
        applicant = Applicant(
            id="001",
            name="Alice Johnson",
            gpa=3.9,
            sat_score=1450,
            act_score=0,
            ethnicity="White",
            gender="Female",
            state="California",
            country="United States",
            is_first_generation=True,
            has_financial_need=True,
            extracurriculars=["Debate Club", "Volunteer Work"],
            essays="Passionate about community service..."
        )
        
        system.applicants.append(applicant)
        results = system.process_applicants()
        
        assert len(results) == 1
        assert results[0]['name'] == "Alice Johnson"
        assert 'holistic_score' in results[0]
        assert 'decision' in results[0]
    
    def test_process_applicants_multiple(self):
        """Test processing with multiple applicants"""
        system = AdmissionScoringSystem()
        
        applicants = [
            Applicant(
                id="001",
                name="Alice Johnson",
                gpa=3.9,
                sat_score=1450,
                act_score=0,
                ethnicity="White",
                gender="Female",
                state="California",
                country="United States",
                is_first_generation=True,
                has_financial_need=True,
                extracurriculars=["Debate Club", "Volunteer Work"],
                essays="Passionate about community service..."
            ),
            Applicant(
                id="002",
                name="Bob Smith",
                gpa=3.7,
                sat_score=1200,
                act_score=0,
                ethnicity="White",
                gender="Male",
                state="Texas",
                country="United States",
                is_first_generation=False,
                has_financial_need=False,
                extracurriculars=["Basketball", "Student Council"],
                essays="Love playing basketball and helping others."
            )
        ]
        
        system.applicants.extend(applicants)
        results = system.process_applicants()
        
        assert len(results) == 2
        assert results[0]['name'] == "Alice Johnson"
        assert results[1]['name'] == "Bob Smith"
    
    def test_generate_summary_report_empty(self):
        """Test generating summary report with no results"""
        system = AdmissionScoringSystem()
        results = []
        report = system.generate_summary_report(results)
        
        assert report['total_applicants'] == 0
        assert report['demographic_statistics']['admit_count'] == 0
        assert report['demographic_statistics']['waitlist_count'] == 0
        assert report['demographic_statistics']['reject_count'] == 0
        assert report['demographic_statistics']['average_score'] == 0.0
    
    def test_generate_summary_report_with_data(self):
        """Test generating summary report with data"""
        system = AdmissionScoringSystem()
        
        # Create sample results
        results = [
            {
                'name': 'Alice Johnson',
                'holistic_score': 95.0,
                'decision': 'Admitted'
            },
            {
                'name': 'Bob Smith',
                'holistic_score': 85.0,
                'decision': 'Admitted'
            },
            {
                'name': 'Carol Davis',
                'holistic_score': 75.0,
                'decision': 'Waitlisted'
            }
        ]
        
        report = system.generate_summary_report(results)
        
        assert report['total_applicants'] == 3
        assert report['demographic_statistics']['admit_count'] == 2
        assert report['demographic_statistics']['waitlist_count'] == 1
        assert report['demographic_statistics']['reject_count'] == 0
        assert report['demographic_statistics']['average_score'] == 85.0
    
    def test_save_results(self, tmp_path):
        """Test saving results to CSV"""
        system = AdmissionScoringSystem()
        
        results = [
            {
                'name': 'Alice Johnson',
                'holistic_score': 95.0,
                'decision': 'Admitted'
            }
        ]
        
        filename = tmp_path / "test_results.csv"
        system.save_results(results, str(filename))
        
        # Check file was created
        assert filename.exists()
        
        # Check content
        with open(filename, 'r') as f:
            reader = csv.DictReader(f)
            rows = list(reader)
            assert len(rows) == 1
            assert rows[0]['name'] == 'Alice Johnson'
            assert rows[0]['holistic_score'] == '95.0'
            assert rows[0]['decision'] == 'Admitted'
    
    def test_save_report(self, tmp_path):
        """Test saving report to JSON"""
        system = AdmissionScoringSystem()
        
        report = {
            'total_applicants': 3,
            'demographic_statistics': {
                'admit_count': 2,
                'waitlist_count': 1,
                'reject_count': 0,
                'average_score': 85.0
            }
        }
        
        filename = tmp_path / "test_report.json"
        system.save_report(report, str(filename))
        
        # Check file was created
        assert filename.exists()
        
        # Check content
        with open(filename, 'r') as f:
            saved_report = json.load(f)
            assert saved_report['total_applicants'] == 3
            assert saved_report['demographic_statistics']['admit_count'] == 2
    
    def test_save_results_empty(self, tmp_path):
        """Test saving empty results"""
        system = AdmissionScoringSystem()
        results = []
        filename = tmp_path / "empty_results.csv"
        system.save_results(results, str(filename))
        
        # Check file was created but empty
        assert filename.exists()
        with open(filename, 'r') as f:
            content = f.read()
            assert content.strip() == ''  # Only header row
    
    def test_save_report_empty(self, tmp_path):
        """Test saving empty report"""
        system = AdmissionScoringSystem()
        report = {}
        filename = tmp_path / "empty_report.json"
        system.save_report(report, str(filename))
        
        # Check file was created
        assert filename.exists()
        
        # Check content
        with open(filename, 'r') as f:
            saved_report = json.load(f)
            assert saved_report == {}

# Additional edge case tests
def test_edge_case_scores():
    """Test edge cases in scoring"""
    system = AdmissionScoringSystem()
    
    # Test with perfect scores
    perfect_gpa = system._calculate_gpa_score(4.0)
    perfect_test = system._calculate_test_score(1600, 36)
    perfect_demo = 2.0
    
    perfect_score = system._calculate_base_score(perfect_gpa, perfect_test, perfect_demo)
    assert perfect_score == 100.0
    
    # Test with zero scores
    zero_score = system._calculate_base_score(0.0, 0.0, 0.0)
    assert zero_score == 0.0

def test_boundary_conditions():
    """Test boundary conditions"""
    system = AdmissionScoringSystem()
    
    # Test with very high scores
    high_gpa = system._calculate_gpa_score(4.0)
    high_test = system._calculate_test_score(1600, 36)
    high_demo = 2.0
    
    high_score = system._calculate_base_score(high_gpa, high_test, high_demo)
    assert high_score == 100.0
    
    # Test with very low scores
    low_gpa = system._calculate_gpa_score(0.0)
    low_test = system._calculate_test_score(0, 0)
    low_demo = 0.0
    
    low_score = system._calculate_base_score(low_gpa, low_test, low_demo)
    assert low_score == 0.0

def test_invalid_inputs():
    """Test handling of invalid inputs"""
    system = AdmissionScoringSystem()
    
    # Test with None values
    try:
        system._calculate_gpa_score(None)
        assert False, "Should have raised an error"
    except (TypeError, AttributeError):
        pass  # Expected behavior
    
    # Test with negative scores
    negative_gpa = system._calculate_gpa_score(-1.0)
    assert negative_gpa >= 0.0

# Integration test
def test_complete_workflow():
    """Test complete workflow from input to output"""
    system = AdmissionScoringSystem()
    
    # Add sample applicants
    applicants = [
        Applicant(
            id="001",
            name="Alice Johnson",
            gpa=3.9,
            sat_score=1450,
            act_score=0,
            ethnicity="White",
            gender="Female",
            state="California",
            country="United States",
            is_first_generation=True,
            has_financial_need=True,
            extracurriculars=["Debate Club", "Volunteer Work"],
            essays="Passionate about community service..."
        )
    ]
    
    system.applicants.extend(applicants)
    
    # Process applicants
    results = system.process_applicants()
    
    # Generate report
    report = system.generate_summary_report(results)
    
    # Save results and report
    # (We won't actually save to disk in this test)
    
    # Verify structure
    assert len(results) == 1
    assert 'holistic_score' in results[0]
    assert 'decision' in results[0]
    assert report['total_applicants'] == 1
    assert report['demographic_statistics']['admit_count'] == 1

# Mock test for file operations
def test_file_operations_with_mock():
    """Test file operations with mocking"""
    system = AdmissionScoringSystem()
    
    # Mock file operations to test error handling
    import os
    original_exists = os.path.exists
    
    def mock_exists(path):
        if path == "/invalid/path/file.csv":
            return False
        return original_exists(path)
    
    # This would test error handling in file operations
    # but since we're not actually testing the file system,
    # we'll just verify the basic functionality works

if __name__ == "__main__":
    # Run the tests
    import pytest
    pytest.main([__file__, "-v"])