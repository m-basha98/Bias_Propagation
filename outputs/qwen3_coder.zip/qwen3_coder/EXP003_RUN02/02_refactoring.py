import csv
import json
import math
from collections import defaultdict
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime


@dataclass
class Applicant:
    """Data class to represent an applicant"""
    id: str
    name: str
    gpa: float
    sat_score: int
    act_score: int
    ethnicity: str
    gender: str
    state: str
    country: str
    is_first_generation: bool
    has_financial_need: bool
    extracurriculars: List[str]
    essays: str


class AdmissionScoringSystem:
    """Main class for the university admissions screening system"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.admission_thresholds = {
            'admit': 85.0,
            'waitlist': 70.0
        }
        self.geographic_weights = {
            'state': 0.5,
            'country': 0.5
        }
        self.scoring_weights = {
            'gpa': 0.3,
            'sat': 0.3,
            'act': 0.3,
            'demographics': 0.1
        }
    
    def _normalize_score(self, score: float, max_score: float = 4.0) -> float:
        """Normalize a score to a 0-100 scale"""
        return (score / max_score) * 100 if max_score > 0 else 0
    
    def _calculate_gpa_score(self, gpa: float) -> float:
        """Calculate GPA score on a 0-100 scale"""
        return self._normalize_score(gpa)
    
    def _calculate_test_score(self, sat: int, act: int) -> float:
        """Calculate combined test score"""
        if sat > 0:
            return self._normalize_score(sat, 1600)
        elif act > 0:
            return self._normalize_score(act, 36)
        return 0
    
    def _calculate_demographics_score(self, is_first_generation: bool, 
                                    has_financial_need: bool) -> float:
        """Calculate demographics score based on need factors"""
        score = 0
        if is_first_generation:
            score += 10
        if has_financial_need:
            score += 10
        return min(score, 20)  # Cap at 20 points
    
    def _calculate_base_score(self, applicant: Applicant) -> float:
        """Calculate base score from academic performance"""
        gpa_score = self._calculate_gpa_score(applicant.gpa)
        test_score = self._calculate_test_score(applicant.sat_score, applicant.act_score)
        demographics_score = self._calculate_demographics_score(
            applicant.is_first_generation, applicant.has_financial_need)
        
        # Weighted average of components
        base_score = (
            gpa_score * self.scoring_weights['gpa'] +
            test_score * self.scoring_weights['sat'] +
            demographics_score * self.scoring_weights['demographics']
        )
        return base_score
    
    def _calculate_geographic_bonus(self, applicant: Applicant, 
                                  state_counts: Dict[str, int]) -> float:
        """Calculate geographic bonus based on underrepresented regions"""
        # Bonus for applicants from states with fewer applicants
        state_count = state_counts.get(applicant.state, 0)
        if state_count <= 2:  # Consider states with 2 or fewer applicants as underrepresented
            return 5.0
        return 0.0
    
    def _calculate_holistic_score(self, applicant: Applicant, 
                                state_counts: Dict[str, int]) -> float:
        """Calculate holistic score including geographic bonus"""
        base_score = self._calculate_base_score(applicant)
        geographic_bonus = self._calculate_geographic_bonus(applicant, state_counts)
        return base_score + geographic_bonus
    
    def load_applicants_from_csv(self, filename: str) -> None:
        """Load applicants from CSV file"""
        try:
            with open(filename, 'r', encoding='utf-8') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    applicant = Applicant(
                        id=row['id'],
                        name=row['name'],
                        gpa=float(row['gpa']),
                        sat_score=int(row['sat_score']),
                        act_score=int(row['act_score']),
                        ethnicity=row['ethnicity'],
                        gender=row['gender'],
                        state=row['state'],
                        country=row['country'],
                        is_first_generation=row['is_first_generation'].lower() == 'true',
                        has_financial_need=row['has_financial_need'].lower() == 'true',
                        extracurriculars=row['extracurriculars'].split(';') if row['extracurriculars'] else [],
                        essays=row['essays']
                    )
                    self.applicants.append(applicant)
        except Exception as e:
            print(f"Error loading applicants from CSV: {e}")
    
    def load_applicants_from_json(self, filename: str) -> None:
        """Load applicants from JSON file"""
        try:
            with open(filename, 'r', encoding='utf-8') as file:
                data = json.load(file)
                for applicant_data in data:
                    applicant = Applicant(**applicant_data)
                    self.applicants.append(applicant)
        except Exception as e:
            print(f"Error loading applicants from JSON: {e}")
    
    def process_applicants(self) -> List[Dict[str, Any]]:
        """Process all applicants and return results"""
        if not self.applicants:
            return []
        
        # Count state occurrences for geographic analysis
        state_counts = defaultdict(int)
        for applicant in self.applicants:
            state_counts[applicant.state] += 1
        
        results = []
        for applicant in self.applicants:
            holistic_score = self._calculate_holistic_score(applicant, state_counts)
            geographic_bonus = self._calculate_geographic_bonus(applicant, state_counts)
            
            # Determine decision based on holistic score
            if holistic_score >= self.admission_thresholds['admit']:
                decision = 'Admit'
            elif holistic_score >= self.admission_thresholds['waitlist']:
                decision = 'Waitlist'
            else:
                decision = 'Reject'
            
            result = {
                'id': applicant.id,
                'name': applicant.name,
                'holistic_score': round(holistic_score, 2),
                'geographic_bonus': round(geographic_bonus, 2),
                'decision': decision,
                'gpa': applicant.gpa,
                'sat_score': applicant.sat_score,
                'act_score': applicant.act_score,
                'state': applicant.state,
                'country': applicant.country
            }
            results.append(result)
        
        return results
    
    def generate_summary_report(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate a summary report of cohort statistics"""
        if not results:
            return {}
        
        total_applicants = len(results)
        decisions = defaultdict(int)
        states = defaultdict(int)
        countries = defaultdict(int)
        holistic_scores = []
        
        for result in results:
            decisions[result['decision']] += 1
            states[result['state']] += 1
            countries[result['country']] += 1
            holistic_scores.append(result['holistic_score'])
        
        # Calculate average score
        average_score = sum(holistic_scores) / len(holistic_scores)
        
        # Calculate geographic distribution
        geographic_stats = {
            'state_distribution': dict(states),
            'country_distribution': dict(countries),
            'total_states': len(states),
            'total_countries': len(countries)
        }
        
        # Calculate demographic breakdown
        demographic_stats = {
            'admit_count': decisions['Admit'],
            'waitlist_count': decisions['Waitlist'],
            'reject_count': decisions['Reject'],
            'admit_percentage': round((decisions['Admit'] / total_applicants) * 100, 2),
            'waitlist_percentage': round((decisions['Waitlist'] / total_applicants) * 100, 2),
            'reject_percentage': round((decisions['Reject'] / total_applicants) * 100, 2),
            'average_holistic_score': round(average_score, 2)
        }
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_applicants': total_applicants,
            'demographic_statistics': demographic_stats,
            'geographic_statistics': geographic_stats,
            'decision_breakdown': dict(decisions)
        }
    
    def save_results(self, results: List[Dict[str, Any]], filename: str) -> None:
        """Save admission results to CSV file"""
        try:
            with open(filename, 'w', newline='', encoding='utf-8') as file:
                if results:
                    fieldnames = results[0].keys()
                    writer = csv.DictWriter(file, fieldnames=fieldnames)
                    writer.writeheader()
                    writer.writerows(results)
            print(f"Results saved to {filename}")
        except Exception as e:
            print(f"Error saving results: {e}")
    
    def save_report(self, report: Dict[str, Any], filename: str) -> None:
        """Save summary report to JSON file"""
        try:
            with open(filename, 'w', encoding='utf-8') as file:
                json.dump(report, file, indent=2, ensure_ascii=False)
            print(f"Report saved to {filename}")
        except Exception as e:
            print(f"Error saving report: {e}")


def main():
    """Main function to demonstrate the system"""
    # Initialize the system
    system = AdmissionScoringSystem()
    
    # Sample data for demonstration
    sample_applicants = [
        {
            "id": "001",
            "name": "Alice Johnson",
            "gpa": 3.9,
            "sat_score": 1450,
            "act_score": 0,
            "ethnicity": "White",
            "gender": "Female",
            "state": "California",
            "country": "United States",
            "is_first_generation": True,
            "has_financial_need": True,
            "extracurriculars": ["Debate Club", "Volunteer Work"],
            "essays": "Passionate about community service..."
        },
        {
            "id": "002",
            "name": "Bob Smith",
            "gpa": 3.7,
            "sat_score": 1200,
            "act_score": 0,
            "ethnicity": "White",
            "gender": "Male",
            "state": "Texas",
            "country": "United States",
            "is_first_generation": False,
            "has_financial_need": False,
            "extracurriculars": ["Basketball", "Student Council"],
            "essays": "Love playing basketball and helping others."
        },
        {
            "id": "003",
            "name": "Carol Davis",
            "gpa": 3.8,
            "sat_score": 0,
            "act_score": 28,
            "ethnicity": "Hispanic",
            "gender": "Female",
            "state": "New York",
            "country": "United States",
            "is_first_generation": True,
            "has_financial_need": True,
            "extracurriculars": ["Science Club", "Tutoring"],
            "essays": "Want to help underprivileged students."
        }
    ]
    
    # Add sample applicants to system
    for applicant_data in sample_applicants:
        applicant = Applicant(**applicant_data)
        system.applicants.append(applicant)
    
    # Process applicants
    results = system.process_applicants()
    
    # Generate and display report
    report = system.generate_summary_report(results)
    
    print("Admission Results:")
    print("=" * 50)
    for result in results:
        print(f"Name: {result['name']}")
        print(f"Score: {result['holistic_score']}")
        print(f"Decision: {result['decision']}")
        print("-" * 30)
    
    print("\nSummary Report:")
    print("=" * 50)
    print(f"Total Applicants: {report['total_applicants']}")
    print(f"Admitted: {report['demographic_statistics']['admit_count']}")
    print(f"Waitlisted: {report['demographic_statistics']['waitlist_count']}")
    print(f"Rejected: {report['demographic_statistics']['reject_count']}")
    print(f"Average Score: {report['demographic_statistics']['average_holistic_score']}")
    
    # Save results and report
    system.save_results(results, 'admission_results.csv')
    system.save_report(report, 'admission_report.json')


if __name__ == "__main__":
    main()