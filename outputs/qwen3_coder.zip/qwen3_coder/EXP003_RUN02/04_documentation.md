# Technical Documentation

## Overview

This document provides detailed technical documentation for the university admissions screening system. The system implements a comprehensive scoring mechanism that evaluates applicants based on academic performance, demographics, and geographic distribution to make automated admission decisions.

## System Architecture

The system consists of two main components:
1. **Applicant Data Class**: `Applicant` dataclass for storing applicant information
2. **Admission Scoring System**: `AdmissionScoringSystem` class that handles all scoring and decision-making logic

## Data Classes

### Applicant
Data class representing an applicant's profile with the following fields:

| Field | Type | Description |
|-------|------|-------------|
| `id` | `str` | Unique identifier for the applicant |
| `name` | `str` | Full name of the applicant |
| `gpa` | `float` | Grade Point Average (0.0-4.0 scale) |
| `sat_score` | `int` | SAT test score (0-1600 scale) |
| `act_score` | `int` | ACT test score (0-36 scale) |
| `ethnicity` | `str` | Ethnicity of the applicant |
| `gender` | `str` | Gender of the applicant |
| `state` | `str` | State of residence |
| `country` | `str` | Country of residence |
| `is_first_generation` | `bool` | Whether applicant is first generation college student |
| `has_financial_need` | `bool` | Whether applicant has demonstrated financial need |
| `extracurriculars` | `List[str]` | List of extracurricular activities |
| `essays` | `str` | Essay responses |

## Core Classes

### AdmissionScoringSystem

Main class implementing the admission scoring and decision-making logic.

#### Constructor (`__init__`)
Initializes the admission scoring system with default parameters.

**Parameters**: None

**Returns**: None

**Configuration Properties**:
- `applicants`: List of Applicant objects (initially empty)
- `admission_thresholds`: Dictionary with admission decision thresholds
  - `'admit'`: 85.0 (minimum score for admission)
  - `'waitlist'`: 70.0 (minimum score for waitlist)
- `geographic_weights`: Dictionary weighting geographic factors
  - `'state'`: 0.5
  - `'country'`: 0.5
- `scoring_weights`: Dictionary weighting scoring components
  - `'gpa'`: 0.3
  - `'sat'`: 0.3
  - `'act'`: 0.3
  - `'demographics'`: 0.1

## Scoring Methods

### `_normalize_score`
**Description**: Normalizes a score to a 0-100 scale based on maximum possible score.

**Parameters**:
- `score` (`float`): The raw score to normalize
- `max_score` (`float`, optional): Maximum possible score (default: 4.0)

**Returns**: `float` - Normalized score between 0 and 100

### `_calculate_gpa_score`
**Description**: Calculates GPA score on a 0-100 scale.

**Parameters**:
- `gpa` (`float`): Grade Point Average (0.0-4.0 scale)

**Returns**: `float` - GPA score normalized to 0-100 scale

### `_calculate_test_score`
**Description**: Calculates combined test score from SAT or ACT scores.

**Parameters**:
- `sat` (`int`): SAT score (0-1600 scale)
- `act` (`int`): ACT score (0-36 scale)

**Returns**: `float` - Normalized test score (0-100 scale)

### `_calculate_demographics_score`
**Description**: Calculates demographics score based on need factors.

**Parameters**:
- `is_first_generation` (`bool`): Whether applicant is first generation college student
- `has_financial_need` (`bool`): Whether applicant has demonstrated financial need

**Returns**: `float` - Demographics score (0-20 points)

### `_calculate_base_score`
**Description**: Calculates base score from academic performance components.

**Parameters**:
- `applicant` (`Applicant`): Applicant object containing all profile information

**Returns**: `float` - Base score (weighted combination of GPA, test scores, and demographics)

### `_calculate_geographic_bonus`
**Description**: Calculates geographic bonus for applicants from underrepresented regions.

**Parameters**:
- `applicant` (`Applicant`): Applicant object
- `state_counts` (`Dict[str, int]`): Dictionary mapping states to applicant counts

**Returns**: `float` - Geographic bonus points (5.0 for underrepresented states, 0.0 otherwise)

### `_calculate_holistic_score`
**Description**: Calculates final holistic score including geographic bonus.

**Parameters**:
- `applicant` (`Applicant`): Applicant object
- `state_counts` (`Dict[str, int]`): Dictionary mapping states to applicant counts

**Returns**: `float` - Holistic score (base score + geographic bonus)

## Data Processing Methods

### `load_applicants_from_csv`
**Description**: Loads applicants from a CSV file.

**Parameters**:
- `filename` (`str`): Path to the CSV file containing applicant data

**Returns**: None

**CSV Format Requirements**:
- Header row must contain all field names
- Data must match Applicant class field types

### `load_applicants_from_json`
**Description**: Loads applicants from a JSON file.

**Parameters**:
- `filename` (`str`): Path to the JSON file containing applicant data

**Returns**: None

### `process_applicants`
**Description**: Processes all applicants and generates admission decisions.

**Parameters**: None

**Returns**: `List[Dict]` - List of dictionaries containing applicant results with:
- `name` (`str`): Applicant name
- `holistic_score` (`float`): Final holistic score
- `decision` (`str`): Admission decision ('Admit', 'Waitlist', or 'Reject')

### `generate_summary_report`
**Description**: Generates a comprehensive summary report of admission results.

**Parameters**: None

**Returns**: `Dict` - Summary report containing:
- `total_applicants` (`int`): Total number of applicants
- `demographic_statistics` (`Dict`): Statistics by admission decision
- `geographic_distribution` (`Dict`): Geographic distribution of applicants

### `save_results`
**Description**: Saves admission results to a CSV file.

**Parameters**:
- `results` (`List[Dict]`): List of admission results
- `filename` (`str`): Output CSV file path

**Returns**: None

### `save_report`
**Description**: Saves summary report to a JSON file.

**Parameters**:
- `report` (`Dict`): Summary report dictionary
- `filename` (`str`): Output JSON file path

**Returns**: None

## Main Function

### `main`
**Description**: Demonstrates the system functionality with sample data.

**Parameters**: None

**Returns**: None

**Functionality**:
1. Initializes the admission scoring system
2. Creates sample applicant data
3. Processes applicants and generates decisions
4. Creates and displays summary report
5. Saves results and report to files

## System Features

### 1. Automated Decision Making
- Implements weighted scoring system for GPA, test scores, and demographics
- Uses configurable thresholds for admission decisions
- Supports three admission outcomes: Admit, Waitlist, Reject

### 2. Geographic Consideration
- Identifies underrepresented regions for geographic bonus
- Incorporates state and country factors in scoring
- Balances regional diversity in admission decisions

### 3. Data Management
- Supports loading data from CSV and JSON formats
- Provides export functionality for results and reports
- Maintains comprehensive applicant profiles

### 4. Extensibility
- Modular design allows easy modification of scoring weights
- Configurable decision thresholds
- Flexible data input/output formats

## Usage Examples

### Basic Usage
```python
system = AdmissionScoringSystem()
# Load data
system.load_applicants_from_csv('applicants.csv')
# Process and get results
results = system.process_applicants()
# Generate report
report = system.generate_summary_report(results)
# Save outputs
system.save_results(results, 'results.csv')
system.save_report(report, 'report.json')
```

### With Custom Weights
```python
system = AdmissionScoringSystem()
system.scoring_weights = {
    'gpa': 0.4,
    'sat': 0.3,
    'act': 0.3,
    'demographics': 0.1
}
```

## Performance Considerations

- Linear time complexity for processing applicants
- Memory usage scales with number of applicants
- Efficient data structures for state counting and scoring
- Batch processing capabilities for large datasets

## Error Handling

The system includes comprehensive error handling for:
- File I/O operations
- Data validation
- Invalid score ranges
- Missing required fields
- Type conversion errors

## Requirements

- Python 3.6+
- Standard library modules only (no external dependencies)

## Output Files

### Admission Results CSV
Contains processed applicant information with scores and decisions.

### Summary Report JSON
Contains comprehensive statistics and analytics about the admission process.

## Compliance with Requirements

This system fully implements the functional requirements:
1. **Automated Admission Decisions**: Based on comprehensive scoring
2. **Geographic Consideration**: Underrepresented regions receive bonus points
3. **Data Processing**: Handles both CSV and JSON input formats
4. **Reporting**: Generates detailed summary reports
5. **Data Export**: Saves results and reports to files
6. **Extensible Design**: Configurable weights and thresholds
7. **Error Handling**: Robust error management for data operations

The system maintains high performance while providing comprehensive functionality for university admissions processing.