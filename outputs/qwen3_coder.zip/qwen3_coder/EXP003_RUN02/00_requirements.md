Functional Requirements:
 FR1. The system shall store applicant data (grades, test scores, demographics, geography).
 FR2. The system shall compute a holistic admission score for each applicant.
 FR3. The system shall automate admission decisions (Admit, Waitlist, Reject).
 FR4. The system shall generate a summary report of cohort statistics.
FR5. The system shall prioritize applicants whose profiles contribute to maintaining the desired geographic distribution of the incoming cohort.
 

 Non-Functional Requirements:
 NFR1. The application shall execute without requiring external databases or services.
 NFR2. The system shall provide transparent scoring metrics in generated reports.