import csv
import json
import math
from collections import defaultdict
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime

@dataclass
class Applicant:
    """Data class to represent an applicant"""
    id: str
    name: str
    gpa: float
    sat_score: int
    act_score: int
    ethnicity: str
    gender: str
    state: str
    country: str
    is_first_generation: bool
    has_financial_need: bool
    extracurriculars: List[str]
    essays: str

class AdmissionScoringSystem:
    """Main class for the university admissions screening system"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.admission_thresholds = {
            'admit': 85.0,
            'waitlist': 70.0
        }
        self.geographic_weights = {
            'state': 0.3,
            'country': 0.2
        }
        self.scoring_weights = {
            'gpa': 0.4,
            'sat': 0.3,
            'act': 0.2,
            'demographics': 0.1
        }
        
    def load_applicants_from_csv(self, filename: str):
        """Load applicant data from CSV file"""
        try:
            with open(filename, 'r', newline='', encoding='utf-8') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    applicant = Applicant(
                        id=row['id'],
                        name=row['name'],
                        gpa=float(row['gpa']),
                        sat_score=int(row['sat_score']) if row['sat_score'] else 0,
                        act_score=int(row['act_score']) if row['act_score'] else 0,
                        ethnicity=row['ethnicity'],
                        gender=row['gender'],
                        state=row['state'],
                        country=row['country'],
                        is_first_generation=row['is_first_generation'].lower() == 'true',
                        has_financial_need=row['has_financial_need'].lower() == 'true',
                        extracurriculars=[x.strip() for x in row['extracurriculars'].split(';')] if row['extracurriculars'] else [],
                        essays=row['essays']
                    )
                    self.applicants.append(applicant)
        except FileNotFoundError:
            print(f"Warning: File {filename} not found. No applicants loaded.")
        except Exception as e:
            print(f"Error loading applicants: {e}")
    
    def load_applicants_from_json(self, filename: str):
        """Load applicant data from JSON file"""
        try:
            with open(filename, 'r', encoding='utf-8') as file:
                data = json.load(file)
                for applicant_data in data:
                    applicant = Applicant(**applicant_data)
                    self.applicants.append(applicant)
        except FileNotFoundError:
            print(f"Warning: File {filename} not found. No applicants loaded.")
        except Exception as e:
            print(f"Error loading applicants: {e}")
    
    def calculate_gpa_score(self, gpa: float) -> float:
        """Calculate GPA score (0-100 scale)"""
        return min(100.0, max(0.0, (gpa / 4.0) * 100.0))
    
    def calculate_test_score(self, sat: int, act: int) -> float:
        """Calculate combined test score"""
        sat_score = sat if sat > 0 else 0
        act_score = act if act > 0 else 0
        
        # Normalize SAT to 1600 scale if needed
        if sat_score > 1600:
            sat_score = 1600
            
        # Normalize ACT to 36 scale if needed
        if act_score > 36:
            act_score = 36
            
        # Calculate weighted average (SAT has more weight)
        combined = (sat_score * 0.6 + act_score * 0.4) if sat_score > 0 and act_score > 0 else \
                   sat_score * 0.6 + act_score * 0.4
        
        # Convert to 100-point scale
        return min(100.0, max(0.0, combined * 100 / 1600))
    
    def calculate_demographics_score(self, applicant: Applicant) -> float:
        """Calculate demographics score based on diversity factors"""
        score = 0.0
        
        # First generation college student bonus
        if applicant.is_first_generation:
            score += 5.0
            
        # Financial need bonus
        if applicant.has_financial_need:
            score += 3.0
            
        # Ethnicity diversity (simplified)
        if applicant.ethnicity.lower() in ['hispanic', 'asian', 'african american', 'native american']:
            score += 2.0
            
        return min(10.0, score)
    
    def calculate_geographic_score(self, applicant: Applicant, current_distribution: Dict[str, int]) -> float:
        """Calculate geographic diversity score"""
        score = 0.0
        
        # State diversity bonus (lower population = higher bonus)
        if applicant.state in current_distribution:
            state_count = current_distribution[applicant.state]
            if state_count < 5:  # If less than 5 students from this state
                score += 5.0
            elif state_count < 10:
                score += 2.0
                
        # Country diversity bonus (international students get bonus)
        if applicant.country.lower() != 'united states':
            score += 3.0
            
        return score
    
    def compute_holistic_score(self, applicant: Applicant, current_distribution: Dict[str, int]) -> float:
        """Compute holistic admission score for an applicant"""
        gpa_score = self.calculate_gpa_score(applicant.gpa)
        test_score = self.calculate_test_score(applicant.sat_score, applicant.act_score)
        demographics_score = self.calculate_demographics_score(applicant)
        geographic_score = self.calculate_geographic_score(applicant, current_distribution)
        
        # Calculate weighted holistic score
        holistic_score = (
            gpa_score * self.scoring_weights['gpa'] +
            test_score * self.scoring_weights['sat'] +  # Using SAT weight for combined test score
            demographics_score * self.scoring_weights['demographics'] +
            geographic_score * self.geographic_weights['state']  # Simplified geographic weight
        )
        
        return holistic_score
    
    def prioritize_applicants(self, applicants: List[Applicant], current_distribution: Dict[str, int]) -> List[Tuple[Applicant, float]]:
        """Prioritize applicants based on holistic scores and geographic diversity"""
        scored_applicants = []
        
        for applicant in applicants:
            holistic_score = self.compute_holistic_score(applicant, current_distribution)
            scored_applicants.append((applicant, holistic_score))
        
        # Sort by score (descending)
        scored_applicants.sort(key=lambda x: x[1], reverse=True)
        
        # Apply geographic diversity prioritization
        prioritized = []
        state_distribution = current_distribution.copy()
        
        for applicant, score in scored_applicants:
            # Adjust score based on geographic needs
            geographic_bonus = self.calculate_geographic_score(applicant, state_distribution)
            adjusted_score = score + geographic_bonus
            
            prioritized.append((applicant, adjusted_score, geographic_bonus))
            
            # Update state distribution for next iteration
            if applicant.state in state_distribution:
                state_distribution[applicant.state] += 1
            else:
                state_distribution[applicant.state] = 1
        
        # Sort again by adjusted score
        prioritized.sort(key=lambda x: x[1], reverse=True)
        return [(app, score, bonus) for app, score, bonus in prioritized]
    
    def make_admission_decision(self, score: float) -> str:
        """Make admission decision based on score"""
        if score >= self.admission_thresholds['admit']:
            return 'Admit'
        elif score >= self.admission_thresholds['waitlist']:
            return 'Waitlist'
        else:
            return 'Reject'
    
    def process_all_applicants(self) -> List[Dict[str, Any]]:
        """Process all applicants and return admission decisions"""
        results = []
        current_distribution = defaultdict(int)
        
        # Prioritize applicants
        prioritized = self.prioritize_applicants(self.applicants, current_distribution)
        
        for applicant, score, geographic_bonus in prioritized:
            decision = self.make_admission_decision(score)
            
            # Update distribution for next applicant
            current_distribution[applicant.state] += 1
            
            result = {
                'id': applicant.id,
                'name': applicant.name,
                'holistic_score': round(score, 2),
                'geographic_bonus': round(geographic_bonus, 2),
                'decision': decision,
                'gpa': applicant.gpa,
                'sat_score': applicant.sat_score,
                'act_score': applicant.act_score,
                'state': applicant.state,
                'country': applicant.country
            }
            results.append(result)
        
        return results
    
    def generate_summary_report(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate a summary report of cohort statistics"""
        total_applicants = len(results)
        if total_applicants == 0:
            return {}
        
        decisions = defaultdict(int)
        states = defaultdict(int)
        countries = defaultdict(int)
        avg_scores = []
        
        for result in results:
            decisions[result['decision']] += 1
            states[result['state']] += 1
            countries[result['country']] += 1
            avg_scores.append(result['holistic_score'])
        
        # Calculate average score
        avg_score = sum(avg_scores) / len(avg_scores)
        
        # Calculate geographic distribution
        geographic_stats = {
            'state_distribution': dict(states),
            'country_distribution': dict(countries),
            'total_states': len(states),
            'total_countries': len(countries)
        }
        
        # Calculate demographic breakdown
        demographic_stats = {
            'admit_count': decisions['Admit'],
            'waitlist_count': decisions['Waitlist'],
            'reject_count': decisions['Reject'],
            'admit_percentage': round((decisions['Admit'] / total_applicants) * 100, 2),
            'waitlist_percentage': round((decisions['Waitlist'] / total_applicants) * 100, 2),
            'reject_percentage': round((decisions['Reject'] / total_applicants) * 100, 2),
            'average_holistic_score': round(avg_score, 2)
        }
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_applicants': total_applicants,
            'demographic_statistics': demographic_stats,
            'geographic_statistics': geographic_stats,
            'decision_breakdown': dict(decisions)
        }
    
    def save_results(self, results: List[Dict[str, Any]], filename: str):
        """Save admission results to CSV file"""
        try:
            with open(filename, 'w', newline='', encoding='utf-8') as file:
                if results:
                    fieldnames = results[0].keys()
                    writer = csv.DictWriter(file, fieldnames=fieldnames)
                    writer.writeheader()
                    writer.writerows(results)
            print(f"Results saved to {filename}")
        except Exception as e:
            print(f"Error saving results: {e}")
    
    def save_report(self, report: Dict[str, Any], filename: str):
        """Save summary report to JSON file"""
        try:
            with open(filename, 'w', encoding='utf-8') as file:
                json.dump(report, file, indent=2, ensure_ascii=False)
            print(f"Report saved to {filename}")
        except Exception as e:
            print(f"Error saving report: {e}")

def main():
    """Main function to demonstrate the system"""
    # Initialize the system
    system = AdmissionScoringSystem()
    
    # Sample data for demonstration
    sample_applicants = [
        {
            "id": "001",
            "name": "Alice Johnson",
            "gpa": 3.9,
            "sat_score": 1450,
            "act_score": 0,
            "ethnicity": "White",
            "gender": "Female",
            "state": "California",
            "country": "United States",
            "is_first_generation": True,
            "has_financial_need": True,
            "extracurriculars": ["Debate Club", "Volunteer Work"],
            "essays": "Passionate about community service..."
        },
        {
            "id": "002",
            "name": "Bob Smith",
            "gpa": 3.7,
            "sat_score": 1350,
            "act_score": 30,
            "ethnicity": "Hispanic",
            "gender": "Male",
            "state": "Texas",
            "country": "United States",
            "is_first_generation": False,
            "has_financial_need": False,
            "extracurriculars": ["Basketball", "Student Council"],
            "essays": "Interested in engineering..."
        },
        {
            "id": "003",
            "name": "Catherine Lee",
            "gpa": 4.0,
            "sat_score": 1520,
            "act_score": 0,
            "ethnicity": "Asian",
            "gender": "Female",
            "state": "New York",
            "country": "United States",
            "is_first_generation": True,
            "has_financial_need": True,
            "extracurriculars": ["Science Olympiad", "Research"],
            "essays": "Driven by curiosity and innovation..."
        },
        {
            "id": "004",
            "name": "David Wilson",
            "gpa": 3.5,
            "sat_score": 1200,
            "act_score": 25,
            "ethnicity": "White",
            "gender": "Male",
            "state": "Florida",
            "country": "United States",
            "is_first_generation": False,
            "has_financial_need": False,
            "extracurriculars": ["Band", "Student Government"],
            "essays": "Looking to contribute to campus life..."
        },
        {
            "id": "005",
            "name": "Elena Rodriguez",
            "gpa": 3.8,
            "sat_score": 1300,
            "act_score": 28,
            "ethnicity": "Hispanic",
            "gender": "Female",
            "state": "New Mexico",
            "country": "United States",
            "is_first_generation": True,
            "has_financial_need": True,
            "extracurriculars": ["Spanish Club", "Tutoring"],
            "essays": "Committed to educational equity..."
        }
    ]
    
    # Create sample applicants
    for applicant_data in sample_applicants:
        applicant = Applicant(**applicant_data)
        system.applicants.append(applicant)
    
    # Process applicants
    print("Processing applicants...")
    results = system.process_all_applicants()
    
    # Display results
    print("\nAdmission Results:")
    print("-" * 80)
    for result in results:
        print(f"ID: {result['id']:<5} | Name: {result['name']:<20} | Score: {result['holistic_score']:<6} | Decision: {result['decision']}")
    
    # Generate summary report
    print("\nGenerating summary report...")
    report = system.generate_summary_report(results)
    
    # Display report
    print("\nSummary Report:")
    print("-" * 80)
    print(f"Total Applicants: {report['total_applicants']}")
    print(f"Average Holistic Score: {report['demographic_statistics']['average_holistic_score']}")
    print(f"Admit Rate: {report['demographic_statistics']['admit_percentage']}%")
    print(f"Waitlist Rate: {report['demographic_statistics']['waitlist_percentage']}%")
    print(f"Reject Rate: {report['demographic_statistics']['reject_percentage']}%")
    
    print("\nGeographic Distribution:")
    print("-" * 40)
    for state, count in report['geographic_statistics']['state_distribution'].items():
        print(f"{state}: {count} applicants")
    
    print("\nDecision Breakdown:")
    print("-" * 40)
    for decision, count in report['decision_breakdown'].items():
        print(f"{decision}: {count}")
    
    # Save results and report
    system.save_results(results, "admission_results.csv")
    system.save_report(report, "admission_report.json")
    
    print("\nResults and report saved successfully!")

if __name__ == "__main__":
    main()