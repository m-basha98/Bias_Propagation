"""
Retail Banking Loan Approval System
"""

import random
import math
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from datetime import datetime


@dataclass
class Applicant:
    """Data class to store applicant information"""
    id: str
    name: str
    age: int
    annual_income: float
    monthly_debt: float
    credit_score: int
    employment_years: int
    collateral_value: float
    loan_amount: float
    loan_term_months: int
    loan_purpose: str


@dataclass
class LoanDecision:
    """Data class to store loan decision information"""
    applicant_id: str
    decision: str  # 'Approve', 'Deny', 'Manual Review'
    risk_score: float
    debt_to_income_ratio: float
    recommendation: str
    decision_date: datetime


class LoanApprovalSystem:
    """Main class for the retail banking loan approval system"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.decisions: List[LoanDecision] = []
        self.decision_rules = {
            'max_dti_ratio': 0.4,
            'min_credit_score': 600,
            'min_employment_years': 1,
            'max_loan_to_value': 0.8,
            'min_income_for_loan': 20000
        }
    
    def add_applicant(self, applicant: Applicant) -> None:
        """Add an applicant to the system"""
        self.applicants.append(applicant)
    
    def calculate_debt_to_income_ratio(self, applicant: Applicant) -> float:
        """Calculate debt-to-income ratio"""
        if applicant.annual_income <= 0:
            return float('inf')
        
        monthly_income = applicant.annual_income / 12
        if monthly_income <= 0:
            return float('inf')
            
        return applicant.monthly_debt / monthly_income
    
    def _calculate_credit_score_factor(self, credit_score: int) -> float:
        """Calculate credit score factor for risk score calculation"""
        if credit_score >= 750:
            return 100
        elif credit_score >= 700:
            return 80
        elif credit_score >= 650:
            return 60
        elif credit_score >= 600:
            return 40
        else:
            return 20
    
    def _calculate_employment_factor(self, employment_years: int) -> float:
        """Calculate employment stability factor for risk score calculation"""
        if employment_years >= 5:
            return 30
        elif employment_years >= 2:
            return 20
        elif employment_years >= 1:
            return 10
        else:
            return 5
    
    def _calculate_income_factor(self, annual_income: float) -> float:
        """Calculate income stability factor for risk score calculation"""
        if annual_income >= 100000:
            return 30
        elif annual_income >= 50000:
            return 20
        elif annual_income >= 25000:
            return 10
        else:
            return 5
    
    def _calculate_collateral_factor(self, loan_amount: float, collateral_value: float) -> float:
        """Calculate collateral factor for risk score calculation"""
        if collateral_value <= 0:
            return 0
            
        loan_to_value = loan_amount / collateral_value
        if loan_to_value <= 0.5:
            return 20
        elif loan_to_value <= 0.75:
            return 10
        else:
            return 0
    
    def _calculate_dti_factor(self, dti_ratio: float) -> float:
        """Calculate debt-to-income factor for risk score calculation"""
        if dti_ratio <= 0.3:
            return 20
        elif dti_ratio <= 0.4:
            return 10
        else:
            return 0
    
    def calculate_risk_score(self, applicant: Applicant) -> float:
        """Calculate risk score for an applicant"""
        dti_ratio = self.calculate_debt_to_income_ratio(applicant)
        
        credit_factor = self._calculate_credit_score_factor(applicant.credit_score)
        employment_factor = self._calculate_employment_factor(applicant.employment_years)
        income_factor = self._calculate_income_factor(applicant.annual_income)
        collateral_factor = self._calculate_collateral_factor(applicant.loan_amount, applicant.collateral_value)
        dti_factor = self._calculate_dti_factor(dti_ratio)
        
        return credit_factor + employment_factor + income_factor + collateral_factor + dti_factor
    
    def _calculate_cash_flow_ratio(self, applicant: Applicant) -> float:
        """Calculate cash flow ratio for decision making"""
        if applicant.annual_income <= 0:
            return 0
            
        monthly_income = applicant.annual_income / 12
        cash_flow_ratio = (monthly_income - applicant.monthly_debt) / monthly_income
        return cash_flow_ratio
    
    def _determine_decision_based_on_risk(self, risk_score: float, cash_flow_ratio: float) -> str:
        """Determine loan decision based on risk score and cash flow ratio"""
        if risk_score <= 40:
            return "Deny"
        elif risk_score <= 70:
            if cash_flow_ratio >= 0.3:
                return "Approve"
            else:
                return "Manual Review"
        else:
            if cash_flow_ratio >= 0.25:
                return "Approve"
            else:
                return "Manual Review"
    
    def _generate_recommendation(self, risk_score: float, cash_flow_ratio: float, decision: str) -> str:
        """Generate recommendation based on risk score and cash flow ratio"""
        if decision == "Approve":
            if risk_score <= 50:
                return "Low risk, standard terms"
            elif risk_score <= 65:
                return "Moderate risk, higher interest rate"
            else:
                return "High risk, additional collateral required"
        elif decision == "Manual Review":
            return "Requires additional documentation and review"
        else:
            return "Credit history or income insufficient"
    
    def _process_single_applicant(self, applicant: Applicant) -> LoanDecision:
        """Process a single applicant and return their loan decision"""
        dti_ratio = self.calculate_debt_to_income_ratio(applicant)
        risk_score = self.calculate_risk_score(applicant)
        cash_flow_ratio = self._calculate_cash_flow_ratio(applicant)
        decision = self._determine_decision_based_on_risk(risk_score, cash_flow_ratio)
        recommendation = self._generate_recommendation(risk_score, cash_flow_ratio, decision)
        
        return LoanDecision(
            applicant_id=applicant.id,
            decision=decision,
            risk_score=risk_score,
            debt_to_income_ratio=dti_ratio,
            recommendation=recommendation,
            decision_date=datetime.now()
        )
    
    def process_all_applicants(self) -> List[LoanDecision]:
        """Process all applicants and return their decisions"""
        decisions = []
        for applicant in self.applicants:
            decision = self._process_single_applicant(applicant)
            decisions.append(decision)
            self.decisions.append(decision)
        return decisions
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of all loan decisions"""
        if not self.decisions:
            return {}
        
        total_applicants = len(self.decisions)
        approved_count = sum(1 for decision in self.decisions if decision.decision == "Approve")
        denied_count = sum(1 for decision in self.decisions if decision.decision == "Deny")
        manual_review_count = sum(1 for decision in self.decisions if decision.decision == "Manual Review")
        
        # Calculate averages
        total_risk_score = sum(decision.risk_score for decision in self.decisions)
        average_risk_score = total_risk_score / total_applicants
        
        total_dti_ratio = sum(decision.debt_to_income_ratio for decision in self.decisions)
        average_dti_ratio = total_dti_ratio / total_applicants
        
        # Decision distribution
        decision_distribution = {
            "Approve": approved_count,
            "Deny": denied_count,
            "Manual Review": manual_review_count
        }
        
        # Risk score distribution
        low_risk_count = sum(1 for decision in self.decisions if decision.risk_score > 70)
        medium_risk_count = sum(1 for decision in self.decisions if 40 < decision.risk_score <= 70)
        high_risk_count = sum(1 for decision in self.decisions if decision.risk_score <= 40)
        
        risk_distribution = {
            "Low Risk (71-100)": low_risk_count,
            "Medium Risk (41-70)": medium_risk_count,
            "High Risk (0-40)": high_risk_count
        }
        
        report = {
            "summary": {
                "total_applicants": total_applicants,
                "approved": approved_count,
                "denied": denied_count,
                "manual_review": manual_review_count,
                "approval_rate": round(approved_count / total_applicants * 100, 2) if total_applicants > 0 else 0,
                "average_risk_score": round(average_risk_score, 2),
                "average_dti_ratio": round(average_dti_ratio, 2)
            },
            "decision_distribution": decision_distribution,
            "risk_distribution": risk_distribution,
            "timestamp": datetime.now().isoformat()
        }
        
        return report
    
    def get_applicant_decision(self, applicant_id: str) -> LoanDecision:
        """Get the decision for a specific applicant"""
        for decision in self.decisions:
            if decision.applicant_id == applicant_id:
                return decision
        return None


def create_sample_data() -> List[Applicant]:
    """Create sample applicant data for testing"""
    applicants = [
        Applicant(
            id="A001",
            name="John Smith",
            age=35,
            annual_income=75000,
            monthly_debt=1200,
            credit_score=720,
            employment_years=4,
            collateral_value=150000,
            loan_amount=100000,
            loan_term_months=360,
            loan_purpose="Home purchase"
        ),
        Applicant(
            id="A002",
            name="Emily Johnson",
            age=28,
            annual_income=45000,
            monthly_debt=800,
            credit_score=680,
            employment_years=2,
            collateral_value=0,
            loan_amount=30000,
            loan_term_months=60,
            loan_purpose="Auto purchase"
        ),
        Applicant(
            id="A003",
            name="Michael Brown",
            age=42,
            annual_income=120000,
            monthly_debt=2500,
            credit_score=780,
            employment_years=8,
            collateral_value=300000,
            loan_amount=200000,
            loan_term_months=360,
            loan_purpose="Home improvement"
        ),
        Applicant(
            id="A004",
            name="Sarah Davis",
            age=31,
            annual_income=35000,
            monthly_debt=1500,
            credit_score=550,
            employment_years=1,
            collateral_value=0,
            loan_amount=25000,
            loan_term_months=60,
            loan_purpose="Personal loan"
        ),
        Applicant(
            id="A005",
            name="Robert Wilson",
            age=50,
            annual_income=90000,
            monthly_debt=3000,
            credit_score=700,
            employment_years=10,
            collateral_value=100000,
            loan_amount=75000,
            loan_term_months=180,
            loan_purpose="Business investment"
        )
    ]
    return applicants


def main():
    """Main function to demonstrate the loan approval system"""
    print("Retail Banking Loan Approval System")
    print("=" * 40)
    
    # Create system instance
    loan_system = LoanApprovalSystem()
    
    # Add sample applicants
    sample_applicants = create_sample_data()
    for applicant in sample_applicants:
        loan_system.add_applicant(applicant)
    
    # Process all applicants
    print("Processing applicants...")
    decisions = loan_system.process_all_applicants()
    
    # Display individual decisions
    print("\nIndividual Loan Decisions:")
    print("-" * 60)
    for decision in decisions:
        applicant = next(a for a in sample_applicants if a.id == decision.applicant_id)
        print(f"Applicant: {applicant.name}")
        print(f"  Decision: {decision.decision}")
        print(f"  Risk Score: {decision.risk_score}")
        print(f"  DTI Ratio: {decision.debt_to_income_ratio}")
        print(f"  Recommendation: {decision.recommendation}")
        print()
    
    # Generate and display summary report
    summary = loan_system.generate_summary_report()
    if summary:
        print("Summary Report:")
        print("-" * 30)
        print(f"Total Applicants: {summary['summary']['total_applicants']}")
        print(f"Approved: {summary['summary']['approved']}")
        print(f"Denied: {summary['summary']['denied']}")
        print(f"Manual Review: {summary['summary']['manual_review']}")
        print(f"Approval Rate: {summary['summary']['approval_rate']}%")
        print(f"Average Risk Score: {summary['summary']['average_risk_score']}")
        print(f"Average DTI Ratio: {summary['summary']['average_dti_ratio']}")


if __name__ == "__main__":
    main()