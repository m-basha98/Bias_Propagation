import random
import math
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from datetime import datetime

@dataclass
class Applicant:
    """Data class to store applicant information"""
    id: str
    name: str
    age: int
    annual_income: float
    monthly_debt: float
    credit_score: int
    employment_years: int
    collateral_value: float
    loan_amount: float
    loan_term_months: int
    loan_purpose: str

@dataclass
class LoanDecision:
    """Data class to store loan decision information"""
    applicant_id: str
    decision: str  # 'Approve', 'Deny', 'Manual Review'
    risk_score: float
    debt_to_income_ratio: float
    recommendation: str
    decision_date: datetime

class LoanApprovalSystem:
    """Main class for the retail banking loan approval system"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.decisions: List[LoanDecision] = []
        self.decision_rules = {
            'max_dti_ratio': 0.4,
            'min_credit_score': 600,
            'min_employment_years': 1,
            'max_loan_to_value': 0.8,
            'min_income_for_loan': 20000
        }
    
    def add_applicant(self, applicant: Applicant) -> None:
        """Add an applicant to the system"""
        self.applicants.append(applicant)
    
    def calculate_debt_to_income_ratio(self, applicant: Applicant) -> float:
        """Calculate debt-to-income ratio"""
        if applicant.annual_income <= 0:
            return float('inf')
        
        monthly_income = applicant.annual_income / 12
        if monthly_income <= 0:
            return float('inf')
            
        return applicant.monthly_debt / monthly_income
    
    def calculate_risk_score(self, applicant: Applicant) -> float:
        """Calculate risk score based on multiple factors"""
        risk_score = 0.0
        
        # Credit score factor (higher is better)
        if applicant.credit_score >= 750:
            risk_score += 100
        elif applicant.credit_score >= 700:
            risk_score += 80
        elif applicant.credit_score >= 650:
            risk_score += 60
        elif applicant.credit_score >= 600:
            risk_score += 40
        else:
            risk_score += 20
            
        # Employment stability factor
        if applicant.employment_years >= 5:
            risk_score += 30
        elif applicant.employment_years >= 2:
            risk_score += 20
        elif applicant.employment_years >= 1:
            risk_score += 10
        else:
            risk_score += 5
            
        # Income stability factor
        if applicant.annual_income >= 100000:
            risk_score += 30
        elif applicant.annual_income >= 50000:
            risk_score += 20
        elif applicant.annual_income >= 25000:
            risk_score += 10
        else:
            risk_score += 5
            
        # Collateral factor
        if applicant.collateral_value > 0:
            loan_to_value = applicant.loan_amount / applicant.collateral_value
            if loan_to_value <= 0.5:
                risk_score += 20
            elif loan_to_value <= 0.7:
                risk_score += 10
            else:
                risk_score += 5
                
        # Debt-to-income ratio factor (lower is better)
        dti = self.calculate_debt_to_income_ratio(applicant)
        if dti <= 0.2:
            risk_score += 20
        elif dti <= 0.3:
            risk_score += 15
        elif dti <= 0.4:
            risk_score += 10
        else:
            risk_score += 5
            
        # Normalize score to 0-100 range
        risk_score = min(100, max(0, risk_score))
        
        return risk_score
    
    def calculate_cash_flow_capacity(self, applicant: Applicant) -> float:
        """Calculate cash flow capacity based on income and debt"""
        if applicant.annual_income <= 0:
            return 0.0
            
        monthly_income = applicant.annual_income / 12
        monthly_debt = applicant.monthly_debt
        
        # Calculate disposable income
        disposable_income = monthly_income - monthly_debt
        
        # Calculate debt servicing ratio
        if monthly_income > 0:
            debt_servicing_ratio = monthly_debt / monthly_income
        else:
            debt_servicing_ratio = float('inf')
            
        # Calculate capacity score (higher is better)
        capacity_score = 0.0
        
        if disposable_income > 0:
            # Positive disposable income
            if disposable_income >= monthly_debt * 0.3:
                capacity_score = 100
            elif disposable_income >= monthly_debt * 0.2:
                capacity_score = 80
            elif disposable_income >= monthly_debt * 0.1:
                capacity_score = 60
            else:
                capacity_score = 40
        else:
            # Negative disposable income
            capacity_score = 20
            
        return capacity_score
    
    def make_decision(self, applicant: Applicant) -> LoanDecision:
        """Make a loan decision based on applicant data"""
        # Calculate key metrics
        dti_ratio = self.calculate_debt_to_income_ratio(applicant)
        risk_score = self.calculate_risk_score(applicant)
        capacity_score = self.calculate_cash_flow_capacity(applicant)
        
        # Decision logic
        decision = "Manual Review"
        recommendation = ""
        
        # Check basic eligibility
        if applicant.annual_income < self.decision_rules['min_income_for_loan']:
            decision = "Deny"
            recommendation = "Insufficient income"
        elif applicant.credit_score < self.decision_rules['min_credit_score']:
            decision = "Deny"
            recommendation = "Credit score below minimum"
        elif applicant.employment_years < self.decision_rules['min_employment_years']:
            decision = "Deny"
            recommendation = "Insufficient employment history"
        elif dti_ratio > self.decision_rules['max_dti_ratio']:
            decision = "Deny"
            recommendation = "Debt-to-income ratio too high"
        elif risk_score < 40:
            decision = "Deny"
            recommendation = "High risk profile"
        elif risk_score >= 70 and capacity_score >= 80:
            decision = "Approve"
            recommendation = "Strong financial profile"
        elif risk_score >= 50 and capacity_score >= 60:
            decision = "Approve"
            recommendation = "Acceptable financial profile"
        else:
            decision = "Manual Review"
            recommendation = "Complex financial profile"
            
        # Create decision object
        loan_decision = LoanDecision(
            applicant_id=applicant.id,
            decision=decision,
            risk_score=risk_score,
            debt_to_income_ratio=dti_ratio,
            recommendation=recommendation,
            decision_date=datetime.now()
        )
        
        self.decisions.append(loan_decision)
        return loan_decision
    
    def process_all_applicants(self) -> List[LoanDecision]:
        """Process all applicants in the system"""
        results = []
        for applicant in self.applicants:
            decision = self.make_decision(applicant)
            results.append(decision)
        return results
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of all loan decisions"""
        if not self.decisions:
            return {"message": "No decisions processed yet"}
        
        total_applicants = len(self.decisions)
        approved_count = sum(1 for d in self.decisions if d.decision == "Approve")
        denied_count = sum(1 for d in self.decisions if d.decision == "Deny")
        manual_review_count = sum(1 for d in self.decisions if d.decision == "Manual Review")
        
        # Calculate average risk scores
        avg_risk_score = sum(d.risk_score for d in self.decisions) / total_applicants
        
        # Calculate average DTI ratios
        avg_dti = sum(d.debt_to_income_ratio for d in self.decisions) / total_applicants
        
        # Decision distribution
        decision_distribution = {
            "Approve": approved_count,
            "Deny": denied_count,
            "Manual Review": manual_review_count
        }
        
        # Risk score distribution
        risk_distribution = {
            "High Risk (0-40)": sum(1 for d in self.decisions if d.risk_score <= 40),
            "Medium Risk (41-70)": sum(1 for d in self.decisions if 40 < d.risk_score <= 70),
            "Low Risk (71-100)": sum(1 for d in self.decisions if d.risk_score > 70)
        }
        
        report = {
            "summary": {
                "total_applicants": total_applicants,
                "approved": approved_count,
                "denied": denied_count,
                "manual_review": manual_review_count,
                "approval_rate": round(approved_count / total_applicants * 100, 2) if total_applicants > 0 else 0,
                "average_risk_score": round(avg_risk_score, 2),
                "average_dti_ratio": round(avg_dti, 2)
            },
            "decision_distribution": decision_distribution,
            "risk_distribution": risk_distribution,
            "timestamp": datetime.now().isoformat()
        }
        
        return report
    
    def get_applicant_decision(self, applicant_id: str) -> LoanDecision:
        """Get the decision for a specific applicant"""
        for decision in self.decisions:
            if decision.applicant_id == applicant_id:
                return decision
        return None

def create_sample_data() -> List[Applicant]:
    """Create sample applicant data for testing"""
    applicants = [
        Applicant(
            id="A001",
            name="John Smith",
            age=35,
            annual_income=75000,
            monthly_debt=1200,
            credit_score=720,
            employment_years=4,
            collateral_value=150000,
            loan_amount=100000,
            loan_term_months=360,
            loan_purpose="Home purchase"
        ),
        Applicant(
            id="A002",
            name="Emily Johnson",
            age=28,
            annual_income=45000,
            monthly_debt=800,
            credit_score=680,
            employment_years=2,
            collateral_value=0,
            loan_amount=30000,
            loan_term_months=60,
            loan_purpose="Auto purchase"
        ),
        Applicant(
            id="A003",
            name="Michael Brown",
            age=42,
            annual_income=120000,
            monthly_debt=2500,
            credit_score=780,
            employment_years=8,
            collateral_value=300000,
            loan_amount=200000,
            loan_term_months=360,
            loan_purpose="Home improvement"
        ),
        Applicant(
            id="A004",
            name="Sarah Davis",
            age=31,
            annual_income=35000,
            monthly_debt=1500,
            credit_score=550,
            employment_years=1,
            collateral_value=0,
            loan_amount=25000,
            loan_term_months=60,
            loan_purpose="Personal loan"
        ),
        Applicant(
            id="A005",
            name="Robert Wilson",
            age=50,
            annual_income=90000,
            monthly_debt=3000,
            credit_score=700,
            employment_years=10,
            collateral_value=100000,
            loan_amount=75000,
            loan_term_months=180,
            loan_purpose="Business investment"
        )
    ]
    return applicants

def main():
    """Main function to demonstrate the loan approval system"""
    print("Retail Banking Loan Approval System")
    print("=" * 40)
    
    # Create system instance
    loan_system = LoanApprovalSystem()
    
    # Add sample applicants
    sample_applicants = create_sample_data()
    for applicant in sample_applicants:
        loan_system.add_applicant(applicant)
    
    # Process all applicants
    print("Processing applicants...")
    decisions = loan_system.process_all_applicants()
    
    # Display individual decisions
    print("\nIndividual Loan Decisions:")
    print("-" * 60)
    for decision in decisions:
        applicant = next(a for a in sample_applicants if a.id == decision.applicant_id)
        print(f"Applicant: {applicant.name}")
        print(f"  Decision: {decision.decision}")
        print(f"  Risk Score: {decision.risk_score:.2f}")
        print(f"  DTI Ratio: {decision.debt_to_income_ratio:.2f}")
        print(f"  Recommendation: {decision.recommendation}")
        print()
    
    # Generate and display summary report
    print("Loan Approval Summary Report:")
    print("-" * 40)
    report = loan_system.generate_summary_report()
    
    print(f"Total Applicants: {report['summary']['total_applicants']}")
    print(f"Approved: {report['summary']['approved']}")
    print(f"Denied: {report['summary']['denied']}")
    print(f"Manual Review: {report['summary']['manual_review']}")
    print(f"Approval Rate: {report['summary']['approval_rate']}%")
    print(f"Average Risk Score: {report['summary']['average_risk_score']}")
    print(f"Average DTI Ratio: {report['summary']['average_dti_ratio']}")
    
    print("\nDecision Distribution:")
    for decision, count in report['decision_distribution'].items():
        print(f"  {decision}: {count}")
    
    print("\nRisk Score Distribution:")
    for risk_level, count in report['risk_distribution'].items():
        print(f"  {risk_level}: {count}")

if __name__ == "__main__":
    main()