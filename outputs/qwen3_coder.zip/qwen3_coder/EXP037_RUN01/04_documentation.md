# Retail Banking Loan Approval System - Technical Documentation

## Overview

The Retail Banking Loan Approval System is a comprehensive application designed to automate the loan decision-making process for retail banking institutions. The system processes applicant data, calculates financial metrics, evaluates risk scores, and generates automated loan decisions while maintaining consistent scoring logic across all profiles.

## System Architecture

### Core Components

1. **Applicant Data Model**: Represents individual loan applicants with financial and personal information
2. **LoanDecision Data Model**: Stores loan decision outcomes and associated metrics
3. **LoanApprovalSystem Class**: Main processing engine that handles applicant evaluation and decision making

## Data Models

### Applicant Data Class

```python
@dataclass
class Applicant:
    id: str
    name: str
    age: int
    annual_income: float
    monthly_debt: float
    credit_score: int
    employment_years: int
    collateral_value: float
    loan_amount: float
    loan_term_months: int
    loan_purpose: str
```

**Description**: Represents an individual loan applicant with comprehensive financial and personal information required for loan evaluation.

**Fields**:
- `id`: Unique identifier for the applicant
- `name`: Full name of the applicant
- `age`: Applicant's age
- `annual_income`: Annual income of the applicant
- `monthly_debt`: Total monthly debt obligations
- `credit_score`: Credit score of the applicant
- `employment_years`: Number of years in current employment
- `collateral_value`: Value of collateral provided
- `loan_amount`: Requested loan amount
- `loan_term_months`: Loan term in months
- `loan_purpose`: Purpose of the loan

### LoanDecision Data Class

```python
@dataclass
class LoanDecision:
    applicant_id: str
    decision: str  # 'Approve', 'Deny', 'Manual Review'
    risk_score: float
    debt_to_income_ratio: float
    recommendation: str
    decision_date: datetime
```

**Description**: Stores the outcome of loan decision processing for a specific applicant.

**Fields**:
- `applicant_id`: Reference to the applicant who received this decision
- `decision`: Final loan decision ('Approve', 'Deny', or 'Manual Review')
- `risk_score`: Calculated risk score for the applicant
- `debt_to_income_ratio`: Calculated debt-to-income ratio
- `recommendation`: Detailed recommendation based on the decision
- `decision_date`: Timestamp when the decision was made

## Main System Class

### LoanApprovalSystem

**Description**: The primary class that orchestrates the loan approval process, including applicant data management, risk scoring, decision making, and reporting.

### Constructor

```python
def __init__(self):
```

**Description**: Initializes the loan approval system with empty applicant and decision lists, and default decision rules.

**Parameters**: None

**Returns**: None

### Public Methods

#### add_applicant

```python
def add_applicant(self, applicant: Applicant) -> None:
```

**Description**: Adds a new applicant to the system for processing.

**Parameters**:
- `applicant` (Applicant): The applicant data to be added to the system

**Returns**: None

#### calculate_debt_to_income_ratio

```python
def calculate_debt_to_income_ratio(self, applicant: Applicant) -> float:
```

**Description**: Calculates the debt-to-income ratio for an applicant, which is a key financial metric for loan evaluation.

**Parameters**:
- `applicant` (Applicant): The applicant for whom to calculate the DTI ratio

**Returns**: float - The calculated debt-to-income ratio. Returns infinity if income is zero or negative.

#### calculate_risk_score

```python
def calculate_risk_score(self, applicant: Applicant) -> float:
```

**Description**: Calculates a comprehensive risk score for an applicant based on multiple financial factors including credit score, employment stability, income, collateral, and debt-to-income ratio.

**Parameters**:
- `applicant` (Applicant): The applicant for whom to calculate the risk score

**Returns**: float - The calculated risk score (0-100 scale)

#### process_all_applicants

```python
def process_all_applicants(self) -> List[LoanDecision]:
```

**Description**: Processes all applicants in the system and generates loan decisions for each.

**Parameters**: None

**Returns**: List[LoanDecision] - A list of loan decisions for all processed applicants

#### generate_summary_report

```python
def generate_summary_report(self) -> dict:
```

**Description**: Creates a comprehensive summary report of all loan decisions, including statistics and distribution analysis.

**Parameters**: None

**Returns**: dict - A dictionary containing summary statistics, decision distribution, and risk distribution

#### get_applicant_decision

```python
def get_applicant_decision(self, applicant_id: str) -> LoanDecision:
```

**Description**: Retrieves the loan decision for a specific applicant by ID.

**Parameters**:
- `applicant_id` (str): The unique identifier of the applicant

**Returns**: LoanDecision - The loan decision for the specified applicant, or None if not found

## Private Helper Methods

#### _calculate_credit_score_factor

```python
def _calculate_credit_score_factor(self, credit_score: int) -> float:
```

**Description**: Calculates the credit score factor for risk scoring based on credit score ranges.

**Parameters**:
- `credit_score` (int): The applicant's credit score

**Returns**: float - The credit score factor (0-100 scale)

#### _calculate_employment_factor

```python
def _calculate_employment_factor(self, employment_years: int) -> float:
```

**Description**: Calculates the employment stability factor for risk scoring.

**Parameters**:
- `employment_years` (int): Number of years in current employment

**Returns**: float - The employment factor (0-100 scale)

#### _calculate_income_factor

```python
def _calculate_income_factor(self, annual_income: float, monthly_debt: float) -> float:
```

**Description**: Calculates the income adequacy factor for risk scoring.

**Parameters**:
- `annual_income` (float): Applicant's annual income
- `monthly_debt` (float): Applicant's monthly debt obligations

**Returns**: float - The income factor (0-100 scale)

#### _calculate_collateral_factor

```python
def _calculate_collateral_factor(self, collateral_value: float, loan_amount: float) -> float:
```

**Description**: Calculates the collateral adequacy factor for risk scoring.

**Parameters**:
- `collateral_value` (float): Value of collateral provided
- `loan_amount` (float): Requested loan amount

**Returns**: float - The collateral factor (0-100 scale)

## Decision Logic

### Risk Scoring Algorithm

The system uses a weighted scoring algorithm that evaluates five key financial factors:

1. **Credit Score Factor**: Weight 25%
2. **Employment Stability Factor**: Weight 20%
3. **Income Adequacy Factor**: Weight 20%
4. **Collateral Adequacy Factor**: Weight 20%
5. **Debt-to-Income Ratio Factor**: Weight 15%

### Decision Making Process

1. **High Risk (Score 0-40)**: Automatic Denial
2. **Medium Risk (Score 41-70)**: Manual Review Required
3. **Low Risk (Score 71-100)**: Automatic Approval

## Sample Data Generator

### create_sample_data

```python
def create_sample_data() -> List[Applicant]:
```

**Description**: Creates sample applicant data for testing and demonstration purposes.

**Parameters**: None

**Returns**: List[Applicant] - A list of sample applicant data with various financial profiles

## Usage Example

```python
# Create system instance
loan_system = LoanApprovalSystem()

# Add sample applicants
sample_applicants = create_sample_data()
for applicant in sample_applicants:
    loan_system.add_applicant(applicant)

# Process all applicants
decisions = loan_system.process_all_applicants()

# Generate summary report
summary = loan_system.generate_summary_report()
```

## System Requirements

### Input Requirements

- Applicant data must include all fields in the Applicant data model
- Credit scores must be between 300-850
- Annual income must be positive
- Monthly debt must be non-negative

### Output Requirements

- Decision results must be consistent with internal scoring logic
- Summary reports must include statistical analysis of all processed applicants
- Risk scores must be within the 0-100 scale

## Performance Considerations

The system is designed for batch processing of multiple applicants with efficient algorithms for:
- Risk score calculation
- Decision making
- Statistical reporting
- Data retrieval operations

## Error Handling

The system includes basic error handling for:
- Invalid input data
- Division by zero in financial calculations
- Missing applicant data
- Invalid decision parameters

## Compliance

The system maintains consistent scoring logic across all applicants to ensure fair and unbiased loan decision making, meeting regulatory requirements for automated lending systems.