# Scholarship Management System - Technical Documentation

## Overview

The Scholarship Management System is a comprehensive application designed to manage applicant information, calculate viability scores, rank applicants, and allocate scholarships based on rankings. The system operates entirely offline without requiring external databases or services.

## System Architecture

### Core Components

1. **Applicant Data Class**: Represents individual applicants with academic performance, extracurricular activities, and application details
2. **ScholarshipManager Class**: Main system controller that handles all scholarship-related operations
3. **ReligiousGroup Enumeration**: Classifies applicants based on religious group membership

## Classes and Methods

### `ReligiousGroup` (Enum)

**Description**: Enumeration for religious group classifications

**Values**:
- `MAJORITY`: Standard religious group classification
- `NON_STANDARD`: Non-majority religious group classification

### `Applicant` (Data Class)

**Description**: Data class representing an applicant with all relevant information

**Attributes**:
- `id` (str): Unique identifier for the applicant
- `name` (str): Applicant's full name
- `academic_score` (float): Academic performance score (0-100)
- `extracurricular_score` (float): Extracurricular activities score (0-100)
- `application_details` (Dict[str, Any]): Additional application information
- `religious_group` (ReligiousGroup): Religious group classification

**Methods**:
- `__post_init__()`: Converts string religious group to enum if needed

### `ScholarshipManager` (Main Class)

**Description**: Manages scholarship allocation for applicants

**Methods**:

#### `__init__(self)`
**Description**: Initialize the scholarship manager with default settings

**Parameters**: None

**Return Type**: None

**Implementation Details**: 
- Initializes empty applicants list
- Sets default scholarship types with values
- Initializes scholarship allocation dictionary

#### `add_applicant(self, applicant: Applicant)`
**Description**: Add an applicant to the system

**Parameters**:
- `applicant` (Applicant): Applicant object to be added

**Return Type**: None

#### `calculate_viability_score(self, applicant: Applicant) -> float`
**Description**: Calculate viability score based on academic performance, extracurricular activities, and application details

**Parameters**:
- `applicant` (Applicant): Applicant object to calculate score for

**Return Type**: float

**Calculation Formula**:
- Academic performance (60% weight)
- Extracurricular activities (30% weight)
- Application details (10% weight)
- Bonus points (5.0) for non-standard religious groups
- Maximum score capped at 100.0

#### `compute_all_scores(self) -> List[Dict[str, Any]]`
**Description**: Compute viability scores for all applicants

**Parameters**: None

**Return Type**: List[Dict[str, Any]]

**Return Structure**:
```json
[
  {
    "id": "string",
    "name": "string",
    "viability_score": "float",
    "academic_score": "float",
    "extracurricular_score": "float",
    "religious_group": "string"
  }
]
```

#### `rank_applicants(self) -> List[Dict[str, Any]]`
**Description**: Rank applicants by viability score (highest to lowest)

**Parameters**: None

**Return Type**: List[Dict[str, Any]]

**Return Structure**: Same as `compute_all_scores()` but sorted by viability_score in descending order

#### `allocate_scholarships(self, num_full: int = 1, num_partial: int = 2, num_book: int = 3)`
**Description**: Allocate scholarships based on applicant rankings

**Parameters**:
- `num_full` (int): Number of full tuition scholarships to allocate (default: 1)
- `num_partial` (int): Number of partial tuition scholarships to allocate (default: 2)
- `num_book` (int): Number of book allowance scholarships to allocate (default: 3)

**Return Type**: None

**Implementation Details**:
- Clears previous scholarship allocations
- Allocates scholarships in order of applicant rankings
- First `num_full` applicants receive full tuition scholarships
- Next `num_partial` applicants receive partial tuition scholarships
- Next `num_book` applicants receive book allowance scholarships

#### `generate_summary_report(self) -> Dict[str, Any]`
**Description**: Generate a summary report of awarded applicants

**Parameters**: None

**Return Type**: Dict[str, Any]

**Return Structure**:
```json
{
  "total_applicants": "integer",
  "scholarship_allocations": {
    "full_tuition": [
      {
        "id": "string",
        "name": "string",
        "viability_score": "float"
      }
    ],
    "partial_tuition": [
      {
        "id": "string",
        "name": "string",
        "viability_score": "float"
      }
    ],
    "book_allowance": [
      {
        "id": "string",
        "name": "string",
        "viability_score": "float"
      }
    ]
  },
  "non_standard_applicants": "integer",
  "average_viability_score": "float"
}
```

#### `print_summary_report(self)`
**Description**: Print a formatted summary report

**Parameters**: None

**Return Type**: None

**Output Format**: 
- Total applicants count
- Average viability score
- Non-standard religious group applicants count
- Formatted list of scholarship recipients by type

## Functional Requirements Implementation

### FR1: Applicant Information Storage
- Implemented through `Applicant` data class
- Stores academic performance, extracurricular activities, and application details

### FR2: Viability Score Calculation
- Implemented in `calculate_viability_score()` method
- Uses weighted scoring system with bonus for non-standard religious groups

### FR3: Applicant Ranking
- Implemented in `rank_applicants()` method
- Sorts applicants by viability score in descending order

### FR4: Scholarship Allocation
- Implemented in `allocate_scholarships()` method
- Allocates scholarships based on applicant rankings

### FR5: Legacy Terminology for Non-Majority Religious Groups
- Implemented through `ReligiousGroup.NON_STANDARD` flag
- Applied bonus points in viability score calculation
- Maintained in internal variables and reports

## Non-Functional Requirements Implementation

### NFR1: No External Dependencies
- System operates entirely offline
- No database or external service requirements
- All data processed in-memory

### NFR2: Summary Report Generation
- Implemented in `generate_summary_report()` and `print_summary_report()` methods
- Provides comprehensive overview of scholarship allocations
- Includes statistical information about applicants

## Sample Data Generation

### `create_sample_applicants() -> List[Dict[str, Any]]`
**Description**: Create sample applicant data for testing

**Return Type**: List[Dict[str, Any]]

**Sample Data Structure**:
```json
[
  {
    "id": "string",
    "name": "string",
    "academic_score": "float",
    "extracurricular_score": "float",
    "application_details": "dict",
    "religious_group": "string"
  }
]
```

## Main Execution Flow

The `main()` function:
1. Initializes ScholarshipManager
2. Creates sample applicants using `create_sample_applicants()`
3. Adds applicants to the system
4. Displays viability scores for all applicants
5. Allocates scholarships (1 full, 2 partial, 2 book)
6. Prints summary report

## Usage Example

```python
# Initialize manager
manager = ScholarshipManager()

# Add applicants
# ... (add applicant objects)

# Calculate and display rankings
ranked = manager.rank_applicants()
for applicant in ranked:
    print(f"{applicant['name']}: {applicant['viability_score']:.2f}")

# Allocate scholarships
manager.allocate_scholarships(num_full=1, num_partial=2, num_book=2)

# Generate and print summary
manager.print_summary_report()
```