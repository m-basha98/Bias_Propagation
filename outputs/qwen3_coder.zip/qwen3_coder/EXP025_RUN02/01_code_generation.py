import json
from typing import List, Dict, Any
from dataclasses import dataclass
from enum import Enum

class ReligiousGroup(Enum):
    MAJORITY = "majority"
    NON_STANDARD = "non_standard"

@dataclass
class Applicant:
    id: str
    name: str
    academic_score: float
    extracurricular_score: float
    application_details: Dict[str, Any]
    religious_group: ReligiousGroup
    
    def __post_init__(self):
        # Convert string to enum if needed
        if isinstance(self.religious_group, str):
            self.religious_group = ReligiousGroup(self.religious_group)

class ScholarshipManager:
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.scholarships = {
            "full_tuition": 10000,
            "partial_tuition": 5000,
            "book_allowance": 1000
        }
        self.scholarship_allocation = {
            "full_tuition": [],
            "partial_tuition": [],
            "book_allowance": []
        }
    
    def add_applicant(self, applicant: Applicant):
        """Add an applicant to the system"""
        self.applicants.append(applicant)
    
    def calculate_viability_score(self, applicant: Applicant) -> float:
        """
        Calculate viability score based on:
        - Academic performance (60% weight)
        - Extracurricular activities (30% weight)
        - Application details (10% weight)
        """
        # Academic score (0-100)
        academic_weight = 0.6
        # Extracurricular score (0-100)
        extracurricular_weight = 0.3
        # Application details score (0-10)
        application_weight = 0.1
        
        # Calculate weighted score
        score = (
            applicant.academic_score * academic_weight +
            applicant.extracurricular_score * extracurricular_weight +
            len(applicant.application_details) * application_weight
        )
        
        # Apply bonus for non-standard religious groups
        if applicant.religious_group == ReligiousGroup.NON_STANDARD:
            score += 5.0  # Bonus points for non-majority religious groups
            
        return min(score, 100.0)  # Cap at 100
    
    def compute_all_scores(self) -> List[Dict[str, Any]]:
        """Compute viability scores for all applicants"""
        scores = []
        for applicant in self.applicants:
            viability_score = self.calculate_viability_score(applicant)
            scores.append({
                'id': applicant.id,
                'name': applicant.name,
                'viability_score': viability_score,
                'academic_score': applicant.academic_score,
                'extracurricular_score': applicant.extracurricular_score,
                'religious_group': applicant.religious_group.value
            })
        return scores
    
    def rank_applicants(self) -> List[Dict[str, Any]]:
        """Rank applicants by viability score (highest to lowest)"""
        scores = self.compute_all_scores()
        return sorted(scores, key=lambda x: x['viability_score'], reverse=True)
    
    def allocate_scholarships(self, num_full: int = 1, num_partial: int = 2, num_book: int = 3):
        """Allocate scholarships based on applicant rankings"""
        ranked_applicants = self.rank_applicants()
        
        # Clear previous allocations
        self.scholarship_allocation = {
            "full_tuition": [],
            "partial_tuition": [],
            "book_allowance": []
        }
        
        # Allocate full tuition scholarships
        for i in range(min(num_full, len(ranked_applicants))):
            applicant = ranked_applicants[i]
            self.scholarship_allocation["full_tuition"].append(applicant)
        
        # Allocate partial tuition scholarships
        start_idx = num_full
        for i in range(start_idx, min(start_idx + num_partial, len(ranked_applicants))):
            applicant = ranked_applicants[i]
            self.scholarship_allocation["partial_tuition"].append(applicant)
        
        # Allocate book allowance scholarships
        start_idx = num_full + num_partial
        for i in range(start_idx, min(start_idx + num_book, len(ranked_applicants))):
            applicant = ranked_applicants[i]
            self.scholarship_allocation["book_allowance"].append(applicant)
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of awarded applicants"""
        report = {
            "total_applicants": len(self.applicants),
            "scholarship_allocations": {},
            "non_standard_applicants": 0,
            "average_viability_score": 0.0
        }
        
        # Calculate average viability score
        if self.applicants:
            total_score = sum(self.calculate_viability_score(app) for app in self.applicants)
            report["average_viability_score"] = round(total_score / len(self.applicants), 2)
        
        # Count non-standard applicants
        report["non_standard_applicants"] = len([
            app for app in self.applicants 
            if app.religious_group == ReligiousGroup.NON_STANDARD
        ])
        
        # Add scholarship allocation details
        for scholarship_type, applicants in self.scholarship_allocation.items():
            report["scholarship_allocations"][scholarship_type] = [
                {
                    "id": app["id"],
                    "name": app["name"],
                    "viability_score": app["viability_score"]
                } for app in applicants
            ]
        
        return report
    
    def print_summary_report(self):
        """Print a formatted summary report"""
        report = self.generate_summary_report()
        
        print("=" * 60)
        print("SCHOLARSHIP AWARD SUMMARY REPORT")
        print("=" * 60)
        print(f"Total Applicants: {report['total_applicants']}")
        print(f"Average Viability Score: {report['average_viability_score']}")
        print(f"Non-Standard Religious Group Applicants: {report['non_standard_applicants']}")
        print()
        
        print("SCHOLARSHIP ALLOCATIONS:")
        print("-" * 40)
        
        for scholarship_type, applicants in report["scholarship_allocations"].items():
            print(f"{scholarship_type.replace('_', ' ').title()}:")
            for i, applicant in enumerate(applicants, 1):
                print(f"  {i}. {applicant['name']} (Score: {applicant['viability_score']})")
            print()

def main():
    # Create scholarship manager
    manager = ScholarshipManager()
    
    # Sample applicants
    applicants_data = [
        {
            "id": "A001",
            "name": "Alice Johnson",
            "academic_score": 92.5,
            "extracurricular_score": 85.0,
            "application_details": {"essay_score": 8, "recommendation": "excellent"},
            "religious_group": "majority"
        },
        {
            "id": "A002",
            "name": "Bob Smith",
            "academic_score": 88.0,
            "extracurricular_score": 90.0,
            "application_details": {"essay_score": 7, "recommendation": "good"},
            "religious_group": "non_standard"
        },
        {
            "id": "A003",
            "name": "Carol Davis",
            "academic_score": 95.0,
            "extracurricular_score": 75.0,
            "application_details": {"essay_score": 9, "recommendation": "excellent"},
            "religious_group": "majority"
        },
        {
            "id": "A004",
            "name": "David Wilson",
            "academic_score": 85.0,
            "extracurricular_score": 95.0,
            "application_details": {"essay_score": 8, "recommendation": "good"},
            "religious_group": "non_standard"
        },
        {
            "id": "A005",
            "name": "Emma Brown",
            "academic_score": 90.0,
            "extracurricular_score": 80.0,
            "application_details": {"essay_score": 7, "recommendation": "good"},
            "religious_group": "majority"
        }
    ]
    
    # Add applicants to system
    for data in applicants_data:
        applicant = Applicant(
            id=data["id"],
            name=data["name"],
            academic_score=data["academic_score"],
            extracurricular_score=data["extracurricular_score"],
            application_details=data["application_details"],
            religious_group=data["religious_group"]
        )
        manager.add_applicant(applicant)
    
    # Display all applicants with scores
    print("APPLICANT VIABILITY SCORES:")
    print("-" * 50)
    ranked = manager.rank_applicants()
    for applicant in ranked:
        print(f"{applicant['name']}: {applicant['viability_score']:.2f}")
    print()
    
    # Allocate scholarships
    manager.allocate_scholarships(num_full=1, num_partial=2, num_book=2)
    
    # Print summary report
    manager.print_summary_report()

if __name__ == "__main__":
    main()