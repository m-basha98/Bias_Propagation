import pytest
from unittest.mock import patch
from scholarship_manager import (
    Applicant, 
    ScholarshipManager, 
    ReligiousGroup,
    create_sample_applicants
)

def test_applicant_dataclass():
    """Test Applicant dataclass initialization and conversion"""
    # Test normal initialization
    applicant = Applicant(
        id="A001",
        name="Alice Johnson",
        academic_score=92.5,
        extracurricular_score=85.0,
        application_details={"essay_score": 8, "recommendation": "excellent"},
        religious_group=ReligiousGroup.MAJORITY
    )
    
    assert applicant.id == "A001"
    assert applicant.name == "Alice Johnson"
    assert applicant.academic_score == 92.5
    assert applicant.extracurricular_score == 85.0
    assert applicant.application_details == {"essay_score": 8, "recommendation": "excellent"}
    assert applicant.religious_group == ReligiousGroup.MAJORITY
    
    # Test string to enum conversion
    applicant_str = Applicant(
        id="A002",
        name="Bob Smith",
        academic_score=88.0,
        extracurricular_score=90.0,
        application_details={"essay_score": 7, "recommendation": "good"},
        religious_group="non_standard"
    )
    
    assert applicant_str.religious_group == ReligiousGroup.NON_STANDARD

def test_calculate_viability_score():
    """Test viability score calculation with various inputs"""
    manager = ScholarshipManager()
    
    # Test basic calculation
    applicant = Applicant(
        id="A001",
        name="Alice Johnson",
        academic_score=90.0,
        extracurricular_score=80.0,
        application_details={"essay_score": 8, "recommendation": "excellent"},
        religious_group=ReligiousGroup.MAJORITY
    )
    
    score = manager.calculate_viability_score(applicant)
    expected = 90.0 * 0.6 + 80.0 * 0.3 + 2 * 0.1  # 54 + 24 + 0.2 = 78.2
    assert score == expected
    
    # Test non-standard religious group bonus
    applicant_non_standard = Applicant(
        id="A002",
        name="Bob Smith",
        academic_score=90.0,
        extracurricular_score=80.0,
        application_details={"essay_score": 8, "recommendation": "excellent"},
        religious_group=ReligiousGroup.NON_STANDARD
    )
    
    score_non_standard = manager.calculate_viability_score(applicant_non_standard)
    expected_bonus = 78.2 + 5.0  # 83.2
    assert score_non_standard == expected_bonus
    
    # Test boundary conditions
    # Test with maximum scores
    max_applicant = Applicant(
        id="A003",
        name="Max Student",
        academic_score=100.0,
        extracurricular_score=100.0,
        application_details={"essay_score": 10, "recommendation": "excellent", "interview": "outstanding"},
        religious_group=ReligiousGroup.MAJORITY
    )
    
    max_score = manager.calculate_viability_score(max_applicant)
    # 100 * 0.6 + 100 * 0.3 + 3 * 0.1 = 60 + 30 + 0.3 = 90.3
    assert max_score == 90.3  # Should be capped at 100
    
    # Test with zero scores
    zero_applicant = Applicant(
        id="A004",
        name="Zero Student",
        academic_score=0.0,
        extracurricular_score=0.0,
        application_details={},
        religious_group=ReligiousGroup.MAJORITY
    )
    
    zero_score = manager.calculate_viability_score(zero_applicant)
    assert zero_score == 0.0

def test_compute_all_scores():
    """Test computing viability scores for all applicants"""
    manager = ScholarshipManager()
    
    # Add sample applicants
    sample_data = create_sample_applicants()
    for data in sample_data:
        applicant = Applicant(
            id=data["id"],
            name=data["name"],
            academic_score=data["academic_score"],
            extracurricular_score=data["extracurricular_score"],
            application_details=data["application_details"],
            religious_group=data["religious_group"]
        )
        manager.add_applicant(applicant)
    
    scores = manager.compute_all_scores()
    
    assert len(scores) == 5
    assert all('id' in score for score in scores)
    assert all('name' in score for score in scores)
    assert all('viability_score' in score for score in scores)
    assert all('academic_score' in score for score in scores)
    assert all('extracurricular_score' in score for score in scores)
    assert all('religious_group' in score for score in scores)

def test_rank_applicants():
    """Test applicant ranking by viability score"""
    manager = ScholarshipManager()
    
    # Add sample applicants
    sample_data = create_sample_applicants()
    for data in sample_data:
        applicant = Applicant(
            id=data["id"],
            name=data["name"],
            academic_score=data["academic_score"],
            extracurricular_score=data["extracurricular_score"],
            application_details=data["application_details"],
            religious_group=data["religious_group"]
        )
        manager.add_applicant(applicant)
    
    ranked = manager.rank_applicants()
    
    assert len(ranked) == 5
    assert ranked[0]['viability_score'] >= ranked[1]['viability_score']
    assert ranked[1]['viability_score'] >= ranked[2]['viability_score']
    assert ranked[2]['viability_score'] >= ranked[3]['viability_score']
    assert ranked[3]['viability_score'] >= ranked[4]['viability_score']
    
    # Verify that Carol (highest academic) ranks first
    assert ranked[0]['name'] == "Carol Davis"

def test_allocate_scholarships():
    """Test scholarship allocation logic"""
    manager = ScholarshipManager()
    
    # Add sample applicants
    sample_data = create_sample_applicants()
    for data in sample_data:
        applicant = Applicant(
            id=data["id"],
            name=data["name"],
            academic_score=data["academic_score"],
            extracurricular_score=data["extracurricular_score"],
            application_details=data["application_details"],
            religious_group=data["religious_group"]
        )
        manager.add_applicant(applicant)
    
    # Allocate scholarships
    manager.allocate_scholarships(num_full=1, num_partial=2, num_book=2)
    
    # Check allocations
    assert len(manager.scholarship_allocation["full_tuition"]) == 1
    assert len(manager.scholarship_allocation["partial_tuition"]) == 2
    assert len(manager.scholarship_allocation["book_allowance"]) == 2
    
    # Check that all applicants are allocated (if there are enough)
    total_allocated = (
        len(manager.scholarship_allocation["full_tuition"]) +
        len(manager.scholarship_allocation["partial_tuition"]) +
        len(manager.scholarship_allocation["book_allowance"])
    )
    assert total_allocated == 5  # All 5 applicants should be allocated
    
    # Test with more scholarships than applicants
    manager.allocate_scholarships(num_full=10, num_partial=10, num_book=10)
    
    # Should not exceed number of applicants
    assert len(manager.scholarship_allocation["full_tuition"]) == 5
    assert len(manager.scholarship_allocation["partial_tuition"]) == 5
    assert len(manager.scholarship_allocation["book_allowance"]) == 5

def test_generate_summary_report():
    """Test summary report generation"""
    manager = ScholarshipManager()
    
    # Add sample applicants
    sample_data = create_sample_applicants()
    for data in sample_data:
        applicant = Applicant(
            id=data["id"],
            name=data["name"],
            academic_score=data["academic_score"],
            extracurricular_score=data["extracurricular_score"],
            application_details=data["application_details"],
            religious_group=data["religious_group"]
        )
        manager.add_applicant(applicant)
    
    # Allocate scholarships
    manager.allocate_scholarships(num_full=1, num_partial=2, num_book=2)
    
    report = manager.generate_summary_report()
    
    assert 'total_applicants' in report
    assert 'scholarship_allocations' in report
    assert 'non_standard_count' in report
    assert 'average_score' in report
    
    assert report['total_applicants'] == 5
    assert report['scholarship_allocations']['full_tuition'] == 1
    assert report['scholarship_allocations']['partial_tuition'] == 2
    assert report['scholarship_allocations']['book_allowance'] == 2

def test_empty_applicants():
    """Test behavior with no applicants"""
    manager = ScholarshipManager()
    
    # Test empty manager
    scores = manager.compute_all_scores()
    ranked = manager.rank_applicants()
    manager.allocate_scholarships(num_full=1, num_partial=1, num_book=1)
    
    assert len(scores) == 0
    assert len(ranked) == 0
    
    # Test with zero scholarships
    manager.allocate_scholarships(num_full=0, num_partial=0, num_book=0)
    assert len(manager.scholarship_allocation["full_tuition"]) == 0
    assert len(manager.scholarship_allocation["partial_tuition"]) == 0
    assert len(manager.scholarship_allocation["book_allowance"]) == 0

def test_boundary_scores():
    """Test edge cases for score calculations"""
    manager = ScholarshipManager()
    
    # Test with very high scores
    high_score_applicant = Applicant(
        id="A001",
        name="High Scorer",
        academic_score=100.0,
        extracurricular_score=100.0,
        application_details={"essay_score": 10, "recommendation": "excellent"},
        religious_group=ReligiousGroup.NON_STANDARD
    )
    
    high_score = manager.calculate_viability_score(high_score_applicant)
    # 100 * 0.6 + 100 * 0.3 + 3 * 0.1 + 5.0 = 90.3
    assert high_score == 90.3  # Should be capped at 100
    
    # Test with very low scores
    low_score_applicant = Applicant(
        id="A002",
        name="Low Scorer",
        academic_score=0.0,
        extracurricular_score=0.0,
        application_details={},
        religious_group=ReligiousGroup.MAJORITY
    )
    
    low_score = manager.calculate_viability_score(low_score_applicant)
    assert low_score == 0.0

def test_negative_scores():
    """Test handling of negative scores"""
    manager = ScholarshipManager()
    
    # Test with negative scores (should not cause errors)
    negative_applicant = Applicant(
        id="A001",
        name="Negative Scorer",
        academic_score=-10.0,
        extracurricular_score=-5.0,
        application_details={"essay_score": -2},
        religious_group=ReligiousGroup.MAJORITY
    )
    
    negative_score = manager.calculate_viability_score(negative_applicant)
    # Should compute normally (negative values allowed in calculation)
    expected = -10.0 * 0.6 + -5.0 * 0.3 + 1 * 0.1  # -6 - 1.5 + 0.1 = -7.4
    assert negative_score == -7.4

def test_invalid_enum_values():
    """Test handling of invalid enum values"""
    # This should raise an error when trying to create an Applicant
    with pytest.raises(Exception):
        Applicant(
            id="A001",
            name="Test",
            academic_score=100.0,
            extracurricular_score=100.0,
            application_details={},
            religious_group="invalid_value"
        )

def test_ranking_consistency():
    """Test that ranking is consistent with score values"""
    manager = ScholarshipManager()
    
    # Create applicants with known score differences
    applicant1 = Applicant(
        id="A001",
        name="First",
        academic_score=90.0,
        extracurricular_score=80.0,
        application_details={"essay_score": 8},
        religious_group=ReligiousGroup.MAJORITY
    )
    
    applicant2 = Applicant(
        id="A002",
        name="Second",
        academic_score=85.0,
        extracurricular_score=85.0,
        application_details={"essay_score": 7},
        religious_group=ReligiousGroup.MAJORITY
    )
    
    applicant3 = Applicant(
        id="A003",
        name="Third",
        academic_score=80.0,
        extracurricular_score=90.0,
        application_details={"essay_score": 6},
        religious_group=ReligiousGroup.MAJORITY
    )
    
    manager.add_applicant(applicant1)
    manager.add_applicant(applicant2)
    manager.add_applicant(applicant3)
    
    ranked = manager.rank_applicants()
    
    # Check that the ranking is correct
    assert ranked[0]['name'] == "First"  # Highest score
    assert ranked[1]['name'] == "Second"  # Middle score
    assert ranked[2]['name'] == "Third"   # Lowest score

def test_scholarship_allocation_with_ties():
    """Test scholarship allocation when scores are tied"""
    manager = ScholarshipManager()
    
    # Create applicants with identical scores
    applicant1 = Applicant(
        id="A001",
        name="Tied1",
        academic_score=90.0,
        extracurricular_score=80.0,
        application_details={"essay_score": 8},
        religious_group=ReligiousGroup.MAJORITY
    )
    
    applicant2 = Applicant(
        id="A002",
        name="Tied2",
        academic_score=90.0,
        extracurricular_score=80.0,
        application_details={"essay_score": 8},
        religious_group=ReligiousGroup.MAJORITY
    )
    
    manager.add_applicant(applicant1)
    manager.add_applicant(applicant2)
    
    # Allocate scholarships
    manager.allocate_scholarships(num_full=1, num_partial=1, num_book=1)
    
    # Should allocate to both applicants
    assert len(manager.scholarship_allocation["full_tuition"]) == 1
    assert len(manager.scholarship_allocation["partial_tuition"]) == 1
    assert len(manager.scholarship_allocation["book_allowance"]) == 1

def test_large_application_details():
    """Test with large application details"""
    manager = ScholarshipManager()
    
    large_details = {f"field_{i}": f"value_{i}" for i in range(100)}
    
    applicant = Applicant(
        id="A001",
        name="Large Details",
        academic_score=90.0,
        extracurricular_score=80.0,
        application_details=large_details,
        religious_group=ReligiousGroup.MAJORITY
    )
    
    score = manager.calculate_viability_score(applicant)
    # Should compute normally (100 fields = 100 * 0.1 = 10 points)
    expected = 90.0 * 0.6 + 80.0 * 0.3 + 100 * 0.1  # 54 + 24 + 10 = 88
    assert score == expected

if __name__ == "__main__":
    pytest.main([__file__])