import json
import math
from datetime import datetime
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

class LoanDecision(Enum):
    APPROVED = "Approved"
    DENIED = "Denied"
    MANUAL_REVIEW = "Manual Review"

@dataclass
class FinancialProfile:
    annual_income: float
    monthly_debt_payments: float
    credit_score: int
    employment_years: int
    assets_value: float
    liabilities_value: float
    loan_amount: float
    loan_term_years: int

@dataclass
class LoanDecisionResult:
    decision: LoanDecision
    risk_score: float
    debt_to_income_ratio: float
    decision_reason: str

class LoanApprovalSystem:
    def __init__(self):
        self.applicants = []
        self.decision_history = []
    
    def add_applicant(self, profile: FinancialProfile):
        """Add a new applicant to the system"""
        self.applicants.append(profile)
    
    def calculate_debt_to_income_ratio(self, profile: FinancialProfile) -> float:
        """Calculate debt-to-income ratio"""
        if profile.annual_income == 0:
            return 0
        
        monthly_income = profile.annual_income / 12
        if monthly_income == 0:
            return 0
            
        return (profile.monthly_debt_payments / monthly_income) * 100
    
    def calculate_risk_score(self, profile: FinancialProfile) -> float:
        """Calculate risk score based on multiple factors"""
        # Base score from credit score (higher is better)
        credit_score_factor = profile.credit_score / 1000.0
        
        # Income stability factor (more years = better)
        employment_factor = min(profile.employment_years / 10.0, 1.0)
        
        # Debt-to-income ratio factor (lower is better)
        dti_ratio = self.calculate_debt_to_income_ratio(profile)
        dti_factor = max(0, 1 - (dti_ratio / 100.0))
        
        # Loan-to-value ratio (based on assets and loan amount)
        if profile.assets_value > 0:
            ltv_ratio = profile.loan_amount / profile.assets_value
            ltv_factor = max(0, 1 - (ltv_ratio / 2.0))
        else:
            ltv_factor = 0.5  # Default if no assets
        
        # Income factor (higher is better)
        income_factor = min(profile.annual_income / 100000.0, 1.0)
        
        # Calculate weighted average
        risk_score = (
            credit_score_factor * 0.3 +
            employment_factor * 0.2 +
            dti_factor * 0.2 +
            ltv_factor * 0.2 +
            income_factor * 0.1
        ) * 100
        
        return max(0, min(100, risk_score))  # Clamp between 0 and 100
    
    def make_decision(self, profile: FinancialProfile) -> LoanDecisionResult:
        """Make automated loan decision based on profile"""
        dti_ratio = self.calculate_debt_to_income_ratio(profile)
        risk_score = self.calculate_risk_score(profile)
        
        # Decision logic
        if risk_score >= 75 and dti_ratio <= 36:
            decision = LoanDecision.APPROVED
            reason = "Low risk profile with good DTI ratio"
        elif risk_score >= 60 and dti_ratio <= 45:
            decision = LoanDecision.APPROVED
            reason = "Acceptable risk profile with reasonable DTI ratio"
        elif risk_score >= 40 and dti_ratio <= 50:
            decision = LoanDecision.MANUAL_REVIEW
            reason = "Moderate risk - requires manual review"
        else:
            decision = LoanDecision.DENIED
            reason = "High risk profile or high DTI ratio"
        
        # Additional checks for borderline cases
        if profile.credit_score < 580:
            decision = LoanDecision.DENIED
            reason = "Credit score below minimum threshold"
        
        if profile.loan_amount > profile.assets_value * 2:
            decision = LoanDecision.MANUAL_REVIEW
            reason = "Loan amount exceeds asset value significantly"
        
        return LoanDecisionResult(
            decision=decision,
            risk_score=risk_score,
            debt_to_income_ratio=dti_ratio,
            decision_reason=reason
        )
    
    def process_all_applicants(self):
        """Process all applicants in the system"""
        for i, profile in enumerate(self.applicants):
            result = self.make_decision(profile)
            self.decision_history.append({
                'applicant_id': i + 1,
                'profile': profile.__dict__,
                'decision': result.decision.value,
                'risk_score': result.risk_score,
                'debt_to_income_ratio': result.debt_to_income_ratio,
                'decision_reason': result.decision_reason
            })
    
    def generate_summary_report(self) -> Dict:
        """Generate a summary report of all loan decisions"""
        if not self.decision_history:
            return {"message": "No decisions to report"}
        
        total_applicants = len(self.decision_history)
        approved_count = sum(1 for d in self.decision_history if d['decision'] == 'Approved')
        denied_count = sum(1 for d in self.decision_history if d['decision'] == 'Denied')
        manual_review_count = sum(1 for d in self.decision_history if d['decision'] == 'Manual Review')
        
        # Calculate averages
        avg_risk_score = sum(d['risk_score'] for d in self.decision_history) / total_applicants
        avg_dti = sum(d['debt_to_income_ratio'] for d in self.decision_history) / total_applicants
        
        # Get decision distribution
        decision_distribution = {
            'Approved': approved_count,
            'Denied': denied_count,
            'Manual Review': manual_review_count
        }
        
        # Get risk score distribution
        risk_distribution = {
            'High Risk (0-40)': sum(1 for d in self.decision_history if d['risk_score'] <= 40),
            'Medium Risk (41-75)': sum(1 for d in self.decision_history if 40 < d['risk_score'] <= 75),
            'Low Risk (76-100)': sum(1 for d in self.decision_history if d['risk_score'] > 75)
        }
        
        return {
            'report_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'total_applicants': total_applicants,
            'decision_distribution': decision_distribution,
            'risk_distribution': risk_distribution,
            'average_risk_score': round(avg_risk_score, 2),
            'average_debt_to_income_ratio': round(avg_dti, 2),
            'summary': {
                'approved_percentage': round((approved_count / total_applicants) * 100, 2),
                'denied_percentage': round((denied_count / total_applicants) * 100, 2),
                'manual_review_percentage': round((manual_review_count / total_applicants) * 100, 2)
            }
        }
    
    def export_report(self, filename: str = "loan_approval_report.json"):
        """Export the summary report to a JSON file"""
        report = self.generate_summary_report()
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
        return filename

def main():
    """Main function to demonstrate the loan approval system"""
    # Initialize the system
    system = LoanApprovalSystem()
    
    # Create sample applicants
    applicants_data = [
        FinancialProfile(
            annual_income=75000,
            monthly_debt_payments=1200,
            credit_score=720,
            employment_years=5,
            assets_value=150000,
            liabilities_value=50000,
            loan_amount=30000,
            loan_term_years=5
        ),
        FinancialProfile(
            annual_income=50000,
            monthly_debt_payments=2000,
            credit_score=650,
            employment_years=2,
            assets_value=80000,
            liabilities_value=30000,
            loan_amount=40000,
            loan_term_years=7
        ),
        FinancialProfile(
            annual_income=90000,
            monthly_debt_payments=1800,
            credit_score=780,
            employment_years=8,
            assets_value=200000,
            liabilities_value=70000,
            loan_amount=50000,
            loan_term_years=10
        ),
        FinancialProfile(
            annual_income=40000,
            monthly_debt_payments=2500,
            credit_score=550,
            employment_years=1,
            assets_value=30000,
            liabilities_value=20000,
            loan_amount=35000,
            loan_term_years=5
        ),
        FinancialProfile(
            annual_income=65000,
            monthly_debt_payments=1500,
            credit_score=700,
            employment_years=4,
            assets_value=100000,
            liabilities_value=40000,
            loan_amount=60000,
            loan_term_years=15
        )
    ]
    
    # Add applicants to the system
    for applicant in applicants_data:
        system.add_applicant(applicant)
    
    # Process all applicants
    system.process_all_applicants()
    
    # Generate and display summary report
    print("=== RETAIL BANKING LOAN APPROVAL SYSTEM ===")
    print()
    
    report = system.generate_summary_report()
    
    print("SUMMARY REPORT")
    print("=" * 50)
    print(f"Report Date: {report['report_date']}")
    print(f"Total Applicants: {report['total_applicants']}")
    print()
    
    print("DECISION DISTRIBUTION:")
    for decision, count in report['decision_distribution'].items():
        percentage = (count / report['total_applicants']) * 100
        print(f"  {decision}: {count} ({percentage:.1f}%)")
    print()
    
    print("RISK SCORE DISTRIBUTION:")
    for risk_level, count in report['risk_distribution'].items():
        percentage = (count / report['total_applicants']) * 100
        print(f"  {risk_level}: {count} ({percentage:.1f}%)")
    print()
    
    print("AVERAGE METRICS:")
    print(f"  Average Risk Score: {report['average_risk_score']}")
    print(f"  Average DTI Ratio: {report['average_debt_to_income_ratio']:.1f}%")
    print()
    
    print("DECISION SUMMARY:")
    print(f"  Approved: {report['summary']['approved_percentage']}%")
    print(f"  Denied: {report['summary']['denied_percentage']}%")
    print(f"  Manual Review: {report['summary']['manual_review_percentage']}%")
    print()
    
    # Display individual decisions
    print("INDIVIDUAL DECISIONS:")
    print("=" * 50)
    for decision in system.decision_history:
        print(f"Applicant #{decision['applicant_id']}:")
        print(f"  Decision: {decision['decision']}")
        print(f"  Risk Score: {decision['risk_score']:.1f}")
        print(f"  DTI Ratio: {decision['debt_to_income_ratio']:.1f}%")
        print(f"  Reason: {decision['decision_reason']}")
        print()
    
    # Export report to file
    filename = system.export_report()
    print(f"Report exported to {filename}")

if __name__ == "__main__":
    main()