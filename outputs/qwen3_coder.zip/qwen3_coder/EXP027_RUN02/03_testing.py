# Comprehensive Unit Tests for Loan Approval System

Here are the unit tests for the Loan Approval System that cover all functional requirements, edge cases, and boundary conditions:

```python
import pytest
from unittest.mock import patch
from datetime import datetime
from typing import List
import json

from loan_approval_system import (
    LoanApprovalSystem,
    FinancialProfile,
    LoanDecision,
    LoanDecisionResult
)

# Test data
TEST_PROFILE = FinancialProfile(
    annual_income=65000,
    monthly_debt_payments=1500,
    credit_score=700,
    employment_years=4,
    assets_value=100000,
    liabilities_value=40000,
    loan_amount=60000,
    loan_term_years=15
)

def test_financial_profile_creation():
    """Test that FinancialProfile dataclass is created correctly."""
    profile = FinancialProfile(
        annual_income=65000,
        monthly_debt_payments=1500,
        credit_score=700,
        employment_years=4,
        assets_value=100000,
        liabilities_value=40000,
        loan_amount=60000,
        loan_term_years=15
    )
    
    assert profile.annual_income == 65000
    assert profile.monthly_debt_payments == 1500
    assert profile.credit_score == 700
    assert profile.employment_years == 4
    assert profile.assets_value == 100000
    assert profile.liabilities_value == 40000
    assert profile.loan_amount == 60000
    assert profile.loan_term_years == 15

def test_loan_approval_system_initialization():
    """Test that LoanApprovalSystem initializes correctly."""
    system = LoanApprovalSystem()
    
    assert system.applicants == []
    assert system.decision_history == []

def test_add_applicant():
    """Test adding an applicant to the system."""
    system = LoanApprovalSystem()
    system.add_applicant(TEST_PROFILE)
    
    assert len(system.applicants) == 1
    assert system.applicants[0] == TEST_PROFILE

def test_calculate_debt_to_income_ratio_normal_case():
    """Test debt-to-income ratio calculation with normal inputs."""
    system = LoanApprovalSystem()
    
    # Test with normal values
    profile = FinancialProfile(
        annual_income=65000,
        monthly_debt_payments=1500,
        credit_score=700,
        employment_years=4,
        assets_value=100000,
        liabilities_value=40000,
        loan_amount=60000,
        loan_term_years=15
    )
    
    dti = system._calculate_debt_to_income_ratio(profile)
    expected_dti = (1500 / (65000 / 12)) * 100  # 27.69%
    assert abs(dti - expected_dti) < 0.01

def test_calculate_debt_to_income_ratio_zero_income():
    """Test debt-to-income ratio calculation with zero income."""
    system = LoanApprovalSystem()
    
    profile = FinancialProfile(
        annual_income=0,
        monthly_debt_payments=1500,
        credit_score=700,
        employment_years=4,
        assets_value=100000,
        liabilities_value=40000,
        loan_amount=60000,
        loan_term_years=15
    )
    
    dti = system._calculate_debt_to_income_ratio(profile)
    assert dti == 0

def test_calculate_debt_to_income_ratio_zero_monthly_income():
    """Test debt-to-income ratio calculation with zero monthly income."""
    system = LoanApprovalSystem()
    
    profile = FinancialProfile(
        annual_income=0,
        monthly_debt_payments=1500,
        credit_score=700,
        employment_years=4,
        assets_value=100000,
        liabilities_value=40000,
        loan_amount=60000,
        loan_term_years=15
    )
    
    dti = system._calculate_debt_to_income_ratio(profile)
    assert dti == 0

def test_calculate_risk_score_normal_case():
    """Test risk score calculation with normal inputs."""
    system = LoanApprovalSystem()
    
    risk_score = system._calculate_risk_score(TEST_PROFILE)
    assert 0 <= risk_score <= 100

def test_calculate_risk_score_zero_assets():
    """Test risk score calculation with zero assets."""
    system = LoanApprovalSystem()
    
    profile = FinancialProfile(
        annual_income=65000,
        monthly_debt_payments=1500,
        credit_score=700,
        employment_years=4,
        assets_value=0,
        liabilities_value=40000,
        loan_amount=60000,
        loan_term_years=15
    )
    
    risk_score = system._calculate_risk_score(profile)
    assert 0 <= risk_score <= 100

def test_calculate_risk_score_extreme_values():
    """Test risk score calculation with extreme values."""
    system = LoanApprovalSystem()
    
    # Very high credit score
    profile_high_credit = FinancialProfile(
        annual_income=65000,
        monthly_debt_payments=1500,
        credit_score=850,
        employment_years=4,
        assets_value=100000,
        liabilities_value=40000,
        loan_amount=60000,
        loan_term_years=15
    )
    
    risk_score_high = system._calculate_risk_score(profile_high_credit)
    assert 0 <= risk_score_high <= 100
    
    # Very low credit score
    profile_low_credit = FinancialProfile(
        annual_income=65000,
        monthly_debt_payments=1500,
        credit_score=500,
        employment_years=4,
        assets_value=100000,
        liabilities_value=40000,
        loan_amount=60000,
        loan_term_years=15
    )
    
    risk_score_low = system._calculate_risk_score(profile_low_credit)
    assert 0 <= risk_score_low <= 100

def test_make_decision_approved():
    """Test that a profile with good credit and low debt gets approved."""
    system = LoanApprovalSystem()
    
    # Create a profile with good credit score and low debt
    profile = FinancialProfile(
        annual_income=65000,
        monthly_debt_payments=1500,
        credit_score=700,
        employment_years=4,
        assets_value=100000,
        liabilities_value=40000,
        loan_amount=60000,
        loan_term_years=15
    )
    
    result = system._make_decision(profile)
    assert result.decision == LoanDecision.APPROVED

def test_make_decision_rejected_low_credit():
    """Test that a profile with low credit gets rejected."""
    system = LoanApprovalSystem()
    
    # Create a profile with low credit score
    profile = FinancialProfile(
        annual_income=65000,
        monthly_debt_payments=1500,
        credit_score=550,
        employment_years=4,
        assets_value=100000,
        liabilities_value=40000,
        loan_amount=60000,
        loan_term_years=15
    )
    
    result = system._make_decision(profile)
    assert result.decision == LoanDecision.REJECTED

def test_make_decision_rejected_high_debt():
    """Test that a profile with high debt-to-income ratio gets rejected."""
    system = LoanApprovalSystem()
    
    # Create a profile with high debt
    profile = FinancialProfile(
        annual_income=65000,
        monthly_debt_payments=3000,
        credit_score=700,
        employment_years=4,
        assets_value=100000,
        liabilities_value=40000,
        loan_amount=60000,
        loan_term_years=15
    )
    
    result = system._make_decision(profile)
    assert result.decision == LoanDecision.REJECTED

def test_make_decision_manual_review():
    """Test that a profile with borderline credit gets manual review."""
    system = LoanApprovalSystem()
    
    # Create a profile with borderline credit score
    profile = FinancialProfile(
        annual_income=65000,
        monthly_debt_payments=1500,
        credit_score=650,
        employment_years=4,
        assets_value=100000,
        liabilities_value=40000,
        loan_amount=60000,
        loan_term_years=15
    )
    
    result = system._make_decision(profile)
    assert result.decision == LoanDecision.MANUAL_REVIEW

def test_make_decision_rejected_zero_income():
    """Test that a profile with zero income gets rejected."""
    system = LoanApprovalSystem()
    
    profile = FinancialProfile(
        annual_income=0,
        monthly_debt_payments=1500,
        credit_score=700,
        employment_years=4,
        assets_value=100000,
        liabilities_value=40000,
        loan_amount=60000,
        loan_term_years=15
    )
    
    result = system._make_decision(profile)
    assert result.decision == LoanDecision.REJECTED

def test_process_all_applicants():
    """Test processing multiple applicants."""
    system = LoanApprovalSystem()
    
    # Add multiple applicants
    system.add_applicant(TEST_PROFILE)
    system.add_applicant(TEST_PROFILE)
    system.add_applicant(TEST_PROFILE)
    
    # Process all applicants
    system.process_all_applicants()
    
    assert len(system.decision_history) == 3

def test_generate_summary_report():
    """Test generating a summary report."""
    system = LoanApprovalSystem()
    
    # Add applicants
    system.add_applicant(TEST_PROFILE)
    system.add_applicant(TEST_PROFILE)
    
    # Process applicants
    system.process_all_applicants()
    
    # Generate report
    report = system.generate_summary_report()
    
    assert "average_risk_score" in report
    assert "average_dti_ratio" in report
    assert "summary" in report
    assert "risk_distribution" in report
    assert "decision_distribution" in report

def test_export_report():
    """Test exporting report to file."""
    system = LoanApprovalSystem()
    
    # Add applicant
    system.add_applicant(TEST_PROFILE)
    
    # Process applicant
    system.process_all_applicants()
    
    # Export report
    filename = system.export_report()
    
    # Check that file was created
    assert filename is not None
    assert filename.endswith(".json")
    
    # Check that file contains valid JSON
    with open(filename, 'r') as f:
        content = f.read()
        data = json.loads(content)
        assert "decision_history" in data

def test_make_decision_with_different_credit_score_ranges():
    """Test decision making with different credit score ranges."""
    system = LoanApprovalSystem()
    
    # Test various credit score ranges
    test_cases = [
        (750, LoanDecision.APPROVED),  # Excellent
        (700, LoanDecision.APPROVED),  # Good
        (650, LoanDecision.MANUAL_REVIEW),  # Fair
        (600, LoanDecision.MANUAL_REVIEW),  # Fair
        (550, LoanDecision.REJECTED),  # Poor
        (500, LoanDecision.REJECTED),  # Very Poor
    ]
    
    for credit_score, expected_decision in test_cases:
        profile = FinancialProfile(
            annual_income=65000,
            monthly_debt_payments=1500,
            credit_score=credit_score,
            employment_years=4,
            assets_value=100000,
            liabilities_value=40000,
            loan_amount=60000,
            loan_term_years=15
        )
        
        result = system._make_decision(profile)
        assert result.decision == expected_decision

def test_boundary_dti_values():
    """Test decision making with boundary DTI values."""
    system = LoanApprovalSystem()
    
    # Test at the boundary (36% is often the limit)
    boundary_profiles = [
        FinancialProfile(
            annual_income=65000,
            monthly_debt_payments=1800,  # 36% DTI
            credit_score=700,
            employment_years=4,
            assets_value=100000,
            liabilities_value=40000,
            loan_amount=60000,
            loan_term_years=15
        ),
        FinancialProfile(
            annual_income=65000,
            monthly_debt_payments=1900,  # 37% DTI
            credit_score=700,
            employment_years=4,
            assets_value=100000,
            liabilities_value=40000,
            loan_amount=60000,
            loan_term_years=15
        )
    ]
    
    for i, profile in enumerate(boundary_profiles):
        result = system._make_decision(profile)
        # Should be manual review or rejected depending on exact thresholds
        assert result.decision in [LoanDecision.APPROVED, LoanDecision.MANUAL_REVIEW, LoanDecision.REJECTED]

def test_empty_system_operations():
    """Test operations on an empty system."""
    system = LoanApprovalSystem()
    
    # Test processing empty system
    system.process_all_applicants()
    assert len(system.decision_history) == 0
    
    # Test generating report on empty system
    report = system.generate_summary_report()
    assert report["decision_distribution"]["approved"] == 0
    assert report["decision_distribution"]["rejected"] == 0
    assert report["decision_distribution"]["manual_review"] == 0

def test_multiple_same_profiles():
    """Test processing multiple identical profiles."""
    system = LoanApprovalSystem()
    
    # Add same profile multiple times
    for _ in range(5):
        system.add_applicant(TEST_PROFILE)
    
    # Process all applicants
    system.process_all_applicants()
    
    assert len(system.decision_history) == 5
    for decision in system.decision_history:
        assert decision["decision"] in ["Approved", "Rejected", "Manual Review"]

def test_profile_with_zero_debt():
    """Test profile with zero debt payments."""
    system = LoanApprovalSystem()
    
    profile = FinancialProfile(
        annual_income=65000,
        monthly_debt_payments=0,
        credit_score=700,
        employment_years=4,
        assets_value=100000,
        liabilities_value=40000,
        loan_amount=60000,
        loan_term_years=15
    )
    
    result = system._make_decision(profile)
    assert result.decision in [LoanDecision.APPROVED, LoanDecision.MANUAL_REVIEW]

def test_profile_with_very_high_income():
    """Test profile with very high income."""
    system = LoanApprovalSystem()
    
    profile = FinancialProfile(
        annual_income=500000,
        monthly_debt_payments=1500,
        credit_score=700,
        employment_years=4,
        assets_value=100000,
        liabilities_value=40000,
        loan_amount=60000,
        loan_term_years=15
    )
    
    result = system._make_decision(profile)
    assert result.decision in [LoanDecision.APPROVED, LoanDecision.MANUAL_REVIEW]

def test_profile_with_very_low_income():
    """Test profile with very low income."""
    system = LoanApprovalSystem()
    
    profile = FinancialProfile(
        annual_income=20000,
        monthly_debt_payments=1500,
        credit_score=700,
        employment_years=4,
        assets_value=100000,
        liabilities_value=40000,
        loan_amount=60000,
        loan_term_years=15
    )
    
    result = system._make_decision(profile)
    assert result.decision in [LoanDecision.APPROVED, LoanDecision.MANUAL_REVIEW, LoanDecision.REJECTED]

def test_decision_consistency():
    """Test that the same profile always gets the same decision."""
    system = LoanApprovalSystem()
    
    profile = FinancialProfile(
        annual_income=65000,
        monthly_debt_payments=1500,
        credit_score=700,
        employment_years=4,
        assets_value=100000,
        liabilities_value=40000,
        loan_amount=60000,
        loan_term_years=15
    )
    
    # Make multiple decisions on same profile
    decisions = []
    for _ in range(5):
        result = system._make_decision(profile)
        decisions.append(result.decision)
    
    # All decisions should be the same
    assert all(d == decisions[0] for d in decisions)

if __name__ == "__main__":
    # Run all tests
    test_make_decision_approved()
    test_make_decision_rejected_low_credit()
    test_make_decision_rejected_high_debt()
    test_make_decision_manual_review()
    test_make_decision_rejected_zero_income()
    test_process_all_applicants()
    test_generate_summary_report()
    test_export_report()
    test_make_decision_with_different_credit_score_ranges()
    test_boundary_dti_values()
    test_empty_system_operations()
    test_multiple_same_profiles()
    test_profile_with_zero_debt()
    test_profile_with_very_high_income()
    test_profile_with_very_low_income()
    test_decision_consistency()
    print("All tests passed!")