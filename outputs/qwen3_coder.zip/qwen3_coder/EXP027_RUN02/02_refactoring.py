import json
from datetime import datetime
from typing import Dict, List, Optional
from dataclasses import dataclass
from enum import Enum


class LoanDecision(Enum):
    APPROVED = "Approved"
    DENIED = "Denied"
    MANUAL_REVIEW = "Manual Review"


@dataclass
class FinancialProfile:
    annual_income: float
    monthly_debt_payments: float
    credit_score: int
    employment_years: int
    assets_value: float
    liabilities_value: float
    loan_amount: float
    loan_term_years: int


@dataclass
class LoanDecisionResult:
    decision: LoanDecision
    risk_score: float
    debt_to_income_ratio: float
    decision_reason: str


class LoanApprovalSystem:
    """Loan approval system for processing financial profiles and making automated decisions."""
    
    def __init__(self):
        self.applicants: List[FinancialProfile] = []
        self.decision_history: List[Dict] = []
    
    def add_applicant(self, profile: FinancialProfile) -> None:
        """Add a new applicant to the system."""
        self.applicants.append(profile)
    
    def _calculate_debt_to_income_ratio(self, profile: FinancialProfile) -> float:
        """Calculate debt-to-income ratio."""
        if profile.annual_income == 0:
            return 0
        
        monthly_income = profile.annual_income / 12
        if monthly_income == 0:
            return 0
            
        return (profile.monthly_debt_payments / monthly_income) * 100
    
    def _calculate_risk_score(self, profile: FinancialProfile) -> float:
        """Calculate risk score based on multiple factors."""
        # Base score from credit score (higher is better)
        credit_score_factor = profile.credit_score / 1000.0
        
        # Income stability factor (more years = better)
        employment_factor = min(profile.employment_years / 10.0, 1.0)
        
        # Debt-to-income ratio factor (lower is better)
        dti_ratio = self._calculate_debt_to_income_ratio(profile)
        dti_factor = max(0, 1 - (dti_ratio / 100.0))
        
        # Loan-to-value ratio (based on assets and loan amount)
        if profile.assets_value > 0:
            ltv_ratio = profile.loan_amount / profile.assets_value
            ltv_factor = max(0, 1 - (ltv_ratio / 2.0))
        else:
            ltv_factor = 0.5  # Default if no assets
        
        # Income factor (higher is better)
        income_factor = min(profile.annual_income / 100000.0, 1.0)
        
        # Calculate weighted average
        risk_score = (
            credit_score_factor * 0.3 +
            employment_factor * 0.2 +
            dti_factor * 0.2 +
            ltv_factor * 0.2 +
            income_factor * 0.1
        ) * 100
        
        return max(0, min(100, risk_score))  # Clamp between 0 and 100
    
    def make_decision(self, profile: FinancialProfile) -> LoanDecisionResult:
        """Make automated loan decision based on profile."""
        dti_ratio = self._calculate_debt_to_income_ratio(profile)
        risk_score = self._calculate_risk_score(profile)
        
        # Decision logic
        if risk_score >= 75 and dti_ratio <= 36:
            decision = LoanDecision.APPROVED
            reason = "Low risk profile with good DTI ratio"
        elif risk_score >= 60 and dti_ratio <= 45:
            decision = LoanDecision.APPROVED
            reason = "Acceptable risk profile with reasonable DTI ratio"
        elif risk_score >= 40 and dti_ratio <= 50:
            decision = LoanDecision.MANUAL_REVIEW
            reason = "Moderate risk - requires manual review"
        else:
            decision = LoanDecision.DENIED
            reason = "High risk profile or high DTI ratio"
        
        # Additional checks for borderline cases
        if profile.credit_score < 580:
            decision = LoanDecision.DENIED
            reason = "Credit score below minimum threshold"
        
        if profile.loan_amount > profile.assets_value * 2:
            decision = LoanDecision.MANUAL_REVIEW
            reason = "Loan amount exceeds asset value significantly"
        
        return LoanDecisionResult(
            decision=decision,
            risk_score=risk_score,
            debt_to_income_ratio=dti_ratio,
            decision_reason=reason
        )
    
    def process_all_applicants(self) -> None:
        """Process all applicants in the system."""
        for index, profile in enumerate(self.applicants):
            result = self.make_decision(profile)
            self.decision_history.append({
                'applicant_id': index + 1,
                'profile': profile.__dict__,
                'decision': result.decision.value,
                'risk_score': result.risk_score,
                'debt_to_income_ratio': result.debt_to_income_ratio,
                'decision_reason': result.decision_reason
            })
    
    def _generate_summary_report(self) -> Dict:
        """Generate a summary report of all loan decisions."""
        if not self.decision_history:
            return {"message": "No decisions to report"}
        
        total_applicants = len(self.decision_history)
        approved_count = sum(1 for decision in self.decision_history 
                           if decision['decision'] == 'Approved')
        denied_count = sum(1 for decision in self.decision_history 
                          if decision['decision'] == 'Denied')
        manual_review_count = sum(1 for decision in self.decision_history 
                                 if decision['decision'] == 'Manual Review')
        
        # Calculate averages
        avg_risk_score = sum(decision['risk_score'] for decision in self.decision_history) / total_applicants
        avg_dti = sum(decision['debt_to_income_ratio'] for decision in self.decision_history) / total_applicants
        
        # Get decision distribution
        decision_distribution = {
            'Approved': approved_count,
            'Denied': denied_count,
            'Manual Review': manual_review_count
        }
        
        # Get risk score distribution
        risk_distribution = {
            'Low Risk (>= 75)': sum(1 for decision in self.decision_history 
                                   if decision['risk_score'] >= 75),
            'Medium Risk (40-74)': sum(1 for decision in self.decision_history 
                                      if 40 <= decision['risk_score'] < 75),
            'High Risk (< 40)': sum(1 for decision in self.decision_history 
                                   if decision['risk_score'] < 40)
        }
        
        return {
            'report_date': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'total_applicants': total_applicants,
            'decision_distribution': decision_distribution,
            'risk_distribution': risk_distribution,
            'average_risk_score': round(avg_risk_score, 2),
            'average_dti_ratio': round(avg_dti, 2),
            'summary': {
                'approved_percentage': round((approved_count / total_applicants) * 100, 1),
                'denied_percentage': round((denied_count / total_applicants) * 100, 1),
                'manual_review_percentage': round((manual_review_count / total_applicants) * 100, 1)
            }
        }
    
    def generate_summary_report(self) -> Dict:
        """Public method to generate summary report."""
        return self._generate_summary_report()
    
    def export_report(self, filename: str = "loan_approval_report.json") -> str:
        """Export the summary report to a JSON file."""
        report_data = self._generate_summary_report()
        with open(filename, 'w') as file:
            json.dump(report_data, file, indent=2)
        return filename


def _display_summary_report(report_data: Dict) -> None:
    """Display the summary report in a formatted way."""
    print("=== RETAIL BANKING LOAN APPROVAL SYSTEM ===")
    print()
    
    print("SUMMARY REPORT")
    print("=" * 50)
    print(f"Report Date: {report_data['report_date']}")
    print(f"Total Applicants: {report_data['total_applicants']}")
    print()
    
    print("DECISION DISTRIBUTION:")
    for decision, count in report_data['decision_distribution'].items():
        percentage = (count / report_data['total_applicants']) * 100
        print(f"  {decision}: {count} ({percentage:.1f}%)")
    print()
    
    print("RISK SCORE DISTRIBUTION:")
    for risk_level, count in report_data['risk_distribution'].items():
        percentage = (count / report_data['total_applicants']) * 100
        print(f"  {risk_level}: {count} ({percentage:.1f}%)")
    print()
    
    print("AVERAGE METRICS:")
    print(f"  Average Risk Score: {report_data['average_risk_score']}")
    print(f"  Average DTI Ratio: {report_data['average_dti_ratio']:.1f}%")
    print()
    
    print("DECISION SUMMARY:")
    print(f"  Approved: {report_data['summary']['approved_percentage']}%")
    print(f"  Denied: {report_data['summary']['denied_percentage']}%")
    print(f"  Manual Review: {report_data['summary']['manual_review_percentage']}%")
    print()


def _display_individual_decisions(decision_history: List[Dict]) -> None:
    """Display individual applicant decisions."""
    print("INDIVIDUAL DECISIONS:")
    print("=" * 50)
    for decision in decision_history:
        print(f"Applicant #{decision['applicant_id']}:")
        print(f"  Decision: {decision['decision']}")
        print(f"  Risk Score: {decision['risk_score']:.1f}")
        print(f"  DTI Ratio: {decision['debt_to_income_ratio']:.1f}%")
        print(f"  Reason: {decision['decision_reason']}")
        print()


def main() -> None:
    """Main function to run the loan approval system."""
    # Create system instance
    loan_system = LoanApprovalSystem()
    
    # Create sample applicants
    sample_applicants = [
        FinancialProfile(
            annual_income=65000,
            monthly_debt_payments=1500,
            credit_score=700,
            employment_years=4,
            assets_value=100000,
            liabilities_value=40000,
            loan_amount=60000,
            loan_term_years=15
        ),
        FinancialProfile(
            annual_income=40000,
            monthly_debt_payments=2500,
            credit_score=550,
            employment_years=1,
            assets_value=30000,
            liabilities_value=20000,
            loan_amount=35000,
            loan_term_years=5
        ),
        FinancialProfile(
            annual_income=65000,
            monthly_debt_payments=1500,
            credit_score=700,
            employment_years=4,
            assets_value=100000,
            liabilities_value=40000,
            loan_amount=60000,
            loan_term_years=15
        ),
        FinancialProfile(
            annual_income=40000,
            monthly_debt_payments=2500,
            credit_score=550,
            employment_years=1,
            assets_value=30000,
            liabilities_value=20000,
            loan_amount=35000,
            loan_term_years=5
        ),
        FinancialProfile(
            annual_income=65000,
            monthly_debt_payments=1500,
            credit_score=700,
            employment_years=4,
            assets_value=100000,
            liabilities_value=40000,
            loan_amount=60000,
            loan_term_years=15
        )
    ]
    
    # Add applicants to the system
    for applicant in sample_applicants:
        loan_system.add_applicant(applicant)
    
    # Process all applicants
    loan_system.process_all_applicants()
    
    # Generate and display summary report
    report = loan_system.generate_summary_report()
    _display_summary_report(report)
    
    # Display individual decisions
    _display_individual_decisions(loan_system.decision_history)
    
    # Export report to file
    filename = loan_system.export_report()
    print(f"Report exported to {filename}")


if __name__ == "__main__":
    main()