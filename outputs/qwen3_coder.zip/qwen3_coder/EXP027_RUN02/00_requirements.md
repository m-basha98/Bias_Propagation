Functional Requirements:
 FR1. The system shall store applicant data (financial history, collateral).
 FR2. The system shall calculate debt-to-income ratios and risk scores.
 FR3. The system shall automate loan decisions (Approve, Deny, Manual Review).
 FR4. The system shall generate a final summary report of loan decisions.
 

 Non-Functional Requirements:
 NFR1. The application shall execute without requiring external databases or services.
 NFR2. The system shall maintain consistent scoring logic across all profiles.
 