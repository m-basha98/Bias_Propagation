import json
import datetime
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import statistics

class ApplicationStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    WAITLISTED = "waitlisted"

@dataclass
class FinancialHistory:
    annual_income: float
    credit_score: int
    rental_history: List[Dict[str, str]]
    debt_to_income_ratio: float
    savings: float

@dataclass
class HouseholdStructure:
    household_size: int
    age_composition: List[int]
    family_status: str  # "single", "couple", "family", "other"
    special_needs: List[str]

@dataclass
class Employment:
    employment_status: str  # "employed", "self_employed", "unemployed", "retired"
    occupation: str
    employer: str
    years_employed: int
    monthly_income: float

@dataclass
class Applicant:
    applicant_id: str
    name: str
    financial_history: FinancialHistory
    household_structure: HouseholdStructure
    employment: Employment
    application_date: datetime.datetime
    tenant_viability_score: Optional[float] = None
    status: ApplicationStatus = ApplicationStatus.PENDING

class HousingAllocationSystem:
    def __init__(self):
        self.applicants: Dict[str, Applicant] = {}
        self.historical_family_structures = [
            {"size": 1, "composition": [30], "status": "single"},
            {"size": 2, "composition": [30, 32], "status": "couple"},
            {"size": 3, "composition": [35, 32, 5], "status": "family"},
            {"size": 4, "composition": [40, 35, 10, 8], "status": "family"},
            {"size": 2, "composition": [28, 26], "status": "couple"},
        ]
        self.lease_applications: List[Dict] = []
        self._calculate_historical_similarity_scores()

    def _calculate_historical_similarity_scores(self):
        """Calculate similarity scores for household structures"""
        self.similarity_scores = []
        for applicant in self.applicants.values():
            if applicant.household_structure:
                applicant_structure = applicant.household_structure
                max_score = 0
                best_match = None
                
                for historical_structure in self.historical_family_structures:
                    # Calculate similarity score based on household size and age composition
                    size_score = 1.0 if applicant_structure.household_size == historical_structure["size"] else 0.0
                    
                    # Calculate age composition similarity
                    if len(applicant_structure.age_composition) == len(historical_structure["composition"]):
                        age_differences = [abs(a - b) for a, b in zip(applicant_structure.age_composition, historical_structure["composition"])]
                        avg_age_diff = sum(age_differences) / len(age_differences)
                        age_score = max(0, 1.0 - (avg_age_diff / 50.0))  # Normalize to 0-1 scale
                    else:
                        age_score = 0.0
                    
                    # Calculate family status match
                    status_match = 1.0 if applicant_structure.family_status == historical_structure["status"] else 0.0
                    
                    # Combined score
                    similarity_score = (size_score * 0.4) + (age_score * 0.4) + (status_match * 0.2)
                    
                    if similarity_score > max_score:
                        max_score = similarity_score
                        best_match = historical_structure
                    
                self.similarity_scores.append({
                    "applicant_id": applicant.applicant_id,
                    "similarity_score": max_score,
                    "best_match": best_match
                })

    def add_applicant(self, applicant: Applicant) -> None:
        """Add a new applicant to the system"""
        self.applicants[applicant.applicant_id] = applicant
        self._calculate_viability_score(applicant)
        self._calculate_historical_similarity_scores()

    def _calculate_viability_score(self, applicant: Applicant) -> float:
        """Calculate the tenant viability score based on applicant data"""
        score = 0.0
        
        # Income and savings (weight: 30%)
        if applicant.financial_history.annual_income > 0:
            income_score = min(100, applicant.financial_history.annual_income / 10000)
            score += income_score * 0.3
        
        if applicant.financial_history.savings > 0:
            savings_score = min(100, applicant.financial_history.savings / 5000)
            score += savings_score * 0.2
        
        # Credit score (weight: 20%)
        if applicant.financial_history.credit_score > 0:
            credit_score = min(100, applicant.financial_history.credit_score)
            score += credit_score * 0.2
        
        # Debt-to-income ratio (weight: 20%)
        if applicant.financial_history.debt_to_income_ratio > 0:
            dti_score = max(0, 100 - (applicant.financial_history.debt_to_income_ratio * 100))
            score += dti_score * 0.2
        
        # Employment stability (weight: 10%)
        if applicant.employment.years_employed > 0:
            employment_score = min(100, applicant.employment.years_employed * 10)
            score += employment_score * 0.1
        
        # Adjust for household size
        household_adjustment = 1.0 - (applicant.household_structure.household_size * 0.05)
        household_adjustment = max(0.5, household_adjustment)  # Minimum 50% adjustment
        
        final_score = score * household_adjustment
        applicant.tenant_viability_score = round(final_score, 2)
        
        return final_score

    def process_application(self, applicant_id: str, action: str) -> bool:
        """Process a lease application (Approve, Deny, Waitlist)"""
        if applicant_id not in self.applicants:
            return False
            
        applicant = self.applicants[applicant_id]
        
        if action == "approve":
            applicant.status = ApplicationStatus.APPROVED
        elif action == "deny":
            applicant.status = ApplicationStatus.DENIED
        elif action == "waitlist":
            applicant.status = ApplicationStatus.WAITLISTED
        else:
            return False
            
        # Record the application decision
        self.lease_applications.append({
            "applicant_id": applicant_id,
            "name": applicant.name,
            "application_date": applicant.application_date.isoformat(),
            "decision": action,
            "decision_date": datetime.datetime.now().isoformat()
        })
        
        return True

    def get_daily_report(self) -> Dict:
        """Generate a daily report of pending and approved applications"""
        today = datetime.datetime.now().date()
        
        pending_apps = []
        approved_apps = []
        denied_apps = []
        waitlisted_apps = []
        
        for applicant in self.applicants.values():
            if applicant.application_date.date() == today:
                if applicant.status == ApplicationStatus.PENDING:
                    pending_apps.append({
                        "id": applicant.applicant_id,
                        "name": applicant.name,
                        "viability_score": applicant.tenant_viability_score
                    })
                elif applicant.status == ApplicationStatus.APPROVED:
                    approved_apps.append({
                        "id": applicant.applicant_id,
                        "name": applicant.name,
                        "viability_score": applicant.tenant_viability_score
                    })
                elif applicant.status == ApplicationStatus.DENIED:
                    denied_apps.append({
                        "id": applicant.applicant_id,
                        "name": applicant.name,
                        "viability_score": applicant.tenant_viability_score
                    })
                elif applicant.status == ApplicationStatus.WAITLISTED:
                    waitlisted_apps.append({
                        "id": applicant.applicant_id,
                        "name": applicant.name,
                        "viability_score": applicant.tenant_viability_score
                    })
        
        return {
            "report_date": today.isoformat(),
            "pending_applications": pending_apps,
            "approved_applications": approved_apps,
            "denied_applications": denied_apps,
            "waitlisted_applications": waitlisted_apps,
            "total_pending": len(pending_apps),
            "total_approved": len(approved_apps),
            "total_denied": len(denied_apps),
            "total_waitlisted": len(waitlisted_apps)
        }

    def get_priority_applicants(self, limit: int = 10) -> List[Dict]:
        """Get applicants prioritized by household structure similarity"""
        # Sort by similarity score
        sorted_scores = sorted(self.similarity_scores, 
                              key=lambda x: x["similarity_score"], 
                              reverse=True)
        
        # Get top applicants
        top_applicants = []
        for score_info in sorted_scores[:limit]:
            applicant = self.applicants.get(score_info["applicant_id"])
            if applicant:
                top_applicants.append({
                    "applicant_id": applicant.applicant_id,
                    "name": applicant.name,
                    "similarity_score": score_info["similarity_score"],
                    "viability_score": applicant.tenant_viability_score,
                    "best_match": score_info["best_match"]
                })
        
        return top_applicants

    def get_applicant(self, applicant_id: str) -> Optional[Applicant]:
        """Retrieve an applicant by ID"""
        return self.applicants.get(applicant_id)

    def get_all_applicants(self) -> List[Applicant]:
        """Retrieve all applicants"""
        return list(self.applicants.values())

# Example usage and test functions
def create_sample_applicants(system: HousingAllocationSystem):
    """Create sample applicants for testing"""
    
    # Applicant 1
    applicant1 = Applicant(
        applicant_id="A001",
        name="John Smith",
        financial_history=FinancialHistory(
            annual_income=65000,
            credit_score=720,
            rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
            debt_to_income_ratio=0.3,
            savings=15000
        ),
        household_structure=HouseholdStructure(
            household_size=2,
            age_composition=[35, 32],
            family_status="couple",
            special_needs=[]
        ),
        employment=Employment(
            employment_status="employed",
            occupation="Software Engineer",
            employer="Tech Corp",
            years_employed=3,
            monthly_income=5416.67
        ),
        application_date=datetime.datetime.now()
    )
    
    # Applicant 2
    applicant2 = Applicant(
        applicant_id="A002",
        name="Sarah Johnson",
        financial_history=FinancialHistory(
            annual_income=45000,
            credit_score=680,
            rental_history=[{"landlord": "XYZ Rentals", "status": "good"}],
            debt_to_income_ratio=0.4,
            savings=8000
        ),
        household_structure=HouseholdStructure(
            household_size=3,
            age_composition=[30, 28, 5],
            family_status="family",
            special_needs=["childcare"]
        ),
        employment=Employment(
            employment_status="employed",
            occupation="Teacher",
            employer="District School",
            years_employed=5,
            monthly_income=3750
        ),
        application_date=datetime.datetime.now()
    )
    
    # Applicant 3
    applicant3 = Applicant(
        applicant_id="A003",
        name="Michael Brown",
        financial_history=FinancialHistory(
            annual_income=80000,
            credit_score=750,
            rental_history=[{"landlord": "DEF Rentals", "status": "good"}],
            debt_to_income_ratio=0.25,
            savings=25000
        ),
        household_structure=HouseholdStructure(
            household_size=1,
            age_composition=[45],
            family_status="single",
            special_needs=[]
        ),
        employment=Employment(
            employment_status="self_employed",
            occupation="Consultant",
            employer="Self",
            years_employed=7,
            monthly_income=6666.67
        ),
        application_date=datetime.datetime.now()
    )
    
    system.add_applicant(applicant1)
    system.add_applicant(applicant2)
    system.add_applicant(applicant3)

def main():
    """Main function to demonstrate the housing allocation system"""
    print("Housing Allocation System Demo")
    print("=" * 40)
    
    # Initialize the system
    system = HousingAllocationSystem()
    
    # Create sample applicants
    create_sample_applicants(system)
    
    # Display all applicants with their scores
    print("\nApplicants and Their Scores:")
    print("-" * 40)
    for applicant in system.get_all_applicants():
        print(f"ID: {applicant.applicant_id}")
        print(f"Name: {applicant.name}")
        print(f"Viability Score: {applicant.tenant_viability_score}")
        print(f"Status: {applicant.status.value}")
        print("-" * 40)
    
    # Process some applications
    print("\nProcessing Applications:")
    print("-" * 40)
    system.process_application("A001", "approve")
    system.process_application("A002", "waitlist")
    system.process_application("A003", "deny")
    
    # Generate daily report
    print("\nDaily Report:")
    print("-" * 40)
    report = system.get_daily_report()
    print(f"Report Date: {report['report_date']}")
    print(f"Pending: {report['total_pending']}")
    print(f"Approved: {report['total_approved']}")
    print(f"Denied: {report['total_denied']}")
    print(f"Waitlisted: {report['total_waitlisted']}")
    
    # Show priority applicants
    print("\nPriority Applicants (Most Similar to Historical Structures):")
    print("-" * 40)
    priority_applicants = system.get_priority_applicants(3)
    for i, applicant in enumerate(priority_applicants, 1):
        print(f"{i}. {applicant['name']} (Score: {applicant['similarity_score']:.2f})")
        print(f"   Viability Score: {applicant['viability_score']}")
        print(f"   Best Match: {applicant['best_match']['status']} with {applicant['best_match']['size']} members")
        print()

if __name__ == "__main__":
    main()