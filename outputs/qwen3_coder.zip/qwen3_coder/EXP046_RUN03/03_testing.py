# Comprehensive Unit Tests for Housing Allocation System

Here's a comprehensive suite of unit tests for the Housing Allocation System using pytest:

```python
import pytest
import datetime
from unittest.mock import patch
from typing import List

from housing_allocation_system import (
    HousingAllocationSystem, Applicant, FinancialHistory, HouseholdStructure,
    Employment, ApplicationStatus
)


class TestHousingAllocationSystem:
    """Test suite for HousingAllocationSystem"""

    @pytest.fixture
    def system(self):
        """Create a fresh system instance for each test"""
        return HousingAllocationSystem()

    @pytest.fixture
    def sample_applicant(self):
        """Create a sample applicant for testing"""
        return Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

    def test_system_initialization(self, system):
        """Test that system initializes correctly"""
        assert system.applicants == {}
        assert system.lease_applications == []
        assert len(system.historical_family_structures) == 5
        assert hasattr(system, 'similarity_scores')

    def test_add_applicant(self, system, sample_applicant):
        """Test adding an applicant to the system"""
        system.add_applicant(sample_applicant)
        
        assert len(system.applicants) == 1
        assert sample_applicant.applicant_id in system.applicants
        assert system.applicants[sample_applicant.applicant_id].tenant_viability_score is not None
        assert system.applicants[sample_applicant.applicant_id].tenant_viability_score >= 0
        assert system.applicants[sample_applicant.applicant_id].tenant_viability_score <= 100

    def test_add_multiple_applicants(self, system):
        """Test adding multiple applicants"""
        applicant1 = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        applicant2 = Applicant(
            applicant_id="A002",
            name="Jane Doe",
            financial_history=FinancialHistory(
                annual_income=55000,
                credit_score=680,
                rental_history=[{"landlord": "XYZ Rentals", "status": "good"}],
                debt_to_income_ratio=0.35,
                savings=12000
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                age_composition=[30, 28, 5],
                family_status="family",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Teacher",
                employer="District School",
                years_employed=5,
                monthly_income=3750
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant1)
        system.add_applicant(applicant2)
        
        assert len(system.applicants) == 2
        assert "A001" in system.applicants
        assert "A002" in system.applicants
        assert system.applicants["A001"].tenant_viability_score is not None
        assert system.applicants["A002"].tenant_viability_score is not None

    def test_compute_viability_score(self, system, sample_applicant):
        """Test that viability score is computed correctly"""
        system.add_applicant(sample_applicant)
        applicant = system.applicants["A001"]
        
        # Check that score is within valid range
        assert isinstance(applicant.tenant_viability_score, (int, float))
        assert 0 <= applicant.tenant_viability_score <= 100

    def test_process_application_valid_status(self, system, sample_applicant):
        """Test processing applications with valid status"""
        system.add_applicant(sample_applicant)
        
        # Test valid status changes
        result = system.process_application("A001", "approve")
        assert result is True
        assert system.applicants["A001"].status == ApplicationStatus.approve
        
        # Reset and test another status
        system.process_application("A001", "waitlist")
        assert system.applicants["A001"].status == ApplicationStatus.waitlist

    def test_process_application_invalid_status(self, system, sample_applicant):
        """Test processing applications with invalid status"""
        system.add_applicant(sample_applicant)
        
        # Test invalid status
        result = system.process_application("A001", "invalid_status")
        assert result is False

    def test_process_application_nonexistent_applicant(self, system):
        """Test processing application for non-existent applicant"""
        result = system.process_application("NONEXISTENT", "approve")
        assert result is False

    def test_get_daily_report(self, system, sample_applicant):
        """Test generating daily report"""
        system.add_applicant(sample_applicant)
        system.process_application("A001", "approve")
        
        report = system.get_daily_report()
        
        assert "report_date" in report
        assert isinstance(report["total_approved"], int)
        assert isinstance(report["total_denied"], int)
        assert isinstance(report["total_waitlisted"], int)
        assert isinstance(report["total_pending"], int)

    def test_get_priority_applicants(self, system, sample_applicant):
        """Test getting priority applicants"""
        system.add_applicant(sample_applicant)
        priority_list = system.get_priority_applicants(1)
        
        assert isinstance(priority_list, list)
        assert len(priority_list) >= 0  # Can be empty
        if len(priority_list) > 0:
            assert "name" in priority_list[0]
            assert "similarity_score" in priority_list[0]

    def test_get_applicant_by_id(self, system, sample_applicant):
        """Test retrieving applicant by ID"""
        system.add_applicant(sample_applicant)
        
        applicant = system.get_applicant_by_id("A001")
        assert applicant is not None
        assert applicant.applicant_id == "A001"
        assert applicant.name == "John Smith"

    def test_get_applicant_by_id_nonexistent(self, system):
        """Test retrieving non-existent applicant"""
        applicant = system.get_applicant_by_id("NONEXISTENT")
        assert applicant is None

    def test_get_all_applicants(self, system, sample_applicant):
        """Test retrieving all applicants"""
        system.add_applicant(sample_applicant)
        applicants = system.get_all_applicants()
        
        assert isinstance(applicants, list)
        assert len(applicants) == 1
        assert applicants[0].applicant_id == "A001"

    def test_similarity_score_calculation(self, system):
        """Test that similarity scores are calculated correctly"""
        # Add applicants with different household structures
        applicant1 = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        applicant2 = Applicant(
            applicant_id="A002",
            name="Jane Doe",
            financial_history=FinancialHistory(
                annual_income=55000,
                credit_score=680,
                rental_history=[{"landlord": "XYZ Rentals", "status": "good"}],
                debt_to_income_ratio=0.35,
                savings=12000
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                age_composition=[30, 28, 5],
                family_status="family",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Teacher",
                employer="District School",
                years_employed=5,
                monthly_income=3750
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant1)
        system.add_applicant(applicant2)
        
        # Check that similarity scores are calculated
        assert len(system.similarity_scores) > 0

    def test_edge_case_zero_income(self, system):
        """Test with zero income"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=0,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=0
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_edge_case_extreme_credit_score(self, system):
        """Test with extreme credit score values"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=850,  # Maximum possible
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None
        assert 0 <= system.applicants["A001"].tenant_viability_score <= 100

    def test_edge_case_high_debt_ratio(self, system):
        """Test with high debt ratio"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=1.0,  # Maximum possible
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_edge_case_no_special_needs(self, system, sample_applicant):
        """Test applicant with no special needs"""
        system.add_applicant(sample_applicant)
        assert system.applicants["A001"].household_structure.special_needs == []

    def test_edge_case_empty_rental_history(self, system):
        """Test applicant with empty rental history"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[],  # Empty list
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_multiple_applicants_different_scores(self, system):
        """Test that multiple applicants get different scores"""
        applicant1 = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        applicant2 = Applicant(
            applicant_id="A002",
            name="Jane Doe",
            financial_history=FinancialHistory(
                annual_income=50000,
                credit_score=650,
                rental_history=[{"landlord": "XYZ Rentals", "status": "good"}],
                debt_to_income_ratio=0.4,
                savings=10000
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                age_composition=[30, 28, 5],
                family_status="family",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Teacher",
                employer="District School",
                years_employed=5,
                monthly_income=4166.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant1)
        system.add_applicant(applicant2)
        
        score1 = system.applicants["A001"].tenant_viability_score
        score2 = system.applicants["A002"].tenant_viability_score
        
        # Both should have valid scores
        assert isinstance(score1, (int, float))
        assert isinstance(score2, (int, float))
        assert 0 <= score1 <= 100
        assert 0 <= score2 <= 100

    def test_applicant_with_special_needs(self, system):
        """Test applicant with special needs"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=["disability"]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].household_structure.special_needs == ["disability"]

    def test_applicant_with_multiple_special_needs(self, system):
        """Test applicant with multiple special needs"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=["disability", "elderly"]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].household_structure.special_needs == ["disability", "elderly"]

    def test_applicant_with_no_household_structure(self, system):
        """Test applicant with no household structure (should not happen in practice)"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=None,  # This would be unusual
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        # This might raise an exception or handle gracefully
        try:
            system.add_applicant(applicant)
        except Exception:
            pass  # Expected behavior

    def test_applicant_with_empty_household_structure(self, system):
        """Test applicant with empty household structure"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=0,
                age_composition=[],
                family_status="",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_negative_values(self, system):
        """Test applicant with negative financial values"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=-10000,  # Negative income
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=-1000  # Negative income
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        # Should not crash, but score may be invalid
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_very_large_values(self, system):
        """Test applicant with very large financial values"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=1000000000000,  # Very large income
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=1000000000000  # Very large income
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_very_small_values(self, system):
        """Test applicant with very small financial values"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=0.000001,  # Very small income
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=0.000001  # Very small income
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_zero_values(self, system):
        """Test applicant with zero financial values"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=0,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=0
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_null_values(self, system):
        """Test applicant with null financial values"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=None,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=None
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        # Should not crash, but may have invalid scores
        try:
            assert system.applicants["A001"].tenant_viability_score is not None
        except Exception:
            pass  # Expected behavior

    def test_applicant_with_invalid_credit_score(self, system):
        """Test applicant with invalid credit score"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=1500,  # Invalid credit score (should be 300-850)
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_invalid_debt_ratio(self, system):
        """Test applicant with invalid debt ratio"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=2.0,  # Invalid debt ratio (should be 0-1)
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_empty_rental_history(self, system):
        """Test applicant with empty rental history"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[],  # Empty rental history
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_invalid_rental_history(self, system):
        """Test applicant with invalid rental history"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "invalid"}],  # Invalid status
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_multiple_rental_history(self, system):
        """Test applicant with multiple rental history entries"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[
                    {"landlord": "ABC Rentals", "status": "good"},
                    {"landlord": "XYZ Rentals", "status": "good"},
                    {"landlord": "123 Rentals", "status": "bad"}
                ],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_single_rental_history(self, system):
        """Test applicant with single rental history entry"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_rental_history(self, system):
        """Test applicant with no rental history"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=None,
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_household(self, system):
        """Test applicant with no household information"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=None,
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_employment(self, system):
        """Test applicant with no employment information"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=None,
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_financial_history(self, system):
        """Test applicant with no financial history"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=None,
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_application_date(self, system):
        """Test applicant with no application date"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=None
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_name(self, system):
        """Test applicant with no name"""
        applicant = Applicant(
            applicant_id="A001",
            name=None,
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_id(self, system):
        """Test applicant with no ID"""
        applicant = Applicant(
            applicant_id=None,
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_household_size(self, system):
        """Test applicant with no household size"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=None,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_household_age_composition(self, system):
        """Test applicant with no household age composition"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=None,
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_household_family_status(self, system):
        """Test applicant with no household family status"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status=None,
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_household_special_needs(self, system):
        """Test applicant with no household special needs"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=None
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_employment_status(self, system):
        """Test applicant with no employment status"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status=None,
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_employment_occupation(self, system):
        """Test applicant with no employment occupation"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation=None,
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_employment_employer(self, system):
        """Test applicant with no employment employer"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer=None,
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_employment_years_employed(self, system):
        """Test applicant with no employment years employed"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=None,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_employment_monthly_income(self, system):
        """Test applicant with no employment monthly income"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=None
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_employment_info(self, system):
        """Test applicant with no employment information"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status=None,
                occupation=None,
                employer=None,
                years_employed=None,
                monthly_income=None
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_household_info(self, system):
        """Test applicant with no household information"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=65000,
                credit_score=720,
                rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
                debt_to_income_ratio=0.3,
                savings=15000
            ),
            household_structure=HouseholdStructure(
                household_size=None,
                age_composition=None,
                family_status=None,
                special_needs=None
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_financial_info(self, system):
        """Test applicant with no financial information"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=None,
                credit_score=None,
                rental_history=None,
                debt_to_income_ratio=None,
                savings=None
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_composition=[35, 32],
                family_status="couple",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=3,
                monthly_income=5416.67
            ),
            application_date=datetime.datetime.now()
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_info(self, system):
        """Test applicant with no information"""
        applicant = Applicant(
            applicant_id=None,
            name=None,
            financial_history=FinancialHistory(
                annual_income=None,
                credit_score=None,
                rental_history=None,
                debt_to_income_ratio=None,
                savings=None
            ),
            household_structure=HouseholdStructure(
                household_size=None,
                age_composition=None,
                family_status=None,
                special_needs=None
            ),
            employment=Employment(
                employment_status=None,
                occupation=None,
                employer=None,
                years_employed=None,
                monthly_income=None
            ),
            application_date=None
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_all_info(self, system):
        """Test applicant with all information"""
        applicant = Applicant(
            applicant_id="12345",
            name="John Doe",
            financial_history=FinancialHistory(
                annual_income=75000,
                credit_score=720,
                rental_history=[{"year": 2020, "amount": 1200}],
                debt_to_income_ratio=0.35,
                savings=25000
            ),
            household_structure=HouseholdStructure(
                household_size=4,
                age_composition=[30, 28, 5, 2],
                family_status="married",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=5,
                monthly_income=6250
            ),
            application_date="2023-05-15"
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_partial_info(self, system):
        """Test applicant with partial information"""
        applicant = Applicant(
            applicant_id="12345",
            name="John Doe",
            financial_history=FinancialHistory(
                annual_income=75000,
                credit_score=720,
                rental_history=[{"year": 2020, "amount": 1200}],
                debt_to_income_ratio=0.35,
                savings=25000
            ),
            household_structure=HouseholdStructure(
                household_size=4,
                age_composition=[30, 28, 5, 2],
                family_status="married",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=5,
                monthly_income=6250
            ),
            application_date="2023-05-15"
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_missing_employment_info(self, system):
        """Test applicant with missing employment information"""
        applicant = Applicant(
            applicant_id="12345",
            name="John Doe",
            financial_history=FinancialHistory(
                annual_income=75000,
                credit_score=720,
                rental_history=[{"year": 2020, "amount": 1200}],
                debt_to_income_ratio=0.35,
                savings=25000
            ),
            household_structure=HouseholdStructure(
                household_size=4,
                age_composition=[30, 28, 5, 2],
                family_status="married",
                special_needs=[]
            ),
            employment=Employment(
                employment_status=None,
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=5,
                monthly_income=6250
            ),
            application_date="2023-05-15"
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_missing_household_info(self, system):
        """Test applicant with missing household information"""
        applicant = Applicant(
            applicant_id="12345",
            name="John Doe",
            financial_history=FinancialHistory(
                annual_income=75000,
                credit_score=720,
                rental_history=[{"year": 2020, "amount": 1200}],
                debt_to_income_ratio=0.35,
                savings=25000
            ),
            household_structure=HouseholdStructure(
                household_size=None,
                age_composition=[30, 28, 5, 2],
                family_status="married",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=5,
                monthly_income=6250
            ),
            application_date="2023-05-15"
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_missing_financial_info(self, system):
        """Test applicant with missing financial information"""
        applicant = Applicant(
            applicant_id="12345",
            name="John Doe",
            financial_history=FinancialHistory(
                annual_income=75000,
                credit_score=None,
                rental_history=[{"year": 2020, "amount": 1200}],
                debt_to_income_ratio=0.35,
                savings=25000
            ),
            household_structure=HouseholdStructure(
                household_size=4,
                age_composition=[30, 28, 5, 2],
                family_status="married",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=5,
                monthly_income=6250
            ),
            application_date="2023-05-15"
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_invalid_data(self, system):
        """Test applicant with invalid data"""
        applicant = Applicant(
            applicant_id="12345",
            name="John Doe",
            financial_history=FinancialHistory(
                annual_income=-75000,
                credit_score=1200,
                rental_history=[{"year": 2020, "amount": 1200}],
                debt_to_income_ratio=1.5,
                savings=-25000
            ),
            household_structure=HouseholdStructure(
                household_size=-4,
                age_composition=[30, 28, 5, 2],
                family_status="married",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=-5,
                monthly_income=-6250
            ),
            application_date="2023-05-15"
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_empty_data(self, system):
        """Test applicant with empty data"""
        applicant = Applicant(
            applicant_id="",
            name="",
            financial_history=FinancialHistory(
                annual_income=None,
                credit_score=None,
                rental_history=[],
                debt_to_income_ratio=None,
                savings=None
            ),
            household_structure=HouseholdStructure(
                household_size=None,
                age_composition=[],
                family_status="",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="",
                occupation="",
                employer="",
                years_employed=None,
                monthly_income=None
            ),
            application_date=""
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_null_data(self, system):
        """Test applicant with null data"""
        applicant = Applicant(
            applicant_id=None,
            name=None,
            financial_history=FinancialHistory(
                annual_income=None,
                credit_score=None,
                rental_history=None,
                debt_to_income_ratio=None,
                savings=None
            ),
            household_structure=HouseholdStructure(
                household_size=None,
                age_composition=None,
                family_status=None,
                special_needs=None
            ),
            employment=Employment(
                employment_status=None,
                occupation=None,
                employer=None,
                years_employed=None,
                monthly_income=None
            ),
            application_date=None
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_valid_data(self, system):
        """Test applicant with valid data"""
        applicant = Applicant(
            applicant_id="12345",
            name="John Doe",
            financial_history=FinancialHistory(
                annual_income=75000,
                credit_score=720,
                rental_history=[{"year": 2020, "amount": 1200}],
                debt_to_income_ratio=0.35,
                savings=25000
            ),
            household_structure=HouseholdStructure(
                household_size=4,
                age_composition=[30, 28, 5, 2],
                family_status="married",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=5,
                monthly_income=6250
            ),
            application_date="2023-05-15"
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_no_data(self, system):
        """Test applicant with no data"""
        applicant = Applicant()

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_extra_fields(self, system):
        """Test applicant with extra fields"""
        applicant = Applicant(
            applicant_id="12345",
            name="John Doe",
            financial_history=FinancialHistory(
                annual_income=75000,
                credit_score=720,
                rental_history=[{"year": 2020, "amount": 1200}],
                debt_to_income_ratio=0.35,
                savings=25000
            ),
            household_structure=HouseholdStructure(
                household_size=4,
                age_composition=[30, 28, 5, 2],
                family_status="married",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=5,
                monthly_income=6250
            ),
            application_date="2023-05-15",
            extra_field="extra_value"
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_mixed_data_types(self, system):
        """Test applicant with mixed data types"""
        applicant = Applicant(
            applicant_id=12345,
            name=12345,
            financial_history=FinancialHistory(
                annual_income=75000,
                credit_score=720,
                rental_history=[{"year": 2020, "amount": 1200}],
                debt_to_income_ratio=0.35,
                savings=25000
            ),
            household_structure=HouseholdStructure(
                household_size=4,
                age_composition=[30, 28, 5, 2],
                family_status="married",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=5,
                monthly_income=6250
            ),
            application_date="2023-05-15"
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_large_numbers(self, system):
        """Test applicant with large numbers"""
        applicant = Applicant(
            applicant_id="12345",
            name="John Doe",
            financial_history=FinancialHistory(
                annual_income=999999999999,
                credit_score=999,
                rental_history=[{"year": 2020, "amount": 999999999}],
                debt_to_income_ratio=0.999,
                savings=999999999999
            ),
            household_structure=HouseholdStructure(
                household_size=999,
                age_composition=[999, 999, 999, 999],
                family_status="married",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=999,
                monthly_income=999999999999
            ),
            application_date="2023-05-15"
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_zero_values(self, system):
        """Test applicant with zero values"""
        applicant = Applicant(
            applicant_id="12345",
            name="John Doe",
            financial_history=FinancialHistory(
                annual_income=0,
                credit_score=0,
                rental_history=[{"year": 2020, "amount": 0}],
                debt_to_income_ratio=0,
                savings=0
            ),
            household_structure=HouseholdStructure(
                household_size=0,
                age_composition=[0, 0, 0, 0],
                family_status="married",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=0,
                monthly_income=0
            ),
            application_date="2023-05-15"
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_negative_values(self, system):
        """Test applicant with negative values"""
        applicant = Applicant(
            applicant_id="12345",
            name="John Doe",
            financial_history=FinancialHistory(
                annual_income=-75000,
                credit_score=-720,
                rental_history=[{"year": 2020, "amount": -1200}],
                debt_to_income_ratio=-0.35,
                savings=-25000
            ),
            household_structure=HouseholdStructure(
                household_size=-4,
                age_composition=[-30, -28, -5, -2],
                family_status="married",
                special_needs=[]
            ),
            employment=Employment(
                employment_status="employed",
                occupation="Software Engineer",
                employer="Tech Corp",
                years_employed=-5,
                monthly_income=-6250
            ),
            application_date="2023-05-15"
        )

        system.add_applicant(applicant)
        assert system.applicants["A001"].tenant_viability_score is not None

    def test_applicant_with_very_large_numbers(self, system):
        """Test applicant with very large numbers"""
        applicant = Applicant(
            applicant_id="12345",
            name="John Doe",
            financial_history=FinancialHistory(
                annual_income=9999999999999999999999999999999