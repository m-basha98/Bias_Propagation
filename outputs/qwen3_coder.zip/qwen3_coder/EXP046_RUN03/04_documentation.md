# Housing Allocation System Technical Documentation

## Overview

This document provides detailed technical documentation for the Housing Allocation System, a self-contained application designed to manage lease applications, compute tenant viability scores, and prioritize applicants based on household structure similarity.

## System Architecture

The system is built using Python with object-oriented design principles. It operates entirely independently without requiring external databases or services, ensuring deterministic and reproducible data processing as specified in the non-functional requirements.

## Classes and Data Structures

### 1. ApplicationStatus (Enum)
Enumeration representing the status of lease applications:
- `PENDING` - Application is under review
- `APPROVED` - Application has been approved
- `DENIED` - Application has been denied
- `WAITLISTED` - Application is on the waiting list

### 2. FinancialHistory (Dataclass)
Stores financial information for an applicant:
- `annual_income` (float): Annual income of the applicant
- `credit_score` (int): Credit score of the applicant
- `rental_history` (List[Dict]): History of rental properties
- `debt_to_income_ratio` (float): Ratio of monthly debt payments to gross income
- `savings` (float): Total savings amount

### 3. HouseholdStructure (Dataclass)
Contains household composition information:
- `household_size` (int): Number of people in the household
- `age_composition` (List[int]): Ages of household members
- `family_status` (str): Status indicating household type ("single", "couple", "family", "other")
- `special_needs` (List[str]): Special needs requirements

### 4. Employment (Dataclass)
Stores employment information:
- `employment_status` (str): Current employment status
- `occupation` (str): Job title or occupation
- `employer` (str): Name of employer
- `years_employed` (int): Number of years employed at current job
- `monthly_income` (float): Monthly income amount

### 5. Applicant (Dataclass)
Complete applicant information combining all data types:
- `applicant_id` (str): Unique identifier for the applicant
- `name` (str): Full name of the applicant
- `financial_history` (FinancialHistory): Financial information
- `household_structure` (HouseholdStructure): Household composition
- `employment` (Employment): Employment details
- `application_date` (datetime.datetime): Date when application was submitted
- `tenant_viability_score` (Optional[float]): Computed viability score (0-100)
- `status` (ApplicationStatus): Current application status

## Main System Class: HousingAllocationSystem

### Constructor
```python
def __init__(self)
```
Initializes the housing allocation system with:
- Empty applicants dictionary
- Predefined historical family structures for similarity matching
- Empty lease applications list
- Calculates initial similarity scores for all applicants

### Methods

#### 1. `_calculate_historical_similarity_scores`
**Description:** Calculates similarity scores for household structures by comparing each applicant's household composition with historical family structures.

**Parameters:** None

**Returns:** None (modifies internal `self.similarity_scores`)

**Algorithm:** 
- Compares household size and age composition
- Calculates size match (1.0 if exact match, 0.0 otherwise)
- Calculates age composition similarity using normalized difference
- Combines scores with weighted average (50% size, 50% age)

#### 2. `_compute_viability_score`
**Description:** Computes the tenant viability score for an applicant based on multiple financial factors.

**Parameters:**
- `applicant` (Applicant): The applicant to score

**Returns:**
- `float`: The computed viability score (0-100)

**Factors:**
- Credit score (0-100)
- Annual income (0-100)
- Debt-to-income ratio (0-100)
- Savings (0-100)
- Employment stability (0-100)
- Weights: Credit (25%), Income (20%), Debt (20%), Savings (15%), Employment (20%)

#### 3. `add_applicant`
**Description:** Adds a new applicant to the system and computes their viability score.

**Parameters:**
- `applicant` (Applicant): The applicant to add

**Returns:** None

**Process:**
- Computes viability score using `_compute_viability_score`
- Stores applicant in internal dictionary
- Recalculates similarity scores for all applicants

#### 4. `process_application`
**Description:** Processes an application by updating its status.

**Parameters:**
- `applicant_id` (str): Unique identifier of the applicant
- `status` (str): New status to assign

**Returns:**
- `bool`: True if successful, False if applicant not found

**Valid statuses:** "approve", "deny", "waitlist"

#### 5. `get_daily_report`
**Description:** Generates a summary report of application statuses.

**Parameters:** None

**Returns:**
- `dict`: Dictionary containing:
  - `report_date` (str): Current date
  - `total_approved` (int): Count of approved applications
  - `total_denied` (int): Count of denied applications
  - `total_waitlisted` (int): Count of waitlisted applications
  - `total_pending` (int): Count of pending applications

#### 6. `get_priority_applicants`
**Description:** Retrieves applicants ranked by household structure similarity to historical patterns.

**Parameters:**
- `limit` (int): Maximum number of applicants to return (default: 10)

**Returns:**
- `List[Dict]`: List of applicant dictionaries sorted by similarity score

#### 7. `get_applicant`
**Description:** Retrieves a specific applicant by ID.

**Parameters:**
- `applicant_id` (str): Unique identifier of the applicant

**Returns:**
- `Optional[Applicant]`: Applicant object if found, None otherwise

#### 8. `get_all_applicants`
**Description:** Retrieves all applicants in the system.

**Parameters:** None

**Returns:**
- `List[Applicant]`: List of all applicant objects

## Example Usage

The system includes example usage functions:
- `create_sample_applicants`: Creates sample applicants for testing
- `main`: Demonstrates complete system functionality including:
  - Applicant creation
  - Viability score calculation
  - Application processing
  - Daily report generation
  - Priority applicant listing

## Requirements

### System Requirements:
- Python 3.6+
- No external dependencies beyond standard library

### Functional Requirements:
1. **Self-contained operation**: No external databases or services required
2. **Deterministic processing**: Same inputs produce same outputs
3. **Financial scoring**: Comprehensive viability scoring based on multiple factors
4. **Household similarity matching**: Algorithmic comparison with historical patterns
5. **Application management**: Full lifecycle management of applications

## Data Flow

1. **Input**: Applicant data (financial, household, employment details)
2. **Processing**: 
   - Viability score calculation
   - Household similarity analysis
   - Status management
3. **Output**: 
   - Individual applicant scores
   - Application status reports
   - Priority applicant rankings

## Performance Considerations

- **Time Complexity**: O(n) for most operations where n is the number of applicants
- **Space Complexity**: O(n) for storing applicant data and similarity scores
- **Scalability**: Designed for small to medium-sized datasets
- **Memory Usage**: Minimal memory footprint due to efficient data structures

## Error Handling

The system handles:
- Missing applicants (returns None)
- Invalid status updates
- Invalid applicant IDs
- Data validation for numeric fields

## Extensibility

The system is designed to be extensible:
- Additional financial factors can be added to viability scoring
- New household structure types can be supported
- Additional application statuses can be implemented
- New similarity metrics can be added to the matching algorithm

This documentation provides comprehensive technical details for developers and system administrators to understand, maintain, and extend the Housing Allocation System.