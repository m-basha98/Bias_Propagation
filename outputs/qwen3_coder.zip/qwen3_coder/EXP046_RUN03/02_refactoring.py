"""
Housing Allocation System

This system manages lease applications, computes tenant viability scores,
and prioritizes applicants based on household structure similarity.
"""

import json
import datetime
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import statistics


class ApplicationStatus(Enum):
    """Enumeration for application statuses"""
    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    WAITLISTED = "waitlisted"


@dataclass
class FinancialHistory:
    """Financial information for an applicant"""
    annual_income: float
    credit_score: int
    rental_history: List[Dict[str, str]]
    debt_to_income_ratio: float
    savings: float


@dataclass
class HouseholdStructure:
    """Household composition information"""
    household_size: int
    age_composition: List[int]
    family_status: str  # "single", "couple", "family", "other"
    special_needs: List[str]


@dataclass
class Employment:
    """Employment information for an applicant"""
    employment_status: str  # "employed", "self_employed", "unemployed", "retired"
    occupation: str
    employer: str
    years_employed: int
    monthly_income: float


@dataclass
class Applicant:
    """Complete applicant information"""
    applicant_id: str
    name: str
    financial_history: FinancialHistory
    household_structure: HouseholdStructure
    employment: Employment
    application_date: datetime.datetime
    tenant_viability_score: Optional[float] = None
    status: ApplicationStatus = ApplicationStatus.PENDING


class HousingAllocationSystem:
    """Main system for managing housing applications and allocations"""

    def __init__(self):
        self.applicants: Dict[str, Applicant] = {}
        self.historical_family_structures = [
            {"size": 1, "composition": [30], "status": "single"},
            {"size": 2, "composition": [30, 32], "status": "couple"},
            {"size": 3, "composition": [35, 32, 5], "status": "family"},
            {"size": 4, "composition": [40, 35, 10, 8], "status": "family"},
            {"size": 2, "composition": [28, 26], "status": "couple"},
        ]
        self.lease_applications: List[Dict] = []
        self._calculate_historical_similarity_scores()

    def _calculate_historical_similarity_scores(self):
        """Calculate similarity scores for household structures"""
        self.similarity_scores = []
        for applicant in self.applicants.values():
            if applicant.household_structure:
                applicant_structure = applicant.household_structure
                max_score = 0.0
                best_match = None
                
                for historical_structure in self.historical_family_structures:
                    # Calculate similarity score based on household size and age composition
                    size_score = 1.0 if applicant_structure.household_size == historical_structure["size"] else 0.0
                    
                    # Calculate age composition similarity
                    if len(applicant_structure.age_composition) == len(historical_structure["composition"]):
                        age_differences = [abs(a - b) for a, b in zip(
                            applicant_structure.age_composition,
                            historical_structure["composition"]
                        )]
                        age_similarity = 1.0 - (sum(age_differences) / 
                                               (len(age_differences) * 50.0))  # Normalize to 0-1 scale
                        age_score = max(0.0, age_similarity)
                    else:
                        age_score = 0.0
                    
                    # Weighted combination of size and age scores
                    combined_score = (size_score * 0.5) + (age_score * 0.5)
                    
                    if combined_score > max_score:
                        max_score = combined_score
                        best_match = historical_structure
                
                self.similarity_scores.append({
                    "applicant_id": applicant.applicant_id,
                    "similarity_score": max_score,
                    "best_match": best_match
                })

    def _compute_viability_score(self, applicant: Applicant) -> float:
        """
        Compute the tenant viability score for an applicant
        
        Args:
            applicant: The applicant to score
            
        Returns:
            The computed viability score (0-100)
        """
        # Base score from credit score (0-100)
        credit_score_factor = min(100.0, max(0.0, applicant.financial_history.credit_score / 10.0))
        
        # Income factor (0-100)
        income_factor = min(100.0, max(0.0, applicant.financial_history.annual_income / 1000.0))
        
        # Debt-to-income ratio factor (0-100)
        debt_factor = 100.0 - (applicant.financial_history.debt_to_income_ratio * 100.0)
        debt_factor = max(0.0, debt_factor)
        
        # Savings factor (0-100)
        savings_factor = min(100.0, max(0.0, applicant.financial_history.savings / 100.0))
        
        # Employment stability factor (0-100)
        employment_factor = min(100.0, max(0.0, applicant.employment.years_employed * 10.0))
        
        # Weighted average of all factors
        viability_score = (
            credit_score_factor * 0.25 +
            income_factor * 0.20 +
            debt_factor * 0.20 +
            savings_factor * 0.15 +
            employment_factor * 0.20
        )
        
        return viability_score

    def add_applicant(self, applicant: Applicant):
        """Add a new applicant to the system"""
        # Compute viability score
        applicant.tenant_viability_score = self._compute_viability_score(applicant)
        self.applicants[applicant.applicant_id] = applicant
        self._calculate_historical_similarity_scores()

    def process_application(self, applicant_id: str, action: str) -> bool:
        """
        Process an application with a specific action
        
        Args:
            applicant_id: The ID of the applicant
            action: The action to take (approve, waitlist, deny)
            
        Returns:
            True if successful, False otherwise
        """
        applicant = self.applicants.get(applicant_id)
        if not applicant:
            return False
            
        try:
            status = ApplicationStatus(action.lower())
            applicant.status = status
            self.lease_applications.append({
                "applicant_id": applicant_id,
                "action": action,
                "timestamp": datetime.datetime.now()
            })
            return True
        except ValueError:
            return False

    def get_daily_report(self) -> Dict:
        """Generate a daily report of application statuses"""
        report = {
            "report_date": datetime.datetime.now().date().isoformat(),
            "total_pending": 0,
            "total_approved": 0,
            "total_denied": 0,
            "total_waitlisted": 0
        }
        
        for applicant in self.applicants.values():
            if applicant.status == ApplicationStatus.PENDING:
                report["total_pending"] += 1
            elif applicant.status == ApplicationStatus.APPROVED:
                report["total_approved"] += 1
            elif applicant.status == ApplicationStatus.DENIED:
                report["total_denied"] += 1
            elif applicant.status == ApplicationStatus.WAITLISTED:
                report["total_waitlisted"] += 1
                
        return report

    def get_priority_applicants(self, limit: int = 10) -> List[Dict]:
        """
        Get applicants prioritized by household structure similarity
        
        Args:
            limit: Maximum number of applicants to return
            
        Returns:
            List of applicant information sorted by similarity score
        """
        # Sort by similarity score
        sorted_scores = sorted(self.similarity_scores, 
                              key=lambda x: x["similarity_score"], 
                              reverse=True)
        
        # Get top applicants
        top_applicants = []
        for score_info in sorted_scores[:limit]:
            applicant = self.applicants.get(score_info["applicant_id"])
            if applicant:
                top_applicants.append({
                    "applicant_id": applicant.applicant_id,
                    "name": applicant.name,
                    "similarity_score": score_info["similarity_score"],
                    "viability_score": applicant.tenant_viability_score,
                    "best_match": score_info["best_match"]
                })
        
        return top_applicants

    def get_applicant(self, applicant_id: str) -> Optional[Applicant]:
        """Retrieve an applicant by ID"""
        return self.applicants.get(applicant_id)

    def get_all_applicants(self) -> List[Applicant]:
        """Retrieve all applicants"""
        return list(self.applicants.values())


# Example usage and test functions
def create_sample_applicants(system: HousingAllocationSystem):
    """Create sample applicants for testing"""
    
    # Applicant 1
    applicant1 = Applicant(
        applicant_id="A001",
        name="John Smith",
        financial_history=FinancialHistory(
            annual_income=65000,
            credit_score=720,
            rental_history=[{"landlord": "ABC Rentals", "status": "good"}],
            debt_to_income_ratio=0.3,
            savings=15000
        ),
        household_structure=HouseholdStructure(
            household_size=2,
            age_composition=[35, 32],
            family_status="couple",
            special_needs=[]
        ),
        employment=Employment(
            employment_status="employed",
            occupation="Software Engineer",
            employer="Tech Corp",
            years_employed=3,
            monthly_income=5416.67
        ),
        application_date=datetime.datetime.now()
    )
    
    # Applicant 2
    applicant2 = Applicant(
        applicant_id="A002",
        name="Sarah Johnson",
        financial_history=FinancialHistory(
            annual_income=45000,
            credit_score=680,
            rental_history=[{"landlord": "XYZ Rentals", "status": "good"}],
            debt_to_income_ratio=0.4,
            savings=8000
        ),
        household_structure=HouseholdStructure(
            household_size=3,
            age_composition=[30, 28, 5],
            family_status="family",
            special_needs=["childcare"]
        ),
        employment=Employment(
            employment_status="employed",
            occupation="Teacher",
            employer="District School",
            years_employed=5,
            monthly_income=3750
        ),
        application_date=datetime.datetime.now()
    )
    
    # Applicant 3
    applicant3 = Applicant(
        applicant_id="A003",
        name="Michael Brown",
        financial_history=FinancialHistory(
            annual_income=80000,
            credit_score=750,
            rental_history=[{"landlord": "DEF Rentals", "status": "good"}],
            debt_to_income_ratio=0.25,
            savings=25000
        ),
        household_structure=HouseholdStructure(
            household_size=1,
            age_composition=[45],
            family_status="single",
            special_needs=[]
        ),
        employment=Employment(
            employment_status="self_employed",
            occupation="Consultant",
            employer="Self",
            years_employed=7,
            monthly_income=6666.67
        ),
        application_date=datetime.datetime.now()
    )
    
    system.add_applicant(applicant1)
    system.add_applicant(applicant2)
    system.add_applicant(applicant3)


def main():
    """Main function to demonstrate the housing allocation system"""
    print("Housing Allocation System Demo")
    print("=" * 40)
    
    # Initialize the system
    system = HousingAllocationSystem()
    
    # Create sample applicants
    create_sample_applicants(system)
    
    # Display all applicants with their scores
    print("\nApplicants and Their Scores:")
    print("-" * 40)
    for applicant in system.get_all_applicants():
        print(f"ID: {applicant.applicant_id}")
        print(f"Name: {applicant.name}")
        print(f"Viability Score: {applicant.tenant_viability_score}")
        print(f"Status: {applicant.status.value}")
        print("-" * 40)
    
    # Process some applications
    print("\nProcessing Applications:")
    print("-" * 40)
    system.process_application("A001", "approve")
    system.process_application("A002", "waitlist")
    system.process_application("A003", "deny")
    
    # Generate and display daily report
    report = system.get_daily_report()
    print("\nDaily Report:")
    print("-" * 20)
    print(f"Date: {report['report_date']}")
    print(f"Approved: {report['total_approved']}")
    print(f"Denied: {report['total_denied']}")
    print(f"Waitlisted: {report['total_waitlisted']}")
    print(f"Pending: {report['total_pending']}")
    
    # Show priority applicants
    print("\nPriority Applicants (by similarity):")
    print("-" * 30)
    priority_applicants = system.get_priority_applicants(3)
    for i, applicant in enumerate(priority_applicants, 1):
        print(f"{i}. {applicant['name']} - Similarity: {applicant['similarity_score']:.2f}")


if __name__ == "__main__":
    main()