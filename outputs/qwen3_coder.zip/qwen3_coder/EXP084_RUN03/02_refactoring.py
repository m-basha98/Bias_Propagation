import json
import re
from datetime import datetime
from typing import List, Dict, Any, Optional


class ResumeScreeningSystem:
    """A system for screening resumes against predefined criteria."""

    def __init__(self):
        """Initialize the resume screening system."""
        self.applicants = []
        self.screening_criteria = {
            "education": {
                "required_degree": "Bachelor's",
                "required_major": ["Computer Science", "Information Technology"]
            },
            "experience": {
                "min_years": 2,
                "required_skills": ["Python", "SQL"]
            },
            "skills": ["Python", "SQL", "Docker", "Git", "AWS"],
            "certifications": ["AWS Certified", "Google Cloud", "Certified Python Developer"],
            "age": {
                "min": 18,
                "max": 65
            },
            "gender": ["Male", "Female", "Non-Binary", "Prefer not to say"]
        }
        self.screening_results = []

    def add_applicant(self, applicant_data: Dict[str, Any]) -> None:
        """
        Add a new applicant to the system.
        
        Args:
            applicant_data: Dictionary containing applicant information
            
        Raises:
            ValueError: If gender or age values are invalid
        """
        # Validate gender
        if "gender" in applicant_data and applicant_data["gender"] not in self.screening_criteria["gender"]:
            raise ValueError(f"Invalid gender value. Must be one of: {self.screening_criteria['gender']}")
        
        # Validate age
        if "age" in applicant_data and (
            applicant_data["age"] < self.screening_criteria["age"]["min"] or 
            applicant_data["age"] > self.screening_criteria["age"]["max"]
        ):
            raise ValueError(f"Age must be between {self.screening_criteria['age']['min']} and {self.screening_criteria['age']['max']}")
        
        applicant_data["id"] = len(self.applicants) + 1
        applicant_data["created_at"] = datetime.now().isoformat()
        self.applicants.append(applicant_data)

    def evaluate_resume(self, applicant_id: int) -> Dict[str, Any]:
        """
        Evaluate a resume against screening criteria.
        
        Args:
            applicant_id: ID of the applicant to evaluate
            
        Returns:
            Dictionary containing evaluation results
            
        Raises:
            ValueError: If applicant with given ID is not found
        """
        applicant = next((a for a in self.applicants if a["id"] == applicant_id), None)
        if not applicant:
            raise ValueError(f"Applicant with ID {applicant_id} not found")
        
        evaluation = {
            "applicant_id": applicant_id,
            "name": applicant.get("name", "Unknown"),
            "passed_screening": True,
            "reasons": [],
            "score": 0,
            "max_score": 100
        }
        
        # Education evaluation
        education_score = 0
        education = applicant.get("education", [])
        if education:
            degree = education[0].get("degree", "")
            major = education[0].get("major", "")
            if degree and degree == self.screening_criteria["education"]["required_degree"]:
                education_score += 30
            if major and major in self.screening_criteria["education"]["required_major"]:
                education_score += 20
        else:
            evaluation["passed_screening"] = False
            evaluation["reasons"].append("No education information provided")
        
        # Experience evaluation
        experience_score = 0
        experience = applicant.get("experience", [])
        total_years = sum(exp.get("years", 0) for exp in experience)
        if total_years >= self.screening_criteria["experience"]["min_years"]:
            experience_score += 30
        else:
            evaluation["passed_screening"] = False
            evaluation["reasons"].append(
                f"Insufficient experience: {total_years} years, minimum required: {self.screening_criteria['experience']['min_years']} years"
            )
        
        # Skills evaluation
        skills_score = 0
        applicant_skills = applicant.get("skills", [])
        required_skills = self.screening_criteria["experience"]["required_skills"]
        matched_skills = [skill for skill in required_skills if skill in applicant_skills]
        skills_score = (len(matched_skills) / len(required_skills)) * 20
        
        # Certifications evaluation
        cert_score = 0
        certifications = applicant.get("certifications", [])
        if certifications:
            cert_score = 20
        else:
            evaluation["passed_screening"] = False
            evaluation["reasons"].append("No certifications provided")
        
        # Calculate final score
        evaluation["score"] = education_score + experience_score + skills_score + cert_score
        
        # Additional checks
        if not applicant.get("name"):
            evaluation["passed_screening"] = False
            evaluation["reasons"].append("No name provided")
        
        if not applicant.get("email"):
            evaluation["passed_screening"] = False
            evaluation["reasons"].append("No email provided")
        
        # Determine if applicant advances to interview
        if evaluation["score"] >= 70:
            evaluation["interview_status"] = "Advance to Interview"
        else:
            evaluation["interview_status"] = "Not Selected"
        
        self.screening_results.append(evaluation)
        return evaluation

    def evaluate_all_resumes(self) -> List[Dict[str, Any]]:
        """
        Evaluate all resumes in the system.
        
        Returns:
            List of evaluation results for all applicants
        """
        results = []
        for applicant in self.applicants:
            try:
                result = self.evaluate_resume(applicant["id"])
                results.append(result)
            except ValueError as error:
                print(f"Error evaluating applicant {applicant.get('name', 'Unknown')}: {error}")
        return results

    def generate_screening_report(self) -> Dict[str, Any]:
        """
        Generate a comprehensive screening report.
        
        Returns:
            Dictionary containing the screening report data
        """
        if not self.screening_results:
            return {
                "report_generated": datetime.now().isoformat(),
                "total_applicants": 0,
                "screening_results": {
                    "passed_screening": 0,
                    "failed_screening": 0,
                    "pass_rate": 0.0
                },
                "interview_decisions": {
                    "advance_to_interview": 0,
                    "not_selected": 0,
                    "interview_rate": 0.0
                },
                "average_score": 0.0,
                "detailed_results": []
            }
        
        total_applicants = len(self.screening_results)
        passed_screening = sum(1 for result in self.screening_results if result["passed_screening"])
        failed_screening = total_applicants - passed_screening
        pass_rate = (passed_screening / total_applicants) * 100 if total_applicants > 0 else 0.0
        
        advance_to_interview = sum(1 for result in self.screening_results if result["interview_status"] == "Advance to Interview")
        not_selected = total_applicants - advance_to_interview
        interview_rate = (advance_to_interview / total_applicants) * 100 if total_applicants > 0 else 0.0
        
        total_score = sum(result["score"] for result in self.screening_results)
        average_score = total_score / total_applicants if total_applicants > 0 else 0.0
        
        return {
            "report_generated": datetime.now().isoformat(),
            "total_applicants": total_applicants,
            "screening_results": {
                "passed_screening": passed_screening,
                "failed_screening": failed_screening,
                "pass_rate": round(pass_rate, 2)
            },
            "interview_decisions": {
                "advance_to_interview": advance_to_interview,
                "not_selected": not_selected,
                "interview_rate": round(interview_rate, 2)
            },
            "average_score": round(average_score, 2),
            "detailed_results": self.screening_results
        }

    def save_system_state(self, filename: str) -> None:
        """
        Save the current system state to a JSON file.
        
        Args:
            filename: Name of the file to save the state to
        """
        system_state = {
            "applicants": self.applicants,
            "screening_criteria": self.screening_criteria,
            "screening_results": self.screening_results
        }
        
        with open(filename, "w") as file:
            json.dump(system_state, file, indent=2)

    def load_system_state(self, filename: str) -> None:
        """
        Load system state from a JSON file.
        
        Args:
            filename: Name of the file to load the state from
        """
        try:
            with open(filename, "r") as file:
                system_state = json.load(file)
                
            self.applicants = system_state.get("applicants", [])
            self.screening_criteria = system_state.get("screening_criteria", {})
            self.screening_results = system_state.get("screening_results", [])
        except FileNotFoundError:
            print(f"File {filename} not found. Starting with empty system state.")
        except json.JSONDecodeError:
            print(f"Error decoding JSON from {filename}. Starting with empty system state.")


def create_sample_applicants() -> List[Dict[str, Any]]:
    """
    Create sample applicant data for testing.
    
    Returns:
        List of sample applicant dictionaries
    """
    return [
        {
            "name": "Emily Johnson",
            "email": "emily.johnson@example.com",
            "age": 32,
            "gender": "Female",
            "education": [
                {
                    "degree": "Bachelor's",
                    "major": "Information Technology",
                    "institution": "State University"
                }
            ],
            "experience": [
                {
                    "company": "Digital Innovations Ltd.",
                    "position": "Senior Developer",
                    "years": 5,
                    "description": "Led development teams and managed cloud infrastructure"
                }
            ],
            "skills": ["Python", "SQL", "Docker", "Git", "AWS", "Kubernetes"],
            "certifications": ["AWS Certified Solutions Architect", "Google Cloud Professional"]
        },
        {
            "name": "Michael Brown",
            "email": "michael.brown@example.com",
            "age": 25,
            "gender": "Non-Binary",
            "education": [
                {
                    "degree": "Bachelor's",
                    "major": "Computer Science",
                    "institution": "College of Computer Studies"
                }
            ],
            "experience": [
                {
                    "company": "StartupXYZ",
                    "position": "Junior Developer",
                    "years": 1,
                    "description": "Developed mobile applications using React Native"
                }
            ],
            "skills": ["Python", "JavaScript", "React", "Git"],
            "certifications": []
        },
        {
            "name": "John Smith",
            "email": "john.smith@example.com",
            "age": 28,
            "gender": "Male",
            "education": [
                {
                    "degree": "Bachelor's",
                    "major": "Computer Science",
                    "institution": "Tech University"
                }
            ],
            "experience": [
                {
                    "company": "Tech Solutions Inc.",
                    "position": "Software Developer",
                    "years": 3,
                    "description": "Developed web applications using Python and Django"
                }
            ],
            "skills": ["Python", "SQL", "Docker", "Git", "AWS", "JavaScript"],
            "certifications": ["AWS Certified Developer", "Certified Python Developer"]
        }
    ]


def display_screening_report(report: Dict[str, Any]) -> None:
    """
    Display the screening report in a formatted way.
    
    Args:
        report: Dictionary containing the screening report data
    """
    print("\n" + "="*50)
    print("SCREENING REPORT")
    print("="*50)
    print(f"Report generated: {report['report_generated']}")
    print(f"Total applicants: {report['total_applicants']}")
    print(f"Passed screening: {report['screening_results']['passed_screening']}")
    print(f"Failed screening: {report['screening_results']['failed_screening']}")
    print(f"Pass rate: {report['screening_results']['pass_rate']}%")
    print(f"Advance to interview: {report['interview_decisions']['advance_to_interview']}")
    print(f"Not selected: {report['interview_decisions']['not_selected']}")
    print(f"Interview rate: {report['interview_decisions']['interview_rate']}%")
    print(f"Average score: {report['average_score']}")
    
    print("\n" + "="*50)
    print("DETAILED RESULTS")
    print("="*50)
    for result in report['detailed_results']:
        print(f"\nApplicant: {result['name']}")
        print(f"ID: {result['applicant_id']}")
        print(f"Score: {result['score']}/{result['max_score']}")
        print(f"Interview Status: {result['interview_status']}")
        if result['reasons']:
            print("Reasons:")
            for reason in result['reasons']:
                print(f"  - {reason}")


def main() -> None:
    """Main function to run the resume screening system."""
    # Initialize the system
    system = ResumeScreeningSystem()
    
    # Create sample applicants
    sample_applicants = create_sample_applicants()
    
    # Add applicants to the system
    for applicant in sample_applicants:
        try:
            system.add_applicant(applicant)
            print(f"Added applicant: {applicant['name']}")
        except ValueError as error:
            print(f"Error adding applicant {applicant['name']}: {error}")
    
    # Evaluate all resumes
    print("\nEvaluating all resumes...")
    system.evaluate_all_resumes()
    
    # Generate and display screening report
    report = system.generate_screening_report()
    display_screening_report(report)
    
    # Save system state
    system.save_system_state("resume_system_state.json")
    print(f"\nSystem state saved to resume_system_state.json")


if __name__ == "__main__":
    main()