# Technical Documentation for Resume Screening System

## Overview

The Resume Screening System is a Python-based application designed to automate the evaluation of job applicants' resumes against predefined screening criteria. The system stores applicant information, evaluates resumes against set criteria, determines interview eligibility, and generates comprehensive screening reports.

## Class: ResumeScreeningSystem

### Description
The main class that manages the entire resume screening process, including storing applicants, evaluating resumes, and generating reports.

### Constructor: `__init__(self)`

#### Description
Initializes the resume screening system with default screening criteria and empty data structures.

#### Parameters
None

#### Returns
None

#### Attributes
- `applicants`: List to store all applicant data
- `screening_criteria`: Dictionary containing all screening requirements
- `screening_results`: List to store evaluation results

## Methods

### Method: `add_applicant(self, applicant_data: Dict[str, Any]) -> None`

#### Description
Adds a new applicant to the system after validating gender and age values.

#### Parameters
- `applicant_data` (Dict[str, Any]): Dictionary containing applicant information including:
  - `name` (str): Applicant's full name
  - `email` (str): Applicant's email address
  - `age` (int): Applicant's age
  - `gender` (str): Applicant's gender
  - `education` (List[Dict]): List of education records
  - `experience` (List[Dict]): List of work experience records
  - `skills` (List[str]): List of applicant's skills
  - `certifications` (List[str]): List of applicant's certifications

#### Returns
None

#### Raises
- `ValueError`: If gender value is invalid or age is outside the allowed range

### Method: `evaluate_resume(self, applicant_id: int) -> Dict[str, Any]`

#### Description
Evaluates a single resume against predefined screening criteria and determines if the applicant advances to the interview stage.

#### Parameters
- `applicant_id` (int): ID of the applicant to evaluate

#### Returns
Dictionary containing evaluation results with the following keys:
- `applicant_id` (int): ID of the applicant
- `name` (str): Applicant's name
- `passed_screening` (bool): Whether the applicant passed initial screening
- `reasons` (List[str]): List of reasons for screening failure
- `score` (int): Total score achieved (0-100)
- `max_score` (int): Maximum possible score (100)
- `interview_status` (str): "Advance to Interview" or "Not Selected"

#### Raises
- `ValueError`: If applicant with given ID is not found

### Method: `evaluate_all_resumes(self) -> List[Dict[str, Any]]`

#### Description
Evaluates all resumes in the system.

#### Parameters
None

#### Returns
List of evaluation results for all applicants

#### Raises
None

### Method: `generate_screening_report(self) -> Dict[str, Any]`

#### Description
Generates a comprehensive screening report summarizing all evaluations.

#### Parameters
None

#### Returns
Dictionary containing the complete screening report with the following structure:
- `report_generated` (str): Timestamp of report generation
- `total_applicants` (int): Total number of applicants evaluated
- `screening_results` (Dict): Screening statistics:
  - `passed_screening` (int): Number of applicants who passed screening
  - `failed_screening` (int): Number of applicants who failed screening
  - `pass_rate` (float): Percentage of applicants who passed screening
- `interview_decisions` (Dict): Interview decision statistics:
  - `advance_to_interview` (int): Number of applicants advancing to interview
  - `not_selected` (int): Number of applicants not selected
  - `interview_rate` (float): Percentage of applicants advancing to interview
- `average_score` (float): Average score of all applicants
- `detailed_results` (List[Dict]): List of individual applicant evaluation results

### Method: `save_system_state(self, filename: str) -> None`

#### Description
Saves the current system state to a JSON file.

#### Parameters
- `filename` (str): Name of the file to save the state to

#### Returns
None

#### Raises
None

### Method: `load_system_state(self, filename: str) -> None`

#### Description
Loads system state from a JSON file.

#### Parameters
- `filename` (str): Name of the file to load the state from

#### Returns
None

#### Raises
- `FileNotFoundError`: If the specified file is not found
- `json.JSONDecodeError`: If the file contains invalid JSON

## Helper Functions

### Function: `create_sample_applicants() -> List[Dict[str, Any]]`

#### Description
Creates sample applicant data for testing purposes.

#### Parameters
None

#### Returns
List of sample applicant dictionaries with realistic data for testing

### Function: `display_screening_report(report: Dict[str, Any]) -> None`

#### Description
Displays the screening report in a formatted, human-readable way.

#### Parameters
- `report` (Dict[str, Any]): Dictionary containing the screening report data

#### Returns
None

## Main Function

### Function: `main() -> None`

#### Description
Main function that orchestrates the entire resume screening process:
1. Initializes the system
2. Creates sample applicants
3. Adds applicants to the system
4. Evaluates all resumes
5. Generates and displays the screening report
6. Saves the system state

#### Parameters
None

#### Returns
None

## System Requirements

### Prerequisites
- Python 3.6 or higher
- No external dependencies (uses only standard library modules)

### Data Structure Requirements
- All applicant data must be provided in the specified dictionary format
- Age must be a valid integer within the allowed range
- Gender must be one of the predefined valid values
- All required fields must be present for proper evaluation

## Usage Example

```python
# Initialize the system
system = ResumeScreeningSystem()

# Add sample applicants
sample_applicants = create_sample_applicants()
for applicant in sample_applicants:
    system.add_applicant(applicant)

# Evaluate all resumes
system.evaluate_all_resumes()

# Generate and display report
report = system.generate_screening_report()
display_screening_report(report)
```

## Security Considerations

- The system validates gender values against predefined acceptable values
- Age validation prevents invalid age entries
- No external data sources are accessed, reducing security risks
- System state files are saved in plain JSON format (no encryption)

## Performance Considerations

- The system is designed for batch processing of applicants
- Evaluation algorithm is optimized for typical applicant datasets
- Memory usage scales linearly with the number of applicants
- No database connections required, reducing external dependencies

## Extensibility

The system can be easily extended by:
- Modifying screening criteria in the constructor
- Adding new evaluation metrics
- Implementing additional data validation rules
- Extending the reporting functionality
- Adding new data sources for applicant information