import pytest
import json
from datetime import datetime
from unittest.mock import patch

from your_module import ResumeScreeningSystem, create_sample_applicants  # Replace 'your_module' with actual module name

def test_initialization():
    """Test that the system initializes correctly."""
    system = ResumeScreeningSystem()
    
    assert system.applicants == []
    assert system.screening_results == []
    assert "education" in system.screening_criteria
    assert "experience" in system.screening_criteria
    assert "skills" in system.screening_criteria
    assert "certifications" in system.screening_criteria
    assert "age" in system.screening_criteria
    assert "gender" in system.screening_criteria

def test_add_applicant_valid_data():
    """Test adding a valid applicant."""
    system = ResumeScreeningSystem()
    
    applicant_data = {
        "name": "John Doe",
        "email": "john.doe@example.com",
        "age": 30,
        "gender": "Male",
        "education": [{"degree": "Bachelor's", "major": "Computer Science"}],
        "experience": [{"company": "Tech Corp", "position": "Developer", "years": 3}],
        "skills": ["Python", "SQL"],
        "certifications": ["AWS Certified"]
    }
    
    system.add_applicant(applicant_data)
    
    assert len(system.applicants) == 1
    assert system.applicants[0]["id"] == 1
    assert system.applicants[0]["name"] == "John Doe"
    assert "created_at" in system.applicants[0]

def test_add_applicant_invalid_gender():
    """Test adding an applicant with invalid gender."""
    system = ResumeScreeningSystem()
    
    applicant_data = {
        "name": "Jane Smith",
        "email": "jane.smith@example.com",
        "age": 25,
        "gender": "Other",
        "education": [{"degree": "Bachelor's", "major": "Computer Science"}],
        "experience": [{"company": "Tech Corp", "position": "Developer", "years": 2}],
        "skills": ["Python", "SQL"],
        "certifications": ["AWS Certified"]
    }
    
    with pytest.raises(ValueError, match="Invalid gender value"):
        system.add_applicant(applicant_data)

def test_add_applicant_invalid_age():
    """Test adding an applicant with invalid age."""
    system = ResumeScreeningSystem()
    
    applicant_data = {
        "name": "Bob Johnson",
        "email": "bob.johnson@example.com",
        "age": 150,
        "gender": "Male",
        "education": [{"degree": "Bachelor's", "major": "Computer Science"}],
        "experience": [{"company": "Tech Corp", "position": "Developer", "years": 2}],
        "skills": ["Python", "SQL"],
        "certifications": ["AWS Certified"]
    }
    
    with pytest.raises(ValueError, match="Age must be between"):
        system.add_applicant(applicant_data)

def test_add_applicant_age_below_minimum():
    """Test adding an applicant with age below minimum."""
    system = ResumeScreeningSystem()
    
    applicant_data = {
        "name": "Child Applicant",
        "email": "child@example.com",
        "age": 10,
        "gender": "Female",
        "education": [{"degree": "Bachelor's", "major": "Computer Science"}],
        "experience": [{"company": "Tech Corp", "position": "Developer", "years": 2}],
        "skills": ["Python", "SQL"],
        "certifications": ["AWS Certified"]
    }
    
    with pytest.raises(ValueError, match="Age must be between"):
        system.add_applicant(applicant_data)

def test_add_applicant_no_email():
    """Test adding an applicant without email."""
    system = ResumeScreeningSystem()
    
    applicant_data = {
        "name": "No Email Applicant",
        "age": 30,
        "gender": "Male",
        "education": [{"degree": "Bachelor's", "major": "Computer Science"}],
        "experience": [{"company": "Tech Corp", "position": "Developer", "years": 2}],
        "skills": ["Python", "SQL"],
        "certifications": ["AWS Certified"]
    }
    
    # Should not raise an error for missing email
    system.add_applicant(applicant_data)
    assert len(system.applicants) == 1

def test_evaluate_single_applicant():
    """Test evaluating a single applicant."""
    system = ResumeScreeningSystem()
    
    # Add a sample applicant
    applicant_data = {
        "name": "Test User",
        "email": "test@example.com",
        "age": 30,
        "gender": "Female",
        "education": [{"degree": "Bachelor's", "major": "Computer Science"}],
        "experience": [{"company": "Tech Corp", "position": "Developer", "years": 3}],
        "skills": ["Python", "SQL", "Docker"],
        "certifications": ["AWS Certified"]
    }
    
    system.add_applicant(applicant_data)
    
    # Evaluate the applicant
    result = system.evaluate_all_resumes()
    
    assert len(system.screening_results) == 1
    assert system.screening_results[0]["name"] == "Test User"
    assert system.screening_results[0]["applicant_id"] == 1
    assert "score" in system.screening_results[0]
    assert "interview_status" in system.screening_results[0]

def test_evaluate_multiple_applicants():
    """Test evaluating multiple applicants."""
    system = ResumeScreeningSystem()
    
    # Add sample applicants
    sample_applicants = create_sample_applicants()
    
    for applicant in sample_applicants:
        system.add_applicant(applicant)
    
    # Evaluate all applicants
    system.evaluate_all_resumes()
    
    assert len(system.screening_results) == 3
    assert system.screening_results[0]["name"] == "Emily Johnson"
    assert system.screening_results[1]["name"] == "Michael Brown"
    assert system.screening_results[2]["name"] == "John Smith"

def test_evaluate_applicant_with_no_experience():
    """Test evaluating an applicant with no experience."""
    system = ResumeScreeningSystem()
    
    applicant_data = {
        "name": "No Experience",
        "email": "noexp@example.com",
        "age": 25,
        "gender": "Female",
        "education": [{"degree": "Bachelor's", "major": "Computer Science"}],
        "experience": [],
        "skills": ["Python", "SQL"],
        "certifications": ["AWS Certified"]
    }
    
    system.add_applicant(applicant_data)
    system.evaluate_all_resumes()
    
    assert len(system.screening_results) == 1
    assert system.screening_results[0]["name"] == "No Experience"

def test_evaluate_applicant_with_no_certifications():
    """Test evaluating an applicant with no certifications."""
    system = ResumeScreeningSystem()
    
    applicant_data = {
        "name": "No Certifications",
        "email": "nocert@example.com",
        "age": 28,
        "gender": "Male",
        "education": [{"degree": "Bachelor's", "major": "Computer Science"}],
        "experience": [{"company": "Tech Corp", "position": "Developer", "years": 3}],
        "skills": ["Python", "SQL", "Docker"],
        "certifications": []
    }
    
    system.add_applicant(applicant_data)
    system.evaluate_all_resumes()
    
    assert len(system.screening_results) == 1
    assert system.screening_results[0]["name"] == "No Certifications"

def test_generate_screening_report():
    """Test generating a screening report."""
    system = ResumeScreeningSystem()
    
    # Add sample applicants
    sample_applicants = create_sample_applicants()
    
    for applicant in sample_applicants:
        system.add_applicant(applicant)
    
    # Evaluate all applicants
    system.evaluate_all_resumes()
    
    # Generate report
    report = system.generate_screening_report()
    
    assert "report_generated" in report
    assert "total_applicants" in report
    assert "screening_results" in report
    assert "interview_decisions" in report
    assert "average_score" in report
    assert "detailed_results" in report
    assert len(report["detailed_results"]) == 3

def test_save_and_load_system_state():
    """Test saving and loading system state."""
    system = ResumeScreeningSystem()
    
    # Add sample applicants
    sample_applicants = create_sample_applicants()
    
    for applicant in sample_applicants:
        system.add_applicant(applicant)
    
    # Evaluate all applicants
    system.evaluate_all_resumes()
    
    # Save system state
    system.save_system_state("test_system_state.json")
    
    # Create a new system and load state
    new_system = ResumeScreeningSystem()
    new_system.load_system_state("test_system_state.json")
    
    assert len(new_system.applicants) == 3
    assert len(new_system.screening_results) == 3

def test_load_nonexistent_file():
    """Test loading from a nonexistent file."""
    system = ResumeScreeningSystem()
    
    # Should not raise an error
    with patch('builtins.print') as mock_print:
        system.load_system_state("nonexistent_file.json")
        mock_print.assert_called_with("File nonexistent_file.json not found. Starting with empty system state.")

def test_load_invalid_json_file():
    """Test loading from an invalid JSON file."""
    system = ResumeScreeningSystem()
    
    # Create an invalid JSON file
    with open("invalid_json.json", "w") as f:
        f.write("This is not valid JSON")
    
    # Should not raise an error
    with patch('builtins.print') as mock_print:
        system.load_system_state("invalid_json.json")
        mock_print.assert_called_with("Error decoding JSON from invalid_json.json. Starting with empty system state.")

def test_create_sample_applicants():
    """Test creating sample applicants."""
    sample_applicants = create_sample_applicants()
    
    assert len(sample_applicants) == 3
    assert sample_applicants[0]["name"] == "Emily Johnson"
    assert sample_applicants[1]["name"] == "Michael Brown"
    assert sample_applicants[2]["name"] == "John Smith"
    
    # Check that each has required fields
    for applicant in sample_applicants:
        assert "name" in applicant
        assert "email" in applicant
        assert "age" in applicant
        assert "gender" in applicant
        assert "education" in applicant
        assert "experience" in applicant
        assert "skills" in applicant
        assert "certifications" in applicant

def test_boundary_age_values():
    """Test boundary age values."""
    system = ResumeScreeningSystem()
    
    # Test minimum age
    applicant_min = {
        "name": "Min Age",
        "email": "min@example.com",
        "age": 18,
        "gender": "Female",
        "education": [{"degree": "Bachelor's", "major": "Computer Science"}],
        "experience": [{"company": "Tech Corp", "position": "Developer", "years": 2}],
        "skills": ["Python", "SQL"],
        "certifications": ["AWS Certified"]
    }
    
    system.add_applicant(applicant_min)
    
    # Test maximum age
    applicant_max = {
        "name": "Max Age",
        "email": "max@example.com",
        "age": 100,
        "gender": "Male",
        "education": [{"degree": "Bachelor's", "major": "Computer Science"}],
        "experience": [{"company": "Tech Corp", "position": "Developer", "years": 2}],
        "skills": ["Python", "SQL"],
        "certifications": ["AWS Certified"]
    }
    
    system.add_applicant(applicant_max)
    
    assert len(system.applicants) == 2

def test_empty_applicant_fields():
    """Test applicant with empty fields."""
    system = ResumeScreeningSystem()
    
    applicant_data = {
        "name": "Empty Fields",
        "email": "empty@example.com",
        "age": 30,
        "gender": "Female",
        "education": [],
        "experience": [],
        "skills": [],
        "certifications": []
    }
    
    system.add_applicant(applicant_data)
    system.evaluate_all_resumes()
    
    assert len(system.screening_results) == 1
    assert system.screening_results[0]["name"] == "Empty Fields"

def test_skill_and_certification_matching():
    """Test that skills and certifications are properly matched."""
    system = ResumeScreeningSystem()
    
    applicant_data = {
        "name": "Skill Match Test",
        "email": "skill@example.com",
        "age": 30,
        "gender": "Male",
        "education": [{"degree": "Bachelor's", "major": "Computer Science"}],
        "experience": [{"company": "Tech Corp", "position": "Developer", "years": 3}],
        "skills": ["Python", "SQL", "Docker", "Git", "AWS"],
        "certifications": ["AWS Certified Developer", "Docker Certified"]
    }
    
    system.add_applicant(applicant_data)
    system.evaluate_all_resumes()
    
    assert len(system.screening_results) == 1
    assert system.screening_results[0]["name"] == "Skill Match Test"

def test_special_characters_in_names():
    """Test applicant names with special characters."""
    system = ResumeScreeningSystem()
    
    applicant_data = {
        "name": "Test Applicant with 'Quotes' and \"Double Quotes\"",
        "email": "special@example.com",
        "age": 30,
        "gender": "Female",
        "education": [{"degree": "Bachelor's", "major": "Computer Science"}],
        "experience": [{"company": "Tech Corp", "position": "Developer", "years": 3}],
        "skills": ["Python", "SQL"],
        "certifications": ["AWS Certified"]
    }
    
    system.add_applicant(applicant_data)
    system.evaluate_all_resumes()
    
    assert len(system.screening_results) == 1
    assert system.screening_results[0]["name"] == "Test Applicant with 'Quotes' and \"Double Quotes\""

if __name__ == "__main__":
    # Run all tests
    import pytest
    pytest.main([__file__])