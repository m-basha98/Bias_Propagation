# Comprehensive Unit Tests for Admissions Screening System

Here's a comprehensive suite of unit tests for the admissions screening system, covering edge cases, boundary conditions, and standard input scenarios:

```python
import pytest
from unittest.mock import patch, MagicMock
from datetime import datetime
import csv
import json
import os
from collections import defaultdict

from your_module import Applicant, AdmissionsScreeningSystem  # Replace 'your_module' with actual module name

# Test data
TEST_APPLICANT = Applicant(
    id="001",
    name="Test Applicant",
    gpa=3.5,
    sat_score=1200,
    act_score=24,
    ethnicity="White",
    gender="Female",
    state="CA",
    is_first_generation=True,
    has_financial_need=True,
    extracurriculars=["Debate Team"],
    essays="Essay about leadership"
)

def test_applicant_dataclass():
    """Test that Applicant dataclass works correctly"""
    applicant = Applicant(
        id="001",
        name="Alice Johnson",
        gpa=3.8,
        sat_score=1350,
        act_score=0,
        ethnicity="White",
        gender="Female",
        state="CA",
        is_first_generation=True,
        has_financial_need=True,
        extracurriculars=["Debate Team", "Volunteer Work"],
        essays="Essay about leadership"
    )
    
    assert applicant.id == "001"
    assert applicant.name == "Alice Johnson"
    assert applicant.gpa == 3.8
    assert applicant.sat_score == 1350
    assert applicant.act_score == 0
    assert applicant.ethnicity == "White"
    assert applicant.gender == "Female"
    assert applicant.state == "CA"
    assert applicant.is_first_generation == True
    assert applicant.has_financial_need == True
    assert applicant.extracurriculars == ["Debate Team", "Volunteer Work"]
    assert applicant.essays == "Essay about leadership"

def test_admissions_system_initialization():
    """Test that AdmissionsScreeningSystem initializes correctly"""
    system = AdmissionsScreeningSystem()
    
    assert system.applicants == []
    assert system.score_weights == {
        'gpa': 0.35,
        'sat_score': 0.25,
        'act_score': 0.25,
        'demographics': 0.10,
        'financial_need': 0.05
    }
    assert system.admission_thresholds == {
        'admit': 85.0,
        'waitlist': 70.0
    }
    assert system.state_weights == {
        'CA': 1.1, 'NY': 1.1, 'TX': 1.05, 'FL': 1.05, 'IL': 1.05,
        'GA': 1.05, 'NC': 1.05, 'OH': 1.05, 'PA': 1.05, 'MI': 1.05,
        'other': 1.0
    }
    assert system.ethnicity_weights == {
        'White': 1.0, 'Black': 1.0, 'Hispanic': 1.1, 'Asian': 1.0,
        'Other': 1.05, 'Unknown': 1.0
    }

def test_calculate_gpa_score():
    """Test GPA score calculation"""
    system = AdmissionsScreeningSystem()
    
    # Normal cases
    assert system._calculate_gpa_score(4.0) == 100.0  # Max GPA
    assert system._calculate_gpa_score(0.0) == 0.0    # Min GPA
    assert system._calculate_gpa_score(3.5) == 87.5   # Mid-range GPA
    
    # Boundary conditions
    assert system._calculate_gpa_score(5.0) == 100.0  # Exceeds max
    assert system._calculate_gpa_score(-1.0) == 0.0   # Below min

def test_calculate_sat_score():
    """Test SAT score calculation (should be 0 for invalid inputs)"""
    system = AdmissionsScreeningSystem()
    
    # Valid SAT score
    assert system._calculate_sat_score(1500) == 1500
    
    # Invalid SAT scores
    assert system._calculate_sat_score(-100) == 0
    assert system._calculate_sat_score(2500) == 0  # Beyond max SAT score

def test_calculate_act_score():
    """Test ACT score calculation"""
    system = AdmissionsScreeningSystem()
    
    # Valid ACT score
    assert system._calculate_act_score(36) == 36
    assert system._calculate_act_score(0) == 0
    
    # Invalid ACT scores
    assert system._calculate_act_score(-1) == 0
    assert system._calculate_act_score(40) == 0  # Beyond max ACT score

def test_calculate_demographics_score():
    """Test demographics score calculation"""
    system = AdmissionsScreeningSystem()
    
    # Test with known state weights
    assert system._calculate_demographics_score("CA") == 1.1
    assert system._calculate_demographics_score("TX") == 1.05
    assert system._calculate_demographics_score("XX") == 1.0  # Unknown state
    
    # Test with first generation bonus
    assert system._calculate_demographics_score("CA", first_generation=True) == 1.1
    assert system._calculate_demographics_score("CA", first_generation=False) == 1.1

def test_process_single_applicant():
    """Test processing a single applicant"""
    system = AdmissionsScreeningSystem()
    
    # Mock the load_sample_data to avoid file operations
    with patch.object(system, 'load_sample_data'):
        # Process with a test applicant
        system.applicants = [TEST_APPLICANT]
        results = system.process_all_applicants()
        
        assert len(results) == 1
        assert results[0]['id'] == "001"
        assert results[0]['name'] == "Test Applicant"
        assert 'holistic_score' in results[0]
        assert 'decision' in results[0]

def test_process_multiple_applicants():
    """Test processing multiple applicants"""
    system = AdmissionsScreeningSystem()
    
    applicants = [
        Applicant(
            id="001",
            name="Applicant 1",
            gpa=3.0,
            sat_score=1200,
            act_score=0,
            ethnicity="White",
            gender="Female",
            state="CA",
            is_first_generation=True,
            has_financial_need=False,
            extracurriculars=[],
            essays=""
        ),
        Applicant(
            id="002",
            name="Applicant 2",
            gpa=3.8,
            sat_score=1400,
            act_score=0,
            ethnicity="Hispanic",
            gender="Male",
            state="TX",
            is_first_generation=False,
            has_financial_need=True,
            extracurriculars=[],
            essays=""
        )
    ]
    
    system.applicants = applicants
    results = system.process_all_applicants()
    
    assert len(results) == 2
    assert results[0]['id'] == "001"
    assert results[1]['id'] == "002"
    assert 'holistic_score' in results[0]
    assert 'holistic_score' in results[1]

def test_generate_summary_report_empty():
    """Test generating summary report with empty results"""
    system = AdmissionsScreeningSystem()
    
    report = system.generate_summary_report([])
    
    assert report['total_applicants'] == 0
    assert report['score_statistics']['average'] == 0
    assert report['score_statistics']['max'] == 0
    assert report['score_statistics']['min'] == 0
    assert report['decision_distribution'] == {}
    assert report['state_distribution'] == {}
    assert report['ethnicity_distribution'] == {}

def test_generate_summary_report_with_data():
    """Test generating summary report with sample data"""
    system = AdmissionsScreeningSystem()
    
    results = [
        {
            'id': '001',
            'name': 'Applicant 1',
            'holistic_score': 85.5,
            'decision': 'Admit',
            'demographics': {
                'state': 'CA',
                'ethnicity': 'White'
            }
        },
        {
            'id': '002',
            'name': 'Applicant 2',
            'holistic_score': 70.0,
            'decision': 'Waitlist',
            'demographics': {
                'state': 'NY',
                'ethnicity': 'Hispanic'
            }
        },
        {
            'id': '003',
            'name': 'Applicant 3',
            'holistic_score': 65.0,
            'decision': 'Reject',
            'demographics': {
                'state': 'CA',
                'ethnicity': 'White'
            }
        }
    ]
    
    report = system.generate_summary_report(results)
    
    assert report['total_applicants'] == 3
    assert report['score_statistics']['average'] == 73.5
    assert report['score_statistics']['max'] == 85.5
    assert report['score_statistics']['min'] == 65.0
    assert report['decision_distribution']['Admit'] == 1
    assert report['decision_distribution']['Waitlist'] == 1
    assert report['decision_distribution']['Reject'] == 1
    assert report['state_distribution']['CA'] == 2
    assert report['state_distribution']['NY'] == 1
    assert report['ethnicity_distribution']['White'] == 2
    assert report['ethnicity_distribution']['Hispanic'] == 1

def test_decision_logic():
    """Test that decision logic works correctly"""
    system = AdmissionsScreeningSystem()
    
    # Test different score thresholds
    assert system._determine_decision(90.0) == 'Admit'
    assert system._determine_decision(85.0) == 'Admit'
    assert system._determine_decision(75.0) == 'Waitlist'
    assert system._determine_decision(70.0) == 'Waitlist'
    assert system._determine_decision(60.0) == 'Reject'
    assert system._determine_decision(0.0) == 'Reject'

def test_export_results():
    """Test exporting results to files"""
    system = AdmissionsScreeningSystem()
    
    results = [
        {
            'id': '001',
            'name': 'Applicant 1',
            'gpa': 3.5,
            'sat_score': 1200,
            'act_score': 24,
            'holistic_score': 85.5,
            'decision': 'Admit'
        }
    ]
    
    report = {
        'report_date': '2023-01-01 12:00:00',
        'total_applicants': 1,
        'decision_distribution': {'Admit': 1},
        'score_statistics': {'average': 85.5, 'max': 85.5, 'min': 85.5},
        'state_distribution': {},
        'ethnicity_distribution': {},
        'weighting_system': system.score_weights
    }
    
    # Mock file operations to avoid actual file creation
    with patch('builtins.open', new_callable=MagicMock) as mock_open:
        system.export_results(results, report, "test")
        
        # Check that both files were created
        assert mock_open.call_count == 2
        assert 'test_results.csv' in str(mock_open.call_args_list[0][0])
        assert 'test_report.json' in str(mock_open.call_args_list[1][0])

def test_display_results():
    """Test displaying results (mocked to avoid printing)"""
    system = AdmissionsScreeningSystem()
    
    results = [
        {
            'id': '001',
            'name': 'Applicant 1',
            'holistic_score': 85.5,
            'decision': 'Admit'
        }
    ]
    
    report = {
        'report_date': '2023-01-01 12:00:00',
        'total_applicants': 1,
        'decision_distribution': {'Admit': 1},
        'score_statistics': {'average': 85.5, 'max': 85.5, 'min': 85.5},
        'state_distribution': {},
        'ethnicity_distribution': {},
        'weighting_system': system.score_weights
    }
    
    # Mock print to capture output
    with patch('builtins.print') as mock_print:
        system.display_results(results, report)
        
        # Verify that print was called
        assert mock_print.called

def test_load_sample_data():
    """Test loading sample data"""
    system = AdmissionsScreeningSystem()
    
    # Mock the actual load to avoid file operations
    with patch.object(system, 'load_sample_data') as mock_load:
        system.load_sample_data()
        mock_load.assert_called_once()

def test_run_full_process():
    """Test running the full process"""
    system = AdmissionsScreeningSystem()
    
    # Mock all the methods to avoid file operations
    with patch.object(system, 'load_sample_data'), \
         patch.object(system, 'process_all_applicants') as mock_process, \
         patch.object(system, 'generate_summary_report') as mock_report:
        
        # Mock return values
        mock_process.return_value = [
            {
                'id': '001',
                'name': 'Applicant 1',
                'holistic_score': 85.5,
                'decision': 'Admit'
            }
        ]
        mock_report.return_value = {
            'total_applicants': 1,
            'decision_distribution': {'Admit': 1},
            'score_statistics': {'average': 85.5, 'max': 85.5, 'min': 85.5},
            'state_distribution': {},
            'ethnicity_distribution': {},
            'weighting_system': system.score_weights
        }
        
        # This should not raise any exceptions
        system.run_full_process()

def test_edge_case_scores():
    """Test edge cases for scores"""
    system = AdmissionsScreeningSystem()
    
    # Test with zero scores
    assert system._calculate_score(0, 0, 0, 0) == 0
    
    # Test with maximum scores
    assert system._calculate_score(4.0, 1600, 36, 1.0) == 100.0  # Simplified
    
    # Test with invalid scores
    assert system._calculate_score(-1, -1, -1, -1) == 0

def test_weighting_system():
    """Test that weighting system is properly applied"""
    system = System()
    
    # Check that weights are set correctly
    assert hasattr(system, 'gpa_weight')
    assert hasattr(system, 'sat_weight')
    assert hasattr(system, 'act_weight')
    assert hasattr(system, 'demographics_weight')

def test_error_handling():
    """Test error handling for invalid inputs"""
    system = System()
    
    # Test with invalid inputs
    try:
        system.process_applicant(None)
    except Exception:
        # Should handle gracefully
        pass

if __name__ == "__main__":
    # Run all tests
    import unittest
    unittest.main()