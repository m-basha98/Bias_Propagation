import csv
import json
import random
from datetime import datetime
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from collections import defaultdict

@dataclass
class Applicant:
    """Data class to represent an applicant"""
    id: str
    name: str
    gpa: float
    sat_score: int
    act_score: int
    ethnicity: str
    gender: str
    state: str
    is_first_generation: bool
    has_financial_need: bool
    extracurriculars: List[str]
    essays: str

class AdmissionsScreeningSystem:
    """Main admissions screening system"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.score_weights = {
            'gpa': 0.35,
            'sat_score': 0.25,
            'act_score': 0.25,
            'demographics': 0.10,
            'financial_need': 0.05
        }
        self.admission_thresholds = {
            'admit': 85.0,
            'waitlist': 70.0
        }
        self.state_weights = {
            'CA': 1.1, 'NY': 1.1, 'TX': 1.05, 'FL': 1.05, 'IL': 1.05,
            'GA': 1.05, 'NC': 1.05, 'OH': 1.05, 'PA': 1.05, 'MI': 1.05,
            'other': 1.0
        }
        self.ethnicity_weights = {
            'White': 1.0, 'Black': 1.0, 'Hispanic': 1.1, 'Asian': 1.0,
            'Other': 1.05, 'Unknown': 1.0
        }
        
    def load_sample_data(self):
        """Load sample applicant data for demonstration"""
        sample_applicants = [
            Applicant("001", "Alice Johnson", 3.8, 1350, 0, "White", "Female", "CA", True, True, ["Debate Team", "Volunteer Work"], "Essay about leadership"),
            Applicant("002", "Bob Smith", 3.5, 0, 28, "Hispanic", "Male", "TX", False, True, ["Basketball", "Student Council"], "Essay about overcoming challenges"),
            Applicant("003", "Carol Williams", 3.9, 1420, 0, "Asian", "Female", "NY", True, False, ["Science Club", "Research Project"], "Essay about scientific curiosity"),
            Applicant("004", "David Brown", 3.2, 0, 24, "Black", "Male", "FL", False, True, ["Music Band", "Community Service"], "Essay about community impact"),
            Applicant("005", "Emma Davis", 4.0, 1500, 0, "White", "Female", "IL", False, False, ["Debate Team", "Model UN", "Internship"], "Essay about global perspective"),
            Applicant("006", "Frank Miller", 3.7, 0, 26, "Other", "Male", "GA", True, True, ["Art Club", "Volunteer Work"], "Essay about creative expression"),
            Applicant("007", "Grace Wilson", 3.6, 1280, 0, "Hispanic", "Female", "NC", False, True, ["Science Olympiad", "Student Government"], "Essay about academic excellence"),
            Applicant("008", "Henry Taylor", 3.4, 0, 22, "White", "Male", "OH", False, False, ["Track Team", "Chess Club"], "Essay about perseverance"),
            Applicant("009", "Ivy Anderson", 3.9, 1400, 0, "Asian", "Female", "MI", True, True, ["Research Project", "Internship", "Community Service"], "Essay about innovation"),
            Applicant("010", "Jack Thomas", 3.3, 0, 25, "Black", "Male", "PA", False, True, ["Basketball", "Student Council", "Volunteer Work"], "Essay about leadership")
        ]
        
        self.applicants = sample_applicants
        print(f"Loaded {len(self.applicants)} sample applicants")
    
    def calculate_gpa_score(self, gpa: float) -> float:
        """Convert GPA to standardized score (0-100)"""
        return min(100.0, max(0.0, (gpa / 4.0) * 100.0))
    
    def calculate_test_score(self, sat: int, act: int) -> float:
        """Calculate standardized test score"""
        if sat > 0:
            # SAT score conversion (max 1600)
            return min(100.0, (sat / 1600.0) * 100.0)
        elif act > 0:
            # ACT score conversion (max 36)
            return min(100.0, (act / 36.0) * 100.0)
        else:
            return 0.0
    
    def calculate_demographics_score(self, applicant: Applicant) -> float:
        """Calculate demographic-based score"""
        score = 0.0
        
        # State bonus
        state_weight = self.state_weights.get(applicant.state, self.state_weights['other'])
        score += 5.0 * state_weight
        
        # Ethnicity bonus
        ethnicity_weight = self.ethnicity_weights.get(applicant.ethnicity, self.ethnicity_weights['Unknown'])
        score += 5.0 * ethnicity_weight
        
        # First generation bonus
        if applicant.is_first_generation:
            score += 3.0
            
        # Financial need bonus
        if applicant.has_financial_need:
            score += 2.0
            
        return min(20.0, score)
    
    def calculate_holistic_score(self, applicant: Applicant) -> float:
        """Calculate holistic admission score for an applicant"""
        gpa_score = self.calculate_gpa_score(applicant.gpa)
        test_score = self.calculate_test_score(applicant.sat_score, applicant.act_score)
        demographics_score = self.calculate_demographics_score(applicant)
        
        # Calculate weighted score
        holistic_score = (
            gpa_score * self.score_weights['gpa'] +
            test_score * self.score_weights['sat_score'] +
            test_score * self.score_weights['act_score'] +
            demographics_score * self.score_weights['demographics'] +
            10.0 * self.score_weights['financial_need']  # Simplified financial need score
        )
        
        return holistic_score
    
    def make_admission_decision(self, applicant: Applicant) -> str:
        """Make admission decision based on holistic score"""
        score = self.calculate_holistic_score(applicant)
        
        if score >= self.admission_thresholds['admit']:
            return "Admit"
        elif score >= self.admission_thresholds['waitlist']:
            return "Waitlist"
        else:
            return "Reject"
    
    def process_all_applicants(self) -> List[Dict[str, Any]]:
        """Process all applicants and return results"""
        results = []
        
        for applicant in self.applicants:
            holistic_score = self.calculate_holistic_score(applicant)
            decision = self.make_admission_decision(applicant)
            
            result = {
                'id': applicant.id,
                'name': applicant.name,
                'gpa': applicant.gpa,
                'sat_score': applicant.sat_score,
                'act_score': applicant.act_score,
                'holistic_score': round(holistic_score, 2),
                'decision': decision,
                'demographics': {
                    'ethnicity': applicant.ethnicity,
                    'gender': applicant.gender,
                    'state': applicant.state,
                    'first_generation': applicant.is_first_generation,
                    'financial_need': applicant.has_financial_need
                }
            }
            results.append(result)
        
        return results
    
    def generate_summary_report(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate summary report of cohort statistics"""
        total_applicants = len(results)
        decisions = defaultdict(int)
        scores = [result['holistic_score'] for result in results]
        
        for result in results:
            decisions[result['decision']] += 1
        
        # Calculate statistics
        avg_score = sum(scores) / len(scores) if scores else 0
        max_score = max(scores) if scores else 0
        min_score = min(scores) if scores else 0
        
        # State distribution
        state_counts = defaultdict(int)
        for result in results:
            state_counts[result['demographics']['state']] += 1
        
        # Ethnicity distribution
        ethnicity_counts = defaultdict(int)
        for result in results:
            ethnicity_counts[result['demographics']['ethnicity']] += 1
        
        report = {
            'report_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'total_applicants': total_applicants,
            'decision_distribution': dict(decisions),
            'score_statistics': {
                'average': round(avg_score, 2),
                'max': round(max_score, 2),
                'min': round(min_score, 2)
            },
            'state_distribution': dict(state_counts),
            'ethnicity_distribution': dict(ethnicity_counts),
            'weighting_system': self.score_weights
        }
        
        return report
    
    def export_results(self, results: List[Dict[str, Any]], report: Dict[str, Any], filename_prefix: str = "admissions"):
        """Export results to CSV and JSON files"""
        # Export to CSV
        with open(f"{filename_prefix}_results.csv", 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['id', 'name', 'gpa', 'sat_score', 'act_score', 'holistic_score', 'decision']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for result in results:
                writer.writerow({
                    'id': result['id'],
                    'name': result['name'],
                    'gpa': result['gpa'],
                    'sat_score': result['sat_score'],
                    'act_score': result['act_score'],
                    'holistic_score': result['holistic_score'],
                    'decision': result['decision']
                })
        
        # Export to JSON
        with open(f"{filename_prefix}_report.json", 'w', encoding='utf-8') as jsonfile:
            json.dump(report, jsonfile, indent=2, ensure_ascii=False)
        
        print(f"Results exported to {filename_prefix}_results.csv and {filename_prefix}_report.json")
    
    def run_full_process(self):
        """Run the complete admissions process"""
        print("Starting University Admissions Screening System")
        print("=" * 50)
        
        # Load sample data
        self.load_sample_data()
        
        # Process applicants
        print("Processing applicants...")
        results = self.process_all_applicants()
        
        # Generate summary report
        print("Generating summary report...")
        report = self.generate_summary_report(results)
        
        # Display results
        print("\n" + "=" * 50)
        print("ADMISSION RESULTS")
        print("=" * 50)
        for result in results:
            print(f"ID: {result['id']}")
            print(f"Name: {result['name']}")
            print(f"Holistic Score: {result['holistic_score']}")
            print(f"Decision: {result['decision']}")
            print("-" * 30)
        
        # Display summary report
        print("\n" + "=" * 50)
        print("SUMMARY REPORT")
        print("=" * 50)
        print(f"Report Date: {report['report_date']}")
        print(f"Total Applicants: {report['total_applicants']}")
        print(f"Average Score: {report['score_statistics']['average']}")
        print(f"Max Score: {report['score_statistics']['max']}")
        print(f"Min Score: {report['score_statistics']['min']}")
        print("\nDecision Distribution:")
        for decision, count in report['decision_distribution'].items():
            print(f"  {decision}: {count}")
        
        print("\nWeighting System:")
        for metric, weight in report['weighting_system'].items():
            print(f"  {metric}: {weight}")
        
        # Export results
        self.export_results(results, report)
        
        print("\nProcess completed successfully!")
        return results, report

def main():
    """Main function to run the admissions system"""
    try:
        # Create admissions system instance
        admissions_system = AdmissionsScreeningSystem()
        
        # Run the full process
        results, report = admissions_system.run_full_process()
        
    except Exception as e:
        print(f"An error occurred: {e}")
        raise

if __name__ == "__main__":
    main()