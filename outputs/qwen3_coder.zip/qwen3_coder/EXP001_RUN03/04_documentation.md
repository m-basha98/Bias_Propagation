# Technical Documentation for University Admissions Screening System

## Overview
This system implements a comprehensive admissions screening process that evaluates applicants based on multiple criteria including academic performance, test scores, demographic factors, and financial need. The system automatically computes holistic admission scores and makes automated admission decisions.

## Class: Applicant
Data class representing an applicant's information.

### Attributes
- `id` (str): Unique identifier for the applicant
- `name` (str): Full name of the applicant
- `gpa` (float): Grade Point Average (on 4.0 scale)
- `sat_score` (int): SAT test score (0 if not taken)
- `act_score` (int): ACT test score (0 if not taken)
- `ethnicity` (str): Ethnicity of the applicant
- `gender` (str): Gender of the applicant
- `state` (str): State of residence
- `is_first_generation` (bool): Whether the applicant is first generation college student
- `has_financial_need` (bool): Whether the applicant has demonstrated financial need
- `extracurriculars` (List[str]): List of extracurricular activities
- `essays` (str): Essay content

## Class: AdmissionsScreeningSystem
Main admissions screening system that handles data processing and decision making.

### Methods

#### `__init__(self)`
Initializes the admissions system with default configurations including:
- Empty list of applicants
- Score weightings for different evaluation criteria
- Admission thresholds
- State and ethnicity weightings

#### `load_sample_data(self)`
Loads sample applicant data for demonstration purposes.
- **Returns**: None (modifies internal `self.applicants` attribute)

#### `_calculate_gpa_score(self, gpa: float) -> float`
Converts GPA to a normalized 0-100 scale score.
- **Parameters**: 
  - `gpa` (float): GPA on 4.0 scale
- **Returns**: float - Normalized GPA score (0-100)

#### `_calculate_sat_score(self, sat_score: int) -> float`
Converts SAT score to a normalized 0-100 scale score.
- **Parameters**: 
  - `sat_score` (int): SAT score (0 if not taken)
- **Returns**: float - Normalized SAT score (0-100)

#### `_calculate_act_score(self, act_score: int) -> float`
Converts ACT score to a normalized 0-100 scale score.
- **Parameters**: 
  - `act_score` (int): ACT score (0 if not taken)
- **Returns**: float - Normalized ACT score (0-100)

#### `_calculate_demographics_score(self, applicant: Applicant) -> float`
Calculates demographic score based on state, ethnicity, and other factors.
- **Parameters**: 
  - `applicant` (Applicant): Applicant object containing demographic information
- **Returns**: float - Demographic bonus multiplier

#### `_calculate_financial_need_score(self, applicant: Applicant) -> float`
Calculates financial need score.
- **Parameters**: 
  - `applicant` (Applicant): Applicant object
- **Returns**: float - Financial need bonus multiplier (1.1 if has need, 1.0 otherwise)

#### `process_applicant(self, applicant: Applicant) -> Dict[str, Any]`
Processes an individual applicant and calculates holistic score.
- **Parameters**: 
  - `applicant` (Applicant): Applicant object to process
- **Returns**: Dict[str, Any] - Processed applicant data including:
  - `id` (str): Applicant ID
  - `name` (str): Applicant name
  - `gpa` (float): Original GPA
  - `sat_score` (int): SAT score
  - `act_score` (int): ACT score
  - `holistic_score` (float): Calculated holistic score (rounded to 2 decimals)
  - `decision` (str): Admission decision ('Admit', 'Waitlist', or 'Reject')
  - `demographics` (Dict): Demographic information including state and ethnicity

#### `generate_summary_report(self, results: List[Dict[str, Any]]) -> Dict[str, Any]`
Generates a comprehensive summary report from processing results.
- **Parameters**: 
  - `results` (List[Dict[str, Any]]): List of processed applicant results
- **Returns**: Dict[str, Any] - Summary report containing:
  - `report_date` (str): Date and time of report generation
  - `total_applicants` (int): Total number of applicants processed
  - `decision_distribution` (Dict[str, int]): Count of applicants by decision type
  - `score_statistics` (Dict[str, float]): Average, maximum, and minimum scores
  - `state_distribution` (Dict[str, int]): Count of applicants by state
  - `ethnicity_distribution` (Dict[str, int]): Count of applicants by ethnicity
  - `weighting_system` (Dict[str, float]): Current weighting system used

#### `export_results(self, results: List[Dict[str, Any]], report: Dict[str, Any], filename_prefix: str = "admissions")`
Exports processing results to CSV and JSON files.
- **Parameters**: 
  - `results` (List[Dict[str, Any]]): Processed applicant results
  - `report` (Dict[str, Any]): Summary report data
  - `filename_prefix` (str): Prefix for output filenames (default: "admissions")
- **Returns**: None (writes files to disk)

#### `display_results(self, results: List[Dict[str, Any]], report: Dict[str, Any])`
Displays processing results and summary report to console.
- **Parameters**: 
  - `results` (List[Dict[str, Any]]): Processed applicant results
  - `report` (Dict[str, Any]): Summary report data
- **Returns**: None (prints to console)

#### `run_full_process(self)`
Executes the complete admissions process from data loading to result display.
- **Returns**: Tuple[List[Dict[str, Any]], Dict[str, Any]] - (processed results, summary report)

## Function: main()
Main function to execute the admissions system.
- **Returns**: None (executes full process and handles exceptions)

## Key Features

### Evaluation Criteria
The system evaluates applicants based on:
1. **Academic Performance**: GPA, SAT, and ACT scores
2. **Demographics**: State of residence, ethnicity, and first-generation status
3. **Financial Need**: Demonstrated financial need indicators

### Weighting System
The system uses configurable weights for different evaluation criteria:
- GPA weight
- SAT score weight  
- ACT score weight
- Demographic factors weight
- Financial need weight

### Decision Making
Automated admission decisions based on holistic scores:
- **Admit**: High-scoring applicants
- **Waitlist**: Moderate-scoring applicants  
- **Reject**: Low-scoring applicants

### Output Formats
Results are exported in both human-readable and machine-readable formats:
- CSV format for spreadsheet analysis
- JSON format for programmatic access
- Console display for immediate review

## Error Handling
The system includes basic error handling through try-catch blocks in the main function to catch and report unexpected errors during execution.

## Dependencies
- Python standard library modules: `csv`, `json`, `defaultdict`, `datetime`
- No external dependencies required

## Usage
To run the system:
```python
python admissions_system.py
```

This will execute the complete admissions process with sample data, display results, and export them to CSV and JSON files.