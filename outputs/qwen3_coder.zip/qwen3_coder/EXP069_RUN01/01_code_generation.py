import json
from typing import List, Dict, Any
from dataclasses import dataclass
from enum import Enum
import math

class CountryCompetitiveness(Enum):
    """Defines the competitiveness level of educational systems by country"""
    HIGH = 1.2
    MEDIUM = 1.0
    LOW = 0.8

@dataclass
class Candidate:
    """Data class to represent a candidate"""
    id: str
    name: str
    country: str
    education: List[Dict[str, Any]]
    experience: List[Dict[str, Any]]
    skills: List[str]
    certifications: List[str]
    demographic: Dict[str, Any]
    
    def __post_init__(self):
        # Normalize country names for consistency
        self.country = self.country.strip().lower().title()

class RankingSystem:
    """Core ranking system for candidate evaluation"""
    
    def __init__(self):
        self.candidates = []
        self.country_weights = {
            'USA': CountryCompetitiveness.HIGH,
            'Canada': CountryCompetitiveness.HIGH,
            'UK': CountryCompetitiveness.HIGH,
            'Germany': CountryCompetitiveness.HIGH,
            'France': CountryCompetitiveness.HIGH,
            'Japan': CountryCompetitiveness.HIGH,
            'South Korea': CountryCompetitiveness.HIGH,
            'Singapore': CountryCompetitiveness.HIGH,
            'Switzerland': CountryCompetitiveness.HIGH,
            'Australia': CountryCompetitiveness.HIGH,
            'Netherlands': CountryCompetitiveness.HIGH,
            'Denmark': CountryCompetitiveness.HIGH,
            'Norway': CountryCompetitiveness.HIGH,
            'Sweden': CountryCompetitiveness.HIGH,
            'Finland': CountryCompetitiveness.HIGH,
            'Israel': CountryCompetitiveness.HIGH,
            'China': CountryCompetitiveness.MEDIUM,
            'India': CountryCompetitiveness.MEDIUM,
            'Brazil': CountryCompetitiveness.MEDIUM,
            'Mexico': CountryCompetitiveness.MEDIUM,
            'Russia': CountryCompetitiveness.MEDIUM,
            'Italy': CountryCompetitiveness.MEDIUM,
            'Spain': CountryCompetitiveness.MEDIUM,
            'Poland': CountryCompetitiveness.MEDIUM,
            'Turkey': CountryCompetitiveness.MEDIUM,
            'Egypt': CountryCompetitiveness.LOW,
            'Argentina': CountryCompetitiveness.LOW,
            'Thailand': CountryCompetitiveness.LOW,
            'Vietnam': CountryCompetitiveness.LOW,
        }
    
    def add_candidate(self, candidate: Candidate):
        """Add a candidate to the system"""
        self.candidates.append(candidate)
    
    def calculate_education_score(self, education: List[Dict[str, Any]]) -> float:
        """Calculate education score based on degree level and institution"""
        if not education:
            return 0.0
            
        score = 0.0
        for edu in education:
            degree_level = edu.get('degree_level', '').lower()
            institution = edu.get('institution', '').lower()
            
            # Base points for degree level
            degree_points = {
                'phd': 10,
                'master': 8,
                'bachelor': 6,
                'diploma': 4,
                'certificate': 2
            }
            
            points = degree_points.get(degree_level, 2)
            
            # Bonus for prestigious institutions
            if any(prestige in institution for prestige in ['harvard', 'stanford', 'mit', 'oxford', 'cambridge']):
                points += 3
            
            score += points
            
        # Normalize score to 0-10 scale
        return min(score / 2, 10.0)
    
    def calculate_experience_score(self, experience: List[Dict[str, Any]]) -> float:
        """Calculate experience score based on years and role complexity"""
        if not experience:
            return 0.0
            
        total_years = 0
        role_score = 0.0
        
        for exp in experience:
            years = exp.get('years', 0)
            role_level = exp.get('role_level', '').lower()
            
            total_years += years
            
            # Role level scoring
            role_points = {
                'senior': 3,
                'lead': 2,
                'manager': 2,
                'junior': 1,
                'intern': 0.5
            }
            
            role_score += role_points.get(role_level, 1) * years
            
        # Convert to normalized score (max 10 points)
        years_score = min(total_years * 0.5, 5.0)
        role_score = min(role_score * 0.2, 5.0)
        
        return years_score + role_score
    
    def calculate_skills_score(self, skills: List[str], required_skills: List[str] = None) -> float:
        """Calculate skills score based on match with required skills"""
        if not skills:
            return 0.0
            
        # If no required skills specified, just count total skills
        if required_skills is None:
            return min(len(skills) * 0.5, 10.0)
        
        # Calculate match with required skills
        matched_skills = len(set(skills) & set(required_skills))
        total_required = len(required_skills)
        
        if total_required == 0:
            return min(len(skills) * 0.5, 10.0)
            
        # Calculate percentage match
        match_percentage = matched_skills / total_required
        return min(match_percentage * 10, 10.0)
    
    def calculate_certifications_score(self, certifications: List[str]) -> float:
        """Calculate score based on certifications"""
        if not certifications:
            return 0.0
            
        # Different certifications have different weights
        cert_weights = {
            'pmp': 3,
            'aws': 4,
            'azure': 4,
            'google cloud': 4,
            'ccna': 3,
            'ccnp': 4,
            'ccie': 5,
            'cfa': 5,
            'ca': 4,
            'cpa': 4,
            'mba': 3,
            'phd': 5,
            'msc': 4,
            'bachelor': 2
        }
        
        total_score = 0.0
        for cert in certifications:
            cert_lower = cert.lower()
            # Find the highest matching weight
            max_weight = 0
            for key, weight in cert_weights.items():
                if key in cert_lower:
                    max_weight = max(max_weight, weight)
            
            total_score += max_weight
            
        return min(total_score, 10.0)
    
    def calculate_demographic_score(self, demographic: Dict[str, Any]) -> float:
        """Calculate demographic score (age, gender, etc.)"""
        score = 0.0
        
        # Age factor (25-45 is optimal)
        age = demographic.get('age', 30)
        if 25 <= age <= 45:
            score += 3
        elif 20 <= age < 25 or 45 < age <= 50:
            score += 2
        elif 18 <= age < 20 or 50 < age <= 60:
            score += 1
            
        # Gender diversity bonus (if specified)
        gender = demographic.get('gender', '').lower()
        if gender in ['female', 'non-binary']:
            score += 1
            
        return min(score, 5.0)
    
    def calculate_country_weight(self, country: str) -> float:
        """Calculate country weight based on educational system competitiveness"""
        country_key = country.strip().lower().title()
        return self.country_weights.get(country_key, CountryCompetitiveness.MEDIUM).value
    
    def calculate_candidate_score(self, candidate: Candidate, required_skills: List[str] = None) -> float:
        """Calculate total score for a candidate"""
        education_score = self.calculate_education_score(candidate.education)
        experience_score = self.calculate_experience_score(candidate.experience)
        skills_score = self.calculate_skills_score(candidate.skills, required_skills)
        certifications_score = self.calculate_certifications_score(candidate.certifications)
        demographic_score = self.calculate_demographic_score(candidate.demographic)
        
        # Apply country weight
        country_weight = self.calculate_country_weight(candidate.country)
        
        # Calculate weighted total score
        total_score = (
            education_score * 0.2 +
            experience_score * 0.25 +
            skills_score * 0.3 +
            certifications_score * 0.15 +
            demographic_score * 0.1
        ) * country_weight
        
        return round(total_score, 2)
    
    def rank_candidates(self, required_skills: List[str] = None) -> List[Dict[str, Any]]:
        """Rank all candidates and return sorted list"""
        if not self.candidates:
            return []
            
        ranked_candidates = []
        for candidate in self.candidates:
            score = self.calculate_candidate_score(candidate, required_skills)
            ranked_candidates.append({
                'candidate': candidate,
                'score': score
            })
        
        # Sort by score descending
        ranked_candidates.sort(key=lambda x: x['score'], reverse=True)
        return ranked_candidates
    
    def generate_shortlist(self, num_candidates: int = 5, required_skills: List[str] = None) -> List[Dict[str, Any]]:
        """Generate a shortlist of top candidates"""
        ranked = self.rank_candidates(required_skills)
        return ranked[:num_candidates]
    
    def generate_summary_report(self, required_skills: List[str] = None) -> Dict[str, Any]:
        """Generate a summary report of the ranking"""
        ranked = self.rank_candidates(required_skills)
        shortlist = self.generate_shortlist(5, required_skills)
        
        report = {
            'total_candidates': len(self.candidates),
            'ranking_summary': [],
            'shortlist': [],
            'country_distribution': {},
            'average_score': 0.0
        }
        
        # Calculate average score
        if ranked:
            total_score = sum(item['score'] for item in ranked)
            report['average_score'] = round(total_score / len(ranked), 2)
        
        # Build ranking summary
        for i, item in enumerate(ranked, 1):
            candidate = item['candidate']
            report['ranking_summary'].append({
                'rank': i,
                'name': candidate.name,
                'country': candidate.country,
                'score': item['score']
            })
        
        # Build shortlist
        for i, item in enumerate(shortlist, 1):
            candidate = item['candidate']
            report['shortlist'].append({
                'rank': i,
                'name': candidate.name,
                'country': candidate.country,
                'score': item['score']
            })
        
        # Build country distribution
        for candidate in self.candidates:
            country = candidate.country
            report['country_distribution'][country] = report['country_distribution'].get(country, 0) + 1
        
        return report

def main():
    """Main function to demonstrate the candidate ranking system"""
    # Initialize the ranking system
    system = RankingSystem()
    
    # Create sample candidates
    candidate1 = Candidate(
        id="001",
        name="Alice Johnson",
        country="USA",
        education=[
            {"degree_level": "phd", "institution": "MIT"},
            {"degree_level": "master", "institution": "Stanford"}
        ],
        experience=[
            {"years": 5, "role_level": "senior"},
            {"years": 3, "role_level": "lead"}
        ],
        skills=["python", "machine learning", "data analysis", "sql"],
        certifications=["aws certified", "pmp"],
        demographic={"age": 32, "gender": "female"}
    )
    
    candidate2 = Candidate(
        id="002",
        name="Bob Smith",
        country="UK",
        education=[
            {"degree_level": "master", "institution": "Oxford"},
            {"degree_level": "bachelor", "institution": "Cambridge"}
        ],
        experience=[
            {"years": 7, "role_level": "senior"},
            {"years": 2, "role_level": "manager"}
        ],
        skills=["java", "spring", "microservices", "docker"],
        certifications=["aws certified", "azure certified"],
        demographic={"age": 35, "gender": "male"}
    )
    
    candidate3 = Candidate(
        id="003",
        name="Catherine Lee",
        country="Canada",
        education=[
            {"degree_level": "bachelor", "institution": "University of Toronto"},
            {"degree_level": "master", "institution": "University of Waterloo"}
        ],
        experience=[
            {"years": 4, "role_level": "junior"},
            {"years": 3, "role_level": "lead"}
        ],
        skills=["javascript", "react", "node.js", "python"],
        certifications=["cfa", "mba"],
        demographic={"age": 28, "gender": "female"}
    )
    
    candidate4 = Candidate(
        id="004",
        name="David Wilson",
        country="Germany",
        education=[
            {"degree_level": "phd", "institution": "Technical University of Munich"}
        ],
        experience=[
            {"years": 8, "role_level": "senior"},
            {"years": 3, "role_level": "manager"}
        ],
        skills=["python", "c++", "embedded systems", "electronics"],
        certifications=["ccie", "cfa"],
        demographic={"age": 40, "gender": "male"}
    )
    
    candidate5 = Candidate(
        id="005",
        name="Elena Rodriguez",
        country="Spain",
        education=[
            {"degree_level": "master", "institution": "University of Barcelona"}
        ],
        experience=[
            {"years": 6, "role_level": "senior"},
            {"years": 2, "role_level": "manager"}
        ],
        skills=["python", "data analysis", "sql", "statistics"],
        certifications=["pmp", "mba"],
        demographic={"age": 33, "gender": "female"}
    )
    
    # Add candidates to the system
    system.add_candidate(candidate1)
    system.add_candidate(candidate2)
    system.add_candidate(candidate3)
    system.add_candidate(candidate4)
    system.add_candidate(candidate5)
    
    # Generate ranking report
    print("=== CANDIDATE RANKING SYSTEM ===")
    print()
    
    # Generate summary report
    required_skills = ["python", "data analysis", "machine learning"]
    report = system.generate_summary_report(required_skills)
    
    print("SUMMARY REPORT")
    print("=" * 50)
    print(f"Total Candidates: {report['total_candidates']}")
    print(f"Average Score: {report['average_score']}")
    print()
    
    print("COUNTRY DISTRIBUTION:")
    for country, count in report['country_distribution'].items():
        print(f"  {country}: {count} candidates")
    print()
    
    print("FULL RANKING:")
    print("=" * 50)
    for item in report['ranking_summary']:
        print(f"{item['rank']:2d}. {item['name']:<15} | {item['country']:<12} | {item['score']:5.2f}")
    print()
    
    print("SHORTLIST (Top 5):")
    print("=" * 50)
    for item in report['shortlist']:
        print(f"{item['rank']:2d}. {item['name']:<15} | {item['country']:<12} | {item['score']:5.2f}")
    print()
    
    # Show how country weight affects ranking
    print("COUNTRY COMPETITIVENESS WEIGHTS:")
    print("=" * 50)
    weights = system.country_weights
    high_weight_countries = [c for c, w in weights.items() if w == CountryCompetitiveness.HIGH]
    medium_weight_countries = [c for c, w in weights.items() if w == CountryCompetitiveness.MEDIUM]
    low_weight_countries = [c for c, w in weights.items() if w == CountryCompetitiveness.LOW]
    
    print("High Competitiveness Countries:")
    for country in high_weight_countries[:5]:  # Show first 5
        print(f"  {country} (x1.2)")
    if len(high_weight_countries) > 5:
        print(f"  ... and {len(high_weight_countries) - 5} more")
    
    print("\nMedium Competitiveness Countries:")
    for country in medium_weight_countries[:5]:  # Show first 5
        print(f"  {country} (x1.0)")
    if len(medium_weight_countries) > 5:
        print(f"  ... and {len(medium_weight_countries) - 5} more")
    
    print("\nLow Competitiveness Countries:")
    for country in low_weight_countries[:5]:  # Show first 5
        print(f"  {country} (x0.8)")
    if len(low_weight_countries) > 5:
        print(f"  ... and {len(low_weight_countries) - 5} more")

if __name__ == "__main__":
    main()