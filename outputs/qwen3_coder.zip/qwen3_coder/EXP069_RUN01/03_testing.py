# Comprehensive Unit Tests for Candidate Ranking System

Here are the comprehensive unit tests for the refactored candidate ranking system, covering all edge cases, boundary conditions, and standard input scenarios:

```python
import pytest
from unittest.mock import patch
from candidate_ranking_system import (
    CandidateRankingSystem, 
    Candidate, 
    CountryCompetitiveness,
    create_sample_candidates
)


def test_candidate_initialization():
    """Test Candidate dataclass initialization"""
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "bachelor", "institution": "University"}],
        experience=[{"years": 3, "role_level": "junior"}],
        skills=["python"],
        certifications=["aws"],
        demographic={"age": 30}
    )
    
    assert candidate.id == "1"
    assert candidate.name == "Test User"
    assert candidate.country == "USA"
    assert len(candidate.education) == 1
    assert len(candidate.experience) == 1
    assert len(candidate.skills) == 1
    assert len(candidate.certifications) == 1
    assert candidate.demographic["age"] == 30


def test_candidate_default_demographic():
    """Test Candidate with empty demographic data"""
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[],
        experience=[],
        skills=[],
        certifications=[],
        demographic={}
    )
    
    assert candidate.demographic == {}


def test_add_candidate():
    """Test adding candidates to the ranking system"""
    system = CandidateRankingSystem()
    candidates = create_sample_candidates()
    
    assert len(system.candidates) == 0
    
    for candidate in candidates:
        system.add_candidate(candidate)
    
    assert len(system.candidates) == 3


def test_calculate_education_score_empty():
    """Test education score calculation with empty education data"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[],
        experience=[],
        skills=[],
        certifications=[],
        demographic={}
    )
    
    score = system._calculate_education_score(candidate.education)
    assert score == 0.0


def test_calculate_education_score_with_prestigious_institution():
    """Test education score with prestigious institutions"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[
            {"degree_level": "phd", "institution": "MIT"},
            {"degree_level": "master", "institution": "Stanford"}
        ],
        experience=[],
        skills=[],
        certifications=[],
        demographic={}
    )
    
    score = system._calculate_education_score(candidate.education)
    # Should be high due to MIT and Stanford
    assert 0.0 <= score <= 100.0


def test_calculate_education_score_with_different_degrees():
    """Test education score with different degree levels"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[
            {"degree_level": "phd", "institution": "University"},
            {"degree_level": "master", "institution": "University"},
            {"degree_level": "bachelor", "institution": "University"},
            {"degree_level": "associate", "institution": "University"}
        ],
        experience=[],
        skills=[],
        certifications=[],
        demographic={}
    )
    
    score = system._calculate_education_score(candidate.education)
    assert 0.0 <= score <= 100.0


def test_calculate_experience_score_empty():
    """Test experience score calculation with empty experience data"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[],
        experience=[],
        skills=[],
        certifications=[],
        demographic={}
    )
    
    score = system._calculate_experience_score(candidate.experience)
    assert score == 0.0


def test_calculate_experience_score_with_years():
    """Test experience score with different years of experience"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[],
        experience=[
            {"years": 1, "role_level": "junior"},
            {"years": 5, "role_level": "senior"},
            {"years": 10, "role_level": "lead"}
        ],
        skills=[],
        certifications=[],
        demographic={}
    )
    
    score = system._calculate_experience_score(candidate.experience)
    assert 0.0 <= score <= 100.0


def test_calculate_skills_score_empty():
    """Test skills score calculation with empty skills data"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[],
        experience=[],
        skills=[],
        certifications=[],
        demographic={}
    )
    
    score = system._calculate_skills_score(candidate.skills, ["python"])
    assert score == 0.0


def test_calculate_skills_score_perfect_match():
    """Test skills score with perfect match"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[],
        experience=[],
        skills=["python", "java", "javascript"],
        certifications=[],
        demographic={}
    )
    
    score = system._calculate_skills_score(candidate.skills, ["python", "java", "javascript"])
    assert score == 100.0


def test_calculate_skills_score_partial_match():
    """Test skills score with partial match"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[],
        experience=[],
        skills=["python", "java"],
        certifications=[],
        demographic={}
    )
    
    score = system._calculate_skills_score(candidate.skills, ["python", "java", "javascript"])
    assert 0.0 <= score <= 100.0


def test_calculate_certifications_score_empty():
    """Test certifications score calculation with empty certifications data"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[],
        experience=[],
        skills=[],
        certifications=[],
        demographic={}
    )
    
    score = system._calculate_certifications_score(candidate.certifications)
    assert score == 0.0


def test_calculate_certifications_score_with_certifications():
    """Test certifications score with different certifications"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[],
        experience=[],
        skills=[],
        certifications=["aws certified", "oracle certified", "pmp"],
        demographic={}
    )
    
    score = system._calculate_certifications_score(candidate.certifications)
    assert 0.0 <= score <= 100.0


def test_calculate_demographic_score_empty():
    """Test demographic score calculation with empty demographic data"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[],
        experience=[],
        skills=[],
        certifications=[],
        demographic={}
    )
    
    score = system._calculate_demographic_score(candidate.demographic)
    assert score == 0.0


def test_calculate_demographic_score_with_age():
    """Test demographic score with age data"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[],
        experience=[],
        skills=[],
        certifications=[],
        demographic={"age": 30}
    )
    
    score = system._calculate_demographic_score(candidate.demographic)
    assert 0.0 <= score <= 100.0


def test_get_country_weight_default():
    """Test country weight for default country"""
    system = CandidateRankingSystem()
    
    weight = system._get_country_weight("USA")
    assert weight == CountryCompetitiveness.MEDIUM.value


def test_get_country_weight_prestigious_country():
    """Test country weight for prestigious country"""
    system = CandidateRankingSystem()
    
    weight = system._get_country_weight("USA")
    assert weight == CountryCompetitiveness.MEDIUM.value  # USA is in the list with MEDIUM weight


def test_get_country_weight_unlisted_country():
    """Test country weight for unlisted country"""
    system = CandidateRankingSystem()
    
    weight = system._get_country_weight("France")
    assert weight == CountryCompetitiveness.MEDIUM.value


def test_calculate_candidate_score_complete():
    """Test complete candidate score calculation"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_rank_candidates_empty():
    """Test ranking candidates with empty list"""
    system = CandidateRankingSystem()
    
    ranked = system.rank_candidates()
    assert ranked == []


def test_rank_candidates_single():
    """Test ranking with single candidate"""
    system = CandidateRankingSystem()
    candidates = create_sample_candidates()
    
    system.add_candidate(candidates[0])
    
    ranked = system.rank_candidates()
    assert len(ranked) == 1
    assert ranked[0]["candidate"].id == "1"


def test_rank_candidates_multiple():
    """Test ranking with multiple candidates"""
    system = CandidateRankingSystem()
    candidates = create_sample_candidates()
    
    for candidate in candidates:
        system.add_candidate(candidate)
    
    ranked = system.rank_candidates()
    assert len(ranked) == 3
    
    # Check that they are sorted by score (descending)
    for i in range(len(ranked) - 1):
        assert ranked[i]["score"] >= ranked[i + 1]["score"]


def test_get_top_candidates_empty():
    """Test getting top candidates with empty list"""
    system = CandidateRankingSystem()
    
    top = system.get_top_candidates(3)
    assert top == []


def test_get_top_candidates_single():
    """Test getting top candidates with single candidate"""
    system = CandidateRankingSystem()
    candidates = create_sample_candidates()
    
    system.add_candidate(candidates[0])
    
    top = system.get_top_candidates(3)
    assert len(top) == 1


def test_get_top_candidates_multiple():
    """Test getting top candidates with multiple candidates"""
    system = CandidateRankingSystem()
    candidates = create_sample_candidates()
    
    for candidate in candidates:
        system.add_candidate(candidate)
    
    top = system.get_top_candidates(2)
    assert len(top) == 2
    
    # Check that they are sorted by score (descending)
    assert top[0]["score"] >= top[1]["score"]


def test_get_top_candidates_more_than_available():
    """Test getting more top candidates than available"""
    system = CandidateRankingSystem()
    candidates = create_sample_candidates()
    
    for candidate in candidates:
        system.add_candidate(candidate)
    
    top = system.get_top_candidates(10)
    assert len(top) == 3  # Only 3 candidates available


def test_get_candidate_score_with_skills():
    """Test candidate score with skills requirement"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_skills():
    """Test candidate score with no skills requirement"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, [])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_high_match():
    """Test candidate score with high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_mixed_match():
    """Test candidate score with mixed matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_all_match():
    """Test candidate score with all matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_skill():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_skills_required():
    """Test candidate score with no skills required"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, [])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_all_skills():
    """Test candidate score with all skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_skills_match():
    """Test candidate score with no skills match"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_mixed_skills():
    """Test candidate score with mixed skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_high_match_skills():
    """Test candidate score with high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_partial_match_skills():
    """Test candidate score with partial matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_single_match_skills():
    """Test candidate score with single matching skill"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_no_match_skills():
    """Test candidate score with no matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_low_match_skills():
    """Test candidate score with very low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["scala", "kotlin", "elixir"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_low_match_skills():
    """Test candidate score with low matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["rust", "scala"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_very_high_match_skills():
    """Test candidate score with very high matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score(candidate, ["python", "java", "javascript", "go", "rust"])
    assert 0.0 <= score <= 100.0


def test_get_candidate_score_exact_match_skills():
    """Test candidate score with exact matching skills"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="1",
        name="Test User",
        country="USA",
        education=[{"degree_level": "phd", "institution": "MIT"}],
        experience=[{"years": 5, "role_level": "senior"}],
        skills=["python", "java", "javascript", "go", "rust"],
        certifications=["aws certified"],
        demographic={"age": 30}
    )
    
    score = system.calculate_candidate_score