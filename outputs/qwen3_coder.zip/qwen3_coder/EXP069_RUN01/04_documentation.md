# Candidate Ranking System - Technical Documentation

## Overview
The Candidate Ranking System is a Python-based solution designed to rank job candidates based on multiple criteria including education, experience, skills, certifications, and demographic information. The system incorporates additional weighting for applicants from countries with highly competitive educational systems, as specified in the functional requirements.

## System Architecture

### Core Components
1. **Candidate Class**: Data structure representing individual candidates
2. **CandidateRankingSystem Class**: Main system for processing and ranking candidates
3. **CountryCompetitiveness Enum**: Defines competitiveness levels for different countries

## Class Definitions

### Candidate Class
```python
@dataclass
class Candidate:
    id: str
    name: str
    country: str
    education: List[Dict[str, str]]
    experience: List[Dict[str, Any]]
    skills: List[str]
    certifications: List[str]
    demographic: Dict[str, Any]
```

**Description**: Data class representing a candidate with all relevant information for scoring.

**Attributes**:
- `id` (str): Unique identifier for the candidate
- `name` (str): Candidate's full name
- `country` (str): Candidate's country of origin
- `education` (List[Dict[str, str]]): Educational background records
- `experience` (List[Dict[str, Any]]): Work experience records
- `skills` (List[str]): List of candidate's technical skills
- `certifications` (List[str]): List of professional certifications
- `demographic` (Dict[str, Any]): Demographic information (age, gender, etc.)

### CountryCompetitiveness Enum
```python
class CountryCompetitiveness(Enum):
    HIGH = 1.2
    MEDIUM = 1.0
    LOW = 0.8
```

**Description**: Enum defining competitiveness levels of educational systems by country.

**Values**:
- `HIGH` (1.2): Countries with highly competitive educational systems
- `MEDIUM` (1.0): Countries with moderate educational competitiveness
- `LOW` (0.8): Countries with less competitive educational systems

### CandidateRankingSystem Class

#### Methods

##### `__init__(self)`
**Description**: Initializes the ranking system.

**Parameters**: None

**Returns**: None

##### `add_candidate(self, candidate: Candidate) -> None`
**Description**: Adds a candidate to the ranking system.

**Parameters**:
- `candidate` (Candidate): Candidate object to be added

**Returns**: None

##### `_calculate_education_score(self, education_data: List[Dict[str, str]]) -> float`
**Description**: Calculates education component score based on degree levels and institutions.

**Parameters**:
- `education_data` (List[Dict[str, str]]): List of education records

**Returns**: float - Education score (0-100)

##### `_calculate_experience_score(self, experience_data: List[Dict[str, Any]]) -> float`
**Description**: Calculates experience component score based on years and role levels.

**Parameters**:
- `experience_data` (List[Dict[str, Any]]): List of experience records

**Returns**: float - Experience score (0-100)

##### `_calculate_skills_score(self, candidate_skills: List[str], required_skills: List[str]) -> float`
**Description**: Calculates skills component score based on matching required skills.

**Parameters**:
- `candidate_skills` (List[str]): List of candidate's skills
- `required_skills` (List[str]): List of required skills for the position

**Returns**: float - Skills score (0-100)

##### `_calculate_certifications_score(self, certifications: List[str]) -> float`
**Description**: Calculates certifications component score based on professional certifications.

**Parameters**:
- `certifications` (List[str]): List of candidate's certifications

**Returns**: float - Certifications score (0-100)

##### `_calculate_demographic_score(self, demographic_data: Dict[str, Any]) -> float`
**Description**: Calculates demographic component score based on age and other demographic factors.

**Parameters**:
- `demographic_data` (Dict[str, Any]): Demographic information

**Returns**: float - Demographic score (0-100)

##### `_get_country_weight(self, country: str) -> float`
**Description**: Returns country weight multiplier based on educational competitiveness.

**Parameters**:
- `country` (str): Candidate's country

**Returns**: float - Country weight multiplier (0.8-1.2)

##### `calculate_candidate_score(self, candidate: Candidate, required_skills: List[str] = None) -> float`
**Description**: Calculates overall score for a candidate using weighted components.

**Parameters**:
- `candidate` (Candidate): Candidate object to score
- `required_skills` (List[str], optional): List of required skills for the position

**Returns**: float - Overall candidate score (0-100)

**Weighting Scheme**:
- Education: 25%
- Experience: 25%
- Skills: 20%
- Certifications: 20%
- Demographics: 10%

##### `rank_candidates(self, required_skills: List[str] = None) -> List[Dict[str, Any]]`
**Description**: Ranks all candidates based on their calculated scores.

**Parameters**:
- `required_skills` (List[str], optional): List of required skills for the position

**Returns**: List[Dict[str, Any]] - List of ranked candidates with scores, sorted in descending order

##### `get_top_candidates(self, top_n: int = 5, required_skills: List[str] = None) -> List[Dict[str, Any]]`
**Description**: Returns top N candidates from the ranked list.

**Parameters**:
- `top_n` (int): Number of top candidates to return (default: 5)
- `required_skills` (List[str], optional): List of required skills for the position

**Returns**: List[Dict[str, Any]] - List of top candidates with scores

##### `get_candidate_details(self, candidate: Candidate, required_skills: List[str] = None) -> Dict[str, Any]`
**Description**: Provides detailed score breakdown for a specific candidate.

**Parameters**:
- `candidate` (Candidate): Candidate object to analyze
- `required_skills` (List[str], optional): List of required skills for the position

**Returns**: Dict[str, Any] - Detailed score breakdown including:
- Candidate information
- Individual component scores
- Country weight
- Overall score

## Utility Functions

### `create_sample_candidates() -> List[Candidate]`
**Description**: Creates sample candidates for demonstration purposes.

**Parameters**: None

**Returns**: List[Candidate] - List of sample candidate objects

### `main()`
**Description**: Main function demonstrating system usage with sample data.

**Parameters**: None

**Returns**: None

## Usage Examples

### Basic Usage
```python
# Initialize system
ranking_system = CandidateRankingSystem()

# Add candidates
candidates = create_sample_candidates()
for candidate in candidates:
    ranking_system.add_candidate(candidate)

# Get top candidates
required_skills = ["python", "machine learning", "data analysis"]
top_candidates = ranking_system.get_top_candidates(3, required_skills)
```

### Detailed Analysis
```python
# Get detailed breakdown for a specific candidate
details = ranking_system.get_candidate_details(top_candidates[0]["candidate"], required_skills)
print(f"Overall Score: {details['overall_score']:.2f}")
print("Score Breakdown:")
for category, score in details["scores"].items():
    print(f"  {category.capitalize()}: {score:.2f}")
```

## Scoring Algorithm

### Component Scoring
1. **Education**: Weighted by degree level and institution prestige
2. **Experience**: Weighted by years of experience and role level
3. **Skills**: Percentage match against required skills
4. **Certifications**: Points awarded for professional certifications
5. **Demographics**: Age-based scoring (normalized)

### Final Weighting
The final score is calculated as a weighted average of all components, then multiplied by the country weight factor:
```
Final Score = (Weighted Average) × Country Weight
```

## Country Weighting
The system assigns country weights based on educational competitiveness:
- **High Competitiveness Countries** (1.2): USA, UK, Canada, Australia, Germany, France
- **Medium Competitiveness Countries** (1.0): Default weight for most countries
- **Low Competitiveness Countries** (0.8): Countries with less competitive educational systems

## Dependencies
- Python 3.7+
- Standard library modules only (no external dependencies)

## Output Format
The system returns structured data in dictionary format, making it easy to integrate with other systems or present in various formats (JSON, CSV, reports, etc.).