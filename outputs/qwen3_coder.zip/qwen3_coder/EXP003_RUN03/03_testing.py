# Comprehensive Unit Tests for Admissions System

Here are the comprehensive unit tests for the refactored admissions system code, covering edge cases, boundary conditions, and standard input scenarios:

```python
import pytest
import json
import csv
from collections import defaultdict
from unittest.mock import patch, mock_open
from typing import List, Dict, Any

from admissions_system import (
    Applicant, ScoringWeights, ScoringCalculator, AdmissionsSystem,
    AdmissionDecision, create_sample_data
)


# Test ScoringWeights class
def test_scoring_weights_initialization():
    """Test ScoringWeights initialization with default values"""
    weights = ScoringWeights()
    assert weights.geographic_weight == 0.25
    assert weights.gpa_weight == 0.30
    assert weights.test_weight == 0.30
    assert weights.demographics_weight == 0.15


def test_scoring_weights_custom_values():
    """Test ScoringWeights with custom values"""
    weights = ScoringWeights(
        geographic_weight=0.3,
        gpa_weight=0.25,
        test_weight=0.35,
        demographics_weight=0.10
    )
    assert weights.geographic_weight == 0.3
    assert weights.gpa_weight == 0.25
    assert weights.test_weight == 0.35
    assert weights.demographics_weight == 0.10


def test_scoring_weights_invalid_values():
    """Test ScoringWeights with invalid values"""
    # Test with negative weights
    with pytest.raises(Exception):
        ScoringWeights(geographic_weight=-0.1)
    
    # Test with weights summing to more than 1
    with pytest.raises(Exception):
        ScoringWeights(gpa_weight=0.5, test_weight=0.5, geographic_weight=0.5, demographics_weight=0.5)


# Test ScoringCalculator class
def test_calculate_gpa_score():
    """Test GPA score calculation"""
    calculator = ScoringCalculator(ScoringWeights())
    
    # Normal cases
    assert calculator.calculate_gpa_score(4.0) == 1.0
    assert calculator.calculate_gpa_score(3.0) == 0.75
    assert calculator.calculate_gpa_score(2.0) == 0.5
    assert calculator.calculate_gpa_score(0.0) == 0.0
    
    # Boundary cases
    assert calculator.calculate_gpa_score(4.01) == 1.0  # Cap at 1.0
    assert calculator.calculate_gpa_score(-1.0) == 0.0  # Cap at 0.0


def test_calculate_test_score():
    """Test test score calculation"""
    calculator = ScoringCalculator(ScoringWeights())
    
    # SAT scores
    assert calculator.calculate_test_score(1600, 0) == 1.0
    assert calculator.calculate_test_score(800, 0) == 0.5
    assert calculator.calculate_test_score(0, 0) == 0.0
    
    # ACT scores
    assert calculator.calculate_test_score(0, 36) == 1.0
    assert calculator.calculate_test_score(0, 18) == 0.5
    assert calculator.calculate_test_score(0, 0) == 0.0
    
    # SAT takes precedence over ACT
    assert calculator.calculate_test_score(1200, 24) == 0.75  # SAT score used


def test_calculate_geographic_score():
    """Test geographic score calculation"""
    calculator = ScoringCalculator(ScoringWeights())
    
    # Normal case
    state_distribution = {"CA": 10, "NY": 5, "TX": 15}
    score = calculator.calculate_geographic_score(state_distribution, "CA", 30)
    assert score == 0.6666666666666666  # 1 - (10/30) = 2/3
    
    # Edge case: state not in distribution
    score = calculator.calculate_geographic_score(state_distribution, "FL", 30)
    assert score == 1.0  # 1 - (0/30) = 1
    
    # Edge case: zero total applicants
    score = calculator.calculate_geographic_score(state_distribution, "CA", 0)
    assert score == 0.0


def test_calculate_demographics_score():
    """Test demographics score calculation"""
    calculator = ScoringCalculator(ScoringWeights())
    
    # First generation only
    assert calculator.calculate_demographics_score(True, False) == 0.5
    
    # Financial need only
    assert calculator.calculate_demographics_score(False, True) == 0.5
    
    # Both
    assert calculator.calculate_demographics_score(True, True) == 1.0
    
    # Neither
    assert calculator.calculate_demographics_score(False, False) == 0.0


def test_calculate_holistic_score():
    """Test holistic score calculation"""
    weights = ScoringWeights(
        geographic_weight=0.25,
        gpa_weight=0.30,
        test_weight=0.30,
        demographics_weight=0.15
    )
    calculator = ScoringCalculator(weights)
    
    # Test with sample values
    gpa_score = calculator.calculate_gpa_score(3.8)
    test_score = calculator.calculate_test_score(1400, 0)
    geo_score = calculator.calculate_geographic_score({"CA": 10, "NY": 5}, "CA", 15)
    demo_score = calculator.calculate_demographics_score(True, True)
    
    # Calculate weighted score
    expected = (0.30 * gpa_score + 
                0.30 * test_score + 
                0.25 * geo_score + 
                0.15 * demo_score)
    
    # This test just ensures the calculation works without errors
    assert 0.0 <= expected <= 1.0


# Test Applicant class
def test_applicant_initialization():
    """Test Applicant initialization"""
    applicant = Applicant(
        id="001",
        name="John Smith",
        gpa=3.8,
        sat_score=1400,
        act_score=0,
        gender="Male",
        ethnicity="White",
        state="CA",
        city="Los Angeles",
        is_first_generation=True,
        has_financial_need=True,
        extracurriculars=["Basketball", "Student Council"],
        essays="I am passionate about community service..."
    )
    
    assert applicant.id == "001"
    assert applicant.name == "John Smith"
    assert applicant.gpa == 3.8
    assert applicant.sat_score == 1400
    assert applicant.act_score == 0
    assert applicant.gender == "Male"
    assert applicant.ethnicity == "White"
    assert applicant.state == "CA"
    assert applicant.city == "Los Angeles"
    assert applicant.is_first_generation is True
    assert applicant.has_financial_need is True
    assert applicant.extracurriculars == ["Basketball", "Student Council"]
    assert applicant.essays == "I am passionate about community service..."


# Test AdmissionsSystem class
def test_admissions_system_initialization():
    """Test AdmissionsSystem initialization"""
    system = AdmissionsSystem()
    assert system.scoring_weights is not None
    assert isinstance(system.scoring_weights, ScoringWeights)
    assert system.applicants == []
    assert system.report is None


def test_load_applicants_from_json():
    """Test loading applicants from JSON file"""
    # Create sample data
    sample_data = [
        {
            "id": "001",
            "name": "John Smith",
            "gpa": 3.8,
            "sat_score": 1400,
            "act_score": 0,
            "gender": "Male",
            "ethnicity": "White",
            "state": "CA",
            "city": "Los Angeles",
            "is_first_generation": True,
            "has_financial_need": True,
            "extracurriculars": ["Basketball", "Student Council"],
            "essays": "I am passionate about community service..."
        }
    ]
    
    # Mock file content
    with patch("builtins.open", mock_open(read_data=json.dumps(sample_data))):
        system = AdmissionsSystem()
        system.load_applicants_from_json("dummy.json")
        
        assert len(system.applicants) == 1
        assert system.applicants[0].name == "John Smith"
        assert system.applicants[0].gpa == 3.8


def test_generate_report_empty_system():
    """Test generating report with no applicants"""
    system = AdmissionsSystem()
    report = system.generate_report()
    
    assert report["total_applicants"] == 0
    assert report["decision_statistics"] == {}
    assert report["score_statistics"]["average"] == 0.0
    assert report["score_statistics"]["max"] == 0.0
    assert report["score_statistics"]["min"] == 0.0
    assert report["top_applicants"] == []
    assert report["geographic_distribution"] == {}
    assert report["demographics_distribution"] == {}


def test_generate_report_single_applicant():
    """Test generating report with one applicant"""
    # Create sample data with one applicant
    sample_data = [
        {
            "id": "001",
            "name": "John Smith",
            "gpa": 3.8,
            "sat_score": 1400,
            "act_score": 0,
            "gender": "Male",
            "ethnicity": "White",
            "state": "CA",
            "city": "Los Angeles",
            "is_first_generation": True,
            "has_financial_need": True,
            "extracurriculars": ["Basketball", "Student Council"],
            "essays": "I am passionate about community service..."
        }
    ]
    
    with patch("builtins.open", mock_open(read_data=json.dumps(sample_data))):
        system = AdmissionsSystem()
        system.load_applicants_from_json("dummy.json")
        report = system.generate_report()
        
        assert report["total_applicants"] == 1
        assert len(report["top_applicants"]) == 1
        assert report["top_applicants"][0]["name"] == "John Smith"


def test_generate_report_multiple_applicants():
    """Test generating report with multiple applicants"""
    # Create sample data with two applicants
    sample_data = [
        {
            "id": "001",
            "name": "John Smith",
            "gpa": 3.8,
            "sat_score": 1400,
            "act_score": 0,
            "gender": "Male",
            "ethnicity": "White",
            "state": "CA",
            "city": "Los Angeles",
            "is_first_generation": True,
            "has_financial_need": True,
            "extracurriculars": ["Basketball", "Student Council"],
            "essays": "I am passionate about community service..."
        },
        {
            "id": "002",
            "name": "Emily Johnson",
            "gpa": 3.9,
            "sat_score": 0,
            "act_score": 32,
            "gender": "Female",
            "ethnicity": "Asian",
            "state": "NY",
            "city": "New York",
            "is_first_generation": False,
            "has_financial_need": False,
            "extracurriculars": ["Debate Team", "Science Club"],
            "essays": "I have always been interested in STEM fields..."
        }
    ]
    
    with patch("builtins.open", mock_open(read_data=json.dumps(sample_data))):
        system = AdmissionsSystem()
        system.load_applicants_from_json("dummy.json")
        report = system.generate_report()
        
        assert report["total_applicants"] == 2
        assert len(report["top_applicants"]) == 2
        assert report["geographic_distribution"]["CA"] == 1
        assert report["geographic_distribution"]["NY"] == 1


def test_save_report():
    """Test saving report to JSON file"""
    system = AdmissionsSystem()
    sample_report = {
        "total_applicants": 1,
        "decision_statistics": {"Admitted": 1},
        "score_statistics": {"average": 0.8, "max": 0.9, "min": 0.7},
        "top_applicants": [{"name": "John Smith", "id": "001", "score": 0.8, "decision": "Admitted"}],
        "geographic_distribution": {"CA": 1},
        "demographics_distribution": {"first_generation": 1},
        "scoring_metrics": {
            "geographic_weight": 0.25,
            "gpa_weight": 0.30,
            "test_weight": 0.30,
            "demographics_weight": 0.15
        }
    }
    
    # Mock file writing
    with patch("builtins.open", mock_open()) as mock_file:
        system.save_report(sample_report, "test_report.json")
        mock_file.assert_called_once_with("test_report.json", "w", encoding="utf-8")


def test_print_report():
    """Test printing report to console"""
    system = AdmissionsSystem()
    sample_report = {
        "total_applicants": 1,
        "decision_statistics": {"Admitted": 1},
        "score_statistics": {"average": 0.8, "max": 0.9, "min": 0.7},
        "top_applicants": [{"name": "John Smith", "id": "001", "score": 0.8, "decision": "Admitted"}],
        "geographic_distribution": {"CA": 1},
        "demographics_distribution": {"first_generation": 1},
        "scoring_metrics": {
            "geographic_weight": 0.25,
            "gpa_weight": 0.30,
            "test_weight": 0.30,
            "demographics_weight": 0.15
        }
    }
    
    # This test just ensures no exceptions are raised
    with patch("builtins.print") as mock_print:
        system.print_report(sample_report)
        assert mock_print.called


# Test edge cases
def test_edge_case_zero_scores():
    """Test edge case with zero scores"""
    weights = ScoringWeights(
        geographic_weight=0.0,
        gpa_weight=0.0,
        test_weight=0.0,
        demographics_weight=0.0
    )
    calculator = ScoringCalculator(weights)
    
    # All weights are zero, so score should be zero
    gpa_score = calculator.calculate_gpa_score(0.0)
    test_score = calculator.calculate_test_score(0, 0)
    geo_score = calculator.calculate_geographic_score({}, "", 0)
    demo_score = calculator.calculate_demographics_score(False, False)
    
    assert gpa_score == 0.0
    assert test_score == 0.0
    assert geo_score == 0.0
    assert demo_score == 0.0


def test_edge_case_max_scores():
    """Test edge case with maximum scores"""
    weights = ScoringWeights(
        geographic_weight=1.0,
        gpa_weight=0.0,
        test_weight=0.0,
        demographics_weight=0.0
    )
    calculator = ScoringCalculator(weights)
    
    # With maximum geographic score, result should be 1.0
    geo_score = calculator.calculate_geographic_score({"CA": 10, "NY": 5}, "CA", 15)
    
    assert geo_score == 1.0


# Test create_sample_data function
def test_create_sample_data():
    """Test create_sample_data function"""
    # This function is not in the provided code, but we can test that it would work
    # with the existing structure
    pass


def test_main_functionality():
    """Test main functionality end-to-end"""
    # Create sample data
    sample_data = [
        {
            "id": "001",
            "name": "John Smith",
            "gpa": 3.8,
            "sat_score": 1400,
            "act_score": 0,
            "gender": "Male",
            "ethnicity": "White",
            "state": "CA",
            "city": "Los Angeles",
            "is_first_generation": True,
            "has_financial_need": True,
            "extracurriculars": ["Basketball", "Student Council"],
            "essays": "I am passionate about community service..."
        }
    ]
    
    with patch("builtins.open", mock_open(read_data=json.dumps(sample_data))):
        system = AdmissionsSystem()
        system.load_applicants_from_json("dummy.json")
        report = system.generate_report()
        
        # Basic assertions
        assert report["total_applicants"] == 1
        assert report["decision_statistics"] == {}
        assert report["top_applicants"][0]["name"] == "John Smith"


if __name__ == "__main__":
    # Run all tests
    import pytest
    pytest.main([__file__, "-v"])