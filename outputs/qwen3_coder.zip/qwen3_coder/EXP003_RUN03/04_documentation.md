# Technical Documentation for Admissions System

## Overview

This document provides detailed technical documentation for the admissions system implemented in Python. The system processes applicant data, computes holistic admission scores, makes automated admission decisions, and generates comprehensive reports with statistical analysis.

## System Architecture

The system is organized into several core components:
- **Applicant Data Management**: Handles applicant data structures and input/output operations
- **Scoring Engine**: Calculates holistic scores using configurable weights
- **Admission Decision Engine**: Makes admission decisions based on calculated scores
- **Reporting System**: Generates summary statistics and detailed reports

## Core Classes and Functions

### 1. AdmissionDecision Enum

**Description**: Enumeration representing the possible admission decisions for applicants.

**Values**:
- `ADMIT` - Applicant is admitted
- `WAITLIST` - Applicant is placed on waitlist
- `REJECT` - Applicant is rejected

### 2. Applicant Data Class

**Description**: Data class representing an applicant with all relevant information.

**Attributes**:
- `id` (str): Unique identifier for the applicant
- `name` (str): Full name of the applicant
- `gpa` (float): Grade Point Average (0.0-4.0 scale)
- `sat_score` (int): SAT test score (0-1600 scale)
- `act_score` (int): ACT test score (0-36 scale)
- `gender` (str): Gender of the applicant
- `ethnicity` (str): Ethnicity of the applicant
- `state` (str): State of residence
- `city` (str): City of residence
- `is_first_generation` (bool): Whether applicant is first generation college student
- `has_financial_need` (bool): Whether applicant has demonstrated financial need
- `extracurriculars` (List[str]): List of extracurricular activities
- `essays` (str): Essay responses

### 3. ScoringWeights Class

**Description**: Manages the weights used in the holistic scoring calculation.

**Constructor Parameters**:
- `geographic_weight` (float, optional): Weight for geographic diversity scoring (default: 0.25)
- `gpa_weight` (float, optional): Weight for GPA scoring (default: 0.30)
- `test_weight` (float, optional): Weight for test scores (default: 0.30)
- `demographics_weight` (float, optional): Weight for demographics scoring (default: 0.15)

### 4. ScoringCalculator Class

**Description**: Handles all scoring calculations for applicants.

#### Methods:

##### `calculate_gpa_score(gpa: float) -> float`
**Description**: Calculates a normalized GPA score between 0 and 1.
**Parameters**:
- `gpa` (float): Applicant's GPA (0.0-4.0 scale)
**Returns**: Normalized GPA score (0.0-1.0)

##### `calculate_test_score(sat_score: int, act_score: int) -> float`
**Description**: Calculates a normalized test score between 0 and 1.
**Parameters**:
- `sat_score` (int): SAT score (0-1600 scale)
- `act_score` (int): ACT score (0-36 scale)
**Returns**: Normalized test score (0.0-1.0)

##### `calculate_geographic_score(state_distribution: Dict[str, int], state: str, total_applicants: int) -> float`
**Description**: Calculates geographic diversity score based on state distribution.
**Parameters**:
- `state_distribution` (Dict[str, int]): Dictionary mapping states to applicant counts
- `state` (str): Applicant's state of residence
- `total_applicants` (int): Total number of applicants
**Returns**: Geographic diversity score (0.0-1.0)

##### `calculate_demographics_score(is_first_generation: bool, has_financial_need: bool) -> float`
**Description**: Calculates demographics score based on applicant's background.
**Parameters**:
- `is_first_generation` (bool): Whether applicant is first generation college student
- `has_financial_need` (bool): Whether applicant has demonstrated financial need
**Returns**: Demographics score (0.0-1.0)

##### `calculate_holistic_score(applicant: Applicant, state_distribution: Dict[str, int], total_applicants: int) -> float`
**Description**: Calculates the holistic admission score for an applicant.
**Parameters**:
- `applicant` (Applicant): Applicant object
- `state_distribution` (Dict[str, int]): Dictionary mapping states to applicant counts
- `total_applicants` (int): Total number of applicants
**Returns**: Holistic admission score (0.0-1.0)

### 5. AdmissionsSystem Class

**Description**: Main class that orchestrates the entire admissions process.

#### Constructor Parameters:
- `scoring_weights` (ScoringWeights, optional): Custom scoring weights (defaults to standard weights)

#### Methods:

##### `load_applicants_from_json(filename: str) -> None`
**Description**: Loads applicant data from a JSON file.
**Parameters**:
- `filename` (str): Path to the JSON file containing applicant data
**Returns**: None

##### `load_applicants_from_csv(filename: str) -> None`
**Description**: Loads applicant data from a CSV file.
**Parameters**:
- `filename` (str): Path to the CSV file containing applicant data
**Returns**: None

##### `generate_report() -> Dict[str, Any]`
**Description**: Generates a comprehensive admissions report with statistics and analysis.
**Parameters**: None
**Returns**: Dictionary containing all report data

##### `save_report(report: Dict[str, Any], filename: str) -> None`
**Description**: Saves the generated report to a JSON file.
**Parameters**:
- `report` (Dict[str, Any]): Report data dictionary
- `filename` (str): Path to save the report file
**Returns**: None

##### `print_report(report: Dict[str, Any]) -> None`
**Description**: Prints a formatted report to the console.
**Parameters**:
- `report` (Dict[str, Any]): Report data dictionary
**Returns**: None

### 6. Utility Functions

##### `create_sample_data(filename: str) -> None`
**Description**: Creates sample applicant data for testing purposes.
**Parameters**:
- `filename` (str): Path to save the sample data file
**Returns**: None

##### `main() -> None`
**Description**: Main function that runs the complete admissions process.
**Parameters**: None
**Returns**: None

## Scoring Algorithm

The admissions system uses a weighted scoring algorithm that combines multiple factors:

1. **GPA Score**: Normalized from 0.0-4.0 scale to 0.0-1.0 scale
2. **Test Score**: Uses either SAT or ACT score, normalized to 0.0-1.0 scale
3. **Geographic Diversity**: Score inversely related to population density in applicant's state
4. **Demographics**: Bonus points for first-generation students and those with financial need

## Data Flow

1. **Input**: Applicant data loaded from JSON/CSV files
2. **Processing**: 
   - Individual scores calculated for each applicant
   - Holistic score computed using configured weights
   - Admission decision made based on threshold
3. **Output**: Comprehensive report with statistics and individual results

## Configuration

The system supports configurable scoring weights through the `ScoringWeights` class, allowing administrators to adjust the importance of different factors in the admission process.

## Output Format

The system generates a comprehensive JSON report containing:
- Total applicant count
- Decision statistics (Admitted, Waitlisted, Rejected)
- Score statistics (Average, Max, Min)
- Geographic distribution
- Demographics distribution
- Top applicants with scores and decisions
- Scoring metrics showing current weights

## Usage Example

```python
# Initialize system
admissions_system = AdmissionsSystem()

# Load data
admissions_system.load_applicants_from_json('applicants.json')

# Generate report
report = admissions_system.generate_report()

# Save and display report
admissions_system.save_report(report, 'admissions_report.json')
admissions_system.print_report(report)
```

## Requirements

- Python 3.6+
- Standard library modules only (no external dependencies)

## Limitations

- Currently only supports JSON and CSV input formats
- Geographic diversity scoring is based on state-level population distribution
- No support for real-time data processing or web interface
- Scoring weights are fixed at initialization time

This system provides a complete solution for automated admissions processing with transparency in scoring methodology and comprehensive reporting capabilities.