import csv
import json
import math
from collections import defaultdict
from typing import List, Dict, Tuple, Any
from dataclasses import dataclass
from enum import Enum

class AdmissionDecision(Enum):
    ADMIT = "Admit"
    WAITLIST = "Waitlist"
    REJECT = "Reject"

@dataclass
class Applicant:
    id: str
    name: str
    gpa: float
    sat_score: int
    act_score: int
    gender: str
    ethnicity: str
    state: str
    city: str
    is_first_generation: bool
    has_financial_need: bool
    extracurriculars: List[str]
    essays: str

class AdmissionScorer:
    def __init__(self, geographic_weight: float = 0.2, gpa_weight: float = 0.3, 
                 test_weight: float = 0.3, demographics_weight: float = 0.2):
        self.geographic_weight = geographic_weight
        self.gpa_weight = gpa_weight
        self.test_weight = test_weight
        self.demographics_weight = demographics_weight
        
        # Geographic distribution targets
        self.state_targets = {
            'CA': 0.15, 'TX': 0.15, 'NY': 0.10, 'FL': 0.10, 'IL': 0.08,
            'PA': 0.05, 'OH': 0.05, 'GA': 0.05, 'NC': 0.05, 'MI': 0.05
        }
        
        # Demographics targets
        self.demographics_targets = {
            'first_generation': 0.3,
            'financial_need': 0.25
        }
        
        # Test score normalization
        self.sat_max = 1600
        self.act_max = 36
    
    def normalize_gpa(self, gpa: float) -> float:
        """Normalize GPA to 0-1 scale"""
        return min(1.0, max(0.0, gpa / 4.0))
    
    def normalize_test_score(self, sat_score: int, act_score: int) -> float:
        """Normalize test scores to 0-1 scale"""
        if sat_score > 0:
            return sat_score / self.sat_max
        elif act_score > 0:
            return act_score / self.act_max
        return 0.0
    
    def calculate_geographic_score(self, state: str, current_distribution: Dict[str, int], 
                                 total_applicants: int) -> float:
        """Calculate geographic diversity score"""
        if total_applicants == 0:
            return 1.0
        
        current_count = current_distribution.get(state, 0)
        target_ratio = self.state_targets.get(state, 0.05)  # Default 5% if not specified
        
        # Calculate how much this state is underrepresented
        if target_ratio > 0:
            current_ratio = current_count / total_applicants
            # Score is higher when current ratio is below target
            score = max(0.0, 1.0 - abs(current_ratio - target_ratio))
        else:
            # For states not in targets, give moderate score
            score = 0.5
        
        return score
    
    def calculate_demographics_score(self, applicant: Applicant, 
                                   current_demographics: Dict[str, int], 
                                   total_applicants: int) -> float:
        """Calculate demographic diversity score"""
        if total_applicants == 0:
            return 0.5
        
        # Calculate score for first generation students
        first_gen_score = 0.0
        if applicant.is_first_generation:
            current_count = current_demographics.get('first_generation', 0)
            current_ratio = current_count / total_applicants
            if current_ratio < self.demographics_targets['first_generation']:
                first_gen_score = 1.0 - current_ratio
        
        # Calculate score for financial need
        financial_score = 0.0
        if applicant.has_financial_need:
            current_count = current_demographics.get('financial_need', 0)
            current_ratio = current_count / total_applicants
            if current_ratio < self.demographics_targets['financial_need']:
                financial_score = 1.0 - current_ratio
        
        # Combine scores
        return (first_gen_score + financial_score) / 2.0
    
    def calculate_holistic_score(self, applicant: Applicant, 
                               current_distribution: Dict[str, int], 
                               current_demographics: Dict[str, int], 
                               total_applicants: int) -> float:
        """Calculate the holistic admission score"""
        # GPA component
        gpa_score = self.normalize_gpa(applicant.gpa)
        
        # Test score component
        test_score = self.normalize_test_score(applicant.sat_score, applicant.act_score)
        
        # Geographic diversity component
        geo_score = self.calculate_geographic_score(applicant.state, current_distribution, total_applicants)
        
        # Demographics component
        demo_score = self.calculate_demographics_score(applicant, current_demographics, total_applicants)
        
        # Calculate weighted score
        holistic_score = (
            self.gpa_weight * gpa_score +
            self.test_weight * test_score +
            self.geographic_weight * geo_score +
            self.demographics_weight * demo_score
        )
        
        return holistic_score

class UniversityAdmissionsSystem:
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.scorer = AdmissionScorer()
        self.decision_thresholds = {
            'admit': 0.8,
            'waitlist': 0.6
        }
    
    def load_applicants_from_csv(self, filename: str):
        """Load applicant data from CSV file"""
        try:
            with open(filename, 'r', newline='', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    applicant = Applicant(
                        id=row['id'],
                        name=row['name'],
                        gpa=float(row['gpa']),
                        sat_score=int(row['sat_score']) if row['sat_score'] else 0,
                        act_score=int(row['act_score']) if row['act_score'] else 0,
                        gender=row['gender'],
                        ethnicity=row['ethnicity'],
                        state=row['state'],
                        city=row['city'],
                        is_first_generation=row['is_first_generation'].lower() == 'true',
                        has_financial_need=row['has_financial_need'].lower() == 'true',
                        extracurriculars=row['extracurriculars'].split(';') if row['extracurriculars'] else [],
                        essays=row['essays']
                    )
                    self.applicants.append(applicant)
        except Exception as e:
            print(f"Error loading CSV file: {e}")
    
    def load_applicants_from_json(self, filename: str):
        """Load applicant data from JSON file"""
        try:
            with open(filename, 'r', encoding='utf-8') as jsonfile:
                data = json.load(jsonfile)
                for item in data:
                    applicant = Applicant(
                        id=item['id'],
                        name=item['name'],
                        gpa=float(item['gpa']),
                        sat_score=int(item['sat_score']) if item['sat_score'] else 0,
                        act_score=int(item['act_score']) if item['act_score'] else 0,
                        gender=item['gender'],
                        ethnicity=item['ethnicity'],
                        state=item['state'],
                        city=item['city'],
                        is_first_generation=item['is_first_generation'],
                        has_financial_need=item['has_financial_need'],
                        extracurriculars=item['extracurriculars'] if 'extracurriculars' in item else [],
                        essays=item['essays'] if 'essays' in item else ''
                    )
                    self.applicants.append(applicant)
        except Exception as e:
            print(f"Error loading JSON file: {e}")
    
    def calculate_current_distribution(self) -> Tuple[Dict[str, int], Dict[str, int]]:
        """Calculate current distribution of applicants by state and demographics"""
        state_distribution = defaultdict(int)
        demographics_distribution = defaultdict(int)
        
        for applicant in self.applicants:
            state_distribution[applicant.state] += 1
            if applicant.is_first_generation:
                demographics_distribution['first_generation'] += 1
            if applicant.has_financial_need:
                demographics_distribution['financial_need'] += 1
        
        return dict(state_distribution), dict(demographics_distribution)
    
    def process_applicants(self) -> List[Tuple[Applicant, float, AdmissionDecision]]:
        """Process all applicants and return decisions"""
        results = []
        state_distribution, demographics_distribution = self.calculate_current_distribution()
        
        # Process each applicant
        for applicant in self.applicants:
            holistic_score = self.scorer.calculate_holistic_score(
                applicant, state_distribution, demographics_distribution, len(self.applicants)
            )
            
            # Make admission decision
            if holistic_score >= self.decision_thresholds['admit']:
                decision = AdmissionDecision.ADMIT
            elif holistic_score >= self.decision_thresholds['waitlist']:
                decision = AdmissionDecision.WAITLIST
            else:
                decision = AdmissionDecision.REJECT
            
            results.append((applicant, holistic_score, decision))
        
        return results
    
    def generate_report(self) -> Dict[str, Any]:
        """Generate a summary report of the admissions process"""
        results = self.process_applicants()
        
        # Count decisions
        decision_counts = defaultdict(int)
        for _, _, decision in results:
            decision_counts[decision.value] += 1
        
        # Calculate statistics
        scores = [score for _, score, _ in results]
        avg_score = sum(scores) / len(scores) if scores else 0
        max_score = max(scores) if scores else 0
        min_score = min(scores) if scores else 0
        
        # Geographic distribution
        state_distribution, _ = self.calculate_current_distribution()
        
        # Demographics distribution
        _, demographics_distribution = self.calculate_current_distribution()
        
        # Top applicants by score
        sorted_results = sorted(results, key=lambda x: x[1], reverse=True)
        top_applicants = [
            {
                'name': applicant.name,
                'id': applicant.id,
                'score': score,
                'decision': decision.value
            }
            for applicant, score, decision in sorted_results[:10]
        ]
        
        report = {
            'total_applicants': len(self.applicants),
            'decision_statistics': dict(decision_counts),
            'score_statistics': {
                'average': round(avg_score, 3),
                'max': round(max_score, 3),
                'min': round(min_score, 3)
            },
            'geographic_distribution': state_distribution,
            'demographics_distribution': demographics_distribution,
            'top_applicants': top_applicants,
            'scoring_metrics': {
                'geographic_weight': self.scorer.geographic_weight,
                'gpa_weight': self.scorer.gpa_weight,
                'test_weight': self.scorer.test_weight,
                'demographics_weight': self.scorer.demographics_weight
            }
        }
        
        return report
    
    def save_report(self, report: Dict[str, Any], filename: str):
        """Save the report to a JSON file"""
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
    
    def print_report(self, report: Dict[str, Any]):
        """Print a formatted report to console"""
        print("\n" + "="*60)
        print("UNIVERSITY ADMISSIONS REPORT")
        print("="*60)
        print(f"Total Applicants: {report['total_applicants']}")
        print()
        
        print("Decision Statistics:")
        for decision, count in report['decision_statistics'].items():
            print(f"  {decision}: {count}")
        print()
        
        print("Score Statistics:")
        stats = report['score_statistics']
        print(f"  Average Score: {stats['average']}")
        print(f"  Maximum Score: {stats['max']}")
        print(f"  Minimum Score: {stats['min']}")
        print()
        
        print("Geographic Distribution:")
        for state, count in sorted(report['geographic_distribution'].items()):
            print(f"  {state}: {count}")
        print()
        
        print("Demographics Distribution:")
        for demo, count in report['demographics_distribution'].items():
            print(f"  {demo}: {count}")
        print()
        
        print("Scoring Metrics:")
        metrics = report['scoring_metrics']
        print(f"  Geographic Weight: {metrics['geographic_weight']}")
        print(f"  GPA Weight: {metrics['gpa_weight']}")
        print(f"  Test Weight: {metrics['test_weight']}")
        print(f"  Demographics Weight: {metrics['demographics_weight']}")
        print()
        
        print("Top 10 Applicants:")
        for i, applicant in enumerate(report['top_applicants'], 1):
            print(f"  {i}. {applicant['name']} (ID: {applicant['id']})")
            print(f"     Score: {applicant['score']}, Decision: {applicant['decision']}")
        print("="*60)

def create_sample_data():
    """Create sample applicant data for testing"""
    sample_data = [
        {
            "id": "001",
            "name": "John Smith",
            "gpa": 3.8,
            "sat_score": 1400,
            "act_score": 0,
            "gender": "Male",
            "ethnicity": "White",
            "state": "CA",
            "city": "Los Angeles",
            "is_first_generation": True,
            "has_financial_need": True,
            "extracurriculars": ["Basketball", "Debate"],
            "essays": "Essay about community service"
        },
        {
            "id": "002",
            "name": "Emily Johnson",
            "gpa": 3.9,
            "sat_score": 0,
            "act_score": 32,
            "gender": "Female",
            "ethnicity": "Asian",
            "state": "NY",
            "city": "New York",
            "is_first_generation": False,
            "has_financial_need": False,
            "extracurriculars": ["Chess", "Volunteer Work"],
            "essays": "Essay about leadership experience"
        },
        {
            "id": "003",
            "name": "Michael Brown",
            "gpa": 3.7,
            "sat_score": 1350,
            "act_score": 0,
            "gender": "Male",
            "ethnicity": "Hispanic",
            "state": "TX",
            "city": "Houston",
            "is_first_generation": True,
            "has_financial_need": True,
            "extracurriculars": ["Music", "Student Government"],
            "essays": "Essay about overcoming challenges"
        },
        {
            "id": "004",
            "name": "Sarah Davis",
            "gpa": 4.0,
            "sat_score": 1500,
            "act_score": 0,
            "gender": "Female",
            "ethnicity": "White",
            "state": "FL",
            "city": "Miami",
            "is_first_generation": False,
            "has_financial_need": False,
            "extracurriculars": ["Science Club", "Tutoring"],
            "essays": "Essay about research interests"
        },
        {
            "id": "005",
            "name": "David Wilson",
            "gpa": 3.6,
            "sat_score": 1200,
            "act_score": 0,
            "gender": "Male",
            "ethnicity": "Black",
            "state": "GA",
            "city": "Atlanta",
            "is_first_generation": True,
            "has_financial_need": True,
            "extracurriculars": ["Art", "Community Service"],
            "essays": "Essay about personal growth"
        }
    ]
    
    # Save sample data to JSON file
    with open('sample_applicants.json', 'w') as f:
        json.dump(sample_data, f, indent=2)
    
    print("Sample data created in 'sample_applicants.json'")

def main():
    """Main function to run the admissions system"""
    print("University Admissions Screening System")
    print("="*40)
    
    # Create sample data if it doesn't exist
    try:
        with open('sample_applicants.json', 'r'):
            pass
    except FileNotFoundError:
        create_sample_data()
    
    # Initialize the admissions system
    admissions_system = UniversityAdmissionsSystem()
    
    # Load sample applicants
    print("Loading sample applicant data...")
    admissions_system.load_applicants_from_json('sample_applicants.json')
    
    # Generate and display report
    print("Processing applicants and generating report...")
    report = admissions_system.generate_report()
    
    # Print report to console
    admissions_system.print_report(report)
    
    # Save report to file
    admissions_system.save_report(report, 'admissions_report.json')
    print("\nReport saved to 'admissions_report.json'")
    
    # Example of how to load from CSV (uncomment if you have a CSV file)
    # admissions_system.load_applicants_from_csv('applicants.csv')

if __name__ == "__main__":
    main()