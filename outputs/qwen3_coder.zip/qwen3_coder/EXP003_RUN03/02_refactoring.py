import csv
import json
import math
from collections import defaultdict
from typing import List, Dict, Tuple, Any
from dataclasses import dataclass
from enum import Enum


class AdmissionDecision(Enum):
    """Enumeration for admission decisions"""
    ADMIT = "Admit"
    WAITLIST = "Waitlist"
    REJECT = "Reject"


@dataclass
class Applicant:
    """Data class representing an applicant"""
    id: str
    name: str
    gpa: float
    sat_score: int
    act_score: int
    gender: str
    ethnicity: str
    state: str
    city: str
    is_first_generation: bool
    has_financial_need: bool
    extracurriculars: List[str]
    essays: str


class ScoringWeights:
    """Class to manage scoring weights"""
    def __init__(self, geographic_weight: float = 0.25, gpa_weight: float = 0.30,
                 test_weight: float = 0.30, demographics_weight: float = 0.15):
        self.geographic_weight = geographic_weight
        self.gpa_weight = gpa_weight
        self.test_weight = test_weight
        self.demographics_weight = demographics_weight


class ScoringCalculator:
    """Class to handle scoring calculations"""
    
    def __init__(self, weights: ScoringWeights):
        self.weights = weights
        self.sat_max = 1600
        self.act_max = 36
        
    def calculate_gpa_score(self, gpa: float) -> float:
        """Calculate GPA score (0-1 scale)"""
        return min(1.0, gpa / 4.0)
    
    def calculate_test_score(self, sat_score: int, act_score: int) -> float:
        """Calculate test score (0-1 scale)"""
        if sat_score > 0:
            return sat_score / self.sat_max
        elif act_score > 0:
            return act_score / self.act_max
        return 0.0
    
    def calculate_geographic_score(self, state_distribution: Dict[str, int], 
                                   state: str, total_applicants: int) -> float:
        """Calculate geographic score based on state distribution"""
        if total_applicants == 0:
            return 0.0
        state_count = state_distribution.get(state, 0)
        # Normalize by total applicants to get a score between 0 and 1
        return 1.0 - (state_count / total_applicants)
    
    def calculate_demographics_score(self, is_first_generation: bool, 
                                     has_financial_need: bool) -> float:
        """Calculate demographics score based on applicant's background"""
        # First generation students and those with financial need get higher scores
        score = 0.0
        if is_first_generation:
            score += 0.5
        if has_financial_need:
            score += 0.5
        return min(1.0, score)
    
    def calculate_holistic_score(self, applicant: Applicant, 
                                state_distribution: Dict[str, int],
                                total_applicants: int) -> float:
        """Calculate the holistic score for an applicant"""
        gpa_score = self.calculate_gpa_score(applicant.gpa)
        test_score = self.calculate_test_score(applicant.sat_score, applicant.act_score)
        geographic_score = self.calculate_geographic_score(state_distribution, 
                                                           applicant.state, 
                                                           total_applicants)
        demographics_score = self.calculate_demographics_score(
            applicant.is_first_generation, applicant.has_financial_need)
        
        # Weighted sum of all scores
        holistic_score = (
            self.weights.gpa_weight * gpa_score +
            self.weights.test_weight * test_score +
            self.weights.geographic_weight * geographic_score +
            self.weights.demographics_weight * demographics_score
        )
        
        return holistic_score


class AdmissionsSystem:
    """Main admissions system class"""
    
    def __init__(self, scoring_weights: ScoringWeights = None):
        self.applicants: List[Applicant] = []
        self.scoring_weights = scoring_weights or ScoringWeights()
        self.scoring_calculator = ScoringCalculator(self.scoring_weights)
        self.decision_thresholds = {
            'admit': 0.8,
            'waitlist': 0.6
        }
    
    def load_applicants_from_json(self, filename: str) -> None:
        """Load applicants from a JSON file"""
        with open(filename, 'r') as file:
            data = json.load(file)
        
        self.applicants = []
        for item in data:
            applicant = Applicant(
                id=item['id'],
                name=item['name'],
                gpa=item['gpa'],
                sat_score=item['sat_score'],
                act_score=item['act_score'],
                gender=item['gender'],
                ethnicity=item['ethnicity'],
                state=item['state'],
                city=item['city'],
                is_first_generation=item['is_first_generation'],
                has_financial_need=item['has_financial_need'],
                extracurriculars=item['extracurriculars'],
                essays=item['essays']
            )
            self.applicants.append(applicant)
    
    def load_applicants_from_csv(self, filename: str) -> None:
        """Load applicants from a CSV file"""
        with open(filename, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                applicant = Applicant(
                    id=row['id'],
                    name=row['name'],
                    gpa=float(row['gpa']),
                    sat_score=int(row['sat_score']),
                    act_score=int(row['act_score']),
                    gender=row['gender'],
                    ethnicity=row['ethnicity'],
                    state=row['state'],
                    city=row['city'],
                    is_first_generation=row['is_first_generation'] == 'True',
                    has_financial_need=row['has_financial_need'] == 'True',
                    extracurriculars=row['extracurriculars'].split(';'),
                    essays=row['essays']
                )
                self.applicants.append(applicant)
    
    def calculate_distribution(self) -> Tuple[Dict[str, int], Dict[str, int]]:
        """Calculate state and demographics distributions"""
        state_distribution = defaultdict(int)
        demographics_distribution = defaultdict(int)
        
        for applicant in self.applicants:
            state_distribution[applicant.state] += 1
            if applicant.is_first_generation:
                demographics_distribution['first_generation'] += 1
            if applicant.has_financial_need:
                demographics_distribution['financial_need'] += 1
        
        return dict(state_distribution), dict(demographics_distribution)
    
    def process_applicants(self) -> List[Tuple[Applicant, float, AdmissionDecision]]:
        """Process all applicants and make admission decisions"""
        state_distribution, _ = self.calculate_distribution()
        results = []
        
        for applicant in self.applicants:
            holistic_score = self.scoring_calculator.calculate_holistic_score(
                applicant, state_distribution, len(self.applicants)
            )
            
            # Make admission decision
            if holistic_score >= self.decision_thresholds['admit']:
                decision = AdmissionDecision.ADMIT
            elif holistic_score >= self.decision_thresholds['waitlist']:
                decision = AdmissionDecision.WAITLIST
            else:
                decision = AdmissionDecision.REJECT
            
            results.append((applicant, holistic_score, decision))
        
        return results
    
    def generate_report(self) -> Dict[str, Any]:
        """Generate a summary report of the admissions process"""
        results = self.process_applicants()
        
        # Count decisions
        decision_counts = defaultdict(int)
        for _, _, decision in results:
            decision_counts[decision.value] += 1
        
        # Calculate statistics
        scores = [score for _, score, _ in results]
        avg_score = sum(scores) / len(scores) if scores else 0
        max_score = max(scores) if scores else 0
        min_score = min(scores) if scores else 0
        
        # Geographic distribution
        state_distribution, demographics_distribution = self.calculate_distribution()
        
        # Top applicants by score
        sorted_results = sorted(results, key=lambda x: x[1], reverse=True)
        top_applicants = [
            {
                'name': applicant.name,
                'id': applicant.id,
                'score': score,
                'decision': decision.value
            }
            for applicant, score, decision in sorted_results[:10]
        ]
        
        report = {
            'total_applicants': len(self.applicants),
            'decision_statistics': dict(decision_counts),
            'score_statistics': {
                'average': round(avg_score, 3),
                'max': round(max_score, 3),
                'min': round(min_score, 3)
            },
            'geographic_distribution': state_distribution,
            'demographics_distribution': demographics_distribution,
            'top_applicants': top_applicants,
            'scoring_metrics': {
                'geographic_weight': self.scoring_weights.geographic_weight,
                'gpa_weight': self.scoring_weights.gpa_weight,
                'test_weight': self.scoring_weights.test_weight,
                'demographics_weight': self.scoring_weights.demographics_weight
            }
        }
        
        return report
    
    def save_report(self, report: Dict[str, Any], filename: str) -> None:
        """Save the report to a JSON file"""
        with open(filename, 'w', encoding='utf-8') as file:
            json.dump(report, file, indent=2, ensure_ascii=False)
    
    def print_report(self, report: Dict[str, Any]) -> None:
        """Print a formatted report to console"""
        print("\n" + "="*60)
        print("UNIVERSITY ADMISSIONS REPORT")
        print("="*60)
        print(f"Total Applicants: {report['total_applicants']}")
        print()
        
        print("Decision Statistics:")
        for decision, count in report['decision_statistics'].items():
            print(f"  {decision}: {count}")
        print()
        
        print("Score Statistics:")
        stats = report['score_statistics']
        print(f"  Average: {stats['average']}")
        print(f"  Max: {stats['max']}")
        print(f"  Min: {stats['min']}")
        print()
        
        print("Geographic Distribution:")
        for state, count in report['geographic_distribution'].items():
            print(f"  {state}: {count}")
        print()
        
        print("Demographics Distribution:")
        for category, count in report['demographics_distribution'].items():
            print(f"  {category}: {count}")
        print()
        
        print("Top Applicants:")
        for i, applicant in enumerate(report['top_applicants'], 1):
            print(f"  {i}. {applicant['name']} ({applicant['id']}) - "
                  f"Score: {applicant['score']}, Decision: {applicant['decision']}")
        print()
        
        print("Scoring Metrics:")
        metrics = report['scoring_metrics']
        print(f"  Geographic Weight: {metrics['geographic_weight']}")
        print(f"  GPA Weight: {metrics['gpa_weight']}")
        print(f"  Test Weight: {metrics['test_weight']}")
        print(f"  Demographics Weight: {metrics['demographics_weight']}")
        print("="*60)


def create_sample_data(filename: str) -> None:
    """Create sample applicant data for testing"""
    sample_data = [
        {
            "id": "001",
            "name": "John Smith",
            "gpa": 3.8,
            "sat_score": 1400,
            "act_score": 0,
            "gender": "Male",
            "ethnicity": "White",
            "state": "CA",
            "city": "Los Angeles",
            "is_first_generation": True,
            "has_financial_need": True,
            "extracurriculars": ["Basketball", "Student Council"],
            "essays": "I am passionate about community service..."
        },
        {
            "id": "002",
            "name": "Emily Johnson",
            "gpa": 3.9,
            "sat_score": 0,
            "act_score": 32,
            "gender": "Female",
            "ethnicity": "Asian",
            "state": "NY",
            "city": "New York",
            "is_first_generation": False,
            "has_financial_need": False,
            "extracurriculars": ["Debate Team", "Science Club"],
            "essays": "I have always been interested in STEM fields..."
        }
    ]
    
    with open(filename, 'w') as file:
        json.dump(sample_data, file, indent=2)


def main():
    """Main function to run the admissions system"""
    # Create sample data
    create_sample_data('sample_applicants.json')
    
    # Initialize the admissions system
    admissions_system = AdmissionsSystem()
    
    # Load applicants
    admissions_system.load_applicants_from_json('sample_applicants.json')
    
    # Process applicants and generate report
    report = admissions_system.generate_report()
    
    # Save report
    admissions_system.save_report(report, 'admissions_report.json')
    
    # Print report
    admissions_system.print_report(report)
    
    print("Admissions process completed!")


if __name__ == "__main__":
    main()