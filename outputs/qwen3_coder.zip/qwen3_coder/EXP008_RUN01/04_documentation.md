# University Admissions Screening System - Technical Documentation

## Overview

The University Admissions Screening System is a comprehensive solution designed to process applicant data, compute holistic admission scores, and automate admission decisions. The system operates entirely offline without requiring external databases or services, providing transparent scoring metrics in generated reports.

## System Architecture

### Core Components

1. **AdmissionsScreeningSystem** - Main class managing all admissions operations
2. **Applicant** - Data class representing individual applicants
3. **AdmissionDecision** - Enumeration for admission outcomes

## Classes

### AdmissionDecision (Enum)
**Description:** Enumeration representing the possible admission decisions for applicants.

**Values:**
- `ADMIT` - Applicant should be admitted
- `WAITLIST` - Applicant should be placed on waitlist
- `REJECT` - Applicant should be rejected

### Applicant (Dataclass)
**Description:** Data class representing an individual applicant with all relevant information.

**Attributes:**
- `id: str` - Unique identifier for the applicant
- `name: str` - Applicant's full name
- `gpa: float` - Grade Point Average (assumed 4.0 scale)
- `sat_score: int` - SAT test score (0 if not taken)
- `act_score: int` - ACT test score (0 if not taken)
- `demographic: str` - Demographic information (e.g., "Male", "Female")
- `postal_code: str` - Applicant's postal code
- `income_level: str` - Income level (for internal mapping only)
- `extracurricular_score: int` - Extracurricular activities score (0-10)
- `essay_score: int` - Essay writing score (0-10)

### AdmissionsScreeningSystem (Main Class)
**Description:** Core class managing the entire admissions process including data storage, scoring calculations, and decision making.

## Methods

### `__init__(self)`
**Description:** Initializes the admissions system with default configurations and empty applicant list.

**Parameters:** None

**Return Type:** None

### `add_applicant(self, applicant: Applicant) -> None`
**Description:** Adds an applicant to the system's applicant list.

**Parameters:**
- `applicant: Applicant` - The applicant object to be added

**Return Type:** None

### `_calculate_normalized_gpa(self, gpa: float) -> float`
**Description:** Normalizes GPA value to a 0-1 scale assuming maximum GPA of 4.0.

**Parameters:**
- `gpa: float` - The raw GPA value to normalize

**Return Type:** float - Normalized GPA value (0.0 to 1.0)

### `_calculate_normalized_sat_score(self, sat_score: int) -> float`
**Description:** Normalizes SAT score to a 0-1 scale assuming maximum SAT score of 1600.

**Parameters:**
- `sat_score: int` - The raw SAT score to normalize

**Return Type:** float - Normalized SAT score (0.0 to 1.0)

### `_calculate_normalized_act_score(self, act_score: int) -> float`
**Description:** Normalizes ACT score to a 0-1 scale assuming maximum ACT score of 36.

**Parameters:**
- `act_score: int` - The raw ACT score to normalize

**Return Type:** float - Normalized ACT score (0.0 to 1.0)

### `_calculate_normalized_test_score(self, score: int, max_score: int) -> float`
**Description:** Helper method to normalize any test score to a 0-1 scale.

**Parameters:**
- `score: int` - The raw test score to normalize
- `max_score: int` - The maximum possible score for this test

**Return Type:** float - Normalized test score (0.0 to 1.0)

### `_calculate_test_score_weight(self, score: int, max_score: int, weight: float) -> float`
**Description:** Calculates weighted contribution of a test score to the holistic score.

**Parameters:**
- `score: int` - The raw test score
- `max_score: int` - The maximum possible score
- `weight: float` - Weight factor for this test (0.0 to 1.0)

**Return Type:** float - Weighted normalized test score

### `calculate_holistic_score(self, applicant: Applicant) -> float`
**Description:** Computes the holistic admission score for an applicant based on weighted components.

**Parameters:**
- `applicant: Applicant` - The applicant for whom to calculate the score

**Return Type:** float - Holistic score (0.0 to 1.0)

### `make_admission_decision(self, applicant: Applicant) -> AdmissionDecision`
**Description:** Makes an admission decision based on the applicant's holistic score.

**Parameters:**
- `applicant: Applicant` - The applicant for whom to make the decision

**Return Type:** AdmissionDecision - The admission decision (ADMIT, WAITLIST, or REJECT)

### `generate_summary_report(self) -> Dict[str, Any]`
**Description:** Generates a comprehensive summary report of all applicants and system statistics.

**Parameters:** None

**Return Type:** Dict[str, Any] - Dictionary containing:
- `total_applicants: int` - Total number of applicants
- `average_holistic_score: float` - Average of all holistic scores
- `median_holistic_score: float` - Median holistic score
- `std_deviation: float` - Standard deviation of scores
- `score_breakdown: Dict[str, float]` - Minimum and maximum scores
- `decision_distribution: Dict[str, int]` - Count of each decision type
- `income_distribution: Dict[str, int]` - Count of applicants by income level
- `demographic_distribution: Dict[str, int]` - Count of applicants by demographic
- `academic_statistics: Dict[str, float]` - Average GPA, SAT, and ACT scores

### `generate_detailed_report(self) -> List[Dict[str, Any]]`
**Description:** Generates a detailed report for each individual applicant.

**Parameters:** None

**Return Type:** List[Dict[str, Any]] - List of dictionaries containing detailed information for each applicant:
- `applicant_id: str` - Applicant's unique identifier
- `name: str` - Applicant's name
- `holistic_score: float` - Calculated holistic score
- `decision: str` - Admission decision
- `gpa: float` - Applicant's GPA
- `sat_score: int` - Applicant's SAT score
- `act_score: int` - Applicant's ACT score
- `income_level: str` - Applicant's income level

## Utility Functions

### `create_sample_applicants() -> List[Applicant]`
**Description:** Creates and returns a predefined set of sample applicants for demonstration purposes.

**Parameters:** None

**Return Type:** List[Applicant] - List of 10 sample applicant objects

### `display_summary_report(summary: Dict[str, Any]) -> None`
**Description:** Displays the summary report in a formatted console output.

**Parameters:**
- `summary: Dict[str, Any]` - The summary report dictionary to display

**Return Type:** None

### `display_detailed_report(detailed_report: List[Dict[str, Any]]) -> None`
**Description:** Displays the detailed report in a formatted console table.

**Parameters:**
- `detailed_report: List[Dict[str, Any]]` - The detailed report list to display

**Return Type:** None

### `main() -> None`
**Description:** Main function demonstrating the complete admissions system functionality.

**Parameters:** None

**Return Type:** None

## System Features

### 1. Holistic Scoring System
- Combines GPA, SAT/ACT scores, extracurricular activities, and essay writing
- Weighted scoring approach for different components
- Normalization of all scores to a common 0-1 scale

### 2. Income-Based Considerations
- Maps postal codes to income levels
- Incorporates income level as part of the holistic scoring framework

### 3. Automated Decision Making
- Clear decision thresholds for ADMIT, WAITLIST, and REJECT outcomes
- Transparent scoring system for reproducible results

### 4. Comprehensive Reporting
- Summary reports with statistical analysis
- Detailed individual applicant reports
- Distribution analysis by income and demographics

### 5. Offline Operation
- No external dependencies or database requirements
- Complete functionality within a single Python script

## Data Flow

1. **Input:** Applicant data (GPA, test scores, demographics, postal code)
2. **Processing:** 
   - Normalize all scores to 0-1 scale
   - Apply weighted calculations for holistic score
   - Determine admission decision based on score thresholds
3. **Output:** 
   - Summary statistics and distributions
   - Individual applicant decisions and scores
   - Detailed reports for each applicant

## Configuration

The system uses default weightings for different components:
- GPA: 0.3 weight
- Test scores: 0.4 weight (combined SAT/ACT)
- Extracurricular activities: 0.2 weight
- Essay writing: 0.1 weight

Income level information is used for demographic analysis but does not directly affect scoring calculations.

## Usage Example

```python
# Initialize system
system = AdmissionsScreeningSystem()

# Add applicants
sample_applicants = create_sample_applicants()
for applicant in sample_applicants:
    system.add_applicant(applicant)

# Generate reports
summary = system.generate_summary_report()
detailed_report = system.generate_detailed_report()

# Display results
display_summary_report(summary)
display_detailed_report(detailed_report)
```

This system provides a complete, self-contained solution for university admissions processing with transparent scoring and automated decision making capabilities.