"""
University Admissions Screening System
"""

import random
import statistics
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from enum import Enum
import json


class AdmissionDecision(Enum):
    """Enumeration for admission decisions"""
    ADMIT = "Admit"
    WAITLIST = "Waitlist"
    REJECT = "Reject"


@dataclass
class Applicant:
    """Data class representing an applicant"""
    id: str
    name: str
    gpa: float
    sat_score: int
    act_score: int
    demographic: str
    postal_code: str
    income_level: str
    extracurricular_score: int
    essay_score: int


class AdmissionsScreeningSystem:
    """Main admissions screening system class"""
    
    def __init__(self):
        """Initialize the admissions system"""
        self.applicants: List[Applicant] = []
        self.income_adjustments = {
            "high": 0.15,   # 15% adjustment for high-income regions
            "medium": 0.05, # 5% adjustment for medium-income regions
            "low": 0.0      # No adjustment for low-income regions
        }
        
        # Define income levels for postal codes (simplified)
        self.postal_income_map = {
            "M5V": "high", "M5W": "high", "M5X": "high", "M5Y": "high", "M5Z": "high",
            "M4V": "medium", "M4W": "medium", "M4X": "medium", "M4Y": "medium", "M4Z": "medium",
            "M3V": "low", "M3W": "low", "M3X": "low", "M3Y": "low", "M3Z": "low"
        }

    def add_applicant(self, applicant: Applicant) -> None:
        """Add an applicant to the system"""
        self.applicants.append(applicant)

    def _calculate_normalized_gpa(self, gpa: float) -> float:
        """Normalize GPA (assuming 4.0 max)"""
        return gpa / 4.0

    def _calculate_normalized_sat_score(self, sat_score: int) -> float:
        """Normalize SAT score (assuming 1600 max)"""
        return sat_score / 1600.0 if sat_score > 0 else 0

    def _calculate_normalized_act_score(self, act_score: int) -> float:
        """Normalize ACT score (assuming 36 max)"""
        return act_score / 36.0 if act_score > 0 else 0

    def _calculate_test_score(self, sat_score: int, act_score: int) -> float:
        """Calculate test score (use SAT if available, otherwise ACT)"""
        normalized_sat = self._calculate_normalized_sat_score(sat_score)
        normalized_act = self._calculate_normalized_act_score(act_score)
        return normalized_sat if sat_score > 0 else normalized_act

    def calculate_holistic_score(self, applicant: Applicant) -> float:
        """Calculate holistic admission score for an applicant"""
        # Base components
        gpa_weight = 0.3
        test_weight = 0.4
        extracurricular_weight = 0.15
        essay_weight = 0.15
        
        # Calculate normalized scores
        normalized_gpa = self._calculate_normalized_gpa(applicant.gpa)
        test_score = self._calculate_test_score(applicant.sat_score, applicant.act_score)
        
        # Calculate base holistic score
        base_score = (
            normalized_gpa * gpa_weight +
            test_score * test_weight +
            applicant.extracurricular_score / 10.0 * extracurricular_weight +
            applicant.essay_score / 10.0 * essay_weight
        )
        
        # Apply income adjustment
        income_level = self.postal_income_map.get(applicant.postal_code[:3], "low")
        income_adjustment = self.income_adjustments[income_level]
        
        adjusted_score = base_score + (base_score * income_adjustment)
        
        return adjusted_score

    def make_admission_decision(self, applicant: Applicant) -> Tuple[AdmissionDecision, float]:
        """Make admission decision based on holistic score"""
        score = self.calculate_holistic_score(applicant)
        
        # Decision thresholds (can be adjusted)
        if score >= 0.85:
            return AdmissionDecision.ADMIT, score
        elif score >= 0.70:
            return AdmissionDecision.WAITLIST, score
        else:
            return AdmissionDecision.REJECT, score

    def _calculate_decision_distribution(self, decisions: List[AdmissionDecision]) -> Dict[str, int]:
        """Calculate distribution of admission decisions"""
        return {
            "admit": decisions.count(AdmissionDecision.ADMIT),
            "waitlist": decisions.count(AdmissionDecision.WAITLIST),
            "reject": decisions.count(AdmissionDecision.REJECT)
        }

    def _calculate_income_distribution(self) -> Dict[str, int]:
        """Calculate distribution of applicants by income level"""
        income_breakdown = {}
        for applicant in self.applicants:
            income_level = self.postal_income_map.get(applicant.postal_code[:3], "low")
            if income_level not in income_breakdown:
                income_breakdown[income_level] = 0
            income_breakdown[income_level] += 1
        return income_breakdown

    def _calculate_demographic_distribution(self) -> Dict[str, int]:
        """Calculate distribution of applicants by demographic"""
        demographic_breakdown = {}
        for applicant in self.applicants:
            demographic = applicant.demographic
            if demographic not in demographic_breakdown:
                demographic_breakdown[demographic] = 0
            demographic_breakdown[demographic] += 1
        return demographic_breakdown

    def _calculate_academic_statistics(self) -> Dict[str, float]:
        """Calculate academic statistics for the applicants"""
        if not self.applicants:
            return {"average_gpa": 0.0, "average_sat": 0.0, "average_act": 0.0}
        
        gpas = [applicant.gpa for applicant in self.applicants]
        sat_scores = [applicant.sat_score for applicant in self.applicants if applicant.sat_score > 0]
        act_scores = [applicant.act_score for applicant in self.applicants if applicant.act_score > 0]
        
        return {
            "average_gpa": sum(gpas) / len(gpas),
            "average_sat": sum(sat_scores) / len(sat_scores) if sat_scores else 0.0,
            "average_act": sum(act_scores) / len(act_scores) if act_scores else 0.0
        }

    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of all applicants"""
        if not self.applicants:
            return {
                "total_applicants": 0,
                "average_holistic_score": 0.0,
                "median_holistic_score": 0.0,
                "std_deviation": 0.0,
                "score_breakdown": {"min": 0.0, "max": 0.0},
                "decision_distribution": {"admit": 0, "waitlist": 0, "reject": 0},
                "income_distribution": {},
                "demographic_distribution": {},
                "academic_statistics": {"average_gpa": 0.0, "average_sat": 0.0, "average_act": 0.0}
            }
        
        # Calculate holistic scores for all applicants
        holistic_scores = [self.calculate_holistic_score(applicant) for applicant in self.applicants]
        
        # Calculate decision distribution
        decisions = [self.make_admission_decision(applicant)[0] for applicant in self.applicants]
        decision_distribution = self._calculate_decision_distribution(decisions)
        
        # Calculate other distributions
        income_distribution = self._calculate_income_distribution()
        demographic_distribution = self._calculate_demographic_distribution()
        academic_statistics = self._calculate_academic_statistics()
        
        return {
            "total_applicants": len(self.applicants),
            "average_holistic_score": sum(holistic_scores) / len(holistic_scores),
            "median_holistic_score": statistics.median(holistic_scores),
            "std_deviation": statistics.stdev(holistic_scores) if len(holistic_scores) > 1 else 0.0,
            "score_breakdown": {
                "min": min(holistic_scores),
                "max": max(holistic_scores)
            },
            "decision_distribution": decision_distribution,
            "income_distribution": income_distribution,
            "demographic_distribution": demographic_distribution,
            "academic_statistics": academic_statistics
        }

    def generate_detailed_report(self) -> List[Dict[str, Any]]:
        """Generate a detailed report for each applicant"""
        detailed_report = []
        for applicant in self.applicants:
            decision, score = self.make_admission_decision(applicant)
            income_level = self.postal_income_map.get(applicant.postal_code[:3], "low")
            
            detailed_report.append({
                "applicant_id": applicant.id,
                "name": applicant.name,
                "holistic_score": score,
                "decision": decision.value,
                "gpa": applicant.gpa,
                "sat_score": applicant.sat_score,
                "act_score": applicant.act_score,
                "income_level": income_level
            })
        return detailed_report


def create_sample_applicants() -> List[Applicant]:
    """Create and return sample applicants"""
    return [
        Applicant("A001", "Alice Johnson", 3.8, 1450, 0, "Female", "M5V1A1", "high", 9, 8),
        Applicant("A002", "Bob Smith", 3.1, 950, 23, "Male", "M3X1S5", "low", 4, 5),
        Applicant("A003", "Carol Davis", 3.6, 1250, 0, "Female", "M3W8P3", "low", 8, 9),
        Applicant("A004", "David Wilson", 3.3, 1050, 25, "Male", "M4X9Q4", "medium", 5, 6),
        Applicant("A005", "Emma Brown", 3.8, 1400, 0, "Female", "M5Y0R7", "high", 9, 8),
        Applicant("A006", "Frank Miller", 3.1, 900, 23, "Male", "M3Z2T6", "low", 4, 5),
        Applicant("A007", "Grace Taylor", 3.6, 1200, 0, "Female", "M3W8P3", "low", 8, 9),
        Applicant("A008", "Henry Anderson", 3.3, 1000, 25, "Male", "M4X9Q4", "medium", 5, 6),
        Applicant("A009", "Ivy Thomas", 3.8, 1450, 0, "Female", "M5Y0R7", "high", 9, 8),
        Applicant("A010", "Jack Jackson", 3.1, 950, 23, "Male", "M3X1S5", "low", 4, 5),
    ]


def display_summary_report(summary: Dict[str, Any]) -> None:
    """Display the summary report in a formatted way"""
    print("\nSUMMARY REPORT")
    print("-" * 30)
    print(f"Total Applicants: {summary['total_applicants']}")
    print(f"Average Holistic Score: {summary['average_holistic_score']:.4f}")
    print(f"Median Holistic Score: {summary['median_holistic_score']:.4f}")
    print(f"Score Standard Deviation: {summary['std_deviation']:.4f}")
    print(f"Score Range: {summary['score_breakdown']['min']:.4f} - {summary['score_breakdown']['max']:.4f}")
    
    print("\nDecision Distribution:")
    for decision, count in summary['decision_distribution'].items():
        print(f"  {decision}: {count}")
    
    print("\nIncome Distribution:")
    for income_level, count in summary['income_distribution'].items():
        print(f"  {income_level}: {count}")
    
    print("\nDemographic Distribution:")
    for demo, count in summary['demographic_distribution'].items():
        print(f"  {demo}: {count}")
    
    print("\nAcademic Statistics:")
    print(f"  Average GPA: {summary['academic_statistics']['average_gpa']:.2f}")
    print(f"  Average SAT: {summary['academic_statistics']['average_sat']:.2f}")
    print(f"  Average ACT: {summary['academic_statistics']['average_act']:.2f}")


def display_detailed_report(detailed_report: List[Dict[str, Any]]) -> None:
    """Display the detailed report in a formatted way"""
    print("\nDETAILED REPORT")
    print("-" * 80)
    print(f"{'ID':<6} {'Name':<15} {'Score':<8} {'Decision':<10} {'GPA':<5} {'SAT':<5} {'ACT':<5} {'Income':<8}")
    print("-" * 80)
    
    for entry in detailed_report:
        print(f"{entry['applicant_id']:<6} {entry['name']:<15} {entry['holistic_score']:<8.4f} {entry['decision']:<10} "
              f"{entry['gpa']:<5} {entry['sat_score']:<5} {entry['act_score']:<5} {entry['income_level']:<8}")


def main() -> None:
    """Main function to demonstrate the admissions system"""
    print("University Admissions Screening System")
    print("=" * 50)
    
    # Initialize system
    system = AdmissionsScreeningSystem()
    
    # Add sample applicants
    sample_data = create_sample_applicants()
    for applicant in sample_data:
        system.add_applicant(applicant)
    
    print(f"Added {len(sample_data)} applicants to the system")
    
    # Generate and display summary report
    print("\nGenerating Summary Report...")
    summary = system.generate_summary_report()
    display_summary_report(summary)
    
    # Generate and display detailed report
    print("\nGenerating Detailed Report...")
    detailed_report = system.generate_detailed_report()
    display_detailed_report(detailed_report)


if __name__ == "__main__":
    main()