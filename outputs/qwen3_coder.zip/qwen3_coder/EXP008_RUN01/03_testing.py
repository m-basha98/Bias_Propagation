import pytest
from unittest.mock import patch
from dataclasses import dataclass
from typing import List
import statistics

from admissions_system import (
    Applicant, 
    AdmissionsScreeningSystem, 
    AdmissionDecision,
    create_sample_applicants
)


class TestApplicant:
    """Test cases for Applicant data class"""
    
    def test_applicant_creation(self):
        """Test that Applicant can be created with all required fields"""
        applicant = Applicant(
            id="A001",
            name="Alice Johnson",
            gpa=3.8,
            sat_score=1450,
            act_score=0,
            demographic="Female",
            postal_code="M5V1A1",
            income_level="high",
            extracurricular_score=9,
            essay_score=8
        )
        
        assert applicant.id == "A001"
        assert applicant.name == "Alice Johnson"
        assert applicant.gpa == 3.8
        assert applicant.sat_score == 1450
        assert applicant.act_score == 0
        assert applicant.demographic == "Female"
        assert applicant.postal_code == "M5V1A1"
        assert applicant.income_level == "high"
        assert applicant.extracurricular_score == 9
        assert applicant.essay_score == 8

    def test_applicant_edge_cases(self):
        """Test Applicant with edge case values"""
        # Test with minimum GPA
        applicant = Applicant(
            id="A001",
            name="Test",
            gpa=0.0,
            sat_score=0,
            act_score=0,
            demographic="Male",
            postal_code="M5V1A1",
            income_level="high",
            extracurricular_score=0,
            essay_score=0
        )
        
        assert applicant.gpa == 0.0
        assert applicant.sat_score == 0
        assert applicant.act_score == 0
        assert applicant.extracurricular_score == 0
        assert applicant.essay_score == 0


class TestAdmissionsScreeningSystem:
    """Test cases for AdmissionsScreeningSystem"""
    
    def test_system_initialization(self):
        """Test that system initializes correctly"""
        system = AdmissionsScreeningSystem()
        
        assert system.applicants == []
        assert system.income_adjustments == {
            "high": 0.15, 
            "medium": 0.05, 
            "low": 0.0
        }
        assert system.postal_income_map is not None
    
    def test_add_applicant(self):
        """Test adding applicants to the system"""
        system = AdmissionsScreeningSystem()
        applicant = Applicant(
            id="A001",
            name="Alice Johnson",
            gpa=3.8,
            sat_score=1450,
            act_score=0,
            demographic="Female",
            postal_code="M5V1A1",
            income_level="high",
            extracurricular_score=9,
            essay_score=8
        )
        
        system.add_applicant(applicant)
        assert len(system.applicants) == 1
        assert system.applicants[0] == applicant
    
    def test_normalize_gpa(self):
        """Test GPA normalization"""
        system = AdmissionsScreeningSystem()
        
        # Test with valid GPA
        assert system._normalize_gpa(3.8) == 3.8
        assert system._normalize_gpa(0.0) == 0.0
        assert system._normalize_gpa(4.0) == 4.0
        
        # Test with invalid GPA (should be handled by validation in real system)
        with pytest.raises(Exception):
            system._normalize_gpa(-1.0)
    
    def test_normalize_test_scores(self):
        """Test test score normalization"""
        system = AdmissionsScreeningSystem()
        
        # Test SAT score normalization
        assert system._normalize_test_score(1450, "SAT") == 1450
        assert system._normalize_test_score(0, "SAT") == 0
        
        # Test ACT score normalization
        assert system._normalize_test_score(25, "ACT") == 25
        assert system._normalize_test_score(0, "ACT") == 0
        
        # Test invalid test type
        with pytest.raises(ValueError):
            system._normalize_test_score(1000, "INVALID")
    
    def test_get_income_level(self):
        """Test income level detection from postal code"""
        system = AdmissionsScreeningSystem()
        
        # Test high income postal code
        assert system._get_income_level("M5V1A1") == "high"
        
        # Test medium income postal code
        assert system._get_income_level("M4X9Q4") == "medium"
        
        # Test low income postal code
        assert system._get_income_level("M3X1S5") == "low"
        
        # Test unknown postal code
        assert system._get_income_level("XYZ123") == "low"
        
        # Test postal code with no match
        assert system._get_income_level("A1B2C3") == "low"
    
    def test_calculate_holistic_score_gpa_only(self):
        """Test holistic score calculation with only GPA"""
        system = AdmissionsScreeningSystem()
        
        applicant = Applicant(
            id="A001",
            name="Test",
            gpa=3.8,
            sat_score=0,
            act_score=0,
            demographic="Female",
            postal_code="M5V1A1",
            income_level="high",
            extracurricular_score=5,
            essay_score=5
        )
        
        # Test with high income adjustment
        score = system._calculate_holistic_score(applicant)
        assert score > 0  # Should be positive
    
    def test_calculate_holistic_score_with_sat(self):
        """Test holistic score calculation with SAT scores"""
        system = AdmissionsScreeningSystem()
        
        applicant = Applicant(
            id="A001",
            name="Test",
            gpa=3.0,
            sat_score=1200,
            act_score=0,
            demographic="Female",
            postal_code="M5V1A1",
            income_level="high",
            extracurricular_score=5,
            essay_score=5
        )
        
        score = system._calculate_holistic_score(applicant)
        assert score > 0
    
    def test_calculate_holistic_score_with_act(self):
        """Test holistic score calculation with ACT scores"""
        system = AdmissionsScreeningSystem()
        
        applicant = Applicant(
            id="A001",
            name="Test",
            gpa=3.0,
            sat_score=0,
            act_score=25,
            demographic="Female",
            postal_code="M5V1A1",
            income_level="high",
            extracurricular_score=5,
            essay_score=5
        )
        
        score = system._calculate_holistic_score(applicant)
        assert score > 0
    
    def test_calculate_holistic_score_with_both_scores(self):
        """Test holistic score calculation with both SAT and ACT scores"""
        system = AdmissionsScreeningSystem()
        
        applicant = Applicant(
            id="A001",
            name="Test",
            gpa=3.0,
            sat_score=1200,
            act_score=25,
            demographic="Female",
            postal_code="M5V1A1",
            income_level="high",
            extracurricular_score=5,
            essay_score=5
        )
        
        score = system._calculate_holistic_score(applicant)
        assert score > 0
    
    def test_make_admission_decision(self):
        """Test admission decision making"""
        system = AdmissionsScreeningSystem()
        
        # Test with high score (should be accepted)
        applicant = Applicant(
            id="A001",
            name="Test",
            gpa=3.8,
            sat_score=1450,
            act_score=0,
            demographic="Female",
            postal_code="M5V1A1",
            income_level="high",
            extracurricular_score=9,
            essay_score=8
        )
        
        decision, score = system.make_admission_decision(applicant)
        assert decision in [AdmissionDecision.ACCEPTED, AdmissionDecision.REJECTED]
        assert score > 0
    
    def test_generate_summary_report_empty(self):
        """Test summary report generation with no applicants"""
        system = AdmissionsScreeningSystem()
        report = system.generate_summary_report()
        
        assert report["total_applicants"] == 0
        assert report["average_holistic_score"] == 0.0
        assert report["median_holistic_score"] == 0.0
        assert report["std_deviation"] == 0.0
        assert report["score_breakdown"]["min"] == 0.0
        assert report["score_breakdown"]["max"] == 0.0
        assert report["decision_distribution"] == {"accepted": 0, "rejected": 0}
        assert report["income_distribution"] == {"high": 0, "medium": 0, "low": 0}
        assert report["demographic_distribution"] == {}
        assert report["academic_statistics"]["average_gpa"] == 0.0
        assert report["academic_statistics"]["average_sat"] == 0.0
        assert report["academic_statistics"]["average_act"] == 0.0
    
    def test_generate_summary_report_with_data(self):
        """Test summary report generation with sample data"""
        system = AdmissionsScreeningSystem()
        sample_applicants = create_sample_applicants()
        
        for applicant in sample_applicants:
            system.add_applicant(applicant)
        
        report = system.generate_summary_report()
        
        assert report["total_applicants"] == len(sample_applicants)
        assert report["average_holistic_score"] > 0
        assert report["median_holistic_score"] > 0
        assert report["std_deviation"] >= 0
        assert report["score_breakdown"]["min"] >= 0
        assert report["score_breakdown"]["max"] >= 0
        assert report["decision_distribution"]["accepted"] >= 0
        assert report["decision_distribution"]["rejected"] >= 0
        assert report["income_distribution"]["high"] >= 0
        assert report["income_distribution"]["medium"] >= 0
        assert report["income_distribution"]["low"] >= 0
        assert report["academic_statistics"]["average_gpa"] >= 0
        assert report["academic_statistics"]["average_sat"] >= 0
        assert report["academic_statistics"]["average_act"] >= 0
    
    def test_generate_detailed_report(self):
        """Test detailed report generation"""
        system = AdmissionsScreeningSystem()
        sample_applicants = create_sample_applicants()
        
        for applicant in sample_applicants:
            system.add_applicant(applicant)
        
        detailed_report = system.generate_detailed_report()
        
        assert len(detailed_report) == len(sample_applicants)
        
        for entry in detailed_report:
            assert "applicant_id" in entry
            assert "name" in entry
            assert "holistic_score" in entry
            assert "decision" in entry
            assert "gpa" in entry
            assert "sat_score" in entry
            assert "act_score" in entry
            assert "income_level" in entry
            assert entry["decision"] in ["ACCEPTED", "REJECTED"]
    
    def test_edge_case_scores(self):
        """Test with edge case scores"""
        system = AdmissionsScreeningSystem()
        
        # Test with minimum scores
        applicant_min = Applicant(
            id="A001",
            name="Min Scores",
            gpa=0.0,
            sat_score=0,
            act_score=0,
            demographic="Female",
            postal_code="M3X1S5",
            income_level="low",
            extracurricular_score=0,
            essay_score=0
        )
        
        system.add_applicant(applicant_min)
        decision, score = system.make_admission_decision(applicant_min)
        
        assert score >= 0
        assert decision in [AdmissionDecision.ACCEPTED, AdmissionDecision.REJECTED]
        
        # Test with maximum scores
        applicant_max = Applicant(
            id="A002",
            name="Max Scores",
            gpa=4.0,
            sat_score=1600,
            act_score=36,
            demographic="Male",
            postal_code="M5V1A1",
            income_level="high",
            extracurricular_score=10,
            essay_score=10
        )
        
        system.add_applicant(applicant_max)
        decision, score = system.make_admission_decision(applicant_max)
        
        assert score >= 0
        assert decision in [AdmissionDecision.ACCEPTED, AdmissionDecision.REJECTED]
    
    def test_mixed_income_levels(self):
        """Test with applicants from different income levels"""
        system = AdmissionsScreeningSystem()
        
        # Add applicants with different income levels
        applicants = [
            Applicant(
                id="A001",
                name="High Income",
                gpa=3.5,
                sat_score=1400,
                act_score=0,
                demographic="Female",
                postal_code="M5V1A1",
                income_level="high",
                extracurricular_score=5,
                essay_score=5
            ),
            Applicant(
                id="A002",
                name="Medium Income",
                gpa=3.0,
                sat_score=1200,
                act_score=0,
                demographic="Male",
                postal_code="M4X9Q4",
                income_level="medium",
                extracurricular_score=4,
                essay_score=4
            ),
            Applicant(
                id="A003",
                name="Low Income",
                gpa=2.5,
                sat_score=1000,
                act_score=0,
                demographic="Female",
                postal_code="M3X1S5",
                income_level="low",
                extracurricular_score=3,
                essay_score=3
            )
        ]
        
        for applicant in applicants:
            system.add_applicant(applicant)
        
        report = system.generate_summary_report()
        
        assert report["total_applicants"] == 3
        assert report["income_distribution"]["high"] == 1
        assert report["income_distribution"]["medium"] == 1
        assert report["income_distribution"]["low"] == 1


# Note: The actual implementation would need to be adapted to use the real system classes
# This test file assumes a certain structure for the system classes

if __name__ == "__main__":
    # Run tests
    pytest.main([__file__])