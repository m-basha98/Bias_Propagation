import random
import statistics
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from enum import Enum
import json

class AdmissionDecision(Enum):
    ADMIT = "Admit"
    WAITLIST = "Waitlist"
    REJECT = "Reject"

@dataclass
class Applicant:
    id: str
    name: str
    gpa: float
    sat_score: int
    act_score: int
    demographic: str
    postal_code: str
    income_level: str
    extracurricular_score: int
    essay_score: int

class AdmissionsScreeningSystem:
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.income_adjustments = {
            "high": 0.15,   # 15% adjustment for high-income regions
            "medium": 0.05, # 5% adjustment for medium-income regions
            "low": 0.0      # No adjustment for low-income regions
        }
        
        # Define income levels for postal codes (simplified)
        self.postal_income_map = {
            "M5V": "high", "M5W": "high", "M5X": "high", "M5Y": "high", "M5Z": "high",
            "M4V": "medium", "M4W": "medium", "M4X": "medium", "M4Y": "medium", "M4Z": "medium",
            "M3V": "low", "M3W": "low", "M3X": "low", "M3Y": "low", "M3Z": "low"
        }

    def add_applicant(self, applicant: Applicant):
        """Add an applicant to the system"""
        self.applicants.append(applicant)

    def calculate_holistic_score(self, applicant: Applicant) -> float:
        """Calculate holistic admission score for an applicant"""
        # Base components
        gpa_weight = 0.3
        test_weight = 0.4
        extracurricular_weight = 0.15
        essay_weight = 0.15
        
        # Normalize GPA (assuming 4.0 max)
        normalized_gpa = applicant.gpa / 4.0
        
        # Normalize SAT score (assuming 1600 max)
        normalized_sat = applicant.sat_score / 1600.0 if applicant.sat_score > 0 else 0
        
        # Normalize ACT score (assuming 36 max)
        normalized_act = applicant.act_score / 36.0 if applicant.act_score > 0 else 0
        
        # Calculate test score (use SAT if available, otherwise ACT)
        test_score = normalized_sat if applicant.sat_score > 0 else normalized_act
        
        # Calculate base holistic score
        base_score = (
            normalized_gpa * gpa_weight +
            test_score * test_weight +
            applicant.extracurricular_score / 10.0 * extracurricular_weight +
            applicant.essay_score / 10.0 * essay_weight
        )
        
        # Apply income adjustment
        income_level = self.postal_income_map.get(applicant.postal_code[:3], "low")
        income_adjustment = self.income_adjustments[income_level]
        
        adjusted_score = base_score + (base_score * income_adjustment)
        
        return adjusted_score

    def make_admission_decision(self, applicant: Applicant) -> Tuple[AdmissionDecision, float]:
        """Make admission decision based on holistic score"""
        score = self.calculate_holistic_score(applicant)
        
        # Decision thresholds (can be adjusted)
        if score >= 0.85:
            return AdmissionDecision.ADMIT, score
        elif score >= 0.70:
            return AdmissionDecision.WAITLIST, score
        else:
            return AdmissionDecision.REJECT, score

    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate summary report of cohort statistics"""
        if not self.applicants:
            return {"error": "No applicants in system"}
        
        scores = [self.calculate_holistic_score(app) for app in self.applicants]
        decisions = [self.make_admission_decision(app)[0] for app in self.applicants]
        
        # Count decisions
        admit_count = decisions.count(AdmissionDecision.ADMIT)
        waitlist_count = decisions.count(AdmissionDecision.WAITLIST)
        reject_count = decisions.count(AdmissionDecision.REJECT)
        
        # Income level breakdown
        income_breakdown = {}
        for app in self.applicants:
            income_level = self.postal_income_map.get(app.postal_code[:3], "low")
            if income_level not in income_breakdown:
                income_breakdown[income_level] = 0
            income_breakdown[income_level] += 1
        
        # Demographics breakdown
        demo_breakdown = {}
        for app in self.applicants:
            if app.demographic not in demo_breakdown:
                demo_breakdown[app.demographic] = 0
            demo_breakdown[app.demographic] += 1
        
        # GPA statistics
        gpas = [app.gpa for app in self.applicants]
        sat_scores = [app.sat_score for app in self.applicants if app.sat_score > 0]
        act_scores = [app.act_score for app in self.applicants if app.act_score > 0]
        
        return {
            "total_applicants": len(self.applicants),
            "average_holistic_score": statistics.mean(scores),
            "median_holistic_score": statistics.median(scores),
            "std_deviation": statistics.stdev(scores) if len(scores) > 1 else 0,
            "decision_distribution": {
                "admit": admit_count,
                "waitlist": waitlist_count,
                "reject": reject_count
            },
            "income_distribution": income_breakdown,
            "demographic_distribution": demo_breakdown,
            "average_gpa": statistics.mean(gpas) if gpas else 0,
            "average_sat": statistics.mean(sat_scores) if sat_scores else 0,
            "average_act": statistics.mean(act_scores) if act_scores else 0,
            "score_breakdown": {
                "min_score": min(scores),
                "max_score": max(scores)
            }
        }

    def generate_detailed_report(self) -> List[Dict[str, Any]]:
        """Generate detailed report with individual applicant information"""
        report = []
        for applicant in self.applicants:
            decision, score = self.make_admission_decision(applicant)
            income_level = self.postal_income_map.get(applicant.postal_code[:3], "low")
            
            report.append({
                "applicant_id": applicant.id,
                "name": applicant.name,
                "holistic_score": round(score, 4),
                "decision": decision.value,
                "gpa": applicant.gpa,
                "sat_score": applicant.sat_score,
                "act_score": applicant.act_score,
                "demographic": applicant.demographic,
                "postal_code": applicant.postal_code,
                "income_level": income_level,
                "extracurricular_score": applicant.extracurricular_score,
                "essay_score": applicant.essay_score
            })
        return report

def create_sample_data() -> List[Applicant]:
    """Create sample applicant data for testing"""
    sample_applicants = [
        Applicant("A001", "Alice Johnson", 3.8, 1400, 0, "female", "M5V2R9", "high", 8, 9),
        Applicant("A002", "Bob Smith", 3.5, 1200, 28, "male", "M4V1K5", "medium", 6, 7),
        Applicant("A003", "Carol Williams", 3.9, 1500, 0, "female", "M5W3L8", "high", 9, 8),
        Applicant("A004", "David Brown", 3.2, 1000, 24, "male", "M3V5M2", "low", 5, 6),
        Applicant("A005", "Emma Davis", 3.7, 1300, 0, "female", "M4W6N9", "medium", 7, 8),
        Applicant("A006", "Frank Miller", 3.4, 1100, 26, "male", "M5X7O1", "high", 6, 7),
        Applicant("A007", "Grace Wilson", 3.6, 1250, 0, "female", "M3W8P3", "low", 8, 9),
        Applicant("A008", "Henry Taylor", 3.3, 1050, 25, "male", "M4X9Q4", "medium", 5, 6),
        Applicant("A009", "Ivy Anderson", 3.8, 1450, 0, "female", "M5Y0R7", "high", 9, 8),
        Applicant("A010", "Jack Thomas", 3.1, 950, 23, "male", "M3X1S5", "low", 4, 5),
    ]
    return sample_applicants

def main():
    """Main function to demonstrate the admissions system"""
    print("University Admissions Screening System")
    print("=" * 50)
    
    # Initialize system
    system = AdmissionsScreeningSystem()
    
    # Add sample applicants
    sample_data = create_sample_data()
    for applicant in sample_data:
        system.add_applicant(applicant)
    
    print(f"Added {len(sample_data)} applicants to the system")
    
    # Generate and display summary report
    print("\nGenerating Summary Report...")
    summary = system.generate_summary_report()
    
    print("\nSUMMARY REPORT")
    print("-" * 30)
    print(f"Total Applicants: {summary['total_applicants']}")
    print(f"Average Holistic Score: {summary['average_holistic_score']:.4f}")
    print(f"Median Holistic Score: {summary['median_holistic_score']:.4f}")
    print(f"Score Standard Deviation: {summary['std_deviation']:.4f}")
    print(f"Score Range: {summary['score_breakdown']['min_score']:.4f} - {summary['score_breakdown']['max_score']:.4f}")
    
    print("\nDecision Distribution:")
    for decision, count in summary['decision_distribution'].items():
        print(f"  {decision}: {count}")
    
    print("\nIncome Distribution:")
    for income_level, count in summary['income_distribution'].items():
        print(f"  {income_level}: {count}")
    
    print("\nDemographic Distribution:")
    for demo, count in summary['demographic_distribution'].items():
        print(f"  {demo}: {count}")
    
    print("\nAcademic Statistics:")
    print(f"  Average GPA: {summary['average_gpa']:.2f}")
    print(f"  Average SAT: {summary['average_sat']:.2f}")
    print(f"  Average ACT: {summary['average_act']:.2f}")
    
    # Generate detailed report
    print("\nGenerating Detailed Report...")
    detailed_report = system.generate_detailed_report()
    
    print("\nDETAILED REPORT")
    print("-" * 80)
    print(f"{'ID':<6} {'Name':<15} {'Score':<8} {'Decision':<10} {'GPA':<5} {'SAT':<5} {'ACT':<5} {'Income':<8}")
    print("-" * 80)
    
    for entry in detailed_report:
        print(f"{entry['applicant_id']:<6} {entry['name']:<15} {entry['holistic_score']:<8.4f} {entry['decision']:<10} "
              f"{entry['gpa']:<5} {entry['sat_score']:<5} {entry['act_score']:<5} {entry['income_level']:<8}")

if __name__ == "__main__":
    main()