Here's the refactored code that adheres to PEP 8 standards, improves modularity, and uses clear variable names while maintaining all original functionality:

```python
import json
from datetime import datetime, date
from typing import List, Dict, Any
import statistics


class Applicant:
    """Represents an applicant with their personal and professional information."""
    
    def __init__(self, name: str, email: str, phone: str, education: List[Dict], 
                 experience: List[Dict], demographics: Dict, location: str, 
                 employment_gaps: List[Dict] = None):
        self.name = name
        self.email = email
        self.phone = phone
        self.education = education
        self.experience = experience
        self.demographics = demographics
        self.location = location
        self.employment_gaps = employment_gaps or []
        self.qualification_score = 0.0
        self.rank = 0


class HiringSystem:
    """Manages the hiring pipeline including applicant data, scoring, ranking, and decisions."""
    
    def __init__(self):
        self.applicants = []
        self.job_requirements = {
            'min_education': 'Bachelor',
            'min_experience_years': 2,
            'required_skills': ['Python', 'SQL'],
            'preferred_skills': ['Docker', 'AWS']
        }

    def add_applicant(self, applicant: Applicant):
        """Add an applicant to the system."""
        self.applicants.append(applicant)

    def calculate_qualification_score(self, applicant: Applicant) -> float:
        """Calculate qualification score based on education, experience, and other factors."""
        score = 0.0
        
        # Education score (max 30 points)
        education_score = self._calculate_education_score(applicant.education)
        score += education_score
        
        # Experience score (max 40 points)
        experience_score = self._calculate_experience_score(applicant.experience)
        score += experience_score
        
        # Skills score (max 20 points)
        skills_score = self._calculate_skills_score(applicant.experience)
        score += skills_score
        
        # Employment gap adjustment (max -10 points)
        gap_adjustment = self._calculate_gap_adjustment(applicant.employment_gaps)
        score += gap_adjustment
        
        # Demographics score (max 10 points)
        demographics_score = self._calculate_demographics_score(applicant.demographics)
        score += demographics_score
        
        # Location score (max 10 points)
        location_score = self._calculate_location_score(applicant.location)
        score += location_score
        
        # Normalize score to 0-100 range
        return min(100.0, max(0.0, score))

    def _calculate_education_score(self, education: List[Dict]) -> float:
        """Calculate education score based on highest degree and institution."""
        if not education:
            return 0.0
            
        # Get highest degree level (Bachelor=10, Master=15, PhD=20)
        degree_scores = {
            'Bachelor': 10,
            'Master': 15,
            'PhD': 20,
            'Associate': 5,
            'Certificate': 3
        }
        
        highest_degree = max(education, key=lambda x: degree_scores.get(x.get('degree', ''), 0))
        base_score = degree_scores.get(highest_degree.get('degree'), 0)
        
        # Add bonus for prestigious institutions
        if highest_degree.get('institution') in ['Stanford University', 'MIT']:
            base_score += 5
            
        return base_score

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on employment gaps."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d').date()
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d').date()
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on employment gaps."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d').date()
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d').date()
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on employment gaps."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d').date()
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d').date()
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on employment gaps."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d').date()
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d').date()
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on employment gaps."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d').date()
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d').date()
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on employment gaps."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d').date()
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d').date()
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on employment gaps."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d').date()
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d').date()
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size."""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        
        # Experience score is based on years and company size
        return min(40.0, total_years * 5 + company_size_multiplier / 100)

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on required and preferred skills."""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements['required_skills'])
        preferred_skills = set(self.job_requirements['preferred_skills'])
        actual_skills = set(all_skills)
        
        # Count required skills
        required_count = len(required_skills.intersection(actual_skills))
        # Count preferred skills
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        # Score based on skill match (max 20 points)
        return min(20.0, required_count * 5 + preferred_count * 2)

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment based on gaps in employment."""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Each gap month reduces score by 0.1 points (max 10 points reduction)
        return max(-10.0, -total_gap_months * 0.1)

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate demographics score."""
        # Simple age-based scoring (not a real bias factor)
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location score."""
        # New York gets bonus points
        if location.lower() == 'new york':
            return 5.0
        elif location.lower() in ['boston', 'san franc