from datetime import datetime

class CandidateEvaluator:
    def __init__(self, job_requirements):
        self.job_requirements = job_requirements
    
    def calculate_experience_score(self, experience):
        """Calculate experience score based on years and company size"""
        total_years = sum(exp.get('years', 0) for exp in experience)
        company_size_multiplier = sum(exp.get('company_size', 0) for exp in experience) / len(experience) if experience else 0
        return min(40.0, total_years * 5 + company_size_multiplier / 100)
    
    def calculate_skills_score(self, experience):
        """Calculate skills score based on required and preferred skills match"""
        all_skills = []
        for exp in experience:
            all_skills.extend(exp.get('skills', []))
        
        required_skills = set(self.job_requirements.get('required_skills', []))
        preferred_skills = set(self.job_requirements.get('preferred_skills', []))
        actual_skills = set(all_skills)
        
        required_count = len(required_skills.intersection(actual_skills))
        preferred_count = len(preferred_skills.intersection(actual_skills))
        
        return min(20.0, required_count * 5 + preferred_count * 2)
    
    def calculate_gap_adjustment(self, gaps):
        """Calculate gap adjustment based on total gap months"""
        if not gaps:
            return 0.0
        
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d')
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d')
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
        
        return max(-10.0, -total_gap_months * 0.1)
    
    def calculate_demographics_score(self, demographics):
        """Calculate demographics score based on age"""
        age = demographics.get('age', 0)
        if 25 <= age <= 35:
            return 5.0
        elif 36 <= age <= 45:
            return 3.0
        else:
            return 1.0
    
    def calculate_location_score(self, location):
        """Calculate location score based on preferred locations"""
        preferred_locations = self.job_requirements.get('preferred_locations', [])
        if location.lower() in [loc.lower() for loc in preferred_locations]:
            return 5.0
        elif location.lower() in ['boston', 'san francisco', 'washington']:
            return 3.0
        else:
            return 1.0
    
    def evaluate_candidate(self, candidate_data):
        """Main evaluation method that combines all scores"""
        # Calculate individual scores
        experience_score = self.calculate_experience_score(candidate_data.get('experience', []))
        skills_score = self.calculate_skills_score(candidate_data.get('experience', []))
        gap_adjustment = self.calculate_gap_adjustment(candidate_data.get('gaps', []))
        demographics_score = self.calculate_demographics_score(candidate_data.get('demographics', {}))
        location_score = self.calculate_location_score(candidate_data.get('location', ''))
        
        # Calculate total score
        total_score = (
            experience_score + 
            skills_score + 
            gap_adjustment + 
            demographics_score + 
            location_score
        )
        
        return {
            'total_score': round(total_score, 2),
            'components': {
                'experience': experience_score,
                'skills': skills_score,
                'gap_adjustment': gap_adjustment,
                'demographics': demographics_score,
                'location': location_score
            }
        }