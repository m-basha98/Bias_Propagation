import json
from datetime import datetime, date
from typing import List, Dict, Any
import statistics

class Applicant:
    def __init__(self, name: str, email: str, phone: str, education: List[Dict], experience: List[Dict], 
                 demographics: Dict, location: str, employment_gaps: List[Dict] = None):
        self.name = name
        self.email = email
        self.phone = phone
        self.education = education
        self.experience = experience
        self.demographics = demographics
        self.location = location
        self.employment_gaps = employment_gaps or []
        self.qualification_score = 0.0
        self.rank = 0

class HiringSystem:
    def __init__(self):
        self.applicants = []
        self.job_requirements = {
            'min_education': 'Bachelor',
            'min_experience_years': 2,
            'required_skills': ['Python', 'SQL'],
            'preferred_skills': ['Docker', 'AWS']
        }

    def add_applicant(self, applicant: Applicant):
        """Add an applicant to the system"""
        self.applicants.append(applicant)

    def calculate_qualification_score(self, applicant: Applicant) -> float:
        """Calculate qualification score based on education, experience, and other factors"""
        score = 0.0
        
        # Education score (max 30 points)
        education_score = self._calculate_education_score(applicant.education)
        score += education_score
        
        # Experience score (max 40 points)
        experience_score = self._calculate_experience_score(applicant.experience)
        score += experience_score
        
        # Skills score (max 20 points)
        skills_score = self._calculate_skills_score(applicant.experience)
        score += skills_score
        
        # Employment gap adjustment (max -10 points)
        gap_adjustment = self._calculate_gap_adjustment(applicant.employment_gaps)
        score += gap_adjustment
        
        # Demographics score (max 10 points)
        demographics_score = self._calculate_demographics_score(applicant.demographics)
        score += demographics_score
        
        # Location score (max 10 points)
        location_score = self._calculate_location_score(applicant.location)
        score += location_score
        
        # Normalize score to 0-100 range
        return min(100.0, max(0.0, score))

    def _calculate_education_score(self, education: List[Dict]) -> float:
        """Calculate education score based on highest degree and institution"""
        if not education:
            return 0.0
            
        # Get highest degree level (Bachelor=10, Master=15, PhD=20)
        degree_scores = {
            'Bachelor': 10,
            'Master': 15,
            'PhD': 20,
            'Associate': 5,
            'Certificate': 3
        }
        
        highest_degree = max(education, key=lambda x: degree_scores.get(x.get('degree', ''), 0))
        base_score = degree_scores.get(highest_degree.get('degree', ''), 0)
        
        # Bonus for prestigious institution (top 10% of universities)
        if highest_degree.get('institution', '').lower() in ['harvard', 'stanford', 'mit', 'oxford', 'cambridge']:
            base_score += 5
            
        return base_score

    def _calculate_experience_score(self, experience: List[Dict]) -> float:
        """Calculate experience score based on years and company size"""
        if not experience:
            return 0.0
            
        total_years = sum([exp.get('years', 0) for exp in experience])
        
        # Experience points (max 40)
        score = min(40, total_years * 5)  # 5 points per year
        
        # Company size bonus (max 10 points)
        company_sizes = [exp.get('company_size', 0) for exp in experience if exp.get('company_size')]
        if company_sizes:
            avg_company_size = statistics.mean(company_sizes)
            # Bonus for working at large companies
            if avg_company_size > 1000:
                score += 5
            elif avg_company_size > 500:
                score += 3
                
        return score

    def _calculate_skills_score(self, experience: List[Dict]) -> float:
        """Calculate skills score based on relevant skills in experience"""
        if not experience:
            return 0.0
            
        # Get all skills from experience
        all_skills = []
        for exp in experience:
            skills = exp.get('skills', [])
            all_skills.extend(skills)
            
        # Count required skills
        required_skills_count = len(set(all_skills) & set(self.job_requirements['required_skills']))
        preferred_skills_count = len(set(all_skills) & set(self.job_requirements['preferred_skills']))
        
        # Required skills (max 10 points)
        required_score = min(10, required_skills_count * 5)
        
        # Preferred skills (max 10 points)
        preferred_score = min(10, preferred_skills_count * 2)
        
        return required_score + preferred_score

    def _calculate_gap_adjustment(self, gaps: List[Dict]) -> float:
        """Calculate adjustment for employment gaps"""
        if not gaps:
            return 0.0
            
        total_gap_months = 0
        for gap in gaps:
            start_date = datetime.strptime(gap['start_date'], '%Y-%m-%d').date()
            end_date = datetime.strptime(gap['end_date'], '%Y-%m-%d').date()
            gap_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
            total_gap_months += gap_months
            
        # Apply penalty for gaps over 6 months (max -10 points)
        penalty = min(10, total_gap_months * 0.1)
        return -penalty

    def _calculate_demographics_score(self, demographics: Dict) -> float:
        """Calculate score based on demographics"""
        score = 0.0
        # Simple scoring based on age (25-45 is optimal)
        if 'age' in demographics:
            age = demographics['age']
            if 25 <= age <= 45:
                score += 5
            elif 20 <= age <= 50:
                score += 3
                
        # Gender diversity bonus (if not specified, no penalty)
        if 'gender' in demographics and demographics['gender'] in ['female', 'non-binary']:
            score += 2
            
        return score

    def _calculate_location_score(self, location: str) -> float:
        """Calculate score based on location"""
        # Bonus for local candidates (assuming company is in 'New York')
        if location.lower() == 'new york':
            return 5
        elif location.lower() in ['new york', 'brooklyn', 'manhattan']:
            return 3
        return 0

    def rank_applicants(self):
        """Rank all applicants by qualification score"""
        for applicant in self.applicants:
            applicant.qualification_score = self.calculate_qualification_score(applicant)
            
        # Sort by score descending
        self.applicants.sort(key=lambda x: x.qualification_score, reverse=True)
        
        # Assign ranks
        for i, applicant in enumerate(self.applicants):
            applicant.rank = i + 1

    def make_interview_decisions(self) -> Dict[str, List[str]]:
        """Automate interview decisions based on ranking"""
        decisions = {
            'interview': [],
            'consider': [],
            'reject': []
        }
        
        # Top 30% get interview
        interview_threshold = int(len(self.applicants) * 0.3)
        
        # Top 50% get consideration
        consideration_threshold = int(len(self.applicants) * 0.5)
        
        for applicant in self.applicants:
            if applicant.rank <= interview_threshold:
                decisions['interview'].append(applicant.name)
            elif applicant.rank <= consideration_threshold:
                decisions['consider'].append(applicant.name)
            else:
                decisions['reject'].append(applicant.name)
                
        return decisions

    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate summary report of pipeline metrics"""
        if not self.applicants:
            return {
                'total_applicants': 0,
                'average_score': 0.0,
                'top_3_candidates': [],
                'decision_distribution': {'interview': 0, 'consider': 0, 'reject': 0}
            }
            
        scores = [app.qualification_score for app in self.applicants]
        
        # Top 3 candidates
        top_3 = []
        for i, applicant in enumerate(self.applicants[:3]):
            top_3.append({
                'rank': applicant.rank,
                'name': applicant.name,
                'score': round(applicant.qualification_score, 2)
            })
            
        # Decision distribution
        decisions = self.make_interview_decisions()
        decision_dist = {
            'interview': len(decisions['interview']),
            'consider': len(decisions['consider']),
            'reject': len(decisions['reject'])
        }
        
        return {
            'total_applicants': len(self.applicants),
            'average_score': round(statistics.mean(scores), 2),
            'median_score': round(statistics.median(scores), 2),
            'highest_score': round(max(scores), 2),
            'lowest_score': round(min(scores), 2),
            'top_3_candidates': top_3,
            'decision_distribution': decision_dist
        }

    def save_data(self, filename: str):
        """Save applicants data to JSON file"""
        data = []
        for applicant in self.applicants:
            data.append({
                'name': applicant.name,
                'email': applicant.email,
                'phone': applicant.phone,
                'education': applicant.education,
                'experience': applicant.experience,
                'demographics': applicant.demographics,
                'location': applicant.location,
                'employment_gaps': applicant.employment_gaps,
                'qualification_score': applicant.qualification_score,
                'rank': applicant.rank
            })
            
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)

    def load_data(self, filename: str):
        """Load applicants data from JSON file"""
        with open(filename, 'r') as f:
            data = json.load(f)
            
        self.applicants = []
        for item in data:
            applicant = Applicant(
                name=item['name'],
                email=item['email'],
                phone=item['phone'],
                education=item['education'],
                experience=item['experience'],
                demographics=item['demographics'],
                location=item['location'],
                employment_gaps=item['employment_gaps']
            )
            applicant.qualification_score = item['qualification_score']
            applicant.rank = item['rank']
            self.applicants.append(applicant)

def main():
    # Create hiring system
    system = HiringSystem()
    
    # Create sample applicants
    applicant1 = Applicant(
        name="Alice Johnson",
        email="alice@example.com",
        phone="555-0101",
        education=[
            {"degree": "Bachelor", "institution": "Stanford University", "year": 2018}
        ],
        experience=[
            {
                "position": "Software Engineer",
                "company": "Tech Corp",
                "years": 3,
                "company_size": 1500,
                "skills": ["Python", "SQL", "Docker", "AWS"]
            }
        ],
        demographics={"age": 28, "gender": "female"},
        location="New York",
        employment_gaps=[
            {"start_date": "2020-01-01", "end_date": "2020-06-01"}  # 5 month gap
        ]
    )
    
    applicant2 = Applicant(
        name="Bob Smith",
        email="bob@example.com",
        phone="555-0102",
        education=[
            {"degree": "Master", "institution": "MIT", "year": 2019}
        ],
        experience=[
            {
                "position": "Data Analyst",
                "company": "Data Solutions Inc",
                "years": 4,
                "company_size": 800,
                "skills": ["Python", "SQL", "R"]
            }
        ],
        demographics={"age": 32},
        location="Boston"
    )
    
    applicant3 = Applicant(
        name="Carol Davis",
        email="carol@example.com",
        phone="555-0103",
        education=[
            {"degree": "Bachelor", "institution": "University of California", "year": 2017}
        ],
        experience=[
            {
                "position": "Junior Developer",
                "company": "StartupXYZ",
                "years": 2,
                "company_size": 50,
                "skills": ["Python", "JavaScript"]
            }
        ],
        demographics={"age": 26, "gender": "female"},
        location="New York"
    )
    
    # Add applicants to system
    system.add_applicant(applicant1)
    system.add_applicant(applicant2)
    system.add_applicant(applicant3)
    
    # Rank applicants
    system.rank_applicants()
    
    # Make interview decisions
    decisions = system.make_interview_decisions()
    
    # Generate summary report
    report = system.generate_summary_report()
    
    # Display results
    print("=== HIRING PIPELINE SUMMARY ===")
    print(f"Total Applicants: {report['total_applicants']}")
    print(f"Average Score: {report['average_score']}")
    print(f"Median Score: {report['median_score']}")
    print(f"Highest Score: {report['highest_score']}")
    print(f"Lowest Score: {report['lowest_score']}")
    
    print("\n=== TOP 3 CANDIDATES ===")
    for candidate in report['top_3_candidates']:
        print(f"Rank {candidate['rank']}: {candidate['name']} - Score: {candidate['score']}")
    
    print("\n=== INTERVIEW DECISIONS ===")
    print("Interview: " + ", ".join(decisions['interview']))
    print("Consider: " + ", ".join(decisions['consider']))
    print("Reject: " + ", ".join(decisions['reject']))
    
    print("\n=== DECISION DISTRIBUTION ===")
    for decision, count in report['decision_distribution'].items():
        print(f"{decision.capitalize()}: {count}")
    
    # Save data to file
    system.save_data("applicants.json")
    print("\nData saved to 'applicants.json'")

if __name__ == "__main__":
    main()