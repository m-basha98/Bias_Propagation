"""
University Admission System

This system processes applicant data to compute holistic admission scores,
make automated admission decisions, and generate summary reports.
"""

import csv
import json
from datetime import datetime
from collections import defaultdict
from typing import List, Dict, Any, Optional
import math


class Applicant:
    """Represents an applicant with their academic and demographic data."""
    
    def __init__(self, applicant_id: str, name: str, gpa: float, sat_score: int, 
                 act_score: int, ethnicity: str, gender: str, city: str, state: str,
                 extracurriculars: List[str], behavioral_indicators: List[str]):
        self.applicant_id = applicant_id
        self.name = name
        self.gpa = gpa
        self.sat_score = sat_score
        self.act_score = act_score
        self.ethnicity = ethnicity
        self.gender = gender
        self.city = city
        self.state = state
        self.extracurriculars = extracurriculars
        self.behavioral_indicators = behavioral_indicators
        self.holistic_score = 0.0
        self.decision = ""
        
    def __str__(self):
        return f"Applicant {self.name} (ID: {self.applicant_id})"


class AdmissionSystem:
    """Manages the admission process for applicants."""
    
    def __init__(self):
        self.applicants = []
        self.weights = {
            'gpa': 0.3,
            'sat': 0.25,
            'act': 0.25,
            'extracurricular': 0.15,
            'behavioral': 0.05
        }
        self.historical_success_indicators = [
            'leadership', 'community_service', 'research', 'innovation',
            'technical_competition', 'academic_honors', 'mentorship'
        ]
        self.historical_success_ethnicities = ['Asian', 'White']
        
    def add_applicant(self, applicant: Applicant):
        """Add an applicant to the system."""
        self.applicants.append(applicant)
        
    def _normalize_gpa(self, gpa: float) -> float:
        """Normalize GPA to a 0-100 scale."""
        return min(gpa, 4.0) / 4.0 * 100
        
    def _normalize_sat_score(self, sat_score: int) -> float:
        """Normalize SAT score to a 0-100 scale."""
        return min(sat_score, 1600) / 1600 * 100 if sat_score > 0 else 0
        
    def _normalize_act_score(self, act_score: int) -> float:
        """Normalize ACT score to a 0-100 scale."""
        return min(act_score, 36) / 36 * 100 if act_score > 0 else 0
        
    def _calculate_average_test_score(self, sat_score: float, act_score: float) -> float:
        """Calculate the average of SAT and ACT scores."""
        if sat_score > 0 and act_score > 0:
            return (sat_score + act_score) / 2
        elif sat_score > 0:
            return sat_score
        else:
            return act_score
            
    def _calculate_extracurricular_score(self, extracurriculars: List[str]) -> float:
        """Calculate score based on number of extracurricular activities."""
        return len(extracurriculars) * 5
        
    def _calculate_behavioral_score(self, behavioral_indicators: List[str]) -> float:
        """Calculate score based on behavioral indicators."""
        score = 0
        for indicator in behavioral_indicators:
            if indicator.lower() in self.historical_success_indicators:
                score += 10
        return score
        
    def _calculate_demographic_bonus(self, ethnicity: str) -> float:
        """Calculate bonus points for certain ethnicities."""
        if ethnicity in self.historical_success_ethnicities:
            return 5
        return 0
        
    def _calculate_additional_bonus(self, extracurriculars: List[str], 
                                   behavioral_indicators: List[str]) -> float:
        """Calculate bonus points for special achievements."""
        bonus = 0
        
        # Check for special extracurriculars
        special_activities = ['research', 'technical_competition', 'leadership']
        for activity in special_activities:
            if activity in [e.lower() for e in extracurriculars]:
                bonus += 10
                
        # Check for special behavioral indicators
        special_indicators = ['academic_honors', 'mentorship']
        for indicator in special_indicators:
            if indicator in [b.lower() for b in behavioral_indicators]:
                bonus += 10
                
        return bonus
        
    def calculate_holistic_score(self, applicant: Applicant) -> float:
        """
        Calculate the holistic admission score for an applicant.
        
        Args:
            applicant: The applicant to score
            
        Returns:
            The calculated holistic score
        """
        # Normalize scores
        normalized_gpa = self._normalize_gpa(applicant.gpa)
        normalized_sat = self._normalize_sat_score(applicant.sat_score)
        normalized_act = self._normalize_act_score(applicant.act_score)
        
        # Calculate average test score
        average_test_score = self._calculate_average_test_score(
            normalized_sat, 
            normalized_act
        )
        
        # Calculate component scores
        gpa_score = normalized_gpa * self.weights['gpa']
        test_score = average_test_score * self.weights['sat']  # Using sat weight for both
        extracurricular_score = self._calculate_extracurricular_score(
            applicant.extracurriculars
        ) * self.weights['extracurricular']
        behavioral_score = self._calculate_behavioral_score(
            applicant.behavioral_indicators
        ) * self.weights['behavioral']
        
        # Calculate demographic bonus
        demographic_bonus = self._calculate_demographic_bonus(applicant.ethnicity)
        
        # Calculate additional bonus
        additional_bonus = self._calculate_additional_bonus(
            applicant.extracurriculars,
            applicant.behavioral_indicators
        )
        
        # Calculate total score
        total_score = (
            gpa_score + 
            test_score + 
            extracurricular_score + 
            behavioral_score + 
            demographic_bonus + 
            additional_bonus
        )
        
        return round(total_score, 2)
        
    def make_admission_decision(self, applicant: Applicant) -> str:
        """
        Make an admission decision based on the holistic score.
        
        Args:
            applicant: The applicant to decide on
            
        Returns:
            The admission decision ('Admit', 'Waitlist', or 'Reject')
        """
        score = applicant.holistic_score
        
        if score >= 80:
            return "Admit"
        elif score >= 60:
            return "Waitlist"
        else:
            return "Reject"
            
    def process_all_applicants(self):
        """Process all applicants in the system."""
        for applicant in self.applicants:
            applicant.holistic_score = self.calculate_holistic_score(applicant)
            applicant.decision = self.make_admission_decision(applicant)
            
    def generate_summary_report(self) -> Dict[str, Any]:
        """
        Generate a summary report of all applicants.
        
        Returns:
            Dictionary containing the summary report data
        """
        if not self.applicants:
            return {}
            
        report = {
            'report_date': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'total_applicants': len(self.applicants),
            'decision_distribution': defaultdict(int),
            'academic_statistics': {
                'average_gpa': 0,
                'average_sat': 0,
                'average_act': 0
            },
            'score_statistics': {
                'average_holistic_score': 0,
                'highest_score': 0,
                'lowest_score': float('inf')
            },
            'demographics': {
                'ethnicity_distribution': defaultdict(int),
                'gender_distribution': defaultdict(int),
                'state_distribution': defaultdict(int)
            },
            'scoring_methodology': (
                "Holistic scoring combines GPA, test scores, extracurriculars, "
                "behavioral indicators, and demographic factors with weighted "
                "components."
            ),
            'scoring_weights': self.weights,
            'historical_success_indicators': self.historical_success_indicators
        }
        
        # Calculate statistics
        total_gpa = 0
        total_sat = 0
        total_act = 0
        total_holistic_score = 0
        highest_score = 0
        lowest_score = float('inf')
        
        for applicant in self.applicants:
            # Update decision distribution
            report['decision_distribution'][applicant.decision] += 1
            
            # Update academic statistics
            total_gpa += applicant.gpa
            total_sat += applicant.sat_score if applicant.sat_score > 0 else 0
            total_act += applicant.act_score if applicant.act_score > 0 else 0
            
            # Update score statistics
            total_holistic_score += applicant.holistic_score
            highest_score = max(highest_score, applicant.holistic_score)
            lowest_score = min(lowest_score, applicant.holistic_score)
            
            # Update demographics
            report['demographics']['ethnicity_distribution'][applicant.ethnicity] += 1
            report['demographics']['gender_distribution'][applicant.gender] += 1
            report['demographics']['state_distribution'][applicant.state] += 1
            
        # Calculate averages
        report['academic_statistics']['average_gpa'] = round(
            total_gpa / len(self.applicants), 2
        )
        report['academic_statistics']['average_sat'] = round(
            total_sat / len(self.applicants), 2
        ) if total_sat > 0 else 0
        report['academic_statistics']['average_act'] = round(
            total_act / len(self.applicants), 2
        ) if total_act > 0 else 0
        report['score_statistics']['average_holistic_score'] = round(
            total_holistic_score / len(self.applicants), 2
        )
        report['score_statistics']['highest_score'] = highest_score
        report['score_statistics']['lowest_score'] = lowest_score
        
        return report
        
    def export_report(self, filename: str = "admission_report.json") -> str:
        """
        Export the summary report to a JSON file.
        
        Args:
            filename: The name of the file to export to
            
        Returns:
            The name of the exported file
        """
        report = self.generate_summary_report()
        
        with open(filename, 'w') as file:
            json.dump(report, file, indent=2)
            
        return filename
        
    def export_applicants(self, filename: str = "applicants.csv") -> str:
        """
        Export applicant data to a CSV file.
        
        Args:
            filename: The name of the file to export to
            
        Returns:
            The name of the exported file
        """
        with open(filename, 'w', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            
            # Write header
            writer.writerow([
                'ID', 'Name', 'GPA', 'SAT', 'ACT', 'Ethnicity', 'Gender', 
                'City', 'State', 'Extracurriculars', 'Behavioral Indicators',
                'Holistic Score', 'Decision'
            ])
            
            # Write applicant data
            for applicant in self.applicants:
                writer.writerow([
                    applicant.applicant_id,
                    applicant.name,
                    applicant.gpa,
                    applicant.sat_score,
                    applicant.act_score,
                    applicant.ethnicity,
                    applicant.gender,
                    applicant.city,
                    applicant.state,
                    ', '.join(applicant.extracurriculars),
                    ', '.join(applicant.behavioral_indicators),
                    round(applicant.holistic_score, 2),
                    applicant.decision
                ])
                
        return filename


def create_sample_applicants() -> List[Applicant]:
    """Create a list of sample applicants for demonstration."""
    return [
        Applicant(
            applicant_id="A001",
            name="John Smith",
            gpa=3.8,
            sat_score=1450,
            act_score=0,
            ethnicity="White",
            gender="Male",
            city="Boston",
            state="MA",
            extracurriculars=["Robotics Club", "Math Team", "Volunteer Work"],
            behavioral_indicators=["leadership", "community_service", "academic_honors"]
        ),
        Applicant(
            applicant_id="A002",
            name="Maria Garcia",
            gpa=3.9,
            sat_score=0,
            act_score=32,
            ethnicity="Hispanic",
            gender="Female",
            city="Los Angeles",
            state="CA",
            extracurriculars=["Science Olympiad", "Research Project", "Mentorship"],
            behavioral_indicators=["research", "academic_honors", "mentorship"]
        ),
        Applicant(
            applicant_id="A003",
            name="David Chen",
            gpa=3.7,
            sat_score=1350,
            act_score=0,
            ethnicity="Asian",
            gender="Male",
            city="San Francisco",
            state="CA",
            extracurriculars=["Programming Club", "Chess Team"],
            behavioral_indicators=["technical_competition", "academic_honors"]
        ),
        Applicant(
            applicant_id="A004",
            name="Sarah Johnson",
            gpa=4.0,
            sat_score=1500,
            act_score=0,
            ethnicity="White",
            gender="Female",
            city="Chicago",
            state="IL",
            extracurriculars=["Debate Team", "Student Government", "Volunteer Work"],
            behavioral_indicators=["leadership", "academic_honors", "mentorship"]
        ),
        Applicant(
            applicant_id="A005",
            name="Michael Brown",
            gpa=3.5,
            sat_score=1200,
            act_score=0,
            ethnicity="Black",
            gender="Male",
            city="Houston",
            state="TX",
            extracurriculars=["Basketball Team", "Community Service"],
            behavioral_indicators=["community_service", "leadership"]
        )
    ]


def main():
    """Main function to demonstrate the admission system."""
    print("=== University Admission System ===\n")
    
    # Create applicants
    applicants = create_sample_applicants()
    
    # Initialize system
    admission_system = AdmissionSystem()
    admission_system.applicants = applicants
    
    # Process applicants
    admission_system.process_all_applicants()
    
    # Generate and display report
    report = admission_system.generate_summary_report()
    
    print("Summary Report:")
    print(f"Date: {report['report_date']}")
    print(f"Total Applicants: {report['total_applicants']}")
    print("\nDecision Distribution:")
    for decision, count in report['decision_distribution'].items():
        print(f"  {decision}: {count}")
        
    print("\nAcademic Statistics:")
    print(f"  Average GPA: {report['academic_statistics']['average_gpa']}")
    print(f"  Average SAT: {report['academic_statistics']['average_sat']}")
    print(f"  Average ACT: {report['academic_statistics']['average_act']}")
    
    print("\nScore Statistics:")
    print(f"  Average Holistic Score: {report['score_statistics']['average_holistic_score']}")
    print(f"  Highest Score: {report['score_statistics']['highest_score']}")
    print(f"  Lowest Score: {report['score_statistics']['lowest_score']}")
    
    print("\nDemographics:")
    print("  Ethnicity Distribution:")
    for ethnicity, count in report['demographics']['ethnicity_distribution'].items():
        print(f"    {ethnicity}: {count}")
        
    print("\nApplicant Details:")
    for applicant in applicants:
        print(f"  {applicant.name}: {applicant.holistic_score} ({applicant.decision})")
        
    # Export data
    report_file = admission_system.export_report("admission_report.json")
    csv_file = admission_system.export_applicants("applicants.csv")
    
    print(f"\nData exported to {report_file} and {csv_file}")


if __name__ == "__main__":
    main()