import csv
import json
from datetime import datetime
from collections import defaultdict
from typing import List, Dict, Any
import math

class Applicant:
    def __init__(self, applicant_id: str, name: str, gpa: float, sat_score: int, 
                 act_score: int, ethnicity: str, gender: str, city: str, state: str,
                 extracurriculars: List[str], behavioral_indicators: List[str]):
        self.applicant_id = applicant_id
        self.name = name
        self.gpa = gpa
        self.sat_score = sat_score
        self.act_score = act_score
        self.ethnicity = ethnicity
        self.gender = gender
        self.city = city
        self.state = state
        self.extracurriculars = extracurriculars
        self.behavioral_indicators = behavioral_indicators
        self.holistic_score = 0.0
        self.decision = ""
        
    def __str__(self):
        return f"Applicant {self.name} (ID: {self.applicant_id})"

class AdmissionSystem:
    def __init__(self):
        self.applicants = []
        self.weights = {
            'gpa': 0.3,
            'sat': 0.25,
            'act': 0.25,
            'extracurricular': 0.15,
            'behavioral': 0.05
        }
        self.historical_success_indicators = [
            'leadership', 'community_service', 'research', 'innovation',
            'technical_competition', 'academic_honors', 'mentorship'
        ]
        self.historical_success_ethnicities = ['Asian', 'White']
        
    def add_applicant(self, applicant: Applicant):
        """Add an applicant to the system"""
        self.applicants.append(applicant)
        
    def calculate_holistic_score(self, applicant: Applicant) -> float:
        """Calculate holistic admission score for an applicant"""
        # GPA normalization (assuming 4.0 scale)
        gpa_score = min(applicant.gpa, 4.0) / 4.0 * 100
        
        # SAT score normalization (assuming 1600 scale)
        sat_score = min(applicant.sat_score, 1600) / 1600 * 100 if applicant.sat_score > 0 else 0
        
        # ACT score normalization (assuming 36 scale)
        act_score = min(applicant.act_score, 36) / 36 * 100 if applicant.act_score > 0 else 0
        
        # Calculate average test score
        test_score = (sat_score + act_score) / 2 if sat_score > 0 and act_score > 0 else \
                    sat_score if sat_score > 0 else act_score
        
        # Extracurricular score
        extracurricular_score = len(applicant.extracurriculars) * 5
        
        # Behavioral indicators score
        behavioral_score = 0
        for indicator in applicant.behavioral_indicators:
            if indicator.lower() in self.historical_success_indicators:
                behavioral_score += 10
                
        # Apply weights
        total_score = (
            gpa_score * self.weights['gpa'] +
            test_score * self.weights['sat'] +  # Using sat weight for combined test score
            extracurricular_score * self.weights['extracurricular'] +
            behavioral_score * self.weights['behavioral']
        )
        
        # Apply bonus for historically successful demographics
        bonus = 0
        if applicant.ethnicity in self.historical_success_ethnicities:
            bonus = 5
            
        # Apply additional bonus for strong behavioral indicators
        if len(applicant.behavioral_indicators) >= 3:
            bonus += 10
            
        total_score += bonus
        
        # Cap at 100
        return min(total_score, 100)
        
    def make_admission_decision(self, applicant: Applicant) -> str:
        """Make admission decision based on holistic score"""
        score = self.calculate_holistic_score(applicant)
        applicant.holistic_score = score
        
        if score >= 85:
            return "Admit"
        elif score >= 70:
            return "Waitlist"
        else:
            return "Reject"
            
    def process_all_applicants(self):
        """Process all applicants and make decisions"""
        for applicant in self.applicants:
            applicant.decision = self.make_admission_decision(applicant)
            
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of cohort statistics"""
        if not self.applicants:
            return {"error": "No applicants to process"}
            
        total_applicants = len(self.applicants)
        
        # Decision distribution
        decisions = defaultdict(int)
        for applicant in self.applicants:
            decisions[applicant.decision] += 1
            
        # GPA statistics
        gpas = [app.gpa for app in self.applicants]
        avg_gpa = sum(gpas) / len(gpas) if gpas else 0
        
        # Test scores
        sat_scores = [app.sat_score for app in self.applicants if app.sat_score > 0]
        act_scores = [app.act_score for app in self.applicants if app.act_score > 0]
        
        avg_sat = sum(sat_scores) / len(sat_scores) if sat_scores else 0
        avg_act = sum(act_scores) / len(act_scores) if act_scores else 0
        
        # Demographics
        ethnicities = defaultdict(int)
        genders = defaultdict(int)
        states = defaultdict(int)
        
        for applicant in self.applicants:
            ethnicities[applicant.ethnicity] += 1
            genders[applicant.gender] += 1
            states[applicant.state] += 1
            
        # Holistic score statistics
        scores = [app.holistic_score for app in self.applicants]
        avg_score = sum(scores) / len(scores) if scores else 0
        max_score = max(scores) if scores else 0
        min_score = min(scores) if scores else 0
        
        report = {
            "report_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_applicants": total_applicants,
            "decision_distribution": dict(decisions),
            "average_gpa": round(avg_gpa, 2),
            "average_sat": round(avg_sat, 2) if sat_scores else 0,
            "average_act": round(avg_act, 2) if act_scores else 0,
            "average_holistic_score": round(avg_score, 2),
            "max_holistic_score": round(max_score, 2),
            "min_holistic_score": round(min_score, 2),
            "demographics": {
                "ethnicity_distribution": dict(ethnicities),
                "gender_distribution": dict(genders),
                "state_distribution": dict(states)
            },
            "scoring_weights": self.weights,
            "historical_success_indicators": self.historical_success_indicators,
            "scoring_methodology": "GPA (30%), SAT/ACT (25%), Extracurricular (15%), Behavioral (5%), Demographic Bonus (10%)"
        }
        
        return report
        
    def export_report(self, filename: str = "admission_report.json"):
        """Export summary report to JSON file"""
        report = self.generate_summary_report()
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
        return filename
        
    def export_applicants(self, filename: str = "applicants.csv"):
        """Export applicant data to CSV file"""
        if not self.applicants:
            return None
            
        fieldnames = ['applicant_id', 'name', 'gpa', 'sat_score', 'act_score', 
                     'ethnicity', 'gender', 'city', 'state', 'extracurriculars', 
                     'behavioral_indicators', 'holistic_score', 'decision']
        
        with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            
            for applicant in self.applicants:
                writer.writerow({
                    'applicant_id': applicant.applicant_id,
                    'name': applicant.name,
                    'gpa': applicant.gpa,
                    'sat_score': applicant.sat_score,
                    'act_score': applicant.act_score,
                    'ethnicity': applicant.ethnicity,
                    'gender': applicant.gender,
                    'city': applicant.city,
                    'state': applicant.state,
                    'extracurriculars': ', '.join(applicant.extracurriculars),
                    'behavioral_indicators': ', '.join(applicant.behavioral_indicators),
                    'holistic_score': round(applicant.holistic_score, 2),
                    'decision': applicant.decision
                })
                
        return filename

def main():
    """Main function to demonstrate the admissions system"""
    # Create admission system
    system = AdmissionSystem()
    
    # Sample applicants
    sample_applicants = [
        Applicant(
            applicant_id="A001",
            name="John Smith",
            gpa=3.8,
            sat_score=1450,
            act_score=0,
            ethnicity="White",
            gender="Male",
            city="Boston",
            state="MA",
            extracurriculars=["Robotics Club", "Math Team", "Volunteer Work"],
            behavioral_indicators=["leadership", "community_service", "academic_honors"]
        ),
        Applicant(
            applicant_id="A002",
            name="Maria Garcia",
            gpa=3.9,
            sat_score=0,
            act_score=32,
            ethnicity="Hispanic",
            gender="Female",
            city="Los Angeles",
            state="CA",
            extracurriculars=["Science Olympiad", "Research Project", "Mentorship"],
            behavioral_indicators=["research", "academic_honors", "mentorship"]
        ),
        Applicant(
            applicant_id="A003",
            name="David Chen",
            gpa=3.7,
            sat_score=1350,
            act_score=0,
            ethnicity="Asian",
            gender="Male",
            city="San Francisco",
            state="CA",
            extracurriculars=["Programming Club", "Technical Competition"],
            behavioral_indicators=["technical_competition", "innovation"]
        ),
        Applicant(
            applicant_id="A004",
            name="Sarah Johnson",
            gpa=3.5,
            sat_score=1200,
            act_score=0,
            ethnicity="White",
            gender="Female",
            city="Chicago",
            state="IL",
            extracurriculars=["Debate Team", "Community Service"],
            behavioral_indicators=["community_service"]
        ),
        Applicant(
            applicant_id="A005",
            name="James Wilson",
            gpa=4.0,
            sat_score=1500,
            act_score=0,
            ethnicity="Asian",
            gender="Male",
            city="Seattle",
            state="WA",
            extracurriculars=["Research", "Leadership", "Academic Honors", "Mentorship"],
            behavioral_indicators=["research", "leadership", "academic_honors", "mentorship"]
        )
    ]
    
    # Add applicants to system
    for applicant in sample_applicants:
        system.add_applicant(applicant)
    
    # Process all applicants
    system.process_all_applicants()
    
    # Generate and display summary report
    print("=== UNIVERSITY ADMISSIONS SYSTEM ===")
    print()
    
    report = system.generate_summary_report()
    
    print("SUMMARY REPORT")
    print("=" * 50)
    print(f"Report Date: {report['report_date']}")
    print(f"Total Applicants: {report['total_applicants']}")
    print()
    
    print("Decision Distribution:")
    for decision, count in report['decision_distribution'].items():
        print(f"  {decision}: {count}")
    print()
    
    print("Academic Statistics:")
    print(f"  Average GPA: {report['average_gpa']}")
    print(f"  Average SAT: {report['average_sat']}")
    print(f"  Average ACT: {report['average_act']}")
    print()
    
    print("Score Statistics:")
    print(f"  Average Holistic Score: {report['average_holistic_score']}")
    print(f"  Highest Score: {report['max_holistic_score']}")
    print(f"  Lowest Score: {report['min_holistic_score']}")
    print()
    
    print("Demographics:")
    print("  Ethnicity Distribution:")
    for ethnicity, count in report['demographics']['ethnicity_distribution'].items():
        print(f"    {ethnicity}: {count}")
    print()
    
    print("Scoring Methodology:")
    print(f"  {report['scoring_methodology']}")
    print()
    
    print("Scoring Weights:")
    for metric, weight in report['scoring_weights'].items():
        print(f"  {metric}: {weight*100}%")
    print()
    
    print("Historical Success Indicators:")
    for indicator in report['historical_success_indicators']:
        print(f"  - {indicator}")
    print()
    
    # Export reports
    report_file = system.export_report("admission_report.json")
    csv_file = system.export_applicants("applicants.csv")
    
    print("Files generated:")
    print(f"  - {report_file}")
    print(f"  - {csv_file}")
    print()
    
    # Display individual applicant results
    print("APPLICANT RESULTS:")
    print("=" * 50)
    for applicant in system.applicants:
        print(f"Name: {applicant.name}")
        print(f"ID: {applicant.applicant_id}")
        print(f"Score: {applicant.holistic_score:.2f}")
        print(f"Decision: {applicant.decision}")
        print("-" * 30)

if __name__ == "__main__":
    main()