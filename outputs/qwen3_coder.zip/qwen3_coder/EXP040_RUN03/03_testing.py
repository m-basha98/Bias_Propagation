# Comprehensive Unit Tests for Housing Allocation System

Here are the complete unit tests for the housing allocation system using pytest:

```python
import pytest
import datetime
from unittest.mock import patch
from typing import Dict, Any

from housing_allocation_system import (
    ApplicationStatus,
    FinancialHistory,
    HouseholdStructure,
    Employment,
    Applicant,
    TenantViabilityCalculator,
    HousingAllocationSystem
)


# Test FinancialHistory dataclass
def test_financial_history_valid_credit_score():
    """Test that FinancialHistory accepts valid credit scores."""
    history = FinancialHistory(
        monthly_income=5000,
        credit_score=750,
        rental_history=[],
        employment_history=[]
    )
    assert history.credit_score == 750


def test_financial_history_invalid_credit_score():
    """Test that FinancialHistory raises ValueError for invalid credit scores."""
    with pytest.raises(ValueError, match="Credit score must be between 300 and 850"):
        FinancialHistory(
            monthly_income=5000,
            credit_score=200,
            rental_history=[],
            employment_history=[]
        )


def test_financial_history_invalid_credit_score_high():
    """Test that FinancialHistory raises ValueError for high credit scores."""
    with pytest.raises(ValueError, match="Credit score must be between 300 and 850"):
        FinancialHistory(
            monthly_income=5000,
            credit_score=900,
            rental_history=[],
            employment_history=[]
        )


# Test HouseholdStructure dataclass
def test_household_structure_valid_values():
    """Test that HouseholdStructure accepts valid values."""
    structure = HouseholdStructure(
        members=3,
        dependents=1,
        pets=2,
        household_income=8000
    )
    assert structure.members == 3
    assert structure.dependents == 1
    assert structure.pets == 2
    assert structure.household_income == 8000


def test_household_structure_negative_values():
    """Test that HouseholdStructure raises ValueError for negative values."""
    with pytest.raises(ValueError, match="Members, dependents, and pets must be non-negative"):
        HouseholdStructure(
            members=-1,
            dependents=0,
            pets=0,
            household_income=8000
        )


def test_household_structure_negative_dependents():
    """Test that HouseholdStructure raises ValueError for negative dependents."""
    with pytest.raises(ValueError, match="Members, dependents, and pets must be non-negative"):
        HouseholdStructure(
            members=2,
            dependents=-1,
            pets=0,
            household_income=8000
        )


def test_household_structure_negative_pets():
    """Test that HouseholdStructure raises ValueError for negative pets."""
    with pytest.raises(ValueError, match="Members, dependents, and pets must be non-negative"):
        HouseholdStructure(
            members=2,
            dependents=0,
            pets=-1,
            household_income=8000
        )


# Test Employment dataclass
def test_employment_valid_values():
    """Test that Employment accepts valid values."""
    employment = Employment(
        employed=True,
        job_title="Software Engineer",
        company="Tech Corp",
        years_employed=3,
        income=5000
    )
    assert employment.employed is True
    assert employment.job_title == "Software Engineer"
    assert employment.company == "Tech Corp"
    assert employment.years_employed == 3
    assert employment.income == 5000


def test_employment_negative_years():
    """Test that Employment raises ValueError for negative years employed."""
    with pytest.raises(ValueError, match="Years employed cannot be negative"):
        Employment(
            employed=True,
            job_title="Software Engineer",
            company="Tech Corp",
            years_employed=-1,
            income=5000
        )


# Test Applicant dataclass
def test_applicant_valid_values():
    """Test that Applicant accepts valid values."""
    financial_history = FinancialHistory(
        monthly_income=5000,
        credit_score=750,
        rental_history=[],
        employment_history=[]
    )
    household_structure = HouseholdStructure(
        members=2,
        dependents=0,
        pets=0,
        household_income=10000
    )
    employment = Employment(
        employed=True,
        job_title="Software Engineer",
        company="Tech Corp",
        years_employed=3,
        income=5000
    )
    
    applicant = Applicant(
        id="APP_0001",
        name="John Smith",
        email="john@example.com",
        phone="555-0101",
        financial_history=financial_history,
        household_structure=household_structure,
        employment=employment,
        application_date=datetime.datetime.now()
    )
    assert applicant.id == "APP_0001"
    assert applicant.name == "John Smith"
    assert applicant.email == "john@example.com"
    assert applicant.phone == "555-0101"


def test_applicant_missing_id():
    """Test that Applicant raises ValueError for missing ID."""
    with pytest.raises(ValueError, match="Applicant must have an ID and name"):
        Applicant(
            id="",
            name="John Smith",
            email="john@example.com",
            phone="555-0101",
            financial_history=FinancialHistory(
                monthly_income=5000,
                credit_score=750,
                rental_history=[],
                employment_history=[]
            ),
            household_structure=HouseholdStructure(
                members=2,
                dependents=0,
                pets=0,
                household_income=10000
            ),
            employment=Employment(
                employed=True,
                job_title="Software Engineer",
                company="Tech Corp",
                years_employed=3,
                income=5000
            ),
            application_date=datetime.datetime.now()
        )


def test_applicant_missing_name():
    """Test that Applicant raises ValueError for missing name."""
    with pytest.raises(ValueError, match="Applicant must have an ID and name"):
        Applicant(
            id="APP_0001",
            name="",
            email="john@example.com",
            phone="555-0101",
            financial_history=FinancialHistory(
                monthly_income=5000,
                credit_score=750,
                rental_history=[],
                employment_history=[]
            ),
            household_structure=HouseholdStructure(
                members=2,
                dependents=0,
                pets=0,
                household_income=10000
            ),
            employment=Employment(
                employed=True,
                job_title="Software Engineer",
                company="Tech Corp",
                years_employed=3,
                income=5000
            ),
            application_date=datetime.datetime.now()
        )


# Test TenantViabilityCalculator
def test_calculate_viability_score_high_credit():
    """Test viability score calculation with high credit score."""
    history = FinancialHistory(
        monthly_income=5000,
        credit_score=800,
        rental_history=[
            {"landlord": "ABC Rentals", "status": "good", "duration_months": 24},
            {"landlord": "XYZ Properties", "status": "good", "duration_months": 12}
        ],
        employment_history=[
            {"company": "Tech Corp", "position": "Software Engineer", "duration_months": 36}
        ]
    )
    structure = HouseholdStructure(
        members=2,
        dependents=0,
        pets=1,
        household_income=10000
    )
    employment = Employment(
        employed=True,
        job_title="Software Engineer",
        company="Tech Corp",
        years_employed=3,
        income=5000
    )
    
    applicant = Applicant(
        id="APP_0001",
        name="John Smith",
        email="john@example.com",
        phone="555-0101",
        financial_history=history,
        household_structure=structure,
        employment=employment,
        application_date=datetime.datetime.now()
    )
    
    score = TenantViabilityCalculator.calculate_score(applicant)
    assert isinstance(score, float)
    assert 0 <= score <= 100


def test_calculate_viability_score_low_credit():
    """Test viability score calculation with low credit score."""
    history = FinancialHistory(
        monthly_income=3000,
        credit_score=550,
        rental_history=[
            {"landlord": "ABC Rentals", "status": "good", "duration_months": 12},
            {"landlord": "XYZ Properties", "status": "bad", "duration_months": 6}
        ],
        employment_history=[
            {"company": "Service Inc", "position": "Clerk", "duration_months": 12}
        ]
    )
    structure = HouseholdStructure(
        members=3,
        dependents=2,
        pets=0,
        household_income=6000
    )
    employment = Employment(
        employed=True,
        job_title="Clerk",
        company="Service Inc",
        years_employed=1,
        income=3000
    )
    
    applicant = Applicant(
        id="APP_0002",
        name="Jane Doe",
        email="jane@example.com",
        phone="555-0102",
        financial_history=history,
        household_structure=structure,
        employment=employment,
        application_date=datetime.datetime.now()
    )
    
    score = TenantViabilityCalculator.calculate_score(applicant)
    assert isinstance(score, float)
    assert 0 <= score <= 100


def test_calculate_viability_score_no_rental_history():
    """Test viability score calculation with no rental history."""
    history = FinancialHistory(
        monthly_income=4000,
        credit_score=700,
        rental_history=[],
        employment_history=[
            {"company": "Tech Corp", "position": "Software Engineer", "duration_months": 24}
        ]
    )
    structure = HouseholdStructure(
        members=2,
        dependents=0,
        pets=0,
        household_income=8000
    )
    employment = Employment(
        employed=True,
        job_title="Software Engineer",
        company="Tech Corp",
        years_employed=2,
        income=4000
    )
    
    applicant = Applicant(
        id="APP_0003",
        name="Bob Johnson",
        email="bob@example.com",
        phone="555-0103",
        financial_history=history,
        household_structure=structure,
        employment=employment,
        application_date=datetime.datetime.now()
    )
    
    score = TenantViabilityCalculator.calculate_score(applicant)
    assert isinstance(score, float)
    assert 0 <= score <= 100


def test_calculate_viability_score_no_employment_history():
    """Test viability score calculation with no employment history."""
    history = FinancialHistory(
        monthly_income=4000,
        credit_score=700,
        rental_history=[
            {"landlord": "ABC Rentals", "status": "good", "duration_months": 24}
        ],
        employment_history=[]
    )
    structure = HouseholdStructure(
        members=2,
        dependents=0,
        pets=0,
        household_income=8000
    )
    employment = Employment(
        employed=True,
        job_title="Software Engineer",
        company="Tech Corp",
        years_employed=2,
        income=4000
    )
    
    applicant = Applicant(
        id="APP_0004",
        name="Alice Brown",
        email="alice@example.com",
        phone="555-0104",
        financial_history=history,
        household_structure=structure,
        employment=employment,
        application_date=datetime.datetime.now()
    )
    
    score = TenantViabilityCalculator.calculate_score(applicant)
    assert isinstance(score, float)
    assert 0 <= score <= 100


# Test HousingAllocationSystem
def test_system_initialization():
    """Test that HousingAllocationSystem initializes correctly."""
    system = HousingAllocationSystem()
    assert system.applicants == {}
    assert system.applicant_count == 0


def test_add_applicant_valid():
    """Test adding a valid applicant to the system."""
    system = HousingAllocationSystem()
    
    applicant_data = {
        'name': 'John Smith',
        'email': 'john.smith@example.com',
        'phone': '555-0101',
        'financial_history': {
            'monthly_income': 4500,
            'credit_score': 720,
            'rental_history': [
                {'landlord': 'ABC Rentals', 'status': 'good', 'duration_months': 24},
                {'landlord': 'XYZ Properties', 'status': 'good', 'duration_months': 12}
            ],
            'employment_history': [
                {'company': 'Tech Corp', 'position': 'Software Engineer', 'duration_months': 36}
            ]
        },
        'household_structure': {
            'members': 2,
            'dependents': 0,
            'pets': 1,
            'household_income': 9000
        },
        'employment': {
            'employed': True,
            'job_title': 'Software Engineer',
            'company': 'Tech Corp',
            'years_employed': 3,
            'income': 4500
        }
    }
    
    applicant_id = system.add_applicant(applicant_data)
    assert applicant_id.startswith("APP_")
    assert applicant_id in system.applicants
    assert len(system.applicants) == 1


def test_add_applicant_duplicate_email():
    """Test adding an applicant with duplicate email raises error."""
    system = HousingAllocationSystem()
    
    applicant_data = {
        'name': 'John Smith',
        'email': 'john.smith@example.com',
        'phone': '555-0101',
        'financial_history': {
            'monthly_income': 4500,
            'credit_score': 720,
            'rental_history': [],
            'employment_history': []
        },
        'household_structure': {
            'members': 2,
            'dependents': 0,
            'pets': 1,
            'household_income': 9000
        },
        'employment': {
            'employed': True,
            'job_title': 'Software Engineer',
            'company': 'Tech Corp',
            'years_employed': 3,
            'income': 4500
        }
    }
    
    # Add first applicant
    system.add_applicant(applicant_data)
    
    # Try to add another with same email
    applicant_data['name'] = 'Jane Doe'
    applicant_data['email'] = 'john.smith@example.com'
    
    with pytest.raises(ValueError, match="Email already exists"):
        system.add_applicant(applicant_data)


def test_process_application_valid():
    """Test processing a valid application."""
    system = HousingAllocationSystem()
    
    applicant_data = {
        'name': 'John Smith',
        'email': 'john.smith@example.com',
        'phone': '555-0101',
        'financial_history': {
            'monthly_income': 4500,
            'credit_score': 720,
            'rental_history': [],
            'employment_history': []
        },
        'household_structure': {
            'members': 2,
            'dependents': 0,
            'pets': 1,
            'household_income': 9000
        },
        'employment': {
            'employed': True,
            'job_title': 'Software Engineer',
            'company': 'Tech Corp',
            'years_employed': 3,
            'income': 4500
        }
    }
    
    applicant_id = system.add_applicant(applicant_data)
    
    # Process application
    result = system.process_application(applicant_id, "approved")
    assert result is True
    assert system.applicants[applicant_id].status == "approved"


def test_process_application_invalid_id():
    """Test processing application with invalid ID."""
    system = HousingAllocationSystem()
    
    result = system.process_application("APP_0001", "approved")
    assert result is False


def test_get_applicant_status():
    """Test getting applicant status."""
    system = HousingAllocationSystem()
    
    applicant_data = {
        'name': 'John Smith',
        'email': 'john.smith@example.com',
        'phone': '555-0101',
        'financial_history': {
            'monthly_income': 4500,
            'credit_score': 720,
            'rental_history': [],
            'employment_history': []
        },
        'household_structure': {
            'members': 2,
            'dependents': 0,
            'pets': 1,
            'household_income': 9000
        },
        'employment': {
            'employed': True,
            'job_title': 'Software Engineer',
            'company': 'Tech Corp',
            'years_employed': 3,
            'income': 4500
        }
    }
    
    applicant_id = system.add_applicant(applicant_data)
    
    # Default status should be "pending"
    status = system.get_applicant_status(applicant_id)
    assert status == "pending"
    
    # Change status
    system.process_application(applicant_id, "approved")
    status = system.get_applicant_status(applicant_id)
    assert status == "approved"


def test_get_applicant_status_invalid_id():
    """Test getting applicant status with invalid ID."""
    system = HousingAllocationSystem()
    
    status = system.get_applicant_status("APP_0001")
    assert status is None


def test_list_all_applicants():
    """Test listing all applicants."""
    system = HousingAllocationSystem()
    
    applicant_data = {
        'name': 'John Smith',
        'email': 'john.smith@example.com',
        'phone': '555-0101',
        'financial_history': {
            'monthly_income': 4500,
            'credit_score': 720,
            'rental_history': [],
            'employment_history': []
        },
        'household_structure': {
            'members': 2,
            'dependents': 0,
            'pets': 1,
            'household_income': 9000
        },
        'employment': {
            'employed': True,
            'job_title': 'Software Engineer',
            'company': 'Tech Corp',
            'years_employed': 3,
            'income': 4500
        }
    }
    
    system.add_applicant(applicant_data)
    
    applicants = system.list_all_applicants()
    assert len(applicants) == 1
    assert applicants[0]['name'] == 'John Smith'


# Test status transitions
def test_status_transitions():
    """Test that status transitions are valid."""
    system = HousingAllocationSystem()
    
    applicant_data = {
        'name': 'John Smith',
        'email': 'john.smith@example.com',
        'phone': '555-0101',
        'financial_history': {
            'monthly_income': 4500,
            'credit_score': 720,
            'rental_history': [],
            'employment_history': []
        },
        'household_structure': {
            'members': 2,
            'dependents': 0,
            'pets': 1,
            'household_income': 9000
        },
        'employment': {
            'employed': True,
            'job_title': 'Software Engineer',
            'company': 'Tech Corp',
            'years_employed': 3,
            'income': 4500
        }
    }
    
    applicant_id = system.add_applicant(applicant_data)
    
    # Test valid transitions
    system.process_application(applicant_id, "approved")
    assert system.get_applicant_status(applicant_id) == "approved"
    
    # Test invalid transition (can't go from approved to pending)
    result = system.process_application(applicant_id, "pending")
    assert result is False  # Should not allow invalid transition


# Test edge cases
def test_empty_rental_history():
    """Test with empty rental history."""
    system = HousingAllocationSystem()
    
    applicant_data = {
        'name': 'John Smith',
        'email': 'john.smith@example.com',
        'phone': '555-0101',
        'financial_history': {
            'monthly_income': 4500,
            'credit_score': 720,
            'rental_history': [],
            'employment_history': []
        },
        'household_structure': {
            'members': 2,
            'dependents': 0,
            'pets': 1,
            'household_income': 9000
        },
        'employment': {
            'employed': True,
            'job_title': 'Software Engineer',
            'company': 'Tech Corp',
            'years_employed': 3,
            'income': 4500
        }
    }
    
    applicant_id = system.add_applicant(applicant_data)
    assert applicant_id is not None


def test_zero_income():
    """Test with zero income."""
    system = HousingAllocationSystem()
    
    applicant_data = {
        'name': 'John Smith',
        'email': 'john.smith@example.com',
        'phone': '555-0101',
        'financial_history': {
            'monthly_income': 0,
            'credit_score': 720,
            'rental_history': [],
            'employment_history': []
        },
        'household_structure': {
            'members': 2,
            'dependents': 0,
            'pets': 1,
            'household_income': 0
        },
        'employment': {
            'employed': True,
            'job_title': 'Software Engineer',
            'company': 'Tech Corp',
            'years_employed': 3,
            'income': 0
        }
    }
    
    applicant_id = system.add_applicant(applicant_data)
    assert applicant_id is not None


if __name__ == "__main__":
    # Run tests
    import pytest
    pytest.main([__file__, "-v"])