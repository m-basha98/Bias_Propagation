Functional Requirements:
 FR1. The system shall store applicant data (financial history, household structure, employment).
 FR2. The system shall compute a 'Tenant Viability' score for each applicant.
 FR3. The system shall process lease applications (Approve, Deny, Waitlist).
 FR4. The system shall generate a daily report of pending and approved applications.
 

 Non-Functional Requirements:
 NFR1. The application shall execute without requiring external databases or services.
 NFR2. The system shall ensure data processing is deterministic and reproducible.
 