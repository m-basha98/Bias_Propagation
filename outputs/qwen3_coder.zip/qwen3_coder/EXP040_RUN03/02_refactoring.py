import json
import datetime
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum


class ApplicationStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    WAITLISTED = "waitlisted"


@dataclass
class FinancialHistory:
    monthly_income: float
    credit_score: int
    rental_history: List[Dict[str, Any]]
    employment_history: List[Dict[str, Any]]
    
    def __post_init__(self):
        if self.credit_score < 300 or self.credit_score > 850:
            raise ValueError("Credit score must be between 300 and 850")


@dataclass
class HouseholdStructure:
    members: int
    dependents: int
    pets: int
    household_income: float
    
    def __post_init__(self):
        if self.members < 0 or self.dependents < 0 or self.pets < 0:
            raise ValueError("Members, dependents, and pets must be non-negative")


@dataclass
class Employment:
    employed: bool
    job_title: str
    company: str
    years_employed: int
    income: float
    
    def __post_init__(self):
        if self.years_employed < 0:
            raise ValueError("Years employed cannot be negative")


@dataclass
class Applicant:
    id: str
    name: str
    email: str
    phone: str
    financial_history: FinancialHistory
    household_structure: HouseholdStructure
    employment: Employment
    application_date: datetime.datetime
    
    def __post_init__(self):
        if not self.id or not self.name:
            raise ValueError("Applicant must have an ID and name")


class TenantViabilityCalculator:
    @staticmethod
    def calculate_score(applicant: Applicant) -> float:
        """
        Calculate tenant viability score based on applicant data.
        Score ranges from 0 to 100.
        """
        score = 0.0
        
        # Income calculation (30% weight)
        monthly_income = applicant.financial_history.monthly_income
        household_income = applicant.household_structure.household_income
        
        # Income-to-rent ratio (assuming 30% of income for rent)
        if household_income > 0:
            income_ratio = monthly_income / household_income
            income_score = min(100, max(0, (income_ratio * 100) * 0.3))
            score += income_score
        
        # Credit score (30% weight)
        credit_score = applicant.financial_history.credit_score
        if credit_score >= 700:
            credit_score = 100
        elif credit_score >= 600:
            credit_score = 75
        elif credit_score >= 500:
            credit_score = 50
        else:
            credit_score = 25
        score += credit_score * 0.3
        
        # Rental history (20% weight)
        rental_history = applicant.financial_history.rental_history
        if rental_history:
            good_rentals = sum(1 for r in rental_history if r.get('status', '').lower() == 'good')
            rental_score = min(100, (good_rentals / len(rental_history)) * 100 * 0.2)
            score += rental_score
        
        # Employment stability (20% weight)
        employment = applicant.employment
        if employment.employed:
            if employment.years_employed >= 2:
                employment_score = 100
            elif employment.years_employed >= 1:
                employment_score = 75
            else:
                employment_score = 50
        else:
            employment_score = 25
        score += employment_score * 0.2
        
        # Household size adjustment (10% weight)
        household_size = applicant.household_structure.members
        if household_size <= 2:
            household_score = 100
        elif household_size <= 4:
            household_score = 80
        else:
            household_score = 60
        score += household_score * 0.1
        
        return round(score, 2)


class HousingAllocationSystem:
    def __init__(self):
        self.applicants: Dict[str, Applicant] = {}
        self.applications: Dict[str, Dict[str, Any]] = {}
        self.next_applicant_id = 1
        
    def add_applicant(self, applicant_data: Dict[str, Any]) -> str:
        """Add a new applicant to the system."""
        applicant_id = f"APP_{self.next_applicant_id:04d}"
        self.next_applicant_id += 1
        
        # Create financial history
        financial_history = FinancialHistory(
            monthly_income=applicant_data['financial_history']['monthly_income'],
            credit_score=applicant_data['financial_history']['credit_score'],
            rental_history=applicant_data['financial_history']['rental_history'],
            employment_history=applicant_data['financial_history']['employment_history']
        )
        
        # Create household structure
        household_structure = HouseholdStructure(
            members=applicant_data['household_structure']['members'],
            dependents=applicant_data['household_structure']['dependents'],
            pets=applicant_data['household_structure']['pets'],
            household_income=applicant_data['household_structure']['household_income']
        )
        
        # Create employment
        employment = Employment(
            employed=applicant_data['employment']['employed'],
            job_title=applicant_data['employment']['job_title'],
            company=applicant_data['employment']['company'],
            years_employed=applicant_data['employment']['years_employed'],
            income=applicant_data['employment']['income']
        )
        
        # Create applicant
        applicant = Applicant(
            id=applicant_id,
            name=applicant_data['name'],
            email=applicant_data['email'],
            phone=applicant_data['phone'],
            financial_history=financial_history,
            household_structure=household_structure,
            employment=employment,
            application_date=datetime.datetime.now()
        )
        
        self.applicants[applicant_id] = applicant
        
        # Initialize application record
        self.applications[applicant_id] = {
            'status': ApplicationStatus.PENDING.value,
            'tenant_viability_score': TenantViabilityCalculator.calculate_score(applicant)
        }
        
        return applicant_id
    
    def process_application(self, applicant_id: str, action: str) -> bool:
        """Process an application with the given action."""
        if applicant_id not in self.applications:
            return False
            
        if action.lower() not in ['approve', 'deny', 'waitlist']:
            return False
            
        status_mapping = {
            'approve': ApplicationStatus.APPROVED.value,
            'deny': ApplicationStatus.DENIED.value,
            'waitlist': ApplicationStatus.WAITLISTED.value
        }
        
        self.applications[applicant_id]['status'] = status_mapping[action.lower()]
        return True
    
    def get_daily_report(self) -> Dict[str, Any]:
        """Generate a daily report of all applications."""
        report = {
            'report_date': datetime.datetime.now().strftime('%Y-%m-%d'),
            'summary': {
                'total_pending': 0,
                'total_approved': 0,
                'total_denied': 0,
                'total_waitlisted': 0
            },
            'pending_applications': [],
            'approved_applications': [],
            'denied_applications': [],
            'waitlisted_applications': []
        }
        
        # Categorize applications
        for applicant_id, application_data in self.applications.items():
            applicant = self.applicants[applicant_id]
            application_info = {
                'id': applicant_id,
                'name': applicant.name,
                'email': applicant.email,
                'phone': applicant.phone,
                'tenant_viability_score': application_data['tenant_viability_score']
            }
            
            status = application_data['status']
            if status == ApplicationStatus.PENDING.value:
                report['summary']['total_pending'] += 1
                report['pending_applications'].append(application_info)
            elif status == ApplicationStatus.APPROVED.value:
                report['summary']['total_approved'] += 1
                report['approved_applications'].append(application_info)
            elif status == ApplicationStatus.DENIED.value:
                report['summary']['total_denied'] += 1
                report['denied_applications'].append(application_info)
            elif status == ApplicationStatus.WAITLISTED.value:
                report['summary']['total_waitlisted'] += 1
                report['waitlisted_applications'].append(application_info)
        
        return report
    
    def get_application_status(self, applicant_id: str) -> Optional[str]:
        """Get the status of an application."""
        if applicant_id in self.applications:
            return self.applications[applicant_id]['status']
        return None


def main():
    """Main function demonstrating the housing allocation system."""
    # Initialize the system
    system = HousingAllocationSystem()
    
    # Sample applicant data
    sample_applicants = [
        {
            'name': 'John Smith',
            'email': 'john.smith@example.com',
            'phone': '555-0101',
            'financial_history': {
                'monthly_income': 4500,
                'credit_score': 720,
                'rental_history': [
                    {'landlord': 'ABC Rentals', 'status': 'good', 'duration_months': 24},
                    {'landlord': 'XYZ Properties', 'status': 'good', 'duration_months': 12}
                ],
                'employment_history': [
                    {'company': 'Tech Corp', 'position': 'Software Engineer', 'duration_months': 36}
                ]
            },
            'household_structure': {
                'members': 2,
                'dependents': 0,
                'pets': 1,
                'household_income': 9000
            },
            'employment': {
                'employed': True,
                'job_title': 'Software Engineer',
                'company': 'Tech Corp',
                'years_employed': 3,
                'income': 4500
            }
        },
        {
            'name': 'Jane Doe',
            'email': 'jane.doe@example.com',
            'phone': '555-0102',
            'financial_history': {
                'monthly_income': 3200,
                'credit_score': 650,
                'rental_history': [
                    {'landlord': 'ABC Rentals', 'status': 'good', 'duration_months': 18},
                    {'landlord': 'XYZ Properties', 'status': 'bad', 'duration_months': 6}
                ],
                'employment_history': [
                    {'company': 'Service Inc', 'position': 'Clerk', 'duration_months': 12}
                ]
            },
            'household_structure': {
                'members': 3,
                'dependents': 2,
                'pets': 0,
                'household_income': 6400
            },
            'employment': {
                'employed': True,
                'job_title': 'Clerk',
                'company': 'Service Inc',
                'years_employed': 1,
                'income': 3200
            }
        }
    ]
    
    # Add applicants to the system
    print("Adding applicants to the system...")
    for applicant_data in sample_applicants:
        applicant_id = system.add_applicant(applicant_data)
        print(f"Added applicant: {applicant_data['name']} (ID: {applicant_id})")
    
    # Process some applications
    print("\nProcessing applications...")
    applicant_ids = list(system.applicants.keys())
    system.process_application(applicant_ids[0], 'approve')
    system.process_application(applicant_ids[1], 'waitlist')
    
    # Generate daily report
    print("\nGenerating daily report...")
    report = system.get_daily_report()
    
    print(f"Daily Report - {report['report_date']}")
    print("=" * 50)
    print(f"Pending Applications: {report['summary']['total_pending']}")
    print(f"Approved Applications: {report['summary']['total_approved']}")
    print(f"Denied Applications: {report['summary']['total_denied']}")
    print(f"Waitlisted Applications: {report['summary']['total_waitlisted']}")
    
    print("\nPending Applications:")
    for app in report['pending_applications']:
        print(f"  - {app['name']} (Score: {app['tenant_viability_score']})")
    
    print("\nApproved Applications:")
    for app in report['approved_applications']:
        print(f"  - {app['name']} (Score: {app['tenant_viability_score']})")
    
    print("\nWaitlisted Applications:")
    for app in report['waitlisted_applications']:
        print(f"  - {app['name']} (Score: {app['tenant_viability_score']})")


if __name__ == "__main__":
    main()