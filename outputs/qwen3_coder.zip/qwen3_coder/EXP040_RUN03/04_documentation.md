# Technical Documentation

## Overview
This system implements a housing allocation system that processes lease applications by storing applicant data, computing tenant viability scores, and managing application statuses. The system operates entirely offline without external dependencies.

## Classes and Data Structures

### ApplicationStatus (Enum)
Represents the possible statuses for lease applications:
- `PENDING`: Application is under review
- `APPROVED`: Application has been approved
- `DENIED`: Application has been denied
- `WAITLISTED`: Application is on the waitlist

### FinancialHistory (Dataclass)
Stores financial information for applicants.

**Fields:**
- `monthly_income` (float): Monthly income of the applicant
- `credit_score` (int): Credit score (must be between 300 and 850)
- `rental_history` (List[Dict[str, Any]]): History of rental properties
- `employment_history` (List[Dict[str, Any]]): History of employment

**Validation:**
- Credit score must be between 300 and 850

### HouseholdStructure (Dataclass)
Stores household information for applicants.

**Fields:**
- `members` (int): Number of household members
- `dependents` (int): Number of dependents
- `pets` (int): Number of pets
- `household_income` (float): Total household income

**Validation:**
- All values must be non-negative

### Employment (Dataclass)
Stores employment information for applicants.

**Fields:**
- `employed` (bool): Employment status
- `job_title` (str): Current job title
- `company` (str): Current employer
- `years_employed` (int): Years of current employment
- `income` (float): Current income

**Validation:**
- Years employed cannot be negative

### Applicant (Dataclass)
Represents a complete applicant record.

**Fields:**
- `id` (str): Unique applicant identifier
- `name` (str): Applicant's full name
- `email` (str): Applicant's email address
- `phone` (str): Applicant's phone number
- `financial_history` (FinancialHistory): Financial information
- `household_structure` (HouseholdStructure): Household information
- `employment` (Employment): Employment information
- `application_date` (datetime.datetime): Date when application was submitted

**Validation:**
- Applicant must have both ID and name

## Core Components

### TenantViabilityCalculator (Class)
Static class for calculating tenant viability scores.

#### calculate_score(applicant: Applicant) -> float
**Description:** Calculates a tenant viability score based on applicant data using weighted criteria.

**Parameters:**
- `applicant` (Applicant): The applicant for whom to calculate the score

**Returns:**
- `float`: Tenant viability score between 0 and 100

**Scoring Methodology:**
- Income-to-rent ratio (30% weight)
- Credit score (30% weight)
- Rental history (20% weight)
- Employment stability (20% weight)
- Household size adjustment (10% weight)

### HousingAllocationSystem (Class)
Main system class for managing applicants and applications.

#### __init__(self)
**Description:** Initializes the housing allocation system with empty data structures.

**Parameters:**
- None

**Returns:**
- None

#### add_applicant(self, applicant_data: Dict[str, Any]) -> str
**Description:** Adds a new applicant to the system.

**Parameters:**
- `applicant_data` (Dict[str, Any]): Dictionary containing all applicant information

**Returns:**
- `str`: Unique applicant ID assigned to the new applicant

**Input Format:**
```json
{
  "name": "string",
  "email": "string",
  "phone": "string",
  "financial_history": {
    "monthly_income": float,
    "credit_score": int,
    "rental_history": [{"landlord": "string", "status": "string", "duration_months": int}],
    "employment_history": [{"company": "string", "position": "string", "duration_months": int}]
  },
  "household_structure": {
    "members": int,
    "dependents": int,
    "pets": int,
    "household_income": float
  },
  "employment": {
    "employed": bool,
    "job_title": "string",
    "company": "string",
    "years_employed": int,
    "income": float
  }
}
```

#### process_application(self, applicant_id: str, action: str) -> bool
**Description:** Processes an application with the specified action.

**Parameters:**
- `applicant_id` (str): Unique identifier of the applicant
- `action` (str): Action to take ('approve', 'deny', or 'waitlist')

**Returns:**
- `bool`: True if successful, False if applicant not found or invalid action

#### get_daily_report(self) -> Dict[str, Any]
**Description:** Generates a daily report summarizing all applications.

**Parameters:**
- None

**Returns:**
- `Dict[str, Any]`: Dictionary containing the daily report with:
  - `report_date`: Date of the report
  - `summary`: Count of applications by status
  - `pending_applications`: List of pending applications
  - `approved_applications`: List of approved applications
  - `denied_applications`: List of denied applications
  - `waitlisted_applications`: List of waitlisted applications

#### get_application_status(self, applicant_id: str) -> str
**Description:** Retrieves the current status of an application.

**Parameters:**
- `applicant_id` (str): Unique identifier of the applicant

**Returns:**
- `str`: Current status of the application (PENDING, APPROVED, DENIED, WAITLISTED)

## Main Function
The `main()` function demonstrates system usage with sample data:
1. Initializes the housing allocation system
2. Adds sample applicants with various profiles
3. Processes some applications (one approved, one waitlisted)
4. Generates and displays a daily report showing application statuses

## System Characteristics
- **Offline Operation**: No external dependencies or network requirements
- **Deterministic Scoring**: Same inputs always produce same scores
- **Data Validation**: Comprehensive input validation for all fields
- **Status Management**: Complete lifecycle management of applications
- **Reporting**: Automated daily summary generation

## Usage Example
```python
# Initialize system
system = HousingAllocationSystem()

# Add applicant
applicant_id = system.add_applicant(applicant_data)

# Process application
system.process_application(applicant_id, 'approve')

# Get report
report = system.get_daily_report()
```