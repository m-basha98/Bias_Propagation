# Technical Documentation for Housing Allocation System

## Overview

The Housing Allocation System is a deterministic, self-contained application designed to manage housing lease applications. It processes applicant data, calculates tenant viability scores, and generates daily reports on application statuses. The system operates without external dependencies and ensures reproducible results.

## System Architecture

### Core Components

1. **Data Classes**: Represent structured data for applicants and their information
2. **ApplicationStatus Enum**: Defines possible application statuses
3. **HousingAllocationSystem**: Main class managing the entire system workflow

## Data Classes

### ApplicationStatus (Enum)
**Description**: Enumeration representing the possible statuses for lease applications.

**Values**:
- `PENDING`: Application under review
- `APPROVED`: Application approved for housing
- `DENIED`: Application denied
- `WAITLISTED`: Application placed on waitlist

### FinancialHistory (Data Class)
**Description**: Stores financial information for applicants.

**Attributes**:
- `monthly_income` (float): Applicant's monthly income
- `income_history` (List[float]): Historical income data points
- `credit_score` (int): Credit score (typically 300-850)
- `debt_to_income_ratio` (float): Ratio of monthly debt payments to gross income
- `rental_history` (List[Dict]): Rental history records

### HouseholdStructure (Data Class)
**Description**: Stores household composition information.

**Attributes**:
- `household_size` (int): Total number of people in household
- `household_composition` (List[str]): Composition types (e.g., "adult", "child")
- `dependents` (int): Number of dependents

### Employment (Data Class)
**Description**: Stores employment information.

**Attributes**:
- `employment_status` (str): Current employment status
- `employer` (str): Name of current employer
- `job_title` (str): Current job title
- `years_employed` (int): Years of continuous employment
- `employment_history` (List[Dict]): Employment history records

### Applicant (Data Class)
**Description**: Complete applicant information including all supporting data.

**Attributes**:
- `applicant_id` (str): Unique identifier for applicant
- `name` (str): Applicant's full name
- `financial_history` (FinancialHistory): Financial data
- `household_structure` (HouseholdStructure): Household information
- `employment` (Employment): Employment data
- `application_date` (datetime.datetime): Date when application was submitted

### LeaseApplication (Data Class)
**Description**: Represents a processed lease application.

**Attributes**:
- `applicant` (Applicant): Reference to applicant data
- `status` (ApplicationStatus): Current application status
- `viability_score` (float): Calculated tenant viability score
- `decision_date` (Optional[datetime.datetime]): Date when decision was made
- `notes` (str): Additional notes about the application

## Main System Class: HousingAllocationSystem

### Constructor (__init__)
**Description**: Initializes the housing allocation system.

**Parameters**: None

**Returns**: None

**Initialization**: Creates empty dictionaries for applicants, applications, and daily reports.

### add_applicant(applicant: Applicant) → None
**Description**: Adds an applicant to the system's internal storage.

**Parameters**:
- `applicant` (Applicant): The applicant object to add

**Returns**: None

**Side Effects**: Stores the applicant in the internal `applicants` dictionary using applicant_id as key.

### process_application(applicant_id: str) → LeaseApplication
**Description**: Processes a lease application for a given applicant by calculating viability score and determining approval status.

**Parameters**:
- `applicant_id` (str): Unique identifier of the applicant to process

**Returns**: LeaseApplication - The processed application with calculated viability score and status

**Throws**: 
- KeyError: If applicant_id does not exist in system

**Processing Logic**:
1. Retrieves applicant data
2. Calculates viability score using internal scoring algorithm
3. Determines application status based on score thresholds
4. Creates and returns LeaseApplication object

### generate_daily_report() → Dict[str, Any]
**Description**: Generates a daily summary report of application processing results.

**Parameters**: None

**Returns**: Dict[str, Any] - Dictionary containing report data with keys:
- "total_applications" (int): Total number of applications processed
- "approved" (int): Number of approved applications
- "denied" (int): Number of denied applications
- "pending" (int): Number of pending applications
- "waitlisted" (int): Number of waitlisted applications
- "average_viability_score" (float): Average viability score of all applications

### save_system_state(filename: str) → None
**Description**: Serializes the current system state to a JSON file.

**Parameters**:
- `filename` (str): Path to the file where system state will be saved

**Returns**: None

**Side Effects**: Creates or overwrites the specified file with system data in JSON format.

### load_system_state(filename: str) → None
**Description**: Loads system state from a JSON file.

**Parameters**:
- `filename` (str): Path to the file containing system state data

**Returns**: None

**Side Effects**: Replaces current system data with data loaded from the specified file.

## Scoring Algorithm

### Viability Score Calculation
The system calculates viability scores based on the following factors:

1. **Credit Score**: Weighted at 30% (750 = 100% score)
2. **Debt-to-Income Ratio**: Weighted at 25% (0.3 = 100% score)
3. **Income Stability**: Weighted at 20% (based on income history variance)
4. **Employment History**: Weighted at 15% (years employed)
5. **Household Size**: Weighted at 10% (impact on affordability)

**Score Range**: 0.0 to 100.0

### Status Assignment
- **Approved**: Viability score ≥ 75.0
- **Waitlisted**: Viability score ≥ 60.0 and < 75.0
- **Denied**: Viability score < 60.0

## Data Persistence

### File Format
The system uses JSON format for data persistence with the following structure:

```json
{
  "daily_reports": [],
  "applicants": {
    "A001": {
      "applicant_id": "A001",
      "name": "John Doe",
      "financial_history": {
        "monthly_income": 5000,
        "income_history": [4800, 5100, 4900, 5200, 5000],
        "credit_score": 750,
        "debt_to_income_ratio": 0.3,
        "rental_history": [{"landlord": "ABC Rentals", "duration": "2 years"}]
      },
      "household_structure": {
        "household_size": 3,
        "household_composition": ["adult", "adult", "child"],
        "dependents": 1
      },
      "employment": {
        "employment_status": "employed",
        "employer": "Tech Corp",
        "job_title": "Software Engineer",
        "years_employed": 3,
        "employment_history": [{"employer": "Tech Corp", "position": "Software Engineer", "duration": "3 years"}]
      },
      "application_date": "2023-12-01T10:00:00"
    }
  },
  "applications": {
    "A001": {
      "applicant_id": "A001",
      "status": "APPROVED",
      "viability_score": 82.5,
      "decision_date": "2023-12-01T11:30:00",
      "notes": ""
    }
  }
}
```

## Usage Example

The main function demonstrates typical usage:

1. Create system instance
2. Create sample applicant data with financial, household, and employment information
3. Add applicants to system
4. Process applications (automatically calculates viability scores)
5. Display results and generate daily report

## System Requirements

### Dependencies
- Python 3.6+
- Standard library modules only (no external dependencies)

### Performance Characteristics
- Memory usage scales linearly with number of applicants
- Processing time is proportional to the number of applicants
- No external network or database dependencies

### Reproducibility
- All calculations are deterministic
- Same inputs always produce identical outputs
- No random number generation or time-based operations affect results

## Error Handling

### Expected Exceptions
- `KeyError`: When attempting to process non-existent applicants
- `FileNotFoundError`: When loading from non-existent files
- `json.JSONDecodeError`: When loading corrupted JSON files

### Graceful Degradation
- System handles missing data by using default values
- Invalid data in files is logged and skipped
- All operations are idempotent where possible

## Security Considerations

- No external network access
- Data is stored in plain text JSON files
- No encryption or authentication mechanisms included
- All processing occurs locally on the system

## Maintenance Notes

### Data Migration
- System supports loading/saving state files for backup and migration
- JSON format ensures compatibility with future versions
- No database schema changes required

### Extensibility
- New data fields can be added to data classes without breaking existing functionality
- Additional scoring criteria can be incorporated through algorithm modifications
- Status types can be extended through enum modifications

This system provides a complete, self-contained solution for managing housing lease applications with deterministic processing and robust data persistence capabilities.