import pytest
import datetime
from unittest.mock import patch
from typing import List, Dict, Any

from housing_allocation_system import (
    HousingAllocationSystem,
    Applicant,
    FinancialHistory,
    HouseholdStructure,
    Employment,
    LeaseApplication,
    ApplicationStatus
)


class TestHousingAllocationSystem:
    """Test suite for the HousingAllocationSystem class."""

    def test_init_system(self):
        """Test initialization of the system."""
        system = HousingAllocationSystem()
        assert system.applicants == {}
        assert system.applications == {}
        assert system.daily_reports == []

    def test_add_applicant(self):
        """Test adding an applicant to the system."""
        system = HousingAllocationSystem()
        applicant = Applicant(
            applicant_id="A001",
            name="John Doe",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        assert system.applicants["A001"] == applicant

    def test_process_application_valid_applicant(self):
        """Test processing a valid application."""
        system = HousingAllocationSystem()
        
        # Create and add applicant
        applicant = Applicant(
            applicant_id="A001",
            name="John Doe",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        
        # Process application
        application = system.process_application("A001")
        
        assert application.applicant == applicant
        assert application.status in [ApplicationStatus.APPROVED, ApplicationStatus.PENDING, 
                                      ApplicationStatus.WAITLISTED, ApplicationStatus.DENIED]
        assert isinstance(application.viability_score, float)
        assert application.decision_date is not None
        assert application.notes == ""

    def test_process_application_invalid_applicant(self):
        """Test processing an application for a non-existent applicant."""
        system = HousingAllocationSystem()
        
        with pytest.raises(ValueError, match="Applicant with ID A001 not found"):
            system.process_application("A001")

    def test_calculate_viability_score_high_credit(self):
        """Test viability score calculation with high credit score."""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="John Doe",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=850,  # Maximum credit score
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        # Mock the system to avoid time-dependent issues
        with patch.object(system, 'add_applicant'):
            system.add_applicant(applicant)
            application = system.process_application("A001")
            
            # Credit score should contribute significantly to the score
            assert application.viability_score >= 0
            assert application.viability_score <= 100

    def test_calculate_viability_score_high_debt(self):
        """Test viability score calculation with high debt-to-income ratio."""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="John Doe",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=750,
                debt_to_income_ratio=0.8,  # High debt ratio
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(applicant)
            application = system.process_application("A001")
            
            # High debt should lower the score
            assert application.viability_score >= 0
            assert application.viability_score <= 100

    def test_calculate_viability_score_multiple_income_values(self):
        """Test viability score calculation with multiple income values."""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="John Doe",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[4800, 5100, 4900, 5200, 5000],  # Stable income
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(applicant)
            application = system.process_application("A001")
            
            # Should be a valid score
            assert application.viability_score >= 0
            assert application.viability_score <= 100

    def test_calculate_viability_score_zero_income(self):
        """Test viability score calculation with zero income."""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="John Doe",
            financial_history=FinancialHistory(
                monthly_income=0,
                income_history=[0],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(applicant)
            application = system.process_application("A001")
            
            # Should still produce a valid score (likely very low)
            assert application.viability_score >= 0
            assert application.viability_score <= 100

    def test_calculate_viability_score_negative_debt(self):
        """Test viability score calculation with negative debt-to-income ratio."""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="John Doe",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=750,
                debt_to_income_ratio=-0.1,  # Negative debt
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(applicant)
            application = system.process_application("A001")
            
            # Should still produce a valid score
            assert application.viability_score >= 0
            assert application.viability_score <= 100

    def test_generate_daily_report(self):
        """Test generating a daily report."""
        system = HousingAllocationSystem()
        
        # Create and add applicant
        applicant = Applicant(
            applicant_id="A001",
            name="John Doe",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        system.process_application("A001")
        
        # Generate report
        report = system.generate_daily_report()
        
        assert isinstance(report, dict)
        assert "applicant_id" in report
        assert "status" in report
        assert "viability_score" in report
        assert "decision_date" in report
        assert "notes" in report
        assert len(system.daily_reports) == 1

    def test_save_and_load_system_state(self, tmp_path):
        """Test saving and loading system state."""
        system = HousingAllocationSystem()
        
        # Create and add applicant
        applicant = Applicant(
            applicant_id="A001",
            name="John Doe",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        system.process_application("A001")
        
        # Save state
        file_path = tmp_path / "test_state.json"
        system.save_system_state(str(file_path))
        
        # Load state
        new_system = HousingAllocationSystem()
        new_system.load_system_state(str(file_path))
        
        # Verify loaded data
        assert len(new_system.applicants) == 1
        assert len(new_system.applications) == 1
        assert len(new_system.daily_reports) == 1

    def test_application_status_distribution(self):
        """Test that applications get appropriate status based on score."""
        system = HousingAllocationSystem()
        
        # Create applicants with different scores
        applicants = []
        for i, score in enumerate([90, 75, 60, 45, 30]):
            applicant = Applicant(
                applicant_id=f"A00{i+1}",
                name=f"Applicant {i+1}",
                financial_history=FinancialHistory(
                    monthly_income=5000,
                    income_history=[5000],
                    credit_score=score,
                    debt_to_income_ratio=0.3,
                    rental_history=[]
                ),
                household_structure=HouseholdStructure(
                    household_size=3,
                    household_composition=["adult", "adult", "child"],
                    dependents=1
                ),
                employment=Employment(
                    employment_status="employed",
                    employer="Tech Corp",
                    job_title="Software Engineer",
                    years_employed=3,
                    employment_history=[]
                ),
                application_date=datetime.datetime.now()
            )
            applicants.append(applicant)
            system.add_applicant(applicant)
        
        # Process applications
        for applicant in applicants:
            system.process_application(applicant.applicant_id)
        
        # Check that we have applications
        assert len(system.applications) == 5

    def test_empty_system_report(self):
        """Test generating a report from an empty system."""
        system = HousingAllocationSystem()
        
        # Generate report from empty system
        report = system.generate_daily_report()
        
        # Should return an empty dict or handle gracefully
        assert isinstance(report, dict)

    def test_multiple_applications(self):
        """Test handling multiple applications."""
        system = HousingAllocationSystem()
        
        # Create multiple applicants
        for i in range(5):
            applicant = Applicant(
                applicant_id=f"A00{i+1}",
                name=f"Applicant {i+1}",
                financial_history=FinancialHistory(
                    monthly_income=5000,
                    income_history=[5000],
                    credit_score=750,
                    debt_to_income_ratio=0.3,
                    rental_history=[]
                ),
                household_structure=HouseholdStructure(
                    household_size=3,
                    household_composition=["adult", "adult", "child"],
                    dependents=1
                ),
                employment=Employment(
                    employment_status="employed",
                    employer="Tech Corp",
                    job_title="Software Engineer",
                    years_employed=3,
                    employment_history=[]
                ),
                application_date=datetime.datetime.now()
            )
            system.add_applicant(applicant)
            system.process_application(applicant.applicant_id)
        
        # Check that we have 5 applications
        assert len(system.applications) == 5

    def test_boundary_credit_scores(self):
        """Test viability score calculation with boundary credit scores."""
        system = HousingAllocationSystem()
        
        # Test with minimum credit score
        applicant_min = Applicant(
            applicant_id="A001",
            name="Min Credit Applicant",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=300,  # Minimum score
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        # Test with maximum credit score
        applicant_max = Applicant(
            applicant_id="A002",
            name="Max Credit Applicant",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=850,  # Maximum score
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(applicant_min)
            system.add_applicant(applicant_max)
            
            app1 = system.process_application("A001")
            app2 = system.process_application("A002")
            
            # Both should have valid scores
            assert app1.viability_score >= 0
            assert app1.viability_score <= 100
            assert app2.viability_score >= 0
            assert app2.viability_score <= 100

    def test_invalid_income_values(self):
        """Test handling of invalid income values."""
        system = HousingAllocationSystem()
        
        # Test with None income
        applicant = Applicant(
            applicant_id="A001",
            name="None Income Applicant",
            financial_history=FinancialHistory(
                monthly_income=None,
                income_history=[None],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(applicant)
            application = system.process_application("A001")
            
            # Should still produce a valid score
            assert application.viability_score >= 0
            assert application.viability_score <= 100

    def test_empty_income_history(self):
        """Test handling of empty income history."""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="Empty History Applicant",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[],  # Empty history
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(applicant)
            application = system.process_application("A001")
            
            # Should still produce a valid score
            assert application.viability_score >= 0
            assert application.viability_score <= 100

    def test_status_assignment_logic(self):
        """Test that status assignment logic works correctly."""
        system = HousingAllocationSystem()
        
        # Test with a high score
        high_score_applicant = Applicant(
            applicant_id="A001",
            name="High Score Applicant",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=800,
                debt_to_income_ratio=0.2,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(high_score_applicant)
            application = system.process_application("A001")
            
            # Should be a valid application
            assert application.viability_score >= 0
            assert application.viability_score <= 100

    def test_consistent_scoring(self):
        """Test that the same applicant produces consistent scores."""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="Consistent Score Applicant",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(applicant)
            app1 = system.process_application("A001")
            app2 = system.process_application("A001")
            
            # Scores should be consistent (though may not be identical due to randomness)
            assert app1.viability_score >= 0
            assert app1.viability_score <= 100
            assert app2.viability_score >= 0
            assert app2.viability_score <= 100

    def test_no_rental_history(self):
        """Test viability score calculation with no rental history."""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="No Rental History Applicant",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(applicant)
            application = system.process_application("A001")
            
            # Should still produce a valid score
            assert application.viability_score >= 0
            assert application.viability_score <= 100

    def test_large_income_values(self):
        """Test viability score calculation with large income values."""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="Large Income Applicant",
            financial_history=FinancialHistory(
                monthly_income=1000000,
                income_history=[1000000],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(applicant)
            application = system.process_application("A001")
            
            # Should still produce a valid score
            assert application.viability_score >= 0
            assert application.viability_score <= 100

    def test_negative_values(self):
        """Test viability score calculation with negative values."""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="Negative Values Applicant",
            financial_history=FinancialHistory(
                monthly_income=-1000,
                income_history=[-1000],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(applicant)
            application = system.process_application("A001")
            
            # Should still produce a valid score
            assert application.viability_score >= 0
            assert application.viability_score <= 100

    def test_zero_values(self):
        """Test viability score calculation with zero values."""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="Zero Values Applicant",
            financial_history=FinancialHistory(
                monthly_income=0,
                income_history=[0],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(applicant)
            application = system.process_application("A001")
            
            # Should still produce a valid score
            assert application.viability_score >= 0
            assert application.viability_score <= 100

    def test_very_high_debt_ratio(self):
        """Test viability score calculation with very high debt ratio."""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="High Debt Ratio Applicant",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=750,
                debt_to_income_ratio=2.0,  # Very high
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(applicant)
            application = system.process_application("A001")
            
            # Should still produce a valid score
            assert application.viability_score >= 0
            assert application.viability_score <= 100

    def test_very_low_credit_score(self):
        """Test viability score calculation with very low credit score."""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="Low Credit Score Applicant",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=300,  # Very low
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(applicant)
            application = system.process_application("A001")
            
            # Should still produce a valid score
            assert application.viability_score >= 0
            assert application.viability_score <= 100

    def test_extreme_income_scenarios(self):
        """Test viability score calculation with extreme income scenarios."""
        system = HousingAllocationSystem()
        
        # Very high income
        high_income_applicant = Applicant(
            applicant_id="A001",
            name="High Income Applicant",
            financial_history=FinancialHistory(
                monthly_income=10000000,
                income_history=[10000000],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        # Very low income
        low_income_applicant = Applicant(
            applicant_id="A002",
            name="Low Income Applicant",
            financial_history=FinancialHistory(
                monthly_income=1000,
                income_history=[1000],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(high_income_applicant)
            system.add_applicant(low_income_applicant)
            
            app1 = system.process_application("A001")
            app2 = system.process_application("A002")
            
            # Both should produce valid scores
            assert app1.viability_score >= 0
            assert app1.viability_score <= 100
            assert app2.viability_score >= 0
            assert app2.viability_score <= 100

    def test_edge_case_scenarios(self):
        """Test viability score calculation with edge case scenarios."""
        system = HousingAllocationSystem()
        
        # Test with maximum credit score and maximum debt ratio
        max_score_max_debt = Applicant(
            applicant_id="A001",
            name="Max Score Max Debt Applicant",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=850,
                debt_to_income_ratio=2.0,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        # Test with minimum credit score and minimum debt ratio
        min_score_min_debt = Applicant(
            applicant_id="A002",
            name="Min Score Min Debt Applicant",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=300,
                debt_to_income_ratio=0.0,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        with patch.object(system, 'add_applicant'):
            system.add_applicant(max_score_max_debt)
            system.add_applicant(min_score_min_debt)
            
            app1 = system.process_application("A001")
            app2 = system.process_application("A002")
            
            # Both should produce valid scores
            assert app1.viability_score >= 0
            assert app1.viability_score <= 100
            assert app2.viability_score >= 0
            assert app2.viability_score <= 100

    def test_multiple_applicants(self):
        """Test viability score calculation with multiple applicants."""
        system = HousingAllocationSystem()
        
        # Create multiple applicants with different scenarios
        applicants = [
            Applicant(
                applicant_id="A001",
                name="Applicant 1",
                financial_history=FinancialHistory(
                    monthly_income=5000,
                    income_history=[5000],
                    credit_score=750,
                    debt_to_income_ratio=0.3,
                    rental_history=[]
                ),
                household_structure=HouseholdStructure(
                    household_size=3,
                    household_composition=["adult", "adult", "child"],
                    dependents=1
                ),
                employment=Employment(
                    employment_status="employed",
                    employer="Tech Corp",
                    job_title="Software Engineer",
                    years_employed=3,
                    employment_history=[]
                ),
                application_date=datetime.datetime.now()
            ),
            Applicant(
                applicant_id="A002",
                name="Applicant 2",
                financial_history=FinancialHistory(
                    monthly_income=3000,
                    income_history=[3000],
                    credit_score=650,
                    debt_to_income_ratio=0.5,
                    rental_history=[]
                ),
                household_structure=HouseholdStructure(
                    household_size=2,
                    household_composition=["adult", "adult"],
                    dependents=0
                ),
                employment=Employment(
                    employment_status="employed",
                    employer="Tech Corp",
                    job_title="Software Engineer",
                    years_employed=2,
                    employment_history=[]
                ),
                application_date=datetime.datetime.now()
            ),
            Applicant(
                applicant_id="A003",
                name="Applicant 3",
                financial_history=FinancialHistory(
                    monthly_income=10000,
                    income_history=[10000],
                    credit_score=800,
                    debt_to_income_ratio=0.2,
                    rental_history=[]
                ),
                household_structure=HouseholdStructure(
                    household_size=4,
                    household_composition=["adult", "adult", "child", "child"],
                    dependents=2
                ),
                employment=Employment(
                    employment_status="employed",
                    employer="Tech Corp",
                    job_title="Software Engineer",
                    years_employed=5,
                    employment_history=[]
                ),
                application_date=datetime.datetime.now()
            )
        ]
        
        with patch.object(system, 'add_applicant'):
            for applicant in applicants:
                system.add_applicant(applicant)
            
            # Process all applicants
            for applicant in applicants:
                application = system.process_application(applicant.applicant_id)
                assert application.viability_score >= 0
                assert application.viability_score <= 100

    def test_consistency_of_results(self):
        """Test that the same applicant produces consistent results."""
        system = HousingAllocationSystem()
        
        # Create the same applicant multiple times
        applicant_data = {
            "applicant_id": "A001",
            "name": "Consistent Applicant",
            "financial_history": FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            "household_structure": HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            "employment": Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            "application_date": datetime.datetime.now()
        }
        
        # Process the same applicant multiple times
        scores = []
        for i in range(5):
            applicant = Applicant(**applicant_data)
            system.add_applicant(applicant)
            application = system.process_application(applicant.applicant_id)
            scores.append(application.viability_score)
        
        # All scores should be the same (or very close)
        assert all(score == scores[0] for score in scores)

    def test_performance_with_large_dataset(self):
        """Test performance with a large dataset."""
        import time
        
        system = HousingAllocationSystem()
        
        # Create a large number of applicants
        start_time = time.time()
        for i in range(1000):
            applicant = Applicant(
                applicant_id=f"A{i:04d}",
                name=f"Applicant {i}",
                financial_history=FinancialHistory(
                    monthly_income=5000 + i,
                    income_history=[5000 + i],
                    credit_score=750,
                    debt_to_income_ratio=0.3,
                    rental_history=[]
                ),
                household_structure=HouseholdStructure(
                    household_size=3,
                    household_composition=["adult", "adult", "child"],
                    dependents=1
                ),
                employment=Employment(
                    employment_status="employed",
                    employer="Tech Corp",
                    job_title="Software Engineer",
                    years_employed=3,
                    employment_history=[]
                ),
                application_date=datetime.datetime.now()
            )
            system.add_applicant(applicant)
        
        end_time = time.time()
        processing_time = end_time - start_time
        
        # Process all applicants
        start_time = time.time()
        for i in range(1000):
            application = system.process_application(f"A{i:04d}")
            assert application.viability_score >= 0
            assert application.viability_score <= 100
        
        end_time = time.time()
        total_time = end_time - start_time
        
        # Should process quickly (less than 10 seconds for 1000 applicants)
        assert total_time < 10, f"Processing 1000 applicants took {total_time} seconds"

    def test_error_handling(self):
        """Test error handling for invalid inputs."""
        system = HousingAllocationSystem()
        
        # Test with invalid applicant data
        try:
            applicant = Applicant(
                applicant_id=None,  # Invalid ID
                name="Invalid Applicant",
                financial_history=FinancialHistory(
                    monthly_income=5000,
                    income_history=[5000],
                    credit_score=750,
                    debt_to_income_ratio=0.3,
                    rental_history=[]
                ),
                household_structure=HouseholdStructure(
                    household_size=3,
                    household_composition=["adult", "adult", "child"],
                    dependents=1
                ),
                employment=Employment(
                    employment_status="employed",
                    employer="Tech Corp",
                    job_title="Software Engineer",
                    years_employed=3,
                    employment_history=[]
                ),
                application_date=datetime.datetime.now()
            )
            system.add_applicant(applicant)
            application = system.process_application(applicant.applicant_id)
            # If we get here without exception, it's okay, but we expect a valid score
            assert application.viability_score >= 0
            assert application.viability_score <= 100
        except Exception as e:
            # We expect some form of error handling
            print(f"Caught expected error: {e}")
            pass  # This is expected for invalid data

    def test_data_validation(self):
        """Test data validation for financial history."""
        system = HousingAllocationSystem()
        
        # Test with valid financial history
        applicant = Applicant(
            applicant_id="A001",
            name="Valid Applicant",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000, 6000, 7000],  # Valid list of incomes
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        application = system.process_application(applicant.applicant_id)
        assert application.viability_score >= 0
        assert application.viability_score <= 100

    def test_comprehensive_scenarios(self):
        """Test comprehensive scenarios covering all edge cases."""
        system = HousingAllocationSystem()
        
        # Test various scenarios
        test_cases = [
            {
                "applicant_id": "A001",
                "name": "Normal Case",
                "financial_history": FinancialHistory(
                    monthly_income=5000,
                    income_history=[5000],
                    credit_score=750,
                    debt_to_income_ratio=0.3,
                    rental_history=[]
                ),
                "household_structure": HouseholdStructure(
                    household_size=3,
                    household_composition=["adult", "adult", "child"],
                    dependents=1
                ),
                "employment": Employment(
                    employment_status="employed",
                    employer="Tech Corp",
                    job_title="Software Engineer",
                    years_employed=3,
                    employment_history=[]
                ),
                "application_date": datetime.datetime.now()
            },
            {
                "applicant_id": "A002",
                "name": "High Income",
                "financial_history": FinancialHistory(
                    monthly_income=20000,
                    income_history=[20000],
                    credit_score=800,
                    debt_to_income_ratio=0.1,
                    rental_history=[]
                ),
                "household_structure": HouseholdStructure(
                    household_size=4,
                    household_composition=["adult", "adult", "child", "child"],
                    dependents=2
                ),
                "employment": Employment(
                    employment_status="employed",
                    employer="Tech Corp",
                    job_title="Software Engineer",
                    years_employed=5,
                    employment_history=[]
                ),
                "application_date": datetime.datetime.now()
            },
            {
                "applicant_id": "A003",
                "name": "Low Income",
                "financial_history": FinancialHistory(
                    monthly_income=1500,
                    income_history=[1500],
                    credit_score=600,
                    debt_to_income_ratio=0.8,
                    rental_history=[]
                ),
                "household_structure": HouseholdStructure(
                    household_size=2,
                    household_composition=["adult", "adult"],
                    dependents=0
                ),
                "employment": Employment(
                    employment_status="employed",
                    employer="Tech Corp",
                    job_title="Software Engineer",
                    years_employed=1,
                    employment_history=[]
                ),
                "application_date": datetime.datetime.now()
            },
            {
                "applicant_id": "A004",
                "name": "High Debt",
                "financial_history": FinancialHistory(
                    monthly_income=5000,
                    income_history=[5000],
                    credit_score=700,
                    debt_to_income_ratio=0.9,
                    rental_history=[]
                ),
                "household_structure": HouseholdStructure(
                    household_size=3,
                    household_composition=["adult", "adult", "child"],
                    dependents=1
                ),
                "employment": Employment(
                    employment_status="employed",
                    employer="Tech Corp",
                    job_title="Software Engineer",
                    years_employed=2,
                    employment_history=[]
                ),
                "application_date": datetime.datetime.now()
            }
        ]
        
        for test_case in test_cases:
            applicant = Applicant(**test_case)
            system.add_applicant(applicant)
            application = system.process_application(applicant.applicant_id)
            assert application.viability_score >= 0
            assert application.viability_score <= 100

    def test_final_output_format(self):
        """Test that the final output format is correct."""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="Final Test Applicant",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        result = system.process_application(applicant.applicant_id)
        
        # Check that result has the expected structure
        assert hasattr(result, 'applicant_id')
        assert hasattr(result, 'viability_score')
        assert hasattr(result, 'risk_level')
        assert hasattr(result, 'recommendation')
        assert hasattr(result, 'confidence_score')
        
        # Check that scores are within expected ranges
        assert 0 <= result.viability_score <= 100
        assert 0 <= result.confidence_score <= 100
        
        # Check that risk_level is a valid string
        assert result.risk_level in ['Low', 'Medium', 'High']
        
        # Check that recommendation is a valid string
        assert result.recommendation in ['Approve', 'Conditional Approval', 'Reject']

    def test_integration_with_external_systems(self):
        """Test integration with external systems."""
        system = HousingAllocationSystem()
        
        # Mock external systems
        class MockCreditBureau:
            def get_credit_score(self, applicant_id):
                return 750
            
            def get_income_history(self, applicant_id):
                return [5000, 6000, 7000]
        
        class MockEmploymentVerification:
            def verify_employment(self, applicant_id):
                return True
        
        # Inject mock systems
        system.credit_bureau = MockCreditBureau()
        system.employment_verifier = MockEmploymentVerification()
        
        # Test with valid data
        applicant = Applicant(
            applicant_id="A001",
            name="External Integration Test",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        result = system.process_application(applicant.applicant_id)
        
        # Should still produce valid results
        assert 0 <= result.viability_score <= 100
        assert 0 <= result.confidence_score <= 100
        assert result.risk_level in ['Low', 'Medium', 'High']
        assert result.recommendation in ['Approve', 'Conditional Approval', 'Reject']

    def test_backwards_compatibility(self):
        """Test backwards compatibility with older data formats."""
        system = HousingAllocationSystem()
        
        # Test with data that might have been generated in previous versions
        old_format_data = {
            "id": "A001",
            "name": "Old Format Test",
            "income": 5000,
            "credit_score": 750,
            "debt_ratio": 0.3,
            "household_size": 3,
            "dependents": 1,
            "employment_status": "employed",
            "employer": "Tech Corp",
            "job_title": "Software Engineer",
            "years_employed": 3,
            "application_date": datetime.datetime.now()
        }
        
        # Convert to new format (this would be handled by the system)
        applicant = Applicant(
            applicant_id=old_format_data["id"],
            name=old_format_data["name"],
            financial_history=FinancialHistory(
                monthly_income=old_format_data["income"],
                income_history=[old_format_data["income"]],
                credit_score=old_format_data["credit_score"],
                debt_to_income_ratio=old_format_data["debt_ratio"],
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=old_format_data["household_size"],
                household_composition=["adult"] * old_format_data["household_size"],
                dependents=old_format_data["dependents"]
            ),
            employment=Employment(
                employment_status=old_format_data["employment_status"],
                employer=old_format_data["employer"],
                job_title=old_format_data["job_title"],
                years_employed=old_format_data["years_employed"],
                employment_history=[]
            ),
            application_date=old_format_data["application_date"]
        )
        
        system.add_applicant(applicant)
        result = system.process_application(applicant.applicant_id)
        
        # Should produce valid results
        assert 0 <= result.viability_score <= 100
        assert 0 <= result.confidence_score <= 100

    def test_security_and_privacy(self):
        """Test security and privacy considerations."""
        system = HousingAllocationSystem()
        
        # Test that sensitive data is handled properly
        applicant = Applicant(
            applicant_id="A001",
            name="Privacy Test Applicant",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Tech Corp",
                job_title="Software Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        # Add applicant
        system.add_applicant(applicant)
        
        # Process application
        result = system.process_application(applicant.applicant_id)
        
        # The system should not expose sensitive information in results
        assert hasattr(result, 'applicant_id')
        assert hasattr(result, 'viability_score')
        assert hasattr(result, 'risk_level')
        assert hasattr(result, 'recommendation')
        assert hasattr(result, 'confidence_score')
        
        # Ensure no personal financial details are exposed
        assert not hasattr(result, 'monthly_income')
        assert not hasattr(result, 'credit_score')
        assert not hasattr(result, 'debt_to_income_ratio')

    def test_performance_under_load(self):
        """Test system performance under load."""
        import time
        
        system = HousingAllocationSystem()
        
        # Generate test data
        test_applicants = []
        for i in range(100):  # Test with 100 applicants
            applicant = Applicant(
                applicant_id=f"A{i:03d}",
                name=f"Test Applicant {i}",
                financial_history=FinancialHistory(
                    monthly_income=5000 + i,
                    income_history=[5000 + i],
                    credit_score=700 + (i % 100),
                    debt_to_income_ratio=0.3 + (i % 50) / 100,
                    rental_history=[]
                ),
                household_structure=HouseholdStructure(
                    household_size=2 + (i % 3),
                    household_composition=["adult"] * (2 + (i % 3)),
                    dependents=1 + (i % 2)
                ),
                employment=Employment(
                    employment_status="employed",
                    employer="Test Corp",
                    job_title="Test Engineer",
                    years_employed=2 + (i % 10),
                    employment_history=[]
                ),
                application_date=datetime.datetime.now()
            )
            test_applicants.append(applicant)
        
        # Time the processing
        start_time = time.time()
        
        for applicant in test_applicants:
            system.add_applicant(applicant)
            result = system.process_application(applicant.applicant_id)
            assert 0 <= result.viability_score <= 100
        
        end_time = time.time()
        
        # Should complete within reasonable time (e.g., 10 seconds for 100 applicants)
        processing_time = end_time - start_time
        assert processing_time < 10, f"Processing took {processing_time:.2f} seconds, which is too slow"
        
        print(f"Processed 100 applicants in {processing_time:.2f} seconds")

    def test_edge_cases(self):
        """Test edge cases and boundary conditions."""
        system = HousingAllocationSystem()
        
        # Test with minimum values
        applicant_min = Applicant(
            applicant_id="MIN",
            name="Minimum Values Test",
            financial_history=FinancialHistory(
                monthly_income=0,
                income_history=[0],
                credit_score=0,
                debt_to_income_ratio=0,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=0,
                household_composition=[],
                dependents=0
            ),
            employment=Employment(
                employment_status="unemployed",
                employer="",
                job_title="",
                years_employed=0,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant_min)
        result_min = system.process_application(applicant_min.applicant_id)
        
        # Should still produce results
        assert 0 <= result_min.viability_score <= 100
        
        # Test with maximum values
        applicant_max = Applicant(
            applicant_id="MAX",
            name="Maximum Values Test",
            financial_history=FinancialHistory(
                monthly_income=1000000,
                income_history=[1000000],
                credit_score=1000,
                debt_to_income_ratio=1.0,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=20,
                household_composition=["adult"] * 20,
                dependents=20
            ),
            employment=Employment(
                employment_status="employed",
                employer="Very Large Corp",
                job_title="Very Senior Position",
                years_employed=50,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant_max)
        result_max = system.process_application(applicant_max.applicant_id)
        
        # Should still produce results
        assert 0 <= result_max.viability_score <= 100

    def test_logging_and_monitoring(self):
        """Test logging and monitoring capabilities."""
        import logging
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        logger = logging.getLogger(__name__)
        
        system = HousingAllocationSystem()
        
        # Test logging during processing
        applicant = Applicant(
            applicant_id="LOG_TEST",
            name="Logging Test Applicant",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Test Corp",
                job_title="Test Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        result = system.process_application(applicant.applicant_id)
        
        # Should produce valid results
        assert 0 <= result.viability_score <= 100
        
        # Log some information
        logger.info(f"Processed applicant {applicant.applicant_id}")
        logger.info(f"Viability score: {result.viability_score}")
        logger.info(f"Risk level: {result.risk_level}")

    def test_error_handling(self):
        """Test error handling and recovery."""
        system = HousingAllocationSystem()
        
        # Test with invalid data
        try:
            # This should be handled gracefully
            invalid_applicant = Applicant(
                applicant_id="INVALID",
                name="",
                financial_history=FinancialHistory(
                    monthly_income=None,  # Invalid
                    income_history=[None],  # Invalid
                    credit_score=None,  # Invalid
                    debt_to_income_ratio=None,  # Invalid
                    rental_history=[]
                ),
                household_structure=HouseholdStructure(
                    household_size=None,  # Invalid
                    household_composition=[],
                    dependents=None  # Invalid
                ),
                employment=Employment(
                    employment_status=None,  # Invalid
                    employer="",
                    job_title="",
                    years_employed=None,  # Invalid
                    employment_history=[]
                ),
                application_date=None  # Invalid
            )
            
            system.add_applicant(invalid_applicant)
            result = system.process_application(invalid_applicant.applicant_id)
            
            # Should still produce a result, even if it's not ideal
            assert 0 <= result.viability_score <= 100
            
        except Exception as e:
            # If an exception occurs, it should be logged or handled appropriately
            print(f"Exception caught: {e}")
            # This is acceptable for testing purposes

    def test_data_validation(self):
        """Test data validation."""
        system = HousingAllocationSystem()
        
        # Test valid data
        valid_applicant = Applicant(
            applicant_id="VALID",
            name="Valid Applicant",
            financial_history=FinancialHistory(
                monthly_income=5000,
                income_history=[5000],
                credit_score=750,
                debt_to_income_ratio=0.3,
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                household_composition=["adult", "adult", "child"],
                dependents=1
            ),
            employment=Employment(
                employment_status="employed",
                employer="Test Corp",
                job_title="Test Engineer",
                years_employed=3,
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(valid_applicant)
        result = system.process_application(valid_applicant.applicant_id)
        
        assert 0 <= result.viability_score <= 100
        
        # Test invalid data that should be caught
        try:
            # This should be handled gracefully
            invalid_applicant = Applicant(
                applicant_id="INVALID",
                name="",
                financial_history=FinancialHistory(
                    monthly_income=-1000,  # Invalid negative income
                    income_history=[-1000],  # Invalid negative income
                    credit_score=1500,  # Invalid high credit score
                    debt_to_income_ratio=2.0,  # Invalid high debt ratio
                    rental_history=[]
                ),
                household_structure=HouseholdStructure(
                    household_size=-1,  # Invalid negative household size
                    household_composition=[],
                    dependents=-1  # Invalid negative dependents
                ),
                employment=Employment(
                    employment_status="",
                    employer="",
                    job_title="",
                    years_employed=-5,  # Invalid negative years employed
                    employment_history=[]
                ),
                application_date=datetime.datetime.now()
            )
            
            system.add_applicant(invalid_applicant)
            result = system.process_application(invalid_applicant.applicant_id)
            
            # Should still produce a result
            assert 0 <= result.viability_score <= 100
            
        except Exception as e:
            # Log the exception
            print(f"Exception in data validation test: {e}")

    def test_comprehensive_functionality(self):
        """Test comprehensive functionality across all scenarios."""
        system = HousingAllocationSystem()
        
        # Test a comprehensive set of scenarios
        test_scenarios = [
            {
                "id": "SCENARIO_001",
                "name": "Standard Application",
                "income": 5000,
                "credit_score": 700,
                "debt_ratio": 0.3,
                "household_size": 3,
                "dependents": 1,
                "employment_years": 5
            },
            {
                "id": "SCENARIO_002",
                "name": "High Income, Low Debt",
                "income": 10000,
                "credit_score": 750,
                "debt_ratio": 0.1,
                "household_size": 2,
                "dependents": 0,
                "employment_years": 10
            },
            {
                "id": "SCENARIO_003",
                "name": "Low Income, High Debt",
                "income": 2000,
                "credit_score": 600,
                "debt_ratio": 0.8,
                "household_size": 4,
                "dependents": 2,
                "employment_years": 2
            },
            {
                "id": "SCENARIO_004",
                "name": "Very High Income",
                "income": 50000,
                "credit_score": 800,
                "debt_ratio": 0.2,
                "household_size": 5,
                "dependents": 3,
                "employment_years": 15
            }
        ]
        
        for scenario in test_scenarios:
            applicant = Applicant(
                applicant_id=scenario["id"],
                name=scenario["name"],
                financial_history=FinancialHistory(
                    monthly_income=scenario["income"],
                    income_history=[scenario["income"]],
                    credit_score=scenario["credit_score"],
                    debt_to_income_ratio=scenario["debt_ratio"],
                    rental_history=[]
                ),
                household_structure=HouseholdStructure(
                    household_size=scenario["household_size"],
                    household_composition=["adult"] * scenario["household_size"],
                    dependents=scenario["dependents"]
                ),
                employment=Employment(
                    employment_status="employed",
                    employer="Test Corp",
                    job_title="Test Engineer",
                    years_employed=scenario["employment_years"],
                    employment_history=[]
                ),
                application_date=datetime.datetime.now()
            )
            
            system.add_applicant(applicant)
            result = system.process_application(applicant.applicant_id)
            
            # All results should be valid
            assert 0 <= result.viability_score <= 100
            assert result.viability_score >= 0
            assert result.viability_score <= 100
            
            print(f"{scenario['name']}: Score = {result.viability_score:.2f}, Risk = {result.risk_level}")

    def test_api_compatibility(self):
        """Test API compatibility."""
        system = HousingAllocationSystem()
        
        # Test that the system can be used in an API context
        test_data = {
            "applicant_id": "API_TEST",
            "name": "API Test Applicant",
            "financial_history": {
                "monthly_income": 5000,
                "credit_score": 750,
                "debt_to_income_ratio": 0.3
            },
            "household_structure": {
                "household_size": 3,
                "dependents": 1
            },
            "employment": {
                "employment_status": "employed",
                "years_employed": 5
            }
        }
        
        # Convert to Applicant object
        applicant = Applicant(
            applicant_id=test_data["applicant_id"],
            name=test_data["name"],
            financial_history=FinancialHistory(
                monthly_income=test_data["financial_history"]["monthly_income"],
                income_history=[test_data["financial_history"]["monthly_income"]],
                credit_score=test_data["financial_history"]["credit_score"],
                debt_to_income_ratio=test_data["financial_history"]["debt_to_income_ratio"],
                rental_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=test_data["household_structure"]["household_size"],
                household_composition=["adult"] * test_data["household_structure"]["household_size"],
                dependents=test_data["household_structure"]["dependents"]
            ),
            employment=Employment(
                employment_status=test_data["employment"]["employment_status"],
                employer="Test Corp",
                job_title="Test Engineer",
                years_employed=test_data["employment"]["years_employed"],
                employment_history=[]
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        result = system.process_application(applicant.applicant_id)
        
        # Should produce a valid result
        assert 0 <= result.viability_score <= 100
        assert hasattr(result, 'viability_score')
        assert hasattr(result, 'risk_level')
        assert hasattr(result, 'confidence_score')

if __name__ == "__main__":
    # Run all tests
    print("Running comprehensive tests for Housing Allocation System...")
    
    # Test each method individually
    test_methods = [
        test_comprehensive_functionality,
        test_api_compatibility,
        test_data_validation,
        test_error_handling,
        test_logging_and_monitoring,
        test_edge_cases,
        test_performance_under_load,
        test_security,
        test_data_integrity,
        test_user_experience,
        test_integration,
        test_regression,
        test_unit,
        test_load,
        test_stress,
        test_performance,
        test_scalability,
        test_reliability,
        test_maintainability,
        test_portability,
        test_security,
        test_compatibility,
        test_interoperability,
        test_documentation,
        test_training,
        test_support,
        test_maintenance,
        test_upgrade,
        test_deployment,
        test_monitoring,
        test_alerting,
        test_backup,
        test_recovery,
        test_disaster_recovery,
        test_business_continuity,
        test_governance,
        test_compliance,
        test_audit,
        test_quality,
        test_reliability,
        test_security,
        test_performance,
        test_scalability,
        test_maintainability,
        test_portability,
        test_compatibility,
        test_interoperability,
        test_documentation,
        test_training,
        test_support,
        test_maintenance,
        test_upgrade,
        test_deployment,
        test_monitoring,
        test_alerting,
        test_backup,
        test_recovery,
        test_disaster_recovery,
        test_business_continuity,
        test_governance,
        test_compliance,
        test_audit,
        test_quality
    ]
    
    for i, test_method in enumerate(test_methods):
        try:
            print(f"\nRunning test {i+1}: {test_method.__name__}")
            test_method()
            print(f"✓ {test_method.__name__} passed")
        except Exception as e:
            print(f"✗ {test_method.__name__} failed: {e}")
            raise
    
    print("\nAll tests completed successfully!")