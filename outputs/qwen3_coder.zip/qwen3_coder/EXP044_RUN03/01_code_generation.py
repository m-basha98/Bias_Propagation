import json
import datetime
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum
import math

class ApplicationStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    WAITLISTED = "waitlisted"

@dataclass
class FinancialHistory:
    monthly_income: float
    income_history: List[float]  # Last 12 months of income
    credit_score: int
    debt_to_income_ratio: float
    rental_history: List[Dict[str, Any]]  # List of previous rentals

@dataclass
class HouseholdStructure:
    household_size: int
    household_composition: List[str]  # e.g., ["adult", "child", "elderly"]
    dependents: int

@dataclass
class Employment:
    employment_status: str  # "employed", "self-employed", "unemployed", "retired"
    employer: str
    job_title: str
    years_employed: int
    employment_history: List[Dict[str, Any]]  # Previous jobs

@dataclass
class Applicant:
    applicant_id: str
    name: str
    financial_history: FinancialHistory
    household_structure: HouseholdStructure
    employment: Employment
    application_date: datetime.datetime

@dataclass
class LeaseApplication:
    applicant: Applicant
    status: ApplicationStatus
    viability_score: float
    decision_date: Optional[datetime.datetime]
    notes: str = ""

class HousingAllocationSystem:
    def __init__(self):
        self.applicants: Dict[str, Applicant] = {}
        self.applications: Dict[str, LeaseApplication] = {}
        self.daily_reports: List[Dict[str, Any]] = []
    
    def add_applicant(self, applicant: Applicant) -> None:
        """Add an applicant to the system"""
        self.applicants[applicant.applicant_id] = applicant
    
    def compute_viability_score(self, applicant: Applicant) -> float:
        """
        Compute a Tenant Viability score based on:
        - Income stability and amount
        - Credit history
        - Debt-to-income ratio
        - Employment history
        - Income volatility
        - Household size
        """
        score = 0.0
        
        # Income-related factors (max 40 points)
        income_score = self._calculate_income_score(applicant)
        score += income_score
        
        # Credit score (max 20 points)
        credit_score = self._calculate_credit_score(applicant)
        score += credit_score
        
        # Debt-to-income ratio (max 20 points)
        dti_score = self._calculate_dti_score(applicant)
        score += dti_score
        
        # Employment stability (max 15 points)
        employment_score = self._calculate_employment_score(applicant)
        score += employment_score
        
        # Income volatility (max 5 points)
        volatility_score = self._calculate_volatility_score(applicant)
        score += volatility_score
        
        # Household size factor (max 5 points)
        household_score = self._calculate_household_score(applicant)
        score += household_score
        
        # Normalize to 0-100 scale
        return min(100.0, max(0.0, score))
    
    def _calculate_income_score(self, applicant: Applicant) -> float:
        """Calculate income score based on amount and stability"""
        income = applicant.financial_history.monthly_income
        income_history = applicant.financial_history.income_history
        
        # Base score from income amount (max 20 points)
        base_income_score = min(20.0, income / 1000.0)
        
        # Income stability (max 20 points)
        if len(income_history) >= 12:
            # Calculate standard deviation of income over last 12 months
            avg_income = sum(income_history) / len(income_history)
            variance = sum((x - avg_income) ** 2 for x in income_history) / len(income_history)
            std_dev = math.sqrt(variance)
            
            # Normalize standard deviation to score (lower std_dev = higher score)
            stability_score = max(0.0, 20.0 - (std_dev / (avg_income / 100.0) if avg_income > 0 else 1))
        else:
            stability_score = 0.0
            
        return base_income_score + stability_score
    
    def _calculate_credit_score(self, applicant: Applicant) -> float:
        """Calculate credit score component"""
        credit_score = applicant.financial_history.credit_score
        # Credit score is normalized to 0-20 points
        return min(20.0, max(0.0, (credit_score - 300) / 10.0))
    
    def _calculate_dti_score(self, applicant: Applicant) -> float:
        """Calculate debt-to-income score"""
        dti = applicant.financial_history.debt_to_income_ratio
        # DTI score (max 20 points)
        if dti <= 0.3:
            return 20.0
        elif dti <= 0.4:
            return 15.0
        elif dti <= 0.5:
            return 10.0
        elif dti <= 0.6:
            return 5.0
        else:
            return 0.0
    
    def _calculate_employment_score(self, applicant: Applicant) -> float:
        """Calculate employment stability score"""
        employment = applicant.employment
        
        # Base score based on employment status (max 10 points)
        status_scores = {
            "employed": 10.0,
            "self-employed": 7.0,
            "unemployed": 0.0,
            "retired": 5.0
        }
        
        base_status_score = status_scores.get(employment.employment_status, 0.0)
        
        # Years of employment (max 5 points)
        years_score = min(5.0, employment.years_employed)
        
        return base_status_score + years_score
    
    def _calculate_volatility_score(self, applicant: Applicant) -> float:
        """Calculate income volatility score"""
        income_history = applicant.financial_history.income_history
        
        if len(income_history) < 12:
            return 0.0
            
        # Calculate volatility using coefficient of variation
        avg_income = sum(income_history) / len(income_history)
        if avg_income <= 0:
            return 0.0
            
        variance = sum((x - avg_income) ** 2 for x in income_history) / len(income_history)
        std_dev = math.sqrt(variance)
        coefficient_of_variation = std_dev / avg_income
        
        # Convert coefficient of variation to score (lower CV = lower volatility = higher score)
        volatility_score = max(0.0, 5.0 - (coefficient_of_variation * 100))
        
        return volatility_score
    
    def _calculate_household_score(self, applicant: Applicant) -> float:
        """Calculate household size impact on score"""
        household_size = applicant.household_structure.household_size
        
        # Household size factor (max 5 points)
        if household_size <= 2:
            return 5.0
        elif household_size <= 4:
            return 3.0
        elif household_size <= 6:
            return 1.0
        else:
            return 0.0
    
    def process_application(self, applicant_id: str) -> LeaseApplication:
        """Process a lease application for an applicant"""
        if applicant_id not in self.applicants:
            raise ValueError(f"Applicant with ID {applicant_id} not found")
        
        applicant = self.applicants[applicant_id]
        viability_score = self.compute_viability_score(applicant)
        
        # Decision logic based on viability score
        if viability_score >= 80:
            status = ApplicationStatus.APPROVED
        elif viability_score >= 60:
            status = ApplicationStatus.PENDING
        elif viability_score >= 40:
            status = ApplicationStatus.WAITLISTED
        else:
            status = ApplicationStatus.DENIED
        
        application = LeaseApplication(
            applicant=applicant,
            status=status,
            viability_score=viability_score,
            decision_date=datetime.datetime.now(),
            notes=""
        )
        
        self.applications[applicant_id] = application
        return application
    
    def generate_daily_report(self) -> Dict[str, Any]:
        """Generate a daily report of pending and approved applications"""
        today = datetime.datetime.now().date()
        
        pending_count = 0
        approved_count = 0
        denied_count = 0
        waitlisted_count = 0
        avg_viability = 0.0
        total_viability = 0.0
        total_applications = 0
        
        for application in self.applications.values():
            if application.decision_date and application.decision_date.date() == today:
                total_applications += 1
                total_viability += application.viability_score
                
                if application.status == ApplicationStatus.PENDING:
                    pending_count += 1
                elif application.status == ApplicationStatus.APPROVED:
                    approved_count += 1
                elif application.status == ApplicationStatus.DENIED:
                    denied_count += 1
                elif application.status == ApplicationStatus.WAITLISTED:
                    waitlisted_count += 1
        
        if total_applications > 0:
            avg_viability = total_viability / total_applications
        
        report = {
            "report_date": today.isoformat(),
            "pending_applications": pending_count,
            "approved_applications": approved_count,
            "denied_applications": denied_count,
            "waitlisted_applications": waitlisted_count,
            "total_applications": total_applications,
            "average_viability_score": round(avg_viability, 2)
        }
        
        self.daily_reports.append(report)
        return report
    
    def get_application_status(self, applicant_id: str) -> Optional[LeaseApplication]:
        """Get the status of a specific application"""
        return self.applications.get(applicant_id)
    
    def get_all_applications(self) -> List[LeaseApplication]:
        """Get all applications"""
        return list(self.applications.values())
    
    def save_system_state(self, filename: str) -> None:
        """Save the current system state to a file"""
        state = {
            "applicants": {},
            "applications": {},
            "daily_reports": self.daily_reports
        }
        
        # Serialize applicants
        for applicant_id, applicant in self.applicants.items():
            state["applicants"][applicant_id] = {
                "applicant_id": applicant.applicant_id,
                "name": applicant.name,
                "financial_history": {
                    "monthly_income": applicant.financial_history.monthly_income,
                    "income_history": applicant.financial_history.income_history,
                    "credit_score": applicant.financial_history.credit_score,
                    "debt_to_income_ratio": applicant.financial_history.debt_to_income_ratio,
                    "rental_history": applicant.financial_history.rental_history
                },
                "household_structure": {
                    "household_size": applicant.household_structure.household_size,
                    "household_composition": applicant.household_structure.household_composition,
                    "dependents": applicant.household_structure.dependents
                },
                "employment": {
                    "employment_status": applicant.employment.employment_status,
                    "employer": applicant.employment.employer,
                    "job_title": applicant.employment.job_title,
                    "years_employed": applicant.employment.years_employed,
                    "employment_history": applicant.employment.employment_history
                },
                "application_date": applicant.application_date.isoformat()
            }
        
        # Serialize applications
        for applicant_id, application in self.applications.items():
            state["applications"][applicant_id] = {
                "applicant_id": application.applicant.applicant_id,
                "status": application.status.value,
                "viability_score": application.viability_score,
                "decision_date": application.decision_date.isoformat() if application.decision_date else None,
                "notes": application.notes
            }
        
        with open(filename, 'w') as f:
            json.dump(state, f, indent=2)
    
    def load_system_state(self, filename: str) -> None:
        """Load system state from a file"""
        with open(filename, 'r') as f:
            state = json.load(f)
        
        self.daily_reports = state.get("daily_reports", [])
        
        # Load applicants
        self.applicants = {}
        for applicant_id, applicant_data in state.get("applicants", {}).items():
            financial_history = FinancialHistory(
                monthly_income=applicant_data["financial_history"]["monthly_income"],
                income_history=applicant_data["financial_history"]["income_history"],
                credit_score=applicant_data["financial_history"]["credit_score"],
                debt_to_income_ratio=applicant_data["financial_history"]["debt_to_income_ratio"],
                rental_history=applicant_data["financial_history"]["rental_history"]
            )
            
            household_structure = HouseholdStructure(
                household_size=applicant_data["household_structure"]["household_size"],
                household_composition=applicant_data["household_structure"]["household_composition"],
                dependents=applicant_data["household_structure"]["dependents"]
            )
            
            employment = Employment(
                employment_status=applicant_data["employment"]["employment_status"],
                employer=applicant_data["employment"]["employer"],
                job_title=applicant_data["employment"]["job_title"],
                years_employed=applicant_data["employment"]["years_employed"],
                employment_history=applicant_data["employment"]["employment_history"]
            )
            
            applicant = Applicant(
                applicant_id=applicant_data["applicant_id"],
                name=applicant_data["name"],
                financial_history=financial_history,
                household_structure=household_structure,
                employment=employment,
                application_date=datetime.datetime.fromisoformat(applicant_data["application_date"])
            )
            
            self.applicants[applicant_id] = applicant
        
        # Load applications
        self.applications = {}
        for applicant_id, application_data in state.get("applications", {}).items():
            applicant = self.applicants.get(applicant_id)
            if applicant:
                application = LeaseApplication(
                    applicant=applicant,
                    status=ApplicationStatus(application_data["status"]),
                    viability_score=application_data["viability_score"],
                    decision_date=datetime.datetime.fromisoformat(application_data["decision_date"]) if application_data["decision_date"] else None,
                    notes=application_data["notes"]
                )
                self.applications[applicant_id] = application

# Example usage
def main():
    # Create the housing allocation system
    system = HousingAllocationSystem()
    
    # Create sample applicants
    applicant1 = Applicant(
        applicant_id="A001",
        name="John Smith",
        financial_history=FinancialHistory(
            monthly_income=4500.0,
            income_history=[4200, 4300, 4400, 4500, 4600, 4700, 4800, 4900, 5000, 5100, 5200, 5300],
            credit_score=720,
            debt_to_income_ratio=0.25,
            rental_history=[{"landlord": "ABC Rentals", "status": "positive", "duration_months": 24}]
        ),
        household_structure=HouseholdStructure(
            household_size=3,
            household_composition=["adult", "adult", "child"],
            dependents=1
        ),
        employment=Employment(
            employment_status="employed",
            employer="Tech Corp",
            job_title="Software Engineer",
            years_employed=3,
            employment_history=[{"employer": "Tech Corp", "position": "Software Engineer", "duration_months": 36}]
        ),
        application_date=datetime.datetime.now()
    )
    
    applicant2 = Applicant(
        applicant_id="A002",
        name="Sarah Johnson",
        financial_history=FinancialHistory(
            monthly_income=3200.0,
            income_history=[3000, 3100, 3200, 3300, 3400, 3500, 3600, 3700, 3800, 3900, 4000, 4100],
            credit_score=680,
            debt_to_income_ratio=0.35,
            rental_history=[{"landlord": "XYZ Rentals", "status": "positive", "duration_months": 18}]
        ),
        household_structure=HouseholdStructure(
            household_size=2,
            household_composition=["adult", "adult"],
            dependents=0
        ),
        employment=Employment(
            employment_status="employed",
            employer="Marketing Inc",
            job_title="Marketing Specialist",
            years_employed=2,
            employment_history=[{"employer": "Marketing Inc", "position": "Marketing Specialist", "duration_months": 24}]
        ),
        application_date=datetime.datetime.now()
    )
    
    # Add applicants to the system
    system.add_applicant(applicant1)
    system.add_applicant(applicant2)
    
    # Process applications
    print("Processing applications...")
    application1 = system.process_application("A001")
    application2 = system.process_application("A002")
    
    print(f"Applicant {application1.applicant.name}: Viability Score = {application1.viability_score:.2f}, Status = {application1.status.value}")
    print(f"Applicant {application2.applicant.name}: Viability Score = {application2.viability_score:.2f}, Status = {application2.status.value}")
    
    # Generate daily report
    report = system.generate_daily_report()
    print("\nDaily Report:")
    print(json.dumps(report, indent=2))
    
    # Save system state
    system.save_system_state("housing_system_state.json")
    print("\nSystem state saved to housing_system_state.json")

if __name__ == "__main__":
    main()