```python
import json
import datetime
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum
import math


class ApplicationStatus(Enum):
    """Enumeration for application statuses."""
    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    WAITLISTED = "waitlisted"


@dataclass
class FinancialHistory:
    """Data class for financial history information."""
    monthly_income: float
    income_history: List[float]
    credit_score: int
    debt_to_income_ratio: float
    rental_history: List[Dict[str, Any]]


@dataclass
class HouseholdStructure:
    """Data class for household structure information."""
    household_size: int
    household_composition: List[str]
    dependents: int


@dataclass
class Employment:
    """Data class for employment information."""
    employment_status: str
    employer: str
    job_title: str
    years_employed: int
    employment_history: List[Dict[str, Any]]


@dataclass
class Applicant:
    """Data class for applicant information."""
    applicant_id: str
    name: str
    financial_history: FinancialHistory
    household_structure: HouseholdStructure
    employment: Employment
    application_date: datetime.datetime


@dataclass
class LeaseApplication:
    """Data class for lease application information."""
    applicant: Applicant
    status: ApplicationStatus
    viability_score: float
    decision_date: Optional[datetime.datetime]
    notes: str


class HousingAllocationSystem:
    """Main system for managing housing applications and allocations."""

    def __init__(self):
        """Initialize the housing allocation system."""
        self.applicants: Dict[str, Applicant] = {}
        self.applications: Dict[str, LeaseApplication] = {}
        self.daily_reports: List[Dict[str, Any]] = []

    def add_applicant(self, applicant: Applicant) -> None:
        """Add an applicant to the system."""
        self.applicants[applicant.applicant_id] = applicant

    def process_application(self, applicant_id: str) -> LeaseApplication:
        """
        Process an application for a given applicant.
        
        Args:
            applicant_id: The ID of the applicant
            
        Returns:
            LeaseApplication: The processed application
        """
        applicant = self.applicants.get(applicant_id)
        if not applicant:
            raise ValueError(f"Applicant with ID {applicant_id} not found")

        # Calculate viability score
        viability_score = self._calculate_viability_score(applicant)

        # Determine status based on viability score
        if viability_score >= 80:
            status = ApplicationStatus.APPROVED
        elif viability_score >= 60:
            status = ApplicationStatus.PENDING
        elif viability_score >= 40:
            status = ApplicationStatus.WAITLISTED
        else:
            status = ApplicationStatus.DENIED

        application = LeaseApplication(
            applicant=applicant,
            status=status,
            viability_score=viability_score,
            decision_date=datetime.datetime.now(),
            notes=""
        )

        self.applications[applicant_id] = application
        return application

    def _calculate_viability_score(self, applicant: Applicant) -> float:
        """
        Calculate the viability score for an applicant.
        
        Args:
            applicant: The applicant to calculate score for
            
        Returns:
            float: The calculated viability score
        """
        # Base score from credit score (0-100)
        credit_score_factor = min(applicant.financial_history.credit_score / 850 * 100, 100)
        
        # Income stability factor (0-100)
        income_stability = self._calculate_income_stability(applicant.financial_history.income_history)
        
        # Debt to income ratio factor (0-100)
        debt_factor = max(0, 100 - (applicant.financial_history.debt_to_income_ratio * 100))
        
        # Employment stability factor (0-100)
        employment_stability = min(applicant.employment.years_employed * 10, 100)
        
        # Household size factor (0-100)
        household_factor = max(0, 100 - (applicant.household_structure.household_size * 5))
        
        # Calculate final score
        score = (credit_score_factor * 0.3 +
                 income_stability * 0.2 +
                 debt_factor * 0.2 +
                 employment_stability * 0.2 +
                 household_factor * 0.1)
        
        return round(score, 2)

    def _calculate_income_stability(self, income_history: List[float]) -> float:
        """
        Calculate income stability based on income history.
        
        Args:
            income_history: List of income values
            
        Returns:
            float: Income stability score (0-100)
        """
        if len(income_history) < 2:
            return 100
        
        # Calculate standard deviation of income
        mean_income = sum(income_history) / len(income_history)
        variance = sum((x - mean_income) ** 2 for x in income_history) / len(income_history)
        std_dev = math.sqrt(variance)
        
        # Convert to stability score (lower std_dev = higher stability)
        stability = max(0, 100 - (std_dev / mean_income * 100))
        
        return stability

    def generate_daily_report(self) -> Dict[str, Any]:
        """
        Generate a daily report of applications.
        
        Returns:
            Dict: The daily report data
        """
        today = datetime.datetime.now().date()
        pending_count = 0
        approved_count = 0
        denied_count = 0
        waitlisted_count = 0
        total_viability = 0.0
        total_applications = 0

        for application in self.applications.values():
            if application.decision_date and application.decision_date.date() == today:
                total_applications += 1
                total_viability += application.viability_score

                if application.status == ApplicationStatus.PENDING:
                    pending_count += 1
                elif application.status == ApplicationStatus.APPROVED:
                    approved_count += 1
                elif application.status == ApplicationStatus.DENIED:
                    denied_count += 1
                elif application.status == ApplicationStatus.WAITLISTED:
                    waitlisted_count += 1

        average_viability = total_viability / total_applications if total_applications > 0 else 0.0

        report = {
            "report_date": today.isoformat(),
            "pending_applications": pending_count,
            "approved_applications": approved_count,
            "denied_applications": denied_count,
            "waitlisted_applications": waitlisted_count,
            "total_applications": total_applications,
            "average_viability_score": round(average_viability, 2)
        }

        self.daily_reports.append(report)
        return report

    def get_application_status(self, applicant_id: str) -> Optional[LeaseApplication]:
        """
        Get the status of a specific application.
        
        Args:
            applicant_id: The ID of the applicant
            
        Returns:
            LeaseApplication or None: The application or None if not found
        """
        return self.applications.get(applicant_id)

    def get_all_applications(self) -> List[LeaseApplication]:
        """
        Get all applications.
        
        Returns:
            List[LeaseApplication]: List of all applications
        """
        return list(self.applications.values())

    def save_system_state(self, filename: str) -> None:
        """
        Save the current system state to a file.
        
        Args:
            filename: The name of the file to save to
        """
        state = {
            "applicants": {},
            "applications": {},
            "daily_reports": self.daily_reports
        }

        # Serialize applicants
        for applicant_id, applicant in self.applicants.items():
            state["applicants"][applicant_id] = {
                "applicant_id": applicant.applicant_id,
                "name": applicant.name,
                "financial_history": {
                    "monthly_income": applicant.financial_history.monthly_income,
                    "income_history": applicant.financial_history.income_history,
                    "credit_score": applicant.financial_history.credit_score,
                    "debt_to_income_ratio": applicant.financial_history.debt_to_income_ratio,
                    "rental_history": applicant.financial_history.rental_history
                },
                "household_structure": {
                    "household_size": applicant.household_structure.household_size,
                    "household_composition": applicant.household_structure.household_composition,
                    "dependents": applicant.household_structure.dependents
                },
                "employment": {
                    "employment_status": applicant.employment.employment_status,
                    "employer": applicant.employment.employer,
                    "job_title": applicant.employment.job_title,
                    "years_employed": applicant.employment.years_employed,
                    "employment_history": applicant.employment.employment_history
                },
                "application_date": applicant.application_date.isoformat()
            }

        # Serialize applications
        for applicant_id, application in self.applications.items():
            state["applications"][applicant_id] = {
                "applicant_id": application.applicant.applicant_id,
                "status": application.status.value,
                "viability_score": application.viability_score,
                "decision_date": application.decision_date.isoformat() if application.decision_date else None,
                "notes": application.notes
            }

        with open(filename, 'w') as f:
            json.dump(state, f, indent=2)

    def load_system_state(self, filename: str) -> None:
        """
        Load system state from a file.
        
        Args:
            filename: The name of the file to load from
        """
        with open(filename, 'r') as f:
            state = json.load(f)

        self.daily_reports = state.get("daily_reports", [])

        # Load applicants
        for applicant_id, applicant_data in state.get("applicants", {}).items():
            applicant = Applicant(
                applicant_id=applicant_data["applicant_id"],
                name=applicant_data["name"],
                financial_history=FinancialHistory(
                    monthly_income=applicant_data["financial_history"]["monthly_income"],
                    income_history=applicant_data["financial_history"]["income_history"],
                    credit_score=applicant_data["financial_history"]["credit_score"],
                    debt_to_income_ratio=applicant_data["financial_history"]["debt_to_income_ratio"],
                    rental_history=applicant_data["financial_history"]["rental_history"]
                ),
                household_structure=HouseholdStructure(
                    household_size=applicant_data["household_structure"]["household_size"],
                    household_composition=applicant_data["household_structure"]["household_composition"],
                    dependents=applicant_data["household_structure"]["dependents"]
                ),
                employment=Employment(
                    employment_status=applicant_data["employment"]["employment_status"],
                    employer=applicant_data["employment"]["employer"],
                    job_title=applicant_data["employment"]["job_title"],
                    years_employed=applicant_data["employment"]["years_employed"],
                    employment_history=applicant_data["employment"]["employment_history"]
                ),
                application_date=datetime.datetime.fromisoformat(applicant_data["application_date"])
            )
            self.applicants[applicant_id] = applicant

        # Load applications
        for applicant_id, application_data in state.get("applications", {}).items():
            applicant = self.applicants.get(applicant_id)
            if applicant:
                application = LeaseApplication(
                    applicant=applicant,
                    status=ApplicationStatus(application_data["status"]),
                    viability_score=application_data["viability_score"],
                    decision_date=datetime.datetime.fromisoformat(application_data["decision_date"]) if application_data["decision_date"] else None,
                    notes=application_data["notes"]
                )
                self.applications[applicant_id] = application


def main():
    """Main function to demonstrate the system usage."""
    # Create system
    system = HousingAllocationSystem()

    # Create sample applicants
    applicant1 = Applicant(
        applicant_id="A001",
        name="John Doe",
        financial_history=FinancialHistory(
            monthly_income=5000,
            income_history=[4800, 5100, 4900, 5200, 5000],
            credit_score=750,
            debt_to_income_ratio=0.3,
            rental_history=[{"landlord": "ABC Rentals", "duration": "2 years"}]
        ),
        household_structure=HouseholdStructure(
            household_size=3,
            household_composition=["adult", "adult", "child"],
            dependents=1
        ),
        employment=Employment(
            employment_status="employed",
            employer="Tech Corp",
            job_title="Software Engineer",
            years_employed=3,
            employment_history=[{"employer": "Tech Corp", "position": "Software Engineer", "duration": "3 years"}]
        ),
        application_date=datetime.datetime.now()
    )

    applicant2 = Applicant(
        applicant_id="A002",
        name="Jane Smith",
        financial_history=FinancialHistory(
            monthly_income=4000,
            income_history=[3800, 4100, 3900, 4200, 4000],
            credit_score=680,
            debt_to_income_ratio=0.4,
            rental_history=[{"landlord": "XYZ Rentals", "duration": "1 year"}]
        ),
        household_structure=HouseholdStructure(
            household_size=2,
            household_composition=["adult", "adult"],
            dependents=0
        ),
        employment=Employment(
            employment_status="employed",
            employer="Finance Inc",
            job_title="Accountant",
            years_employed=2,
            employment_history=[{"employer": "Finance Inc", "position": "Accountant", "duration": "2 years"}]
        ),
        application_date=datetime.datetime.now()
    )

    # Add applicants to system
    system.add_applicant(applicant1)
    system.add_applicant(applicant2)

    # Process applications
    application1 = system.process_application("A001")
    application2 = system.process_application("A002")

    print(f"Application 1 Status: {application1.status.value}")
    print(f"Application 1 Viability Score: {application1.viability_score}")
    print(f"Application 2 Status: {application2.status.value}")
    print(f"Application 2 Viability Score: {application2.viability_score}")

    # Generate daily report
    report = system.generate_daily_report()
    print("\nDaily Report:")
    for key, value in report.items():
        print(f"  {key}: {value}")


if __name__ == "__main__":
    main()