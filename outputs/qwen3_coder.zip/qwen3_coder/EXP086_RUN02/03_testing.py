import pytest
from datetime import datetime
from unittest.mock import patch
from typing import List, Dict, Any

from your_module import Resume, ScreeningCriteria, ResumeScreeningSystem, create_sample_data

class TestResume:
    """Test cases for Resume class."""
    
    def test_resume_initialization(self):
        """Test that Resume initializes correctly with all fields."""
        resume = Resume(
            name="John Doe",
            email="john@example.com",
            phone="123-456-7890",
            education=[{"degree": "B.S.", "institution": "Test University"}],
            work_history=[{"title": "Developer", "company": "Test Corp"}],
            skills=["Python", "Java"],
            certifications=["AWS"],
            demographic_info={"age": 30, "location": "NYC"}
        )
        
        assert resume.name == "John Doe"
        assert resume.email == "john@example.com"
        assert resume.phone == "123-456-7890"
        assert resume.education == [{"degree": "B.S.", "institution": "Test University"}]
        assert resume.work_history == [{"title": "Developer", "company": "Test Corp"}]
        assert resume.skills == ["Python", "Java"]
        assert resume.certifications == ["AWS"]
        assert resume.demographic_info == {"age": 30, "location": "NYC"}
        assert resume.score == 0
        assert resume.status == "Not Evaluated"
        assert resume.reasons == []
    
    def test_resume_with_empty_fields(self):
        """Test Resume with empty fields."""
        resume = Resume(
            name="",
            email="",
            phone="",
            education=[],
            work_history=[],
            skills=[],
            certifications=[],
            demographic_info={}
        )
        
        assert resume.name == ""
        assert resume.email == ""
        assert resume.phone == ""
        assert resume.education == []
        assert resume.work_history == []
        assert resume.skills == []
        assert resume.certifications == []
        assert resume.demographic_info == {}
        assert resume.score == 0
        assert resume.status == "Not Evaluated"
        assert resume.reasons == []

class TestScreeningCriteria:
    """Test cases for ScreeningCriteria class."""
    
    def test_criteria_initialization(self):
        """Test that ScreeningCriteria initializes correctly."""
        criteria = ScreeningCriteria()
        
        assert criteria.required_skills == ["Python", "Java", "SQL", "Docker", "Kubernetes"]
        assert criteria.min_experience_years == 3
        assert criteria.preferred_institutions == [
            "Stanford University", "MIT", "Harvard University", 
            "University of California, Berkeley", "Carnegie Mellon University"
        ]
        assert criteria.min_experience_years == 3
        assert criteria.max_experience_years == 50  # Default value

class TestResumeScreeningSystem:
    """Test cases for ResumeScreeningSystem class."""
    
    def test_system_initialization(self):
        """Test that ScreeningSystem initializes correctly."""
        system = ResumeScreeningSystem()
        
        assert system.resumes == []
        assert system.criteria is not None
    
    def test_add_resume(self):
        """Test adding a resume to the system."""
        system = ResumeScreeningSystem()
        resume = Resume(
            name="Test User",
            email="test@example.com",
            phone="123-456-7890",
            education=[],
            work_history=[],
            skills=[],
            certifications=[],
            demographic_info={}
        )
        
        system.add_resume(resume)
        assert len(system.resumes) == 1
        assert system.resumes[0] == resume
    
    def test_add_multiple_resumes(self):
        """Test adding multiple resumes to the system."""
        system = ResumeScreeningSystem()
        resume1 = Resume(name="User 1", email="user1@example.com", phone="", education=[], work_history=[], skills=[], certifications=[], demographic_info={})
        resume2 = Resume(name="User 2", email="user2@example.com", phone="", education=[], work_history=[], skills=[], certifications=[], demographic_info={})
        
        system.add_resume(resume1)
        system.add_resume(resume2)
        
        assert len(system.resumes) == 2
        assert system.resumes[0] == resume1
        assert system.resumes[1] == resume2
    
    def test_screen_single_resume(self):
        """Test screening a single resume."""
        system = ResumeScreeningSystem()
        resume = Resume(
            name="Test User",
            email="test@example.com",
            phone="123-456-7890",
            education=[{"degree": "B.S.", "institution": "Stanford University"}],
            work_history=[{"title": "Developer", "company": "Test Corp", "start_date": "2020-01-01", "end_date": "2023-01-01"}],
            skills=["Python", "Java", "SQL", "Docker", "Kubernetes"],
            certifications=["AWS Certified Solutions Architect"],
            demographic_info={"age": 30, "location": "NYC"}
        )
        
        system.add_resume(resume)
        results = system.screen_all_resumes()
        
        assert len(results) == 1
        assert results[0]['name'] == "Test User"
        assert results[0]['email'] == "test@example.com"
        assert results[0]['score'] >= 0  # Score should be non-negative
        assert results[0]['status'] in ["Advanced to Interview", "Consider for Interview", "Not Advanced"]
    
    def test_screen_multiple_resumes(self):
        """Test screening multiple resumes."""
        system = ResumeScreeningSystem()
        resumes = create_sample_data()
        
        for resume in resumes:
            system.add_resume(resume)
        
        results = system.screen_all_resumes()
        
        assert len(results) == len(resumes)
        for result in results:
            assert result['name'] in [r.name for r in resumes]
            assert result['score'] >= 0
            assert result['status'] in ["Advanced to Interview", "Consider for Interview", "Not Advanced"]
    
    def test_empty_resumes_list(self):
        """Test screening with empty resumes list."""
        system = ResumeScreeningSystem()
        results = system.screen_all_resumes()
        
        assert len(results) == 0
    
    def test_generate_report_empty(self):
        """Test generating report with no resumes."""
        system = ResumeScreeningSystem()
        report = system.generate_report()
        
        assert "Advanced to Interview: 0" in report
        assert "Consider for Interview: 0" in report
        assert "Not Advanced: 0" in report
        assert "DETAILED RESULTS" in report
    
    def test_generate_report_with_resumes(self):
        """Test generating report with resumes."""
        system = ResumeScreeningSystem()
        resumes = create_sample_data()
        
        for resume in resumes:
            system.add_resume(resume)
        
        system.screen_all_resumes()
        report = system.generate_report()
        
        assert "Advanced to Interview:" in report
        assert "Consider for Interview:" in report
        assert "Not Advanced:" in report
        assert "DETAILED RESULTS" in report
        for resume in resumes:
            assert resume.name in report
            assert resume.email in report

class TestEvaluationLogic:
    """Test cases for the evaluation logic."""
    
    def test_education_evaluation(self):
        """Test education evaluation logic."""
        system = ResumeScreeningSystem()
        
        # Test resume with preferred institution
        resume1 = Resume(
            name="Test User 1",
            email="test1@example.com",
            phone="123-456-7890",
            education=[{"degree": "B.S.", "institution": "Stanford University"}],
            work_history=[{"title": "Developer", "company": "Test Corp", "start_date": "2020-01-01", "end_date": "2023-01-01"}],
            skills=["Python", "Java", "SQL", "Docker", "Kubernetes"],
            certifications=["AWS Certified Solutions Architect"],
            demographic_info={"age": 30, "location": "NYC"}
        )
        
        system.add_resume(resume1)
        results = system.screen_all_resumes()
        
        assert len(results) == 1
        # Should have some score due to preferred institution
    
    def test_experience_evaluation(self):
        """Test experience evaluation logic."""
        system = ResumeScreeningSystem()
        
        # Test resume with sufficient experience
        resume1 = Resume(
            name="Test User 1",
            email="test1@example.com",
            phone="123-456-7890",
            education=[{"degree": "B.S.", "institution": "Test University"}],
            work_history=[
                {"title": "Developer", "company": "Test Corp", "start_date": "2020-01-01", "end_date": "2023-01-01"},
                {"title": "Senior Developer", "company": "Test Corp", "start_date": "2023-01-01", "end_date": "2024-01-01"}
            ],
            skills=["Python", "Java", "SQL", "Docker", "Kubernetes"],
            certifications=["AWS Certified Solutions Architect"],
            demographic_info={"age": 30, "location": "NYC"}
        )
        
        system.add_resume(resume1)
        results = system.screen_all_resumes()
        
        assert len(results) == 1
        assert results[0]['score'] >= 0
    
    def test_skill_evaluation(self):
        """Test skill evaluation logic."""
        system = ResumeScreeningSystem()
        
        # Test resume with all required skills
        resume1 = Resume(
            name="Test User 1",
            email="test1@example.com",
            phone="123-456-7890",
            education=[{"degree": "B.S.", "institution": "Test University"}],
            work_history=[{"title": "Developer", "company": "Test Corp", "start_date": "2020-01-01", "end_date": "2023-01-01"}],
            skills=["Python", "Java", "SQL", "Docker", "Kubernetes"],
            certifications=["AWS Certified Solutions Architect"],
            demographic_info={"age": 30, "location": "NYC"}
        )
        
        system.add_resume(resume1)
        results = system.screen_all_resumes()
        
        assert len(results) == 1
        assert results[0]['score'] >= 0
    
    def test_certification_evaluation(self):
        """Test certification evaluation logic."""
        system = ResumeScreeningSystem()
        
        # Test resume with required certifications
        resume1 = Resume(
            name="Test User 1",
            email="test1@example.com",
            phone="123-456-7890",
            education=[{"degree": "B.S.", "institution": "Test University"}],
            work_history=[{"title": "Developer", "company": "Test Corp", "start_date": "2020-01-01", "end_date": "2023-01-01"}],
            skills=["Python", "Java", "SQL", "Docker", "Kubernetes"],
            certifications=["AWS Certified Solutions Architect", "Google Cloud Professional"],
            demographic_info={"age": 30, "location": "NYC"}
        )
        
        system.add_resume(resume1)
        results = system.screen_all_resumes()
        
        assert len(results) == 1
        assert results[0]['score'] >= 0

class TestEdgeCases:
    """Test edge cases and boundary conditions."""
    
    def test_resume_with_no_education(self):
        """Test resume with no education."""
        system = ResumeScreeningSystem()
        resume = Resume(
            name="Test User",
            email="test@example.com",
            phone="123-456-7890",
            education=[],
            work_history=[{"title": "Developer", "company": "Test Corp", "start_date": "2020-01-01", "end_date": "2023-01-01"}],
            skills=["Python", "Java", "SQL", "Docker", "Kubernetes"],
            certifications=["AWS Certified Solutions Architect"],
            demographic_info={"age": 30, "location": "NYC"}
        )
        
        system.add_resume(resume)
        results = system.screen_all_resumes()
        
        assert len(results) == 1
        assert results[0]['score'] >= 0
    
    def test_resume_with_no_experience(self):
        """Test resume with no experience."""
        system = ResumeScreeningSystem()
        resume = Resume(
            name="Test User",
            email="test@example.com",
            phone="123-456-7890",
            education=[{"degree": "B.S.", "institution": "Test University"}],
            work_history=[],
            skills=["Python", "Java", "SQL", "Docker", "Kubernetes"],
            certifications=["AWS Certified Solutions Architect"],
            demographic_info={"age": 30, "location": "NYC"}
        )
        
        system.add_resume(resume)
        results = system.screen_all_resumes()
        
        assert len(results) == 1
        assert results[0]['score'] >= 0
    
    def test_resume_with_insufficient_skills(self):
        """Test resume with insufficient skills."""
        system = ResumeScreeningSystem()
        resume = Resume(
            name="Test User",
            email="test@example.com",
            phone="123-456-7890",
            education=[{"degree": "B.S.", "institution": "Test University"}],
            work_history=[{"title": "Developer", "company": "Test Corp", "start_date": "2020-01-01", "end_date": "2023-01-01"}],
            skills=["Python"],
            certifications=["AWS Certified Solutions Architect"],
            demographic_info={"age": 30, "location": "NYC"}
        )
        
        system.add_resume(resume)
        results = system.screen_all_resumes()
        
        assert len(results) == 1
        assert results[0]['score'] >= 0
    
    def test_resume_with_no_certifications(self):
        """Test resume with no certifications."""
        system = ResumeScreeningSystem()
        resume = Resume(
            name="Test User",
            email="test@example.com",
            phone="123-456-7890",
            education=[{"degree": "B.S.", "institution": "Test University"}],
            work_history=[{"title": "Developer", "company": "Test Corp", "start_date": "2020-01-01", "end_date": "2023-01-01"}],
            skills=["Python", "Java", "SQL", "Docker", "Kubernetes"],
            certifications=[],
            demographic_info={"age": 30, "location": "NYC"}
        )
        
        system.add_resume(resume)
        results = system.screen_all_resumes()
        
        assert len(results) == 1
        assert results[0]['score'] >= 0
    
    def test_resume_with_incorrect_dates(self):
        """Test resume with incorrect dates."""
        system = ResumeScreeningSystem()
        resume = Resume(
            name="Test User",
            email="test@example.com",
            phone="123-456-7890",
            education=[{"degree": "B.S.", "institution": "Test University"}],
            work_history=[{"title": "Developer", "company": "Test Corp", "start_date": "2025-01-01", "end_date": "2023-01-01"}],
            skills=["Python", "Java", "SQL", "Docker", "Kubernetes"],
            certifications=["AWS Certified Solutions Architect"],
            demographic_info={"age": 30, "location": "NYC"}
        )
        
        system.add_resume(resume)
        results = system.screen_all_resumes()
        
        assert len(results) == 1
        assert results[0]['score'] >= 0

class TestCreateSampleData:
    """Test sample data creation."""
    
    def test_create_sample_data(self):
        """Test that sample data is created correctly."""
        system = ResumeScreeningSystem()
        resumes = create_sample_data()
        
        assert len(resumes) > 0
        for resume in resumes:
            assert resume.name is not None
            assert resume.email is not None
            assert resume.phone is not None
            assert resume.education is not None
            assert resume.work_history is not None
            assert resume.skills is not None
            assert resume.certifications is not None
            assert resume.demographic_info is not None

def create_sample_data():
    """Helper function to create sample data for testing."""
    # This is a simplified version of the sample data creation
    # In a real test, this would be imported from the actual module
    return [
        Resume(
            name="John Doe",
            email="john.doe@example.com",
            phone="123-456-7890",
            education=[{"degree": "B.S.", "institution": "Stanford University"}],
            work_history=[{"title": "Software Engineer", "company": "Tech Corp", "start_date": "2020-01-01", "end_date": "2023-01-01"}],
            skills=["Python", "Java", "SQL", "Docker", "Kubernetes"],
            certifications=["AWS Certified Solutions Architect"],
            demographic_info={"age": 30, "location": "NYC"}
        ),
        Resume(
            name="Jane Smith",
            email="jane.smith@example.com",
            phone="123-456-7891",
            education=[{"degree": "M.S.", "institution": "MIT"}],
            work_history=[{"title": "Senior Developer", "company": "Innovate Inc", "start_date": "2019-01-01", "end_date": "2023-01-01"}],
            skills=["Python", "JavaScript", "React", "Node.js", "MongoDB"],
            certifications=["Google Cloud Professional", "Azure Developer"],
            demographic_info={"age": 32, "location": "SF"}
        )
    ]

if __name__ == "__main__":
    # Run the tests
    import pytest
    pytest.main([__file__])