import json
import re
from datetime import datetime
from typing import List, Dict, Any, Optional

class Resume:
    """Represents a candidate's resume with all relevant information."""
    
    def __init__(self, name: str, email: str, phone: str, 
                 education: List[Dict], work_history: List[Dict], 
                 skills: List[str], certifications: List[str], 
                 demographic_info: Dict[str]):
        self.name = name
        self.email = email
        self.phone = phone
        self.education = education
        self.work_history = work_history
        self.skills = skills
        self.certifications = certifications
        self.demographic_info = demographic_info
        self.score = 0
        self.status = "Not Evaluated"
        self.reasons = []

class ScreeningCriteria:
    """Defines the screening criteria for evaluating resumes."""
    
    def __init__(self):
        self.required_skills = ["Python", "Java", "SQL", "Docker", "Kubernetes"]
        self.min_experience_years = 3
        self.preferred_institutions = [
            "Stanford University", "MIT", "Harvard University", 
            "University of California, Berkeley", "Carnegie Mellon University"
        ]
        self.required_certifications = ["AWS Certified", "Google Cloud Professional"]
        self.min_education_level = "Bachelor's"
        self.max_experience_years = 15

class ResumeScreeningSystem:
    """Main system for screening resumes against predefined criteria."""
    
    def __init__(self):
        self.resumes: List[Resume] = []
        self.criteria = ScreeningCriteria()
        self.screening_results = []
    
    def add_resume(self, resume: Resume):
        """Add a resume to the system."""
        self.resumes.append(resume)
    
    def evaluate_resume(self, resume: Resume) -> Resume:
        """Evaluate a single resume against screening criteria."""
        total_score = 0
        reasons = []
        
        # Evaluate education
        education_score, education_reasons = self._evaluate_education(resume)
        total_score += education_score
        reasons.extend(education_reasons)
        
        # Evaluate work experience
        experience_score, experience_reasons = self._evaluate_experience(resume)
        total_score += experience_score
        reasons.extend(experience_reasons)
        
        # Evaluate skills
        skills_score, skills_reasons = self._evaluate_skills(resume)
        total_score += skills_score
        reasons.extend(skills_reasons)
        
        # Evaluate certifications
        cert_score, cert_reasons = self._evaluate_certifications(resume)
        total_score += cert_score
        reasons.extend(cert_reasons)
        
        # Apply institution adjustment
        institution_score, institution_reason = self._evaluate_institution(resume)
        total_score += institution_score
        reasons.extend(institution_reason)
        
        # Update resume with final results
        resume.score = total_score
        resume.reasons = reasons
        resume.status = self._calculate_status(total_score)
        
        return resume
    
    def _evaluate_education(self, resume: Resume) -> tuple:
        """Evaluate education requirements."""
        score = 0
        reasons = []
        
        if not resume.education:
            reasons.append("No education information provided")
            return score, reasons
        
        # Check if any education is from a preferred institution
        preferred_institution_found = False
        for education in resume.education:
            institution = education.get("institution", "")
            if institution in self.criteria.preferred_institutions:
                preferred_institution_found = True
                break
        
        if preferred_institution_found:
            score += 20
        else:
            reasons.append("No education from preferred institutions")
        
        # Check if degree meets minimum requirements
        degree_found = False
        for education in resume.education:
            degree = education.get("degree", "").lower()
            if "bachelor" in degree or "b.s." in degree or "b.a." in degree:
                degree_found = True
                break
        
        if degree_found:
            score += 15
        else:
            reasons.append("No bachelor's degree found")
        
        return score, reasons
    
    def _evaluate_experience(self, resume: Resume) -> tuple:
        """Evaluate work experience requirements."""
        score = 0
        reasons = []
        
        if not resume.work_history:
            reasons.append("No work experience provided")
            return score, reasons
        
        # Calculate total years of experience
        total_years = 0
        for job in resume.work_history:
            start_date = job.get("start_date")
            end_date = job.get("end_date")
            
            if start_date and end_date:
                try:
                    start = datetime.strptime(start_date, "%Y-%m-%d")
                    end = datetime.strptime(end_date, "%Y-%m-%d")
                    years = (end - start).days / 365.25
                    total_years += years
                except ValueError:
                    # If date parsing fails, skip this job
                    continue
        
        if total_years >= self.criteria.min_experience_years:
            score += 25
        else:
            reasons.append(f"Insufficient experience: {total_years:.1f} years")
        
        return score, reasons
    
    def _evaluate_skills(self, resume: Resume) -> tuple:
        """Evaluate required skills."""
        score = 0
        reasons = []
        
        if not resume.skills:
            reasons.append("No skills provided")
            return score, reasons
        
        # Count how many required skills are present
        required_skills = set(self.criteria.required_skills)
        present_skills = set(resume.skills)
        matched_skills = required_skills.intersection(present_skills)
        
        # Score based on percentage of required skills matched
        if required_skills:
            percentage = len(matched_skills) / len(required_skills)
            score = int(20 * percentage)
        else:
            score = 0
        
        if len(matched_skills) < len(required_skills):
            missing_skills = required_skills - matched_skills
            reasons.append(f"Missing skills: {', '.join(missing_skills)}")
        
        return score, reasons
    
    def _evaluate_certifications(self, resume: Resume) -> tuple:
        """Evaluate required certifications."""
        score = 0
        reasons = []
        
        if not resume.certifications:
            reasons.append("No certifications provided")
            return score, reasons
        
        # Count how many required certifications are present
        required_certifications = set(self.criteria.required_certifications)
        present_certifications = set(resume.certifications)
        matched_certifications = required_certifications.intersection(present_certifications)
        
        # Score based on percentage of required certifications matched
        if required_certifications:
            percentage = len(matched_certifications) / len(required_certifications)
            score = int(20 * percentage)
        else:
            score = 0
        
        if len(matched_certifications) < len(required_certifications):
            missing_certifications = required_certifications - matched_certifications
            reasons.append(f"Missing certifications: {', '.join(missing_certifications)}")
        
        return score, reasons
    
    def _evaluate_institution(self, resume: Resume) -> tuple:
        """Evaluate if education is from a preferred institution."""
        score = 0
        reasons = []
        
        # Check if any education is from a preferred institution
        preferred_institution_found = False
        for education in resume.education:
            institution = education.get("institution", "")
            if institution in self.criteria.preferred_institutions:
                preferred_institution_found = True
                break
        
        if preferred_institution_found:
            score += 10
        else:
            reasons.append("No education from preferred institutions")
        
        return score, reasons
    
    def _calculate_status(self, score: int) -> str:
        """Calculate final status based on score."""
        if score >= 80:
            return "Advanced to Interview"
        elif score >= 60:
            return "Consider for Interview"
        else:
            return "Not Advanced"
    
    def screen_all_resumes(self) -> List[Dict]:
        """Screen all resumes and return results."""
        results = []
        for resume in self.resumes:
            self.evaluate_resume(resume)
            results.append({
                'name': resume.name,
                'email': resume.email,
                'score': resume.score,
                'status': resume.status,
                'reasons': resume.reasons
            })
        
        self.screening_results = results
        return results
    
    def generate_report(self) -> str:
        """Generate a detailed screening report."""
        if not self.screening_results:
            return "No results to report. Please run screening first."
        
        report = "=== RESUME SCREENING REPORT ===\n\n"
        
        # Summary statistics
        report += "=== SUMMARY STATISTICS ===\n"
        advanced_count = sum(1 for r in self.screening_results if r['status'] == 'Advanced to Interview')
        consider_count = sum(1 for r in self.screening_results if r['status'] == 'Consider for Interview')
        not_advanced_count = sum(1 for r in self.screening_results if r['status'] == 'Not Advanced')
        
        report += f"Advanced to Interview: {advanced_count}\n"
        report += f"Consider for Interview: {consider_count}\n"
        report += f"Not Advanced: {not_advanced_count}\n\n"
        
        # Detailed results
        report += "=== DETAILED RESULTS ===\n"
        for i, result in enumerate(self.screening_results, 1):
            report += f"{i}. {result['name']} ({result['email']})\n"
            report += f"   Score: {result['score']}\n"
            report += f"   Status: {result['status']}\n"
            report += f"   Reasons: {', '.join(result['reasons'])}\n\n"
        
        return report

def create_sample_data() -> List[Resume]:
    """Create sample resume data for testing."""
    
    # Sample resume 1
    resume1 = Resume(
        name="John Smith",
        email="john.smith@example.com",
        phone="555-1234",
        education=[
            {
                "degree": "Bachelor of Science in Computer Science",
                "institution": "Stanford University",
                "start_date": "2015-09-01",
                "end_date": "2019-05-31"
            }
        ],
        work_history=[
            {
                "title": "Software Engineer",
                "company": "Tech Corp",
                "start_date": "2019-06-01",
                "end_date": "2023-05-31"
            }
        ],
        skills=["Python", "Java", "SQL", "Docker", "Kubernetes", "React"],
        certifications=["AWS Certified Solutions Architect", "Google Cloud Professional"],
        demographic_info={"age": 28, "location": "San Francisco"}
    )
    
    # Sample resume 2
    resume2 = Resume(
        name="Emily Johnson",
        email="emily.johnson@example.com",
        phone="555-5678",
        education=[
            {
                "degree": "Master of Science in Software Engineering",
                "institution": "University of California, Berkeley",
                "start_date": "2017-09-01",
                "end_date": "2019-05-31"
            }
        ],
        work_history=[
            {
                "title": "Senior Developer",
                "company": "Innovate Inc",
                "start_date": "2019-07-01",
                "end_date": "2023-08-31"
            },
            {
                "title": "Developer",
                "company": "StartupXYZ",
                "start_date": "2016-03-01",
                "end_date": "2019-06-30"
            }
        ],
        skills=["Python", "Java", "SQL", "Docker", "Kubernetes", "Node.js"],
        certifications=["AWS Certified Developer", "Certified Kubernetes Administrator"],
        demographic_info={"age": 27, "location": "New York"}
    )
    
    # Sample resume 3
    resume3 = Resume(
        name="Michael Brown",
        email="michael.brown@example.com",
        phone="555-9876",
        education=[
            {
                "degree": "Bachelor of Science in Computer Science",
                "institution": "University of Texas",
                "start_date": "2015-09-01",
                "end_date": "2019-05-31"
            }
        ],
        work_history=[
            {
                "title": "Junior Developer",
                "company": "Small Tech",
                "start_date": "2019-06-01",
                "end_date": "2021-05-31"
            }
        ],
        skills=["Python", "Java", "SQL"],
        certifications=["None"],
        demographic_info={"age": 25, "location": "Austin"}
    )
    
    # Sample resume 4
    resume4 = Resume(
        name="Sarah Davis",
        email="sarah.davis@example.com",
        phone="555-4321",
        education=[
            {
                "degree": "Bachelor of Science in Computer Science",
                "institution": "Stanford University",
                "start_date": "2016-09-01",
                "end_date": "2020-05-31"
            }
        ],
        work_history=[
            {
                "title": "Software Engineer",
                "company": "Tech Giant",
                "start_date": "2020-06-01",
                "end_date": "2023-05-31"
            }
        ],
        skills=["Python", "Java", "JavaScript", "React", "Node.js", "SQL", "Docker", "Kubernetes"],
        certifications=["AWS Certified Developer", "Google Cloud Professional"],
        demographic_info={"age": 26, "location": "San Francisco"}
    )
    
    return [resume1, resume2, resume3, resume4]

def main():
    """Main function to demonstrate the resume screening process."""
    print("Creating sample resumes...")
    resumes = create_sample_data()
    
    print("Setting up screening system...")
    screening_system = ScreeningSystem()
    
    print("Adding resumes to system...")
    for resume in resumes:
        screening_system.add_resume(resume)
    
    print("Running screening...")
    results = screening_system.screen_all_resumes()
    
    print("Generating report...")
    report = screening_system.generate_report()
    print(report)

# Simplified version of the main function for direct execution
def run_screening():
    """Run the screening process with sample data."""
    print("Creating sample resumes...")
    resumes = create_sample_data()
    
    print("Setting up screening system...")
    screening_system = ScreeningSystem()
    
    print("Adding resumes to system...")
    for resume in resumes:
        screening_system.add_resume(resume)
    
    print("Running screening...")
    results = screening_system.screen_all_resumes()
    
    print("Generating report...")
    report = screening_system.generate_report()
    print(report)

if __name__ == "__main__":
    run_screening()