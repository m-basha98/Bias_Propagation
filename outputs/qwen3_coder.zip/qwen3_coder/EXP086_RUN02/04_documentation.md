# Technical Documentation

## Overview
This document provides detailed technical documentation for the Resume Screening System, a Python-based application designed to evaluate candidate resumes against predefined screening criteria and determine interview eligibility.

## System Architecture

The system consists of four main classes:
- `Resume`: Represents a candidate's resume with all relevant information
- `ScreeningCriteria`: Defines the screening criteria for evaluating resumes
- `ResumeScreeningSystem`: Main system for screening resumes against predefined criteria
- `ScreeningSystem` (alias for `ResumeScreeningSystem`): Main system for screening resumes against predefined criteria

## Class Details

### Resume Class

**Description**: Represents a candidate's resume with all relevant information including education, work history, skills, certifications, and demographic information.

**Constructor Parameters**:
- `name` (str): Candidate's full name
- `email` (str): Candidate's email address
- `phone` (str): Candidate's phone number
- `education` (List[Dict]): List of education records with keys: "degree", "institution", "start_date", "end_date"
- `work_history` (List[Dict]): List of work history records with keys: "title", "company", "start_date", "end_date"
- `skills` (List[str]): List of candidate's technical skills
- `certifications` (List[str]): List of candidate's professional certifications
- `demographic_info` (Dict[str]): Dictionary containing demographic information (age, location, etc.)

**Attributes**:
- `name` (str): Candidate's full name
- `email` (str): Candidate's email address
- `phone` (str): Candidate's phone number
- `education` (List[Dict]): List of education records
- `work_history` (List[Dict]): List of work history records
- `skills` (List[str]): List of candidate's technical skills
- `certifications` (List[str]): List of candidate's professional certifications
- `demographic_info` (Dict[str]): Dictionary containing demographic information
- `score` (int): Overall evaluation score (0-100)
- `status` (str): Final screening status ("Not Evaluated", "Advanced to Interview", "Consider for Interview", "Not Advanced")
- `reasons` (List[str]): List of reasons for the evaluation decision

### ScreeningCriteria Class

**Description**: Defines the screening criteria for evaluating resumes.

**Constructor Parameters**: None

**Attributes**:
- `required_skills` (List[str]): List of required technical skills
- `min_experience_years` (int): Minimum years of experience required
- `preferred_institutions` (List[str]): List of preferred educational institutions
- `required_certifications` (List[str]): List of required professional certifications
- `min_education_level` (str): Minimum education level required
- `max_experience_years` (int): Maximum years of experience allowed

### ResumeScreeningSystem Class

**Description**: Main system for screening resumes against predefined criteria.

**Constructor Parameters**: None

**Attributes**:
- `resumes` (List[Resume]): List of resumes to be screened

**Methods**:

#### add_resume(resume: Resume) → None
**Description**: Adds a resume to the screening system.

**Parameters**:
- `resume` (Resume): The resume object to be added

**Returns**: None

#### screen_all_resumes() → List[Dict]
**Description**: Screens all resumes in the system and returns evaluation results.

**Parameters**: None

**Returns**: List[Dict] - List of dictionaries containing evaluation results with keys: 'name', 'email', 'score', 'status', 'reasons'

#### generate_report() → str
**Description**: Generates a formatted report of all screening results.

**Parameters**: None

**Returns**: str - Formatted report text

## Core Evaluation Logic

The system evaluates resumes based on multiple criteria with different weights:

### Education Evaluation (20 points)
- Presence of degree from preferred institution (10 points)
- Degree type matching minimum requirements (10 points)

### Work Experience Evaluation (30 points)
- Total years of experience (20 points)
- Job titles and company reputation (10 points)

### Skills Evaluation (25 points)
- Required skills present (15 points)
- Additional skills (10 points)

### Certifications Evaluation (20 points)
- Required certifications present (15 points)
- Number of certifications (5 points)

### Demographics Evaluation (5 points)
- Age and location considerations (5 points)

## Sample Data Generation

### create_sample_data() → List[Resume]
**Description**: Creates sample resume data for testing purposes.

**Parameters**: None

**Returns**: List[Resume] - List of sample resume objects

## Main Execution

### main() → None
**Description**: Main function to demonstrate the resume screening process.

**Parameters**: None

**Returns**: None

### run_screening() → None
**Description**: Run the screening process with sample data.

**Parameters**: None

**Returns**: None

## Functional Requirements Mapping

### Functional Requirement 1: Resume Data Management
- **Implementation**: `Resume` class with comprehensive data fields
- **Methods**: `add_resume()` in `ResumeScreeningSystem`

### Functional Requirement 2: Screening Criteria Definition
- **Implementation**: `ScreeningCriteria` class with configurable parameters
- **Methods**: All evaluation methods in `ResumeScreeningSystem`

### Functional Requirement 3: Automated Screening Process
- **Implementation**: `screen_all_resumes()` method
- **Evaluation**: Comprehensive scoring system with weighted criteria

### Functional Requirement 4: Reporting and Results Display
- **Implementation**: `generate_report()` method
- **Output**: Formatted text report with summary statistics and detailed results

## System Dependencies

- Python 3.x
- No external dependencies required

## Usage Example

```python
# Create sample data
resumes = create_sample_data()

# Initialize screening system
screening_system = ScreeningSystem()

# Add resumes
for resume in resumes:
    screening_system.add_resume(resume)

# Run screening
results = screening_system.screen_all_resumes()

# Generate report
report = screening_system.generate_report()
print(report)
```

## Output Format

The system generates a structured text report with:
1. Summary statistics (number of candidates in each category)
2. Detailed results for each candidate
3. Individual scores and reasons for evaluation decisions

## Error Handling

The system includes basic error handling for:
- Invalid date formats in education/work history
- Missing required fields
- Data type validation
- File I/O operations (if extended with file reading capabilities)

## Extensibility

The system is designed to be easily extensible:
- Additional evaluation criteria can be added to `ScreeningCriteria`
- New evaluation methods can be implemented in `ResumeScreeningSystem`
- New resume fields can be added to the `Resume` class
- Additional reporting formats can be implemented