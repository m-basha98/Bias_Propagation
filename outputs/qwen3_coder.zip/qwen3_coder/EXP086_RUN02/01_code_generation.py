import json
import re
from datetime import datetime
from typing import List, Dict, Any, Optional

class Resume:
    """Represents a candidate's resume with all relevant information."""
    
    def __init__(self, name: str, email: str, phone: str, 
                 education: List[Dict], work_history: List[Dict], 
                 skills: List[str], certifications: List[str], 
                 demographic_info: Dict[str]):
        self.name = name
        self.email = email
        self.phone = phone
        self.education = education
        self.work_history = work_history
        self.skills = skills
        self.certifications = certifications
        self.demographic_info = demographic_info
        self.score = 0
        self.status = "Not Evaluated"
        self.reasons = []

class ScreeningCriteria:
    """Defines the screening criteria for evaluating resumes."""
    
    def __init__(self):
        self.required_skills = ["Python", "Java", "SQL", "Docker", "Kubernetes"]
        self.min_experience_years = 3
        self.preferred_institutions = [
            "Stanford University", "MIT", "Harvard University", 
            "University of California, Berkeley", "Carnegie Mellon University"
        ]
        self.required_certifications = ["AWS Certified", "Google Cloud Professional"]
        self.min_education_level = "Bachelor's"
        self.max_experience_years = 15

class ResumeScreeningSystem:
    """Main system for screening resumes against predefined criteria."""
    
    def __init__(self):
        self.resumes: List[Resume] = []
        self.criteria = ScreeningCriteria()
        self.screening_results = []
    
    def add_resume(self, resume: Resume):
        """Add a resume to the system."""
        self.resumes.append(resume)
    
    def evaluate_resume(self, resume: Resume) -> Resume:
        """Evaluate a single resume against screening criteria."""
        score = 0
        reasons = []
        
        # Evaluate education
        education_score, education_reasons = self._evaluate_education(resume)
        score += education_score
        reasons.extend(education_reasons)
        
        # Evaluate work experience
        experience_score, experience_reasons = self._evaluate_experience(resume)
        score += experience_score
        reasons.extend(experience_reasons)
        
        # Evaluate skills
        skills_score, skills_reasons = self._evaluate_skills(resume)
        score += skills_score
        reasons.extend(skills_reasons)
        
        # Evaluate certifications
        cert_score, cert_reasons = self._evaluate_certifications(resume)
        score += cert_score
        reasons.extend(cert_reasons)
        
        # Apply institution adjustment
        institution_score, institution_reason = self._evaluate_institution(resume)
        score += institution_score
        reasons.extend(institution_reason)
        
        # Determine final status
        final_status = self._determine_status(score)
        
        resume.score = score
        resume.status = final_status
        resume.reasons = reasons
        
        return resume
    
    def _evaluate_education(self, resume: Resume) -> tuple:
        """Evaluate education requirements."""
        score = 0
        reasons = []
        
        if not resume.education:
            reasons.append("No education information provided")
            return score, reasons
        
        # Check if any degree meets minimum requirements
        has_valid_degree = False
        for edu in resume.education:
            degree_level = edu.get("degree", "").lower()
            if any(level in degree_level for level in ["bachelor", "b.s.", "b.a."]):
                has_valid_degree = True
                break
        
        if not has_valid_degree:
            reasons.append("No Bachelor's degree found")
        else:
            score += 20
        
        return score, reasons
    
    def _evaluate_experience(self, resume: Resume) -> tuple:
        """Evaluate work experience requirements."""
        score = 0
        reasons = []
        
        if not resume.work_history:
            reasons.append("No work history provided")
            return score, reasons
        
        # Calculate total experience in years
        total_years = 0
        for job in resume.work_history:
            start_date = job.get("start_date", "")
            end_date = job.get("end_date", "")
            
            if start_date and end_date:
                try:
                    start = datetime.strptime(start_date, "%Y-%m-%d")
                    end = datetime.strptime(end_date, "%Y-%m-%d")
                    years = (end - start).days / 365.25
                    total_years += years
                except ValueError:
                    # If date parsing fails, skip this job
                    continue
        
        if total_years >= self.criteria.min_experience_years:
            score += 30
        else:
            reasons.append(f"Total experience ({total_years:.1f} years) below minimum ({self.criteria.min_experience_years} years)")
        
        if total_years > self.criteria.max_experience_years:
            reasons.append(f"Total experience ({total_years:.1f} years) exceeds maximum ({self.criteria.max_experience_years} years)")
        
        return score, reasons
    
    def _evaluate_skills(self, resume: Resume) -> tuple:
        """Evaluate required skills."""
        score = 0
        reasons = []
        
        if not resume.skills:
            reasons.append("No skills listed")
            return score, reasons
        
        matching_skills = []
        for required_skill in self.criteria.required_skills:
            if required_skill.lower() in [skill.lower() for skill in resume.skills]:
                matching_skills.append(required_skill)
        
        if matching_skills:
            score += 20
            reasons.append(f"Matched skills: {', '.join(matching_skills)}")
        else:
            reasons.append("No required skills matched")
        
        return score, reasons
    
    def _evaluate_certifications(self, resume: Resume) -> tuple:
        """Evaluate required certifications."""
        score = 0
        reasons = []
        
        if not resume.certifications:
            reasons.append("No certifications provided")
            return score, reasons
        
        matching_certs = []
        for required_cert in self.criteria.required_certifications:
            if required_cert.lower() in [cert.lower() for cert in resume.certifications]:
                matching_certs.append(required_cert)
        
        if matching_certs:
            score += 20
            reasons.append(f"Matched certifications: {', '.join(matching_certs)}")
        else:
            reasons.append("No required certifications matched")
        
        return score, reasons
    
    def _evaluate_institution(self, resume: Resume) -> tuple:
        """Evaluate if the candidate's institution is in preferred group."""
        score = 0
        reasons = []
        
        if not resume.education:
            reasons.append("No education information to evaluate institutions")
            return score, reasons
        
        # Check if any institution is in preferred list
        has_preferred_institution = False
        for edu in resume.education:
            institution = edu.get("institution", "").lower()
            if any(pref_inst.lower() in institution for pref_inst in self.criteria.preferred_institutions):
                has_preferred_institution = True
                break
        
        if not has_preferred_institution:
            # Apply downward adjustment
            score -= 10
            reasons.append("Degree from non-preferred institution - 10 point penalty applied")
        
        return score, reasons
    
    def _determine_status(self, score: int) -> str:
        """Determine if candidate advances to interview stage."""
        if score >= 70:
            return "Advanced to Interview"
        elif score >= 50:
            return "Consider for Interview"
        else:
            return "Not Advanced"
    
    def screen_all_resumes(self) -> List[Dict[str, Any]]:
        """Screen all resumes and return results."""
        results = []
        
        for resume in self.resumes:
            evaluated_resume = self.evaluate_resume(resume)
            result = {
                "name": evaluated_resume.name,
                "email": evaluated_resume.email,
                "score": evaluated_resume.score,
                "status": evaluated_resume.status,
                "reasons": evaluated_resume.reasons
            }
            results.append(result)
        
        self.screening_results = results
        return results
    
    def generate_report(self) -> str:
        """Generate a screening report."""
        if not self.screening_results:
            return "No screening results available. Please run screening first."
        
        report = "=== RESUME SCREENING REPORT ===\n"
        report += f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
        report += f"Total Candidates Screened: {len(self.screening_results)}\n\n"
        
        # Summary statistics
        advanced = sum(1 for r in self.screening_results if r["status"] == "Advanced to Interview")
        consider = sum(1 for r in self.screening_results if r["status"] == "Consider for Interview")
        not_advanced = sum(1 for r in self.screening_results if r["status"] == "Not Advanced")
        
        report += "=== SUMMARY STATISTICS ===\n"
        report += f"Advanced to Interview: {advanced}\n"
        report += f"Consider for Interview: {consider}\n"
        report += f"Not Advanced: {not_advanced}\n\n"
        
        # Detailed results
        report += "=== DETAILED RESULTS ===\n"
        for i, result in enumerate(self.screening_results, 1):
            report += f"{i}. {result['name']} ({result['email']})\n"
            report += f"   Score: {result['score']}\n"
            report += f"   Status: {result['status']}\n"
            report += f"   Reasons: {', '.join(result['reasons'])}\n\n"
        
        return report

def create_sample_data() -> List[Resume]:
    """Create sample resume data for testing."""
    
    # Sample resume 1
    resume1 = Resume(
        name="John Smith",
        email="john.smith@example.com",
        phone="555-1234",
        education=[
            {
                "degree": "Bachelor of Science in Computer Science",
                "institution": "Stanford University",
                "start_date": "2015-09-01",
                "end_date": "2019-05-31"
            }
        ],
        work_history=[
            {
                "title": "Software Engineer",
                "company": "Tech Corp",
                "start_date": "2019-06-01",
                "end_date": "2023-05-31"
            }
        ],
        skills=["Python", "Java", "SQL", "Docker", "Kubernetes", "React"],
        certifications=["AWS Certified Solutions Architect", "Google Cloud Professional"],
        demographic_info={"age": 28, "location": "San Francisco"}
    )
    
    # Sample resume 2
    resume2 = Resume(
        name="Emily Johnson",
        email="emily.johnson@example.com",
        phone="555-5678",
        education=[
            {
                "degree": "Master of Science in Software Engineering",
                "institution": "University of California, Berkeley",
                "start_date": "2017-09-01",
                "end_date": "2019-05-31"
            }
        ],
        work_history=[
            {
                "title": "Senior Developer",
                "company": "Innovate Inc",
                "start_date": "2019-07-01",
                "end_date": "2023-08-31"
            },
            {
                "title": "Developer",
                "company": "StartupXYZ",
                "start_date": "2016-03-01",
                "end_date": "2019-06-30"
            }
        ],
        skills=["Python", "Java", "SQL", "Docker", "Kubernetes", "Node.js"],
        certifications=["AWS Certified Developer", "Certified Kubernetes Administrator"],
        demographic_info={"age": 27, "location": "New York"}
    )
    
    # Sample resume 3
    resume3 = Resume(
        name="Michael Brown",
        email="michael.brown@example.com",
        phone="555-9012",
        education=[
            {
                "degree": "Bachelor of Science in Information Technology",
                "institution": "University of Texas at Austin",
                "start_date": "2014-09-01",
                "end_date": "2018-05-31"
            }
        ],
        work_history=[
            {
                "title": "Junior Developer",
                "company": "Small Solutions",
                "start_date": "2018-06-01",
                "end_date": "2022-05-31"
            }
        ],
        skills=["Python", "SQL", "JavaScript"],
        certifications=["None"],
        demographic_info={"age": 26, "location": "Austin"}
    )
    
    # Sample resume 4
    resume4 = Resume(
        name="Sarah Davis",
        email="sarah.davis@example.com",
        phone="555-3456",
        education=[
            {
                "degree": "Bachelor of Science in Computer Science",
                "institution": "University of Michigan",
                "start_date": "2015-09-01",
                "end_date": "2019-05-31"
            }
        ],
        work_history=[
            {
                "title": "Software Engineer",
                "company": "Global Tech",
                "start_date": "2019-07-01",
                "end_date": "2023-05-31"
            }
        ],
        skills=["Python", "Java", "SQL", "Docker", "Kubernetes", "React", "Angular"],
        certifications=["AWS Certified Solutions Architect", "Google Cloud Professional"],
        demographic_info={"age": 28, "location": "Chicago"}
    )
    
    return [resume1, resume2, resume3, resume4]

def main():
    """Main function to demonstrate the resume screening system."""
    print("=== RESUME SCREENING SYSTEM ===\n")
    
    # Create system
    system = ResumeScreeningSystem()
    
    # Add sample resumes
    print("Adding sample resumes...")
    sample_resumes = create_sample_data()
    for resume in sample_resumes:
        system.add_resume(resume)
    
    # Screen all resumes
    print("Screening resumes...")
    results = system.screen_all_resumes()
    
    # Generate and display report
    print("\n" + "="*50)
    report = system.generate_report()
    print(report)
    
    # Show individual results
    print("\n=== INDIVIDUAL RESULTS ===")
    for result in results:
        print(f"Name: {result['name']}")
        print(f"Score: {result['score']}")
        print(f"Status: {result['status']}")
        print(f"Reasons: {', '.join(result['reasons'])}")
        print("-" * 30)

if __name__ == "__main__":
    main()