# University Admissions System - Technical Documentation

## Overview
The University Admissions System is a Python-based application designed to process applicant data, compute holistic admission scores, make automated admission decisions, and generate comprehensive summary reports. The system operates entirely in-memory without requiring external databases or services.

## Architecture

### Core Components
1. **Applicant Data Class**: Represents individual applicant information
2. **AdmissionResult Data Class**: Stores admission decision outcomes
3. **UniversityAdmissionsSystem Class**: Main system controller managing all operations

## Class Definitions

### Applicant Data Class
```python
@dataclass
class Applicant:
    """Data class to represent an applicant"""
    id: str
    name: str
    gpa: float
    sat_score: int
    act_score: int
    ethnicity: str
    gender: str
    state: str
    is_first_generation: bool
    has_financial_need: bool
    extracurriculars: List[str]
    essays: List[str]
```

**Attributes:**
- `id` (str): Unique identifier for the applicant
- `name` (str): Full name of the applicant
- `gpa` (float): Grade Point Average (0.0-4.0 scale)
- `sat_score` (int): SAT test score (0-1600 scale)
- `act_score` (int): ACT test score (0-36 scale)
- `ethnicity` (str): Applicant's ethnic background
- `gender` (str): Applicant's gender
- `state` (str): State of residence
- `is_first_generation` (bool): Whether applicant is first generation college student
- `has_financial_need` (bool): Whether applicant demonstrates financial need
- `extracurriculars` (List[str]): List of extracurricular activities
- `essays` (List[str]): List of essay submissions

### AdmissionResult Data Class
```python
@dataclass
class AdmissionResult:
    """Data class to represent admission decision for an applicant"""
    applicant_id: str
    name: str
    holistic_score: float
    decision: str  # "Admit", "Waitlist", "Reject"
    reasons: List[str]
```

**Attributes:**
- `applicant_id` (str): Reference to the applicant's unique ID
- `name` (str): Applicant's name
- `holistic_score` (float): Computed holistic admission score (0.0-1.0)
- `decision` (str): Admission decision ("Admit", "Waitlist", "Reject")
- `reasons` (List[str]): List of reasons supporting the admission decision

## Main System Class

### UniversityAdmissionsSystem Class

#### Constructor
```python
def __init__(self):
```

**Description:** Initializes the admissions system with empty applicant and results lists, and sets default scoring weights.

**Parameters:** None

**Returns:** None

#### Public Methods

##### `add_applicant(applicant: Applicant)`
**Description:** Adds an applicant to the system's applicant list for processing.

**Parameters:**
- `applicant` (Applicant): The applicant object to be added

**Returns:** None

**Example:**
```python
system.add_applicant(applicant)
```

##### `process_all_applicants()`
**Description:** Processes all applicants in the system, computes their holistic scores, and makes admission decisions.

**Parameters:** None

**Returns:** None

**Example:**
```python
system.process_all_applicants()
```

##### `generate_summary_report() -> Dict[str, Any]`
**Description:** Generates a comprehensive summary report of cohort statistics including scores, decisions, and system parameters.

**Parameters:** None

**Returns:** 
- `Dict[str, Any]`: Dictionary containing:
  - `generated_at` (str): ISO formatted timestamp of report generation
  - `total_applicants` (int): Total number of processed applicants
  - `average_holistic_score` (float): Average holistic score of cohort
  - `median_holistic_score` (float): Median holistic score of cohort
  - `standard_deviation` (float): Standard deviation of scores
  - `decision_distribution` (Dict[str, int]): Count of each decision type
  - `score_ranges` (Dict[str, int]): Count of applicants in score ranges
  - `weighting_system` (Dict[str, float]): Scoring weights used
  - `decision_criteria` (Dict[str, float]): Thresholds for admission decisions

**Example:**
```python
report = system.generate_summary_report()
```

##### `export_results(filename: str)`
**Description:** Exports all admission results to a JSON file for external use.

**Parameters:**
- `filename` (str): Path and name of the output JSON file

**Returns:** None

**Example:**
```python
system.export_results("admission_results.json")
```

##### `display_summary_report()`
**Description:** Displays the summary report in a formatted, human-readable way to console.

**Parameters:** None

**Returns:** None

**Example:**
```python
system.display_summary_report()
```

##### `display_individual_results()`
**Description:** Displays individual applicant results with their holistic scores and decision reasons.

**Parameters:** None

**Returns:** None

**Example:**
```python
system.display_individual_results()
```

#### Private Methods

##### `_normalize_gpa(gpa: float) -> float`
**Description:** Normalizes GPA from 0-4.0 scale to 0-1.0 scale.

**Parameters:**
- `gpa` (float): Applicant's GPA on 4.0 scale

**Returns:** 
- `float`: Normalized GPA value between 0.0 and 1.0

**Example:**
```python
normalized_gpa = self._normalize_gpa(3.8)
```

##### `_normalize_test_score(score: int, max_score: int = 1600) -> float`
**Description:** Normalizes test scores to 0-1.0 scale.

**Parameters:**
- `score` (int): Raw test score
- `max_score` (int, optional): Maximum possible score (default: 1600 for SAT)

**Returns:** 
- `float`: Normalized score value between 0.0 and 1.0

**Example:**
```python
normalized_sat = self._normalize_test_score(1520, 1600)
```

##### `_compute_holistic_score(applicant: Applicant) -> float`
**Description:** Computes the holistic admission score for an applicant based on weighted factors.

**Parameters:**
- `applicant` (Applicant): The applicant object to score

**Returns:** 
- `float`: Holistic score between 0.0 and 1.0

**Example:**
```python
score = self._compute_holistic_score(applicant)
```

##### `_make_admission_decision(holistic_score: float) -> str`
**Description:** Makes admission decision based on holistic score thresholds.

**Parameters:**
- `holistic_score` (float): The computed holistic score

**Returns:** 
- `str`: Admission decision ("Admit", "Waitlist", or "Reject")

**Example:**
```python
decision = self._make_admission_decision(0.85)
```

## Scoring Algorithm

The system uses a weighted scoring algorithm that considers:
1. Academic performance (GPA and standardized test scores)
2. Demographic factors (first-generation status, financial need)
3. Extracurricular involvement
4. Essay quality (indirectly through essay count)

**Default Weights:**
- GPA: 30%
- SAT/ACT scores: 30%
- First-generation status: 10%
- Financial need: 10%
- Extracurricular activities: 20%

## Usage Example

```python
# Create system instance
system = UniversityAdmissionsSystem()

# Add applicants
system.add_applicant(applicant1)
system.add_applicant(applicant2)

# Process all applicants
system.process_all_applicants()

# Display results
system.display_summary_report()
system.display_individual_results()

# Export results
system.export_results("results.json")
```

## System Requirements

- Python 3.7 or higher
- No external dependencies (pure Python implementation)
- In-memory operation (no database required)

## Output Format

The system generates both console output and JSON export files with structured data for easy integration with other systems.