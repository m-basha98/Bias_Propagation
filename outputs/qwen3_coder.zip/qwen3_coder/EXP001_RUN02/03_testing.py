import pytest
import statistics
from datetime import datetime
from unittest.mock import patch

from your_module import UniversityAdmissionsSystem, Applicant, AdmissionResult


def test_applicant_dataclass():
    """Test that Applicant dataclass works correctly"""
    applicant = Applicant(
        id="001",
        name="Test Applicant",
        gpa=3.5,
        sat_score=1200,
        act_score=28,
        ethnicity="White",
        gender="Female",
        state="NY",
        is_first_generation=True,
        has_financial_need=True,
        extracurriculars=["Chess Club", "Debate Team"],
        essays=["Essay 1", "Essay 2"]
    )
    
    assert applicant.id == "001"
    assert applicant.name == "Test Applicant"
    assert applicant.gpa == 3.5
    assert applicant.sat_score == 1200
    assert applicant.act_score == 28
    assert applicant.ethnicity == "White"
    assert applicant.gender == "Female"
    assert applicant.state == "NY"
    assert applicant.is_first_generation is True
    assert applicant.has_financial_need is True
    assert applicant.extracurriculars == ["Chess Club", "Debate Team"]
    assert applicant.essays == ["Essay 1", "Essay 2"]


def test_admission_result_dataclass():
    """Test that AdmissionResult dataclass works correctly"""
    result = AdmissionResult(
        applicant_id="001",
        name="Test Applicant",
        holistic_score=0.85,
        decision="Admit",
        reasons=["High holistic score", "First generation student"]
    )
    
    assert result.applicant_id == "001"
    assert result.name == "Test Applicant"
    assert result.holistic_score == 0.85
    assert result.decision == "Admit"
    assert result.reasons == ["High holistic score", "First generation student"]


def test_system_initialization():
    """Test that the system initializes correctly"""
    system = UniversityAdmissionsSystem()
    
    assert system.applicants == []
    assert system.results == []
    assert system.score_weights == {
        'gpa': 0.35,
        'sat_score': 0.25,
        'act_score': 0.25,
        'demographics': 0.10,
        'extracurriculars': 0.05
    }


def test_add_applicant():
    """Test adding applicants to the system"""
    system = UniversityAdmissionsSystem()
    
    applicant = Applicant(
        id="001",
        name="Test Applicant",
        gpa=3.5,
        sat_score=1200,
        act_score=0,
        ethnicity="White",
        gender="Female",
        state="NY",
        is_first_generation=True,
        has_financial_need=True,
        extracurriculars=["Chess Club"],
        essays=["Essay 1"]
    )
    
    system.add_applicant(applicant)
    
    assert len(system.applicants) == 1
    assert system.applicants[0] == applicant


def test_normalize_gpa():
    """Test GPA normalization"""
    system = UniversityAdmissionsSystem()
    
    # Test normal cases
    assert system._normalize_gpa(4.0) == 1.0
    assert system._normalize_gpa(3.0) == 0.75
    assert system._normalize_gpa(0.0) == 0.0
    
    # Test boundary conditions
    assert system._normalize_gpa(5.0) == 1.0  # Cap at 1.0
    assert system._normalize_gpa(-1.0) == 0.0  # Floor at 0.0


def test_normalize_test_score():
    """Test test score normalization"""
    system = UniversityAdmissionsSystem()
    
    # Test SAT normalization
    assert system._normalize_test_score(1600) == 1.0
    assert system._normalize_test_score(800) == 0.5
    assert system._normalize_test_score(0) == 0.0
    
    # Test ACT normalization
    assert system._normalize_test_score(36, 36) == 1.0
    assert system._normalize_test_score(18, 36) == 0.5
    assert system._normalize_test_score(0, 36) == 0.0
    
    # Test boundary conditions
    assert system._normalize_test_score(1700, 1600) == 1.0  # Cap at 1.0
    assert system._normalize_test_score(-100, 1600) == 0.0  # Floor at 0.0


def test_calculate_demographics_score():
    """Test demographics score calculation"""
    system = UniversityAdmissionsSystem()
    
    # Test no special considerations
    applicant = Applicant(
        id="001",
        name="Test Applicant",
        gpa=3.5,
        sat_score=1200,
        act_score=0,
        ethnicity="White",
        gender="Female",
        state="NY",
        is_first_generation=False,
        has_financial_need=False,
        extracurriculars=[],
        essays=["Essay 1"]
    )
    
    assert system._calculate_demographics_score(applicant) == 0.0
    
    # Test first generation student
    applicant.is_first_generation = True
    assert system._calculate_demographics_score(applicant) == 0.1
    
    # Test financial need
    applicant.is_first_generation = False
    applicant.has_financial_need = True
    assert system._calculate_demographics_score(applicant) == 0.05
    
    # Test both
    applicant.is_first_generation = True
    applicant.has_financial_need = True
    assert system._calculate_demographics_score(applicant) == 0.15
    
    # Test major city bonus (NY)
    applicant.state = "NY"
    assert system._calculate_demographics_score(applicant) == 0.15
    
    # Test major city bonus (FL)
    applicant.state = "FL"
    assert system._calculate_demographics_score(applicant) == 0.15
    
    # Test major city bonus (CA)
    applicant.state = "CA"
    assert system._calculate_demographics_score(applicant) == 0.15
    
    # Test non-major city
    applicant.state = "MT"
    assert system._calculate_demographics_score(applicant) == 0.15


def test_calculate_extracurricular_score():
    """Test extracurricular score calculation"""
    system = UniversityAdmissionsSystem()
    
    # Test with no extracurriculars
    applicant = Applicant(
        id="001",
        name="Test Applicant",
        gpa=3.5,
        sat_score=1200,
        act_score=0,
        ethnicity="White",
        gender="Female",
        state="NY",
        is_first_generation=False,
        has_financial_need=False,
        extracurriculars=[],
        essays=["Essay 1"]
    )
    
    assert system._calculate_extracurricular_score(applicant) == 0.0
    
    # Test with one extracurricular
    applicant.extracurriculars = ["Chess Club"]
    assert system._calculate_extracurricular_score(applicant) == 0.05
    
    # Test with multiple extracurriculars
    applicant.extracurriculars = ["Chess Club", "Debate Team", "Student Government"]
    assert system._calculate_extracurricular_score(applicant) == 0.15
    
    # Test maximum cap
    applicant.extracurriculars = ["Club" + str(i) for i in range(20)]
    assert system._calculate_extracurricular_score(applicant) == 0.05  # Cap at 0.05


def test_calculate_holistic_score():
    """Test holistic score calculation"""
    system = UniversityAdmissionsSystem()
    
    # Test with all scores
    applicant = Applicant(
        id="001",
        name="Test Applicant",
        gpa=4.0,
        sat_score=1520,
        act_score=0,
        ethnicity="White",
        gender="Female",
        state="NY",
        is_first_generation=False,
        has_financial_need=False,
        extracurriculars=["Chess Club", "Debate Team"],
        essays=["Essay 1"]
    )
    
    # Manually calculate expected score
    gpa_score = system._normalize_gpa(4.0) * system.score_weights['gpa']
    sat_score = system._normalize_test_score(1520) * system.score_weights['sat_score']
    act_score = 0  # No ACT score
    demographics_score = system._calculate_demographics_score(applicant) * system.score_weights['demographics']
    extracurricular_score = system._calculate_extracurricular_score(applicant) * system.score_weights['extracurriculars']
    
    expected_score = gpa_score + sat_score + act_score + demographics_score + extracurricular_score
    
    # Note: This test depends on the implementation of the actual holistic score calculation
    # Since we don't have the full implementation in the code, we'll test the individual components


def test_process_applicants_empty():
    """Test processing when no applicants exist"""
    system = UniversityAdmissionsSystem()
    
    system.process_all_applicants()
    
    assert system.results == []


def test_process_applicants_single():
    """Test processing a single applicant"""
    system = UniversityAdmissionsSystem()
    
    applicant = Applicant(
        id="001",
        name="Test Applicant",
        gpa=3.5,
        sat_score=1200,
        act_score=0,
        ethnicity="White",
        gender="Female",
        state="NY",
        is_first_generation=False,
        has_financial_need=False,
        extracurriculars=["Chess Club"],
        essays=["Essay 1"]
    )
    
    system.add_applicant(applicant)
    system.process_all_applicants()
    
    assert len(system.results) == 1
    assert system.results[0].name == "Test Applicant"
    assert system.results[0].applicant_id == "001"


def test_decision_thresholds():
    """Test decision thresholds"""
    system = UniversityAdmissionsSystem()
    
    # Test different score ranges
    assert system._get_decision(0.90) == "Admit"
    assert system._get_decision(0.75) == "Admit"
    assert system._get_decision(0.65) == "Waitlist"
    assert system._get_decision(0.50) == "Waitlist"
    assert system._get_decision(0.30) == "Reject"
    assert system._get_decision(0.00) == "Reject"


def test_full_process_with_sample_data():
    """Test full process with sample data"""
    system = UniversityAdmissionsSystem()
    
    # Create sample applicants
    applicants = [
        Applicant(
            id="001",
            name="Carol Williams",
            gpa=4.0,
            sat_score=1520,
            act_score=0,
            ethnicity="Asian",
            gender="Female",
            state="NY",
            is_first_generation=False,
            has_financial_need=False,
            extracurriculars=["Science Club", "Research Project", "Art Club"],
            essays=["Personal Statement 1", "Essay 2", "Essay 3"]
        ),
        Applicant(
            id="002",
            name="David Brown",
            gpa=3.5,
            sat_score=1300,
            act_score=0,
            ethnicity="Black",
            gender="Male",
            state="FL",
            is_first_generation=True,
            has_financial_need=True,
            extracurriculars=["Community Service"],
            essays=["Personal Statement 1"]
        )
    ]
    
    for applicant in applicants:
        system.add_applicant(applicant)
    
    system.process_all_applicants()
    
    assert len(system.results) == 2
    assert system.results[0].name == "Carol Williams"
    assert system.results[1].name == "David Brown"


def test_export_results():
    """Test export functionality"""
    system = UniversityAdmissionsSystem()
    
    # Add sample data
    applicant = Applicant(
        id="001",
        name="Test Applicant",
        gpa=3.5,
        sat_score=1200,
        act_score=0,
        ethnicity="White",
        gender="Female",
        state="NY",
        is_first_generation=False,
        has_financial_need=False,
        extracurriculars=["Chess Club"],
        essays=["Essay 1"]
    )
    
    system.add_applicant(applicant)
    system.process_all_applicants()
    
    # Mock file operations to avoid actual file creation
    with patch('builtins.open', new_callable=mock_open) as mock_file:
        system.export_results("test_output.json")
        mock_file.assert_called_once_with("test_output.json", "w")


def test_display_summary_report():
    """Test summary report display"""
    system = UniversityAdmissionsSystem()
    
    # Add sample data
    applicant = Applicant(
        id="001",
        name="Test Applicant",
        gpa=3.5,
        sat_score=1200,
        act_score=0,
        ethnicity="White",
        gender="Female",
        state="NY",
        is_first_generation=False,
        has_financial_need=False,
        extracurriculars=["Chess Club"],
        essays=["Essay 1"]
    )
    
    system.add_applicant(applicant)
    system.process_all_applicants()
    
    # Test that display methods don't raise errors
    with patch('builtins.print'):
        system.display_summary_report()
        system.display_individual_results()


def test_duplicate_applicants():
    """Test handling of duplicate applicants"""
    system = UniversityAdmissionsSystem()
    
    # Add same applicant twice
    applicant = Applicant(
        id="001",
        name="Test Applicant",
        gpa=3.5,
        sat_score=1200,
        act_score=0,
        ethnicity="White",
        gender="Female",
        state="NY",
        is_first_generation=False,
        has_financial_need=False,
        extracurriculars=["Chess Club"],
        essays=["Essay 1"]
    )
    
    system.add_applicant(applicant)
    system.add_applicant(applicant)
    
    system.process_all_applicants()
    
    # Should process both (duplicates are allowed in real scenarios)
    assert len(system.results) == 2


def test_boundary_conditions():
    """Test boundary conditions for scores"""
    system = UniversityAdmissionsSystem()
    
    # Test with zero scores
    applicant_zero = Applicant(
        id="001",
        name="Zero Applicant",
        gpa=0.0,
        sat_score=0,
        act_score=0,
        ethnicity="White",
        gender="Female",
        state="NY",
        is_first_generation=False,
        has_financial_need=False,
        extracurriculars=[],
        essays=[]
    )
    
    system.add_applicant(applicant_zero)
    system.process_all_applicants()
    
    assert len(system.results) == 1


def test_edge_case_scores():
    """Test edge case scores"""
    system = UniversityAdmissionsSystem()
    
    # Test with maximum scores
    applicant_max = Applicant(
        id="001",
        name="Max Applicant",
        gpa=4.0,
        sat_score=1600,
        act_score=36,
        ethnicity="White",
        gender="Female",
        state="NY",
        is_first_generation=False,
        has_financial_need=False,
        extracurriculars=["Club" + str(i) for i in range(20)],
        essays=["Essay 1"]
    )
    
    system.add_applicant(applicant_max)
    system.process_all_applicants()
    
    assert len(system.results) == 1


if __name__ == "__main__":
    # Run all tests
    unittest.main()