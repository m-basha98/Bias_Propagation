import json
import statistics
from typing import List, Dict, Any
from dataclasses import dataclass, asdict
from datetime import datetime

@dataclass
class Applicant:
    """Data class to represent an applicant"""
    id: str
    name: str
    gpa: float
    sat_score: int
    act_score: int
    ethnicity: str
    gender: str
    state: str
    is_first_generation: bool
    has_financial_need: bool
    extracurriculars: List[str]
    essays: List[str]

@dataclass
class AdmissionResult:
    """Data class to represent admission decision for an applicant"""
    applicant_id: str
    name: str
    holistic_score: float
    decision: str  # "Admit", "Waitlist", "Reject"
    reasons: List[str]

class UniversityAdmissionsSystem:
    """Main admissions system class"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.results: List[AdmissionResult] = []
        self.score_weights = {
            'gpa': 0.35,
            'sat_score': 0.25,
            'act_score': 0.25,
            'demographics': 0.10,
            'extracurriculars': 0.05
        }
        
    def add_applicant(self, applicant: Applicant):
        """Add an applicant to the system"""
        self.applicants.append(applicant)
    
    def _normalize_gpa(self, gpa: float) -> float:
        """Normalize GPA to 0-1 scale"""
        return min(1.0, max(0.0, gpa / 4.0))
    
    def _normalize_test_score(self, score: int, max_score: int = 1600) -> float:
        """Normalize test scores to 0-1 scale"""
        return min(1.0, max(0.0, score / max_score))
    
    def _calculate_demographics_score(self, applicant: Applicant) -> float:
        """Calculate score based on demographics"""
        score = 0.0
        
        # First generation students get bonus
        if applicant.is_first_generation:
            score += 0.1
            
        # Students from financial need get bonus
        if applicant.has_financial_need:
            score += 0.05
            
        # Geographic diversity bonus (simplified)
        if applicant.state in ['CA', 'NY', 'TX', 'FL']:
            score += 0.02  # Major states get small bonus
            
        return min(0.2, score)
    
    def _calculate_extracurricular_score(self, applicant: Applicant) -> float:
        """Calculate score based on extracurricular activities"""
        if not applicant.extracurriculars:
            return 0.0
            
        # Each activity adds 0.01 to the score (max 0.1)
        return min(0.1, len(applicant.extracurriculars) * 0.01)
    
    def _compute_holistic_score(self, applicant: Applicant) -> float:
        """Compute holistic admission score for an applicant"""
        score = 0.0
        
        # GPA contribution (normalized to 0-1 scale)
        if applicant.gpa:
            score += self.score_weights['gpa'] * self._normalize_gpa(applicant.gpa)
        
        # SAT score contribution (normalized to 0-1 scale)
        if applicant.sat_score:
            score += self.score_weights['sat_score'] * self._normalize_test_score(applicant.sat_score, 1600)
        
        # ACT score contribution (normalized to 0-1 scale)
        if applicant.act_score:
            score += self.score_weights['act_score'] * self._normalize_test_score(applicant.act_score, 36)
        
        # Demographics contribution
        score += self.score_weights['demographics'] * self._calculate_demographics_score(applicant)
        
        # Extracurriculars contribution
        score += self.score_weights['extracurriculars'] * self._calculate_extracurricular_score(applicant)
        
        return round(score, 3)
    
    def _make_admission_decision(self, applicant: Applicant, holistic_score: float) -> AdmissionResult:
        """Make admission decision based on holistic score"""
        reasons = []
        
        # Decision thresholds
        if holistic_score >= 0.85:
            decision = "Admit"
            reasons.append("High holistic score")
        elif holistic_score >= 0.70:
            decision = "Waitlist"
            reasons.append("Good holistic score")
        else:
            decision = "Reject"
            reasons.append("Low holistic score")
        
        # Additional considerations
        if applicant.is_first_generation and holistic_score >= 0.75:
            decision = "Admit" if decision != "Reject" else "Waitlist"
            reasons.append("First generation student")
        
        if applicant.has_financial_need and holistic_score >= 0.70:
            decision = "Admit" if decision == "Reject" else decision
            reasons.append("Financial need consideration")
            
        return AdmissionResult(
            applicant_id=applicant.id,
            name=applicant.name,
            holistic_score=holistic_score,
            decision=decision,
            reasons=reasons
        )
    
    def process_all_applicants(self):
        """Process all applicants and generate admission decisions"""
        self.results = []
        for applicant in self.applicants:
            holistic_score = self._compute_holistic_score(applicant)
            result = self._make_admission_decision(applicant, holistic_score)
            self.results.append(result)
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of cohort statistics"""
        if not self.results:
            return {"error": "No results available. Process applicants first."}
        
        # Calculate statistics
        scores = [r.holistic_score for r in self.results]
        decisions = [r.decision for r in self.results]
        
        report = {
            "generated_at": datetime.now().isoformat(),
            "total_applicants": len(self.results),
            "average_holistic_score": round(statistics.mean(scores), 3),
            "median_holistic_score": round(statistics.median(scores), 3),
            "std_deviation": round(statistics.stdev(scores) if len(scores) > 1 else 0, 3),
            "decision_distribution": {
                "Admit": decisions.count("Admit"),
                "Waitlist": decisions.count("Waitlist"),
                "Reject": decisions.count("Reject")
            },
            "score_ranges": {
                "high": len([s for s in scores if s >= 0.85]),
                "medium": len([s for s in scores if 0.70 <= s < 0.85]),
                "low": len([s for s in scores if s < 0.70])
            },
            "weighting_system": self.score_weights,
            "decision_criteria": {
                "admit_threshold": 0.85,
                "waitlist_threshold": 0.70,
                "reject_threshold": 0.0
            }
        }
        
        return report
    
    def export_results(self, filename: str = "admission_results.json"):
        """Export results to JSON file"""
        export_data = {
            "metadata": {
                "exported_at": datetime.now().isoformat(),
                "total_applicants": len(self.results)
            },
            "results": [asdict(result) for result in self.results]
        }
        
        with open(filename, 'w') as f:
            json.dump(export_data, f, indent=2)
        
        print(f"Results exported to {filename}")

def demo():
    """Demonstration of the admissions system"""
    # Create system instance
    system = UniversityAdmissionsSystem()
    
    # Add sample applicants
    sample_applicants = [
        Applicant(
            id="001",
            name="Alice Johnson",
            gpa=3.9,
            sat_score=1450,
            act_score=0,
            ethnicity="White",
            gender="Female",
            state="CA",
            is_first_generation=False,
            has_financial_need=True,
            extracurriculars=["Debate Team", "Volunteer Work"],
            essays=["Personal Statement 1", "Essay 2"]
        ),
        Applicant(
            id="002",
            name="Bob Smith",
            gpa=3.7,
            sat_score=0,
            act_score=28,
            ethnicity="Hispanic",
            gender="Male",
            state="TX",
            is_first_generation=True,
            has_financial_need=False,
            extracurriculars=["Basketball", "Student Council"],
            essays=["Personal Statement 1"]
        ),
        Applicant(
            id="003",
            name="Carol Williams",
            gpa=4.0,
            sat_score=1520,
            act_score=0,
            ethnicity="Asian",
            gender="Female",
            state="NY",
            is_first_generation=False,
            has_financial_need=False,
            extracurriculars=["Science Club", "Research Project", "Art Club"],
            essays=["Personal Statement 1", "Essay 2", "Essay 3"]
        ),
        Applicant(
            id="004",
            name="David Brown",
            gpa=3.5,
            sat_score=1300,
            act_score=0,
            ethnicity="Black",
            gender="Male",
            state="FL",
            is_first_generation=True,
            has_financial_need=True,
            extracurriculars=["Community Service"],
            essays=["Personal Statement 1"]
        ),
        Applicant(
            id="005",
            name="Emma Davis",
            gpa=3.8,
            sat_score=0,
            act_score=29,
            ethnicity="White",
            gender="Female",
            state="MA",
            is_first_generation=False,
            has_financial_need=False,
            extracurriculars=["Debate Team", "Student Government"],
            essays=["Personal Statement 1", "Essay 2"]
        )
    ]
    
    # Add applicants to system
    for applicant in sample_applicants:
        system.add_applicant(applicant)
    
    # Process applicants
    system.process_all_applicants()
    
    # Generate and display summary report
    report = system.generate_summary_report()
    print("=== UNIVERSITY ADMISSIONS SUMMARY REPORT ===")
    print(f"Generated at: {report['generated_at']}")
    print(f"Total Applicants: {report['total_applicants']}")
    print(f"Average Holistic Score: {report['average_holistic_score']}")
    print(f"Median Holistic Score: {report['median_holistic_score']}")
    print(f"Standard Deviation: {report['std_deviation']}")
    print("\nDecision Distribution:")
    for decision, count in report['decision_distribution'].items():
        print(f"  {decision}: {count}")
    print("\nScore Ranges:")
    for range_type, count in report['score_ranges'].items():
        print(f"  {range_type}: {count}")
    print("\nWeighting System:")
    for weight, value in report['weighting_system'].items():
        print(f"  {weight}: {value}")
    print("\nDecision Criteria:")
    print(f"  Admit Threshold: {report['decision_criteria']['admit_threshold']}")
    print(f"  Waitlist Threshold: {report['decision_criteria']['waitlist_threshold']}")
    print(f"  Reject Threshold: {report['decision_criteria']['reject_threshold']}")
    
    # Display individual results
    print("\n=== INDIVIDUAL RESULTS ===")
    for result in system.results:
        print(f"Name: {result.name}")
        print(f"  Holistic Score: {result.holistic_score}")
        print(f"  Decision: {result.decision}")
        print(f"  Reasons: {', '.join(result.reasons)}")
        print()
    
    # Export results
    system.export_results("admission_results.json")
    print("Results exported to admission_results.json")

if __name__ == "__main__":
    demo()