import pytest
from datetime import datetime
from unittest.mock import patch

from your_module import (
    Applicant, 
    Education, 
    WorkExperience, 
    Certification, 
    ResumeScreeningSystem,
    create_sample_applicants
)


class TestResumeScreeningSystem:
    """Test suite for ResumeScreeningSystem class"""
    
    @pytest.fixture
    def screening_system(self):
        """Create a fresh screening system for each test"""
        return ResumeScreeningSystem()
    
    @pytest.fixture
    def sample_applicants(self):
        """Create sample applicants for testing"""
        return create_sample_applicants()
    
    def test_initialization(self, screening_system):
        """Test that the screening system initializes correctly"""
        assert screening_system.required_skills == ['Python', 'SQL', 'Data Analysis', 'Machine Learning']
        assert screening_system.required_degrees == ['Computer Science', 'Software Engineering', 'Data Science']
        assert screening_system.preferred_institutions == ['MIT', 'Stanford', 'Harvard', 'Princeton', 'CMU']
        assert screening_system.min_experience_years == 2
        assert screening_system.min_gpa == 3.0
        assert screening_system.max_age == 35
        assert screening_system.min_years_experience == 2
        assert screening_system.screening_results == []
    
    def test_validate_email_valid(self, screening_system):
        """Test valid email validation"""
        valid_emails = [
            "test@example.com",
            "user.name@domain.co.uk",
            "user+tag@domain.org",
            "a@b.co"
        ]
        
        for email in valid_emails:
            assert screening_system.validate_email(email) is True
    
    def test_validate_email_invalid(self, screening_system):
        """Test invalid email validation"""
        invalid_emails = [
            "invalid.email",
            "@domain.com",
            "user@",
            "user@domain",
            "user..name@domain.com",
            ""
        ]
        
        for email in invalid_emails:
            assert screening_system.validate_email(email) is False
    
    def test_calculate_experience_years(self, screening_system):
        """Test experience calculation with valid dates"""
        work_history = [
            WorkExperience("Company A", "Developer", "2020-01-01", "2022-12-31", ""),
            WorkExperience("Company B", "Senior Dev", "2023-01-01", "2024-05-31", "")
        ]
        
        expected_years = 3  # (2022-2020) + (2024-2023) = 2 + 1 = 3
        assert screening_system.calculate_experience_years(work_history) == expected_years
    
    def test_calculate_experience_years_invalid_dates(self, screening_system):
        """Test experience calculation with invalid dates"""
        work_history = [
            WorkExperience("Company A", "Developer", "invalid-date", "2022-12-31", ""),
            WorkExperience("Company B", "Senior Dev", "2023-01-01", "2024-05-31", "")
        ]
        
        # Should skip invalid date and only count valid one
        expected_years = 1  # Only second job contributes
        assert screening_system.calculate_experience_years(work_history) == expected_years
    
    def test_calculate_experience_years_empty(self, screening_system):
        """Test experience calculation with empty work history"""
        work_history = []
        assert screening_system.calculate_experience_years(work_history) == 0
    
    def test_is_preferred_institution(self, screening_system):
        """Test preferred institution checking"""
        preferred_institutions = ['MIT', 'Stanford', 'Harvard']
        non_preferred_institutions = ['University of California', 'MIT East', 'Harvard Business School']
        
        # Test preferred institutions
        for institution in preferred_institutions:
            assert screening_system.is_preferred_institution(institution) is True
        
        # Test non-preferred institutions
        for institution in non_preferred_institutions:
            assert screening_system.is_preferred_institution(institution) is False
    
    def test_evaluate_resume_strong_candidate(self, screening_system):
        """Test evaluation of strong candidate"""
        applicant = create_sample_applicants()[0]  # Jane Smith
        
        result = screening_system.evaluate_resume(applicant)
        
        assert result['applicant'] == "Jane Smith"
        assert result['decision'] == "ADVANCE TO INTERVIEW"
        assert result['score'] >= 50
        assert len(result['matched_skills']) == 4  # All required skills
        assert result['total_experience'] >= 2
        assert result['highest_gpa'] >= 3.0
        assert len(result['adjustments']) == 0  # No adjustments for preferred institutions
    
    def test_evaluate_resume_weak_candidate(self, screening_system):
        """Test evaluation of weak candidate"""
        applicant = create_sample_applicants()[1]  # John Doe
        
        result = screening_system.evaluate_resume(applicant)
        
        assert result['applicant'] == "John Doe"
        assert result['decision'] == "REJECT"
        assert result['score'] < 50
        assert len(result['reasons']) > 0  # Should have reasons for rejection
        assert len(result['matched_skills']) < 4  # Missing some skills
        assert result['total_experience'] < 2  # Insufficient experience
        assert result['highest_gpa'] < 3.0  # Low GPA
    
    def test_evaluate_resume_moderate_candidate(self, screening_system):
        """Test evaluation of moderate candidate"""
        applicant = create_sample_applicants()[2]  # Robert Johnson
        
        result = screening_system.evaluate_resume(applicant)
        
        assert result['applicant'] == "Robert Johnson"
        # Decision could be either ADVANCE or REJECT depending on scoring
        assert result['score'] >= 0
        assert len(result['matched_skills']) == 4  # All required skills
        assert result['total_experience'] >= 2
        assert result['highest_gpa'] >= 3.0
    
    def test_evaluate_resume_non_preferred_institution(self, screening_system):
        """Test evaluation when degree is from non-preferred institution"""
        # Create applicant with degree from non-preferred institution
        applicant = Applicant(
            name="Test User",
            email="test@example.com",
            phone="555-1234",
            education=[
                Education("University of California", "Bachelor of Science", "Computer Science", 2018, 3.5)
            ],
            work_history=[
                WorkExperience("Company", "Developer", "2018-01-01", "2020-12-31", "")
            ],
            skills=["Python", "SQL", "Data Analysis", "Machine Learning"],
            certifications=[],
            demographic_info={"age": 25, "location": "Test City"}
        )
        
        result = screening_system.evaluate_resume(applicant)
        
        # Should have adjustments for non-preferred institution
        assert len(result['adjustments']) > 0
    
    def test_evaluate_resume_missing_required_skills(self, screening_system):
        """Test evaluation when candidate lacks required skills"""
        applicant = Applicant(
            name="Test User",
            email="test@example.com",
            phone="555-1234",
            education=[
                Education("MIT", "Bachelor of Science", "Computer Science", 2018, 3.5)
            ],
            work_history=[
                WorkExperience("Company", "Developer", "2018-01-01", "2020-12-31", "")
            ],
            skills=["HTML", "CSS", "JavaScript"],  # Missing required skills
            certifications=[],
            demographic_info={"age": 25, "location": "Test City"}
        )
        
        result = screening_system.evaluate_resume(applicant)
        
        assert len(result['matched_skills']) < 4  # Not all required skills matched
        assert result['decision'] == "REJECT"  # Should be rejected due to missing skills
    
    def test_evaluate_resume_insufficient_experience(self, screening_system):
        """Test evaluation when candidate has insufficient experience"""
        applicant = Applicant(
            name="Test User",
            email="test@example.com",
            phone="555-1234",
            education=[
                Education("MIT", "Bachelor of Science", "Computer Science", 2018, 3.5)
            ],
            work_history=[
                WorkExperience("Company", "Developer", "2020-01-01", "2020-12-31", "")
            ],
            skills=["Python", "SQL", "Data Analysis", "Machine Learning"],
            certifications=[],
            demographic_info={"age": 25, "location": "Test City"}
        )
        
        result = screening_system.evaluate_resume(applicant)
        
        assert result['total_experience'] < 2  # Less than required experience
        assert result['decision'] == "REJECT"  # Should be rejected due to experience
    
    def test_evaluate_resume_low_gpa(self, screening_system):
        """Test evaluation when candidate has low GPA"""
        applicant = Applicant(
            name="Test User",
            email="test@example.com",
            phone="555-1234",
            education=[
                Education("MIT", "Bachelor of Science", "Computer Science", 2018, 2.5)
            ],
            work_history=[
                WorkExperience("Company", "Developer", "2018-01-01", "2020-12-31", "")
            ],
            skills=["Python", "SQL", "Data Analysis", "Machine Learning"],
            certifications=[],
            demographic_info={"age": 25, "location": "Test City"}
        )
        
        result = screening_system.evaluate_resume(applicant)
        
        assert result['highest_gpa'] < 3.0  # Below minimum GPA
        assert result['decision'] == "REJECT"  # Should be rejected due to GPA
    
    def test_add_applicant(self, screening_system, sample_applicants):
        """Test adding applicant to screening system"""
        # Add one applicant
        screening_system.add_applicant(sample_applicants[0])
        
        assert len(screening_system.screening_results) == 1
        assert screening_system.screening_results[0]['applicant'] == "Jane Smith"
        
        # Add another applicant
        screening_system.add_applicant(sample_applicants[1])
        
        assert len(screening_system.screening_results) == 2
        assert screening_system.screening_results[1]['applicant'] == "John Doe"
    
    def test_generate_report(self, screening_system, sample_applicants):
        """Test report generation"""
        # Add applicants
        for applicant in sample_applicants:
            screening_system.add_applicant(applicant)
        
        report = screening_system.generate_report()
        
        assert isinstance(report, str)
        assert len(report) > 0
        # Should contain information about all applicants
        assert "Jane Smith" in report
        assert "John Doe" in report
        assert "Robert Johnson" in report
        # Should contain score information
        assert "Score:" in report
        # Should contain decision information
        assert "Decision:" in report
    
    def test_get_applicant_results(self, screening_system, sample_applicants):
        """Test retrieving applicant results"""
        # Add applicants
        for applicant in sample_applicants:
            screening_system.add_applicant(applicant)
        
        results = screening_system.get_applicant_results()
        
        assert len(results) == 3
        assert results[0]['applicant'] == "Jane Smith"
        assert results[1]['applicant'] == "John Doe"
        assert results[2]['applicant'] == "Robert Johnson"
    
    def test_edge_case_empty_applicant(self, screening_system):
        """Test evaluation with minimal applicant data"""
        applicant = Applicant(
            name="Test User",
            email="test@example.com",
            phone="555-1234",
            education=[],
            work_history=[],
            skills=[],
            certifications=[],
            demographic_info={}
        )
        
        result = screening_system.evaluate_resume(applicant)
        
        assert result['applicant'] == "Test User"
        assert result['decision'] == "REJECT"  # Should be rejected due to lack of qualifications
    
    def test_edge_case_high_gpa(self, screening_system):
        """Test evaluation with very high GPA"""
        applicant = Applicant(
            name="Test User",
            email="test@example.com",
            phone="555-1234",
            education=[
                Education("MIT", "Bachelor of Science", "Computer Science", 2018, 4.0)
            ],
            work_history=[
                WorkExperience("Company", "Developer", "2018-01-01", "2020-12-31", "")
            ],
            skills=["Python", "SQL", "Data Analysis", "Machine Learning"],
            certifications=[],
            demographic_info={"age": 25, "location": "Test City"}
        )
        
        result = screening_system.evaluate_resume(applicant)
        
        assert result['highest_gpa'] == 4.0
        assert result['decision'] == "ADVANCE TO INTERVIEW"  # Should be accepted due to high GPA
    
    def test_edge_case_old_age(self, screening_system):
        """Test evaluation with older candidate"""
        applicant = Applicant(
            name="Test User",
            email="test@example.com",
            phone="555-1234",
            education=[
                Education("MIT", "Bachelor of Science", "Computer Science", 2018, 3.5)
            ],
            work_history=[
                WorkExperience("Company", "Developer", "2018-01-01", "2020-12-31", "")
            ],
            skills=["Python", "SQL", "Data Analysis", "Machine Learning"],
            certifications=[],
            demographic_info={"age": 45, "location": "Test City"}
        )
        
        result = screening_system.evaluate_resume(applicant)
        
        assert result['decision'] == "REJECT"  # Should be rejected due to age (over 35)
    
    def test_edge_case_exactly_at_age_limit(self, screening_system):
        """Test evaluation with candidate at exact age limit"""
        applicant = Applicant(
            name="Test User",
            email="test@example.com",
            phone="555-1234",
            education=[
                Education("MIT", "Bachelor of Science", "Computer Science", 2018, 3.5)
            ],
            work_history=[
                WorkExperience("Company", "Developer", "2018-01-01", "2020-12-31", "")
            ],
            skills=["Python", "SQL", "Data Analysis", "Machine Learning"],
            certifications=[],
            demographic_info={"age": 35, "location": "Test City"}
        )
        
        result = screening_system.evaluate_resume(applicant)
        
        assert result['decision'] == "REJECT"  # Should be rejected due to age limit


class TestCreateSampleApplicants:
    """Test suite for create_sample_applicants function"""
    
    def test_create_sample_applicants(self):
        """Test that sample applicants are created correctly"""
        applicants = create_sample_applicants()
        
        assert len(applicants) == 3
        assert isinstance(applicants[0], Applicant)
        assert isinstance(applicants[1], Applicant)
        assert isinstance(applicants[2], Applicant)
        
        # Check names
        assert applicants[0].name == "Jane Smith"
        assert applicants[1].name == "John Doe"
        assert applicants[2].name == "Robert Johnson"
        
        # Check that each has required fields
        for applicant in applicants:
            assert applicant.name is not None
            assert applicant.email is not None
            assert applicant.phone is not None
            assert applicant.education is not None
            assert applicant.work_history is not None
            assert applicant.skills is not None
            assert applicant.certifications is not None
            assert applicant.demographic_info is not None


if __name__ == "__main__":
    # Run tests
    import pytest
    pytest.main([__file__])