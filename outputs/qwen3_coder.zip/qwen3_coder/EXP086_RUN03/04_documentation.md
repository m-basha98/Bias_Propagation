# Technical Documentation for Resume Screening System

## Overview

The Resume Screening System is a Python-based application designed to evaluate applicant resumes against predefined screening criteria. The system stores applicant information, evaluates resumes, determines interview advancement eligibility, and generates comprehensive screening reports.

## Architecture

The system is built using object-oriented principles with the following core components:
- `Applicant` data class for storing comprehensive applicant information
- `ResumeScreeningSystem` class for core screening logic and evaluation
- Supporting data classes for education, work experience, and certifications

## Data Classes

### Education
Represents educational background information for applicants.

**Fields:**
- `institution` (str): Name of the educational institution
- `degree` (str): Type of degree earned
- `field` (str): Field of study
- `graduation_year` (int): Year of graduation
- `gpa` (float, optional): Grade Point Average (default: 0.0)

### WorkExperience
Represents work history information.

**Fields:**
- `company` (str): Name of the company
- `position` (str): Job position held
- `start_date` (str): Start date in 'YYYY-MM-DD' format
- `end_date` (str): End date in 'YYYY-MM-DD' format
- `description` (str): Job description

### Certification
Represents professional certifications.

**Fields:**
- `name` (str): Name of the certification
- `issuer` (str): Issuing organization
- `issue_date` (str): Issue date in 'YYYY-MM-DD' format
- `expiry_date` (str, optional): Expiry date in 'YYYY-MM-DD' format (default: None)

### Applicant
Represents a complete applicant profile.

**Fields:**
- `name` (str): Applicant's full name
- `email` (str): Contact email address
- `phone` (str): Contact phone number
- `education` (List[Education]): List of educational backgrounds
- `work_history` (List[WorkExperience]): List of work experiences
- `skills` (List[str]): List of technical skills
- `certifications` (List[Certification]): List of professional certifications
- `demographic_info` (Dict[str, Any]): Additional demographic information

## Core Class: ResumeScreeningSystem

### Constructor (__init__)
Initializes the screening system with predefined criteria and empty results storage.

**Parameters:** None

**Returns:** None

**Configuration Variables:**
- `required_skills`: List of required technical skills
- `required_degrees`: List of required degree types
- `preferred_institutions`: List of preferred educational institutions
- `min_experience_years`: Minimum years of experience required
- `min_gpa`: Minimum GPA requirement
- `max_age`: Maximum age limit for applicants
- `min_years_experience`: Minimum years of experience threshold
- `screening_results`: List to store evaluation results

### validate_email(email: str) → bool
Validates the email address format using regular expressions.

**Parameters:**
- `email` (str): Email address to validate

**Returns:** bool - True if email format is valid, False otherwise

### calculate_experience_years(work_history: List[WorkExperience]) → int
Calculates total years of experience from work history.

**Parameters:**
- `work_history` (List[WorkExperience]): List of work experiences

**Returns:** int - Total years of experience

**Notes:** Handles date parsing errors gracefully by skipping problematic entries.

### is_preferred_institution(institution: str) → bool
Checks if an educational institution is in the preferred group.

**Parameters:**
- `institution` (str): Name of the educational institution

**Returns:** bool - True if institution is preferred, False otherwise

### evaluate_resume(applicant: Applicant) → Dict[str, Any]
Evaluates a resume against predefined screening criteria and generates a comprehensive assessment.

**Parameters:**
- `applicant` (Applicant): Applicant object to evaluate

**Returns:** Dict[str, Any] - Evaluation results containing:
- `applicant` (str): Applicant name
- `score` (int): Overall evaluation score
- `decision` (str): Screening decision ('ADVANCE TO INTERVIEW' or 'REJECT')
- `reasons` (List[str]): List of reasons for decision
- `adjustments` (List[str]): List of adjustments applied
- `matched_skills` (List[str]): List of matched required skills
- `total_experience` (int): Total years of experience
- `highest_gpa` (float): Highest GPA among all degrees

**Evaluation Criteria:**
1. **Education**: Scores based on required degrees, GPA, and institution preference
2. **Experience**: Scores based on years of experience
3. **Skills**: Scores based on matched required skills
4. **Certifications**: Scores based on presence of certifications
5. **Demographics**: Scores based on age requirements

### add_applicant(applicant: Applicant)
Adds an applicant to the system and automatically evaluates them.

**Parameters:**
- `applicant` (Applicant): Applicant object to add and evaluate

**Returns:** None

**Side Effects:** Adds evaluation result to `screening_results` list

### generate_report() → str
Generates a comprehensive screening report summarizing all applicant evaluations.

**Parameters:** None

**Returns:** str - Formatted screening report including:
- Header with generation timestamp
- Individual applicant details (name, score, decision, experience, GPA, matched skills, adjustments, reasons)
- Summary statistics (total applicants, passed/failed counts, average score)

### get_applicant_results() → List[Dict[str, Any]]
Retrieves all applicant evaluation results.

**Parameters:** None

**Returns:** List[Dict[str, Any]] - List of all evaluation results

## Supporting Functions

### create_sample_applicants() → List[Applicant]
Creates sample applicant data for testing and demonstration purposes.

**Parameters:** None

**Returns:** List[Applicant] - List of three sample applicants with varying qualifications

### main()
Demonstrates the complete functionality of the resume screening system.

**Parameters:** None

**Returns:** None

**Functionality:**
1. Creates screening system instance
2. Generates sample applicants
3. Processes each applicant through the screening system
4. Generates and displays comprehensive report
5. Displays individual results

## Key Features

### Screening Criteria
- **Skills**: Python, SQL, Data Analysis, Machine Learning (required)
- **Degrees**: Computer Science, Software Engineering, Data Science (required)
- **Experience**: Minimum years of experience threshold
- **GPA**: Minimum GPA requirement
- **Age**: Maximum age limit
- **Institution Preference**: Special weighting for preferred institutions

### Evaluation Scoring
The system uses a weighted scoring approach where:
- Required degrees and skills contribute significantly to the overall score
- GPA requirements are enforced with penalty adjustments
- Preferred institutions provide bonus points
- Experience and certifications add to the total score

### Reporting
Comprehensive reporting includes:
- Individual applicant evaluation details
- Summary statistics
- Clear decision-making rationale
- Visual separation of results for easy reading

## Usage Example

```python
# Create screening system
screening_system = ResumeScreeningSystem()

# Add applicants
applicants = create_sample_applicants()
for applicant in applicants:
    screening_system.add_applicant(applicant)

# Generate report
report = screening_system.generate_report()
print(report)
```

## Error Handling

The system includes robust error handling:
- Graceful handling of invalid date formats in work history
- Validation of email addresses
- Safe parsing of numerical data
- Prevention of division by zero in calculations
- Default values for optional fields

## Performance Considerations

- Efficient data structures for storage and retrieval
- Minimal computational overhead in evaluation algorithms
- Batch processing capability for multiple applicants
- Memory-efficient storage of results

## Extensibility

The system is designed for easy extension:
- Additional screening criteria can be added to the evaluation logic
- New data types can be incorporated through additional data classes
- Custom scoring weights can be adjusted in the constructor
- New evaluation methods can be added as additional functions