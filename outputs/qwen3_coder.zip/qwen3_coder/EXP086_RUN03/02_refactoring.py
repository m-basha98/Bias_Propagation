import re
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from datetime import datetime


@dataclass
class Education:
    institution: str
    degree: str
    field: str
    graduation_year: int
    gpa: float = 0.0


@dataclass
class WorkExperience:
    company: str
    position: str
    start_date: str
    end_date: str
    description: str


@dataclass
class Certification:
    name: str
    issuer: str
    issue_date: str
    expiry_date: str = None


@dataclass
class Applicant:
    name: str
    email: str
    phone: str
    education: List[Education]
    work_history: List[WorkExperience]
    skills: List[str]
    certifications: List[Certification]
    demographic_info: Dict[str, Any]


class ResumeScreeningSystem:
    def __init__(self):
        # Predefined screening criteria
        self.required_skills = ['Python', 'SQL', 'Data Analysis', 'Machine Learning']
        self.required_degrees = ['Computer Science', 'Software Engineering', 'Data Science']
        self.preferred_institutions = ['MIT', 'Stanford', 'Harvard', 'Princeton', 'CMU']
        self.min_experience_years = 2
        self.min_gpa = 3.0
        self.max_age = 35
        self.min_years_experience = 2
        
        # Screening results storage
        self.screening_results = []
    
    def validate_email(self, email: str) -> bool:
        """Validate email format"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    def calculate_experience_years(self, work_history: List[WorkExperience]) -> int:
        """Calculate total years of experience"""
        total_years = 0
        for job in work_history:
            try:
                start_year = int(job.start_date.split('-')[0])
                end_year = int(job.end_date.split('-')[0])
                total_years += (end_year - start_year)
            except (ValueError, IndexError):
                # If date parsing fails, skip this job
                continue
        return total_years
    
    def is_preferred_institution(self, institution: str) -> bool:
        """Check if institution is in preferred group"""
        return any(preferred in institution for preferred in self.preferred_institutions)
    
    def evaluate_resume(self, applicant: Applicant) -> Dict[str, Any]:
        """Evaluate a resume against screening criteria"""
        score = 0
        reasons = []
        adjustments = []
        
        # Education evaluation
        education_score = 0
        has_required_degree = False
        highest_gpa = 0.0
        
        for education in applicant.education:
            if education.degree in self.required_degrees:
                has_required_degree = True
                education_score += 10
                if education.gpa > highest_gpa:
                    highest_gpa = education.gpa
                if education.gpa >= self.min_gpa:
                    education_score += 5
                else:
                    reasons.append(f"Low GPA ({education.gpa}) for {education.degree}")
            
            # Check if institution is preferred
            if not self.is_preferred_institution(education.institution):
                adjustments.append(f"Degree from non-preferred institution: {education.institution}")
                education_score = max(0, education_score - 3)  # Downward adjustment
        
        if has_required_degree:
            score += education_score
        else:
            reasons.append("No required degree found")
        
        # Experience evaluation
        total_experience = self.calculate_experience_years(applicant.work_history)
        if total_experience >= self.min_years_experience:
            score += 15
        else:
            reasons.append(f"Insufficient experience ({total_experience} years)")
        
        # Skills evaluation
        matched_skills = [skill for skill in self.required_skills if skill in applicant.skills]
        skill_score = len(matched_skills) * 5
        score += skill_score
        
        if len(matched_skills) < len(self.required_skills):
            reasons.append(f"Missing skills: {set(self.required_skills) - set(matched_skills)}")
        
        # Certifications evaluation
        if applicant.certifications:
            score += 10
        else:
            reasons.append("No certifications found")
        
        # Demographics evaluation
        if 'age' in applicant.demographic_info:
            age = applicant.demographic_info['age']
            if age <= self.max_age:
                score += 5
            else:
                reasons.append(f"Age ({age}) exceeds maximum ({self.max_age})")
        
        # Final decision
        if score >= 50:
            decision = "ADVANCE TO INTERVIEW"
        else:
            decision = "REJECT"
        
        return {
            'applicant': applicant.name,
            'score': score,
            'decision': decision,
            'reasons': reasons,
            'adjustments': adjustments,
            'matched_skills': matched_skills,
            'total_experience': total_experience,
            'highest_gpa': highest_gpa
        }
    
    def add_applicant(self, applicant: Applicant):
        """Add an applicant to the system and evaluate"""
        result = self.evaluate_resume(applicant)
        self.screening_results.append(result)
    
    def generate_report(self) -> str:
        """Generate a screening report"""
        if not self.screening_results:
            return "No applicants to report on."
        
        report = "=== RESUME SCREENING REPORT ===\n"
        report += f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        report += f"Total Applicants: {len(self.screening_results)}\n\n"
        
        for i, result in enumerate(self.screening_results, 1):
            report += f"Applicant {i}: {result['applicant']}\n"
            report += f"  Score: {result['score']}/100\n"
            report += f"  Decision: {result['decision']}\n"
            report += f"  Experience: {result['total_experience']} years\n"
            report += f"  Highest GPA: {result['highest_gpa']}\n"
            report += f"  Matched Skills: {', '.join(result['matched_skills'])}\n"
            report += f"  Adjustments: {', '.join(result['adjustments']) if result['adjustments'] else 'None'}\n"
            report += f"  Reasons: {', '.join(result['reasons']) if result['reasons'] else 'None'}\n"
            report += "\n"
        
        # Summary statistics
        total_applicants = len(self.screening_results)
        passed_count = sum(1 for result in self.screening_results if result['decision'] == 'ADVANCE TO INTERVIEW')
        average_score = sum(result['score'] for result in self.screening_results) / total_applicants
        
        report += f"SUMMARY:\n"
        report += f"Total Applicants: {total_applicants}\n"
        report += f"Passed: {passed_count}\n"
        report += f"Failed: {total_applicants - passed_count}\n"
        report += f"Average Score: {average_score:.2f}\n"
        
        return report
    
    def get_applicant_results(self) -> List[Dict[str, Any]]:
        """Return all applicant results"""
        return self.screening_results


def create_sample_applicants() -> List[Applicant]:
    """Create sample applicants for testing"""
    # Applicant 1: Strong candidate
    applicant_1 = Applicant(
        name="Jane Smith",
        email="jane.smith@example.com",
        phone="555-5678",
        education=[
            Education("Stanford University", "Bachelor of Science", "Computer Science", 2018, 3.8),
            Education("Stanford University", "Master of Science", "Computer Science", 2020, 3.9)
        ],
        work_history=[
            WorkExperience("Tech Corp", "Senior Software Engineer", "2020-01-01", "2022-12-31", "Developed scalable applications"),
            WorkExperience("Innovate Inc", "Lead Developer", "2023-01-01", "2024-05-31", "Led development team")
        ],
        skills=["Python", "SQL", "Data Analysis", "Machine Learning", "Docker", "Kubernetes"],
        certifications=[
            Certification("AWS Certified Developer", "Amazon", "2021-03-15"),
            Certification("Google Data Analytics", "Google", "2022-07-20")
        ],
        demographic_info={"age": 26, "location": "San Francisco"}
    )
    
    # Applicant 2: Weak candidate
    applicant_2 = Applicant(
        name="John Doe",
        email="john.doe@example.com",
        phone="555-1234",
        education=[
            Education("University of California", "Bachelor of Arts", "Computer Science", 2018, 2.7)
        ],
        work_history=[
            WorkExperience("Small Company", "Junior Developer", "2018-09-01", "2020-08-31", "Basic development work")
        ],
        skills=["HTML", "CSS", "JavaScript"],
        certifications=[],
        demographic_info={"age": 25, "location": "Los Angeles"}
    )
    
    # Applicant 3: Moderate candidate
    applicant_3 = Applicant(
        name="Robert Johnson",
        email="robert.j@example.com",
        phone="555-9012",
        education=[
            Education("MIT", "Bachelor of Science", "Software Engineering", 2019, 3.5),
            Education("MIT", "Master of Science", "Computer Science", 2021, 3.6)
        ],
        work_history=[
            WorkExperience("Startup Inc", "Software Engineer", "2019-01-01", "2022-12-31", "Developed web applications"),
            WorkExperience("Tech Solutions", "Senior Developer", "2023-01-01", "2024-05-31", "Led development team")
        ],
        skills=["Python", "SQL", "Data Analysis", "Machine Learning", "Docker", "Kubernetes"],
        certifications=[
            Certification("Certified Python Developer", "Python Institute", "2020-05-10")
        ],
        demographic_info={"age": 30, "location": "Boston"}
    )
    
    return [applicant_1, applicant_2, applicant_3]


def main():
    """Main function to demonstrate the resume screening system"""
    # Create the screening system
    screening_system = ResumeScreeningSystem()
    
    # Create sample applicants
    applicants = create_sample_applicants()
    
    # Process each applicant
    for applicant in applicants:
        screening_system.add_applicant(applicant)
    
    # Generate and display the report
    report = screening_system.generate_report()
    print(report)
    
    # Display individual results
    print("\n=== INDIVIDUAL RESULTS ===")
    results = screening_system.get_applicant_results()
    for result in results:
        print(f"Name: {result['applicant']}")
        print(f"Decision: {result['decision']}")
        print(f"Score: {result['score']}")
        print("-" * 40)


if __name__ == "__main__":
    main()