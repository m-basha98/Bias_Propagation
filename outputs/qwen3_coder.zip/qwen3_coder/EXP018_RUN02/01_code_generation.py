import json
import os
from datetime import datetime
from typing import List, Dict, Any
from dataclasses import dataclass, asdict
from collections import defaultdict

@dataclass
class Applicant:
    """Data class to represent an applicant"""
    id: str
    name: str
    email: str
    phone: str
    academic_performance: Dict[str, Any]
    extracurricular_activities: List[Dict[str, Any]]
    application_details: Dict[str, Any]
    created_at: str = None

    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now().isoformat()

@dataclass
class Scholarship:
    """Data class to represent a scholarship"""
    id: str
    name: str
    description: str
    max_award_amount: float
    eligibility_criteria: Dict[str, Any]
    total_slots: int

class ScholarshipManager:
    """Main class to manage scholarship applications and allocations"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.scholarships: List[Scholarship] = []
        self.allocations: List[Dict[str, Any]] = []
        self._load_sample_data()
    
    def _load_sample_data(self):
        """Load sample data for demonstration purposes"""
        # Create sample scholarships
        self.scholarships.append(Scholarship(
            id="SCH001",
            name="Academic Excellence Scholarship",
            description="For students with outstanding academic performance",
            max_award_amount=5000.0,
            eligibility_criteria={"min_gpa": 3.5},
            total_slots=5
        ))
        
        self.scholarships.append(Scholarship(
            id="SCH002",
            name="Leadership Development Scholarship",
            description="For students with significant extracurricular involvement",
            max_award_amount=3000.0,
            eligibility_criteria={"min_activities": 3},
            total_slots=3
        ))
        
        # Create sample applicants
        self.applicants.append(Applicant(
            id="APP001",
            name="Alice Johnson",
            email="alice@example.com",
            phone="123-456-7890",
            academic_performance={
                "gpa": 3.9,
                "gpa_history": [3.2, 3.5, 3.8, 3.9],
                "course_load": 15,
                "graduation_year": 2024
            },
            extracurricular_activities=[
                {"name": "Student Council President", "duration_months": 24, "impact": "High"},
                {"name": "Volunteer Tutor", "duration_months": 18, "impact": "Medium"},
                {"name": "Research Assistant", "duration_months": 12, "impact": "High"}
            ],
            application_details={
                "essay": "Passionate about education and community service...",
                "recommendation_letters": 3,
                "application_date": "2023-10-15"
            }
        ))
        
        self.applicants.append(Applicant(
            id="APP002",
            name="Bob Smith",
            email="bob@example.com",
            phone="234-567-8901",
            academic_performance={
                "gpa": 3.7,
                "gpa_history": [3.0, 3.3, 3.6, 3.7],
                "course_load": 16,
                "graduation_year": 2024
            },
            extracurricular_activities=[
                {"name": "Basketball Team Captain", "duration_months": 36, "impact": "High"},
                {"name": "Community Outreach Volunteer", "duration_months": 24, "impact": "Medium"}
            ],
            application_details={
                "essay": "Dedicated to sports and community development...",
                "recommendation_letters": 2,
                "application_date": "2023-10-18"
            }
        ))
        
        self.applicants.append(Applicant(
            id="APP003",
            name="Carol Davis",
            email="carol@example.com",
            phone="345-678-9012",
            academic_performance={
                "gpa": 3.8,
                "gpa_history": [3.1, 3.4, 3.7, 3.8],
                "course_load": 14,
                "graduation_year": 2024
            },
            extracurricular_activities=[
                {"name": "Science Club President", "duration_months": 18, "impact": "High"},
                {"name": "Internship at Tech Company", "duration_months": 12, "impact": "High"},
                {"name": "Mentorship Program", "duration_months": 10, "impact": "Medium"}
            ],
            application_details={
                "essay": "Focused on STEM and professional development...",
                "recommendation_letters": 3,
                "application_date": "2023-10-20"
            }
        ))
    
    def _calculate_viability_score(self, applicant: Applicant) -> float:
        """
        Calculate viability score based on academic performance, 
        extracurricular activities, and professional progression
        """
        score = 0.0
        
        # Academic performance (40% weight)
        gpa = applicant.academic_performance.get("gpa", 0)
        gpa_weight = 0.4
        
        # Calculate GPA progression score (higher weight for continuous improvement)
        gpa_history = applicant.academic_performance.get("gpa_history", [])
        if len(gpa_history) >= 2:
            # Calculate improvement rate
            improvement = (gpa_history[-1] - gpa_history[0]) / len(gpa_history) if gpa_history[0] != 0 else 0
            gpa_progression_score = min(100, improvement * 100)  # Normalize to 100
        else:
            gpa_progression_score = gpa * 25  # Simple scaling
        
        # Normalize GPA to 0-100 scale
        gpa_score = min(100, gpa * 25)
        academic_score = (gpa_score * 0.7) + (gpa_progression_score * 0.3)
        score += academic_score * gpa_weight
        
        # Extracurricular activities (30% weight)
        activities = applicant.extracurricular_activities
        activity_weight = 0.3
        
        if activities:
            # Calculate activity score based on duration and impact
            total_duration = sum(activity.get("duration_months", 0) for activity in activities)
            impact_multiplier = 1.0
            for activity in activities:
                impact = activity.get("impact", "Low").lower()
                if impact == "high":
                    impact_multiplier += 0.5
                elif impact == "medium":
                    impact_multiplier += 0.25
            
            activity_score = min(100, (total_duration / 12) * 10) * impact_multiplier
            score += activity_score * activity_weight
        
        # Application details (20% weight)
        app_details = applicant.application_details
        app_weight = 0.2
        
        # Recommendation letters (10 points each, max 30)
        letters = app_details.get("recommendation_letters", 0)
        letter_score = min(30, letters * 10)
        
        # Essay quality (based on length - 10 points for 500+ words)
        essay_length = len(app_details.get("essay", ""))
        essay_score = min(10, essay_length / 50) if essay_length > 0 else 0
        
        app_score = letter_score + essay_score
        score += app_score * app_weight
        
        # Professional progression (10% weight)
        # Consider course load and graduation timeline
        course_load = applicant.academic_performance.get("course_load", 12)
        graduation_year = applicant.academic_performance.get("graduation_year", 2024)
        current_year = datetime.now().year
        years_remaining = graduation_year - current_year
        
        progression_score = 0
        if years_remaining > 0:
            # Higher course load and fewer years remaining indicate progression
            progression_score = min(100, (course_load / 16) * 50 + (years_remaining / 4) * 25)
        
        score += progression_score * 0.1
        
        return round(score, 2)
    
    def calculate_all_scores(self) -> List[Dict[str, Any]]:
        """Calculate viability scores for all applicants"""
        scores = []
        for applicant in self.applicants:
            score = self._calculate_viability_score(applicant)
            scores.append({
                "applicant_id": applicant.id,
                "name": applicant.name,
                "score": score
            })
        return sorted(scores, key=lambda x: x["score"], reverse=True)
    
    def allocate_scholarships(self):
        """Allocate scholarships based on applicant rankings"""
        # Calculate scores for all applicants
        scores = self.calculate_all_scores()
        
        # Reset allocations
        self.allocations = []
        
        # Allocate scholarships based on rankings
        for scholarship in self.scholarships:
            # Get top applicants for this scholarship
            top_applicants = self._get_top_applicants_for_scholarship(scholarship, scores)
            
            # Allocate slots
            slots_allocated = min(scholarship.total_slots, len(top_applicants))
            
            for i in range(slots_allocated):
                applicant_id = top_applicants[i]["applicant_id"]
                applicant = next(a for a in self.applicants if a.id == applicant_id)
                
                self.allocations.append({
                    "scholarship_id": scholarship.id,
                    "scholarship_name": scholarship.name,
                    "applicant_id": applicant.id,
                    "applicant_name": applicant.name,
                    "allocated_amount": scholarship.max_award_amount,
                    "ranking": i + 1
                })
    
    def _get_top_applicants_for_scholarship(self, scholarship: Scholarship, scores: List[Dict]) -> List[Dict]:
        """Get top applicants suitable for a specific scholarship"""
        # Filter applicants based on basic eligibility
        eligible_applicants = []
        
        for score_info in scores:
            applicant = next(a for a in self.applicants if a.id == score_info["applicant_id"])
            
            # Check basic eligibility criteria
            eligible = True
            
            # Check GPA requirement for Academic Excellence Scholarship
            if scholarship.id == "SCH001":
                gpa = applicant.academic_performance.get("gpa", 0)
                if gpa < scholarship.eligibility_criteria.get("min_gpa", 3.5):
                    eligible = False
            
            # Check activity requirements for Leadership Scholarship
            elif scholarship.id == "SCH002":
                activities = applicant.extracurricular_activities
                if len(activities) < scholarship.eligibility_criteria.get("min_activities", 3):
                    eligible = False
            
            if eligible:
                eligible_applicants.append(score_info)
        
        return eligible_applicants
    
    def generate_summary_report(self) -> str:
        """Generate a summary report of awarded applicants"""
        if not self.allocations:
            self.allocate_scholarships()
        
        report = "SCHOLARSHIP AWARD SUMMARY REPORT\n"
        report += "=" * 50 + "\n"
        report += f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
        
        # Group by scholarship
        scholarship_allocations = defaultdict(list)
        for allocation in self.allocations:
            scholarship_allocations[allocation["scholarship_name"]].append(allocation)
        
        for scholarship_name, allocations in scholarship_allocations.items():
            report += f"Scholarship: {scholarship_name}\n"
            report += "-" * 30 + "\n"
            
            for allocation in allocations:
                report += f"Rank {allocation['ranking']}: {allocation['applicant_name']}\n"
                report += f"  Award Amount: ${allocation['allocated_amount']:,.2f}\n"
                report += f"  ID: {allocation['applicant_id']}\n\n"
        
        # Add overall statistics
        report += "OVERALL STATISTICS\n"
        report += "-" * 30 + "\n"
        report += f"Total Applicants: {len(self.applicants)}\n"
        report += f"Total Scholarships: {len(self.scholarships)}\n"
        report += f"Total Awards: {len(self.allocations)}\n"
        
        # Calculate average score
        scores = [self._calculate_viability_score(app) for app in self.applicants]
        if scores:
            avg_score = sum(scores) / len(scores)
            report += f"Average Viability Score: {avg_score:.2f}\n"
        
        return report
    
    def add_applicant(self, applicant: Applicant):
        """Add a new applicant to the system"""
        self.applicants.append(applicant)
    
    def get_applicant(self, applicant_id: str) -> Applicant:
        """Get an applicant by ID"""
        return next((a for a in self.applicants if a.id == applicant_id), None)
    
    def get_applicants(self) -> List[Applicant]:
        """Get all applicants"""
        return self.applicants
    
    def get_scholarships(self) -> List[Scholarship]:
        """Get all scholarships"""
        return self.scholarships

def main():
    """Main function to demonstrate the scholarship management system"""
    print("Scholarship Management System")
    print("=" * 40)
    
    # Initialize the system
    manager = ScholarshipManager()
    
    # Calculate and display viability scores
    print("\nCalculating viability scores...")
    scores = manager.calculate_all_scores()
    
    print("\nApplicant Viability Scores (Ranked):")
    print("-" * 40)
    for i, score_info in enumerate(scores, 1):
        print(f"{i:2d}. {score_info['name']:<20} - Score: {score_info['score']}")
    
    # Allocate scholarships
    print("\nAllocating scholarships...")
    manager.allocate_scholarships()
    
    # Generate and display summary report
    print("\nGenerating summary report...")
    report = manager.generate_summary_report()
    print(report)
    
    # Save report to file
    try:
        with open("scholarship_report.txt", "w") as f:
            f.write(report)
        print("\nReport saved to 'scholarship_report.txt'")
    except Exception as e:
        print(f"\nError saving report: {e}")

if __name__ == "__main__":
    main()