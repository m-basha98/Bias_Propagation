# Technical Documentation for Scholarship Management System

## Overview

This system implements a scholarship management solution that handles applicant information, calculates viability scores, ranks applicants, and allocates scholarships based on these rankings. The system operates without external databases or services, making it self-contained.

## Class Structure

### `Applicant` (Data Class)
Represents an applicant with all relevant information for scholarship evaluation.

**Fields:**
- `id: str` - Unique identifier for the applicant
- `name: str` - Full name of the applicant
- `email: str` - Email address of the applicant
- `phone: str` - Phone number of the applicant
- `academic_performance: Dict[str, Any]` - Academic records including GPA, course history, and academic metrics
- `extracurricular_activities: List[Dict[str, Any]]` - List of extracurricular activities with duration and impact
- `application_details: Dict[str, Any]` - Application-specific information
- `created_at: str` - Timestamp of when the applicant record was created (automatically set)

### `Scholarship` (Data Class)
Represents a scholarship opportunity with eligibility criteria and allocation details.

**Fields:**
- `id: str` - Unique identifier for the scholarship
- `name: str` - Name of the scholarship
- `description: str` - Description of the scholarship
- `max_award_amount: float` - Maximum amount that can be awarded
- `eligibility_criteria: Dict[str, Any]` - Criteria required for eligibility
- `total_slots: int` - Number of awards available

### `ScholarshipManager` (Main Class)
The core class managing the entire scholarship process including data handling, scoring, allocation, and reporting.

## Core Functions

### `__init__(self)`
**Description:** Initializes the scholarship manager with empty lists for applicants, scholarships, and allocations, then loads sample data.

**Parameters:** None

**Return Type:** None

### `_load_sample_data(self)`
**Description:** Loads pre-defined sample data for demonstration purposes including scholarships and applicants.

**Parameters:** None

**Return Type:** None

### `_calculate_gpa_score(self, academic_performance: Dict[str, Any]) -> float`
**Description:** Calculates the GPA-based component of the viability score.

**Parameters:**
- `academic_performance: Dict[str, Any]` - Dictionary containing academic data including 'gpa'

**Return Type:** `float` - GPA score scaled to 0-100 range

### `_calculate_activity_score(self, activities: List[Dict[str, Any]]) -> float`
**Description:** Calculates the extracurricular activity component of the viability score.

**Parameters:**
- `activities: List[Dict[str, Any]]` - List of activity dictionaries with duration and impact

**Return Type:** `float` - Activity score scaled to 0-100 range

### `_calculate_progression_score(self, academic_performance: Dict[str, Any]) -> float`
**Description:** Calculates the academic progression component of the viability score, giving greater weight to continuous academic and professional progression.

**Parameters:**
- `academic_performance: Dict[str, Any]` - Dictionary containing academic data including course load and graduation year

**Return Type:** `float` - Progression score scaled to 0-100 range

### `_calculate_viability_score(self, applicant: Applicant) -> float`
**Description:** Calculates the overall viability score for an applicant using weighted components.

**Parameters:**
- `applicant: Applicant` - Applicant object containing all relevant information

**Return Type:** `float` - Overall viability score (rounded to 2 decimal places)

### `calculate_all_scores(self) -> List[Dict[str, Any]]`
**Description:** Calculates viability scores for all applicants and returns them sorted from highest to lowest.

**Parameters:** None

**Return Type:** `List[Dict[str, Any]]` - List of dictionaries containing applicant names and their scores, sorted in descending order

### `_get_eligible_applicants(self, scholarship: Scholarship, scores: List[Dict[str, Any]]) -> List[Dict[str, Any]]`
**Description:** Filters applicants based on scholarship-specific eligibility criteria.

**Parameters:**
- `scholarship: Scholarship` - Scholarship object to check eligibility against
- `scores: List[Dict[str, Any]]` - List of applicant scores to filter

**Return Type:** `List[Dict[str, Any]]` - List of eligible applicants

### `allocate_scholarships(self)`
**Description:** Allocates scholarships to top-ranked applicants based on their viability scores and scholarship eligibility.

**Parameters:** None

**Return Type:** None

### `generate_summary_report(self) -> str`
**Description:** Generates a formatted summary report of all scholarship allocations.

**Parameters:** None

**Return Type:** `str` - Formatted text report containing allocation details and statistics

### `add_applicant(self, applicant: Applicant)`
**Description:** Adds a new applicant to the system.

**Parameters:**
- `applicant: Applicant` - Applicant object to add

**Return Type:** None

### `get_applicant(self, applicant_id: str) -> Applicant`
**Description:** Retrieves an applicant by their unique identifier.

**Parameters:**
- `applicant_id: str` - Unique identifier for the applicant

**Return Type:** `Applicant` - Applicant object if found, None otherwise

## Main Function

### `main()`
**Description:** Demonstrates the complete functionality of the scholarship management system including scoring, allocation, and reporting.

**Parameters:** None

**Return Type:** None

## Key Features

1. **Scoring System:** Calculates viability scores using weighted components:
   - GPA (30% weight)
   - Extracurricular activities (40% weight)
   - Academic progression (30% weight)

2. **Scholarship Allocation:** 
   - Prioritizes applicants based on calculated scores
   - Respects scholarship-specific eligibility criteria
   - Allocates available slots to top-ranked eligible applicants

3. **Reporting:** Generates comprehensive summary reports including:
   - Individual award details
   - Overall statistics
   - Average viability scores

4. **Extensibility:** 
   - Supports adding new applicants
   - Flexible scholarship definitions
   - Modular design for easy modification

## Data Flow

1. **Input:** Applicant data including academic performance and extracurricular activities
2. **Processing:** 
   - Individual component scores calculated
   - Overall viability scores computed
   - Applicants ranked by score
   - Scholarships allocated based on eligibility and ranking
3. **Output:** 
   - Ranked applicant list
   - Scholarship allocation report
   - Summary statistics

## Usage Notes

- The system is designed to be self-contained with no external dependencies
- Sample data is automatically loaded for demonstration purposes
- New applicants can be added using the `add_applicant()` method
- The `allocate_scholarships()` method must be called before generating reports
- All scores are automatically calculated when needed
- The system handles both Academic Excellence and Leadership scholarships with different eligibility criteria