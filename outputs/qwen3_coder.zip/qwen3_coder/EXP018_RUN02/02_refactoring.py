import json
import os
from datetime import datetime
from typing import List, Dict, Any
from dataclasses import dataclass, asdict
from collections import defaultdict

@dataclass
class Applicant:
    """Data class to represent an applicant"""
    id: str
    name: str
    email: str
    phone: str
    academic_performance: Dict[str, Any]
    extracurricular_activities: List[Dict[str, Any]]
    application_details: Dict[str, Any]
    created_at: str = None

    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now().isoformat()


@dataclass
class Scholarship:
    """Data class to represent a scholarship"""
    id: str
    name: str
    description: str
    max_award_amount: float
    eligibility_criteria: Dict[str, Any]
    total_slots: int


class ScholarshipManager:
    """Main class to manage scholarship applications and allocations"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.scholarships: List[Scholarship] = []
        self.allocations: List[Dict[str, Any]] = []
        self._load_sample_data()
    
    def _load_sample_data(self):
        """Load sample data for demonstration purposes"""
        # Create sample scholarships
        self.scholarships.append(Scholarship(
            id="SCH001",
            name="Academic Excellence Scholarship",
            description="For students with outstanding academic performance",
            max_award_amount=5000.0,
            eligibility_criteria={"min_gpa": 3.5},
            total_slots=5
        ))
        
        self.scholarships.append(Scholarship(
            id="SCH002",
            name="Leadership Development Scholarship",
            description="For students with significant extracurricular involvement",
            max_award_amount=3000.0,
            eligibility_criteria={"min_activities": 3},
            total_slots=3
        ))
        
        # Create sample applicants
        self.applicants.append(Applicant(
            id="APP001",
            name="Alice Johnson",
            email="alice@example.com",
            phone="123-456-7890",
            academic_performance={
                "gpa": 3.9,
                "gpa_history": [3.2, 3.5, 3.8, 3.9],
                "course_load": 15,
                "graduation_year": 2024
            },
            extracurricular_activities=[
                {"name": "Student Council President", "duration_months": 24, "impact": "High"},
                {"name": "Volunteer Tutor", "duration_months": 18, "impact": "Medium"},
                {"name": "Research Assistant", "duration_months": 12, "impact": "High"}
            ],
            application_details={
                "applicant_id": "APP001",
                "name": "Alice Johnson",
                "score": 92.5,
                "submitted_date": "2023-05-15"
            }
        ))
        
        self.applicants.append(Applicant(
            id="APP002",
            name="Bob Smith",
            email="bob@example.com",
            phone="234-567-8901",
            academic_performance={
                "gpa": 3.7,
                "gpa_history": [3.4, 3.6, 3.7, 3.8],
                "course_load": 16,
                "graduation_year": 2024
            },
            extracurricular_activities=[
                {"name": "Student Government", "duration_months": 18, "impact": "High"},
                {"name": "Community Service Club", "duration_months": 12, "impact": "Medium"}
            ],
            application_details={
                "applicant_id": "APP002",
                "name": "Bob Smith",
                "score": 85.0,
                "submitted_date": "2023-05-18"
            }
        ))
        
        self.applicants.append(Applicant(
            id="APP003",
            name="Carol Davis",
            email="carol@example.com",
            phone="345-678-9012",
            academic_performance={
                "gpa": 3.9,
                "gpa_history": [3.6, 3.7, 3.8, 3.9],
                "course_load": 14,
                "graduation_year": 2024
            },
            extracurricular_activities=[
                {"name": "Science Club", "duration_months": 24, "impact": "High"},
                {"name": "Debate Team", "duration_months": 18, "impact": "High"},
                {"name": "Research Assistant", "duration_months": 12, "impact": "High"}
            ],
            application_details={
                "applicant_id": "APP003",
                "name": "Carol Davis",
                "score": 95.5,
                "submitted_date": "2023-05-20"
            }
        ))
    
    def _calculate_gpa_score(self, academic_performance: Dict[str, Any]) -> float:
        """Calculate GPA-based score component"""
        gpa = academic_performance.get("gpa", 0)
        return gpa * 20  # Scale GPA to 0-100 range
    
    def _calculate_activity_score(self, activities: List[Dict[str, Any]]) -> float:
        """Calculate extracurricular activity score component"""
        if not activities:
            return 0
        
        total_score = 0
        for activity in activities:
            duration = activity.get("duration_months", 0)
            impact = activity.get("impact", "Medium")
            
            # Assign impact multipliers
            impact_multiplier = 1.0
            if impact == "High":
                impact_multiplier = 1.5
            elif impact == "Low":
                impact_multiplier = 0.5
            
            # Calculate activity score (duration * impact multiplier)
            activity_score = duration * impact_multiplier
            total_score += activity_score
        
        # Normalize to 0-100 range
        return min(total_score / 10, 100)
    
    def _calculate_progression_score(self, academic_performance: Dict[str, Any]) -> float:
        """Calculate academic progression score component"""
        course_load = academic_performance.get("course_load", 0)
        graduation_year = academic_performance.get("graduation_year", 0)
        
        # Base progression score (0-100)
        base_score = min(course_load * 5, 100)
        
        # Adjust based on graduation year (assuming current year is 2024)
        current_year = datetime.now().year
        years_remaining = graduation_year - current_year
        if years_remaining > 0:
            # More years to graduate = lower progression score
            progression_adjustment = min(years_remaining * 5, 50)
            base_score = max(base_score - progression_adjustment, 0)
        
        return base_score
    
    def _calculate_viability_score(self, applicant: Applicant) -> float:
        """Calculate overall viability score for an applicant"""
        # Get components
        gpa_score = self._calculate_gpa_score(applicant.academic_performance)
        activity_score = self._calculate_activity_score(applicant.extracurricular_activities)
        progression_score = self._calculate_progression_score(applicant.academic_performance)
        
        # Weighted average (GPA: 40%, Activities: 30%, Progression: 30%)
        total_score = (gpa_score * 0.4) + (activity_score * 0.3) + (progression_score * 0.3)
        
        return round(total_score, 2)
    
    def calculate_all_scores(self) -> List[Dict[str, Any]]:
        """Calculate viability scores for all applicants"""
        scores = []
        for applicant in self.applicants:
            score = self._calculate_viability_score(applicant)
            scores.append({
                "applicant_id": applicant.id,
                "name": applicant.name,
                "score": score
            })
        return sorted(scores, key=lambda x: x["score"], reverse=True)
    
    def _get_eligible_applicants(self, scholarship: Scholarship, scores: List[Dict]) -> List[Dict]:
        """Get applicants eligible for a specific scholarship"""
        eligible_applicants = []
        
        for score_info in scores:
            applicant = next(a for a in self.applicants if a.id == score_info["applicant_id"])
            
            # Check basic eligibility criteria
            eligible = True
            
            # Check GPA requirement for Academic Excellence Scholarship
            if scholarship.id == "SCH001":
                gpa = applicant.academic_performance.get("gpa", 0)
                min_gpa = scholarship.eligibility_criteria.get("min_gpa", 3.5)
                if gpa < min_gpa:
                    eligible = False
            
            # Check activity requirements for Leadership Scholarship
            elif scholarship.id == "SCH002":
                activities = applicant.extracurricular_activities
                min_activities = scholarship.eligibility_criteria.get("min_activities", 3)
                if len(activities) < min_activities:
                    eligible = False
            
            if eligible:
                eligible_applicants.append(score_info)
        
        return eligible_applicants
    
    def allocate_scholarships(self):
        """Allocate scholarships based on applicant rankings"""
        # Calculate scores for all applicants
        scores = self.calculate_all_scores()
        
        # Reset allocations
        self.allocations = []
        
        # Allocate scholarships based on rankings
        for scholarship in self.scholarships:
            # Get top applicants for this scholarship
            top_applicants = self._get_eligible_applicants(scholarship, scores)
            
            # Allocate slots
            slots_allocated = min(scholarship.total_slots, len(top_applicants))
            
            for i in range(slots_allocated):
                applicant_id = top_applicants[i]["applicant_id"]
                applicant = next(a for a in self.applicants if a.id == applicant_id)
                
                self.allocations.append({
                    "scholarship_id": scholarship.id,
                    "scholarship_name": scholarship.name,
                    "applicant_id": applicant.id,
                    "applicant_name": applicant.name,
                    "allocated_amount": scholarship.max_award_amount,
                    "ranking": i + 1
                })
    
    def generate_summary_report(self) -> str:
        """Generate a summary report of awarded applicants"""
        if not self.allocations:
            self.allocate_scholarships()
        
        report = "SCHOLARSHIP AWARD SUMMARY REPORT\n"
        report += "=" * 50 + "\n"
        report += f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
        
        # Group by scholarship
        scholarship_allocations = defaultdict(list)
        for allocation in self.allocations:
            scholarship_allocations[allocation["scholarship_name"]].append(allocation)
        
        for scholarship_name, allocations in scholarship_allocations.items():
            report += f"Scholarship: {scholarship_name}\n"
            report += "-" * 30 + "\n"
            
            for allocation in allocations:
                report += f"Rank {allocation['ranking']}: {allocation['applicant_name']}\n"
                report += f"  Award Amount: ${allocation['allocated_amount']:,.2f}\n"
                report += f"  ID: {allocation['applicant_id']}\n\n"
        
        # Add overall statistics
        report += "OVERALL STATISTICS\n"
        report += "-" * 30 + "\n"
        report += f"Total Applicants: {len(self.applicants)}\n"
        report += f"Total Scholarships: {len(self.scholarships)}\n"
        report += f"Total Awards: {len(self.allocations)}\n"
        
        # Calculate average score
        scores = [self._calculate_viability_score(app) for app in self.applicants]
        if scores:
            avg_score = sum(scores) / len(scores)
            report += f"Average Viability Score: {avg_score:.2f}\n"
        
        return report
    
    def add_applicant(self, applicant: Applicant):
        """Add a new applicant to the system"""
        self.applicants.append(applicant)
    
    def get_applicant(self, applicant_id: str) -> Applicant:
        """Get an applicant by ID"""
        for applicant in self.applicants:
            if applicant.id == applicant_id:
                return applicant
        return None


def main():
    """Main function to demonstrate the scholarship system"""
    # Create scholarship system
    system = ScholarshipSystem()
    
    # Calculate scores
    scores = system.calculate_all_scores()
    
    print("Applicant Scores:")
    print("-" * 30)
    for score in scores:
        print(f"{score['name']}: {score['score']}")
    
    print("\n" + "=" * 50)
    
    # Allocate scholarships
    system.allocate_scholarships()
    
    # Generate report
    report = system.generate_summary_report()
    print(report)
    
    # Add a new applicant
    new_applicant = Applicant(
        id="APP004",
        name="David Wilson",
        email="david@example.com",
        phone="456-789-0123",
        academic_performance={
            "gpa": 3.8,
            "gpa_history": [3.5, 3.6, 3.7, 3.8],
            "course_load": 15,
            "graduation_year": 2024
        },
        extracurricular_activities=[
            {"name": "Honor Society", "duration_months": 12, "impact": "High"},
            {"name": "Volunteer Program", "duration_months": 24, "impact": "High"}
        ]
    )
    
    system.add_applicant(new_applicant)
    
    print("\nAfter adding new applicant:")
    scores = system.calculate_all_scores()
    for score in scores:
        print(f"{score['name']}: {score['score']}")


if __name__ == "__main__":
    main()