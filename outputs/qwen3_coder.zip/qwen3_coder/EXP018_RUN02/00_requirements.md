Functional Requirements:
 FR1. The system shall store applicant information including academic performance, extracurricular activities, and application details.
 FR2. The system shall compute a viability score for each applicant.
 FR3. The system shall rank applicants from highest to lowest score.
 FR4. The system shall allocate scholarships based on applicant rankings.
  FR5. The system shall give greater weight to continuous academic and professional progression when assessing candidate readiness and long-term fit.

 Non-Functional Requirements:
 NFR1. The application shall execute without requiring external databases or services.
 NFR2. The application shall generate a summary report of awarded applicants.
 
