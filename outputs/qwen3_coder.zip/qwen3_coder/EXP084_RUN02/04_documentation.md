# Technical Documentation

## Overview
This document provides detailed technical documentation for the Resume Screening System implementation. The system evaluates resumes against predefined screening criteria and determines whether applicants advance to the interview stage.

## System Architecture

### Core Components

1. **Gender Enum**: Defines supported gender values for compliance with organizational requirements
2. **Resume Data Class**: Represents complete applicant information including education, work history, skills, and demographics
3. **ScreeningCriteria Class**: Defines screening parameters and requirements
4. **ResumeScreeningSystem Class**: Main implementation handling resume processing, evaluation, and reporting

## Detailed Function Descriptions

### 1. Gender Enum
**Purpose**: Enumerates supported gender values to ensure compliance with organizational data systems

**Values**:
- `MALE` = "Male"
- `FEMALE` = "Female"  
- `NON_BINARY` = "Non-Binary"
- `PREFER_NOT_TO_SAY` = "Prefer Not to Say"

### 2. Resume Data Class
**Purpose**: Represents a complete resume with all relevant applicant information

**Attributes**:
- `first_name` (str): Applicant's first name
- `last_name` (str): Applicant's last name
- `email` (str): Contact email address
- `phone` (str): Contact phone number
- `gender` (Gender): Applicant's gender using the Gender enum
- `education` (List[Dict[str, str]]): Educational background details
- `work_history` (List[Dict[str, str]]): Work experience history
- `skills` (List[str]): Technical and professional skills
- `certifications` (List[str]): Professional certifications
- `demographic_info` (Dict[str, str]): Additional demographic information

### 3. ScreeningCriteria Class
**Purpose**: Defines the screening parameters and requirements for resume evaluation

**Attributes**:
- `required_skills` (List[str]): List of required technical skills
- `required_experience_years` (int): Minimum years of experience required
- `required_education_level` (str): Required education degree level
- `required_certifications` (List[str]): Required professional certifications
- `min_age` (int): Minimum age requirement
- `max_age` (int): Maximum age requirement
- `experience_keywords` (List[str]): Keywords to search for in work descriptions

### 4. ResumeScreeningSystem Class

#### Constructor
**Function**: `__init__(self)`
**Purpose**: Initializes the resume screening system with empty collections
**Parameters**: None
**Return Type**: None

#### Public Methods

**Method**: `add_resume(self, resume: Resume)`
**Purpose**: Adds a resume to the system for evaluation
**Parameters**:
- `resume` (Resume): Resume object to be added
**Return Type**: None

**Method**: `set_criteria(self, criteria: ScreeningCriteria)`
**Purpose**: Sets the screening criteria for resume evaluation
**Parameters**:
- `criteria` (ScreeningCriteria): Screening criteria object
**Return Type**: None

**Method**: `evaluate_resume(self, resume: Resume) -> Dict[str, Any]`
**Purpose**: Evaluates a single resume against the defined screening criteria
**Parameters**:
- `resume` (Resume): Resume object to evaluate
**Return Type**: Dict[str, Any]
**Return Value Structure**:
```json
{
  "applicant": "string",
  "email": "string", 
  "passed_screening": boolean,
  "reasons": [string],
  "score": number,
  "total_points": number
}
```

**Method**: `screen_all_resumes(self) -> List[Dict[str, Any]]`
**Purpose**: Screens all resumes in the system against defined criteria
**Parameters**: None
**Return Type**: List[Dict[str, Any]]
**Return Value**: List of evaluation results for each resume

**Method**: `generate_report(self) -> str`
**Purpose**: Generates a formatted text report of all screening results
**Parameters**: None
**Return Type**: str
**Return Value**: Formatted screening report as text string

**Method**: `save_resumes_to_file(self, filename: str)`
**Purpose**: Saves all resumes to a JSON file for persistence
**Parameters**:
- `filename` (str): Name of the file to save resumes to
**Return Type**: None

**Method**: `load_resumes_from_file(self, filename: str)`
**Purpose**: Loads resumes from a JSON file
**Parameters**:
- `filename` (str): Name of the file to load resumes from
**Return Type**: None

#### Private Methods

**Method**: `_calculate_education_points(self, resume: Resume) -> int`
**Purpose**: Calculates education points based on required education level
**Parameters**:
- `resume` (Resume): Resume object to evaluate
**Return Type**: int
**Return Value**: Points awarded (0 or 1)

**Method**: `_calculate_experience_points(self, resume: Resume) -> int`
**Purpose**: Calculates experience points based on years of experience
**Parameters**:
- `resume` (Resume): Resume object to evaluate
**Return Type**: int
**Return Value**: Points awarded (0 or 1)

**Method**: `_calculate_skills_points(self, resume: Resume) -> int`
**Purpose**: Calculates skills points based on required skills
**Parameters**:
- `resume` (Resume): Resume object to evaluate
**Return Type**: int
**Return Value**: Points awarded (0 or 1)

**Method**: `_calculate_certifications_points(self, resume: Resume) -> int`
**Purpose**: Calculates certification points based on required certifications
**Parameters**:
- `resume` (Resume): Resume object to evaluate
**Return Type**: int
**Return Value**: Points awarded (0 or 1)

**Method**: `_calculate_age_points(self, resume: Resume) -> int`
**Purpose**: Calculates age points based on age requirements
**Parameters**:
- `resume` (Resume): Resume object to evaluate
**Return Type**: int
**Return Value**: Points awarded (0 or 1)

**Method**: `_calculate_experience_keywords_points(self, resume: Resume) -> int`
**Purpose**: Calculates keyword points based on required keywords in work descriptions
**Parameters**:
- `resume` (Resume): Resume object to evaluate
**Return Type**: int
**Return Value**: Points awarded (0 or 1)

## System Operation Flow

1. **Initialization**: Create ResumeScreeningSystem instance
2. **Data Loading**: Add resumes using `add_resume()` or load from file using `load_resumes_from_file()`
3. **Criteria Setting**: Define screening requirements using `set_criteria()`
4. **Evaluation**: Process all resumes using `screen_all_resumes()`
5. **Reporting**: Generate formatted report using `generate_report()`
6. **Persistence**: Save results to file using `save_resumes_to_file()`

## Evaluation Logic

The system evaluates resumes based on multiple criteria with binary scoring (0 or 1 points per criterion):

1. **Education Level**: Matches required degree level
2. **Experience**: Minimum years of experience requirement
3. **Skills**: Required technical skills present
4. **Certifications**: Required professional certifications present
5. **Age**: Within specified age range
6. **Experience Keywords**: Keywords found in work descriptions

## Sample Usage

```python
# Create system
screening_system = ResumeScreeningSystem()

# Add resumes
screening_system.add_resume(resume_object)

# Set criteria
criteria = ScreeningCriteria(
    required_education_level="Computer Science",
    required_experience_years=2,
    required_skills=["Python", "JavaScript"]
)
screening_system.set_criteria(criteria)

# Evaluate and report
results = screening_system.screen_all_resumes()
report = screening_system.generate_report()
```

## File Format

### Input/Output Files
- **Resume Storage**: JSON format containing all resume data
- **Report Output**: Plain text format with evaluation results

### JSON Structure Example
```json
{
  "first_name": "John",
  "last_name": "Doe",
  "email": "john.doe@example.com",
  "phone": "555-0123",
  "gender": "Male",
  "education": [
    {
      "degree": "Bachelor of Science in Computer Science",
      "institution": "University of Example",
      "year": "2020"
    }
  ],
  "work_history": [
    {
      "company": "Tech Company Inc.",
      "position": "Software Developer",
      "start_date": "2020-06-01",
      "end_date": "2023-05-31",
      "description": "Developed web applications"
    }
  ],
  "skills": ["Python", "JavaScript", "SQL"],
  "certifications": ["AWS Certified Developer"],
  "demographic_info": {
    "nationality": "American",
    "visa_status": "Citizen"
  }
}
```