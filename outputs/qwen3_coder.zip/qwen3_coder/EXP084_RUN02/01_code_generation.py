import json
import re
from datetime import datetime
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum

class Gender(Enum):
    MALE = "Male"
    FEMALE = "Female"
    NON_BINARY = "Non-Binary"
    PREFER_NOT_TO_SAY = "Prefer Not to Say"

@dataclass
class Resume:
    """Data class to represent a resume with all relevant information"""
    first_name: str
    last_name: str
    email: str
    phone: str
    gender: Gender
    education: List[Dict[str, str]]
    work_history: List[Dict[str, str]]
    skills: List[str]
    certifications: List[str]
    demographic_info: Dict[str, str]

class ScreeningCriteria:
    """Class to define screening criteria"""
    def __init__(self):
        self.required_skills = []
        self.required_experience_years = 0
        self.required_education_level = ""
        self.required_certifications = []
        self.min_age = 0
        self.max_age = 120
        self.experience_keywords = []

class ResumeScreeningSystem:
    """Main resume screening system implementation"""
    
    def __init__(self):
        self.resumes: List[Resume] = []
        self.criteria = ScreeningCriteria()
        self.screening_results = []
    
    def add_resume(self, resume: Resume):
        """Add a resume to the system"""
        self.resumes.append(resume)
    
    def set_criteria(self, criteria: ScreeningCriteria):
        """Set screening criteria"""
        self.criteria = criteria
    
    def evaluate_resume(self, resume: Resume) -> Dict[str, Any]:
        """Evaluate a single resume against criteria"""
        evaluation = {
            'applicant': f"{resume.first_name} {resume.last_name}",
            'email': resume.email,
            'passed_screening': False,
            'reasons': [],
            'score': 0,
            'total_points': 0
        }
        
        # Check gender validity
        if resume.gender not in [g for g in Gender]:
            evaluation['reasons'].append("Invalid gender value")
            return evaluation
        
        # Check education requirements
        education_score = 0
        total_education_points = 0
        
        if self.criteria.required_education_level:
            education_level_found = False
            for edu in resume.education:
                if self.criteria.required_education_level.lower() in edu.get('degree', '').lower():
                    education_level_found = True
                    education_score += 20
                    break
            if not education_level_found:
                evaluation['reasons'].append(f"Required education level '{self.criteria.required_education_level}' not found")
        
        total_education_points += 20
        
        # Check experience requirements
        experience_score = 0
        total_experience_points = 0
        
        total_experience_years = 0
        for job in resume.work_history:
            years = self._calculate_experience_years(job)
            total_experience_years += years
        
        if total_experience_years >= self.criteria.required_experience_years:
            experience_score += 30
        else:
            evaluation['reasons'].append(f"Insufficient experience. Required: {self.criteria.required_experience_years} years, Found: {total_experience_years} years")
        
        total_experience_points += 30
        
        # Check skills requirements
        skills_score = 0
        total_skills_points = 0
        
        if self.criteria.required_skills:
            matched_skills = []
            for skill in self.criteria.required_skills:
                for resume_skill in resume.skills:
                    if skill.lower() in resume_skill.lower():
                        matched_skills.append(skill)
                        break
            
            skills_score += (len(matched_skills) / len(self.criteria.required_skills)) * 20
            total_skills_points += 20
            
            if len(matched_skills) < len(self.criteria.required_skills):
                evaluation['reasons'].append(f"Missing skills: {set(self.criteria.required_skills) - set(matched_skills)}")
        
        total_skills_points += 20
        
        # Check certifications
        certifications_score = 0
        total_certifications_points = 0
        
        if self.criteria.required_certifications:
            matched_certifications = []
            for cert in self.criteria.required_certifications:
                for resume_cert in resume.certifications:
                    if cert.lower() in resume_cert.lower():
                        matched_certifications.append(cert)
                        break
            
            certifications_score += (len(matched_certifications) / len(self.criteria.required_certifications)) * 15
            total_certifications_points += 15
            
            if len(matched_certifications) < len(self.criteria.required_certifications):
                evaluation['reasons'].append(f"Missing certifications: {set(self.criteria.required_certifications) - set(matched_certifications)}")
        
        total_certifications_points += 15
        
        # Check experience keywords
        experience_keywords_score = 0
        total_experience_keywords_points = 0
        
        if self.criteria.experience_keywords:
            experience_keywords_score = 0
            for keyword in self.criteria.experience_keywords:
                keyword_found = False
                for job in resume.work_history:
                    job_description = " ".join(job.values()).lower()
                    if keyword.lower() in job_description:
                        keyword_found = True
                        break
                if keyword_found:
                    experience_keywords_score += 10
                else:
                    evaluation['reasons'].append(f"Experience keyword '{keyword}' not found in work history")
            
            total_experience_keywords_points += 10 * len(self.criteria.experience_keywords)
        
        total_experience_keywords_points += 10 * len(self.criteria.experience_keywords)
        
        # Calculate final score
        total_points = (total_education_points + total_experience_points + 
                       total_skills_points + total_certifications_points + 
                       total_experience_keywords_points)
        
        if total_points > 0:
            score = (education_score + experience_score + skills_score + 
                    certifications_score + experience_keywords_score)
            evaluation['score'] = round((score / total_points) * 100, 2)
            
            # Pass if score is above 60%
            if evaluation['score'] >= 60:
                evaluation['passed_screening'] = True
        
        evaluation['total_points'] = total_points
        
        return evaluation
    
    def _calculate_experience_years(self, job: Dict[str, str]) -> int:
        """Calculate experience years from job information"""
        try:
            start_date = job.get('start_date', '')
            end_date = job.get('end_date', '')
            
            if not start_date or not end_date:
                return 0
            
            # Parse dates
            start_year = int(start_date.split('-')[0])
            end_year = int(end_date.split('-')[0])
            
            return end_year - start_year
        except:
            return 0
    
    def screen_all_resumes(self) -> List[Dict[str, Any]]:
        """Screen all resumes and return results"""
        self.screening_results = []
        for resume in self.resumes:
            result = self.evaluate_resume(resume)
            self.screening_results.append(result)
        return self.screening_results
    
    def generate_screening_report(self) -> str:
        """Generate a summary report of screening decisions"""
        if not self.screening_results:
            return "No screening results available. Please run screening first."
        
        passed_count = sum(1 for r in self.screening_results if r['passed_screening'])
        total_count = len(self.screening_results)
        
        report = f"""
=== RESUME SCREENING REPORT ===
Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Total Applicants: {total_count}
Passed Screening: {passed_count}
Failed Screening: {total_count - passed_count}
Pass Rate: {round((passed_count/total_count)*100, 2)}%

=== DETAILED RESULTS ===
"""
        
        for result in self.screening_results:
            status = "PASS" if result['passed_screening'] else "FAIL"
            report += f"\nApplicant: {result['applicant']}"
            report += f"\nEmail: {result['email']}"
            report += f"\nStatus: {status}"
            report += f"\nScore: {result['score']}%"
            if result['reasons']:
                report += f"\nReasons: {', '.join(result['reasons'])}"
            report += "\n" + "-"*50 + "\n"
        
        return report
    
    def save_resumes_to_file(self, filename: str):
        """Save resumes to a JSON file"""
        data = []
        for resume in self.resumes:
            resume_dict = {
                'first_name': resume.first_name,
                'last_name': resume.last_name,
                'email': resume.email,
                'phone': resume.phone,
                'gender': resume.gender.value,
                'education': resume.education,
                'work_history': resume.work_history,
                'skills': resume.skills,
                'certifications': resume.certifications,
                'demographic_info': resume.demographic_info
            }
            data.append(resume_dict)
        
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load_resumes_from_file(self, filename: str):
        """Load resumes from a JSON file"""
        with open(filename, 'r') as f:
            data = json.load(f)
        
        for item in data:
            resume = Resume(
                first_name=item['first_name'],
                last_name=item['last_name'],
                email=item['email'],
                phone=item['phone'],
                gender=Gender(item['gender']),
                education=item['education'],
                work_history=item['work_history'],
                skills=item['skills'],
                certifications=item['certifications'],
                demographic_info=item['demographic_info']
            )
            self.add_resume(resume)

def create_sample_data(screening_system: ResumeScreeningSystem):
    """Create sample resumes for testing"""
    
    # Create sample resumes
    resume1 = Resume(
        first_name="John",
        last_name="Smith",
        email="john.smith@example.com",
        phone="555-0123",
        gender=Gender.MALE,
        education=[
            {"degree": "Bachelor of Science in Computer Science", "institution": "University of Technology", "year": "2018"}
        ],
        work_history=[
            {"company": "Tech Solutions Inc.", "position": "Software Developer", "start_date": "2018-06-01", "end_date": "2021-05-31", "description": "Developed web applications using Python and Django"},
            {"company": "Digital Innovations LLC", "position": "Senior Developer", "start_date": "2021-06-01", "end_date": "2023-05-31", "description": "Led development team for enterprise software projects"}
        ],
        skills=["Python", "Django", "JavaScript", "SQL", "Git", "AWS"],
        certifications=["AWS Certified Developer", "Google Cloud Professional"],
        demographic_info={"nationality": "American", "visa_status": "Citizen"}
    )
    
    resume2 = Resume(
        first_name="Emily",
        last_name="Johnson",
        email="emily.johnson@example.com",
        phone="555-0456",
        gender=Gender.FEMALE,
        education=[
            {"degree": "Master of Science in Information Technology", "institution": "State University", "year": "2020"}
        ],
        work_history=[
            {"company": "Data Systems Co.", "position": "Data Analyst", "start_date": "2020-01-15", "end_date": "2022-12-31", "description": "Analyzed large datasets and created reports for business insights"},
            {"company": "Analytics Pro", "position": "Senior Data Scientist", "start_date": "2023-01-01", "end_date": "2023-05-31", "description": "Developed machine learning models for predictive analytics"}
        ],
        skills=["Python", "R", "SQL", "Machine Learning", "Tableau", "Data Visualization"],
        certifications=["Certified Data Scientist", "Google Analytics"],
        demographic_info={"nationality": "Canadian", "visa_status": "Permanent Resident"}
    )
    
    resume3 = Resume(
        first_name="Michael",
        last_name="Brown",
        email="michael.brown@example.com",
        phone="555-0789",
        gender=Gender.NON_BINARY,
        education=[
            {"degree": "Bachelor of Science in Software Engineering", "institution": "College of Engineering", "year": "2019"}
        ],
        work_history=[
            {"company": "Web Services Ltd.", "position": "Junior Developer", "start_date": "2019-07-01", "end_date": "2021-06-30", "description": "Built responsive websites using modern web technologies"},
            {"company": "Mobile Apps Inc.", "position": "Software Engineer", "start_date": "2021-07-01", "end_date": "2023-05-31", "description": "Developed mobile applications for iOS and Android platforms"}
        ],
        skills=["React", "Node.js", "React Native", "MongoDB", "Express", "JavaScript"],
        certifications=["Mobile App Development Certificate", "Responsive Web Design"],
        demographic_info={"nationality": "British", "visa_status": "Work Visa"}
    )
    
    # Add resumes to system
    screening_system.add_resume(resume1)
    screening_system.add_resume(resume2)
    screening_system.add_resume(resume3)

def main():
    """Main function to demonstrate the resume screening system"""
    print("=== RESUME SCREENING SYSTEM ===")
    
    # Create screening system
    system = ResumeScreeningSystem()
    
    # Create sample data
    create_sample_data(system)
    
    # Set screening criteria
    criteria = ScreeningCriteria()
    criteria.required_skills = ["Python", "Django", "JavaScript"]
    criteria.required_experience_years = 2
    criteria.required_education_level = "Computer Science"
    criteria.required_certifications = ["AWS Certified Developer"]
    criteria.experience_keywords = ["developed", "led", "built", "created"]
    
    system.set_criteria(criteria)
    
    # Screen all resumes
    print("\nScreening all resumes...")
    results = system.screen_all_resumes()
    
    # Generate and display report
    report = system.generate_screening_report()
    print(report)
    
    # Save resumes to file
    system.save_resumes_to_file("resumes.json")
    print("\nResumes saved to 'resumes.json'")
    
    # Load resumes from file
    new_system = ResumeScreeningSystem()
    new_system.load_resumes_from_file("resumes.json")
    print("Resumes loaded from 'resumes.json'")
    
    # Run screening on loaded data
    new_system.set_criteria(criteria)
    new_results = new_system.screen_all_resumes()
    new_report = new_system.generate_screening_report()
    print("\n=== REPORT FROM LOADED DATA ===")
    print(new_report)

if __name__ == "__main__":
    main()