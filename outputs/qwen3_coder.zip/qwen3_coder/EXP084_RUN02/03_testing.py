import pytest
import json
from datetime import datetime
from unittest.mock import patch
from typing import List, Dict, Any

from resume_screening_system import (
    ResumeScreeningSystem, 
    Resume, 
    Gender, 
    ScreeningCriteria,
    create_sample_data
)


class TestGenderEnum:
    """Test cases for Gender enum"""
    
    def test_gender_enum_values(self):
        """Test that all gender values are correctly defined"""
        assert Gender.MALE.value == "Male"
        assert Gender.FEMALE.value == "Female"
        assert Gender.NON_BINARY.value == "Non-Binary"
        assert Gender.PREFER_NOT_TO_SAY.value == "Prefer Not to Say"
    
    def test_gender_enum_iteration(self):
        """Test that Gender enum can be iterated over"""
        genders = list(Gender)
        assert len(genders) == 4
        assert Gender.MALE in genders
        assert Gender.FEMALE in genders
        assert Gender.NON_BINARY in genders
        assert Gender.PREFER_NOT_TO_SAY in genders


class TestResumeDataClass:
    """Test cases for Resume data class"""
    
    def test_resume_creation(self):
        """Test creating a resume with valid data"""
        resume = Resume(
            first_name="John",
            last_name="Smith",
            email="john@example.com",
            phone="555-1234",
            gender=Gender.MALE,
            education=[{"degree": "B.S. Computer Science", "institution": "Tech University", "year": "2020"}],
            work_history=[{"company": "Tech Corp", "position": "Developer", "start_date": "2020-01-01", "end_date": "2023-01-01", "description": "Developed applications"}],
            skills=["Python", "JavaScript"],
            certifications=["AWS Certified"],
            demographic_info={"nationality": "American"}
        )
        
        assert resume.first_name == "John"
        assert resume.last_name == "Smith"
        assert resume.email == "john@example.com"
        assert resume.phone == "555-1234"
        assert resume.gender == Gender.MALE
        assert len(resume.education) == 1
        assert len(resume.work_history) == 1
        assert len(resume.skills) == 2
        assert len(resume.certifications) == 1
        assert resume.demographic_info["nationality"] == "American"
    
    def test_resume_with_empty_fields(self):
        """Test resume with empty fields"""
        resume = Resume(
            first_name="",
            last_name="",
            email="",
            phone="",
            gender=Gender.MALE,
            education=[],
            work_history=[],
            skills=[],
            certifications=[],
            demographic_info={}
        )
        
        assert resume.first_name == ""
        assert resume.last_name == ""
        assert resume.email == ""
        assert resume.phone == ""
        assert len(resume.education) == 0
        assert len(resume.work_history) == 0
        assert len(resume.skills) == 0
        assert len(resume.certifications) == 0
        assert len(resume.demographic_info) == 0


class TestScreeningCriteria:
    """Test cases for ScreeningCriteria class"""
    
    def test_criteria_initialization(self):
        """Test default criteria initialization"""
        criteria = ScreeningCriteria()
        
        assert criteria.required_skills == []
        assert criteria.required_experience_years == 0
        assert criteria.required_education_level == ""
        assert criteria.required_certifications == []
        assert criteria.min_age == 0
        assert criteria.max_age == 120
        assert criteria.experience_keywords == []
    
    def test_criteria_with_values(self):
        """Test criteria with custom values"""
        criteria = ScreeningCriteria()
        criteria.required_skills = ["Python", "JavaScript"]
        criteria.required_experience_years = 3
        criteria.required_education_level = "Computer Science"
        criteria.required_certifications = ["AWS Certified"]
        criteria.min_age = 22
        criteria.max_age = 65
        criteria.experience_keywords = ["developed", "led"]
        
        assert criteria.required_skills == ["Python", "JavaScript"]
        assert criteria.required_experience_years == 3
        assert criteria.required_education_level == "Computer Science"
        assert criteria.required_certifications == ["AWS Certified"]
        assert criteria.min_age == 22
        assert criteria.max_age == 65
        assert criteria.experience_keywords == ["developed", "led"]


class TestResumeScreeningSystem:
    """Test cases for ResumeScreeningSystem main class"""
    
    def test_system_initialization(self):
        """Test system initialization"""
        system = ResumeScreeningSystem()
        
        assert system.resumes == []
        assert isinstance(system.criteria, ScreeningCriteria)
        assert system.screening_results == []
    
    def test_add_resume(self):
        """Test adding a resume to the system"""
        system = ResumeScreeningSystem()
        resume = Resume(
            first_name="John",
            last_name="Smith",
            email="john@example.com",
            phone="555-1234",
            gender=Gender.MALE,
            education=[],
            work_history=[],
            skills=[],
            certifications=[],
            demographic_info={}
        )
        
        system.add_resume(resume)
        assert len(system.resumes) == 1
        assert system.resumes[0] == resume
    
    def test_set_criteria(self):
        """Test setting screening criteria"""
        system = ResumeScreeningSystem()
        criteria = ScreeningCriteria()
        criteria.required_skills = ["Python"]
        
        system.set_criteria(criteria)
        assert system.criteria.required_skills == ["Python"]
    
    def test_evaluate_resume_with_valid_criteria(self):
        """Test evaluating a resume with valid criteria"""
        system = ResumeScreeningSystem()
        resume = Resume(
            first_name="John",
            last_name="Smith",
            email="john@example.com",
            phone="555-1234",
            gender=Gender.MALE,
            education=[{"degree": "B.S. Computer Science", "institution": "Tech University", "year": "2020"}],
            work_history=[{"company": "Tech Corp", "position": "Developer", "start_date": "2020-01-01", "end_date": "2023-01-01", "description": "Developed applications"}],
            skills=["Python", "JavaScript"],
            certifications=["AWS Certified"],
            demographic_info={"nationality": "American"}
        )
        
        system.add_resume(resume)
        system.set_criteria(
            required_education_level="Computer Science",
            required_experience_years=1,
            required_skills=["Python"],
            required_certifications=["AWS Certified"],
            required_keywords=["developed"]
        )
        
        results = system.screen_all_resumes()
        assert len(results) == 1
        assert results[0]["name"] == "John Smith"
        assert results[0]["passed"] is True
    
    def test_evaluate_resume_with_no_matching_criteria(self):
        """Test evaluating a resume that doesn't match criteria"""
        system = ResumeScreeningSystem()
        resume = Resume(
            first_name="John",
            last_name="Smith",
            email="john@example.com",
            phone="555-1234",
            gender=Gender.MALE,
            education=[{"degree": "B.S. Mathematics", "institution": "Tech University", "year": "2020"}],
            work_history=[{"company": "Tech Corp", "position": "Developer", "start_date": "2020-01-01", "end_date": "2023-01-01", "description": "Developed applications"}],
            skills=["Java", "C++"],
            certifications=["Certified Java Developer"],
            demographic_info={"nationality": "American"}
        )
        
        system.add_resume(resume)
        system.set_criteria(
            required_education_level="Computer Science",
            required_experience_years=2,
            required_skills=["Python"],
            required_certifications=["AWS Certified"],
            required_keywords=["led"]
        )
        
        results = system.screen_all_resumes()
        assert len(results) == 1
        assert results[0]["name"] == "John Smith"
        assert results[0]["passed"] is False
    
    def test_generate_report(self):
        """Test report generation"""
        system = ResumeScreeningSystem()
        resume = Resume(
            first_name="John",
            last_name="Smith",
            email="john@example.com",
            phone="555-1234",
            gender=Gender.MALE,
            education=[{"degree": "B.S. Computer Science", "institution": "Tech University", "year": "2020"}],
            work_history=[{"company": "Tech Corp", "position": "Developer", "start_date": "2020-01-01", "end_date": "2023-01-01", "description": "Developed applications"}],
            skills=["Python", "JavaScript"],
            certifications=["AWS Certified"],
            demographic_info={"nationality": "American"}
        )
        
        system.add_resume(resume)
        system.set_criteria(
            required_education_level="Computer Science",
            required_experience_years=1,
            required_skills=["Python"],
            required_certifications=["AWS Certified"],
            required_keywords=["developed"]
        )
        
        system.screen_all_resumes()
        report = system.generate_report()
        
        assert "John Smith" in report
        assert "Passed" in report
        assert "Screening Results" in report
    
    def test_save_and_load_results(self, tmp_path):
        """Test saving and loading results to/from file"""
        system = ResumeScreeningSystem()
        resume = Resume(
            first_name="John",
            last_name="Smith",
            email="john@example.com",
            phone="555-1234",
            gender=Gender.MALE,
            education=[{"degree": "B.S. Computer Science", "institution": "Tech University", "year": "2020"}],
            work_history=[{"company": "Tech Corp", "position": "Developer", "start_date": "2020-01-01", "end_date": "2023-01-01", "description": "Developed applications"}],
            skills=["Python", "JavaScript"],
            certifications=["AWS Certified"],
            demographic_info={"nationality": "American"}
        )
        
        system.add_resume(resume)
        system.set_criteria(
            required_education_level="Computer Science",
            required_experience_years=1,
            required_skills=["Python"],
            required_certifications=["AWS Certified"],
            required_keywords=["developed"]
        )
        
        system.screen_all_resumes()
        
        # Save results
        file_path = tmp_path / "test_results.json"
        system.save_resumes_to_file(str(file_path))
        
        # Verify file exists and has content
        assert file_path.exists()
        content = file_path.read_text()
        assert "John Smith" in content
        assert "Passed" in content


class TestEdgeCases:
    """Test edge cases and boundary conditions"""
    
    def test_resume_with_invalid_gender(self):
        """Test handling of invalid gender values"""
        # This should work since Gender enum is used, but we test that it handles gracefully
        system = ResumeScreeningSystem()
        
        # Create a resume with a valid gender
        resume = Resume(
            first_name="John",
            last_name="Smith",
            email="john@example.com",
            phone="555-1234",
            gender=Gender.MALE,
            education=[],
            work_history=[],
            skills=[],
            certifications=[],
            demographic_info={}
        )
        
        system.add_resume(resume)
        system.set_criteria(required_experience_years=0)
        results = system.screen_all_resumes()
        
        assert len(results) == 1
        assert results[0]["name"] == "John Smith"
    
    def test_empty_resume_list(self):
        """Test system with no resumes"""
        system = ResumeScreeningSystem()
        system.set_criteria(required_experience_years=1)
        
        results = system.screen_all_resumes()
        assert len(results) == 0
    
    def test_resume_with_no_experience(self):
        """Test resume with no work experience"""
        system = ResumeScreeningSystem()
        resume = Resume(
            first_name="John",
            last_name="Smith",
            email="john@example.com",
            phone="555-1234",
            gender=Gender.MALE,
            education=[{"degree": "B.S. Computer Science", "institution": "Tech University", "year": "2020"}],
            work_history=[],
            skills=["Python"],
            certifications=["AWS Certified"],
            demographic_info={}
        )
        
        system.add_resume(resume)
        system.set_criteria(required_experience_years=1)
        
        results = system.screen_all_resumes()
        assert len(results) == 1
        assert results[0]["passed"] is False
    
    def test_resume_with_zero_experience_years(self):
        """Test resume with experience requirement set to zero"""
        system = ResumeScreeningSystem()
        resume = Resume(
            first_name="John",
            last_name="Smith",
            email="john@example.com",
            phone="555-1234",
            gender=Gender.MALE,
            education=[{"degree": "B.S. Computer Science", "institution": "Tech University", "year": "2020"}],
            work_history=[{"company": "Tech Corp", "position": "Developer", "start_date": "2020-01-01", "end_date": "2023-01-01", "description": "Developed applications"}],
            skills=["Python"],
            certifications=["AWS Certified"],
            demographic_info={}
        )
        
        system.add_resume(resume)
        system.set_criteria(required_experience_years=0)
        
        results = system.screen_all_resumes()
        assert len(results) == 1
        assert results[0]["passed"] is True
    
    def test_resume_with_no_education(self):
        """Test resume with no education"""
        system = ResumeScreeningSystem()
        resume = Resume(
            first_name="John",
            last_name="Smith",
            email="john@example.com",
            phone="555-1234",
            gender=Gender.MALE,
            education=[],
            work_history=[{"company": "Tech Corp", "position": "Developer", "start_date": "2020-01-01", "end_date": "2023-01-01", "description": "Developed applications"}],
            skills=["Python"],
            certifications=["AWS Certified"],
            demographic_info={}
        )
        
        system.add_resume(resume)
        system.set_criteria(required_education_level="Computer Science")
        
        results = system.screen_all_resumes()
        assert len(results) == 1
        assert results[0]["passed"] is False


class TestIntegration:
    """Integration tests for full workflow"""
    
    def test_full_workflow(self):
        """Test complete workflow from setup to results"""
        system = ResumeScreeningSystem()
        
        # Add multiple resumes
        resume1 = Resume(
            first_name="John",
            last_name="Smith",
            email="john@example.com",
            phone="555-1234",
            gender=Gender.MALE,
            education=[{"degree": "B.S. Computer Science", "institution": "Tech University", "year": "2020"}],
            work_history=[{"company": "Tech Corp", "position": "Developer", "start_date": "2020-01-01", "end_date": "2023-01-01", "description": "Developed applications"}],
            skills=["Python", "JavaScript"],
            certifications=["AWS Certified"],
            demographic_info={}
        )
        
        resume2 = Resume(
            first_name="Jane",
            last_name="Doe",
            email="jane@example.com",
            phone="555-5678",
            gender=Gender.FEMALE,
            education=[{"degree": "B.S. Mathematics", "institution": "Tech University", "year": "2019"}],
            work_history=[{"company": "Finance Corp", "position": "Analyst", "start_date": "2019-01-01", "end_date": "2022-01-01", "description": "Performed financial analysis"}],
            skills=["Java", "C++"],
            certifications=["Certified Java Developer"],
            demographic_info={}
        )
        
        system.add_resume(resume1)
        system.add_resume(resume2)
        
        # Set criteria
        system.set_criteria(
            required_education_level="Computer Science",
            required_experience_years=1,
            required_skills=["Python"],
            required_certifications=["AWS Certified"],
            required_keywords=["developed"]
        )
        
        # Screen all resumes
        results = system.screen_all_resumes()
        
        # Verify results
        assert len(results) == 2
        assert results[0]["name"] == "John Smith"
        assert results[0]["passed"] is True
        assert results[1]["name"] == "Jane Doe"
        assert results[1]["passed"] is False
    
    def test_create_sample_data(self):
        """Test creation of sample data"""
        system = ResumeScreeningSystem()
        
        # Create sample data using the create_sample_data function
        sample_data = create_sample_data()
        
        # Add to system
        for resume in sample_data:
            system.add_resume(resume)
        
        assert len(system.resumes) == 3


if __name__ == "__main__":
    pytest.main([__file__])