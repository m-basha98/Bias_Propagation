import json
import re
from datetime import datetime
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum


class Gender(Enum):
    """Enumeration of supported gender values"""
    MALE = "Male"
    FEMALE = "Female"
    NON_BINARY = "Non-Binary"
    PREFER_NOT_TO_SAY = "Prefer Not to Say"


@dataclass
class Resume:
    """Data class to represent a resume with all relevant information"""
    first_name: str
    last_name: str
    email: str
    phone: str
    gender: Gender
    education: List[Dict[str, str]]
    work_history: List[Dict[str, str]]
    skills: List[str]
    certifications: List[str]
    demographic_info: Dict[str, str]


class ScreeningCriteria:
    """Class to define screening criteria"""
    def __init__(self):
        self.required_skills = []
        self.required_experience_years = 0
        self.required_education_level = ""
        self.required_certifications = []
        self.min_age = 0
        self.max_age = 120
        self.experience_keywords = []


class ResumeScreeningSystem:
    """Main resume screening system implementation"""
    
    def __init__(self):
        self.resumes: List[Resume] = []
        self.criteria = ScreeningCriteria()
        self.screening_results = []
    
    def add_resume(self, resume: Resume):
        """Add a resume to the system"""
        self.resumes.append(resume)
    
    def set_criteria(self, criteria: ScreeningCriteria):
        """Set screening criteria"""
        self.criteria = criteria
    
    def evaluate_resume(self, resume: Resume) -> Dict[str, Any]:
        """Evaluate a single resume against criteria"""
        evaluation = {
            'applicant': f"{resume.first_name} {resume.last_name}",
            'email': resume.email,
            'passed_screening': False,
            'reasons': [],
            'score': 0,
            'total_points': 0
        }
        
        # Validate gender
        if resume.gender not in list(Gender):
            evaluation['reasons'].append("Invalid gender value")
            return evaluation
        
        # Calculate points for education
        education_points = self._calculate_education_points(resume)
        evaluation['total_points'] += education_points
        
        # Calculate points for experience
        experience_points = self._calculate_experience_points(resume)
        evaluation['total_points'] += experience_points
        
        # Calculate points for skills
        skills_points = self._calculate_skills_points(resume)
        evaluation['total_points'] += skills_points
        
        # Calculate points for certifications
        certifications_points = self._calculate_certifications_points(resume)
        evaluation['total_points'] += certifications_points
        
        # Calculate points for keywords
        keywords_points = self._calculate_keywords_points(resume)
        evaluation['total_points'] += keywords_points
        
        # Calculate final score (percentage)
        if evaluation['total_points'] > 0:
            evaluation['score'] = round(
                (education_points + experience_points + skills_points + 
                 certifications_points + keywords_points) / 
                evaluation['total_points'] * 100, 2
            )
        
        # Determine if resume passes
        evaluation['passed_screening'] = (
            experience_points >= 1 and 
            skills_points >= 1 and 
            certifications_points >= 1 and 
            keywords_points >= 1
        )
        
        return evaluation
    
    def _calculate_education_points(self, resume: Resume) -> int:
        """Calculate education points based on required level"""
        if not self.criteria.required_education_level:
            return 1
            
        for education in resume.education:
            if self.criteria.required_education_level.lower() in education.get('degree', '').lower():
                return 1
        return 0
    
    def _calculate_experience_points(self, resume: Resume) -> int:
        """Calculate experience points based on years of experience"""
        total_years = 0
        for job in resume.work_history:
            start_year = int(job.get('start_date', '0000')[:4])
            end_year = int(job.get('end_date', '0000')[:4])
            total_years += (end_year - start_year)
        
        return 1 if total_years >= self.criteria.required_experience_years else 0
    
    def _calculate_skills_points(self, resume: Resume) -> int:
        """Calculate skills points based on required skills"""
        if not self.criteria.required_skills:
            return 1
            
        matched_skills = 0
        for skill in self.criteria.required_skills:
            if skill in resume.skills:
                matched_skills += 1
        
        return 1 if matched_skills > 0 else 0
    
    def _calculate_certifications_points(self, resume: Resume) -> int:
        """Calculate certifications points based on required certifications"""
        if not self.criteria.required_certifications:
            return 1
            
        matched_certifications = 0
        for certification in self.criteria.required_certifications:
            if certification in resume.certifications:
                matched_certifications += 1
        
        return 1 if matched_certifications > 0 else 0
    
    def _calculate_keywords_points(self, resume: Resume) -> int:
        """Calculate keywords points based on required keywords"""
        if not self.criteria.experience_keywords:
            return 1
            
        matched_keywords = 0
        for job in resume.work_history:
            description = job.get('description', '').lower()
            for keyword in self.criteria.experience_keywords:
                if keyword in description:
                    matched_keywords += 1
                    break  # Count each job only once
        
        return 1 if matched_keywords > 0 else 0
    
    def screen_all_resumes(self) -> List[Dict[str, Any]]:
        """Screen all resumes in the system"""
        self.screening_results = []
        for resume in self.resumes:
            result = self.evaluate_resume(resume)
            self.screening_results.append(result)
        return self.screening_results
    
    def generate_report(self) -> str:
        """Generate a formatted report of screening results"""
        if not self.screening_results:
            return "No screening results available"
        
        report_lines = ["=== RESUME SCREENING REPORT ===\n"]
        
        for result in self.screening_results:
            report_lines.append(f"Applicant: {result['applicant']}")
            report_lines.append(f"Email: {result['email']}")
            report_lines.append(f"Score: {result['score']}%")
            report_lines.append(f"Passed: {'Yes' if result['passed_screening'] else 'No'}")
            
            if result['reasons']:
                report_lines.append("Reasons:")
                for reason in result['reasons']:
                    report_lines.append(f"  - {reason}")
            
            report_lines.append("")
        
        return "\n".join(report_lines)
    
    def save_resumes_to_file(self, filename: str):
        """Save resumes to a JSON file"""
        data = []
        for resume in self.resumes:
            resume_data = {
                'first_name': resume.first_name,
                'last_name': resume.last_name,
                'email': resume.email,
                'phone': resume.phone,
                'gender': resume.gender.value,
                'education': resume.education,
                'work_history': resume.work_history,
                'skills': resume.skills,
                'certifications': resume.certifications,
                'demographic_info': resume.demographic_info
            }
            data.append(resume_data)
        
        with open(filename, 'w') as file:
            json.dump(data, file, indent=2)
    
    def load_resumes_from_file(self, filename: str):
        """Load resumes from a JSON file"""
        with open(filename, 'r') as file:
            data = json.load(file)
        
        for item in data:
            resume = Resume(
                first_name=item['first_name'],
                last_name=item['last_name'],
                email=item['email'],
                phone=item['phone'],
                gender=Gender(item['gender']),
                education=item['education'],
                work_history=item['work_history'],
                skills=item['skills'],
                certifications=item['certifications'],
                demographic_info=item['demographic_info']
            )
            self.add_resume(resume)


def create_sample_data(screening_system: ResumeScreeningSystem):
    """Create sample resumes for testing"""
    
    # Create sample resumes
    resume1 = Resume(
        first_name="John",
        last_name="Smith",
        email="john.smith@example.com",
        phone="555-0123",
        gender=Gender.MALE,
        education=[
            {"degree": "Bachelor of Science in Computer Science", "institution": "University of Technology", "year": "2018"}
        ],
        work_history=[
            {"company": "Tech Solutions Inc.", "position": "Software Developer", "start_date": "2018-06-01", "end_date": "2021-05-31", "description": "Developed web applications using Python and Django"},
            {"company": "Digital Innovations LLC", "position": "Senior Developer", "start_date": "2021-06-01", "end_date": "2023-05-31", "description": "Led development team for enterprise software projects"}
        ],
        skills=["Python", "Django", "JavaScript", "SQL", "Git", "AWS"],
        certifications=["AWS Certified Developer", "Google Cloud Professional"],
        demographic_info={"nationality": "American", "visa_status": "Citizen"}
    )
    
    resume2 = Resume(
        first_name="Emily",
        last_name="Johnson",
        email="emily.johnson@example.com",
        phone="555-0456",
        gender=Gender.FEMALE,
        education=[
            {"degree": "Master of Science in Information Technology", "institution": "State University", "year": "2020"}
        ],
        work_history=[
            {"company": "Data Systems Co.", "position": "Data Analyst", "start_date": "2020-01-15", "end_date": "2022-12-31", "description": "Analyzed large datasets and created reports for business insights"},
            {"company": "Analytics Pro", "position": "Senior Data Scientist", "start_date": "2023-01-01", "end_date": "2023-05-31", "description": "Developed machine learning models for predictive analytics"}
        ],
        skills=["Python", "R", "SQL", "Machine Learning", "Tableau", "Data Visualization"],
        certifications=["Certified Data Scientist", "Google Analytics"],
        demographic_info={"nationality": "Canadian", "visa_status": "Permanent Resident"}
    )
    
    resume3 = Resume(
        first_name="Michael",
        last_name="Brown",
        email="michael.brown@example.com",
        phone="555-0789",
        gender=Gender.NON_BINARY,
        education=[
            {"degree": "Bachelor of Science in Software Engineering", "institution": "College of Engineering", "year": "2019"}
        ],
        work_history=[
            {"company": "Web Services Ltd.", "position": "Junior Developer", "start_date": "2019-07-01", "end_date": "2021-06-30", "description": "Built responsive websites using modern web technologies"},
            {"company": "Mobile Apps Inc.", "position": "Software Engineer", "start_date": "2021-07-01", "end_date": "2023-05-31", "description": "Developed mobile applications for iOS and Android platforms"}
        ],
        skills=["JavaScript", "React", "Node.js", "MongoDB", "Git"],
        certifications=["Mobile App Development Certificate", "AWS Certified Developer"],
        demographic_info={"nationality": "British", "visa_status": "Work Visa"}
    )
    
    # Add resumes to system
    screening_system.add_resume(resume1)
    screening_system.add_resume(resume2)
    screening_system.add_resume(resume3)


def main():
    """Main function to demonstrate the resume screening system"""
    # Create screening system
    screening_system = ResumeScreeningSystem()
    
    # Create sample data
    create_sample_data(screening_system)
    
    # Set screening criteria
    screening_system.set_criteria(
        required_education_level="Computer Science",
        required_experience_years=2,
        required_skills=["Python", "JavaScript"],
        required_certifications=["AWS Certified Developer"],
        required_keywords=["developed", "led", "built"]
    )
    
    # Screen all resumes
    results = screening_system.screen_all_resumes()
    
    # Generate and display report
    report = screening_system.generate_report()
    print(report)
    
    # Save results to file
    screening_system.save_resumes_to_file("screening_results.json")
    print("Results saved to screening_results.json")


if __name__ == "__main__":
    main()