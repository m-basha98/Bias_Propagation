import json
import csv
from datetime import datetime
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from enum import Enum

class Gender(Enum):
    MALE = "Male"
    FEMALE = "Female"
    NON_BINARY = "Non-Binary"
    PREFER_NOT_TO_SAY = "Prefer Not to Say"
    OTHER = "Other"

@dataclass
class Candidate:
    """Data class to represent a candidate"""
    id: str
    name: str
    email: str
    gender: Gender
    education: List[Dict[str, Any]]
    experience: List[Dict[str, Any]]
    skills: List[str]
    certifications: List[Dict[str, Any]]
    demographic_info: Dict[str, Any]
    created_at: datetime = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now()

class CandidateRankingSystem:
    """Main system for ranking candidates based on multiple criteria"""
    
    def __init__(self):
        self.candidates: List[Candidate] = []
        self.weights = {
            'education': 0.25,
            'experience': 0.30,
            'skills': 0.25,
            'certifications': 0.20
        }
    
    def add_candidate(self, candidate: Candidate):
        """Add a candidate to the system"""
        self.candidates.append(candidate)
    
    def _calculate_education_score(self, education: List[Dict[str, Any]]) -> float:
        """Calculate education score based on degree levels and institutions"""
        if not education:
            return 0.0
            
        score = 0.0
        degree_weights = {
            'PhD': 10.0,
            'Master': 8.0,
            'Bachelor': 6.0,
            'Associate': 4.0,
            'Certificate': 2.0
        }
        
        for edu in education:
            degree = edu.get('degree', '').lower()
            institution = edu.get('institution', '')
            
            # Base score from degree level
            degree_score = degree_weights.get(degree, 0.0)
            score += degree_score
            
            # Bonus for prestigious institutions (simplified)
            if institution and 'harvard' in institution.lower() or 'stanford' in institution.lower():
                score += 3.0
                
        return min(score, 10.0)  # Cap at 10.0
    
    def _calculate_experience_score(self, experience: List[Dict[str, Any]]) -> float:
        """Calculate experience score based on years and roles"""
        if not experience:
            return 0.0
            
        total_years = 0
        role_scores = {
            'Senior': 5.0,
            'Lead': 4.0,
            'Manager': 3.0,
            'Specialist': 2.0,
            'Junior': 1.0
        }
        
        for exp in experience:
            years = exp.get('years', 0)
            role = exp.get('role', '').lower()
            
            total_years += years
            
            # Role-based bonus
            role_bonus = 0.0
            for role_key, bonus in role_scores.items():
                if role_key in role:
                    role_bonus = bonus
                    break
                    
            # Add bonus for long experience
            if years >= 10:
                total_years += 5.0
            elif years >= 5:
                total_years += 3.0
                
        # Normalize to 10.0 scale
        return min(total_years * 0.5, 10.0)
    
    def _calculate_skills_score(self, skills: List[str]) -> float:
        """Calculate skills score based on quantity and relevance"""
        if not skills:
            return 0.0
            
        # Define high-value skills (simplified for demo)
        high_value_skills = {
            'python', 'java', 'javascript', 'sql', 'machine learning',
            'data analysis', 'project management', 'leadership', 'communication'
        }
        
        skill_count = len(skills)
        high_value_count = sum(1 for skill in skills if skill.lower() in high_value_skills)
        
        # Base score from quantity
        score = skill_count * 0.5
        
        # Bonus for high-value skills
        score += high_value_count * 1.5
        
        return min(score, 10.0)
    
    def _calculate_certifications_score(self, certifications: List[Dict[str, Any]]) -> float:
        """Calculate certification score based on number and type"""
        if not certifications:
            return 0.0
            
        score = 0.0
        cert_weights = {
            'Professional': 3.0,
            'Advanced': 4.0,
            'Expert': 5.0,
            'Master': 6.0
        }
        
        for cert in certifications:
            cert_type = cert.get('type', '').lower()
            name = cert.get('name', '').lower()
            
            # Base score from certification type
            cert_score = cert_weights.get(cert_type, 2.0)
            score += cert_score
            
            # Bonus for specific certifications
            if 'aws' in name or 'azure' in name or 'google cloud' in name:
                score += 2.0
                
        return min(score, 10.0)
    
    def _calculate_candidate_score(self, candidate: Candidate) -> float:
        """Calculate overall score for a candidate"""
        education_score = self._calculate_education_score(candidate.education)
        experience_score = self._calculate_experience_score(candidate.experience)
        skills_score = self._calculate_skills_score(candidate.skills)
        certifications_score = self._calculate_certifications_score(candidate.certifications)
        
        # Weighted total
        total_score = (
            education_score * self.weights['education'] +
            experience_score * self.weights['experience'] +
            skills_score * self.weights['skills'] +
            certifications_score * self.weights['certifications']
        )
        
        return round(total_score, 2)
    
    def rank_candidates(self) -> List[Tuple[Candidate, float]]:
        """Rank all candidates by their scores"""
        scores = []
        for candidate in self.candidates:
            score = self._calculate_candidate_score(candidate)
            scores.append((candidate, score))
        
        # Sort by score descending
        return sorted(scores, key=lambda x: x[1], reverse=True)
    
    def get_shortlist(self, top_n: int = 5) -> List[Tuple[Candidate, float]]:
        """Get the top N candidates as a shortlist"""
        ranked = self.rank_candidates()
        return ranked[:top_n]
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of the ranking process"""
        if not self.candidates:
            return {"message": "No candidates to rank"}
        
        ranked = self.rank_candidates()
        top_candidates = self.get_shortlist(3)
        
        # Gender distribution
        gender_counts = {}
        for candidate in self.candidates:
            gender = candidate.gender.value
            gender_counts[gender] = gender_counts.get(gender, 0) + 1
        
        # Overall statistics
        scores = [score for _, score in ranked]
        avg_score = round(sum(scores) / len(scores), 2)
        max_score = max(scores)
        min_score = min(scores)
        
        report = {
            "timestamp": datetime.now().isoformat(),
            "total_candidates": len(self.candidates),
            "average_score": avg_score,
            "max_score": max_score,
            "min_score": min_score,
            "gender_distribution": gender_counts,
            "top_candidates": [
                {
                    "id": candidate.id,
                    "name": candidate.name,
                    "score": score,
                    "gender": candidate.gender.value
                }
                for candidate, score in top_candidates
            ],
            "weights_used": self.weights
        }
        
        return report
    
    def export_ranking_results(self, filename: str = "ranking_results.csv"):
        """Export ranking results to CSV file"""
        ranked = self.rank_candidates()
        
        with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['id', 'name', 'email', 'gender', 'score', 'total_education', 'total_experience', 'total_skills', 'total_certifications']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            writer.writeheader()
            for candidate, score in ranked:
                writer.writerow({
                    'id': candidate.id,
                    'name': candidate.name,
                    'email': candidate.email,
                    'gender': candidate.gender.value,
                    'score': score,
                    'total_education': len(candidate.education),
                    'total_experience': len(candidate.experience),
                    'total_skills': len(candidate.skills),
                    'total_certifications': len(candidate.certifications)
                })
    
    def export_summary_report(self, filename: str = "ranking_summary.json"):
        """Export summary report to JSON file"""
        report = self.generate_summary_report()
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, default=str)

# Example usage and demonstration
def demo_application():
    """Demonstrate the candidate ranking system"""
    # Initialize the system
    system = CandidateRankingSystem()
    
    # Create sample candidates
    candidate1 = Candidate(
        id="C001",
        name="Alice Johnson",
        email="alice.johnson@example.com",
        gender=Gender.FEMALE,
        education=[
            {"degree": "Master", "institution": "Stanford University", "field": "Computer Science"},
            {"degree": "Bachelor", "institution": "University of California", "field": "Mathematics"}
        ],
        experience=[
            {"years": 5, "role": "Senior Software Engineer", "company": "Tech Corp"},
            {"years": 2, "role": "Software Developer", "company": "Startup Inc"}
        ],
        skills=["Python", "JavaScript", "SQL", "Machine Learning", "Project Management"],
        certifications=[
            {"name": "AWS Certified Solutions Architect", "type": "Professional"},
            {"name": "Google Cloud Professional Data Engineer", "type": "Advanced"}
        ],
        demographic_info={"age": 32, "location": "San Francisco"}
    )
    
    candidate2 = Candidate(
        id="C002",
        name="Bob Smith",
        email="bob.smith@example.com",
        gender=Gender.MALE,
        education=[
            {"degree": "Bachelor", "institution": "MIT", "field": "Computer Engineering"},
            {"degree": "Certificate", "institution": "Coursera", "field": "Data Science"}
        ],
        experience=[
            {"years": 7, "role": "Lead Developer", "company": "Innovate Inc"},
            {"years": 3, "role": "Software Engineer", "company": "Tech Solutions"}
        ],
        skills=["Java", "Python", "SQL", "Data Analysis", "Leadership"],
        certifications=[
            {"name": "Certified Scrum Master", "type": "Professional"},
            {"name": "Azure Developer Associate", "type": "Advanced"}
        ],
        demographic_info={"age": 35, "location": "New York"}
    )
    
    candidate3 = Candidate(
        id="C003",
        name="Carol Williams",
        email="carol.williams@example.com",
        gender=Gender.FEMALE,
        education=[
            {"degree": "PhD", "institution": "Harvard University", "field": "Artificial Intelligence"},
            {"degree": "Master", "institution": "University of Cambridge", "field": "Computer Science"}
        ],
        experience=[
            {"years": 8, "role": "Research Scientist", "company": "AI Research Lab"},
            {"years": 4, "role": "Senior Researcher", "company": "Tech Research"}
        ],
        skills=["Python", "TensorFlow", "PyTorch", "Research", "Machine Learning"],
        certifications=[
            {"name": "Google Deep Learning Professional", "type": "Expert"},
            {"name": "AWS Certified Machine Learning", "type": "Advanced"}
        ],
        demographic_info={"age": 38, "location": "Boston"}
    )
    
    # Add candidates to system
    system.add_candidate(candidate1)
    system.add_candidate(candidate2)
    system.add_candidate(candidate3)
    
    # Rank candidates
    print("=== CANDIDATE RANKING RESULTS ===")
    ranked = system.rank_candidates()
    
    for i, (candidate, score) in enumerate(ranked, 1):
        print(f"{i}. {candidate.name} (Score: {score})")
    
    print("\n=== SHORTLIST (Top 3) ===")
    shortlist = system.get_shortlist(3)
    for i, (candidate, score) in enumerate(shortlist, 1):
        print(f"{i}. {candidate.name} - Score: {score} - Gender: {candidate.gender.value}")
    
    print("\n=== RANKING SUMMARY REPORT ===")
    report = system.generate_summary_report()
    print(f"Total Candidates: {report['total_candidates']}")
    print(f"Average Score: {report['average_score']}")
    print(f"Max Score: {report['max_score']}")
    print(f"Min Score: {report['min_score']}")
    print("Gender Distribution:")
    for gender, count in report['gender_distribution'].items():
        print(f"  {gender}: {count}")
    
    print("\n=== TOP 3 CANDIDATES ===")
    for i, candidate_info in enumerate(report['top_candidates'], 1):
        print(f"{i}. {candidate_info['name']} - Score: {candidate_info['score']} - Gender: {candidate_info['gender']}")
    
    # Export results
    system.export_ranking_results("ranking_results.csv")
    system.export_summary_report("ranking_summary.json")
    
    print("\n=== EXPORTED FILES ===")
    print("1. ranking_results.csv - Detailed ranking results")
    print("2. ranking_summary.json - Summary report")
    
    return system

if __name__ == "__main__":
    # Run the demonstration
    system = demo_application()
    
    # Example of adding a new candidate
    print("\n=== ADDING NEW CANDIDATE ===")
    new_candidate = Candidate(
        id="C004",
        name="David Brown",
        email="david.brown@example.com",
        gender=Gender.MALE,
        education=[
            {"degree": "Bachelor", "institution": "University of Texas", "field": "Software Engineering"}
        ],
        experience=[
            {"years": 3, "role": "Junior Developer", "company": "Web Solutions"}
        ],
        skills=["Python", "JavaScript", "SQL"],
        certifications=[],
        demographic_info={"age": 28, "location": "Austin"}
    )
    
    system.add_candidate(new_candidate)
    
    # Re-rank after adding new candidate
    print("New ranking after adding David Brown:")
    ranked = system.rank_candidates()
    for i, (candidate, score) in enumerate(ranked, 1):
        print(f"{i}. {candidate.name} (Score: {score})")