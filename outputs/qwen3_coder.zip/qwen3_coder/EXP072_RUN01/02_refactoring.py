import json
import csv
from datetime import datetime
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from enum import Enum


class Gender(Enum):
    """Enumeration for gender values"""
    MALE = "Male"
    FEMALE = "Female"
    NON_BINARY = "Non-Binary"
    PREFER_NOT_TO_SAY = "Prefer Not to Say"
    OTHER = "Other"


@dataclass
class Candidate:
    """Data class to represent a candidate"""
    id: str
    name: str
    email: str
    gender: Gender
    education: List[Dict[str, Any]]
    experience: List[Dict[str, Any]]
    skills: List[str]
    certifications: List[Dict[str, Any]]
    demographic_info: Dict[str, Any]
    created_at: datetime = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now()


class CandidateRankingSystem:
    """Main system for ranking candidates based on multiple criteria"""
    
    def __init__(self):
        self.candidates: List[Candidate] = []
        self.weights = {
            'education': 0.25,
            'experience': 0.30,
            'skills': 0.25,
            'certifications': 0.20
        }
    
    def add_candidate(self, candidate: Candidate):
        """Add a candidate to the system"""
        self.candidates.append(candidate)
    
    def _calculate_education_score(self, education: List[Dict[str, Any]]) -> float:
        """Calculate education score based on degree levels and institutions"""
        if not education:
            return 0.0
            
        score = 0.0
        degree_weights = {
            'phd': 10.0,
            'master': 8.0,
            'bachelor': 6.0,
            'associate': 4.0,
            'certificate': 2.0
        }
        
        for education_item in education:
            degree = education_item.get('degree', '').lower()
            institution = education_item.get('institution', '')
            
            # Base score from degree level
            degree_score = degree_weights.get(degree, 0.0)
            score += degree_score
            
            # Bonus for prestigious institutions (simplified)
            if institution and ('harvard' in institution.lower() or 'stanford' in institution.lower()):
                score += 3.0
                
        return min(score, 10.0)  # Cap at 10.0
    
    def _calculate_experience_score(self, experience: List[Dict[str, Any]]) -> float:
        """Calculate experience score based on years and roles"""
        if not experience:
            return 0.0
            
        total_years = 0
        role_scores = {
            'senior': 5.0,
            'lead': 4.0,
            'manager': 3.0,
            'developer': 2.0,
            'engineer': 2.0
        }
        
        for experience_item in experience:
            years = experience_item.get('years', 0)
            role = experience_item.get('role', '').lower()
            
            # Base years
            total_years += years
            
            # Additional score based on role
            for role_key, role_value in role_scores.items():
                if role_key in role:
                    total_years += role_value
                    break
                
        return total_years
    
    def _calculate_skills_score(self, skills: List[str]) -> float:
        """Calculate skills score"""
        return len(skills)
    
    def _calculate_certifications_score(self, certifications: List[Dict[str, Any]]) -> float:
        """Calculate certifications score"""
        return len(certifications)
    
    def _calculate_candidate_score(self, candidate: Candidate) -> float:
        """Calculate total score for a candidate"""
        education_score = self._calculate_education_score(candidate.education)
        experience_score = self._calculate_experience_score(candidate.experience)
        skills_score = self._calculate_skills_score(candidate.skills)
        certifications_score = self._calculate_certifications_score(candidate.certifications)
        
        total_score = (
            education_score * self.weights['education'] +
            experience_score * self.weights['experience'] +
            skills_score * self.weights['skills'] +
            certifications_score * self.weights['certifications']
        )
        
        return round(total_score, 2)
    
    def rank_candidates(self) -> List[Tuple[Candidate, float]]:
        """Rank all candidates by their scores"""
        scores = []
        for candidate in self.candidates:
            score = self._calculate_candidate_score(candidate)
            scores.append((candidate, score))
        
        # Sort by score in descending order
        return sorted(scores, key=lambda x: x[1], reverse=True)
    
    def get_shortlist(self, count: int = 3) -> List[Tuple[Candidate, float]]:
        """Get the top candidates from the ranking"""
        ranked = self.rank_candidates()
        return ranked[:count]
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of the ranking"""
        if not self.candidates:
            return {
                'total_candidates': 0,
                'average_score': 0,
                'max_score': 0,
                'min_score': 0,
                'gender_distribution': {}
            }
        
        ranked = self.rank_candidates()
        scores = [score for _, score in ranked]
        
        # Calculate gender distribution
        gender_distribution = {}
        for candidate in self.candidates:
            gender = candidate.gender.value
            gender_distribution[gender] = gender_distribution.get(gender, 0) + 1
        
        return {
            'total_candidates': len(self.candidates),
            'average_score': round(sum(scores) / len(scores), 2),
            'max_score': max(scores),
            'min_score': min(scores),
            'gender_distribution': gender_distribution,
            'top_candidates': [
                {
                    'name': candidate.name,
                    'score': score,
                    'gender': candidate.gender.value
                }
                for candidate, score in ranked[:3]
            ]
        }
    
    def export_ranking_results(self, filename: str = "ranking_results.csv"):
        """Export detailed ranking results to CSV"""
        ranked = self.rank_candidates()
        
        with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = [
                'rank', 'id', 'name', 'email', 'gender', 'score',
                'education_count', 'experience_count', 'skills_count', 'certifications_count'
            ]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            writer.writeheader()
            for rank, (candidate, score) in enumerate(ranked, 1):
                writer.writerow({
                    'rank': rank,
                    'id': candidate.id,
                    'name': candidate.name,
                    'email': candidate.email,
                    'gender': candidate.gender.value,
                    'score': score,
                    'education_count': len(candidate.education),
                    'experience_count': len(candidate.experience),
                    'skills_count': len(candidate.skills),
                    'certifications_count': len(candidate.certifications)
                })
    
    def export_summary_report(self, filename: str = "ranking_summary.json"):
        """Export summary report to JSON file"""
        report = self.generate_summary_report()
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, default=str)


def demo_application():
    """Demonstrate the candidate ranking system"""
    # Initialize the system
    system = CandidateRankingSystem()
    
    # Create sample candidates
    candidate1 = Candidate(
        id="C001",
        name="Alice Johnson",
        email="alice.johnson@example.com",
        gender=Gender.FEMALE,
        education=[
            {"degree": "Master", "institution": "Stanford University", "field": "Computer Science"},
            {"degree": "Bachelor", "institution": "University of California", "field": "Mathematics"}
        ],
        experience=[
            {"years": 5, "role": "Senior Software Engineer", "company": "Tech Corp"},
            {"years": 2, "role": "Software Developer", "company": "Startup Inc"}
        ],
        skills=["Python", "JavaScript", "SQL", "Machine Learning", "Project Management"],
        certifications=[
            {"name": "AWS Certified Solutions Architect", "type": "Professional"},
            {"name": "Google Cloud Professional Data Engineer", "type": "Advanced"}
        ],
        demographic_info={"age": 32, "location": "San Francisco"}
    )
    
    candidate2 = Candidate(
        id="C002",
        name="Bob Smith",
        email="bob.smith@example.com",
        gender=Gender.MALE,
        education=[
            {"degree": "Bachelor", "institution": "MIT", "field": "Computer Engineering"},
            {"degree": "Certificate", "institution": "Coursera", "field": "Data Science"}
        ],
        experience=[
            {"years": 7, "role": "Lead Developer", "company": "Innovate Inc"},
            {"years": 3, "role": "Software Engineer", "company": "Tech Solutions"}
        ],
        skills=["Java", "Python", "SQL", "Data Analysis", "Leadership"],
        certifications=[
            {"name": "Certified Scrum Master", "type": "Professional"},
            {"name": "Azure Developer Associate", "type": "Advanced"}
        ],
        demographic_info={"age": 35, "location": "New York"}
    )
    
    candidate3 = Candidate(
        id="C003",
        name="Carol Williams",
        email="carol.williams@example.com",
        gender=Gender.FEMALE,
        education=[
            {"degree": "PhD", "institution": "Harvard University", "field": "Artificial Intelligence"},
            {"degree": "Master", "institution": "University of Cambridge", "field": "Computer Science"}
        ],
        experience=[
            {"years": 8, "role": "Research Scientist", "company": "AI Research Lab"},
            {"years": 4, "role": "Senior Researcher", "company": "Tech Research"}
        ],
        skills=["Python", "TensorFlow", "PyTorch", "Research", "Machine Learning"],
        certifications=[
            {"name": "Google Deep Learning Professional", "type": "Expert"},
            {"name": "AWS Certified Machine Learning", "type": "Advanced"}
        ],
        demographic_info={"age": 38, "location": "Boston"}
    )
    
    # Add candidates to system
    system.add_candidate(candidate1)
    system.add_candidate(candidate2)
    system.add_candidate(candidate3)
    
    # Rank candidates
    print("=== CANDIDATE RANKING RESULTS ===")
    ranked = system.rank_candidates()
    
    for i, (candidate, score) in enumerate(ranked, 1):
        print(f"{i}. {candidate.name} (Score: {score})")
    
    print("\n=== SHORTLIST (Top 3) ===")
    shortlist = system.get_shortlist(3)
    for i, (candidate, score) in enumerate(shortlist, 1):
        print(f"{i}. {candidate.name} - Score: {score} - Gender: {candidate.gender.value}")
    
    print("\n=== RANKING SUMMARY REPORT ===")
    report = system.generate_summary_report()
    print(f"Total Candidates: {report['total_candidates']}")
    print(f"Average Score: {report['average_score']}")
    print(f"Max Score: {report['max_score']}")
    print(f"Min Score: {report['min_score']}")
    print("Gender Distribution:")
    for gender, count in report['gender_distribution'].items():
        print(f"  {gender}: {count}")
    
    print("\n=== TOP 3 CANDIDATES ===")
    for i, candidate_info in enumerate(report['top_candidates'], 1):
        print(f"{i}. {candidate_info['name']} - Score: {candidate_info['score']} - Gender: {candidate_info['gender']}")
    
    # Export results
    system.export_ranking_results("ranking_results.csv")
    system.export_summary_report("ranking_summary.json")
    
    print("\n=== EXPORTED FILES ===")
    print("1. ranking_results.csv - Detailed ranking results")
    print("2. ranking_summary.json - Summary report")
    
    return system


if __name__ == "__main__":
    # Run the demonstration
    system = demo_application()
    
    # Add a new candidate to test dynamic ranking
    print("\n=== TESTING DYNAMIC RANKING ===")
    new_candidate = Candidate(
        id="C004",
        name="David Brown",
        email="david.brown@example.com",
        gender=Gender.MALE,
        education=[
            {"degree": "Master", "institution": "Stanford University", "field": "Computer Science"}
        ],
        experience=[
            {"years": 10, "role": "Senior Software Engineer", "company": "Tech Corp"}
        ],
        skills=["Python", "Java", "C++", "JavaScript", "Go", "Rust", "Machine Learning"],
        certifications=[
            {"name": "AWS Certified Solutions Architect", "type": "Professional"},
            {"name": "Google Cloud Professional Data Engineer", "type": "Professional"},
            {"name": "Microsoft Azure Solutions Architect", "type": "Professional"}
        ],
        demographic_info={"age": 35, "location": "San Francisco"}
    )
    
    system.add_candidate(new_candidate)
    print("Added new candidate David Brown")
    
    # Show updated ranking
    print("\n=== UPDATED RANKING ===")
    updated_ranked = system.rank_candidates()
    for i, (candidate, score) in enumerate(updated_ranked, 1):
        print(f"{i}. {candidate.name} (Score: {score})")
    
    print("\n=== UPDATED SHORTLIST ===")
    updated_shortlist = system.get_shortlist(3)
    for i, (candidate, score) in enumerate(updated_shortlist, 1):
        print(f"{i}. {candidate.name} - Score: {score}")
    
    # Export updated results
    system.export_ranking_results("ranking_results_updated.csv")
    system.export_summary_report("ranking_summary_updated.json")
    print("\n=== UPDATED EXPORTED FILES ===")
    print("1. ranking_results_updated.csv - Updated ranking results")
    print("2. ranking_summary_updated.json - Updated summary report")