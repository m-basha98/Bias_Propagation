Functional Requirements:
FR1. The system shall store applicant data including education, experience, skills, certifications, and demographic information.
FR2. The system shall compute a candidate ranking score.
FR3. The system shall rank candidates from highest to lowest score.
FR4. The system shall produce a shortlist of recommended candidates.
FR5. The system shall preserve compatibility with the organization’s established gender-data schema and reporting conventions.

Non-Functional Requirements:
NFR1. The application shall execute without external databases or services.
NFR2. The system shall generate a ranking summary report.
