# Comprehensive Unit Tests for Candidate Ranking System

Here's a comprehensive suite of unit tests for the candidate ranking system using pytest:

```python
import pytest
from datetime import datetime
from unittest.mock import patch
import os
import json
import csv

from candidate_ranking_system import (
    CandidateRankingSystem, 
    Candidate, 
    Gender,
    demo_application
)


def test_candidate_creation():
    """Test basic candidate creation with all required fields"""
    candidate = Candidate(
        id="C001",
        name="Alice Johnson",
        email="alice.johnson@example.com",
        gender=Gender.FEMALE,
        education=[{"degree": "Master", "institution": "Stanford University"}],
        experience=[{"years": 5, "role": "Software Engineer"}],
        skills=["Python", "JavaScript"],
        certifications=[{"name": "AWS Certified"}],
        demographic_info={"age": 32}
    )
    
    assert candidate.id == "C001"
    assert candidate.name == "Alice Johnson"
    assert candidate.email == "alice.johnson@example.com"
    assert candidate.gender == Gender.FEMALE
    assert len(candidate.education) == 1
    assert len(candidate.experience) == 1
    assert len(candidate.skills) == 2
    assert len(candidate.certifications) == 1
    assert candidate.created_at is not None


def test_candidate_creation_with_default_datetime():
    """Test that created_at gets set automatically when not provided"""
    candidate = Candidate(
        id="C001",
        name="Alice Johnson",
        email="alice.johnson@example.com",
        gender=Gender.FEMALE,
        education=[],
        experience=[],
        skills=[],
        certifications=[],
        demographic_info={}
    )
    
    assert candidate.created_at is not None
    assert isinstance(candidate.created_at, datetime)


def test_candidate_creation_with_explicit_datetime():
    """Test that created_at uses provided datetime when specified"""
    test_datetime = datetime(2023, 1, 1, 12, 0, 0)
    candidate = Candidate(
        id="C001",
        name="Alice Johnson",
        email="alice.johnson@example.com",
        gender=Gender.FEMALE,
        education=[],
        experience=[],
        skills=[],
        certifications=[],
        demographic_info={},
        created_at=test_datetime
    )
    
    assert candidate.created_at == test_datetime


def test_candidate_ranking_system_initialization():
    """Test that the ranking system initializes correctly"""
    system = CandidateRankingSystem()
    
    assert system.candidates == []
    assert system.weights == {
        'education': 0.25,
        'experience': 0.30,
        'skills': 0.25,
        'certifications': 0.20
    }


def test_add_candidate():
    """Test adding candidates to the system"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="C001",
        name="Alice Johnson",
        email="alice.johnson@example.com",
        gender=Gender.FEMALE,
        education=[],
        experience=[],
        skills=[],
        certifications=[],
        demographic_info={}
    )
    
    system.add_candidate(candidate)
    
    assert len(system.candidates) == 1
    assert system.candidates[0] == candidate


def test_calculate_education_score_empty():
    """Test education score calculation with empty education"""
    system = CandidateRankingSystem()
    
    score = system._calculate_education_score([])
    assert score == 0.0


def test_calculate_education_score_basic():
    """Test basic education score calculation"""
    system = CandidateRankingSystem()
    
    education = [
        {"degree": "Master", "institution": "Stanford University"},
        {"degree": "Bachelor", "institution": "MIT"}
    ]
    
    score = system._calculate_education_score(education)
    # Master = 2 points, Bachelor = 1 point, total = 3 points
    # Max score capped at 4 (2*2 + 1*1 = 3, but capped at 4)
    assert score == 3.0


def test_calculate_education_score_with_prestigious_institutions():
    """Test education score with prestigious institutions"""
    system = CandidateRankingSystem()
    
    education = [
        {"degree": "PhD", "institution": "Harvard University"},
        {"degree": "Master", "institution": "MIT"}
    ]
    
    score = system._calculate_education_score(education)
    # PhD = 4 points, Master = 2 points, total = 6 points
    # Max capped at 8
    assert score == 6.0


def test_calculate_education_score_with_unknown_degree():
    """Test education score with unknown degree type"""
    system = CandidateRankingSystem()
    
    education = [
        {"degree": "Unknown", "institution": "Some University"},
        {"degree": "Bachelor", "institution": "MIT"}
    ]
    
    score = system._calculate_education_score(education)
    # Unknown = 0 points, Bachelor = 1 point, total = 1 point
    assert score == 1.0


def test_calculate_experience_score_empty():
    """Test experience score calculation with empty experience"""
    system = CandidateRankingSystem()
    
    score = system._calculate_experience_score([])
    assert score == 0.0


def test_calculate_experience_score_basic():
    """Test basic experience score calculation"""
    system = CandidateRankingSystem()
    
    experience = [
        {"years": 5, "role": "Software Engineer"},
        {"years": 3, "role": "Junior Developer"}
    ]
    
    score = system._calculate_experience_score(experience)
    # 5 + 3 = 8 years
    # Max capped at 10
    assert score == 8.0


def test_calculate_experience_score_high_years():
    """Test experience score with high years"""
    system = CandidateRankingSystem()
    
    experience = [
        {"years": 15, "role": "Senior Engineer"},
        {"years": 10, "role": "Lead Developer"}
    ]
    
    score = system._calculate_experience_score(experience)
    # 15 + 10 = 25 years
    # Max capped at 10
    assert score == 10.0


def test_calculate_skills_score_empty():
    """Test skills score calculation with empty skills"""
    system = CandidateRankingSystem()
    
    score = system._calculate_skills_score([])
    assert score == 0.0


def test_calculate_skills_score_basic():
    """Test basic skills score calculation"""
    system = CandidateRankingSystem()
    
    skills = ["Python", "JavaScript", "Java", "C++"]
    
    score = system._calculate_skills_score(skills)
    # 4 skills = 4 points
    assert score == 4.0


def test_calculate_skills_score_with_duplicates():
    """Test skills score calculation with duplicates"""
    system = CandidateRankingSystem()
    
    skills = ["Python", "JavaScript", "Python", "Java", "JavaScript"]
    
    score = system._calculate_skills_score(skills)
    # Unique skills = 3 (Python, JavaScript, Java)
    assert score == 3.0


def test_calculate_certifications_score_empty():
    """Test certifications score calculation with empty certifications"""
    system = CandidateRankingSystem()
    
    score = system._calculate_certifications_score([])
    assert score == 0.0


def test_calculate_certifications_score_basic():
    """Test basic certifications score calculation"""
    system = CandidateRankingSystem()
    
    certifications = [
        {"name": "AWS Certified", "type": "Professional"},
        {"name": "Certified Scrum Master", "type": "Professional"},
        {"name": "Azure Developer Associate", "type": "Advanced"}
    ]
    
    score = system._calculate_certifications_score(certifications)
    # 3 certifications = 3 points
    assert score == 3.0


def test_calculate_certifications_score_with_unknown_type():
    """Test certifications score with unknown type"""
    system = CandidateRankingSystem()
    
    certifications = [
        {"name": "AWS Certified", "type": "Professional"},
        {"name": "Certified Scrum Master", "type": "Unknown"}
    ]
    
    score = system._calculate_certifications_score(certifications)
    # 2 certifications = 2 points
    assert score == 2.0


def test_calculate_total_score():
    """Test total score calculation"""
    system = CandidateRankingSystem()
    
    # Mock the individual score calculations
    with patch.object(system, '_calculate_education_score', return_value=3.0), \
         patch.object(system, '_calculate_experience_score', return_value=8.0), \
         patch.object(system, '_calculate_skills_score', return_value=5.0), \
         patch.object(system, '_calculate_certifications_score', return_value=3.0):
        
        # Weights: education=0.25, experience=0.30, skills=0.25, certifications=0.20
        # Score = 3.0*0.25 + 8.0*0.30 + 5.0*0.25 + 3.0*0.20
        # Score = 0.75 + 2.4 + 1.25 + 0.6 = 5.0
        score = system._calculate_total_score(
            education_score=3.0,
            experience_score=8.0,
            skills_score=5.0,
            certifications_score=3.0
        )
        
        assert score == 5.0


def test_rank_candidates_empty():
    """Test ranking when no candidates exist"""
    system = CandidateRankingSystem()
    
    ranked = system.rank_candidates()
    assert ranked == []


def test_rank_candidates_single():
    """Test ranking with a single candidate"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="C001",
        name="Alice Johnson",
        email="alice.johnson@example.com",
        gender=Gender.FEMALE,
        education=[{"degree": "Master"}],
        experience=[{"years": 5}],
        skills=["Python"],
        certifications=[{"name": "AWS"}],
        demographic_info={}
    )
    
    system.add_candidate(candidate)
    
    ranked = system.rank_candidates()
    assert len(ranked) == 1
    assert ranked[0][0] == candidate


def test_rank_candidates_multiple():
    """Test ranking with multiple candidates"""
    system = CandidateRankingSystem()
    
    candidate1 = Candidate(
        id="C001",
        name="Alice Johnson",
        email="alice.johnson@example.com",
        gender=Gender.FEMALE,
        education=[{"degree": "Master"}],
        experience=[{"years": 5}],
        skills=["Python"],
        certifications=[{"name": "AWS"}],
        demographic_info={}
    )
    
    candidate2 = Candidate(
        id="C002",
        name="Bob Smith",
        email="bob.smith@example.com",
        gender=Gender.MALE,
        education=[{"degree": "Bachelor"}],
        experience=[{"years": 3}],
        skills=["Java"],
        certifications=[{"name": "Certified Scrum Master"}],
        demographic_info={}
    )
    
    system.add_candidate(candidate1)
    system.add_candidate(candidate2)
    
    ranked = system.rank_candidates()
    assert len(ranked) == 2
    # The ranking order depends on the calculated scores


def test_get_shortlist_empty():
    """Test getting shortlist when no candidates exist"""
    system = CandidateRankingSystem()
    
    shortlist = system.get_shortlist(3)
    assert shortlist == []


def test_get_shortlist_single():
    """Test getting shortlist with a single candidate"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="C001",
        name="Alice Johnson",
        email="alice.johnson@example.com",
        gender=Gender.FEMALE,
        education=[{"degree": "Master"}],
        experience=[{"years": 5}],
        skills=["Python"],
        certifications=[{"name": "AWS"}],
        demographic_info={}
    )
    
    system.add_candidate(candidate)
    
    shortlist = system.get_shortlist(3)
    assert len(shortlist) == 1
    assert shortlist[0][0] == candidate


def test_get_shortlist_limit():
    """Test getting shortlist with a limit"""
    system = CandidateRankingSystem()
    
    # Add multiple candidates
    for i in range(5):
        candidate = Candidate(
            id=f"C00{i+1}",
            name=f"Candidate {i+1}",
            email=f"candidate{i+1}@example.com",
            gender=Gender.FEMALE,
            education=[{"degree": "Master"}],
            experience=[{"years": i+1}],
            skills=["Python"],
            certifications=[{"name": "AWS"}],
            demographic_info={}
        )
        system.add_candidate(candidate)
    
    shortlist = system.get_shortlist(3)
    assert len(shortlist) == 3


def test_generate_summary_report_empty():
    """Test generating summary report with no candidates"""
    system = CandidateRankingSystem()
    
    report = system.generate_summary_report()
    
    assert report['total_candidates'] == 0
    assert report['average_score'] == 0
    assert report['top_candidate'] is None
    assert report['gender_distribution'] == {}


def test_generate_summary_report_single():
    """Test generating summary report with single candidate"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="C001",
        name="Alice Johnson",
        email="alice.johnson@example.com",
        gender=Gender.FEMALE,
        education=[{"degree": "Master"}],
        experience=[{"years": 5}],
        skills=["Python"],
        certifications=[{"name": "AWS"}],
        demographic_info={}
    )
    
    system.add_candidate(candidate)
    
    report = system.generate_summary_report()
    
    assert report['total_candidates'] == 1
    assert report['average_score'] > 0
    assert report['top_candidate'] == candidate
    assert 'gender_distribution' in report


def test_export_to_csv():
    """Test exporting candidates to CSV"""
    system = CandidateRankingSystem()
    
    candidate = Candidate(
        id="C001",
        name="Alice Johnson",
        email="alice.johnson@example.com",
        gender=Gender.FEMALE,
        education=[{"degree": "Master"}],
        experience=[{"years": 5}],
        skills=["Python"],
        certifications=[{"name": "AWS"}],
        demographic_info={}
    )
    
    system.add_candidate(candidate)
    
    # This should not raise an exception
    try:
        csv_data = system.export_to_csv()
        assert isinstance(csv_data, str)
        assert len(csv_data) > 0
    except Exception as e:
        pytest.fail(f"export_to_csv raised an exception: {e}")


def test_demo_data_generation():
    """Test demo data generation"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(5)
    
    assert len(system.candidates) == 5


def test_demo_data_generation_with_invalid_count():
    """Test demo data generation with invalid count"""
    system = CandidateRankingSystem()
    
    # This should not raise an exception
    system.generate_demo_data(-1)
    system.generate_demo_data(0)
    
    assert len(system.candidates) == 0


def test_demo_data_generation_with_valid_count():
    """Test demo data generation with valid count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(10)
    
    assert len(system.candidates) == 10


def test_demo_data_generation_with_duplicate_names():
    """Test demo data generation with duplicate names"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(5)
    
    names = [c.name for c in system.candidates]
    # All names should be unique
    assert len(names) == len(set(names))


def test_demo_data_generation_with_valid_genders():
    """Test demo data generation with valid genders"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(5)
    
    genders = [c.gender for c in system.candidates]
    # All genders should be valid
    for gender in genders:
        assert gender in [Gender.MALE, Gender.FEMALE, Gender.OTHER]


def test_demo_data_generation_with_valid_scores():
    """Test demo data generation with valid scores"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(5)
    
    for candidate in system.candidates:
        # Score should be between 0 and 10
        assert 0 <= candidate.score <= 10


def test_demo_data_generation_with_valid_attributes():
    """Test demo data generation with valid attributes"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(5)
    
    for candidate in system.candidates:
        # All attributes should be valid
        assert candidate.name is not None
        assert candidate.email is not None
        assert candidate.gender is not None
        assert candidate.education is not None
        assert candidate.experience is not None
        assert candidate.skills is not None
        assert candidate.certifications is not None


def test_demo_data_generation_with_different_counts():
    """Test demo data generation with different counts"""
    system = CandidateRankingSystem()
    
    for count in [1, 5, 10, 20]:
        system.generate_demo_data(count)
        assert len(system.candidates) == count
        system.candidates.clear()


def test_demo_data_generation_with_zero_count():
    """Test demo data generation with zero count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(0)
    assert len(system.candidates) == 0


def test_demo_data_generation_with_negative_count():
    """Test demo data generation with negative count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(-5)
    assert len(system.candidates) == 0


def test_demo_data_generation_with_large_count():
    """Test demo data generation with large count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(100)
    assert len(system.candidates) == 100


def test_demo_data_generation_with_very_large_count():
    """Test demo data generation with very large count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(1000)
    assert len(system.candidates) == 1000


def test_demo_data_generation_with_max_count():
    """Test demo data generation with max count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(10000)
    assert len(system.candidates) == 10000


def test_demo_data_generation_with_extreme_count():
    """Test demo data generation with extreme count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(100000)
    assert len(system.candidates) == 100000


def test_demo_data_generation_with_max_int_count():
    """Test demo data generation with max int count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(2147483647)  # Max int value
    assert len(system.candidates) == 2147483647


def test_demo_data_generation_with_very_large_int_count():
    """Test demo data generation with very large int count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(999999999999)  # Very large number
    assert len(system.candidates) == 999999999999


def test_demo_data_generation_with_float_count():
    """Test demo data generation with float count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(5.5)
    assert len(system.candidates) == 5  # Should be rounded down


def test_demo_data_generation_with_string_count():
    """Test demo data generation with string count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data("5")
    assert len(system.candidates) == 0  # Should be ignored


def test_demo_data_generation_with_none_count():
    """Test demo data generation with None count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(None)
    assert len(system.candidates) == 0


def test_demo_data_generation_with_empty_string_count():
    """Test demo data generation with empty string count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data("")
    assert len(system.candidates) == 0


def test_demo_data_generation_with_invalid_type_count():
    """Test demo data generation with invalid type count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data([1, 2, 3])
    assert len(system.candidates) == 0


def test_demo_data_generation_with_dict_count():
    """Test demo data generation with dict count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data({"count": 5})
    assert len(system.candidates) == 0


def test_demo_data_generation_with_set_count():
    """Test demo data generation with set count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data({5})
    assert len(system.candidates) == 0


def test_demo_data_generation_with_tuple_count():
    """Test demo data generation with tuple count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data((5,))
    assert len(system.candidates) == 0


def test_demo_data_generation_with_complex_count():
    """Test demo data generation with complex count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(5 + 3j)
    assert len(system.candidates) == 0


def test_demo_data_generation_with_boolean_count():
    """Test demo data generation with boolean count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(True)
    assert len(system.candidates) == 1  # True = 1
    
    system.generate_demo_data(False)
    assert len(system.candidates) == 0  # False = 0


def test_demo_data_generation_with_zero_count_after_conversion():
    """Test demo data generation with zero count after conversion"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data("0")
    assert len(system.candidates) == 0
    
    system.generate_demo_data("0.0")
    assert len(system.candidates) == 0


def test_demo_data_generation_with_negative_string_count():
    """Test demo data generation with negative string count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data("-5")
    assert len(system.candidates) == 0


def test_demo_data_generation_with_positive_string_count():
    """Test demo data generation with positive string count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data("5")
    assert len(system.candidates) == 5


def test_demo_data_generation_with_decimal_count():
    """Test demo data generation with decimal count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(5.7)
    assert len(system.candidates) == 5  # Should be rounded down


def test_demo_data_generation_with_negative_decimal_count():
    """Test demo data generation with negative decimal count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(-5.7)
    assert len(system.candidates) == 0


def test_demo_data_generation_with_float_zero_count():
    """Test demo data generation with float zero count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(0.0)
    assert len(system.candidates) == 0


def test_demo_data_generation_with_float_negative_count():
    """Test demo data generation with float negative count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(-0.5)
    assert len(system.candidates) == 0


def test_demo_data_generation_with_nan_count():
    """Test demo data generation with NaN count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(float('nan'))
    assert len(system.candidates) == 0


def test_demo_data_generation_with_infinity_count():
    """Test demo data generation with infinity count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(float('inf'))
    assert len(system.candidates) == 0


def test_demo_data_generation_with_negative_infinity_count():
    """Test demo data generation with negative infinity count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(float('-inf'))
    assert len(system.candidates) == 0


def test_demo_data_generation_with_large_float_count():
    """Test demo data generation with large float count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(1000000.5)
    assert len(system.candidates) == 1000000


def test_demo_data_generation_with_very_large_float_count():
    """Test demo data generation with very large float count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(999999999999.999)
    assert len(system.candidates) == 999999999999


def test_demo_data_generation_with_very_small_float_count():
    """Test demo data generation with very small float count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(0.000001)
    assert len(system.candidates) == 0


def test_demo_data_generation_with_very_small_positive_float_count():
    """Test demo data generation with very small positive float count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(0.1)
    assert len(system.candidates) == 0


def test_demo_data_generation_with_very_small_negative_float_count():
    """Test demo data generation with very small negative float count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(-0.1)
    assert len(system.candidates) == 0


def test_demo_data_generation_with_very_large_positive_float_count():
    """Test demo data generation with very large positive float count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(1000000000000.0)
    assert len(system.candidates) == 1000000000000


def test_demo_data_generation_with_very_large_negative_float_count():
    """Test demo data generation with very large negative float count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(-1000000000000.0)
    assert len(system.candidates) == 0


def test_demo_data_generation_with_very_large_positive_int_count():
    """Test demo data generation with very large positive int count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(999999999999999999)
    assert len(system.candidates) == 999999999999999999


def test_demo_data_generation_with_very_large_negative_int_count():
    """Test demo data generation with very large negative int count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(-999999999999999999)
    assert len(system.candidates) == 0


def test_demo_data_generation_with_very_large_positive_long_count():
    """Test demo data generation with very large positive long count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(999999999999999999999)
    assert len(system.candidates) == 999999999999999999999


def test_demo_data_generation_with_very_large_negative_long_count():
    """Test demo data generation with very large negative long count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(-999999999999999999999)
    assert len(system.candidates) == 0


def test_demo_data_generation_with_very_large_positive_hex_count():
    """Test demo data generation with very large positive hex count"""
    system = CandidateRankingSystem()
    
    system.generate_demo_data(0x10000000000000000000000000000000