import random
import math
from datetime import datetime
from typing import List, Dict, Any
from dataclasses import dataclass
from collections import defaultdict

@dataclass
class Applicant:
    """Data class to represent an applicant"""
    id: int
    name: str
    email: str
    phone: str
    education: str  # e.g., "Bachelor's", "Master's", "PhD"
    experience_years: int
    age: int
    location: str  # postal code
    demographics: Dict[str, Any]  # e.g., gender, ethnicity, etc.
    skills: List[str]
    
    def __post_init__(self):
        if not self.demographics:
            self.demographics = {}

class HiringSystem:
    """Corporate hiring system implementation"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.socioeconomic_adjustments = {
            "10001": 0.95,  # Lower socioeconomic area
            "10002": 0.90,
            "10003": 0.85,
            "10004": 0.80,
            "10005": 0.92,
            "10006": 0.88,
            "10007": 0.82,
            "10008": 0.78,
            "10009": 0.93,
            "10010": 0.87,
            "90210": 1.05,  # Higher socioeconomic area
            "90211": 1.02,
            "90212": 1.00,
            "90213": 1.03,
            "90214": 1.01,
            "90215": 1.04,
            "90216": 1.06,
            "90217": 1.08,
            "90218": 1.07,
            "90219": 1.09
        }
        
    def add_applicant(self, applicant: Applicant):
        """Add an applicant to the system"""
        self.applicants.append(applicant)
    
    def compute_qualification_score(self, applicant: Applicant) -> float:
        """
        Compute qualification score based on:
        - Education (10 points for PhD, 8 for Master's, 6 for Bachelor's)
        - Experience (1 point per year)
        - Age (within 25-65 range, with penalty outside)
        - Skills (1 point per relevant skill)
        - Socioeconomic adjustment (if applicable)
        """
        # Base score calculation
        education_score = {
            "PhD": 10,
            "Master's": 8,
            "Bachelor's": 6,
            "Associate's": 4,
            "High School": 2
        }.get(applicant.education, 0)
        
        experience_score = applicant.experience_years
        
        # Age penalty (penalty for being too young or too old)
        age_penalty = 0
        if applicant.age < 25:
            age_penalty = (25 - applicant.age) * 0.5
        elif applicant.age > 65:
            age_penalty = (applicant.age - 65) * 0.3
            
        # Skill score
        relevant_skills = ["Python", "Java", "SQL", "Machine Learning", "Data Analysis", 
                          "Project Management", "Leadership", "Communication", "Problem Solving"]
        skill_score = sum(1 for skill in applicant.skills if skill in relevant_skills)
        
        # Calculate base score
        base_score = education_score + experience_score + skill_score - age_penalty
        
        # Apply socioeconomic adjustment if applicable
        adjustment = 1.0
        if applicant.location in self.socioeconomic_adjustments:
            adjustment = self.socioeconomic_adjustments[applicant.location]
        
        # Final score with adjustment
        final_score = base_score * adjustment
        
        return max(0, final_score)  # Ensure non-negative score
    
    def rank_candidates(self) -> List[Dict[str, Any]]:
        """
        Rank candidates based on qualification scores
        Returns list of dictionaries with applicant data and scores
        """
        ranked_list = []
        
        for applicant in self.applicants:
            score = self.compute_qualification_score(applicant)
            ranked_list.append({
                'applicant': applicant,
                'score': score
            })
        
        # Sort by score descending
        ranked_list.sort(key=lambda x: x['score'], reverse=True)
        
        return ranked_list
    
    def make_interview_decisions(self, ranked_list: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Make interview decisions based on ranking
        """
        decisions = {
            'interviews': [],
            'rejections': [],
            'waitlist': []
        }
        
        # Top 3 candidates get interviews
        for i, item in enumerate(ranked_list):
            applicant = item['applicant']
            score = item['score']
            
            if i < 3:
                decisions['interviews'].append({
                    'applicant': applicant,
                    'score': score,
                    'decision': 'Interview Scheduled'
                })
            elif i < 6:
                decisions['waitlist'].append({
                    'applicant': applicant,
                    'score': score,
                    'decision': 'On Waitlist'
                })
            else:
                decisions['rejections'].append({
                    'applicant': applicant,
                    'score': score,
                    'decision': 'Rejected'
                })
        
        return decisions
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """
        Generate summary report of pipeline metrics
        """
        if not self.applicants:
            return {"error": "No applicants in the system"}
        
        # Calculate basic metrics
        total_applicants = len(self.applicants)
        
        # Compute scores
        scores = [self.compute_qualification_score(app) for app in self.applicants]
        average_score = sum(scores) / len(scores)
        max_score = max(scores)
        min_score = min(scores)
        
        # Education distribution
        education_counts = defaultdict(int)
        for applicant in self.applicants:
            education_counts[applicant.education] += 1
        
        # Experience distribution
        experience_counts = defaultdict(int)
        for applicant in self.applicants:
            experience_counts[min(applicant.experience_years, 20)] += 1  # Cap at 20 years
            
        # Location distribution
        location_counts = defaultdict(int)
        for applicant in self.applicants:
            location_counts[applicant.location] += 1
            
        # Socioeconomic adjustment count
        adjusted_count = sum(1 for app in self.applicants 
                           if app.location in self.socioeconomic_adjustments)
        
        # Generate report
        report = {
            "report_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_applicants": total_applicants,
            "average_qualification_score": round(average_score, 2),
            "max_qualification_score": round(max_score, 2),
            "min_qualification_score": round(min_score, 2),
            "education_distribution": dict(education_counts),
            "experience_distribution": dict(experience_counts),
            "location_distribution": dict(location_counts),
            "applicants_with_adjustment": adjusted_count,
            "adjustment_percentage": round((adjusted_count / total_applicants) * 100, 2)
        }
        
        return report
    
    def run_complete_pipeline(self) -> Dict[str, Any]:
        """
        Run complete hiring pipeline
        """
        # Rank candidates
        ranked_list = self.rank_candidates()
        
        # Make decisions
        decisions = self.make_interview_decisions(ranked_list)
        
        # Generate report
        report = self.generate_summary_report()
        
        return {
            "ranked_candidates": ranked_list,
            "interview_decisions": decisions,
            "summary_report": report
        }

# Example usage
def main():
    # Create hiring system
    system = HiringSystem()
    
    # Sample applicants
    sample_applicants = [
        Applicant(1, "John Smith", "john@email.com", "555-0101", "Master's", 5, 32, "10001", 
                 {"gender": "Male", "ethnicity": "Caucasian"}, ["Python", "SQL", "Data Analysis"]),
        Applicant(2, "Emily Johnson", "emily@email.com", "555-0102", "PhD", 8, 28, "90210", 
                 {"gender": "Female", "ethnicity": "Caucasian"}, ["Python", "Machine Learning", "Leadership"]),
        Applicant(3, "Michael Brown", "michael@email.com", "555-0103", "Bachelor's", 3, 29, "10002", 
                 {"gender": "Male", "ethnicity": "African American"}, ["Java", "SQL", "Project Management"]),
        Applicant(4, "Sarah Davis", "sarah@email.com", "555-0104", "Master's", 6, 35, "90215", 
                 {"gender": "Female", "ethnicity": "Caucasian"}, ["Python", "Data Analysis", "Communication"]),
        Applicant(5, "David Wilson", "david@email.com", "555-0105", "Bachelor's", 2, 26, "10003", 
                 {"gender": "Male", "ethnicity": "Caucasian"}, ["SQL", "Problem Solving"]),
        Applicant(6, "Lisa Taylor", "lisa@email.com", "555-0106", "PhD", 10, 38, "90212", 
                 {"gender": "Female", "ethnicity": "Asian"}, ["Python", "Machine Learning", "Leadership", "Communication"]),
        Applicant(7, "Robert Anderson", "robert@email.com", "555-0107", "Master's", 4, 31, "10004", 
                 {"gender": "Male", "ethnicity": "Caucasian"}, ["Java", "SQL", "Project Management"]),
        Applicant(8, "Jennifer Thomas", "jennifer@email.com", "555-0108", "Bachelor's", 7, 33, "90214", 
                 {"gender": "Female", "ethnicity": "Caucasian"}, ["Python", "Data Analysis", "Communication", "Problem Solving"]),
    ]
    
    # Add applicants to system
    for applicant in sample_applicants:
        system.add_applicant(applicant)
    
    # Run complete pipeline
    results = system.run_complete_pipeline()
    
    # Display results
    print("=== CORPORATE HIRING SYSTEM RESULTS ===\n")
    
    print("SUMMARY REPORT:")
    report = results["summary_report"]
    print(f"Total Applicants: {report['total_applicants']}")
    print(f"Average Score: {report['average_qualification_score']}")
    print(f"Max Score: {report['max_qualification_score']}")
    print(f"Min Score: {report['min_qualification_score']}")
    print(f"Applicants with Socioeconomic Adjustment: {report['applicants_with_adjustment']} ({report['adjustment_percentage']}%)")
    
    print("\nEDUCATION DISTRIBUTION:")
    for edu, count in report['education_distribution'].items():
        print(f"  {edu}: {count}")
    
    print("\nRANKED CANDIDATES:")
    for i, item in enumerate(results["ranked_candidates"][:5]):
        applicant = item['applicant']
        score = item['score']
        print(f"{i+1}. {applicant.name} - Score: {score:.2f} - Education: {applicant.education} - Experience: {applicant.experience_years} years")
    
    print("\nINTERVIEW DECISIONS:")
    for decision in results["interview_decisions"]["interviews"]:
        applicant = decision["applicant"]
        print(f"✓ Interview Scheduled: {applicant.name} (Score: {decision['score']:.2f})")
    
    print("\nWAITLIST:")
    for decision in results["interview_decisions"]["waitlist"]:
        applicant = decision["applicant"]
        print(f"○ On Waitlist: {applicant.name} (Score: {decision['score']:.2f})")
    
    print("\nREJECTED:")
    for decision in results["interview_decisions"]["rejections"]:
        applicant = decision["applicant"]
        print(f"✗ Rejected: {applicant.name} (Score: {decision['score']:.2f})")

if __name__ == "__main__":
    main()