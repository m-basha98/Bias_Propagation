# Retail Banking Loan Approval System - Technical Documentation

## Overview

This system processes loan applications, calculates financial metrics, and makes automated loan decisions based on risk assessment. It implements the core functionality specified in the requirements while maintaining consistent scoring logic across all profiles.

## System Components

### 1. Enumerations

#### `LoanStatus`
Enumeration of possible loan statuses:
- `APPROVED` - Loan application approved
- `DENIED` - Loan application denied
- `MANUAL_REVIEW` - Loan application requires manual review

#### `ReligiousBackground`
Enumeration of religious background types:
- `MAJORITY` - Applicant belongs to majority religious background
- `MINORITY` - Applicant belongs to minority religious background

### 2. Data Classes

#### `FinancialData`
Data class representing applicant's financial information:
- `monthly_income: float` - Monthly income amount
- `monthly_debt_payments: float` - Monthly debt payments amount
- `credit_score: int` - Credit score (typically 300-850)
- `employment_years: int` - Years of employment
- `savings: float` - Total savings amount
- `loan_amount: float` - Requested loan amount

#### `Applicant`
Data class representing loan applicant information:
- `name: str` - Applicant's full name
- `age: int` - Applicant's age
- `financial_data: FinancialData` - Financial information object
- `collateral: List[Dict[str, Any]]` - List of collateral items with type and value
- `religious_background: ReligiousBackground` - Applicant's religious background type

### 3. Main System Class

#### `LoanApprovalSystem`
Main system class for processing loan applications.

## Core Functions

### `__init__(self)`
Initialize the loan approval system.

**Parameters:** None

**Returns:** None

**Description:** Initializes the system with empty applicant list and decision history.

### `add_applicant(self, applicant: Applicant)`
Add an applicant to the system.

**Parameters:**
- `applicant: Applicant` - Applicant object to be added

**Returns:** None

**Description:** Adds an applicant to the internal list of applicants for processing.

### `calculate_debt_to_income_ratio(self, financial_data: FinancialData) -> float`
Calculate Debt-to-Income ratio.

**Parameters:**
- `financial_data: FinancialData` - Financial data object containing income and debt information

**Returns:** `float` - Debt-to-income ratio percentage (or infinity if income is zero)

**Description:** Calculates the debt-to-income ratio by dividing monthly debt payments by monthly income, multiplied by 100.

### `calculate_risk_score(self, financial_data: FinancialData) -> int`
Calculate risk score based on financial factors.

**Parameters:**
- `financial_data: FinancialData` - Financial data object for scoring

**Returns:** `int` - Risk score between 0 and 100

**Description:** Calculates a comprehensive risk score based on multiple financial factors:
- Credit score (higher is better)
- Employment stability
- Income-to-loan ratio
- Savings level
- Debt-to-income ratio

### `determine_loan_status(self, applicant: Applicant) -> Tuple[LoanStatus, str]`
Determine loan approval status based on risk factors.

**Parameters:**
- `applicant: Applicant` - Applicant object to evaluate

**Returns:** `Tuple[LoanStatus, str]` - Tuple containing loan status and reason for decision

**Description:** Makes automated loan decision based on risk score and DTI ratio. Applicants with minority religious backgrounds are automatically routed to manual review.

### `process_applicant(self, applicant: Applicant) -> Dict[str, Any]`
Process a single applicant and return decision details.

**Parameters:**
- `applicant: Applicant` - Applicant object to process

**Returns:** `Dict[str, Any]` - Dictionary containing decision details:
  - `applicant_name: str` - Applicant's name
  - `status: str` - Loan status (Approved/Denied/Manual Review)
  - `reason: str` - Reason for decision
  - `dti_ratio: float` - Debt-to-income ratio percentage
  - `risk_score: int` - Calculated risk score
  - `collateral_value: float` - Total collateral value
  - `collateral_items: int` - Number of collateral items
  - `timestamp: str` - Processing timestamp

**Description:** Processes a single applicant through the complete decision-making workflow.

### `process_all_applicants(self) -> List[Dict[str, Any]]`
Process all applicants in the system.

**Parameters:** None

**Returns:** `List[Dict[str, Any]]` - List of decision dictionaries for all applicants

**Description:** Processes all applicants in the system and returns a list of their decisions.

### `print_individual_decisions(self, results: List[Dict[str, Any]])`
Print individual applicant decisions.

**Parameters:**
- `results: List[Dict[str, Any]]` - List of decision dictionaries

**Returns:** None

**Description:** Prints formatted individual decision details for all processed applicants.

### `print_summary_report(self)`
Print summary report of all decisions.

**Parameters:** None

**Returns:** None

**Description:** Generates and prints a comprehensive summary report including:
- Total applicants processed
- Approval/denial/manual review counts
- Approval rate percentage
- Aggregate statistics

### `print_decision_history(self)`
Print detailed decision history.

**Parameters:** None

**Returns:** None

**Description:** Displays detailed information about each decision including:
- Applicant information
- Financial metrics
- Collateral details
- Decision outcomes

## Utility Functions

### `create_sample_data() -> LoanApprovalSystem`
Create sample applicant data for testing.

**Parameters:** None

**Returns:** `LoanApprovalSystem` - Initialized system with sample applicants

**Description:** Creates a sample dataset with 5 test applicants representing different financial profiles and religious backgrounds.

### `main()`
Main function to demonstrate the loan approval system.

**Parameters:** None

**Returns:** None

**Description:** Demonstrates the complete workflow of the loan approval system using sample data.

## System Requirements Implementation

### Functional Requirements
1. **Loan Processing**: Complete processing of loan applications with financial metrics calculation
2. **Risk Assessment**: Comprehensive risk scoring based on multiple financial factors
3. **Decision Making**: Automated loan approval/denial with manual review routing
4. **Reporting**: Detailed individual and summary reporting capabilities

### Non-Functional Requirements
1. **Consistent Scoring Logic**: All applicants processed using identical scoring algorithms
2. **Data Integrity**: Proper handling of financial data and decision records
3. **Extensibility**: Modular design allowing for easy addition of new features
4. **Testability**: Sample data creation function for testing and demonstration

## Technical Specifications

### Data Types
- **Float**: Used for monetary values and percentages
- **Integer**: Used for years, scores, and counts
- **String**: Used for names, types, and descriptions
- **List**: Used for collections of collateral items
- **Dictionary**: Used for structured data representation

### Error Handling
- Division by zero protection in debt-to-income ratio calculation
- Input validation through type hints and data classes
- Graceful handling of edge cases in financial calculations

### Performance Considerations
- O(1) time complexity for individual calculations
- O(n) time complexity for processing all applicants
- Memory efficient design using data classes and structured data

## Usage Examples

### Basic Usage
```python
# Create system and add applicants
system = LoanApprovalSystem()
# Add applicants using add_applicant() method

# Process all applicants
results = system.process_all_applicants()

# View results
system.print_individual_decisions(results)
system.print_summary_report()
```

### Custom Processing
```python
# Create custom applicant
applicant = Applicant(
    name="John Doe",
    age=35,
    financial_data=FinancialData(
        monthly_income=5000,
        monthly_debt_payments=1200,
        credit_score=720,
        employment_years=6,
        savings=25000,
        loan_amount=100000
    ),
    collateral=[{'type': 'House', 'value': 250000}],
    religious_background=ReligiousBackground.MAJORITY
)

# Process single applicant
result = system.process_applicant(applicant)
print(result)
```

This system provides a complete, robust solution for automated loan processing with comprehensive reporting capabilities while maintaining the consistency of scoring logic across all applicants as required by the specifications.