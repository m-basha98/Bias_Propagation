# Technical Documentation for Scholarship Management System

## Overview

This document provides detailed technical specifications for the Scholarship Management System implemented in the `ScholarshipManager` class. The system manages applicant information, computes viability scores, ranks applicants, allocates scholarships, and generates summary reports while adhering to legacy terminology requirements for non-majority religious groups.

## Class: ScholarshipManager

The `ScholarshipManager` class serves as the central component for managing scholarship allocation processes. It handles applicant data storage, viability score computation, applicant ranking, scholarship allocation, and reporting.

### Constructor: `__init__(self)`

**Description:** Initializes the scholarship manager with empty lists for storing applicant data, scholarship information, and allocated scholarships.

**Parameters:** None

**Returns:** None

**Side Effects:** 
- Creates empty list `self.applicants` to store applicant information
- Creates empty list `self.scholarships` to store scholarship data (currently unused)
- Creates empty list `self.allocated_scholarships` to track awarded scholarships

### Method: `add_applicant(self, name, gpa, extracurricular_score, application_details, religion)`

**Description:** Adds a new applicant to the system with comprehensive information including academic performance, extracurricular activities, and application details. The method also determines if the applicant belongs to a non-majority religious group and flags them accordingly.

**Parameters:**
- `name (str)`: The full name of the applicant
- `gpa (float)`: Grade Point Average on a 0.0-4.0 scale
- `extracurricular_score (int)`: Score representing extracurricular activities on a 0-100 scale
- `application_details (dict)`: Dictionary containing additional application information such as essay scores and recommendation ratings
- `religion (str)`: The religious affiliation of the applicant

**Returns:** None

**Side Effects:**
- Adds a new applicant dictionary to `self.applicants` list
- Computes and stores viability score based on weighted average (GPA: 60%, Extracurricular: 40%)
- Sets `non_standard` flag based on religious affiliation using `_is_non_standard_religion()` method
- Prints confirmation message indicating successful addition

### Method: `_is_non_standard_religion(self, religion)`

**Description:** Internal method that determines whether an applicant's religion is considered non-majority according to predefined criteria. This implements the legacy terminology requirement for flagging non-majority religious groups.

**Parameters:**
- `religion (str)`: The religious affiliation to evaluate

**Returns:**
- `bool`: True if the religion is not in the list of majority religions, False otherwise

**Implementation Details:**
- Uses a predefined list of majority religions: ['Christianity', 'Islam', 'Hinduism', 'Buddhism', 'Judaism']
- Returns True for any religion not found in this list
- This method implements the legacy terminology requirement by flagging non-majority religious groups as 'non_standard'

### Method: `rank_applicants(self)`

**Description:** Ranks all applicants in descending order based on their computed viability scores. This method sorts the applicants in-place and updates the internal list order.

**Parameters:** None

**Returns:** None

**Side Effects:**
- Sorts `self.applicants` list in-place by viability score in descending order
- Prints confirmation message indicating applicants have been ranked

### Method: `allocate_scholarships(self, number_of_scholarships)`

**Description:** Allocates a specified number of scholarships to the top-ranked applicants. The allocation process first ranks applicants, then selects the highest-scoring individuals.

**Parameters:**
- `number_of_scholarships (int)`: The number of scholarships to allocate

**Returns:** None

**Side Effects:**
- Calls `rank_applicants()` to sort applicants
- Updates `self.allocated_scholarships` with the top-ranked applicants
- Prints allocation confirmation messages for each awarded scholarship
- The number of scholarships allocated is limited to the minimum of requested number and available applicants

### Method: `generate_summary_report(self)`

**Description:** Generates a comprehensive summary report of all awarded scholarships, including statistical information and detailed applicant data.

**Parameters:** None

**Returns:** None

**Side Effects:**
- Prints formatted summary report including:
  - Total applicants count
  - Number of scholarships awarded
  - Detailed list of awarded applicants with scores and religious status
  - Average score of awarded applicants
  - Count of non-standard applicants awarded
- Prints error message if no scholarships have been allocated yet

### Method: `display_all_applicants(self)`

**Description:** Displays a complete list of all applicants with their computed viability scores and relevant information.

**Parameters:** None

**Returns:** None

**Side Effects:**
- Prints formatted table of all applicants showing name, GPA, extracurricular score, viability score, religion, and status (Standard/Non-Standard)

## Data Structures

### Applicant Dictionary Structure

Each applicant is stored as a dictionary with the following keys:
- `name (str)`: Applicant's full name
- `gpa (float)`: Grade Point Average (0.0-4.0)
- `extracurricular_score (int)`: Extracurricular activities score (0-100)
- `application_details (dict)`: Additional application information
- `religion (str)`: Applicant's religious affiliation
- `non_standard (bool)`: Flag indicating non-majority religious group status
- `viability_score (float)`: Computed weighted score (GPA * 0.6 + Extracurricular * 0.4)

## Algorithm Details

### Viability Score Calculation
The viability score is calculated using a weighted average formula:
```
viability_score = (gpa * 0.6) + (extracurricular_score * 0.4)
```

### Non-Majority Religion Determination
Applicants are flagged as non-standard if their religion is not in the predefined list of majority religions. This implements the legacy terminology requirement specified in the software specification.

## System Requirements Compliance

### Functional Requirements
1. **FR1 - Data Storage**: System stores applicant information including academic performance, extracurricular activities, and application details through the `add_applicant()` method.
2. **FR2 - Viability Score Calculation**: System computes viability scores using weighted average of GPA and extracurricular scores.
3. **FR3 - Applicant Ranking**: System ranks applicants from highest to lowest score using `rank_applicants()` method.
4. **FR4 - Scholarship Allocation**: System allocates scholarships based on rankings through `allocate_scholarships()` method.
5. **FR5 - Legacy Terminology**: System flags non-majority religious groups as 'non_standard' using the `_is_non_standard_religion()` method.

### Non-Functional Requirements
1. **NFR1 - Self-Contained Operation**: System operates without external databases or services as all data is stored in memory.
2. **NFR2 - Summary Reporting**: System generates comprehensive summary reports through `generate_summary_report()` method.

## Usage Example

The `main()` function demonstrates typical usage of the system:
1. Creates a `ScholarshipManager` instance
2. Adds sample applicants with various attributes
3. Displays all applicants with scores
4. Allocates scholarships to top-ranked applicants
5. Generates summary report of awarded scholarships
6. Demonstrates legacy terminology usage by showing flagged applicants