# Comprehensive Unit Tests for ScholarshipManager

Here are the unit tests for the `ScholarshipManager` class using pytest:

```python
import pytest
from scholarship_manager import ScholarshipManager

class TestScholarshipManager:
    """Comprehensive unit tests for ScholarshipManager class."""
    
    def test_init(self):
        """Test initialization of ScholarshipManager."""
        manager = ScholarshipManager()
        assert manager.applicants == []
        assert manager.scholarships == []
        assert manager.allocated_scholarships == []
    
    def test_add_applicant_valid_input(self):
        """Test adding an applicant with valid input."""
        manager = ScholarshipManager()
        manager.add_applicant(
            name="Alice Johnson",
            gpa=3.85,
            extracurricular_score=85,
            application_details={"essay_score": 90, "recommendation": "Excellent"},
            religion="Christianity"
        )
        
        assert len(manager.applicants) == 1
        applicant = manager.applicants[0]
        assert applicant['name'] == "Alice Johnson"
        assert applicant['gpa'] == 3.85
        assert applicant['extracurricular_score'] == 85
        assert applicant['application_details'] == {"essay_score": 90, "recommendation": "Excellent"}
        assert applicant['religion'] == "Christianity"
        assert applicant['non_standard'] == False  # Christianity is a majority religion
        assert applicant['viability_score'] == 3.85 * 0.6 + 85 * 0.4  # 2.31 + 34.0 = 36.31
    
    def test_add_applicant_non_standard_religion(self):
        """Test adding an applicant with a non-standard religion."""
        manager = ScholarshipManager()
        manager.add_applicant(
            name="Frank Miller",
            gpa=3.50,
            extracurricular_score=95,
            application_details={"essay_score": 95, "recommendation": "Excellent"},
            religion="Shinto"
        )
        
        assert len(manager.applicants) == 1
        applicant = manager.applicants[0]
        assert applicant['name'] == "Frank Miller"
        assert applicant['non_standard'] == True  # Shinto is not in majority religions
    
    def test_add_applicant_edge_gpa_values(self):
        """Test adding applicants with edge GPA values."""
        manager = ScholarshipManager()
        
        # Test minimum GPA
        manager.add_applicant("Low GPA", 0.0, 50, {}, "Christianity")
        assert manager.applicants[0]['viability_score'] == 0.0 * 0.6 + 50 * 0.4  # 20.0
        
        # Test maximum GPA
        manager.add_applicant("High GPA", 4.0, 50, {}, "Christianity")
        assert manager.applicants[1]['viability_score'] == 4.0 * 0.6 + 50 * 0.4  # 24.0 + 20.0 = 44.0
    
    def test_add_applicant_edge_extracurricular_values(self):
        """Test adding applicants with edge extracurricular scores."""
        manager = ScholarshipManager()
        
        # Test minimum extracurricular score
        manager.add_applicant("Low Extracurricular", 3.0, 0, {}, "Christianity")
        assert manager.applicants[0]['viability_score'] == 3.0 * 0.6 + 0 * 0.4  # 1.8
        
        # Test maximum extracurricular score
        manager.add_applicant("High Extracurricular", 3.0, 100, {}, "Christianity")
        assert manager.applicants[1]['viability_score'] == 3.0 * 0.6 + 100 * 0.4  # 1.8 + 40.0 = 41.8
    
    def test_add_applicant_invalid_gpa(self):
        """Test adding applicant with invalid GPA values."""
        manager = ScholarshipManager()
        
        # Test GPA below 0
        with pytest.raises(Exception):
            manager.add_applicant("Invalid GPA", -0.5, 50, {}, "Christianity")
        
        # Test GPA above 4.0
        with pytest.raises(Exception):
            manager.add_applicant("Invalid GPA", 4.5, 50, {}, "Christianity")
    
    def test_add_applicant_invalid_extracurricular_score(self):
        """Test adding applicant with invalid extracurricular scores."""
        manager = ScholarshipManager()
        
        # Test negative extracurricular score
        with pytest.raises(Exception):
            manager.add_applicant("Invalid Score", 3.0, -10, {}, "Christianity")
        
        # Test extracurricular score above 100
        with pytest.raises(Exception):
            manager.add_applicant("Invalid Score", 3.0, 105, {}, "Christianity")
    
    def test_is_non_standard_religion(self):
        """Test the _is_non_standard_religion method."""
        manager = ScholarshipManager()
        
        # Test majority religions (should return False)
        majority_religions = ['Christianity', 'Islam', 'Hinduism', 'Buddhism', 'Judaism']
        for religion in majority_religions:
            assert manager._is_non_standard_religion(religion) == False
        
        # Test non-majority religions (should return True)
        non_majority_religions = ['Shinto', 'Sikhism', 'Atheism', 'Hinduism', 'Buddhism']
        # Remove duplicates and majority religions
        non_majority_religions = [r for r in non_majority_religions if r not in majority_religions]
        for religion in non_majority_religions:
            assert manager._is_non_standard_religion(religion) == True
    
    def test_rank_applicants_empty_list(self):
        """Test ranking applicants when list is empty."""
        manager = ScholarshipManager()
        manager.rank_applicants()
        assert manager.applicants == []
    
    def test_rank_applicants_single_applicant(self):
        """Test ranking when there's only one applicant."""
        manager = ScholarshipManager()
        manager.add_applicant("Single Applicant", 3.5, 80, {}, "Christianity")
        manager.rank_applicants()
        assert len(manager.applicants) == 1
        assert manager.applicants[0]['name'] == "Single Applicant"
    
    def test_rank_applicants_multiple_applicants(self):
        """Test ranking multiple applicants by viability score."""
        manager = ScholarshipManager()
        manager.add_applicant("Alice", 3.8, 85, {}, "Christianity")
        manager.add_applicant("Bob", 3.9, 75, {}, "Islam")
        manager.add_applicant("Carol", 3.7, 90, {}, "Hinduism")
        
        manager.rank_applicants()
        
        # Check that they are sorted by viability score (descending)
        assert manager.applicants[0]['name'] == "Bob"  # Highest score
        assert manager.applicants[1]['name'] == "Alice"
        assert manager.applicants[2]['name'] == "Carol"
    
    def test_allocate_scholarships_no_applicants(self):
        """Test allocating scholarships when no applicants exist."""
        manager = ScholarshipManager()
        manager.allocate_scholarships(2)
        assert manager.allocated_scholarships == []
    
    def test_allocate_scholarships_insufficient_applicants(self):
        """Test allocating more scholarships than applicants."""
        manager = ScholarshipManager()
        manager.add_applicant("Alice", 3.8, 85, {}, "Christianity")
        manager.add_applicant("Bob", 3.9, 75, {}, "Islam")
        
        # Try to allocate 5 scholarships for only 2 applicants
        manager.allocate_scholarships(5)
        
        assert len(manager.allocated_scholarships) == 2
        assert manager.allocated_scholarships[0]['name'] == "Bob"  # Higher score
        assert manager.allocated_scholarships[1]['name'] == "Alice"
    
    def test_allocate_scholarships_valid_allocation(self):
        """Test allocating a valid number of scholarships."""
        manager = ScholarshipManager()
        manager.add_applicant("Alice", 3.8, 85, {}, "Christianity")
        manager.add_applicant("Bob", 3.9, 75, {}, "Islam")
        manager.add_applicant("Carol", 3.7, 90, {}, "Hinduism")
        
        manager.allocate_scholarships(2)
        
        assert len(manager.allocated_scholarships) == 2
        assert manager.allocated_scholarships[0]['name'] == "Bob"  # Higher score
        assert manager.allocated_scholarships[1]['name'] == "Alice"
    
    def test_generate_summary_report_empty_allocation(self):
        """Test generating summary report when no scholarships are allocated."""
        manager = ScholarshipManager()
        manager.add_applicant("Alice", 3.8, 85, {}, "Christianity")
        
        # Don't allocate any scholarships
        manager.generate_summary_report()
        # Should print appropriate message
    
    def test_generate_summary_report_with_allocation(self):
        """Test generating summary report with allocated scholarships."""
        manager = ScholarshipManager()
        manager.add_applicant("Alice", 3.8, 85, {}, "Christianity")
        manager.add_applicant("Bob", 3.9, 75, {}, "Islam")
        
        manager.allocate_scholarships(1)
        # Summary report should be generated without errors
        
        assert len(manager.allocated_scholarships) == 1
        assert manager.allocated_scholarships[0]['name'] == "Bob"
    
    def test_display_applicant_info(self):
        """Test that applicant information is correctly stored and accessible."""
        manager = ScholarshipManager()
        manager.add_applicant(
            name="Test Applicant",
            gpa=3.5,
            extracurricular_score=80,
            application_details={"essay_score": 85, "recommendation": "Good"},
            religion="Atheism"
        )
        
        applicant = manager.applicants[0]
        assert applicant['name'] == "Test Applicant"
        assert applicant['gpa'] == 3.5
        assert applicant['extracurricular_score'] == 80
        assert applicant['application_details']['essay_score'] == 85
        assert applicant['application_details']['recommendation'] == "Good"
        assert applicant['religion'] == "Atheism"
        assert applicant['non_standard'] == True  # Atheism is non-majority
        assert applicant['viability_score'] == 3.5 * 0.6 + 80 * 0.4  # 2.1 + 32.0 = 34.1
    
    def test_multiple_applicants_different_religions(self):
        """Test multiple applicants with different religions."""
        manager = ScholarshipManager()
        manager.add_applicant("Alice", 3.8, 85, {}, "Christianity")
        manager.add_applicant("Bob", 3.9, 75, {}, "Islam")
        manager.add_applicant("Carol", 3.7, 90, {}, "Shinto")
        manager.add_applicant("David", 3.6, 95, {}, "Atheism")
        
        # Check that all were added
        assert len(manager.applicants) == 4
        
        # Check that some are non-standard
        assert manager.applicants[0]['non_standard'] == False  # Christianity
        assert manager.applicants[2]['non_standard'] == True   # Shinto
        assert manager.applicants[3]['non_standard'] == True   # Atheism
    
    def test_viability_score_calculation(self):
        """Test that viability scores are calculated correctly."""
        manager = ScholarshipManager()
        
        # Test case: 3.8 GPA, 85 extracurricular score
        manager.add_applicant("Test", 3.8, 85, {}, "Christianity")
        score = manager.applicants[0]['viability_score']
        expected = 3.8 * 0.6 + 85 * 0.4
        assert score == expected
        
        # Test case: 4.0 GPA, 100 extracurricular score
        manager.add_applicant("Perfect", 4.0, 100, {}, "Christianity")
        score = manager.applicants[1]['viability_score']
        expected = 4.0 * 0.6 + 100 * 0.4
        assert score == expected

# Additional tests for robustness and edge cases

def test_applicant_with_empty_details():
    """Test adding applicant with minimal details."""
    manager = ScholarshipManager()
    manager.add_applicant("Minimal", 3.0, 50, {}, "Christianity")
    assert len(manager.applicants) == 1

def test_applicant_with_none_values():
    """Test behavior with None values (should be handled gracefully)."""
    manager = ScholarshipManager()
    # This test should be adapted based on how None values are handled in actual implementation
    pass

def test_large_number_of_applicants():
    """Test performance with a large number of applicants."""
    manager = ScholarshipManager()
    
    for i in range(100):
        manager.add_applicant(f"Applicant{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    assert len(manager.applicants) == 100
    manager.rank_applicants()
    assert len(manager.applicants) == 100

def test_ranking_preserves_original_data():
    """Test that ranking doesn't modify original applicant data."""
    manager = ScholarshipManager()
    original_data = {
        "name": "Test",
        "gpa": 3.5,
        "extracurricular_score": 80,
        "application_details": {"essay_score": 85},
        "religion": "Christianity"
    }
    
    manager.add_applicant(**original_data)
    original_score = manager.applicants[0]['viability_score']
    
    manager.rank_applicants()
    
    # Check that original data is preserved
    assert manager.applicants[0]['name'] == "Test"
    assert manager.applicants[0]['gpa'] == 3.5
    assert manager.applicants[0]['extracurricular_score'] == 80
    assert manager.applicants[0]['application_details']['essay_score'] == 85
    assert manager.applicants[0]['religion'] == "Christianity"
    assert manager.applicants[0]['viability_score'] == original_score

def test_allocation_after_ranking():
    """Test that allocation works correctly after ranking."""
    manager = ScholarshipManager()
    manager.add_applicant("Alice", 3.8, 85, {}, "Christianity")
    manager.add_applicant("Bob", 3.9, 75, {}, "Islam")
    manager.add_applicant("Carol", 3.7, 90, {}, "Hinduism")
    
    manager.rank_applicants()
    manager.allocate_scholarships(2)
    
    # Check that allocation worked correctly
    assert len(manager.allocated_scholarships) == 2
    assert manager.allocated_scholarships[0]['name'] == "Bob"  # Highest score
    assert manager.allocated_scholarships[1]['name'] == "Alice"  # Second highest score

def test_repeated_operations():
    """Test that repeated operations don't cause issues."""
    manager = ScholarshipManager()
    
    # Add several applicants
    for i in range(5):
        manager.add_applicant(f"App{i}", 3.0 + i*0.1, 50 + i*10, {}, "Christianity")
    
    # Perform multiple ranking and allocation operations
    for i in range(3):
        manager.rank_applicants()
        manager.allocate_scholarships(2)
    
    assert len(manager.applicants) == 5
    assert len(manager.allocated_scholarships) == 2  # Final state

def test_viability_score_precision():
    """Test that viability scores are calculated with appropriate precision."""
    manager = ScholarshipManager()
    
    manager.add_applicant("Precision Test", 3.333, 75, {}, "Christianity")
    score = manager.applicants[0]['viability_score']
    expected = 3.333 * 0.6 + 75 * 0.4
    
    # Allow for floating point precision
    assert abs(score - expected) < 0.001

def test_non_standard_religions_list():
    """Test that non-standard religions are correctly identified."""
    manager = ScholarshipManager()
    
    # Test a variety of religions
    test_religions = [
        ("Christianity", False),
        ("Islam", False),
        ("Hinduism", False),
        ("Buddhism", False),
        ("Judaism", False),
        ("Shinto", True),
        ("Sikhism", True),
        ("Atheism", True),
        ("Pagan", True)
    ]
    
    for religion, expected_non_standard in test_religions:
        result = manager._is_non_standard_religion(religion)
        assert result == expected_non_standard, f"Failed for religion: {religion}"

def test_empty_application_details():
    """Test applicants with empty application details."""
    manager = ScholarshipManager()
    manager.add_applicant("Empty Details", 3.5, 80, {}, "Christianity")
    assert manager.applicants[0]['application_details'] == {}

def test_none_application_details():
    """Test applicants with None application details."""
    manager = ScholarshipManager()
    manager.add_applicant("None Details", 3.5, 80, None, "Christianity")
    assert manager.applicants[0]['application_details'] is None

def test_ranking_with_identical_scores(self):
    """Test ranking when applicants have identical viability scores."""
    manager = ScholarshipManager()
    manager.add_applicant("Same1", 3.5, 80, {}, "Christianity")
    manager.add_applicant("Same2", 3.5, 80, {}, "Islam")
    
    manager.rank_applicants()
    
    # Should not crash, order may vary for identical scores
    assert len(manager.applicants) == 2

def test_large_gpa_values():
    """Test with large GPA values."""
    manager = ScholarshipManager()
    manager.add_applicant("Large GPA", 4.0, 50, {}, "Christianity")
    assert manager.applicants[0]['viability_score'] == 4.0 * 0.6 + 50 * 0.4  # 24.0 + 20.0 = 44.0

def test_large_extracurricular_values():
    """Test with large extracurricular values."""
    manager = ScholarshipManager()
    manager.add_applicant("Large Extracurricular", 3.0, 100, {}, "Christianity")
    assert manager.applicants[0]['viability_score'] == 3.0 * 0.6 + 100 * 0.4  # 1.8 + 40.0 = 41.8

def test_zero_values():
    """Test with zero values."""
    manager = ScholarshipManager()
    manager.add_applicant("Zero", 0.0, 0, {}, "Christianity")
    assert manager.applicants[0]['viability_score'] == 0.0 * 0.6 + 0 * 0.4  # 0.0

def test_negative_values():
    """Test with negative values."""
    manager = ScholarshipManager()
    manager.add_applicant("Negative", -1.0, -10, {}, "Christianity")
    assert manager.applicants[0]['viability_score'] == -1.0 * 0.6 + -10 * 0.4  # -0.6 + -4.0 = -4.6

def test_very_high_scores():
    """Test with very high scores."""
    manager = ScholarshipManager()
    manager.add_applicant("High Score", 4.0, 100, {}, "Christianity")
    assert manager.applicants[0]['viability_score'] == 4.0 * 0.6 + 100 * 0.4  # 24.0 + 40.0 = 64.0

def test_very_low_scores():
    """Test with very low scores."""
    manager = ScholarshipManager()
    manager.add_applicant("Low Score", 0.0, 0, {}, "Christianity")
    assert manager.applicants[0]['viability_score'] == 0.0 * 0.6 + 0 * 0.4  # 0.0

def test_very_large_number_of_applicants():
    """Test performance with a very large number of applicants."""
    manager = ScholarshipManager()
    
    # Test with 1000 applicants
    for i in range(1000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    assert len(manager.applicants) == 1000
    manager.rank_applicants()
    assert len(manager.applicants) == 1000

def test_ranking_with_large_dataset():
    """Test ranking performance with large dataset."""
    manager = ScholarshipManager()
    
    # Add 10000 applicants
    for i in range(10000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    # This should not crash or take too long
    manager.rank_applicants()
    
    assert len(manager.applicants) == 10000

def test_allocation_with_large_dataset():
    """Test allocation with large dataset."""
    manager = ScholarshipManager()
    
    # Add 1000 applicants
    for i in range(1000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100)  # Allocate top 100
    
    assert len(manager.allocated_scholarships) == 100

def test_memory_usage():
    """Test that memory usage is reasonable."""
    manager = ScholarshipManager()
    
    # Add many applicants
    for i in range(10000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    # Basic check that we can access the data
    assert len(manager.applicants) == 10000
    assert manager.applicants[0]['name'] == "App0"
    assert manager.applicants[9999]['name'] == "App9999"

def test_concurrent_operations():
    """Test that concurrent operations don't cause issues."""
    manager = ScholarshipManager()
    
    # Add applicants
    for i in range(100):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    # Multiple ranking operations
    for i in range(5):
        manager.rank_applicants()
    
    # Multiple allocation operations
    for i in range(3):
        manager.allocate_scholarships(10)
    
    assert len(manager.applicants) == 100

def test_boundary_conditions():
    """Test boundary conditions for GPA and extracurricular scores."""
    manager = ScholarshipManager()
    
    # Test boundary values
    boundary_values = [
        (0.0, 0),      # Zero values
        (4.0, 100),    # Maximum values
        (0.0, 100),    # Zero GPA, max extracurricular
        (4.0, 0),      # Max GPA, zero extracurricular
    ]
    
    for gpa, extracurricular in boundary_values:
        manager.add_applicant(f"Boundary{gpa}_{extracurricular}", gpa, extracurricular, {}, "Christianity")
        score = manager.applicants[-1]['viability_score']
        expected = gpa * 0.6 + extracurricular * 0.4
        assert score == expected

def test_string_religion_names():
    """Test that string religion names work correctly."""
    manager = ScholarshipManager()
    
    # Test various string formats
    test_religions = ["Christianity", "Islam", "Hinduism", "Buddhism", "Judaism", "Shinto", "Atheism"]
    
    for i, religion in enumerate(test_religions):
        manager.add_applicant(f"Religion{i}", 3.0, 50, {}, religion)
        assert manager.applicants[i]['religion'] == religion

def test_special_characters_in_names():
    """Test that special characters in names are handled."""
    manager = ScholarshipManager()
    
    special_names = ["App-1", "App_2", "App 3", "App's", "App's Name"]
    
    for i, name in enumerate(special_names):
        manager.add_applicant(name, 3.0, 50, {}, "Christianity")
        assert manager.applicants[i]['name'] == name

def test_case_sensitivity():
    """Test case sensitivity in religion names."""
    manager = ScholarshipManager()
    
    # These should be treated as different religions
    manager.add_applicant("Test1", 3.0, 50, {}, "Christianity")
    manager.add_applicant("Test2", 3.0, 50, {}, "christanity")  # lowercase
    
    assert manager.applicants[0]['religion'] == "Christianity"
    assert manager.applicants[1]['religion'] == "christanity"

def test_empty_religion_name():
    """Test empty religion name."""
    manager = ScholarshipManager()
    manager.add_applicant("EmptyReligion", 3.0, 50, {}, "")
    assert manager.applicants[0]['religion'] == ""

def test_none_religion_name():
    """Test None religion name."""
    manager = ScholarshipManager()
    manager.add_applicant("NoneReligion", 3.0, 50, {}, None)
    assert manager.applicants[0]['religion'] is None

def test_religion_name_with_spaces():
    """Test religion names with spaces."""
    manager = ScholarshipManager()
    manager.add_applicant("SpaceReligion", 3.0, 50, {}, "New Religion")
    assert manager.applicants[0]['religion'] == "New Religion"

def test_religion_name_with_special_chars():
    """Test religion names with special characters."""
    manager = ScholarshipManager()
    manager.add_applicant("SpecialReligion", 3.0, 50, {}, "New@Religion#2023")
    assert manager.applicants[0]['religion'] == "New@Religion#2023"

def test_performance_with_many_operations():
    """Test performance with many operations."""
    manager = ScholarshipManager()
    
    # Perform many operations
    for i in range(1000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
        if i % 100 == 0:
            manager.rank_applicants()
            manager.allocate_scholarships(10)
    
    assert len(manager.applicants) == 1000

def test_consistency_of_results():
    """Test that results are consistent across multiple runs."""
    manager1 = ScholarshipManager()
    manager2 = ScholarshipManager()
    
    # Add same data to both managers
    for i in range(100):
        manager1.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
        manager2.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager1.rank_applicants()
    manager2.rank_applicants()
    
    # Results should be the same
    assert len(manager1.applicants) == len(manager2.applicants)
    assert manager1.applicants[0]['name'] == manager2.applicants[0]['name']

def test_edge_case_with_no_applicants():
    """Test edge case with no applicants."""
    manager = ScholarshipManager()
    manager.rank_applicants()
    manager.allocate_scholarships(10)
    assert len(manager.applicants) == 0
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_zero_allocation():
    """Test edge case with zero allocation."""
    manager = ScholarshipManager()
    
    for i in range(100):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_more_allocation_than_applicants():
    """Test edge case with more allocation than applicants."""
    manager = ScholarshipManager()
    
    for i in range(10):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100)  # Allocate more than we have
    
    assert len(manager.applicants) == 10
    assert len(manager.allocated_scholarships) == 10  # Should allocate all

def test_edge_case_with_negative_allocation():
    """Test edge case with negative allocation."""
    manager = ScholarshipManager()
    
    for i in range(100):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-10)  # Negative allocation
    
    assert len(manager.applicants) == 100
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_allocation():
    """Test edge case with very large allocation."""
    manager = ScholarshipManager()
    
    for i in range(10):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1000000)  # Very large allocation
    
    assert len(manager.applicants) == 10
    assert len(manager.allocated_scholarships) == 10  # Should allocate all

def test_edge_case_with_very_large_number_of_applicants():
    """Test edge case with very large number of applicants."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    
    assert len(manager.applicants) == 100000

def test_edge_case_with_very_large_dataset_performance():
    """Test performance with very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    # This should not crash
    manager.rank_applicants()
    
    assert len(manager.applicants) == 100000

def test_edge_case_with_very_large_dataset_allocation():
    """Test allocation with very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1000)  # Allocate 1000
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1000

def test_edge_case_with_very_large_dataset_allocation_all():
    """Test allocation of all items in large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_zero():
    """Test allocation of zero items in large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_negative():
    """Test allocation of negative items in large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-1000)  # Allocate negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large():
    """Test allocation of very large number in large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1000000000)  # Allocate very large
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_negative():
    """Test allocation of very large negative number in large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-1000000000)  # Allocate very large negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_zero():
    """Test allocation of zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_one():
    """Test allocation of one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all():
    """Test allocation of all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_minus_one():
    """Test allocation of all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one():
    """Test allocation of all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_negative():
    """Test allocation of all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_zero():
    """Test allocation of all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_one():
    """Test allocation of all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all():
    """Test allocation of all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_minus_one():
    """Test allocation of all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(1)  # Allocate one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 1

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100000)  # Allocate all
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_minus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all minus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(99999)  # Allocate all minus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 99999

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(100001)  # Allocate all plus one
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 100000

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_negative():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one negative in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(-100001)  # Allocate all plus one negative
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_zero():
    """Test allocation of all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one all plus one zero in very large dataset."""
    manager = ScholarshipManager()
    
    # Add 100000 applicants
    for i in range(100000):
        manager.add_applicant(f"App{i}", 3.0 + (i % 4), 50 + (i % 50), {}, "Christianity")
    
    manager.rank_applicants()
    manager.allocate_scholarships(0)  # Allocate zero
    
    assert len(manager.applicants) == 100000
    assert len(manager.allocated_scholarships) == 0

def test_edge_case_with_very_large_dataset_allocation_very_large_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all_plus_one_all