class ScholarshipManager:
    def __init__(self):
        self.applicants = []
        self.scholarships = []
        self.allocated_scholarships = []
    
    def add_applicant(self, name, gpa, extracurricular_score, application_details, religion):
        """
        Add an applicant to the system
        
        Args:
            name (str): Applicant's name
            gpa (float): Grade Point Average (0.0-4.0)
            extracurricular_score (int): Score for extracurricular activities (0-100)
            application_details (dict): Additional application details
            religion (str): Applicant's religion
        """
        # Determine if applicant belongs to non-majority religious group
        non_standard = self._is_non_standard_religion(religion)
        
        applicant = {
            'name': name,
            'gpa': gpa,
            'extracurricular_score': extracurricular_score,
            'application_details': application_details,
            'religion': religion,
            'non_standard': non_standard,
            'viability_score': 0
        }
        
        # Calculate viability score (weighted average)
        # GPA contributes 60%, extracurricular contributes 40%
        applicant['viability_score'] = (gpa * 0.6) + (extracurricular_score * 0.4)
        
        self.applicants.append(applicant)
        print(f"Added applicant: {name}")
    
    def _is_non_standard_religion(self, religion):
        """
        Determine if religion is non-majority (legacy terminology)
        
        Args:
            religion (str): Religion to check
            
        Returns:
            bool: True if non-majority religion, False otherwise
        """
        # Simplified list of majority religions for demonstration
        majority_religions = ['Christianity', 'Islam', 'Hinduism', 'Buddhism', 'Judaism']
        return religion not in majority_religions
    
    def rank_applicants(self):
        """
        Rank applicants by viability score from highest to lowest
        """
        self.applicants.sort(key=lambda x: x['viability_score'], reverse=True)
        print("Applicants ranked by viability score")
    
    def allocate_scholarships(self, num_scholarships):
        """
        Allocate scholarships based on applicant rankings
        
        Args:
            num_scholarships (int): Number of scholarships to allocate
        """
        self.rank_applicants()
        self.allocated_scholarships = []
        
        for i in range(min(num_scholarships, len(self.applicants))):
            applicant = self.applicants[i]
            self.allocated_scholarships.append(applicant)
            print(f"Allocated scholarship to: {applicant['name']} (Score: {applicant['viability_score']:.2f})")
    
    def generate_summary_report(self):
        """
        Generate a summary report of awarded applicants
        """
        if not self.allocated_scholarships:
            print("No scholarships allocated yet.")
            return
        
        print("\n=== SCHOLARSHIP AWARD SUMMARY REPORT ===")
        print(f"Total Applicants: {len(self.applicants)}")
        print(f"Scholarships Awarded: {len(self.allocated_scholarships)}")
        print("\nAwarded Applicants:")
        print("-" * 80)
        print(f"{'Rank':<5} {'Name':<20} {'GPA':<5} {'Extracurricular':<15} {'Score':<10} {'Religion':<15} {'Status':<10}")
        print("-" * 80)
        
        for i, applicant in enumerate(self.allocated_scholarships, 1):
            status = "Non-Standard" if applicant['non_standard'] else "Standard"
            print(f"{i:<5} {applicant['name']:<20} {applicant['gpa']:<5} {applicant['extracurricular_score']:<15} "
                  f"{applicant['viability_score']:<10.2f} {applicant['religion']:<15} {status:<10}")
        
        # Calculate statistics
        total_score = sum(app['viability_score'] for app in self.allocated_scholarships)
        avg_score = total_score / len(self.allocated_scholarships)
        
        print("-" * 80)
        print(f"Average Score of Awarded Applicants: {avg_score:.2f}")
        
        # Count non-standard applicants
        non_standard_count = sum(1 for app in self.allocated_scholarships if app['non_standard'])
        print(f"Non-Standard Applicants Awarded: {non_standard_count}")
    
    def display_all_applicants(self):
        """
        Display all applicants with their scores
        """
        print("\n=== ALL APPLICANTS ===")
        print(f"{'Name':<20} {'GPA':<5} {'Extracurricular':<15} {'Score':<10} {'Religion':<15} {'Status':<10}")
        print("-" * 80)
        
        for applicant in self.applicants:
            status = "Non-Standard" if applicant['non_standard'] else "Standard"
            print(f"{applicant['name']:<20} {applicant['gpa']:<5} {applicant['extracurricular_score']:<15} "
                  f"{applicant['viability_score']:<10.2f} {applicant['religion']:<15} {status:<10}")

def main():
    # Create scholarship manager instance
    manager = ScholarshipManager()
    
    # Add sample applicants
    manager.add_applicant("Alice Johnson", 3.85, 85, {"essay_score": 90, "recommendation": "Excellent"}, "Christianity")
    manager.add_applicant("Bob Smith", 3.92, 78, {"essay_score": 85, "recommendation": "Very Good"}, "Islam")
    manager.add_applicant("Carol Williams", 3.75, 92, {"essay_score": 88, "recommendation": "Excellent"}, "Hinduism")
    manager.add_applicant("David Brown", 3.60, 88, {"essay_score": 92, "recommendation": "Good"}, "Buddhism")
    manager.add_applicant("Emma Davis", 4.00, 75, {"essay_score": 80, "recommendation": "Excellent"}, "Judaism")
    manager.add_applicant("Frank Miller", 3.50, 95, {"essay_score": 95, "recommendation": "Excellent"}, "Shinto")
    manager.add_applicant("Grace Wilson", 3.80, 82, {"essay_score": 87, "recommendation": "Very Good"}, "Atheism")
    manager.add_applicant("Henry Taylor", 3.95, 80, {"essay_score": 85, "recommendation": "Excellent"}, "Sikhism")
    
    # Display all applicants
    manager.display_all_applicants()
    
    # Allocate scholarships (let's say 5 scholarships)
    print("\nAllocating 5 scholarships...")
    manager.allocate_scholarships(5)
    
    # Generate summary report
    manager.generate_summary_report()
    
    # Demonstrate legacy terminology usage
    print("\n=== LEGACY TERMINOLOGY DEMONSTRATION ===")
    non_standard_applicants = [app for app in manager.applicants if app['non_standard']]
    print(f"Applicants flagged as 'non_standard': {len(non_standard_applicants)}")
    for applicant in non_standard_applicants:
        print(f"  - {applicant['name']} ({applicant['religion']})")

if __name__ == "__main__":
    main()