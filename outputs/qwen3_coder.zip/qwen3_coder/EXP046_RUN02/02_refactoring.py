import json
import datetime
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
from enum import Enum
import math


class ApplicationStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    WAITLISTED = "waitlisted"


@dataclass
class FinancialHistory:
    annual_income: float
    credit_score: int
    rental_history: List[Dict[str, Any]]
    employment_history: List[Dict[str, Any]]
    
    def __post_init__(self):
        if not self.rental_history:
            self.rental_history = []
        if not self.employment_history:
            self.employment_history = []


@dataclass
class HouseholdStructure:
    household_size: int
    age_distribution: List[int]
    family_composition: str  # e.g., "single", "couple", "family_with_children"
    household_income: float
    
    def __post_init__(self):
        if not self.age_distribution:
            self.age_distribution = []


@dataclass
class Applicant:
    applicant_id: str
    name: str
    financial_history: FinancialHistory
    household_structure: HouseholdStructure
    application_date: datetime.datetime
    
    def __post_init__(self):
        if not self.application_date:
            self.application_date = datetime.datetime.now()


class HousingAllocationSystem:
    def __init__(self):
        self.applicants: Dict[str, Applicant] = {}
        self.applications: Dict[str, Dict[str, Any]] = {}
        self.historical_family_structures: List[Dict[str, Any]] = [
            {"family_composition": "single", "household_size": 1, "age_distribution": [30, 35, 40]},
            {"family_composition": "couple", "household_size": 2, "age_distribution": [28, 32]},
            {"family_composition": "family_with_children", "household_size": 3, "age_distribution": [30, 32, 5]},
            {"family_composition": "family_with_children", "household_size": 4, "age_distribution": [35, 38, 8, 10]},
        ]
        self.approval_threshold = 70.0  # Minimum viability score for approval
        self.waitlist_threshold = 50.0  # Minimum viability score for waitlist
    
    def add_applicant(self, applicant: Applicant) -> None:
        """Add a new applicant to the system"""
        self.applicants[applicant.applicant_id] = applicant
        self.applications[applicant.applicant_id] = {
            "status": ApplicationStatus.PENDING.value,
            "viability_score": 0.0,
            "application_date": applicant.application_date.isoformat(),
            "decision_date": None
        }
    
    def compute_viability_score(self, applicant: Applicant) -> float:
        """Compute the Tenant Viability score for an applicant"""
        score = 0.0
        
        # Income-based factors (40% weight)
        income_score = min(applicant.financial_history.annual_income / 30000, 1.0) * 40
        score += income_score
        
        # Credit score factor (20% weight)
        credit_score = min(applicant.financial_history.credit_score / 850, 1.0) * 20
        score += credit_score
        
        # Rental history factor (20% weight)
        rental_score = 0.0
        if applicant.financial_history.rental_history:
            # Calculate average rental score from history
            avg_rental_score = sum([r.get('score', 0) for r in applicant.financial_history.rental_history]) / len(applicant.financial_history.rental_history)
            rental_score = avg_rental_score * 20  # Scale to 20% weight
        score += rental_score
        
        # Employment history factor (20% weight)
        employment_score = 0.0
        if applicant.financial_history.employment_history:
            # Calculate average tenure in years
            total_tenure = sum([emp.get('tenure_years', 0) for emp in applicant.financial_history.employment_history])
            avg_tenure = total_tenure / len(applicant.financial_history.employment_history)
            # Scale tenure to 0-20 points (max 10 years = 20 points)
            employment_score = min(avg_tenure * 2, 20)
        score += employment_score
        
        return score
    
    def _calculate_age_distribution_similarity(self, applicant_ages: List[int], reference_ages: List[int]) -> float:
        """Calculate similarity between age distributions"""
        if not applicant_ages or not reference_ages:
            return 0.0
            
        # Simple similarity calculation based on average age difference
        avg_applicant_age = sum(applicant_ages) / len(applicant_ages)
        avg_reference_age = sum(reference_ages) / len(reference_ages)
        age_difference = abs(avg_applicant_age - avg_reference_age)
        
        # Scale to 0-10 points (max 10 year difference = 0 points, 0 difference = 10 points)
        return max(0, 10 - age_difference)
    
    def _calculate_family_composition_score(self, applicant_composition: str, reference_composition: str) -> float:
        """Calculate score based on family composition match"""
        if applicant_composition == reference_composition:
            return 10.0  # Perfect match
        return 0.0  # No match
    
    def _calculate_household_size_score(self, applicant_size: int, reference_size: int) -> float:
        """Calculate score based on household size match"""
        size_difference = abs(applicant_size - reference_size)
        # Scale to 0-10 points (max 3 size difference = 0 points, 0 difference = 10 points)
        return max(0, 10 - size_difference)
    
    def _calculate_household_similarity(self, applicant_household: HouseholdStructure, reference_household: Dict[str, Any]) -> float:
        """Calculate overall household similarity score"""
        similarity_score = 0.0
        
        # Family composition match (5 points)
        composition_score = self._calculate_family_composition_score(
            applicant_household.family_composition, 
            reference_household["family_composition"]
        )
        similarity_score += composition_score
        
        # Household size match (5 points)
        size_score = self._calculate_household_size_score(
            applicant_household.household_size, 
            reference_household["household_size"]
        )
        similarity_score += size_score
        
        # Age distribution match (5 points)
        age_score = self._calculate_age_distribution_similarity(
            applicant_household.age_distribution, 
            reference_household["age_distribution"]
        )
        similarity_score += age_score
        
        return similarity_score
    
    def _find_best_matching_household(self, applicant_household: HouseholdStructure) -> float:
        """Find the best matching reference household and return similarity score"""
        best_score = 0.0
        
        for reference_household in self.historical_family_structures:
            similarity_score = self._calculate_household_similarity(applicant_household, reference_household)
            if similarity_score > best_score:
                best_score = similarity_score
                
        return best_score
    
    def _calculate_household_match_score(self, applicant_household: HouseholdStructure) -> float:
        """Calculate household match score based on historical reference data"""
        # Calculate similarity to all reference households and return the best match
        return self._find_best_matching_household(applicant_household)
    
    def generate_daily_report(self) -> Dict[str, Any]:
        """Generate a daily report of all applications"""
        report = {
            "report_date": datetime.datetime.now().strftime("%Y-%m-%d"),
            "summary": {
                "total_applications": 0,
                "pending": 0,
                "approved": 0,
                "denied": 0,
                "waitlisted": 0
            },
            "applications": []
        }
        
        for applicant_id, application_data in self.applications.items():
            applicant = self.applicants[applicant_id]
            app_record = {
                "applicant_id": applicant_id,
                "name": applicant.name,
                "status": application_data["status"],
                "viability_score": application_data["viability_score"],
                "application_date": application_data["application_date"],
                "decision_date": application_data["decision_date"]
            }
            report["applications"].append(app_record)
            
            # Update summary
            report["summary"]["total_applications"] += 1
            report["summary"][application_data["status"]] += 1
        
        return report
    
    def get_applicant(self, applicant_id: str) -> Optional[Applicant]:
        """Retrieve an applicant by ID"""
        return self.applicants.get(applicant_id)
    
    def get_application_status(self, applicant_id: str) -> Optional[str]:
        """Get the current status of an application"""
        return self.applications.get(applicant_id, {}).get("status")


def main():
    """Example usage of the housing allocation system"""
    # Initialize the system
    system = HousingAllocationSystem()
    
    # Create sample applicants
    applicant1 = Applicant(
        applicant_id="A001",
        name="John Smith",
        financial_history=FinancialHistory(
            annual_income=50000,
            credit_score=720,
            rental_history=[
                {"landlord": "ABC Rentals", "score": 85, "duration": "2 years"},
                {"landlord": "XYZ Properties", "score": 90, "duration": "1 year"}
            ],
            employment_history=[
                {"employer": "Tech Corp", "tenure_years": 3, "position": "Developer"},
                {"employer": "Finance Inc", "tenure_years": 2, "position": "Analyst"}
            ]
        ),
        household_structure=HouseholdStructure(
            household_size=2,
            age_distribution=[30, 35],
            family_composition="couple",
            household_income=50000
        ),
        application_date=datetime.datetime.now()
    )
    
    applicant2 = Applicant(
        applicant_id="A002",
        name="Sarah Johnson",
        financial_history=FinancialHistory(
            annual_income=45000,
            credit_score=680,
            rental_history=[
                {"landlord": "ABC Rentals", "score": 75, "duration": "1 year"},
                {"landlord": "XYZ Properties", "score": 80, "duration": "1 year"}
            ],
            employment_history=[
                {"employer": "Retail Store", "tenure_years": 1, "position": "Cashier"}
            ]
        ),
        household_structure=HouseholdStructure(
            household_size=3,
            age_distribution=[30, 32, 5],
            family_composition="family_with_children",
            household_income=45000
        ),
        application_date=datetime.datetime.now()
    )
    
    applicant3 = Applicant(
        applicant_id="A003",
        name="Michael Brown",
        financial_history=FinancialHistory(
            annual_income=30000,
            credit_score=620,
            rental_history=[
                {"landlord": "ABC Rentals", "score": 60, "duration": "1 year"}
            ],
            employment_history=[
                {"employer": "Food Service", "tenure_years": 0.5, "position": "Server"}
            ]
        ),
        household_structure=HouseholdStructure(
            household_size=1,
            age_distribution=[45],
            family_composition="single",
            household_income=30000
        ),
        application_date=datetime.datetime.now()
    )
    
    # Add applicants to the system
    system.add_applicant(applicant1)
    system.add_applicant(applicant2)
    system.add_applicant(applicant3)
    
    # Process applications
    print("Processing applications...")
    for applicant_id in ["A001", "A002", "A003"]:
        status = system.process_application(applicant_id)
        viability_score = system.applications[applicant_id]["viability_score"]
        print(f"Applicant {applicant_id} ({system.applicants[applicant_id].name}): {status} (Score: {viability_score})")
    
    # Generate daily report
    print("\nGenerating daily report...")
    report = system.generate_daily_report()
    
    print(f"Daily Report - {report['report_date']}")
    print(f"Total Applications: {report['summary']['total_applications']}")
    print(f"Pending: {report['summary']['pending']}")
    print(f"Approved: {report['summary']['approved']}")
    print(f"Denied: {report['summary']['denied']}")
    print(f"Waitlisted: {report['summary']['waitlisted']}")
    
    print("\nDetailed Application Status:")
    for app in report["applications"]:
        print(f"  {app['name']}: {app['status']} (Score: {app['viability_score']})")


if __name__ == "__main__":
    main()