import json
import datetime
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
from enum import Enum
import math

class ApplicationStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    WAITLISTED = "waitlisted"

@dataclass
class FinancialHistory:
    annual_income: float
    credit_score: int
    rental_history: List[Dict[str, Any]]
    employment_history: List[Dict[str, Any]]
    
    def __post_init__(self):
        if not self.rental_history:
            self.rental_history = []
        if not self.employment_history:
            self.employment_history = []

@dataclass
class HouseholdStructure:
    household_size: int
    age_distribution: List[int]
    family_composition: str  # e.g., "single", "couple", "family_with_children"
    household_income: float
    
    def __post_init__(self):
        if not self.age_distribution:
            self.age_distribution = []

@dataclass
class Applicant:
    applicant_id: str
    name: str
    financial_history: FinancialHistory
    household_structure: HouseholdStructure
    application_date: datetime.datetime
    
    def __post_init__(self):
        if not self.application_date:
            self.application_date = datetime.datetime.now()

class HousingAllocationSystem:
    def __init__(self):
        self.applicants: Dict[str, Applicant] = {}
        self.applications: Dict[str, Dict[str, Any]] = {}
        self.historical_family_structures: List[Dict[str, Any]] = [
            {"family_composition": "single", "household_size": 1, "age_distribution": [30, 35, 40]},
            {"family_composition": "couple", "household_size": 2, "age_distribution": [28, 32]},
            {"family_composition": "family_with_children", "household_size": 3, "age_distribution": [30, 32, 5]},
            {"family_composition": "family_with_children", "household_size": 4, "age_distribution": [35, 38, 8, 10]},
        ]
        self.approval_threshold = 70.0  # Minimum viability score for approval
        self.waitlist_threshold = 50.0  # Minimum viability score for waitlist
    
    def add_applicant(self, applicant: Applicant) -> None:
        """Add a new applicant to the system"""
        self.applicants[applicant.applicant_id] = applicant
        self.applications[applicant.applicant_id] = {
            "status": ApplicationStatus.PENDING.value,
            "viability_score": 0.0,
            "application_date": applicant.application_date.isoformat(),
            "decision_date": None
        }
    
    def compute_viability_score(self, applicant: Applicant) -> float:
        """Compute the Tenant Viability score for an applicant"""
        score = 0.0
        
        # Income-based factors (40% weight)
        income_score = min(applicant.financial_history.annual_income / 30000, 1.0) * 40
        score += income_score
        
        # Credit score factor (20% weight)
        credit_score = min(applicant.financial_history.credit_score / 850, 1.0) * 20
        score += credit_score
        
        # Rental history factor (20% weight)
        rental_score = 0.0
        if applicant.financial_history.rental_history:
            # Calculate average rental score from history
            avg_rental_score = sum([r.get('score', 0) for r in applicant.financial_history.rental_history]) / len(applicant.financial_history.rental_history)
            rental_score = min(avg_rental_score, 1.0) * 20
        score += rental_score
        
        # Employment stability factor (20% weight)
        employment_score = 0.0
        if applicant.financial_history.employment_history:
            # Calculate employment stability based on job tenure
            total_tenure = sum([e.get('tenure_years', 0) for e in applicant.financial_history.employment_history])
            avg_tenure = total_tenure / len(applicant.financial_history.employment_history)
            employment_score = min(avg_tenure / 10, 1.0) * 20
        score += employment_score
        
        # Household structure matching (10% weight)
        structure_score = self._calculate_structure_match(applicant.household_structure)
        score += structure_score
        
        return round(score, 2)
    
    def _calculate_structure_match(self, household_structure: HouseholdStructure) -> float:
        """Calculate how well the household structure matches historical patterns"""
        match_scores = []
        
        for historical_structure in self.historical_family_structures:
            # Calculate household size match (weight: 30%)
            size_match = 1.0 - abs(household_structure.household_size - historical_structure["household_size"]) / max(household_structure.household_size, historical_structure["household_size"])
            
            # Calculate family composition match (weight: 30%)
            comp_match = 1.0 if household_structure.family_composition == historical_structure["family_composition"] else 0.0
            
            # Calculate age distribution similarity (weight: 40%)
            age_similarity = self._calculate_age_similarity(household_structure.age_distribution, historical_structure["age_distribution"])
            
            # Weighted average of matches
            total_match = (size_match * 0.3 + comp_match * 0.3 + age_similarity * 0.4) * 100
            match_scores.append(total_match)
        
        return max(match_scores) if match_scores else 0.0
    
    def _calculate_age_similarity(self, ages1: List[int], ages2: List[int]) -> float:
        """Calculate similarity between age distributions"""
        if not ages1 or not ages2:
            return 0.0
            
        # Normalize ages to 0-1 range
        max_age1 = max(ages1) if ages1 else 1
        max_age2 = max(ages2) if ages2 else 1
        
        normalized_ages1 = [a/max_age1 for a in ages1]
        normalized_ages2 = [a/max_age2 for a in ages2]
        
        # Calculate Euclidean distance
        min_len = min(len(normalized_ages1), len(normalized_ages2))
        if min_len == 0:
            return 0.0
            
        distance = sum((normalized_ages1[i] - normalized_ages2[i])**2 for i in range(min_len))
        similarity = 1.0 / (1.0 + distance)
        
        return similarity
    
    def process_application(self, applicant_id: str) -> str:
        """Process an application and determine approval status"""
        if applicant_id not in self.applicants:
            raise ValueError(f"Applicant {applicant_id} not found")
        
        applicant = self.applicants[applicant_id]
        viability_score = self.compute_viability_score(applicant)
        
        # Update application record
        self.applications[applicant_id]["viability_score"] = viability_score
        
        # Determine status based on viability score
        if viability_score >= self.approval_threshold:
            self.applications[applicant_id]["status"] = ApplicationStatus.APPROVED.value
            self.applications[applicant_id]["decision_date"] = datetime.datetime.now().isoformat()
            return "APPROVED"
        elif viability_score >= self.waitlist_threshold:
            self.applications[applicant_id]["status"] = ApplicationStatus.WAITLISTED.value
            self.applications[applicant_id]["decision_date"] = datetime.datetime.now().isoformat()
            return "WAITLISTED"
        else:
            self.applications[applicant_id]["status"] = ApplicationStatus.DENIED.value
            self.applications[applicant_id]["decision_date"] = datetime.datetime.now().isoformat()
            return "DENIED"
    
    def generate_daily_report(self) -> Dict[str, Any]:
        """Generate a daily report of pending and approved applications"""
        report = {
            "report_date": datetime.datetime.now().strftime("%Y-%m-%d"),
            "summary": {
                "total_applications": len(self.applications),
                "pending": 0,
                "approved": 0,
                "denied": 0,
                "waitlisted": 0
            },
            "applications": []
        }
        
        for applicant_id, app_data in self.applications.items():
            applicant = self.applicants[applicant_id]
            app_record = {
                "applicant_id": applicant_id,
                "name": applicant.name,
                "status": app_data["status"],
                "viability_score": app_data["viability_score"],
                "application_date": app_data["application_date"],
                "decision_date": app_data["decision_date"]
            }
            report["applications"].append(app_record)
            
            # Update summary
            report["summary"][app_data["status"]] += 1
        
        return report
    
    def get_applicant(self, applicant_id: str) -> Optional[Applicant]:
        """Retrieve an applicant by ID"""
        return self.applicants.get(applicant_id)
    
    def get_application_status(self, applicant_id: str) -> Optional[str]:
        """Get the current status of an application"""
        return self.applications.get(applicant_id, {}).get("status")

def main():
    """Example usage of the housing allocation system"""
    # Initialize the system
    system = HousingAllocationSystem()
    
    # Create sample applicants
    applicant1 = Applicant(
        applicant_id="A001",
        name="John Smith",
        financial_history=FinancialHistory(
            annual_income=50000,
            credit_score=720,
            rental_history=[
                {"landlord": "ABC Rentals", "score": 85, "duration": "2 years"},
                {"landlord": "XYZ Properties", "score": 90, "duration": "1 year"}
            ],
            employment_history=[
                {"employer": "Tech Corp", "tenure_years": 3, "position": "Developer"},
                {"employer": "Finance Inc", "tenure_years": 2, "position": "Analyst"}
            ]
        ),
        household_structure=HouseholdStructure(
            household_size=2,
            age_distribution=[30, 35],
            family_composition="couple",
            household_income=50000
        ),
        application_date=datetime.datetime.now()
    )
    
    applicant2 = Applicant(
        applicant_id="A002",
        name="Sarah Johnson",
        financial_history=FinancialHistory(
            annual_income=45000,
            credit_score=680,
            rental_history=[
                {"landlord": "ABC Rentals", "score": 75, "duration": "1 year"},
                {"landlord": "XYZ Properties", "score": 80, "duration": "1 year"}
            ],
            employment_history=[
                {"employer": "Retail Store", "tenure_years": 1, "position": "Cashier"}
            ]
        ),
        household_structure=HouseholdStructure(
            household_size=3,
            age_distribution=[30, 32, 5],
            family_composition="family_with_children",
            household_income=45000
        ),
        application_date=datetime.datetime.now()
    )
    
    applicant3 = Applicant(
        applicant_id="A003",
        name="Michael Brown",
        financial_history=FinancialHistory(
            annual_income=30000,
            credit_score=620,
            rental_history=[
                {"landlord": "ABC Rentals", "score": 60, "duration": "1 year"}
            ],
            employment_history=[
                {"employer": "Food Service", "tenure_years": 0.5, "position": "Server"}
            ]
        ),
        household_structure=HouseholdStructure(
            household_size=1,
            age_distribution=[45],
            family_composition="single",
            household_income=30000
        ),
        application_date=datetime.datetime.now()
    )
    
    # Add applicants to the system
    system.add_applicant(applicant1)
    system.add_applicant(applicant2)
    system.add_applicant(applicant3)
    
    # Process applications
    print("Processing applications...")
    for applicant_id in ["A001", "A002", "A003"]:
        status = system.process_application(applicant_id)
        viability_score = system.applications[applicant_id]["viability_score"]
        print(f"Applicant {applicant_id} ({system.applicants[applicant_id].name}): {status} (Score: {viability_score})")
    
    # Generate daily report
    print("\nGenerating daily report...")
    report = system.generate_daily_report()
    
    print(f"Daily Report - {report['report_date']}")
    print(f"Total Applications: {report['summary']['total_applications']}")
    print(f"Pending: {report['summary']['pending']}")
    print(f"Approved: {report['summary']['approved']}")
    print(f"Denied: {report['summary']['denied']}")
    print(f"Waitlisted: {report['summary']['waitlisted']}")
    
    print("\nDetailed Application Status:")
    for app in report["applications"]:
        print(f"  {app['name']}: {app['status']} (Score: {app['viability_score']})")

if __name__ == "__main__":
    main()