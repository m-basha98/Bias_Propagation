import pytest
import datetime
from unittest.mock import patch
from dataclasses import asdict

from your_module import (  # Replace 'your_module' with actual module name
    ApplicationStatus,
    FinancialHistory,
    HouseholdStructure,
    Applicant,
    HousingAllocationSystem
)


class TestFinancialHistory:
    def test_financial_history_initialization(self):
        """Test FinancialHistory initialization with all fields"""
        history = FinancialHistory(
            annual_income=50000,
            credit_score=720,
            rental_history=[{"landlord": "ABC", "score": 85}],
            employment_history=[{"employer": "Tech", "tenure_years": 2}]
        )
        
        assert history.annual_income == 50000
        assert history.credit_score == 720
        assert len(history.rental_history) == 1
        assert len(history.employment_history) == 1

    def test_financial_history_empty_lists(self):
        """Test FinancialHistory with empty lists"""
        history = FinancialHistory(
            annual_income=50000,
            credit_score=720,
            rental_history=[],
            employment_history=[]
        )
        
        assert history.rental_history == []
        assert history.employment_history == []


class TestHouseholdStructure:
    def test_household_structure_initialization(self):
        """Test HouseholdStructure initialization with all fields"""
        structure = HouseholdStructure(
            household_size=3,
            age_distribution=[25, 30, 35],
            family_composition="family_with_children",
            household_income=60000
        )
        
        assert structure.household_size == 3
        assert structure.age_distribution == [25, 30, 35]
        assert structure.family_composition == "family_with_children"
        assert structure.household_income == 60000

    def test_household_structure_empty_age_distribution(self):
        """Test HouseholdStructure with empty age distribution"""
        structure = HouseholdStructure(
            household_size=2,
            age_distribution=[],
            family_composition="couple",
            household_income=50000
        )
        
        assert structure.age_distribution == []


class TestApplicant:
    def test_applicant_initialization(self):
        """Test Applicant initialization with all fields"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=50000,
                credit_score=720,
                rental_history=[],
                employment_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_distribution=[30, 35],
                family_composition="couple",
                household_income=50000
            ),
            application_date=datetime.datetime.now()
        )
        
        assert applicant.applicant_id == "A001"
        assert applicant.name == "John Smith"
        assert applicant.application_date is not None

    def test_applicant_default_application_date(self):
        """Test Applicant with default application date"""
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=50000,
                credit_score=720,
                rental_history=[],
                employment_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_distribution=[30, 35],
                family_composition="couple",
                household_income=50000
            )
        )
        
        assert applicant.application_date is not None


class TestHousingAllocationSystem:
    def test_system_initialization(self):
        """Test HousingAllocationSystem initialization"""
        system = HousingAllocationSystem()
        
        assert system.applicants == {}
        assert system.applications == {}
        assert len(system.historical_family_structures) == 4
        assert system.approval_threshold == 70.0
        assert system.waitlist_threshold == 50.0

    def test_add_applicant(self):
        """Test adding an applicant to the system"""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=50000,
                credit_score=720,
                rental_history=[],
                employment_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_distribution=[30, 35],
                family_composition="couple",
                household_income=50000
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        
        assert "A001" in system.applicants
        assert "A001" in system.applications
        assert system.applicants["A001"] == applicant
        assert system.applications["A001"]["status"] == "pending"

    def test_compute_viability_score(self):
        """Test viability score computation with various inputs"""
        system = HousingAllocationSystem()
        
        # Test with high income, good credit, good rental history
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=80000,
                credit_score=750,
                rental_history=[
                    {"landlord": "ABC", "score": 90},
                    {"landlord": "XYZ", "score": 85}
                ],
                employment_history=[
                    {"employer": "Tech", "tenure_years": 5}
                ]
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_distribution=[30, 35],
                family_composition="couple",
                household_income=80000
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        
        # Test the actual computation (this requires mocking or direct access to private methods)
        # For now, just test that it doesn't crash
        assert True

    def test_process_application_approve(self):
        """Test processing application that should be approved"""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=80000,
                credit_score=750,
                rental_history=[
                    {"landlord": "ABC", "score": 90},
                    {"landlord": "XYZ", "score": 85}
                ],
                employment_history=[
                    {"employer": "Tech", "tenure_years": 5}
                ]
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_distribution=[30, 35],
                family_composition="couple",
                household_income=80000
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        
        # Mock the actual processing to ensure it returns approved
        with patch.object(system, '_calculate_viability_score', return_value=85.0):
            status = system.process_application("A001")
            assert status == "approved"
            assert system.applications["A001"]["viability_score"] == 85.0

    def test_process_application_waitlist(self):
        """Test processing application that should be waitlisted"""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A002",
            name="Jane Doe",
            financial_history=FinancialHistory(
                annual_income=60000,
                credit_score=680,
                rental_history=[
                    {"landlord": "ABC", "score": 75},
                    {"landlord": "XYZ", "score": 80}
                ],
                employment_history=[
                    {"employer": "Tech", "tenure_years": 3}
                ]
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_distribution=[25, 30],
                family_composition="couple",
                household_income=60000
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        
        # Mock the actual processing to ensure it returns waitlisted
        with patch.object(system, '_calculate_viability_score', return_value=65.0):
            status = system.process_application("A002")
            assert status == "waitlisted"
            assert system.applications["A002"]["viability_score"] == 65.0

    def test_process_application_deny(self):
        """Test processing application that should be denied"""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A003",
            name="Bob Johnson",
            financial_history=FinancialHistory(
                annual_income=30000,
                credit_score=600,
                rental_history=[
                    {"landlord": "ABC", "score": 60}
                ],
                employment_history=[
                    {"employer": "Tech", "tenure_years": 0.5}
                ]
            ),
            household_structure=HouseholdStructure(
                household_size=1,
                age_distribution=[45],
                family_composition="single",
                household_income=30000
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        
        # Mock the actual processing to ensure it returns denied
        with patch.object(system, '_calculate_viability_score', return_value=45.0):
            status = system.process_application("A003")
            assert status == "denied"
            assert system.applications["A003"]["viability_score"] == 45.0

    def test_generate_daily_report(self):
        """Test generating daily report"""
        system = HousingAllocationSystem()
        
        # Add some applicants
        applicant1 = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=50000,
                credit_score=720,
                rental_history=[],
                employment_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_distribution=[30, 35],
                family_composition="couple",
                household_income=50000
            ),
            application_date=datetime.datetime.now()
        )
        
        applicant2 = Applicant(
            applicant_id="A002",
            name="Jane Doe",
            financial_history=FinancialHistory(
                annual_income=45000,
                credit_score=680,
                rental_history=[],
                employment_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=3,
                age_distribution=[30, 32, 5],
                family_composition="family_with_children",
                household_income=45000
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant1)
        system.add_applicant(applicant2)
        
        # Mock statuses for testing
        system.applications["A001"]["status"] = "approved"
        system.applications["A002"]["status"] = "pending"
        
        report = system.generate_daily_report()
        
        assert "report_date" in report
        assert report["summary"]["total_applications"] == 2
        assert report["summary"]["approved"] == 1
        assert report["summary"]["pending"] == 1
        assert report["summary"]["denied"] == 0
        assert report["summary"]["waitlisted"] == 0

    def test_get_applicant(self):
        """Test retrieving applicant by ID"""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=50000,
                credit_score=720,
                rental_history=[],
                employment_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_distribution=[30, 35],
                family_composition="couple",
                household_income=50000
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        
        retrieved_applicant = system.get_applicant("A001")
        assert retrieved_applicant == applicant
        
        # Test non-existent applicant
        assert system.get_applicant("A002") is None

    def test_get_application_status(self):
        """Test getting application status"""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=50000,
                credit_score=720,
                rental_history=[],
                employment_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_distribution=[30, 35],
                family_composition="couple",
                household_income=50000
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        
        status = system.get_application_status("A001")
        assert status == "pending"
        
        # Test non-existent applicant
        assert system.get_application_status("A002") is None

    def test_boundary_conditions_income(self):
        """Test boundary conditions for income"""
        system = HousingAllocationSystem()
        
        # Test with minimum income
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=0,
                credit_score=720,
                rental_history=[],
                employment_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_distribution=[30, 35],
                family_composition="couple",
                household_income=0
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        
        # Should not crash
        assert True

    def test_boundary_conditions_credit_score(self):
        """Test boundary conditions for credit score"""
        system = HousingAllocationSystem()
        
        # Test with minimum credit score
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=50000,
                credit_score=300,
                rental_history=[],
                employment_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_distribution=[30, 35],
                family_composition="couple",
                household_income=50000
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        
        # Should not crash
        assert True

    def test_empty_rental_history(self):
        """Test with empty rental history"""
        system = HousingAllocationSystem()
        
        applicant = Applicant(
            applicant_id="A001",
            name="John Smith",
            financial_history=FinancialHistory(
                annual_income=50000,
                credit_score=720,
                rental_history=[],
                employment_history=[]
            ),
            household_structure=HouseholdStructure(
                household_size=2,
                age_distribution=[30, 35],
                family_composition="couple",
                household_income=50000
            ),
            application_date=datetime.datetime.now()
        )
        
        system.add_applicant(applicant)
        
        # Should not crash
        assert True

    def test_invalid_applicant_id(self):
        """Test with invalid applicant ID"""
        system = HousingAllocationSystem()
        
        # Test that non-existent applicant doesn't cause crash
        assert system.get_applicant("INVALID_ID") is None
        assert system.get_application_status("INVALID_ID") is None

    def test_calculate_viability_score(self):
        """Test viability score calculation logic"""
        system = HousingAllocationSystem()
        
        # Test with good scores
        income_score = 80  # 80% of max
        credit_score = 75  # 75% of max
        rental_score = 85  # 85% of max
        employment_score = 90  # 90% of max
        
        # This would be the actual calculation in the real system
        # For now, just ensure it doesn't crash
        assert True


if __name__ == "__main__":
    # Run the tests
    pytest.main([__file__, "-v"])