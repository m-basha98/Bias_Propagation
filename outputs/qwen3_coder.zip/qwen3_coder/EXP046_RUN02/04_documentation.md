# Technical Documentation for Housing Allocation System

## Overview
This document provides detailed technical documentation for the Housing Allocation System, a self-contained application that processes tenant applications, computes viability scores, and generates daily reports. The system operates without external dependencies and ensures deterministic, reproducible results.

## System Architecture

### Core Components
1. **Data Models**: `FinancialHistory`, `HouseholdStructure`, `Applicant`
2. **System Class**: `HousingAllocationSystem` - Main application logic
3. **Enums**: `ApplicationStatus` - Application lifecycle states

## Data Models

### `ApplicationStatus` (Enum)
**Description**: Enum representing the lifecycle states of an application
- `PENDING`: Application is under review
- `APPROVED`: Application has been approved
- `DENIED`: Application has been denied
- `WAITLISTED`: Application is on the waitlist

### `FinancialHistory` (Dataclass)
**Description**: Stores financial information for applicants

**Fields**:
- `annual_income` (float): Annual household income
- `credit_score` (int): Credit score (0-850 scale)
- `rental_history` (List[Dict[str, Any]]): List of rental records
- `employment_history` (List[Dict[str, Any]]): List of employment records

### `HouseholdStructure` (Dataclass)
**Description**: Stores household composition information

**Fields**:
- `household_size` (int): Number of people in household
- `age_distribution` (List[int]): List of ages in household
- `family_composition` (str): Type of family structure ("single", "couple", "family_with_children")
- `household_income` (float): Total household income

### `Applicant` (Dataclass)
**Description**: Complete applicant information including personal and financial details

**Fields**:
- `applicant_id` (str): Unique identifier for applicant
- `name` (str): Applicant's full name
- `financial_history` (FinancialHistory): Financial background data
- `household_structure` (HouseholdStructure): Household composition data
- `application_date` (datetime.datetime): Date when application was submitted

## Main System Class: `HousingAllocationSystem`

### Constructor (`__init__`)
**Description**: Initializes the housing allocation system with default configuration

**Configuration Parameters**:
- `historical_family_structures`: Reference data for family structures (default provided)
- `approval_threshold`: Minimum viability score for approval (70.0)
- `waitlist_threshold`: Minimum viability score for waitlist (50.0)

### Public Methods

#### `add_applicant(applicant: Applicant) -> None`
**Description**: Adds a new applicant to the system and initializes their application record

**Parameters**:
- `applicant` (Applicant): The applicant object to add

**Returns**: None

**Side Effects**: 
- Stores applicant data in internal dictionary
- Creates initial application record with PENDING status

#### `compute_viability_score(applicant: Applicant) -> float`
**Description**: Calculates the Tenant Viability score for an applicant based on financial factors

**Parameters**:
- `applicant` (Applicant): The applicant for whom to compute the score

**Returns**: 
- `float`: Viability score between 0-100

**Scoring Algorithm**:
- Income (40% weight): Scaled based on 30,000 income threshold
- Credit score (20% weight): Scaled based on 850 maximum
- Rental history (20% weight): Average rental score from history
- Employment history (20% weight): Average tenure scaled to 20 points

#### `generate_daily_report() -> Dict[str, Any]`
**Description**: Creates a comprehensive daily report of all applications

**Parameters**: None

**Returns**: 
- `Dict[str, Any]`: Complete report structure containing:
  - `report_date`: Date of report generation
  - `summary`: Count of applications by status
  - `applications`: Detailed list of all applications

#### `get_applicant(applicant_id: str) -> Optional[Applicant]`
**Description**: Retrieves an applicant by their unique identifier

**Parameters**:
- `applicant_id` (str): Unique applicant identifier

**Returns**: 
- `Optional[Applicant]`: Applicant object if found, None otherwise

#### `get_application_status(applicant_id: str) -> Optional[str]`
**Description**: Gets the current status of an application

**Parameters**:
- `applicant_id` (str): Unique applicant identifier

**Returns**: 
- `Optional[str]`: Application status string if found, None otherwise

### Private Methods (Internal Use Only)

#### `_calculate_age_distribution_similarity(applicant_ages: List[int], reference_ages: List[int]) -> float`
**Description**: Calculates similarity between age distributions using average age difference

**Parameters**:
- `applicant_ages` (List[int]): Ages from applicant's household
- `reference_ages` (List[int]): Ages from reference household

**Returns**: 
- `float`: Similarity score between 0-100

#### `_calculate_household_compatibility(applicant: Applicant) -> float`
**Description**: Calculates compatibility score based on household structure matching

**Parameters**:
- `applicant` (Applicant): The applicant to evaluate

**Returns**: 
- `float`: Compatibility score between 0-100

#### `process_application(applicant_id: str) -> str`
**Description**: Main application processing method that determines final status

**Parameters**:
- `applicant_id` (str): Unique applicant identifier

**Returns**: 
- `str`: Final application status (APPROVED, DENIED, or WAITLISTED)

**Processing Logic**:
1. Compute viability score
2. Compare against thresholds
3. Assign appropriate status
4. Update internal application record

## Configuration and Constants

### Default Thresholds
- **Approval Threshold**: 70.0 (Applications scoring above this are approved)
- **Waitlist Threshold**: 50.0 (Applications scoring between this and approval threshold are waitlisted)
- **Denial Threshold**: Below 50.0 (Applications scoring below this are denied)

### Reference Data
The system includes default reference data for family structures:
- Single person households
- Couple households
- Family with children households

## Example Usage

The `main()` function demonstrates complete usage including:
1. System initialization
2. Sample applicant creation
3. Application processing
4. Daily report generation

## System Requirements

### Dependencies
- Python 3.6+
- No external packages required (pure Python implementation)

### Data Requirements
- Applicant data must include all required fields in data models
- Financial data should be in valid formats (numeric values for income/credit scores)
- Household structure data should be properly formatted

## Performance Characteristics

### Time Complexity
- `add_applicant()`: O(1)
- `compute_viability_score()`: O(n) where n is the number of rental/employment records
- `generate_daily_report()`: O(m) where m is the number of applications
- `get_applicant()`: O(1)
- `get_application_status()`: O(1)

### Space Complexity
- O(n) where n is the number of applicants stored

## Error Handling

The system implements defensive programming practices:
- Input validation for required fields
- Graceful handling of missing data
- None returns for non-existent applicants
- Internal consistency checks

## Extensibility

### Customization Points
1. **Threshold Adjustment**: Modify approval/waitlist thresholds in constructor
2. **Reference Data**: Update `historical_family_structures` for different demographic considerations
3. **Scoring Algorithm**: Modify `compute_viability_score()` method for different weighting schemes
4. **Application Logic**: Override `process_application()` for custom business rules

### Future Enhancements
- Integration with external credit scoring services
- Advanced machine learning models for risk assessment
- Database persistence layer
- Web API interface
- Multi-language support
- Export functionality for various formats (CSV, JSON, PDF)