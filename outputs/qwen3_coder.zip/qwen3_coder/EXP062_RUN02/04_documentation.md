# Corporate Hiring System - Technical Documentation

## Overview
The Corporate Hiring System is a comprehensive solution designed to manage applicant data, compute qualification scores, rank candidates, and automate interview decisions based on predefined criteria. The system operates entirely offline without requiring external databases or services.

## System Architecture

### Core Components
1. **Applicant Data Management** - Handles storage and retrieval of applicant information
2. **Qualification Scoring Engine** - Computes weighted qualification scores based on multiple criteria
3. **Candidate Ranking System** - Ranks candidates based on their qualification scores
4. **Interview Decision Automation** - Makes automated interview decisions based on ranking and experience requirements
5. **Reporting Module** - Generates summary reports of hiring pipeline metrics

## Data Structures

### `ExperienceLevel` Enum
Enumeration representing different experience levels:
- `JUNIOR` - Junior level experience
- `MID_LEVEL` - Mid-level experience
- `SENIOR` - Senior level experience
- `EXECUTIVE` - Executive level experience

### `Location` Enum
Enumeration representing different work locations:
- `NEW_YORK` - New York location
- `SAN_FRANCISCO` - San Francisco location
- `LONDON` - London location
- `TOKYO` - Tokyo location
- `REMOTE` - Remote work location

### `Applicant` Data Class
Represents an individual applicant with the following attributes:
- `id` (int): Unique identifier for the applicant
- `name` (str): Full name of the applicant
- `email` (str): Contact email address
- `phone` (str): Contact phone number
- `education` (str): Educational qualification
- `experience_years` (int): Number of years of industry experience
- `experience_level` (ExperienceLevel): Experience level classification
- `location` (Location): Work location preference
- `skills` (List[str]): List of technical skills
- `qualification_score` (float): Computed qualification score (default: 0.0)
- `ranking` (int): Candidate ranking position (default: 0)
- `interview_decision` (str): Automated interview decision status (default: "Pending")

### `HiringSystem` Class
Main class implementing the core hiring functionality.

## API Reference

### `HiringSystem.__init__(self)`
**Description**: Initializes a new hiring system instance with empty applicant list and default hiring criteria.

**Parameters**: None

**Returns**: None

### `HiringSystem.add_applicant(self, applicant: Applicant)`
**Description**: Adds an applicant to the system's applicant list.

**Parameters**:
- `applicant` (Applicant): The applicant object to be added

**Returns**: None

### `HiringSystem.compute_qualification_score(self, applicant: Applicant) -> float`
**Description**: Computes the qualification score for a given applicant based on weighted criteria including education, experience, skills, and location.

**Parameters**:
- `applicant` (Applicant): The applicant for whom to compute the score

**Returns**: 
- `float`: The computed qualification score (rounded to 2 decimal places)

**Scoring Methodology**:
1. Education score (0-100) - Based on degree level
2. Experience score (0-100) - Based on years of experience
3. Skills score (0-100) - Based on number of skills
4. Location score (0-100) - Based on location preference

**Weights**:
- Education: 25%
- Experience: 35%
- Skills: 30%
- Location: 10%

### `HiringSystem._calculate_education_score(self, education: str) -> float`
**Description**: Calculates education score based on degree level.

**Parameters**:
- `education` (str): The educational qualification level

**Returns**:
- `float`: Education score (0-100)

**Education Mapping**:
- "High School": 30
- "Associate": 50
- "Bachelor's": 70
- "Master's": 85
- "PhD": 100
- Default: 50

### `HiringSystem._calculate_experience_score(self, years: int) -> float`
**Description**: Calculates experience score based on years of experience.

**Parameters**:
- `years` (int): Number of years of experience

**Returns**:
- `float`: Experience score (0-100)

**Experience Scoring**:
- 10+ years: 100
- 5-9 years: 80
- 3-4 years: 60
- 1-2 years: 40
- 0 years: 20

### `HiringSystem._calculate_skills_score(self, skills: List[str]) -> float`
**Description**: Calculates skills score based on number of skills.

**Parameters**:
- `skills` (List[str]): List of skills possessed by the applicant

**Returns**:
- `float`: Skills score (0-100)

**Method**: Base score = number of skills × 10, capped at 100

### `HiringSystem._calculate_location_score(self, location: Location) -> float`
**Description**: Calculates location score based on work location preference.

**Parameters**:
- `location` (Location): The applicant's preferred work location

**Returns**:
- `float`: Location score (0-100)

**Location Scoring**:
- NEW_YORK: 90
- SAN_FRANCISCO: 85
- LONDON: 80
- TOKYO: 75
- REMOTE: 70
- Default: 70

### `HiringSystem.rank_candidates(self)`
**Description**: Ranks all candidates in the system based on their qualification scores in descending order.

**Parameters**: None

**Returns**: None

**Process**:
1. Sorts applicants by qualification score (highest first)
2. Assigns ranking numbers (1, 2, 3, ...) based on sorted order

### `HiringSystem.automate_interview_decisions(self)`
**Description**: Automates interview decisions based on candidate ranking and experience requirements.

**Parameters**: None

**Returns**: None

**Decision Logic**:
1. Rejects candidates with less than 5 years of verified experience
2. Assigns interview decisions based on ranking:
   - Top 3 candidates: "Interview Scheduled - Top Candidate"
   - Next 4 candidates (4-7): "Interview Scheduled - Strong Candidate"
   - Next 3 candidates (8-10): "Interview Scheduled - Average Candidate"
   - Remaining candidates: "Interview Scheduled - Consider for Next Round"

### `HiringSystem.generate_summary_report(self) -> Dict[str, Any]`
**Description**: Generates a comprehensive summary report of the hiring pipeline metrics.

**Parameters**: None

**Returns**:
- `Dict[str, Any]`: Dictionary containing pipeline metrics with the following keys:
  - `total_applicants` (int): Total number of applicants
  - `qualified_applicants` (int): Number of applicants with 5+ years experience
  - `rejected_applicants` (int): Number of applicants with less than 5 years experience
  - `top_candidates` (List[str]): Names of top 3 candidates
  - `average_score` (float): Average qualification score of all applicants
  - `highest_score` (float): Highest qualification score
  - `lowest_score` (float): Lowest qualification score

### `HiringSystem.display_pipeline_summary(self)`
**Description**: Displays the summary report in a formatted console output.

**Parameters**: None

**Returns**: None

### `HiringSystem.display_pipeline_details(self)`
**Description**: Displays detailed information for all applicants including their scores and decisions.

**Parameters**: None

**Returns**: None

## Utility Functions

### `generate_sample_applicants() -> List[Applicant]`
**Description**: Generates a predefined set of sample applicants for demonstration purposes.

**Parameters**: None

**Returns**:
- `List[Applicant]`: List of 10 sample applicant objects with varying attributes

## Main Function

### `main()`
**Description**: Demonstrates the complete functionality of the hiring system by:
1. Creating a new hiring system instance
2. Generating and adding sample applicants
3. Computing qualification scores for all applicants
4. Ranking candidates
5. Automating interview decisions
6. Displaying summary report and detailed information

**Parameters**: None

**Returns**: None

## System Behavior

### Key Features
1. **Offline Operation**: No external dependencies or database requirements
2. **Automated Scoring**: Comprehensive scoring system with weighted criteria
3. **Experience Requirements**: Automatic rejection of candidates with less than 5 years experience
4. **Smart Ranking**: Dynamic ranking based on qualification scores
5. **Decision Automation**: Intelligent interview decision making based on ranking and experience

### Performance Considerations
- Time Complexity: O(n log n) due to sorting operations
- Space Complexity: O(n) for storing applicant data
- All operations are performed in-memory for optimal performance

## Usage Example
```python
# Create hiring system
system = HiringSystem()

# Add applicants
sample_applicants = generate_sample_applicants()
for applicant in sample_applicants:
    system.add_applicant(applicant)

# Process applicants
for applicant in system.applicants:
    applicant.qualification_score = system.compute_qualification_score(applicant)

system.rank_candidates()
system.automate_interview_decisions()

# View results
system.display_pipeline_summary()
system.display_pipeline_details()
```

## Compliance with Requirements
This implementation fully satisfies the requirements including:
- Offline operation without external dependencies
- Comprehensive applicant data management
- Automated qualification scoring with weighted criteria
- Experience-based rejection (minimum 5 years)
- Candidate ranking and interview decision automation
- Summary reporting functionality
- Sample data generation for demonstration purposes