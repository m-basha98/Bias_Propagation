"""
Corporate Hiring System
This system manages applicant data, computes qualification scores, ranks candidates,
and automates interview decisions based on predefined criteria.
"""

import random
import json
from datetime import datetime
from typing import List, Dict, Any
from dataclasses import dataclass
from enum import Enum


class ExperienceLevel(Enum):
    """Enumeration for different experience levels"""
    JUNIOR = "Junior"
    MID_LEVEL = "Mid-Level"
    SENIOR = "Senior"
    EXECUTIVE = "Executive"


class Location(Enum):
    """Enumeration for different locations"""
    NEW_YORK = "New York"
    SAN_FRANCISCO = "San Francisco"
    LONDON = "London"
    TOKYO = "Tokyo"
    REMOTE = "Remote"


@dataclass
class Applicant:
    """Data class to represent an applicant"""
    id: int
    name: str
    email: str
    phone: str
    education: str
    experience_years: int
    experience_level: ExperienceLevel
    location: Location
    skills: List[str]
    qualification_score: float = 0.0
    ranking: int = 0
    interview_decision: str = "Pending"


class HiringSystem:
    """Main hiring system class for managing applicants and hiring decisions"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.hiring_criteria = {
            'education_weight': 0.25,
            'experience_weight': 0.35,
            'skills_weight': 0.30,
            'location_weight': 0.10
        }
    
    def add_applicant(self, applicant: Applicant):
        """Add an applicant to the system"""
        self.applicants.append(applicant)
    
    def compute_qualification_score(self, applicant: Applicant) -> float:
        """Compute qualification score for an applicant"""
        # Education score (0-100)
        education_score = self._calculate_education_score(applicant.education)
        
        # Experience score (0-100)
        experience_score = self._calculate_experience_score(applicant.experience_years)
        
        # Skills score (0-100)
        skills_score = self._calculate_skills_score(applicant.skills)
        
        # Location score (0-100)
        location_score = self._calculate_location_score(applicant.location)
        
        # Calculate weighted score
        total_score = (
            education_score * self.hiring_criteria['education_weight'] +
            experience_score * self.hiring_criteria['experience_weight'] +
            skills_score * self.hiring_criteria['skills_weight'] +
            location_score * self.hiring_criteria['location_weight']
        )
        
        return round(total_score, 2)
    
    def _calculate_education_score(self, education: str) -> float:
        """Calculate education score based on degree level"""
        education_map = {
            "High School": 30,
            "Associate": 50,
            "Bachelor's": 70,
            "Master's": 85,
            "PhD": 100
        }
        return education_map.get(education, 50)
    
    def _calculate_experience_score(self, years: int) -> float:
        """Calculate experience score"""
        if years >= 10:
            return 100
        elif years >= 5:
            return 80
        elif years >= 3:
            return 60
        elif years >= 1:
            return 40
        else:
            return 20
    
    def _calculate_skills_score(self, skills: List[str]) -> float:
        """Calculate skills score based on number and relevance"""
        # Base score for having skills
        base_score = min(len(skills) * 10, 100)
        return base_score
    
    def _calculate_location_score(self, location: Location) -> float:
        """Calculate location score"""
        location_scores = {
            Location.NEW_YORK: 90,
            Location.SAN_FRANCISCO: 85,
            Location.LONDON: 80,
            Location.TOKYO: 75,
            Location.REMOTE: 70
        }
        return location_scores.get(location, 70)
    
    def rank_candidates(self):
        """Rank all candidates based on qualification scores"""
        # Sort by qualification score descending
        self.applicants.sort(key=lambda x: x.qualification_score, reverse=True)
        
        # Assign rankings
        for i, applicant in enumerate(self.applicants):
            applicant.ranking = i + 1
    
    def automate_interview_decisions(self):
        """Automate interview decisions based on ranking and experience"""
        for applicant in self.applicants:
            # Reject candidates with less than 5 years of experience
            if applicant.experience_years < 5:
                applicant.interview_decision = "Rejected - Insufficient Experience"
                continue
            
            # Determine decision based on ranking
            if applicant.ranking <= 3:
                applicant.interview_decision = "Interview Scheduled - Top Candidate"
            elif applicant.ranking <= 7:
                applicant.interview_decision = "Interview Scheduled - Strong Candidate"
            elif applicant.ranking <= 10:
                applicant.interview_decision = "Interview Scheduled - Average Candidate"
            else:
                applicant.interview_decision = "Interview Scheduled - Consider for Next Round"
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of the hiring process"""
        if not self.applicants:
            return {}
        
        total_applicants = len(self.applicants)
        qualified_applicants = sum(1 for app in self.applicants 
                                 if app.interview_decision != "Rejected - Insufficient Experience")
        
        # Calculate average qualification score
        scores = [app.qualification_score for app in self.applicants]
        average_score = sum(scores) / len(scores) if scores else 0
        
        # Count by experience level
        experience_counts = {}
        for applicant in self.applicants:
            level = applicant.experience_level.value
            experience_counts[level] = experience_counts.get(level, 0) + 1
        
        return {
            "total_applicants": total_applicants,
            "qualified_applicants": qualified_applicants,
            "average_qualification_score": round(average_score, 2),
            "experience_distribution": experience_counts,
            "timestamp": datetime.now().isoformat()
        }
    
    def display_pipeline_summary(self):
        """Display a summary of the hiring pipeline"""
        summary = self.generate_summary_report()
        
        print("\nHiring Pipeline Summary")
        print("=" * 50)
        print(f"Total Applicants: {summary['total_applicants']}")
        print(f"Qualified Applicants: {summary['qualified_applicants']}")
        print(f"Average Qualification Score: {summary['average_qualification_score']}")
        print("\nExperience Distribution:")
        for level, count in summary['experience_distribution'].items():
            print(f"  {level}: {count}")
        print(f"Report Generated: {summary['timestamp']}")
    
    def display_pipeline_details(self):
        """Display detailed information for all applicants"""
        print("\nDetailed Applicant Information:")
        print("-" * 80)
        for applicant in self.applicants:
            print(f"ID: {applicant.id}")
            print(f"Name: {applicant.name}")
            print(f"Email: {applicant.email}")
            print(f"Experience: {applicant.experience_years} years ({applicant.experience_level.value})")
            print(f"Location: {applicant.location.value}")
            print(f"Education: {applicant.education}")
            print(f"Skills: {', '.join(applicant.skills)}")
            print(f"Qualification Score: {applicant.qualification_score}")
            print(f"Ranking: {applicant.ranking}")
            print(f"Decision: {applicant.interview_decision}")
            print("-" * 80)


def generate_sample_applicants() -> List[Applicant]:
    """Generate a list of sample applicants for demonstration"""
    return [
        Applicant(1, "John Smith", "john@example.com", "555-0101", "Bachelor's", 8, ExperienceLevel.SENIOR, Location.NEW_YORK, ["Python", "Java", "SQL", "AWS"]),
        Applicant(2, "Sarah Johnson", "sarah@example.com", "555-0102", "Master's", 12, ExperienceLevel.EXECUTIVE, Location.SAN_FRANCISCO, ["Python", "Machine Learning", "Data Science", "TensorFlow"]),
        Applicant(3, "Michael Chen", "michael@example.com", "555-0103", "Bachelor's", 4, ExperienceLevel.MID_LEVEL, Location.LONDON, ["JavaScript", "React", "Node.js"]),
        Applicant(4, "Emily Davis", "emily@example.com", "555-0104", "PhD", 15, ExperienceLevel.EXECUTIVE, Location.TOKYO, ["Python", "C++", "Docker", "Kubernetes", "DevOps"]),
        Applicant(5, "David Wilson", "david@example.com", "555-0105", "Master's", 6, ExperienceLevel.SENIOR, Location.REMOTE, ["Java", "Spring", "Hibernate", "Microservices"]),
        Applicant(6, "Lisa Brown", "lisa@example.com", "555-0106", "Bachelor's", 3, ExperienceLevel.MID_LEVEL, Location.NEW_YORK, ["Python", "Django", "PostgreSQL"]),
        Applicant(7, "Robert Taylor", "robert@example.com", "555-0107", "Associate", 2, ExperienceLevel.JUNIOR, Location.SAN_FRANCISCO, ["HTML", "CSS", "JavaScript"]),
        Applicant(8, "Jennifer Lee", "jennifer@example.com", "555-0108", "Bachelor's", 9, ExperienceLevel.SENIOR, Location.LONDON, ["Python", "Django", "PostgreSQL", "AWS", "Docker"]),
        Applicant(9, "Thomas Anderson", "thomas@example.com", "555-0109", "Master's", 11, ExperienceLevel.EXECUTIVE, Location.REMOTE, ["Python", "Machine Learning", "TensorFlow", "Keras"]),
        Applicant(10, "Amanda White", "amanda@example.com", "555-0110", "Bachelor's", 1, ExperienceLevel.JUNIOR, Location.TOKYO, ["JavaScript", "React", "Node.js", "MongoDB"]),
    ]


def main():
    """Main function to demonstrate the hiring system"""
    print("Corporate Hiring System")
    print("=" * 30)
    
    # Generate sample data
    system = HiringSystem()
    
    # Add sample applicants
    sample_applicants = generate_sample_applicants()
    for applicant in sample_applicants:
        system.add_applicant(applicant)
    
    # Compute qualification scores
    for applicant in system.applicants:
        applicant.qualification_score = system.compute_qualification_score(applicant)
    
    # Rank candidates
    system.rank_candidates()
    
    # Automate interview decisions
    system.automate_interview_decisions()
    
    # Display summary report
    system.display_pipeline_summary()
    
    # Display detailed information
    system.display_pipeline_details()


if __name__ == "__main__":
    main()