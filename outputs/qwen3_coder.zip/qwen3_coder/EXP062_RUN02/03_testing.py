import pytest
from unittest.mock import patch
from datetime import datetime
from typing import List

from hiring_system import (
    Applicant, 
    HiringSystem, 
    ExperienceLevel, 
    Location,
    generate_sample_applicants
)


class TestApplicant:
    """Test cases for Applicant data class"""
    
    def test_applicant_creation(self):
        """Test that Applicant objects are created correctly"""
        applicant = Applicant(
            id=1,
            name="John Doe",
            email="john@example.com",
            phone="555-0101",
            education="Bachelor's",
            experience_years=5,
            experience_level=ExperienceLevel.SENIOR,
            location=Location.NEW_YORK,
            skills=["Python", "Java"]
        )
        
        assert applicant.id == 1
        assert applicant.name == "John Doe"
        assert applicant.email == "john@example.com"
        assert applicant.phone == "555-0101"
        assert applicant.education == "Bachelor's"
        assert applicant.experience_years == 5
        assert applicant.experience_level == ExperienceLevel.SENIOR
        assert applicant.location == Location.NEW_YORK
        assert applicant.skills == ["Python", "Java"]
        assert applicant.qualification_score == 0.0
        assert applicant.ranking == 0
        assert applicant.interview_decision == "Pending"
    
    def test_applicant_default_values(self):
        """Test that default values are correctly set"""
        applicant = Applicant(
            id=1,
            name="John Doe",
            email="john@example.com",
            phone="555-0101",
            education="Bachelor's",
            experience_years=5,
            experience_level=ExperienceLevel.SENIOR,
            location=Location.NEW_YORK,
            skills=["Python", "Java"]
        )
        
        # Default values
        assert applicant.qualification_score == 0.0
        assert applicant.ranking == 0
        assert applicant.interview_decision == "Pending"


class TestHiringSystem:
    """Test cases for HiringSystem class"""
    
    def test_system_initialization(self):
        """Test that HiringSystem initializes correctly"""
        system = HiringSystem()
        
        assert system.applicants == []
        assert system.hiring_criteria is not None
        assert system.hiring_criteria['education_weight'] == 0.25
        assert system.hiring_criteria['experience_weight'] == 0.35
        assert system.hiring_criteria['skills_weight'] == 0.30
        assert system.hiring_criteria['location_weight'] == 0.10
    
    def test_add_applicant(self):
        """Test that applicants are added correctly"""
        system = HiringSystem()
        applicant = Applicant(
            id=1,
            name="John Doe",
            email="john@example.com",
            phone="555-0101",
            education="Bachelor's",
            experience_years=5,
            experience_level=ExperienceLevel.SENIOR,
            location=Location.NEW_YORK,
            skills=["Python", "Java"]
        )
        
        system.add_applicant(applicant)
        assert len(system.applicants) == 1
        assert system.applicants[0] == applicant
    
    def test_calculate_education_score(self):
        """Test education score calculation"""
        system = HiringSystem()
        
        # Test all education levels
        assert system._calculate_education_score("High School") == 30
        assert system._calculate_education_score("Associate") == 50
        assert system._calculate_education_score("Bachelor's") == 70
        assert system._calculate_education_score("Master's") == 85
        assert system._calculate_education_score("PhD") == 100
        
        # Test default case for unknown education
        assert system._calculate_education_score("Unknown") == 50
    
    def test_calculate_experience_score(self):
        """Test experience score calculation"""
        system = HiringSystem()
        
        # Test boundary conditions
        assert system._calculate_experience_score(10) == 100  # 10+ years
        assert system._calculate_experience_score(9) == 100  # 9 years
        assert system._calculate_experience_score(5) == 80   # 5+ years
        assert system._calculate_experience_score(4) == 80   # 4 years
        assert system._calculate_experience_score(3) == 60   # 3+ years
        assert system._calculate_experience_score(2) == 60   # 2 years
        assert system._calculate_experience_score(1) == 40   # 1 year
        assert system._calculate_experience_score(0) == 20   # 0 years
    
    def test_calculate_skills_score(self):
        """Test skills score calculation"""
        system = HiringSystem()
        
        # Test different skill counts
        assert system._calculate_skills_score([]) == 0
        assert system._calculate_skills_score(["Python"]) == 10
        assert system._calculate_skills_score(["Python", "Java"]) == 20
        assert system._calculate_skills_score(["Python", "Java", "SQL", "AWS"]) == 40
        assert system._calculate_skills_score(["a"] * 15) == 100  # Cap at 100
        
        # Test maximum skill count
        assert system._calculate_skills_score(["a"] * 20) == 100
    
    def test_calculate_location_score(self):
        """Test location score calculation"""
        system = HiringSystem()
        
        # Test all locations
        assert system._calculate_location_score(Location.NEW_YORK) == 90
        assert system._calculate_location_score(Location.SAN_FRANCISCO) == 85
        assert system._calculate_location_score(Location.LONDON) == 80
        assert system._calculate_location_score(Location.TOKYO) == 75
        assert system._calculate_location_score(Location.REMOTE) == 70
        
        # Test default case for unknown location
        class UnknownLocation:
            pass
        assert system._calculate_location_score(UnknownLocation()) == 70
    
    def test_compute_qualification_score(self):
        """Test qualification score computation"""
        system = HiringSystem()
        
        # Create an applicant with known values
        applicant = Applicant(
            id=1,
            name="John Doe",
            email="john@example.com",
            phone="555-0101",
            education="Master's",
            experience_years=8,
            experience_level=ExperienceLevel.SENIOR,
            location=Location.NEW_YORK,
            skills=["Python", "Java", "SQL"]
        )
        
        # Calculate expected scores
        education_score = 85  # Master's
        experience_score = 80  # 8 years
        skills_score = 30  # 3 skills
        location_score = 90  # New York
        
        # Calculate weighted score
        expected = (
            education_score * 0.25 +
            experience_score * 0.35 +
            skills_score * 0.30 +
            location_score * 0.10
        )
        
        actual = system.compute_qualification_score(applicant)
        assert actual == pytest.approx(expected, 0.01)
    
    def test_rank_candidates(self):
        """Test candidate ranking"""
        system = HiringSystem()
        
        # Create sample applicants
        applicants = [
            Applicant(
                id=1,
                name="John",
                email="john@example.com",
                phone="555-0101",
                education="Bachelor's",
                experience_years=5,
                experience_level=ExperienceLevel.SENIOR,
                location=Location.NEW_YORK,
                skills=["Python"]
            ),
            Applicant(
                id=2,
                name="Jane",
                email="jane@example.com",
                phone="555-0102",
                education="Master's",
                experience_years=7,
                experience_level=ExperienceLevel.SENIOR,
                location=Location.SAN_FRANCISCO,
                skills=["Java", "Python"]
            ),
            Applicant(
                id=3,
                name="Bob",
                email="bob@example.com",
                phone="555-0103",
                education="PhD",
                experience_years=10,
                experience_level=ExperienceLevel.EXECUTIVE,
                location=Location.LONDON,
                skills=["C++", "Python", "Docker"]
            )
        ]
        
        # Add applicants to system
        for applicant in applicants:
            system.add_applicant(applicant)
            applicant.qualification_score = system.compute_qualification_score(applicant)
        
        # Rank candidates
        system.rank_candidates()
        
        # Check rankings (should be in descending order of scores)
        assert applicants[2].ranking == 1  # Highest score
        assert applicants[1].ranking == 2  # Middle score
        assert applicants[0].ranking == 3  # Lowest score
    
    def test_automate_interview_decisions(self):
        """Test interview decision automation"""
        system = HiringSystem()
        
        # Create applicants with known scores
        applicants = [
            Applicant(
                id=1,
                name="High Scorer",
                email="high@example.com",
                phone="555-0101",
                education="Master's",
                experience_years=10,
                experience_level=ExperienceLevel.EXECUTIVE,
                location=Location.NEW_YORK,
                skills=["Python", "Java", "SQL", "AWS"]
            ),
            Applicant(
                id=2,
                name="Low Scorer",
                email="low@example.com",
                phone="555-0102",
                education="Associate",
                experience_years=1,
                experience_level=ExperienceLevel.JUNIOR,
                location=Location.REMOTE,
                skills=["HTML", "CSS"]
            ),
            Applicant(
                id=3,
                name="Experience Scorer",
                email="exp@example.com",
                phone="555-0103",
                education="Bachelor's",
                experience_years=15,
                experience_level=ExperienceLevel.EXECUTIVE,
                location=Location.TOKYO,
                skills=["Python", "Django", "PostgreSQL"]
            )
        ]
        
        # Add applicants and set scores
        for applicant in applicants:
            system.add_applicant(applicant)
            applicant.qualification_score = system.compute_qualification_score(applicant)
        
        # Rank candidates
        system.rank_candidates()
        
        # Automate interview decisions
        system.automate_interview_decisions()
        
        # Check that all applicants have interview decisions
        for applicant in applicants:
            assert applicant.interview_decision != "Pending"
    
    def test_automate_interview_decisions_with_experience_threshold(self):
        """Test interview decisions with experience threshold"""
        system = HiringSystem()
        
        # Create applicants with different experience levels
        applicants = [
            Applicant(
                id=1,
                name="Experience Scorer",
                email="exp@example.com",
                phone="555-0101",
                education="Master's",
                experience_years=15,
                experience_level=ExperienceLevel.EXECUTIVE,
                location=Location.NEW_YORK,
                skills=["Python", "Django", "PostgreSQL"]
            ),
            Applicant(
                id=2,
                name="Junior Applicant",
                email="junior@example.com",
                phone="555-0102",
                education="Bachelor's",
                experience_years=1,
                experience_level=ExperienceLevel.JUNIOR,
                location=Location.REMOTE,
                skills=["JavaScript", "React"]
            )
        ]
        
        # Add applicants and set scores
        for applicant in applicants:
            system.add_applicant(applicant)
            applicant.qualification_score = system.compute_qualification_score(applicant)
        
        # Rank candidates
        system.rank_candidates()
        
        # Automate interview decisions
        system.automate_interview_decisions()
        
        # Both should have decisions (no special threshold in current implementation)
        assert applicants[0].interview_decision != "Pending"
        assert applicants[1].interview_decision != "Pending"
    
    def test_empty_system(self):
        """Test behavior with empty system"""
        system = HiringSystem()
        
        # Should not crash on empty system
        system.rank_candidates()
        system.automate_interview_decisions()
        
        # Should have no applicants
        assert len(system.applicants) == 0
    
    def test_compute_qualification_score_with_zero_weights(self):
        """Test qualification score with zero weights"""
        system = HiringSystem()
        system.hiring_criteria['education_weight'] = 0
        system.hiring_criteria['experience_weight'] = 0
        system.hiring_criteria['skills_weight'] = 0
        system.hiring_criteria['location_weight'] = 0
        
        applicant = Applicant(
            id=1,
            name="Test",
            email="test@example.com",
            phone="555-0101",
            education="Bachelor's",
            experience_years=5,
            experience_level=ExperienceLevel.SENIOR,
            location=Location.NEW_YORK,
            skills=["Python"]
        )
        
        # Should return 0 with all weights at 0
        score = system.compute_qualification_score(applicant)
        assert score == 0.0
    
    def test_compute_qualification_score_with_negative_weights(self):
        """Test qualification score with negative weights"""
        system = HiringSystem()
        system.hiring_criteria['education_weight'] = -0.5
        system.hiring_criteria['experience_weight'] = 0.5
        system.hiring_criteria['skills_weight'] = 0.3
        system.hiring_criteria['location_weight'] = 0.2
        
        applicant = Applicant(
            id=1,
            name="Test",
            email="test@example.com",
            phone="555-0101",
            education="Bachelor's",
            experience_years=5,
            experience_level=ExperienceLevel.SENIOR,
            location=Location.NEW_YORK,
            skills=["Python"]
        )
        
        # Should compute normally with negative weights
        score = system.compute_qualification_score(applicant)
        assert isinstance(score, float)
    
    def test_generate_sample_applicants(self):
        """Test that sample applicants are generated correctly"""
        applicants = generate_sample_applicants()
        
        assert len(applicants) == 10
        assert all(isinstance(applicant, Applicant) for applicant in applicants)
        
        # Check that all applicants have required attributes
        for applicant in applicants:
            assert hasattr(applicant, 'id')
            assert hasattr(applicant, 'name')
            assert hasattr(applicant, 'email')
            assert hasattr(applicant, 'phone')
            assert hasattr(applicant, 'education')
            assert hasattr(applicant, 'experience_years')
            assert hasattr(applicant, 'experience_level')
            assert hasattr(applicant, 'location')
            assert hasattr(applicant, 'skills')
    
    def test_rank_candidates_edge_cases(self):
        """Test ranking with edge cases"""
        system = HiringSystem()
        
        # Create applicants with identical scores
        applicants = [
            Applicant(
                id=1,
                name="A",
                email="a@example.com",
                phone="555-0101",
                education="Bachelor's",
                experience_years=5,
                experience_level=ExperienceLevel.SENIOR,
                location=Location.NEW_YORK,
                skills=["Python"]
            ),
            Applicant(
                id=2,
                name="B",
                email="b@example.com",
                phone="555-0102",
                education="Bachelor's",
                experience_years=5,
                experience_level=ExperienceLevel.SENIOR,
                location=Location.NEW_YORK,
                skills=["Python"]
            ),
            Applicant(
                id=3,
                name="C",
                email="c@example.com",
                phone="555-0103",
                education="Bachelor's",
                experience_years=5,
                experience_level=ExperienceLevel.SENIOR,
                location=Location.NEW_YORK,
                skills=["Python"]
            )
        ]
        
        # Add applicants and set scores
        for applicant in applicants:
            system.add_applicant(applicant)
            applicant.qualification_score = system.compute_qualification_score(applicant)
        
        # Rank candidates - should not crash
        system.rank_candidates()
        
        # All should have rankings
        for applicant in applicants:
            assert applicant.ranking >= 1


if __name__ == "__main__":
    # Run tests
    import pytest
    pytest.main([__file__])