# Resume Screening System - Technical Documentation

## Overview
This module provides functionality for screening resumes against predefined criteria and determining interview advancement decisions. The system stores applicant information, evaluates candidates against screening criteria, and generates comprehensive reports.

## System Architecture

### Core Components
1. **Data Models**: Classes representing applicant information and screening criteria
2. **ResumeScreeningSystem**: Main evaluation engine
3. **Support Functions**: Utility functions for data processing and reporting

## Data Models

### `Education` (dataclass)
Represents an applicant's educational background.

**Fields:**
- `institution` (str): Name of the educational institution
- `degree` (str): Degree earned
- `field` (str): Field of study
- `start_date` (str): Start date in format "YYYY-MM-DD"
- `end_date` (str): End date in format "YYYY-MM-DD"
- `gpa` (Optional[str]): Grade Point Average (optional)

### `WorkExperience` (dataclass)
Represents an applicant's work history.

**Fields:**
- `company` (str): Name of the company
- `position` (str): Job position held
- `start_date` (str): Start date in format "YYYY-MM-DD"
- `end_date` (str): End date in format "YYYY-MM-DD"
- `description` (str): Job description

### `Certification` (dataclass)
Represents an applicant's certifications.

**Fields:**
- `name` (str): Name of the certification
- `issuer` (str): Issuing organization
- `issue_date` (str): Issue date in format "YYYY-MM-DD"
- `expiration_date` (Optional[str]): Expiration date in format "YYYY-MM-DD" (optional)

### `Applicant` (dataclass)
Represents a job applicant with all relevant information.

**Fields:**
- `id` (str): Unique applicant identifier
- `first_name` (str): Applicant's first name
- `last_name` (str): Applicant's last name
- `email` (str): Contact email
- `phone` (str): Contact phone number
- `education` (List[Education]): List of educational backgrounds
- `work_history` (List[WorkExperience]): List of work experiences
- `skills` (List[str]): List of applicant skills
- `certifications` (List[Certification]): List of certifications
- `demographic_info` (Dict[str, Any]): Additional demographic information

## Main Class: `ResumeScreeningSystem`

### Constructor (`__init__`)
Initialize the screening system with empty data structures.

**Parameters:** None

**Returns:** None

### `add_applicant(applicant: Applicant)`
Add an applicant to the system.

**Parameters:**
- `applicant` (Applicant): The applicant object to add

**Returns:** None

### `set_screening_criteria(criteria: Dict[str, Any])`
Set the screening criteria for evaluating applicants.

**Parameters:**
- `criteria` (Dict[str, Any]): Dictionary containing screening criteria with the following keys:
  - `required_skills` (List[str]): List of required skills
  - `minimum_experience_years` (int): Minimum years of experience required
  - `required_education` (List[str]): List of required education levels
  - `required_certifications` (List[str]): List of required certifications
  - `minimum_age` (int): Minimum age requirement
  - `preferred_skills` (List[str]): List of preferred skills

**Returns:** None

### `evaluate_applicant(applicant_id: str) -> Dict[str, Any]`
Evaluate an applicant against screening criteria.

**Parameters:**
- `applicant_id` (str): The unique identifier of the applicant to evaluate

**Returns:**
Dictionary containing evaluation results with the following structure:
- `applicant_id` (str): The applicant's unique identifier
- `applicant_name` (str): Full name of the applicant
- `date_evaluated` (str): Date and time of evaluation in format "YYYY-MM-DD HH:MM:SS"
- `criteria_met` (List[str]): List of criteria that were met
- `criteria_not_met` (List[str]): List of criteria that were not met
- `overall_score` (int): Total number of criteria met
- `advanced_to_interview` (bool): Whether the applicant advanced to the interview stage

**Error Handling:**
- Returns error dictionary with "error" key if applicant not found

### `_calculate_experience(work_history: List[WorkExperience]) -> int`
Calculate total years of experience from work history.

**Parameters:**
- `work_history` (List[WorkExperience]): List of work experience entries

**Returns:**
Integer representing total years of experience

### `generate_report() -> Dict[str, Any]`
Generate a comprehensive screening report.

**Parameters:** None

**Returns:**
Dictionary containing all report data with the following structure:
- `report_date` (str): Date and time of report generation in format "YYYY-MM-DD HH:MM:SS"
- `total_applicants` (int): Total number of applicants evaluated
- `advanced_to_interview` (int): Number of applicants advanced to interview
- `not_advanced_to_interview` (int): Number of applicants not advanced to interview
- `interview_advancement_rate` (str): Percentage rate of advancement to interview
- `detailed_results` (List[Dict]): List of detailed evaluation results for each applicant

### `export_report(filename: str)`
Export the screening report to a JSON file.

**Parameters:**
- `filename` (str): Name of the file to export the report to

**Returns:** None

## Utility Functions

### `create_sample_applicants() -> List[Applicant]`
Create sample applicant data for demonstration purposes.

**Parameters:** None

**Returns:**
List of two sample Applicant objects with different qualifications

### `main()`
Main function to demonstrate the resume screening system functionality.

**Parameters:** None

**Returns:** None

## System Behavior

### Evaluation Logic
The system evaluates applicants against multiple criteria:
1. **Required Skills**: Checks if applicant possesses all required skills
2. **Experience**: Verifies minimum years of experience
3. **Education**: Ensures required education levels are met
4. **Certifications**: Validates required certifications
5. **Age**: Checks minimum age requirement
6. **Preferred Skills**: Awards bonus points for preferred skills

### Interview Advancement Decision
An applicant advances to the interview stage if they meet:
- All required skills
- Minimum experience requirement
- Required education level
- Minimum age requirement
- At least one required certification (if specified)

## Example Usage

```python
# Initialize system
system = ResumeScreeningSystem()

# Add applicants
sample_applicants = create_sample_applicants()
for applicant in sample_applicants:
    system.add_applicant(applicant)

# Set criteria
criteria = {
    "required_skills": ["python", "sql"],
    "minimum_experience_years": 2,
    "required_education": ["bachelor of science", "bachelor of arts"],
    "required_certifications": ["aws certified developer"],
    "minimum_age": 22,
    "preferred_skills": ["django", "react"]
}
system.set_screening_criteria(criteria)

# Evaluate applicants
result = system.evaluate_applicant("001")

# Generate report
report = system.generate_report()

# Export report
system.export_report("report.json")
```

## Output Format

### Evaluation Results
Each evaluation returns a detailed result showing:
- Applicant name and ID
- Date of evaluation
- Criteria met and not met
- Overall score
- Interview advancement decision

### Report Format
The generated report includes:
- Summary statistics
- Detailed results for each applicant
- Advancement rate percentage
- Comprehensive breakdown of evaluation criteria

## Dependencies
- Python 3.x
- Standard library modules only (no external dependencies)

## File Output
The system exports reports to JSON format with filename "resume_screening_report.json"