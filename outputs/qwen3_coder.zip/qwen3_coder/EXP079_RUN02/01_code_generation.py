import json
import re
from datetime import datetime
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
from collections import defaultdict

@dataclass
class Education:
    institution: str
    degree: str
    field: str
    start_date: str
    end_date: str
    gpa: Optional[str] = None

@dataclass
class WorkExperience:
    company: str
    position: str
    start_date: str
    end_date: str
    description: str

@dataclass
class Certification:
    name: str
    issuer: str
    issue_date: str
    expiration_date: Optional[str] = None

@dataclass
class Applicant:
    id: str
    first_name: str
    last_name: str
    email: str
    phone: str
    education: List[Education]
    work_history: List[WorkExperience]
    skills: List[str]
    certifications: List[Certification]
    demographic_info: Dict[str, Any]

class ResumeScreeningSystem:
    def __init__(self):
        self.applicants: Dict[str, Applicant] = {}
        self.screening_criteria = {
            "required_skills": [],
            "minimum_experience_years": 0,
            "required_education": [],
            "required_certifications": [],
            "minimum_age": 0,
            "preferred_skills": []
        }
        self.screening_results = []

    def add_applicant(self, applicant: Applicant):
        """Add an applicant to the system"""
        self.applicants[applicant.id] = applicant

    def set_screening_criteria(self, criteria: Dict[str, Any]):
        """Set the screening criteria"""
        self.screening_criteria.update(criteria)

    def evaluate_applicant(self, applicant_id: str) -> Dict[str, Any]:
        """Evaluate an applicant against screening criteria"""
        applicant = self.applicants.get(applicant_id)
        if not applicant:
            return {"error": f"Applicant with ID {applicant_id} not found"}
        
        evaluation = {
            "applicant_id": applicant_id,
            "applicant_name": f"{applicant.first_name} {applicant.last_name}",
            "date_evaluated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "criteria_met": [],
            "criteria_not_met": [],
            "overall_score": 0,
            "advanced_to_interview": False
        }
        
        # Check required skills
        applicant_skills = set([skill.lower() for skill in applicant.skills])
        required_skills = set([skill.lower() for skill in self.screening_criteria["required_skills"]])
        
        if required_skills.issubset(applicant_skills):
            evaluation["criteria_met"].append("Required skills met")
        else:
            missing_skills = required_skills - applicant_skills
            evaluation["criteria_not_met"].append(f"Missing required skills: {', '.join(missing_skills)}")
        
        # Check minimum experience
        total_experience = self._calculate_experience(applicant.work_history)
        if total_experience >= self.screening_criteria["minimum_experience_years"]:
            evaluation["criteria_met"].append("Minimum experience requirement met")
        else:
            evaluation["criteria_not_met"].append(f"Insufficient experience: {total_experience} years, need {self.screening_criteria['minimum_experience_years']} years")
        
        # Check required education
        applicant_education = [edu.degree.lower() for edu in applicant.education]
        required_education = [degree.lower() for degree in self.screening_criteria["required_education"]]
        
        if any(required in applicant_education for required in required_education):
            evaluation["criteria_met"].append("Required education level met")
        else:
            evaluation["criteria_not_met"].append(f"Required education level not met. Available: {', '.join(applicant_education)}")
        
        # Check required certifications
        applicant_certifications = [cert.name.lower() for cert in applicant.certifications]
        required_certifications = [cert.lower() for cert in self.screening_criteria["required_certifications"]]
        
        if all(required in applicant_certifications for required in required_certifications):
            evaluation["criteria_met"].append("Required certifications met")
        else:
            missing_certs = [cert for cert in required_certifications if cert not in applicant_certifications]
            evaluation["criteria_not_met"].append(f"Missing required certifications: {', '.join(missing_certs)}")
        
        # Calculate score and determine interview advancement
        evaluation["overall_score"] = len(evaluation["criteria_met"])
        if len(evaluation["criteria_not_met"]) == 0:
            evaluation["advanced_to_interview"] = True
        else:
            # Advanced to interview if at least 70% of criteria are met
            total_criteria = len(evaluation["criteria_met"]) + len(evaluation["criteria_not_met"])
            if total_criteria > 0 and len(evaluation["criteria_met"]) / total_criteria >= 0.7:
                evaluation["advanced_to_interview"] = True
        
        self.screening_results.append(evaluation)
        return evaluation

    def _calculate_experience(self, work_history: List[WorkExperience]) -> int:
        """Calculate total years of experience"""
        total_months = 0
        for job in work_history:
            start_year = int(job.start_date.split('-')[0])
            end_year = int(job.end_date.split('-')[0])
            total_months += (end_year - start_year) * 12
        return total_months // 12

    def generate_report(self) -> Dict[str, Any]:
        """Generate a summary report of screening decisions"""
        if not self.screening_results:
            return {"message": "No screening results available"}
        
        total_applicants = len(self.screening_results)
        advanced_to_interview = sum(1 for result in self.screening_results if result["advanced_to_interview"])
        not_advanced = total_applicants - advanced_to_interview
        
        report = {
            "report_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_applicants": total_applicants,
            "advanced_to_interview": advanced_to_interview,
            "not_advanced_to_interview": not_advanced,
            "interview_advancement_rate": f"{(advanced_to_interview/total_applicants)*100:.1f}%" if total_applicants > 0 else "0%",
            "detailed_results": self.screening_results,
            "criteria_summary": self._generate_criteria_summary()
        }
        
        return report

    def _generate_criteria_summary(self) -> Dict[str, int]:
        """Generate summary of how many applicants met each criteria"""
        summary = defaultdict(int)
        for result in self.screening_results:
            for criterion in result["criteria_met"]:
                summary[criterion] += 1
            for criterion in result["criteria_not_met"]:
                summary[criterion] += 1
        return dict(summary)

    def export_report(self, filename: str = "screening_report.json"):
        """Export the screening report to a JSON file"""
        report = self.generate_report()
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
        return f"Report exported to {filename}"

def create_sample_data():
    """Create sample applicant data for demonstration"""
    # Create sample applicants
    applicant1 = Applicant(
        id="001",
        first_name="John",
        last_name="Smith",
        email="john.smith@example.com",
        phone="555-0101",
        education=[
            Education(
                institution="University of Technology",
                degree="Bachelor of Science",
                field="Computer Science",
                start_date="2015-09-01",
                end_date="2019-06-01",
                gpa="3.7"
            )
        ],
        work_history=[
            WorkExperience(
                company="Tech Solutions Inc.",
                position="Software Developer",
                start_date="2019-07-01",
                end_date="2022-06-01",
                description="Developed web applications using Python and Django framework."
            ),
            WorkExperience(
                company="Digital Innovations LLC",
                position="Junior Developer",
                start_date="2022-07-01",
                end_date="2023-06-01",
                description="Worked on mobile app development using React Native."
            )
        ],
        skills=["python", "django", "javascript", "react", "sql", "git"],
        certifications=[
            Certification(
                name="AWS Certified Developer",
                issuer="Amazon Web Services",
                issue_date="2021-03-15",
                expiration_date="2024-03-15"
            )
        ],
        demographic_info={
            "age": 28,
            "location": "San Francisco, CA",
            "gender": "Male"
        }
    )

    applicant2 = Applicant(
        id="002",
        first_name="Emily",
        last_name="Johnson",
        email="emily.johnson@example.com",
        phone="555-0102",
        education=[
            Education(
                institution="State University",
                degree="Bachelor of Arts",
                field="Information Technology",
                start_date="2016-09-01",
                end_date="2020-06-01",
                gpa="3.5"
            )
        ],
        work_history=[
            WorkExperience(
                company="Web Services Corp",
                position="IT Support Specialist",
                start_date="2020-07-01",
                end_date="2023-06-01",
                description="Provided technical support and maintained IT infrastructure."
            )
        ],
        skills=["python", "sql", "linux", "networking", "customer service"],
        certifications=[],
        demographic_info={
            "age": 25,
            "location": "New York, NY",
            "gender": "Female"
        }
    )

    return [applicant1, applicant2]

def main():
    """Main function to demonstrate the resume screening system"""
    # Initialize the screening system
    system = ResumeScreeningSystem()
    
    # Add sample applicants
    sample_applicants = create_sample_data()
    for applicant in sample_applicants:
        system.add_applicant(applicant)
    
    # Set screening criteria
    criteria = {
        "required_skills": ["python", "sql"],
        "minimum_experience_years": 2,
        "required_education": ["bachelor of science", "bachelor of arts"],
        "required_certifications": ["aws certified developer"],
        "minimum_age": 22,
        "preferred_skills": ["django", "react"]
    }
    
    system.set_screening_criteria(criteria)
    
    # Evaluate all applicants
    print("Evaluating applicants...")
    for applicant_id in system.applicants:
        result = system.evaluate_applicant(applicant_id)
        print(f"\nApplicant: {result['applicant_name']}")
        print(f"Advanced to interview: {'Yes' if result['advanced_to_interview'] else 'No'}")
        print(f"Overall score: {result['overall_score']}")
        if result["criteria_met"]:
            print("Criteria met:")
            for criterion in result["criteria_met"]:
                print(f"  - {criterion}")
        if result["criteria_not_met"]:
            print("Criteria not met:")
            for criterion in result["criteria_not_met"]:
                print(f"  - {criterion}")
    
    # Generate and display report
    print("\n" + "="*50)
    print("SCREENING REPORT")
    print("="*50)
    
    report = system.generate_report()
    
    print(f"Report generated on: {report['report_date']}")
    print(f"Total applicants: {report['total_applicants']}")
    print(f"Advanced to interview: {report['advanced_to_interview']}")
    print(f"Not advanced to interview: {report['not_advanced_to_interview']}")
    print(f"Interview advancement rate: {report['interview_advancement_rate']}")
    
    print("\nDetailed results:")
    for result in report['detailed_results']:
        print(f"\nApplicant: {result['applicant_name']}")
        print(f"Advanced to interview: {'Yes' if result['advanced_to_interview'] else 'No'}")
        print(f"Overall score: {result['overall_score']}")
        print("Criteria met:")
        for criterion in result['criteria_met']:
            print(f"  - {criterion}")
        if result['criteria_not_met']:
            print("Criteria not met:")
            for criterion in result['criteria_not_met']:
                print(f"  - {criterion}")
    
    # Export report
    system.export_report("resume_screening_report.json")
    print("\nReport exported to resume_screening_report.json")

if __name__ == "__main__":
    main()