import pytest
from datetime import datetime
from unittest.mock import patch
from resume_screening_system import (
    Applicant, Education, WorkExperience, Certification,
    ResumeScreeningSystem, create_sample_applicants
)

# Test data for applicants
def create_test_applicant():
    return Applicant(
        id="test001",
        first_name="Test",
        last_name="Applicant",
        email="test@applicant.com",
        phone="555-1234",
        education=[
            Education(
                institution="Test University",
                degree="Bachelor of Science",
                field="Computer Science",
                start_date="2018-09-01",
                end_date="2022-06-01",
                gpa="3.7"
            )
        ],
        work_history=[
            WorkExperience(
                company="Test Company",
                position="Junior Developer",
                start_date="2022-07-01",
                end_date="2023-06-01",
                description="Developed web applications."
            )
        ],
        skills=["python", "sql", "javascript"],
        certifications=[],
        demographic_info={
            "age": 25,
            "location": "Test City, TC",
            "gender": "Other"
        }
    )

def create_test_applicant_with_cert():
    return Applicant(
        id="test002",
        first_name="Certified",
        last_name="Applicant",
        email="cert@applicant.com",
        phone="555-5678",
        education=[
            Education(
                institution="Cert University",
                degree="Master of Science",
                field="Software Engineering",
                start_date="2016-09-01",
                end_date="2018-06-01",
                gpa="3.9"
            )
        ],
        work_history=[
            WorkExperience(
                company="Cert Company",
                position="Senior Developer",
                start_date="2018-07-01",
                end_date="2023-06-01",
                description="Led development projects."
            )
        ],
        skills=["python", "java", "docker", "kubernetes"],
        certifications=[
            Certification(
                name="AWS Certified Developer",
                issuer="Amazon Web Services",
                issue_date="2021-01-01",
                expiration_date="2024-01-01"
            )
        ],
        demographic_info={
            "age": 28,
            "location": "Cert City, CC",
            "gender": "Male"
        }
    )

# Test ResumeScreeningSystem class
class TestResumeScreeningSystem:
    
    def test_init(self):
        """Test initialization of the screening system."""
        system = ResumeScreeningSystem()
        assert system.applicants == {}
        assert system.screening_criteria == {
            "required_skills": [],
            "minimum_experience_years": 0,
            "required_education": [],
            "required_certifications": [],
            "minimum_age": 0,
            "preferred_skills": []
        }
        assert system.screening_results == []
    
    def test_add_applicant(self):
        """Test adding an applicant to the system."""
        system = ResumeScreeningSystem()
        applicant = create_test_applicant()
        system.add_applicant(applicant)
        assert system.applicants["test001"] == applicant
    
    def test_set_screening_criteria(self):
        """Test setting screening criteria."""
        system = ResumeScreeningSystem()
        criteria = {
            "required_skills": ["python", "sql"],
            "minimum_experience_years": 2,
            "required_education": ["bachelor of science"],
            "required_certifications": ["aws certified developer"],
            "minimum_age": 22,
            "preferred_skills": ["django"]
        }
        system.set_screening_criteria(criteria)
        assert system.screening_criteria == criteria
    
    def test_evaluate_applicant_not_found(self):
        """Test evaluating a non-existent applicant."""
        system = ResumeScreeningSystem()
        result = system.evaluate_applicant("nonexistent")
        assert "error" in result
        assert "not found" in result["error"]
    
    def test_evaluate_applicant_no_criteria(self):
        """Test evaluating an applicant with no screening criteria set."""
        system = ResumeScreeningSystem()
        applicant = create_test_applicant()
        system.add_applicant(applicant)
        result = system.evaluate_applicant("test001")
        
        assert result["applicant_id"] == "test001"
        assert result["applicant_name"] == "Test Applicant"
        assert "date_evaluated" in result
        assert result["overall_score"] == 0
        assert result["advanced_to_interview"] == False
        assert len(result["criteria_met"]) == 0
        assert len(result["criteria_not_met"]) == 0
    
    def test_evaluate_applicant_required_skills_met(self):
        """Test evaluating an applicant with required skills met."""
        system = ResumeScreeningSystem()
        applicant = create_test_applicant()
        system.add_applicant(applicant)
        
        # Set criteria that match applicant skills
        criteria = {"required_skills": ["python", "sql"]}
        system.set_screening_criteria(criteria)
        
        result = system.evaluate_applicant("test001")
        assert result["overall_score"] == 1  # Only required skills
        assert result["advanced_to_interview"] == True
        assert "Required skills" in result["criteria_met"][0]
        assert len(result["criteria_not_met"]) == 0
    
    def test_evaluate_applicant_required_skills_not_met(self):
        """Test evaluating an applicant with required skills not met."""
        system = ResumeScreeningSystem()
        applicant = create_test_applicant()
        system.add_applicant(applicant)
        
        # Set criteria that don't match applicant skills
        criteria = {"required_skills": ["java", "c++"]}
        system.set_screening_criteria(criteria)
        
        result = system.evaluate_applicant("test001")
        assert result["overall_score"] == 0
        assert result["advanced_to_interview"] == False
        assert len(result["criteria_not_met"]) == 1
        assert "Required skills" in result["criteria_not_met"][0]
    
    def test_evaluate_applicant_experience_met(self):
        """Test evaluating an applicant with sufficient experience."""
        system = ResumeScreeningSystem()
        applicant = create_test_applicant()
        system.add_applicant(applicant)
        
        # Set criteria that match applicant experience (1 year)
        criteria = {"minimum_experience_years": 1}
        system.set_screening_criteria(criteria)
        
        result = system.evaluate_applicant("test001")
        assert result["overall_score"] == 1
        assert result["advanced_to_interview"] == True
        assert "Minimum experience" in result["criteria_met"][0]
    
    def test_evaluate_applicant_experience_not_met(self):
        """Test evaluating an applicant with insufficient experience."""
        system = ResumeScreeningSystem()
        applicant = create_test_applicant()
        system.add_applicant(applicant)
        
        # Set criteria that exceed applicant experience (3 years)
        criteria = {"minimum_experience_years": 3}
        system.set_screening_criteria(criteria)
        
        result = system.evaluate_applicant("test001")
        assert result["overall_score"] == 0
        assert result["advanced_to_interview"] == False
        assert "Minimum experience" in result["criteria_not_met"][0]
    
    def test_evaluate_applicant_education_met(self):
        """Test evaluating an applicant with required education met."""
        system = ResumeScreeningSystem()
        applicant = create_test_applicant()
        system.add_applicant(applicant)
        
        # Set criteria that match applicant education
        criteria = {"required_education": ["bachelor of science"]}
        system.set_screening_criteria(criteria)
        
        result = system.evaluate_applicant("test001")
        assert result["overall_score"] == 1
        assert result["advanced_to_interview"] == True
        assert "Required education" in result["criteria_met"][0]
    
    def test_evaluate_applicant_education_not_met(self):
        """Test evaluating an applicant with required education not met."""
        system = ResumeScreeningSystem()
        applicant = create_test_applicant()
        system.add_applicant(applicant)
        
        # Set criteria that don't match applicant education
        criteria = {"required_education": ["master of science"]}
        system.set_screening_criteria(criteria)
        
        result = system.evaluate_applicant("test001")
        assert result["overall_score"] == 0
        assert result["advanced_to_interview"] == False
        assert "Required education" in result["criteria_not_met"][0]
    
    def test_evaluate_applicant_certification_met(self):
        """Test evaluating an applicant with required certification met."""
        system = ResumeScreeningSystem()
        applicant = create_test_applicant_with_cert()
        system.add_applicant(applicant)
        
        # Set criteria that match applicant certification
        criteria = {"required_certifications": ["aws certified developer"]}
        system.set_screening_criteria(criteria)
        
        result = system.evaluate_applicant("test002")
        assert result["overall_score"] == 1
        assert result["advanced_to_interview"] == True
        assert "Required certifications" in result["criteria_met"][0]
    
    def test_evaluate_applicant_certification_not_met(self):
        """Test evaluating an applicant with required certification not met."""
        system = ResumeScreeningSystem()
        applicant = create_test_applicant_with_cert()
        system.add_applicant(applicant)
        
        # Set criteria that don't match applicant certification
        criteria = {"required_certifications": ["google certified developer"]}
        system.set_screening_criteria(criteria)
        
        result = system.evaluate_applicant("test002")
        assert result["overall_score"] == 0
        assert result["advanced_to_interview"] == False
        assert "Required certifications" in result["criteria_not_met"][0]
    
    def test_evaluate_applicant_age_met(self):
        """Test evaluating an applicant with sufficient age."""
        system = ResumeScreeningSystem()
        applicant = create_test_applicant()
        system.add_applicant(applicant)
        
        # Set criteria that match applicant age (25)
        criteria = {"minimum_age": 20}
        system.set_screening_criteria(criteria)
        
        result = system.evaluate_applicant("test001")
        assert result["overall_score"] == 1
        assert result["advanced_to_interview"] == True
        assert "Minimum age" in result["criteria_met"][0]
    
    def test_evaluate_applicant_age_not_met(self):
        """Test evaluating an applicant with insufficient age."""
        system = ResumeScreeningSystem()
        applicant = create_test_applicant()
        system.add_applicant(applicant)
        
        # Set criteria that exceed applicant age (30)
        criteria = {"minimum_age": 30}
        system.set_screening_criteria(criteria)
        
        result = system.evaluate_applicant("test001")
        assert result["overall_score"] == 0
        assert result["advanced_to_interview"] == False
        assert "Minimum age" in result["criteria_not_met"][0]
    
    def test_evaluate_applicant_preferred_skills(self):
        """Test evaluating an applicant with preferred skills."""
        system = ResumeScreeningSystem()
        applicant = create_test_applicant()
        system.add_applicant(applicant)
        
        # Set criteria with preferred skills
        criteria = {"preferred_skills": ["javascript"]}
        system.set_screening_criteria(criteria)
        
        result = system.evaluate_applicant("test001")
        assert result["overall_score"] == 0  # Preferred skills don't count towards score
        assert result["advanced_to_interview"] == True  # Still advanced since no other criteria
        assert len(result["criteria_met"]) == 0
        assert len(result["criteria_not_met"]) == 0
    
    def test_evaluate_applicant_multiple_criteria_met(self):
        """Test evaluating an applicant with multiple criteria met."""
        system = ResumeScreeningSystem()
        applicant = create_test_applicant_with_cert()
        system.add_applicant(applicant)
        
        # Set criteria that match all applicant qualifications
        criteria = {
            "required_skills": ["python", "java"],
            "minimum_experience_years": 2,
            "required_education": ["master of science"],
            "required_certifications": ["aws certified developer"],
            "minimum_age": 25
        }
        system.set_screening_criteria(criteria)
        
        result = system.evaluate_applicant("test002")
        assert result["overall_score"] == 5  # All 5 criteria met
        assert result["advanced_to_interview"] == True
        assert len(result["criteria_met"]) == 5
        assert len(result["criteria_not_met"]) == 0
    
    def test_evaluate_applicant_multiple_criteria_mixed(self):
        """Test evaluating an applicant with mixed criteria met/not met."""
        system = ResumeScreeningSystem()
        applicant = create_test_applicant_with_cert()
        system.add_applicant(applicant)
        
        # Set criteria with some matching and some not
        criteria = {
            "required_skills": ["python", "java"],
            "minimum_experience_years": 5,
            "required_education": ["master of science"],
            "required_certifications": ["aws certified developer"],
            "minimum_age": 30
        }
        system.set_screening_criteria(criteria)
        
        result = system.evaluate_applicant("test002")
        assert result["overall_score"] == 3  # Only 3 criteria met
        assert result["advanced_to_interview"] == False  # Not advanced due to failed criteria
        assert len(result["criteria_met"]) == 3
        assert len(result["criteria_not_met"]) == 2
    
    def test_generate_report(self):
        """Test generating a screening report."""
        system = ResumeScreeningSystem()
        applicant1 = create_test_applicant()
        applicant2 = create_test_applicant_with_cert()
        system.add_applicant(applicant1)
        system.add_applicant(applicant2)
        
        # Set criteria
        criteria = {"required_skills": ["python"]}
        system.set_screening_criteria(criteria)
        
        # Evaluate both applicants
        system.evaluate_applicant("test001")
        system.evaluate_applicant("test002")
        
        report = system.generate_report()
        assert "report_date" in report
        assert report["total_applicants"] == 2
        assert report["advanced_to_interview"] == 2
        assert report["not_advanced_to_interview"] == 0
        assert report["interview_advancement_rate"] == "100%"
        assert len(report["detailed_results"]) == 2
    
    def test_create_sample_data(self):
        """Test creating sample data."""
        system = create_sample_data()
        assert len(system.applicants) == 3
        assert len(system.criteria) == 0  # No criteria set yet
        assert len(system.results) == 0  # No evaluations yet
    
    def test_calculate_experience(self):
        """Test calculating years of experience."""
        # This would be tested with more complex data
        pass

def create_sample_data():
    """Create sample data for testing."""
    system = ScreeningSystem()
    # Add sample applicants
    applicant1 = Applicant("John Doe", 25, ["python", "javascript"], ["bachelor of science"])
    applicant2 = Applicant("Jane Smith", 30, ["java", "c++"], ["master of science"])
    applicant3 = Applicant("Bob Johnson", 28, ["python", "java"], ["bachelor of science"])
    system.add_applicant(applicant1)
    system.add_applicant(applicant2)
    system.add_applicant(applicant3)
    return system

# Mock classes for testing
class Applicant:
    def __init__(self, name, age, skills, education):
        self.name = name
        self.age = age
        self.skills = skills
        self.education = education

class ScreeningSystem:
    def __init__(self):
        self.applicants = []
        self.criteria = {}
        self.results = []
    
    def add_applicant(self, applicant):
        self.applicants.append(applicant)
    
    def set_criteria(self, criteria):
        self.criteria = criteria
    
    def evaluate_applicant(self, applicant):
        # Mock evaluation
        self.results.append({"applicant": applicant.name, "score": 1})
    
    def generate_report(self):
        return {
            "report_date": "2023-01-01",
            "total_applicants": len(self.applicants),
            "advanced_to_interview": len(self.results),
            "not_advanced_to_interview": 0,
            "interview_advancement_rate": "100%",
            "detailed_results": self.results
        }

if __name__ == "__main__":
    # Run tests
    test_create_sample_data()
    test_generate_report()
    test_calculate_experience()
    print("All tests passed!")