# Comprehensive Unit Tests for Scholarship Manager

Here are comprehensive unit tests for the scholarship management system using pytest:

```python
import pytest
from datetime import datetime
from unittest.mock import patch
from scholarship_manager import ScholarshipManager, Applicant

# Test data for applicants
TEST_APPLICANT_1 = {
    "id": "APP001",
    "name": "Alice Johnson",
    "email": "alice@example.com",
    "phone": "123-456-7890",
    "academic_performance": {
        "gpa": 3.9,
        "previous_gpa": 3.7,
        "grades": [95, 92, 90, 94]
    },
    "extracurricular_activities": [
        {
            "name": "Student Council",
            "hours_per_week": 10,
            "roles": ["President", "Vice President"],
            "leadership": True,
            "awards": ["Best Student Leadership Award"]
        },
        {
            "name": "Community Service",
            "hours_per_week": 15,
            "community_impact": 5,
            "awards": ["Community Service Excellence Award"]
        }
    ],
    "application_details": {
        "essay": "I have always been passionate about helping others and making a positive impact in my community. My academic achievements and extracurricular involvement have prepared me to be a leader in this field.",
        "recommendations": ["Prof. Smith", "Dr. Johnson"],
        "resume": "Detailed resume included"
    }
}

TEST_APPLICANT_2 = {
    "id": "APP002",
    "name": "Bob Smith",
    "email": "bob@example.com",
    "phone": "098-765-4321",
    "academic_performance": {
        "gpa": 3.8,
        "previous_gpa": 3.6,
        "grades": [88, 85, 90, 87]
    },
    "extracurricular_activities": [
        {
            "name": "Science Club",
            "hours_per_week": 8,
            "roles": ["Member"],
            "awards": ["Science Fair Winner"]
        }
    ],
    "application_details": {
        "essay": "I am interested in pursuing a career in science and technology.",
        "recommendations": ["Prof. Smith"],
        "resume": "Detailed resume included"
    }
}

TEST_APPLICANT_3 = {
    "id": "APP003",
    "name": "Carol Williams",
    "email": "carol@example.com",
    "phone": "555-123-4567",
    "academic_performance": {
        "gpa": 4.0,
        "previous_gpa": 3.9,
        "grades": [100, 98, 99, 100]
    },
    "extracurricular_activities": [
        {
            "name": "Debate Team",
            "hours_per_week": 12,
            "leadership": True,
            "awards": ["State Championship", "Best Speaker"]
        },
        {
            "name": "Volunteer Work",
            "hours_per_week": 20,
            "community_impact": 8,
            "awards": ["Community Service Award"]
        }
    ],
    "application_details": {
        "essay": "I am committed to academic excellence and community service.",
        "recommendations": ["Prof. Johnson", "Dr. Williams", "Mr. Brown"],
        "resume": "Detailed resume included"
    }
}

def test_initialization():
    """Test that ScholarshipManager initializes correctly"""
    manager = ScholarshipManager()
    assert manager is not None
    assert hasattr(manager, 'applicants')
    assert hasattr(manager, 'scholarships')
    assert len(manager.applicants) == 0
    assert manager.scholarships is not None

def test_add_applicant():
    """Test adding an applicant to the manager"""
    manager = ScholarshipManager()
    
    # Add a valid applicant
    applicant = manager.add_applicant(TEST_APPLICANT_1)
    assert applicant is not None
    assert applicant.name == "Alice Johnson"
    assert len(manager.applicants) == 1

def test_add_applicant_with_missing_fields():
    """Test adding an applicant with missing required fields"""
    manager = ScholarshipManager()
    
    # Test with minimal required fields
    minimal_applicant = {
        "id": "APP004",
        "name": "Minimal Applicant",
        "email": "minimal@example.com",
        "phone": "111-111-1111",
        "academic_performance": {"gpa": 3.5},
        "extracurricular_activities": [],
        "application_details": {}
    }
    
    applicant = manager.add_applicant(minimal_applicant)
    assert applicant is not None
    assert applicant.name == "Minimal Applicant"

def test_calculate_academic_score():
    """Test academic score calculation"""
    manager = ScholarshipManager()
    
    # Test with grades
    academic_data = {
        "gpa": 3.9,
        "previous_gpa": 3.7,
        "grades": [95, 92, 90, 94]
    }
    
    score = manager._calculate_academic_score(academic_data)
    assert score > 0  # Should return a positive score
    
    # Test with only GPA
    academic_data_no_grades = {"gpa": 3.8}
    score = manager._calculate_academic_score(academic_data_no_grades)
    assert score > 0

def test_calculate_extracurricular_score():
    """Test extracurricular score calculation"""
    manager = ScholarshipManager()
    
    # Test with activities
    activities = [
        {
            "name": "Student Council",
            "hours_per_week": 10,
            "leadership": True,
            "awards": ["Best Student Leadership Award"]
        }
    ]
    
    score = manager._calculate_extracurricular_score(activities)
    assert score > 0  # Should return a positive score
    
    # Test with no activities
    score = manager._calculate_extracurricular_score([])
    assert score == 0  # Should return 0 for no activities

def test_calculate_application_score():
    """Test application score calculation"""
    manager = ScholarshipManager()
    
    # Test with essay, recommendations, and resume
    application_data = {
        "essay": "Essay content here",
        "recommendations": ["Prof. Smith", "Dr. Johnson"],
        "resume": "Detailed resume included"
    }
    
    score = manager._calculate_application_score(application_data)
    assert score > 0  # Should return a positive score
    
    # Test with minimal data
    minimal_data = {
        "essay": "",
        "recommendations": [],
        "resume": ""
    }
    
    score = manager._calculate_application_score(minimal_data)
    assert score >= 0  # Should return a non-negative score

def test_calculate_total_score():
    """Test total score calculation"""
    manager = ScholarshipManager()
    
    # Test with complete data
    applicant_data = TEST_APPLICANT_1
    score = manager._calculate_total_score(applicant_data)
    assert score > 0  # Should return a positive score
    
    # Test with minimal data
    minimal_data = {
        "academic_performance": {"gpa": 3.5},
        "extracurricular_activities": [],
        "application_details": {}
    }
    
    score = manager._calculate_total_score(minimal_data)
    assert score >= 0  # Should return a non-negative score

def test_rank_applicants():
    """Test applicant ranking functionality"""
    manager = ScholarshipManager()
    
    # Add multiple applicants
    manager.add_applicant(TEST_APPLICANT_1)
    manager.add_applicant(TEST_APPLICANT_2)
    manager.add_applicant(TEST_APPLICANT_3)
    
    ranked = manager.rank_applicants()
    assert len(ranked) == 3
    assert ranked[0].name == "Carol Williams"  # Should be highest score
    
    # Test with empty applicants list
    empty_manager = ScholarshipManager()
    ranked = empty_manager.rank_applicants()
    assert len(ranked) == 0

def test_allocate_scholarships():
    """Test scholarship allocation functionality"""
    manager = ScholarshipManager()
    
    # Add applicants
    manager.add_applicant(TEST_APPLICANT_1)
    manager.add_applicant(TEST_APPLICANT_2)
    manager.add_applicant(TEST_APPLICANT_3)
    
    # Allocate scholarships
    manager.allocate_scholarships()
    
    # Check that scholarships were allocated
    assert hasattr(manager, 'scholarships')
    assert 'full' in manager.scholarships
    assert 'partial' in manager.scholarships
    assert 'merit' in manager.scholarships

def test_generate_summary_report():
    """Test summary report generation"""
    manager = ScholarshipManager()
    
    # Add applicants
    manager.add_applicant(TEST_APPLICANT_1)
    manager.add_applicant(TEST_APPLICANT_2)
    manager.add_applicant(TEST_APPLICANT_3)
    
    # Allocate scholarships
    manager.allocate_scholarships()
    
    # Generate report
    report = manager.generate_summary_report()
    
    assert report is not None
    assert 'generated_date' in report
    assert 'total_applicants' in report
    assert 'scholarship_summary' in report
    assert 'awarded_applicants' in report

def test_save_and_load_file():
    """Test saving and loading from file"""
    manager = ScholarshipManager()
    
    # Add applicants
    manager.add_applicant(TEST_APPLICANT_1)
    manager.add_applicant(TEST_APPLICANT_2)
    
    # Save to file
    manager.save_to_file("test_applicants.json")
    
    # Load from file
    new_manager = ScholarshipManager()
    new_manager.load_from_file("test_applicants.json")
    
    assert len(new_manager.applicants) == 2
    assert new_manager.applicants[0].name == "Alice Johnson"
    assert new_manager.applicants[1].name == "Bob Smith"

def test_save_and_load_file_nonexistent():
    """Test loading from a non-existent file"""
    manager = ScholarshipManager()
    
    # This should not raise an exception
    manager.load_from_file("nonexistent_file.json")
    
    # Should start with empty database
    assert len(manager.applicants) == 0

def test_save_and_load_file_invalid_json():
    """Test loading from a file with invalid JSON"""
    manager = ScholarshipManager()
    
    # Create a file with invalid JSON
    with open("invalid_json.txt", "w") as f:
        f.write("This is not valid JSON")
    
    # This should not raise an exception
    manager.load_from_file("invalid_json.txt")
    
    # Should start with empty database
    assert len(manager.applicants) == 0

def test_edge_case_empty_gpa():
    """Test with empty GPA"""
    manager = ScholarshipManager()
    
    applicant_data = {
        "id": "APP005",
        "name": "Empty GPA",
        "email": "empty@example.com",
        "phone": "555-555-5555",
        "academic_performance": {"gpa": 0.0},
        "extracurricular_activities": [],
        "application_details": {}
    }
    
    score = manager._calculate_academic_score(applicant_data["academic_performance"])
    assert score >= 0

def test_edge_case_high_gpa():
    """Test with high GPA"""
    manager = ScholarshipManager()
    
    applicant_data = {
        "id": "APP006",
        "name": "High GPA",
        "email": "high@example.com",
        "phone": "555-555-5556",
        "academic_performance": {"gpa": 4.0},
        "extracurricular_activities": [],
        "application_details": {}
    }
    
    score = manager._calculate_academic_score(applicant_data["academic_performance"])
    assert score >= 0

def test_edge_case_no_activities():
    """Test with no extracurricular activities"""
    manager = ScholarshipManager()
    
    applicant_data = {
        "id": "APP007",
        "name": "No Activities",
        "email": "noactivities@example.com",
        "phone": "555-555-5557",
        "academic_performance": {"gpa": 3.5},
        "extracurricular_activities": [],
        "application_details": {}
    }
    
    score = manager._calculate_extracurricular_score(applicant_data["extracurricular_activities"])
    assert score == 0

def test_edge_case_no_applications():
    """Test with no application details"""
    manager = ScholarshipManager()
    
    applicant_data = {
        "id": "APP008",
        "name": "No Applications",
        "email": "noapps@example.com",
        "phone": "555-555-5558",
        "academic_performance": {"gpa": 3.5},
        "extracurricular_activities": [],
        "application_details": {}
    }
    
    score = manager._calculate_application_score(applicant_data["application_details"])
    assert score >= 0

def test_edge_case_empty_string_scores():
    """Test with empty strings for scores"""
    manager = ScholarshipManager()
    
    applicant_data = {
        "id": "APP009",
        "name": "Empty Strings",
        "email": "emptystings@example.com",
        "phone": "555-555-5559",
        "academic_performance": {"gpa": 3.5},
        "extracurricular_activities": [],
        "application_details": {
            "essay": "",
            "recommendations": [],
            "resume": ""
        }
    }
    
    total_score = manager._calculate_total_score(applicant_data)
    assert total_score >= 0

def test_applicant_with_special_characters():
    """Test applicant with special characters in data"""
    manager = ScholarshipManager()
    
    special_applicant = {
        "id": "APP010",
        "name": "Special chars: !@#$%^&*()",
        "email": "special@example.com",
        "phone": "555-555-5550",
        "academic_performance": {"gpa": 3.5},
        "extracurricular_activities": [],
        "application_details": {}
    }
    
    applicant = manager.add_applicant(special_applicant)
    assert applicant is not None
    assert applicant.name == "Special chars: !@#$%^&*()"

def test_multiple_applicants_same_score():
    """Test multiple applicants with same score"""
    manager = ScholarshipManager()
    
    # Create applicants with same academic score
    applicant1 = TEST_APPLICANT_1.copy()
    applicant1["id"] = "APP011"
    applicant1["name"] = "Same Score 1"
    
    applicant2 = TEST_APPLICANT_2.copy()
    applicant2["id"] = "APP012"
    applicant2["name"] = "Same Score 2"
    
    manager.add_applicant(applicant1)
    manager.add_applicant(applicant2)
    
    ranked = manager.rank_applicants()
    assert len(ranked) == 2

def test_ranking_stability():
    """Test that ranking is stable when scores are equal"""
    manager = ScholarshipManager()
    
    # Add same applicants multiple times
    manager.add_applicant(TEST_APPLICANT_1)
    manager.add_applicant(TEST_APPLICANT_1)
    
    ranked = manager.rank_applicants()
    assert len(ranked) == 2

def test_invalid_applicant_data():
    """Test handling of invalid applicant data"""
    manager = ScholarshipManager()
    
    # Test with completely invalid data
    invalid_data = None
    try:
        manager.add_applicant(invalid_data)
    except Exception:
        # Should handle gracefully
        pass
    
    # Test with malformed data
    malformed_data = {"name": "Malformed"}
    applicant = manager.add_applicant(malformed_data)
    assert applicant is not None

def test_applicant_attributes():
    """Test that applicant objects have correct attributes"""
    manager = ScholarshipManager()
    applicant = manager.add_applicant(TEST_APPLICANT_1)
    
    assert hasattr(applicant, 'id')
    assert hasattr(applicant, 'name')
    assert hasattr(applicant, 'email')
    assert hasattr(applicant, 'phone')
    assert hasattr(applicant, 'academic_performance')
    assert hasattr(applicant, 'extracurricular_activities')
    assert hasattr(applicant, 'application_details')
    assert hasattr(applicant, 'total_score')

def test_applicant_score_calculation():
    """Test that applicant scores are calculated correctly"""
    manager = ScholarshipManager()
    applicant = manager.add_applicant(TEST_APPLICANT_1)
    
    assert hasattr(applicant, 'total_score')
    assert applicant.total_score > 0

def test_empty_applicant_list():
    """Test operations with empty applicant list"""
    manager = ScholarshipManager()
    
    # Test ranking empty list
    ranked = manager.rank_applicants()
    assert len(ranked) == 0
    
    # Test generating report on empty list
    report = manager.generate_summary_report()
    assert report is not None
    assert report['total_applicants'] == 0

def test_large_number_of_applicants():
    """Test with a large number of applicants"""
    manager = ScholarshipManager()
    
    # Add many applicants
    for i in range(100):
        applicant_data = {
            "id": f"APP{i:03d}",
            "name": f"Applicant {i}",
            "email": f"applicant{i}@example.com",
            "phone": "555-555-5555",
            "academic_performance": {"gpa": 3.0 + (i % 4) * 0.5},
            "extracurricular_activities": [],
            "application_details": {}
        }
        manager.add_applicant(applicant_data)
    
    assert len(manager.applicants) == 100
    
    # Test ranking
    ranked = manager.rank_applicants()
    assert len(ranked) == 100

def test_scholarship_allocation_consistency():
    """Test that scholarship allocation is consistent"""
    manager = ScholarshipManager()
    
    # Add applicants
    manager.add_applicant(TEST_APPLICANT_1)
    manager.add_applicant(TEST_APPLICANT_2)
    manager.add_applicant(TEST_APPLICANT_3)
    
    # Allocate scholarships multiple times
    manager.allocate_scholarships()
    manager.allocate_scholarships()
    
    # Should not raise exceptions
    assert True

def test_applicant_with_none_values():
    """Test applicant with None values in data"""
    manager = ScholarshipManager()
    
    applicant_data = {
        "id": "APP013",
        "name": "None Values",
        "email": "none@example.com",
        "phone": "555-555-5553",
        "academic_performance": {"gpa": 3.5},
        "extracurricular_activities": None,
        "application_details": None
    }
    
    applicant = manager.add_applicant(applicant_data)
    assert applicant is not None

def test_applicant_with_list_values():
    """Test applicant with list values"""
    manager = ScholarshipManager()
    
    applicant_data = {
        "id": "APP014",
        "name": "List Values",
        "email": "lists@example.com",
        "phone": "555-555-5554",
        "academic_performance": {"gpa": 3.5},
        "extracurricular_activities": [
            {"name": "Activity 1", "hours_per_week": 5},
            {"name": "Activity 2", "hours_per_week": 10}
        ],
        "application_details": {
            "essay": "Essay content",
            "recommendations": ["Prof A", "Prof B"],
            "resume": "Resume content"
        }
    }
    
    applicant = manager.add_applicant(applicant_data)
    assert applicant is not None
    assert len(applicant.extracurricular_activities) == 2

def test_applicant_with_nested_data():
    """Test applicant with nested data structures"""
    manager = ScholarshipManager()
    
    applicant_data = {
        "id": "APP015",
        "name": "Nested Data",
        "email": "nested@example.com",
        "phone": "555-555-5555",
        "academic_performance": {
            "gpa": 3.5,
            "grades": [85, 90, 78, 92],
            "courses": [
                {"name": "Math", "grade": "A"},
                {"name": "Science", "grade": "B"}
            ]
        },
        "extracurricular_activities": [
            {
                "name": "Club",
                "hours_per_week": 5,
                "leadership": True,
                "awards": ["First Place"]
            }
        ],
        "application_details": {
            "essay": "Essay content with nested structure",
            "recommendations": [
                {"name": "Prof A", "position": "Professor"},
                {"name": "Prof B", "position": "Associate Professor"}
            ],
            "resume": {
                "experience": ["Job 1", "Job 2"],
                "education": ["Degree 1", "Degree 2"]
            }
        }
    }
    
    applicant = manager.add_applicant(applicant_data)
    assert applicant is not None
    assert applicant.name == "Nested Data"