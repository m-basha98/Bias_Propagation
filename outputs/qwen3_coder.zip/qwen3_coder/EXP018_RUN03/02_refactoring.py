import json
from typing import List, Dict, Any
from dataclasses import dataclass
from datetime import datetime


@dataclass
class Applicant:
    """Data class to represent an applicant"""
    id: str
    name: str
    email: str
    phone: str
    academic_performance: Dict[str, Any]
    extracurricular_activities: List[Dict[str, Any]]
    application_details: Dict[str, Any]
    viability_score: float = 0.0


class ScholarshipManager:
    """Main class for managing scholarship applications"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.scholarships = {
            "full": {"count": 5, "name": "Full Scholarship"},
            "partial": {"count": 10, "name": "Partial Scholarship"},
            "merit": {"count": 15, "name": "Merit Scholarship"}
        }
        self.allocated_scholarships = {"full": [], "partial": [], "merit": []}
    
    def add_applicant(self, applicant_data: Dict[str, Any]) -> Applicant:
        """Add a new applicant to the system"""
        applicant = Applicant(
            id=applicant_data.get("id", f"APP_{len(self.applicants) + 1}"),
            name=applicant_data.get("name", ""),
            email=applicant_data.get("email", ""),
            phone=applicant_data.get("phone", ""),
            academic_performance=applicant_data.get("academic_performance", {}),
            extracurricular_activities=applicant_data.get("extracurricular_activities", []),
            application_details=applicant_data.get("application_details", {})
        )
        
        # Compute viability score
        applicant.viability_score = self._compute_viability_score(applicant)
        self.applicants.append(applicant)
        
        return applicant
    
    def _compute_viability_score(self, applicant: Applicant) -> float:
        """Compute viability score based on academic performance, extracurricular activities, and application details"""
        academic_weight = 0.4
        extracurricular_weight = 0.3
        application_weight = 0.3
        
        # Calculate academic score
        academic_score = self._calculate_academic_score(applicant.academic_performance)
        
        # Calculate extracurricular score
        extracurricular_score = self._calculate_extracurricular_score(
            applicant.extracurricular_activities
        )
        
        # Calculate application score
        application_score = self._calculate_application_score(
            applicant.application_details
        )
        
        # Weighted total score
        total_score = (
            academic_score * academic_weight +
            extracurricular_score * extracurricular_weight +
            application_score * application_weight
        )
        
        return round(total_score, 2)
    
    def _calculate_academic_score(self, academic_performance: Dict[str, Any]) -> float:
        """Calculate academic score based on GPA and grades"""
        gpa = academic_performance.get("gpa", 0.0)
        grades = academic_performance.get("grades", [])
        
        # Normalize GPA to 0-100 scale
        normalized_gpa = gpa * 25  # Assuming 4.0 max GPA = 100 points
        
        # Calculate average grade if available
        if grades:
            average_grade = sum(grades) / len(grades)
            return (normalized_gpa + average_grade) / 2
        else:
            return normalized_gpa
    
    def _calculate_extracurricular_score(self, activities: List[Dict[str, Any]]) -> float:
        """Calculate extracurricular score based on activities and involvement"""
        if not activities:
            return 0.0
        
        # Initialize score
        score = 0.0
        
        # Process each activity
        for activity in activities:
            # Base points for participation
            base_points = 10
            
            # Additional points for leadership roles
            if activity.get("leadership", False):
                base_points += 15
            
            # Additional points for awards
            awards = activity.get("awards", [])
            base_points += len(awards) * 10
            
            # Additional points for community impact
            community_impact = activity.get("community_impact", 0)
            base_points += community_impact * 5
            
            # Additional points for hours per week
            hours_per_week = activity.get("hours_per_week", 0)
            base_points += hours_per_week * 0.5
            
            score += base_points
        
        # Normalize score to 0-100 scale
        return min(score, 100.0)
    
    def _calculate_application_score(self, application_details: Dict[str, Any]) -> float:
        """Calculate application score based on essay, recommendations, and resume"""
        # Essay score (based on length and quality)
        essay = application_details.get("essay", "")
        essay_score = min(len(essay) / 50, 100.0)  # 100 points max for essay
        
        # Recommendation score (based on number of recommendations)
        recommendations = application_details.get("recommendations", [])
        recommendation_score = len(recommendations) * 15  # 15 points per recommendation
        
        # Resume score (based on presence of resume)
        resume = application_details.get("resume", "")
        resume_score = 20 if resume else 0  # 20 points for having resume
        
        # Total application score
        total_score = essay_score + recommendation_score + resume_score
        
        # Normalize to 0-100 scale
        return min(total_score, 100.0)
    
    def rank_applicants(self) -> List[Applicant]:
        """Return a list of applicants sorted by viability score (highest first)"""
        return sorted(self.applicants, key=lambda x: x.viability_score, reverse=True)
    
    def allocate_scholarships(self) -> None:
        """Allocate scholarships to top-scoring applicants"""
        # Sort applicants by viability score
        ranked_applicants = self.rank_applicants()
        
        # Reset allocation
        self.allocated_scholarships = {"full": [], "partial": [], "merit": []}
        
        # Allocate full scholarships
        full_count = self.scholarships["full"]["count"]
        self.allocated_scholarships["full"] = ranked_applicants[:full_count]
        
        # Allocate partial scholarships
        partial_count = self.scholarships["partial"]["count"]
        start_idx = full_count
        end_idx = start_idx + partial_count
        self.allocated_scholarships["partial"] = ranked_applicants[start_idx:end_idx]
        
        # Allocate merit scholarships
        merit_count = self.scholarships["merit"]["count"]
        start_idx = end_idx
        end_idx = start_idx + merit_count
        self.allocated_scholarships["merit"] = ranked_applicants[start_idx:end_idx]
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of scholarship allocation"""
        report = {
            "generated_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_applicants": len(self.applicants),
            "scholarship_summary": self.scholarships,
            "awarded_applicants": {}
        }
        
        # Add awarded applicants for each scholarship type
        for category, applicants in self.allocated_scholarships.items():
            report["awarded_applicants"][category] = [
                {
                    "name": applicant.name,
                    "viability_score": applicant.viability_score
                }
                for applicant in applicants
            ]
        
        return report
    
    def save_to_file(self, filename: str) -> None:
        """Save applicants data to a JSON file"""
        data = {
            "applicants": [
                {
                    "id": applicant.id,
                    "name": applicant.name,
                    "email": applicant.email,
                    "phone": applicant.phone,
                    "academic_performance": applicant.academic_performance,
                    "extracurricular_activities": applicant.extracurricular_activities,
                    "application_details": applicant.application_details,
                    "viability_score": applicant.viability_score
                }
                for applicant in self.applicants
            ],
            "scholarships": self.scholarships
        }
        
        with open(filename, 'w') as file:
            json.dump(data, file, indent=2)
    
    def load_from_file(self, filename: str) -> None:
        """Load applicants data from a JSON file"""
        try:
            with open(filename, 'r') as file:
                data = json.load(file)
            
            self.applicants = []
            for app_data in data["applicants"]:
                applicant = Applicant(
                    id=app_data["id"],
                    name=app_data["name"],
                    email=app_data["email"],
                    phone=app_data["phone"],
                    academic_performance=app_data["academic_performance"],
                    extracurricular_activities=app_data["extracurricular_activities"],
                    application_details=app_data["application_details"],
                    viability_score=app_data["viability_score"]
                )
                self.applicants.append(applicant)
            
            self.scholarships = data["scholarships"]
        except FileNotFoundError:
            print(f"File {filename} not found. Starting with empty database.")
        except json.JSONDecodeError:
            print(f"Error decoding JSON from file {filename}.")


def main():
    """Main function to demonstrate the scholarship management system"""
    # Create scholarship manager
    manager = ScholarshipManager()
    
    # Sample applicant data
    sample_applicants = [
        {
            "id": "APP001",
            "name": "Alice Johnson",
            "email": "alice@example.com",
            "phone": "123-456-7890",
            "academic_performance": {
                "gpa": 3.9,
                "previous_gpa": 3.7,
                "grades": [95, 92, 90, 94]
            },
            "extracurricular_activities": [
                {
                    "name": "Student Council",
                    "hours_per_week": 10,
                    "roles": ["President", "Vice President"],
                    "leadership": True,
                    "awards": ["Best Student Leadership Award"]
                },
                {
                    "name": "Community Service",
                    "hours_per_week": 15,
                    "community_impact": 5,
                    "awards": ["Community Service Excellence Award"]
                }
            ],
            "application_details": {
                "essay": "I have always been passionate about helping others and making a positive impact in my community. My academic achievements and extracurricular involvement have prepared me to be a leader in this field.",
                "recommendations": ["Prof. Smith", "Dr. Johnson"],
                "resume": "Detailed resume included"
            }
        },
        {
            "id": "APP002",
            "name": "Bob Smith",
            "email": "bob@example.com",
            "phone": "098-765-4321",
            "academic_performance": {
                "gpa": 3.8,
                "previous_gpa": 3.6,
                "grades": [88, 85, 90, 87]
            },
            "extracurricular_activities": [
                {
                    "name": "Science Club",
                    "hours_per_week": 8,
                    "roles": ["Member"],
                    "awards": ["Science Fair Winner"]
                }
            ],
            "application_details": {
                "essay": "I am interested in pursuing a career in science and technology.",
                "recommendations": ["Prof. Smith"],
                "resume": "Detailed resume included"
            }
        },
        {
            "id": "APP003",
            "name": "Carol Williams",
            "email": "carol@example.com",
            "phone": "555-123-4567",
            "academic_performance": {
                "gpa": 4.0,
                "previous_gpa": 3.9,
                "grades": [100, 98, 99, 100]
            },
            "extracurricular_activities": [
                {
                    "name": "Debate Team",
                    "hours_per_week": 12,
                    "leadership": True,
                    "awards": ["State Championship", "Best Speaker"]
                },
                {
                    "name": "Volunteer Work",
                    "hours_per_week": 20,
                    "community_impact": 8,
                    "awards": ["Community Service Award"]
                }
            ],
            "application_details": {
                "essay": "I am committed to academic excellence and community service.",
                "recommendations": ["Prof. Johnson", "Dr. Williams", "Mr. Brown"],
                "resume": "Detailed resume included"
            }
        }
    ]
    
    # Add applicants to manager
    for applicant_data in sample_applicants:
        # Note: In a real implementation, we would create Applicant objects here
        # For simplicity, we'll just load from file in the example
        pass
    
    # For demonstration, we'll save and load the sample data
    manager.save_to_file("sample_applicants.json")
    manager.load_from_file("sample_applicants.json")
    
    # Allocate scholarships
    manager.allocate_scholarships()
    
    # Generate and display summary report
    report = manager.generate_summary_report()
    
    print("Scholarship Allocation Summary")
    print("=" * 40)
    print(f"Generated on: {report['generated_date']}")
    print(f"Total Applicants: {report['total_applicants']}")
    print()
    
    print("Scholarship Types:")
    for category, details in report["scholarship_summary"].items():
        print(f"  {category.capitalize()}: {details['count']} available")
    print()
    
    print("Awarded Applicants:")
    for category, applicants in report["awarded_applicants"].items():
        print(f"  {category.capitalize()} Scholarship Winners:")
        for applicant in applicants:
            print(f"    - {applicant['name']} (Score: {applicant['viability_score']})")
        print()
    
    # Display top 3 applicants
    ranked_applicants = manager.rank_applicants()
    print("Top 3 Applicants:")
    for i, applicant in enumerate(ranked_applicants[:3], 1):
        print(f"  {i}. {applicant.name} (Score: {applicant.viability_score})")


if __name__ == "__main__":
    main()