# Technical Documentation

## Overview
This software implements a scholarship management system that handles applicant information, computes viability scores, ranks applicants, and allocates scholarships based on rankings. The system is designed to operate without external databases or services and generates summary reports of awarded applicants.

## Class Documentation

### `Applicant` (Data Class)
Represents an applicant with all relevant information for scholarship evaluation.

**Attributes:**
- `id` (str): Unique identifier for the applicant
- `name` (str): Full name of the applicant
- `email` (str): Email address of the applicant
- `phone` (str): Phone number of the applicant
- `academic_performance` (Dict[str, Any]): Academic records including GPA and grades
- `extracurricular_activities` (List[Dict[str, Any]]): List of extracurricular activities
- `application_details` (Dict[str, Any]): Application materials including essays and recommendations
- `viability_score` (float): Computed viability score for the applicant (default: 0.0)

### `ScholarshipManager` (Main Class)
Main class for managing scholarship applications and allocations.

**Attributes:**
- `applicants` (List[Applicant]): List of all applicants
- `scholarships` (Dict[str, Dict[str, Any]]): Configuration for different scholarship types
- `allocated_scholarships` (Dict[str, List[Applicant]]): Track of allocated scholarships by category

## Function Documentation

### `__init__(self)`
Initializes the ScholarshipManager with default scholarship configurations and empty applicant lists.

**Parameters:** None

**Returns:** None

### `add_applicant(self, applicant_data: Dict[str, Any]) -> Applicant`
Adds a new applicant to the system and computes their viability score.

**Parameters:**
- `applicant_data` (Dict[str, Any]): Dictionary containing applicant information with keys:
  - `id` (str): Unique identifier
  - `name` (str): Full name
  - `email` (str): Email address
  - `phone` (str): Phone number
  - `academic_performance` (Dict[str, Any]): Academic records
  - `extracurricular_activities` (List[Dict[str, Any]]): Extracurricular activities
  - `application_details` (Dict[str, Any]): Application materials

**Returns:** Applicant - The created applicant object with computed viability score

### `_compute_viability_score(self, applicant: Applicant) -> float`
Computes a weighted viability score for an applicant based on academic performance, extracurricular activities, and application details.

**Parameters:**
- `applicant` (Applicant): The applicant object to score

**Returns:** float - The computed viability score (rounded to 2 decimal places)

### `_calculate_academic_score(self, academic_performance: Dict[str, Any]) -> float`
Calculates academic score based on GPA and grades.

**Parameters:**
- `academic_performance` (Dict[str, Any]): Dictionary containing academic records with keys:
  - `gpa` (float): Grade Point Average
  - `grades` (List[float]): List of individual grades

**Returns:** float - Normalized academic score (0-100 scale)

### `_calculate_extracurricular_score(self, activities: List[Dict[str, Any]]) -> float`
Calculates extracurricular score based on activities and involvement.

**Parameters:**
- `activities` (List[Dict[str, Any]]): List of extracurricular activity dictionaries with keys:
  - `name` (str): Activity name
  - `hours_per_week` (int): Hours spent per week
  - `leadership` (bool): Whether applicant held leadership position
  - `awards` (List[str]): List of awards received

**Returns:** float - Normalized extracurricular score (0-100 scale)

### `_calculate_application_score(self, application_details: Dict[str, Any]) -> float`
Calculates application score based on essay quality and recommendations.

**Parameters:**
- `application_details` (Dict[str, Any]): Dictionary containing application materials with keys:
  - `essay` (str): Essay content
  - `recommendations` (List[str]): List of recommendation names
  - `resume` (str): Resume information

**Returns:** float - Normalized application score (0-100 scale)

### `rank_applicants(self) -> List[Applicant]`
Ranks all applicants by their viability scores in descending order.

**Parameters:** None

**Returns:** List[Applicant] - List of applicants sorted by viability score (highest first)

### `allocate_scholarships(self)`
Allocates scholarships to applicants based on their rankings.

**Parameters:** None

**Returns:** None

### `generate_summary_report(self) -> Dict[str, Any]`
Generates a summary report of scholarship allocations.

**Parameters:** None

**Returns:** Dict[str, Any] - Dictionary containing:
  - `generated_date` (str): Date when report was generated
  - `total_applicants` (int): Number of applicants
  - `scholarship_summary` (Dict[str, Dict[str, Any]]): Configuration of scholarship types
  - `awarded_applicants` (Dict[str, List[Dict[str, Any]]]): List of awarded applicants by category

### `save_to_file(self, filename: str) -> None`
Saves current applicant data to a JSON file.

**Parameters:**
- `filename` (str): Name of the file to save data to

**Returns:** None

### `load_from_file(self, filename: str) -> None`
Loads applicant data from a JSON file.

**Parameters:**
- `filename` (str): Name of the file to load data from

**Returns:** None

## Main Function

### `main()`
Demonstrates the functionality of the scholarship management system.

**Parameters:** None

**Returns:** None

**Functionality:**
1. Creates a ScholarshipManager instance
2. Defines sample applicant data
3. Saves sample data to file
4. Loads sample data from file
5. Allocates scholarships
6. Generates and displays summary report
7. Displays top 3 applicants

## Key Features

### Weighted Scoring System
The system uses a weighted approach to evaluate applicants:
- Academic performance: 40% weight
- Extracurricular activities: 30% weight
- Application materials: 30% weight

### File I/O Operations
- Save/load functionality using JSON format
- Error handling for file operations
- Graceful handling of missing files

### Scholarship Allocation
- Automatic allocation based on applicant rankings
- Configurable scholarship types and quantities
- Summary reporting of allocations

### Non-Database Operation
The system operates entirely in memory and uses file-based storage for persistence, meeting the requirement of not using external databases.

## Data Flow

1. **Input**: Applicant data provided through `add_applicant()` method
2. **Processing**: 
   - Individual scores calculated for academic performance, extracurricular activities, and application materials
   - Weighted viability score computed
3. **Storage**: Applicants stored in memory with computed scores
4. **Output**: 
   - Rankings generated
   - Scholarships allocated
   - Summary reports created
   - Data saved/loaded from files

## Error Handling

The system includes error handling for:
- File not found errors during loading
- JSON decoding errors
- Graceful degradation when files are missing or corrupted

## Example Usage

```python
# Create manager
manager = ScholarshipManager()

# Add applicants
applicant1 = manager.add_applicant(applicant_data)

# Allocate scholarships
manager.allocate_scholarships()

# Generate report
report = manager.generate_summary_report()
```