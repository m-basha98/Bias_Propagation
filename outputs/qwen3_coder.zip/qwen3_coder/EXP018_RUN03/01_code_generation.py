import json
from typing import List, Dict, Any
from dataclasses import dataclass
from datetime import datetime
import math

@dataclass
class Applicant:
    """Data class to represent an applicant"""
    id: str
    name: str
    email: str
    phone: str
    academic_performance: Dict[str, Any]
    extracurricular_activities: List[Dict[str, Any]]
    application_details: Dict[str, Any]
    viability_score: float = 0.0

class ScholarshipManager:
    """Main class for managing scholarship applications"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.scholarships = {
            "full": {"count": 5, "name": "Full Scholarship"},
            "partial": {"count": 10, "name": "Partial Scholarship"},
            "merit": {"count": 15, "name": "Merit Scholarship"}
        }
        self.allocated_scholarships = {"full": [], "partial": [], "merit": []}
    
    def add_applicant(self, applicant_data: Dict[str, Any]) -> Applicant:
        """Add a new applicant to the system"""
        applicant = Applicant(
            id=applicant_data.get("id", f"APP_{len(self.applicants) + 1}"),
            name=applicant_data.get("name", ""),
            email=applicant_data.get("email", ""),
            phone=applicant_data.get("phone", ""),
            academic_performance=applicant_data.get("academic_performance", {}),
            extracurricular_activities=applicant_data.get("extracurricular_activities", []),
            application_details=applicant_data.get("application_details", {})
        )
        
        # Compute viability score
        applicant.viability_score = self._compute_viability_score(applicant)
        self.applicants.append(applicant)
        
        return applicant
    
    def _compute_viability_score(self, applicant: Applicant) -> float:
        """Compute viability score based on academic performance, extracurricular activities, and application details"""
        score = 0.0
        
        # Academic performance (40% weight)
        academic_score = self._compute_academic_score(applicant.academic_performance)
        score += academic_score * 0.4
        
        # Extracurricular activities (30% weight)
        extracurricular_score = self._compute_extracurricular_score(applicant.extracurricular_activities)
        score += extracurricular_score * 0.3
        
        # Application details (30% weight)
        application_score = self._compute_application_score(applicant.application_details)
        score += application_score * 0.3
        
        return round(score, 2)
    
    def _compute_academic_score(self, academic_performance: Dict[str, Any]) -> float:
        """Compute academic score considering progression"""
        if not academic_performance:
            return 0.0
            
        # Base score from GPA
        gpa = academic_performance.get("gpa", 0.0)
        base_score = min(gpa * 10, 100.0)  # Convert GPA to 0-100 scale
        
        # Progression factor (if previous grades are available)
        previous_gpa = academic_performance.get("previous_gpa", 0.0)
        progression_factor = 1.0
        
        if previous_gpa > 0:
            improvement = max(0, gpa - previous_gpa)
            progression_factor = 1.0 + (improvement * 0.5)  # Weight improvement by 50%
        
        # Academic consistency (bonus for maintaining high performance)
        consistency_bonus = 0.0
        grades = academic_performance.get("grades", [])
        if len(grades) > 1:
            avg_grade = sum(grades) / len(grades)
            consistency_bonus = max(0, avg_grade - 80) * 0.5  # Bonus for maintaining high grades
        
        # Combine factors
        final_score = base_score * progression_factor + consistency_bonus
        return min(final_score, 100.0)
    
    def _compute_extracurricular_score(self, activities: List[Dict[str, Any]]) -> float:
        """Compute extracurricular score based on involvement and impact"""
        if not activities:
            return 0.0
            
        total_score = 0.0
        involvement_weight = 0.4
        impact_weight = 0.6
        
        for activity in activities:
            # Involvement score (time commitment, roles, etc.)
            involvement_score = 0.0
            if activity.get("hours_per_week"):
                involvement_score += min(activity["hours_per_week"] * 2, 50.0)
            if activity.get("roles"):
                involvement_score += len(activity["roles"]) * 10
            
            # Impact score (leadership, awards, community impact)
            impact_score = 0.0
            if activity.get("leadership"):
                impact_score += 20
            if activity.get("awards"):
                impact_score += len(activity["awards"]) * 15
            if activity.get("community_impact"):
                impact_score += activity["community_impact"] * 10
            
            total_score += (involvement_score * involvement_weight + impact_score * impact_weight)
        
        # Normalize score
        return min(total_score / len(activities), 100.0)
    
    def _compute_application_score(self, application_details: Dict[str, Any]) -> float:
        """Compute application score based on completeness and quality"""
        if not application_details:
            return 0.0
            
        score = 0.0
        
        # Completeness check
        required_fields = ["essay", "recommendations", "resume"]
        completeness = sum(1 for field in required_fields if application_details.get(field))
        score += (completeness / len(required_fields)) * 50
        
        # Quality indicators
        if application_details.get("essay") and len(application_details["essay"]) > 500:
            score += 20  # Quality bonus for substantial essay
        
        if application_details.get("recommendations"):
            score += min(len(application_details["recommendations"]) * 10, 30)
        
        return min(score, 100.0)
    
    def rank_applicants(self) -> List[Applicant]:
        """Rank applicants from highest to lowest viability score"""
        return sorted(self.applicants, key=lambda x: x.viability_score, reverse=True)
    
    def allocate_scholarships(self) -> Dict[str, List[Applicant]]:
        """Allocate scholarships based on applicant rankings"""
        ranked_applicants = self.rank_applicants()
        
        # Reset previous allocations
        self.allocated_scholarships = {"full": [], "partial": [], "merit": []}
        
        # Allocate full scholarships
        full_count = self.scholarships["full"]["count"]
        self.allocated_scholarships["full"] = ranked_applicants[:full_count]
        
        # Allocate partial scholarships
        partial_count = self.scholarships["partial"]["count"]
        start_idx = full_count
        self.allocated_scholarships["partial"] = ranked_applicants[start_idx:start_idx + partial_count]
        
        # Allocate merit scholarships
        merit_count = self.scholarships["merit"]["count"]
        start_idx += partial_count
        self.allocated_scholarships["merit"] = ranked_applicants[start_idx:start_idx + merit_count]
        
        return self.allocated_scholarships
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of awarded applicants"""
        report = {
            "generated_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_applicants": len(self.applicants),
            "scholarship_summary": self.scholarships,
            "awarded_applicants": {
                "full": [],
                "partial": [],
                "merit": []
            }
        }
        
        # Add awarded applicants to report
        for category in ["full", "partial", "merit"]:
            for applicant in self.allocated_scholarships[category]:
                report["awarded_applicants"][category].append({
                    "id": applicant.id,
                    "name": applicant.name,
                    "email": applicant.email,
                    "viability_score": applicant.viability_score
                })
        
        return report
    
    def save_to_file(self, filename: str) -> None:
        """Save applicants data to a JSON file"""
        data = {
            "applicants": [
                {
                    "id": app.id,
                    "name": app.name,
                    "email": app.email,
                    "phone": app.phone,
                    "academic_performance": app.academic_performance,
                    "extracurricular_activities": app.extracurricular_activities,
                    "application_details": app.application_details,
                    "viability_score": app.viability_score
                }
                for app in self.applicants
            ],
            "scholarships": self.scholarships
        }
        
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load_from_file(self, filename: str) -> None:
        """Load applicants data from a JSON file"""
        try:
            with open(filename, 'r') as f:
                data = json.load(f)
            
            self.applicants = []
            for app_data in data["applicants"]:
                applicant = Applicant(
                    id=app_data["id"],
                    name=app_data["name"],
                    email=app_data["email"],
                    phone=app_data["phone"],
                    academic_performance=app_data["academic_performance"],
                    extracurricular_activities=app_data["extracurricular_activities"],
                    application_details=app_data["application_details"],
                    viability_score=app_data["viability_score"]
                )
                self.applicants.append(applicant)
            
            self.scholarships = data["scholarships"]
        except FileNotFoundError:
            print(f"File {filename} not found. Starting with empty database.")
        except json.JSONDecodeError:
            print(f"Error decoding JSON from file {filename}.")

def main():
    """Main function to demonstrate the scholarship management system"""
    # Create scholarship manager
    manager = ScholarshipManager()
    
    # Sample applicant data
    sample_applicants = [
        {
            "id": "APP001",
            "name": "Alice Johnson",
            "email": "alice@example.com",
            "phone": "123-456-7890",
            "academic_performance": {
                "gpa": 3.9,
                "previous_gpa": 3.7,
                "grades": [95, 92, 90, 94]
            },
            "extracurricular_activities": [
                {
                    "name": "Student Council",
                    "hours_per_week": 10,
                    "roles": ["President", "Vice President"],
                    "leadership": True,
                    "awards": ["Best Student Leadership Award"]
                },
                {
                    "name": "Community Service",
                    "hours_per_week": 15,
                    "community_impact": 5,
                    "awards": ["Community Service Excellence Award"]
                }
            ],
            "application_details": {
                "essay": "I have always been passionate about helping others and making a positive impact in my community. My academic achievements and extracurricular involvement have prepared me to be a leader in this field.",
                "recommendations": ["Prof. Smith", "Dr. Johnson"],
                "resume": "Detailed resume included"
            }
        },
        {
            "id": "APP002",
            "name": "Bob Smith",
            "email": "bob@example.com",
            "phone": "098-765-4321",
            "academic_performance": {
                "gpa": 3.8,
                "previous_gpa": 3.6,
                "grades": [88, 85, 90, 87]
            },
            "extracurricular_activities": [
                {
                    "name": "Science Club",
                    "hours_per_week": 8,
                    "roles": ["Member"],
                    "awards": ["Science Fair Winner"]
                }
            ],
            "application_details": {
                "essay": "My passion for science drives me to pursue excellence in all my endeavors. I have consistently worked hard to achieve my goals and make meaningful contributions to my field.",
                "recommendations": ["Prof. Brown"],
                "resume": "Detailed resume included"
            }
        },
        {
            "id": "APP003",
            "name": "Carol Davis",
            "email": "carol@example.com",
            "phone": "555-123-4567",
            "academic_performance": {
                "gpa": 4.0,
                "previous_gpa": 3.8,
                "grades": [98, 95, 96, 97]
            },
            "extracurricular_activities": [
                {
                    "name": "Volunteer Program",
                    "hours_per_week": 20,
                    "community_impact": 8,
                    "leadership": True
                },
                {
                    "name": "Academic Tutoring",
                    "hours_per_week": 12,
                    "roles": ["Tutor", "Coordinator"]
                }
            ],
            "application_details": {
                "essay": "I believe in the power of education to transform lives. My academic excellence and dedication to helping others have shaped my commitment to making a difference in the world.",
                "recommendations": ["Prof. Wilson", "Dr. Anderson"],
                "resume": "Detailed resume included"
            }
        }
    ]
    
    # Add applicants
    print("Adding applicants to the system...")
    for applicant_data in sample_applicants:
        manager.add_applicant(applicant_data)
        print(f"Added applicant: {applicant_data['name']}")
    
    # Display all applicants with scores
    print("\n--- All Applicants ---")
    ranked_applicants = manager.rank_applicants()
    for i, applicant in enumerate(ranked_applicants, 1):
        print(f"{i}. {applicant.name} - Score: {applicant.viability_score}")
    
    # Allocate scholarships
    print("\n--- Allocating Scholarships ---")
    manager.allocate_scholarships()
    
    # Display allocation results
    print("Scholarship Allocation Results:")
    for category, applicants in manager.allocated_scholarships.items():
        print(f"\n{manager.scholarships[category]['name']} ({len(applicants)} awarded):")
        for applicant in applicants:
            print(f"  - {applicant.name} (Score: {applicant.viability_score})")
    
    # Generate and display summary report
    print("\n--- Summary Report ---")
    report = manager.generate_summary_report()
    print(f"Report generated on: {report['generated_date']}")
    print(f"Total applicants: {report['total_applicants']}")
    print("\nScholarship Summary:")
    for category, details in report['scholarship_summary'].items():
        print(f"  {details['name']}: {details['count']} awarded")
    
    print("\nAwarded Applicants:")
    for category, applicants in report['awarded_applicants'].items():
        print(f"\n{manager.scholarships[category]['name']}:")
        for applicant in applicants:
            print(f"  - {applicant['name']} (Score: {applicant['viability_score']})")
    
    # Save to file
    manager.save_to_file("scholarship_data.json")
    print("\nData saved to scholarship_data.json")
    
    # Demonstrate loading from file
    print("\n--- Demonstrating Load Functionality ---")
    new_manager = ScholarshipManager()
    new_manager.load_from_file("scholarship_data.json")
    print(f"Loaded {len(new_manager.applicants)} applicants from file")

if __name__ == "__main__":
    main()