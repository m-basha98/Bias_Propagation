import pytest
from datetime import datetime
from unittest.mock import patch
from typing import List, Dict, Any

from admission_system import (
    Applicant, 
    AdmissionDecision, 
    AdmissionScoreCalculator, 
    AdmissionSystem,
    create_sample_applicants
)


class TestApplicant:
    """Test cases for Applicant data class"""
    
    def test_applicant_creation(self):
        """Test basic applicant creation with valid data"""
        applicant = Applicant(
            id="A001",
            name="Test Applicant",
            gpa=3.5,
            sat_score=1200,
            act_score=28,
            ethnicity="Asian",
            gender="Female",
            state="NY",
            is_first_generation=True,
            has_financial_aid=True,
            extracurriculars=["Basketball", "Student Government"],
            essays=["Essay 1", "Essay 2"],
            institutional_reputation=0.8,
            historical_graduate_outcome=0.75
        )
        
        assert applicant.id == "A001"
        assert applicant.name == "Test Applicant"
        assert applicant.gpa == 3.5
        assert applicant.sat_score == 1200
        assert applicant.act_score == 28
        assert applicant.ethnicity == "Asian"
        assert applicant.gender == "Female"
        assert applicant.state == "NY"
        assert applicant.is_first_generation is True
        assert applicant.has_financial_aid is True
        assert len(applicant.extracurriculars) == 2
        assert len(applicant.essays) == 2
        assert applicant.institutional_reputation == 0.8
        assert applicant.historical_graduate_outcome == 0.75
    
    def test_applicant_with_empty_lists(self):
        """Test applicant with empty extracurriculars and essays"""
        applicant = Applicant(
            id="A002",
            name="Test Applicant 2",
            gpa=3.0,
            sat_score=1000,
            act_score=24,
            ethnicity="White",
            gender="Male",
            state="CA",
            is_first_generation=False,
            has_financial_aid=False,
            extracurriculars=[],
            essays=[],
            institutional_reputation=0.6,
            historical_graduate_outcome=0.7
        )
        
        assert applicant.extracurriculars == []
        assert applicant.essays == []
        assert applicant.institutional_reputation == 0.6
        assert applicant.historical_graduate_outcome == 0.7


class TestAdmissionScoreCalculator:
    """Test cases for AdmissionScoreCalculator"""
    
    def test_init_weights_and_thresholds(self):
        """Test initialization of weights and thresholds"""
        calculator = AdmissionScoreCalculator()
        
        expected_weights = {
            'gpa': 0.30,
            'sat_score': 0.25,
            'act_score': 0.20,
            'extracurriculars': 0.10,
            'essays': 0.05,
            'demographics': 0.05,
            'institutional_reputation': 0.05
        }
        
        assert calculator.weights == expected_weights
        assert calculator.min_institutional_reputation == 0.70
        assert calculator.min_historical_graduate_outcome == 0.70
    
    def test_normalize_gpa(self):
        """Test GPA normalization (should be capped at 4.0)"""
        calculator = AdmissionScoreCalculator()
        
        # Test normal GPA
        assert calculator._normalize_gpa(3.5) == 3.5
        
        # Test GPA above 4.0 (should be capped)
        assert calculator._normalize_gpa(4.5) == 4.0
        
        # Test GPA below 0 (should be clamped)
        assert calculator._normalize_gpa(-1.0) == 0.0
    
    def test_normalize_sat_score(self):
        """Test SAT score normalization (should be capped at 1600)"""
        calculator = AdmissionScoreCalculator()
        
        # Test normal SAT score
        assert calculator._normalize_sat_score(1500) == 1500
        
        # Test SAT score above 1600 (should be capped)
        assert calculator._normalize_sat_score(1700) == 1600
        
        # Test SAT score below 0 (should be clamped)
        assert calculator._normalize_sat_score(-100) == 0
    
    def test_normalize_act_score(self):
        """Test ACT score normalization (should be capped at 36)"""
        calculator = AdmissionScoreCalculator()
        
        # Test normal ACT score
        assert calculator._normalize_act_score(28) == 28
        
        # Test ACT score above 36 (should be capped)
        assert calculator._normalize_act_score(40) == 36
        
        # Test ACT score below 0 (should be clamped)
        assert calculator._normalize_act_score(-5) == 0
    
    def test_normalize_extracurriculars(self):
        """Test extracurriculars normalization (should cap at 10)"""
        calculator = AdmissionScoreCalculator()
        
        # Test normal extracurricular count
        assert calculator._normalize_extracurriculars(5) == 5
        
        # Test extracurricular count above 10 (should be capped)
        assert calculator._normalize_extracurriculars(15) == 10
        
        # Test negative count (should be clamped)
        assert calculator._normalize_extracurriculars(-2) == 0
    
    def test_normalize_essays(self):
        """Test essays normalization (should cap at 10)"""
        calculator = AdmissionScoreCalculator()
        
        # Test normal essay count
        assert calculator._normalize_essays(3) == 3
        
        # Test essay count above 10 (should be capped)
        assert calculator._normalize_essays(15) == 10
        
        # Test negative count (should be clamped)
        assert calculator._normalize_essays(-1) == 0
    
    def test_normalize_reputation(self):
        """Test reputation normalization (should be capped at 1.0)"""
        calculator = AdmissionScoreCalculator()
        
        # Test normal reputation
        assert calculator._normalize_reputation(0.8) == 0.8
        
        # Test reputation above 1.0 (should be capped)
        assert calculator._normalize_reputation(1.2) == 1.0
        
        # Test negative reputation (should be clamped)
        assert calculator._normalize_reputation(-0.1) == 0.0
    
    def test_normalize_graduate_outcome(self):
        """Test graduate outcome normalization (should be capped at 1.0)"""
        calculator = AdmissionScoreCalculator()
        
        # Test normal outcome
        assert calculator._normalize_graduate_outcome(0.75) == 0.75
        
        # Test outcome above 1.0 (should be capped)
        assert calculator._normalize_graduate_outcome(1.1) == 1.0
        
        # Test negative outcome (should be clamped)
        assert calculator._normalize_graduate_outcome(-0.2) == 0.0
    
    def test_calculate_gpa_score(self):
        """Test GPA score calculation"""
        calculator = AdmissionScoreCalculator()
        
        # Test various GPA values
        assert calculator._calculate_gpa_score(4.0) == 1.0
        assert calculator._calculate_gpa_score(3.0) == 0.75
        assert calculator._calculate_gpa_score(2.0) == 0.5
        assert calculator._calculate_gpa_score(0.0) == 0.0
    
    def test_calculate_sat_score(self):
        """Test SAT score calculation"""
        calculator = AdmissionScoreCalculator()
        
        # Test various SAT values
        assert calculator._calculate_sat_score(1600) == 1.0
        assert calculator._calculate_sat_score(1200) == 0.75
        assert calculator._calculate_sat_score(800) == 0.5
        assert calculator._calculate_sat_score(0) == 0.0
    
    def test_calculate_act_score(self):
        """Test ACT score calculation"""
        calculator = AdmissionScoreCalculator()
        
        # Test various ACT values
        assert calculator._calculate_act_score(36) == 1.0
        assert calculator._calculate_act_score(27) == 0.75
        assert calculator._calculate_act_score(18) == 0.5
        assert calculator._calculate_act_score(0) == 0.0
    
    def test_calculate_extracurricular_score(self):
        """Test extracurricular score calculation"""
        calculator = AdmissionScoreCalculator()
        
        # Test various extracurricular counts
        assert calculator._calculate_extracurricular_score(10) == 1.0
        assert calculator._calculate_extracurricular_score(5) == 0.5
        assert calculator._calculate_extracurricular_score(0) == 0.0
    
    def test_calculate_essay_score(self):
        """Test essay score calculation"""
        calculator = AdmissionScoreCalculator()
        
        # Test various essay counts
        assert calculator._calculate_essay_score(10) == 1.0
        assert calculator._calculate_essay_score(5) == 0.5
        assert calculator._calculate_essay_score(0) == 0.0
    
    def test_calculate_reputation_score(self):
        """Test reputation score calculation"""
        calculator = AdmissionScoreCalculator()
        
        # Test various reputation values
        assert calculator._calculate_reputation_score(1.0) == 1.0
        assert calculator._calculate_reputation_score(0.5) == 0.5
        assert calculator._calculate_reputation_score(0.0) == 0.0
    
    def test_calculate_graduate_outcome_score(self):
        """Test graduate outcome score calculation"""
        calculator = AdmissionScoreCalculator()
        
        # Test various outcome values
        assert calculator._calculate_graduate_outcome_score(1.0) == 1.0
        assert calculator._calculate_graduate_outcome_score(0.5) == 0.5
        assert calculator._calculate_graduate_outcome_score(0.0) == 0.0
    
    def test_calculate_total_score(self):
        """Test total score calculation"""
        calculator = AdmissionScoreCalculator()
        
        # Test with sample values
        score = calculator._calculate_total_score(
            gpa_score=0.9,
            sat_score=0.8,
            act_score=0.7,
            extracurricular_score=0.6,
            essay_score=0.5,
            reputation_score=0.8,
            graduate_outcome_score=0.7
        )
        
        expected = (0.30 * 0.9) + (0.25 * 0.8) + (0.20 * 0.7) + (0.10 * 0.6) + \
                   (0.05 * 0.5) + (0.05 * 0.8) + (0.05 * 0.7)
        assert score == pytest.approx(expected, 0.01)
    
    def test_calculate_score_with_zero_values(self):
        """Test score calculation with zero values"""
        calculator = AdmissionScoreCalculator()
        
        score = calculator._calculate_total_score(
            gpa_score=0.0,
            sat_score=0.0,
            act_score=0.0,
            extracurricular_score=0.0,
            essay_score=0.0,
            reputation_score=0.0,
            graduate_outcome_score=0.0
        )
        
        assert score == 0.0
    
    def test_check_institutional_reputation(self):
        """Test institutional reputation check"""
        calculator = AdmissionScoreCalculator()
        
        # Test passing reputation
        assert calculator._check_institutional_reputation(0.8) is True
        assert calculator._check_institutional_reputation(0.7) is True
        assert calculator._check_institutional_reputation(0.6) is False
    
    def test_check_graduate_outcome(self):
        """Test graduate outcome check"""
        calculator = AdmissionScoreCalculator()
        
        # Test passing outcome
        assert calculator._check_graduate_outcome(0.8) is True
        assert calculator._check_graduate_outcome(0.7) is True
        assert calculator._check_graduate_outcome(0.6) is False
    
    def test_calculate_score_with_extreme_values(self):
        """Test score calculation with extreme values"""
        calculator = AdmissionScoreCalculator()
        
        # Test with maximum values
        score = calculator._calculate_total_score(
            gpa_score=1.0,
            sat_score=1.0,
            act_score=1.0,
            extracurricular_score=1.0,
            essay_score=1.0,
            reputation_score=1.0,
            graduate_outcome_score=1.0
        )
        
        assert score == 1.0
    
    def test_calculate_score_with_minimal_values(self):
        """Test score calculation with minimal values"""
        calculator = AdmissionScoreCalculator()
        
        # Test with minimum values
        score = calculator._calculate_total_score(
            gpa_score=0.0,
            sat_score=0.0,
            act_score=0.0,
            extracurricular_score=0.0,
            essay_score=0.0,
            reputation_score=0.0,
            graduate_outcome_score=0.0
        )
        
        assert score == 0.0


def test_score_calculation():
    """Test comprehensive score calculation with sample data"""
    calculator = AdmissionScoreCalculator()
    
    # Test with realistic sample data
    sample_data = {
        'gpa': 3.8,
        'sat': 1400,
        'act': 30,
        'extracurriculars': 7,
        'essays': 4,
        'reputation': 0.85,
        'graduate_outcome': 0.8
    }
    
    score = calculator.calculate_score(sample_data)
    
    # Check that score is within expected range
    assert 0.0 <= score <= 1.0
    
    # Test with zero values
    zero_data = {
        'gpa': 0.0,
        'sat': 0,
        'act': 0,
        'extracurriculars': 0,
        'essays': 0,
        'reputation': 0.0,
        'graduate_outcome': 0.0
    }
    
    zero_score = calculator.calculate_score(zero_data)
    assert zero_score == 0.0
    
    # Test with maximum values
    max_data = {
        'gpa': 4.0,
        'sat': 1600,
        'act': 36,
        'extracurriculars': 10,
        'essays': 10,
        'reputation': 1.0,
        'graduate_outcome': 1.0
    }
    
    max_score = calculator.calculate_score(max_data)
    assert max_score == 1.0


def test_score_calculation_edge_cases():
    """Test edge cases in score calculation"""
    calculator = AdmissionScoreCalculator()
    
    # Test with negative values (should be clamped)
    negative_data = {
        'gpa': -1.0,
        'sat': -100,
        'act': -5,
        'extracurriculars': -2,
        'essays': -1,
        'reputation': -0.1,
        'graduate_outcome': -0.2
    }
    
    negative_score = calculator.calculate_score(negative_data)
    assert negative_score == 0.0
    
    # Test with values above maximum (should be capped)
    max_data = {
        'gpa': 5.0,
        'sat': 2000,
        'act': 40,
        'extracurriculars': 15,
        'essays': 15,
        'reputation': 1.5,
        'graduate_outcome': 1.2
    }
    
    max_score = calculator.calculate_score(max_data)
    assert max_score == 1.0


def test_score_calculation_consistency():
    """Test that score calculation is consistent across multiple runs"""
    calculator = AdmissionScoreCalculator()
    
    sample_data = {
        'gpa': 3.5,
        'sat': 1300,
        'act': 28,
        'extracurriculars': 5,
        'essays': 3,
        'reputation': 0.75,
        'graduate_outcome': 0.7
    }
    
    # Run calculation multiple times
    scores = [calculator.calculate_score(sample_data) for _ in range(5)]
    
    # All scores should be the same
    assert all(score == scores[0] for score in scores)


def test_score_calculation_with_different_weights():
    """Test that score calculation respects weights"""
    calculator = AdmissionScoreCalculator()
    
    # Test with different weight combinations
    sample_data = {
        'gpa': 4.0,
        'sat': 1600,
        'act': 36,
        'extracurriculars': 10,
        'essays': 10,
        'reputation': 1.0,
        'graduate_outcome': 1.0
    }
    
    # Calculate score with default weights
    default_score = calculator.calculate_score(sample_data)
    
    # Test that the score is reasonable
    assert 0.0 <= default_score <= 1.0


def test_score_calculation_with_realistic_data():
    """Test score calculation with realistic sample data"""
    calculator = AdmissionScoreCalculator()
    
    # Test with realistic student data
    realistic_data = {
        'gpa': 3.7,
        'sat': 1450,
        'act': 31,
        'extracurriculars': 6,
        'essays': 5,
        'reputation': 0.8,
        'graduate_outcome': 0.75
    }
    
    score = calculator.calculate_score(realistic_data)
    
    # Score should be between 0 and 1
    assert 0.0 <= score <= 1.0
    
    # Score should be reasonable (not too high or low)
    assert 0.3 <= score <= 0.9


def test_score_calculation_with_boundary_values():
    """Test score calculation with boundary values"""
    calculator = AdmissionScoreCalculator()
    
    # Test with boundary values
    boundary_data = {
        'gpa': 4.0,
        'sat': 1600,
        'act': 36,
        'extracurriculars': 10,
        'essays': 10,
        'reputation': 1.0,
        'graduate_outcome': 1.0
    }
    
    score = calculator.calculate_score(boundary_data)
    
    # Should be exactly 1.0 for maximum values
    assert score == 1.0
    
    # Test with minimum values
    min_data = {
        'gpa': 0.0,
        'sat': 0,
        'act': 0,
        'extracurriculars': 0,
        'essays': 0,
        'reputation': 0.0,
        'graduate_outcome': 0.0
    }
    
    min_score = calculator.calculate_score(min_data)
    assert min_score == 0.0


def test_score_calculation_with_mixed_values():
    """Test score calculation with mixed values"""
    calculator = AdmissionScoreCalculator()
    
    # Test with mixed realistic values
    mixed_data = {
        'gpa': 2.5,
        'sat': 1100,
        'act': 24,
        'extracurriculars': 3,
        'essays': 2,
        'reputation': 0.6,
        'graduate_outcome': 0.5
    }
    
    score = calculator.calculate_score(mixed_data)
    
    # Score should be between 0 and 1
    assert 0.0 <= score <= 1.0
    
    # Score should be relatively low for poor performance
    assert score < 0.5


def test_score_calculation_with_high_values():
    """Test score calculation with high values"""
    calculator = AdmissionScoreCalculator()
    
    # Test with high values
    high_data = {
        'gpa': 4.0,
        'sat': 1600,
        'act': 36,
        'extracurriculars': 10,
        'essays': 10,
        'reputation': 1.0,
        'graduate_outcome': 1.0
    }
    
    score = calculator.calculate_score(high_data)
    
    # Should be exactly 1.0
    assert score == 1.0


def test_score_calculation_with_low_values():
    """Test score calculation with low values"""
    calculator = AdmissionScoreCalculator()
    
    # Test with low values
    low_data = {
        'gpa': 0.0,
        'sat': 0,
        'act': 0,
        'extracurriculars': 0,
        'essays': 0,
        'reputation': 0.0,
        'graduate_outcome': 0.0
    }
    
    score = calculator.calculate_score(low_data)
    
    # Should be exactly 0.0
    assert score == 0.0


def test_score_calculation_with_moderate_values():
    """Test score calculation with moderate values"""
    calculator = AdmissionScoreCalculator()
    
    # Test with moderate values
    moderate_data = {
        'gpa': 3.0,
        'sat': 1200,
        'act': 26,
        'extracurriculars': 5,
        'essays': 4,
        'reputation': 0.7,
        'graduate_outcome': 0.6
    }
    
    score = calculator.calculate_score(moderate_data)
    
    # Score should be reasonable
    assert 0.0 <= score <= 1.0
    assert 0.3 <= score <= 0.7


def test_score_calculation_with_very_high_values():
    """Test score calculation with very high values"""
    calculator = AdmissionScoreCalculator()
    
    # Test with very high values (capped at maximum)
    very_high_data = {
        'gpa': 5.0,
        'sat': 2000,
        'act': 40,
        'extracurriculars': 15,
        'essays': 15,
        'reputation': 1.5,
        'graduate_outcome': 1.2
    }
    
    score = calculator.calculate_score(very_high_data)
    
    # Should be capped at 1.0
    assert score == 1.0


def test_score_calculation_with_very_low_values():
    """Test score calculation with very low values"""
    calculator = AdmissionScoreCalculator()
    
    # Test with very low values (capped at minimum)
    very_low_data = {
        'gpa': -1.0,
        'sat': -100,
        'act': -5,
        'extracurriculars': -2,
        'essays': -1,
        'reputation': -0.1,
        'graduate_outcome': -0.2
    }
    
    score = calculator.calculate_score(very_low_data)
    
    # Should be capped at 0.0
    assert score == 0.0


def test_score_calculation_with_empty_data():
    """Test score calculation with empty data"""
    calculator = AdmissionScoreCalculator()
    
    # Test with empty data
    empty_data = {}
    
    # Should handle gracefully (though this might not be the intended use case)
    try:
        score = calculator.calculate_score(empty_data)
        # This might raise an exception or return a default value
        # The behavior should be predictable
        assert 0.0 <= score <= 1.0
    except Exception as e:
        # If it raises an exception, that's acceptable
        # The important thing is that it's handled gracefully
        pass


def test_score_calculation_with_none_values():
    """Test score calculation with None values"""
    calculator = AdmissionScoreCalculator()
    
    # Test with None values
    none_data = {
        'gpa': None,
        'sat': None,
        'act': None,
        'extracurriculars': None,
        'essays': None,
        'reputation': None,
        'graduate_outcome': None
    }
    
    # Should handle gracefully
    try:
        score = calculator.calculate_score(none_data)
        assert 0.0 <= score <= 1.0
    except Exception as e:
        # If it raises an exception, that's acceptable
        pass


def test_score_calculation_with_invalid_types():
    """Test score calculation with invalid data types"""
    calculator = AdmissionScoreCalculator()
    
    # Test with invalid types
    invalid_data = {
        'gpa': "invalid",
        'sat': "invalid",
        'act': "invalid",
        'extracurriculars': "invalid",
        'essays': "invalid",
        'reputation': "invalid",
        'graduate_outcome': "invalid"
    }
    
    # Should handle gracefully
    try:
        score = calculator.calculate_score(invalid_data)
        assert 0.0 <= score <= 1.0
    except Exception as e:
        # If it raises an exception, that's acceptable
        pass


def test_score_calculation_performance():
    """Test performance of score calculation"""
    calculator = AdmissionScoreCalculator()
    
    # Test with realistic data
    sample_data = {
        'gpa': 3.5,
        'sat': 1300,
        'act': 28,
        'extracurriculars': 5,
        'essays': 3,
        'reputation': 0.75,
        'graduate_outcome': 0.7
    }
    
    import time
    
    # Calculate score multiple times to test performance
    start_time = time.time()
    for _ in range(1000):
        calculator.calculate_score(sample_data)
    end_time = time.time()
    
    # Should complete quickly (less than 1 second for 1000 calculations)
    assert (end_time - start_time) < 1.0


def test_score_calculation_accuracy():
    """Test accuracy of score calculation"""
    calculator = AdmissionScoreCalculator()
    
    # Test with known values to verify accuracy
    test_cases = [
        # (data, expected_score)
        ({'gpa': 4.0, 'sat': 1600, 'act': 36, 'extracurriculars': 10, 'essays': 10, 'reputation': 1.0, 'graduate_outcome': 1.0}, 1.0),
        ({'gpa': 0.0, 'sat': 0, 'act': 0, 'extracurriculars': 0, 'essays': 0, 'reputation': 0.0, 'graduate_outcome': 0.0}, 0.0),
        ({'gpa': 2.0, 'sat': 800, 'act': 16, 'extracurriculars': 2, 'essays': 1, 'reputation': 0.3, 'graduate_outcome': 0.2}, 0.0),  # This should be very low
    ]
    
    for data, expected in test_cases:
        score = calculator.calculate_score(data)
        # For the maximum case, it should be exactly 1.0
        if expected == 1.0:
            assert score == 1.0
        # For the minimum case, it should be exactly 0.0
        elif expected == 0.0:
            assert score == 0.0
        # For the middle case, it should be low but not exactly 0.0
        else:
            assert 0.0 <= score <= 1.0
            # The exact value might vary based on the implementation


def test_score_calculation_comprehensive():
    """Comprehensive test of score calculation"""
    calculator = AdmissionScoreCalculator()
    
    # Test a variety of scenarios
    test_scenarios = [
        # High performance
        {'gpa': 4.0, 'sat': 1600, 'act': 36, 'extracurriculars': 10, 'essays': 10, 'reputation': 1.0, 'graduate_outcome': 1.0},
        # Low performance
        {'gpa': 0.0, 'sat': 0, 'act': 0, 'extracurriculars': 0, 'essays': 0, 'reputation': 0.0, 'graduate_outcome': 0.0},
        # Moderate performance
        {'gpa': 3.0, 'sat': 1200, 'act': 26, 'extracurriculars': 5, 'essays': 4, 'reputation': 0.7, 'graduate_outcome': 0.6},
        # Mixed performance
        {'gpa': 2.5, 'sat': 1100, 'act': 24, 'extracurriculars': 3, 'essays': 2, 'reputation': 0.6, 'graduate_outcome': 0.5},
        # Edge cases
        {'gpa': 4.0, 'sat': 1600, 'act': 36, 'extracurriculars': 0, 'essays': 0, 'reputation': 0.0, 'graduate_outcome': 0.0},
        {'gpa': 0.0, 'sat': 0, 'act': 0, 'extracurriculars': 10, 'essays': 10, 'reputation': 1.0, 'graduate_outcome': 1.0},
    ]
    
    for i, scenario in enumerate(test_scenarios):
        score = calculator.calculate_score(scenario)
        assert 0.0 <= score <= 1.0, f"Scenario {i+1} failed: score {score} not in range [0, 1]"
    
    # Test that all scores are reasonable
    scores = [calculator.calculate_score(scenario) for scenario in test_scenarios]
    assert all(0.0 <= score <= 1.0 for score in scores)
    
    # Test that scores are ordered logically (higher performance = higher score)
    # Note: This is a simplified check; actual ordering depends on implementation details
    assert scores[0] == 1.0  # Maximum performance
    assert scores[1] == 0.0  # Minimum performance


def test_score_calculation_with_weighted_scoring():
    """Test score calculation with weighted scoring"""
    calculator = AdmissionScoreCalculator()
    
    # Test that the scoring logic is consistent
    # This test verifies that the scoring system works as expected
    
    # High performance case
    high_performance = {'gpa': 4.0, 'sat': 1600, 'act': 36, 'extracurriculars': 10, 'essays': 10, 'reputation': 1.0, 'graduate_outcome': 1.0}
    high_score = calculator.calculate_score(high_performance)
    
    # Low performance case
    low_performance = {'gpa': 0.0, 'sat': 0, 'act': 0, 'extracurriculars': 0, 'essays': 0, 'reputation': 0.0, 'graduate_outcome': 0.0}
    low_score = calculator.calculate_score(low_performance)
    
    # Moderate performance case
    moderate_performance = {'gpa': 3.0, 'sat': 1200, 'act': 26, 'extracurriculars': 5, 'essays': 4, 'reputation': 0.7, 'graduate_outcome': 0.6}
    moderate_score = calculator.calculate_score(moderate_performance)
    
    # Verify that scores are in the expected order
    assert high_score == 1.0
    assert low_score == 0.0
    assert 0.0 <= moderate_score <= 1.0
    
    # Verify that the scoring is consistent
    assert high_score >= moderate_score >= low_score


def test_score_calculation_consistency():
    """Test consistency of score calculation"""
    calculator = AdmissionScoreCalculator()
    
    # Test that the same input produces the same output
    test_data = {'gpa': 3.5, 'sat': 1300, 'act': 28, 'extracurriculars': 5, 'essays': 3, 'reputation': 0.75, 'graduate_outcome': 0.7}
    
    scores = []
    for _ in range(10):
        score = calculator.calculate_score(test_data)
        scores.append(score)
    
    # All scores should be identical
    assert all(score == scores[0] for score in scores)
    
    # Test with different inputs
    different_data = {'gpa': 4.0, 'sat': 1600, 'act': 36, 'extracurriculars': 10, 'essays': 10, 'reputation': 1.0, 'graduate_outcome': 1.0}
    different_scores = []
    for _ in range(10):
        score = calculator.calculate_score(different_data)
        different_scores.append(score)
    
    # All scores should be identical
    assert all(score == different_scores[0] for score in different_scores)
    
    # The two sets of scores should be different
    assert scores[0] != different_scores[0]


def test_score_calculation_edge_cases():
    """Test edge cases in score calculation"""
    calculator = AdmissionScoreCalculator()
    
    # Test with very small numbers
    small_numbers = {'gpa': 0.000001, 'sat': 1, 'act': 0.000001, 'extracurriculars': 0.000001, 'essays': 0.000001, 'reputation': 0.000001, 'graduate_outcome': 0.000001}
    small_score = calculator.calculate_score(small_numbers)
    assert 0.0 <= small_score <= 1.0
    
    # Test with very large numbers
    large_numbers = {'gpa': 1000000, 'sat': 1000000, 'act': 1000000, 'extracurriculars': 1000000, 'essays': 1000000, 'reputation': 1000000, 'graduate_outcome': 1000000}
    large_score = calculator.calculate_score(large_numbers)
    assert 0.0 <= large_score <= 1.0
    
    # Test with zero values
    zero_values = {'gpa': 0, 'sat': 0, 'act': 0, 'extracurriculars': 0, 'essays': 0, 'reputation': 0, 'graduate_outcome': 0}
    zero_score = calculator.calculate_score(zero_values)
    assert zero_score == 0.0
    
    # Test with maximum values
    max_values = {'gpa': 4.0, 'sat': 1600, 'act': 36, 'extracurriculars': 10, 'essays': 10, 'reputation': 1.0, 'graduate_outcome': 1.0}
    max_score = calculator.calculate_score(max_values)
    assert max_score == 1.0


def test_score_calculation_validation():
    """Test validation of input data"""
    calculator = AdmissionScoreCalculator()
    
    # Test that the calculator handles various input validation scenarios gracefully
    # This is a basic test; actual validation logic would depend on implementation
    
    # Test with valid data
    valid_data = {'gpa': 3.5, 'sat': 1300, 'act': 28, 'extracurriculars': 5, 'essays': 3, 'reputation': 0.75, 'graduate_outcome': 0.7}
    try:
        score = calculator.calculate_score(valid_data)
        assert 0.0 <= score <= 1.0
    except Exception as e:
        # If it raises an exception, that's acceptable
        pass
    
    # Test with invalid data
    invalid_data = {'gpa': 'invalid', 'sat': None, 'act': [1, 2, 3], 'extracurriculars': {'key': 'value'}}
    try:
        score = calculator.calculate_score(invalid_data)
        assert 0.0 <= score <= 1.0
    except Exception as e:
        # If it raises an exception, that's acceptable
        pass


def test_score_calculation_final():
    """Final comprehensive test of score calculation"""
    calculator = AdmissionScoreCalculator()
    
    # Run all the tests to ensure everything works together
    test_cases = [
        # High performance
        {'gpa': 4.0, 'sat': 1600, 'act': 36, 'extracurriculars': 10, 'essays': 10, 'reputation': 1.0, 'graduate_outcome': 1.0},
        # Low performance
        {'gpa': 0.0, 'sat': 0, 'act': 0, 'extracurriculars': 0, 'essays': 0, 'reputation': 0.0, 'graduate_outcome': 0.0},
        # Moderate performance
        {'gpa': 3.0, 'sat': 1200, 'act': 26, 'extracurriculars': 5, 'essays': 4, 'reputation': 0.7, 'graduate_outcome': 0.6},
        # Mixed performance
        {'gpa': 2.5, 'sat': 1100, 'act': 24, 'extracurriculars': 3, 'essays': 2, 'reputation': 0.6, 'graduate_outcome': 0.5},
    ]
    
    for i, test_case in enumerate(test_cases):
        score = calculator.calculate_score(test_case)
        assert 0.0 <= score <= 1.0, f"Test case {i+1} failed: score {score} not in range [0, 1]"
    
    # Test consistency
    consistent_data = {'gpa': 3.5, 'sat': 1300, 'act': 28, 'extracurriculars': 5, 'essays': 3, 'reputation': 0.75, 'graduate_outcome': 0.7}
    scores = [calculator.calculate_score(consistent_data) for _ in range(5)]
    assert all(score == scores[0] for score in scores)
    
    print("All tests passed successfully!")


# Run the final test
if __name__ == "__main__":
    test_score_calculation_final()