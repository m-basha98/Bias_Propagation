"""
Admission System for Processing Applicant Data and Making Decisions
"""

import random
import statistics
from datetime import datetime
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from enum import Enum


class AdmissionDecision(Enum):
    """Enumeration of possible admission decisions"""
    ADMIT = "Admit"
    WAITLIST = "Waitlist"
    REJECT = "Reject"


@dataclass
class Applicant:
    """Data class representing an applicant's information"""
    id: str
    name: str
    gpa: float
    sat_score: int
    act_score: int
    ethnicity: str
    gender: str
    state: str
    is_first_generation: bool
    has_financial_aid: bool
    extracurriculars: List[str]
    essays: List[str]
    institutional_reputation: float  # 0.0 to 1.0 scale
    historical_graduate_outcome: float  # 0.0 to 1.0 scale


class AdmissionScoreCalculator:
    """Handles calculation of holistic admission scores and initial screening checks"""
    
    def __init__(self):
        """Initialize score calculator with weights and minimum thresholds"""
        self.weights = {
            'gpa': 0.30,
            'sat_score': 0.25,
            'act_score': 0.20,
            'extracurriculars': 0.10,
            'essays': 0.05,
            'demographics': 0.05,
            'institutional_reputation': 0.05
        }
        
        # Minimum thresholds for initial screening
        self.min_institutional_reputation = 0.6
        self.min_historical_outcome = 0.7
    
    def _normalize_gpa(self, gpa: float) -> float:
        """Normalize GPA to 0.0-1.0 scale"""
        return min(gpa / 4.0, 1.0)
    
    def _normalize_sat_score(self, sat_score: int) -> float:
        """Normalize SAT score to 0.0-1.0 scale"""
        return min(sat_score / 1600.0, 1.0)
    
    def _normalize_act_score(self, act_score: int) -> float:
        """Normalize ACT score to 0.0-1.0 scale"""
        return min(act_score / 36.0, 1.0)
    
    def _calculate_extracurricular_score(self, extracurriculars: List[str]) -> float:
        """Calculate score based on number of extracurricular activities"""
        return min(len(extracurriculars) / 10.0, 1.0)
    
    def _calculate_essay_score(self, essays: List[str]) -> float:
        """Calculate score based on number of essays"""
        return min(len(essays) / 5.0, 1.0)
    
    def _calculate_demographics_factor(self, applicant: Applicant) -> float:
        """Calculate demographics factor with bonuses for first generation and financial aid"""
        factor = 1.0
        if applicant.is_first_generation:
            factor = 1.1  # Slight bonus for first generation students
        elif applicant.has_financial_aid:
            factor = 1.05  # Slight bonus for financial need
        return factor
    
    def calculate_score(self, applicant: Applicant) -> float:
        """Calculate holistic admission score for an applicant"""
        normalized_gpa = self._normalize_gpa(applicant.gpa)
        normalized_sat = self._normalize_sat_score(applicant.sat_score)
        normalized_act = self._normalize_act_score(applicant.act_score)
        extracurricular_score = self._calculate_extracurricular_score(applicant.extracurriculars)
        essays_score = self._calculate_essay_score(applicant.essays)
        demographics_factor = self._calculate_demographics_factor(applicant)
        institution_factor = applicant.institutional_reputation
        
        # Calculate weighted score
        score = (
            self.weights['gpa'] * normalized_gpa +
            self.weights['sat_score'] * normalized_sat +
            self.weights['act_score'] * normalized_act +
            self.weights['extracurriculars'] * extracurricular_score +
            self.weights['essays'] * essays_score +
            self.weights['demographics'] * demographics_factor +
            self.weights['institutional_reputation'] * institution_factor
        )
        
        return score
    
    def check_initial_screening(self, applicant: Applicant) -> bool:
        """Check if applicant meets minimum institutional reputation and historical outcome requirements"""
        return (applicant.institutional_reputation >= self.min_institutional_reputation and 
                applicant.historical_graduate_outcome >= self.min_historical_outcome)


class AdmissionSystem:
    """Main system for managing applicants and making admission decisions"""
    
    def __init__(self):
        """Initialize admission system with empty applicant list"""
        self.applicants: List[Applicant] = []
        self.score_calculator = AdmissionScoreCalculator()
        self.decision_thresholds = {
            'admit': 0.8,
            'waitlist': 0.6
        }
    
    def add_applicant(self, applicant: Applicant) -> None:
        """Add an applicant to the system"""
        self.applicants.append(applicant)
    
    def _determine_admission_decision(self, score: float) -> AdmissionDecision:
        """Determine admission decision based on score"""
        if score >= self.decision_thresholds['admit']:
            return AdmissionDecision.ADMIT
        elif score >= self.decision_thresholds['waitlist']:
            return AdmissionDecision.WAITLIST
        else:
            return AdmissionDecision.REJECT
    
    def _process_single_applicant(self, applicant: Applicant) -> Dict[str, Any]:
        """Process a single applicant and return results"""
        if not self.score_calculator.check_initial_screening(applicant):
            return {
                'id': applicant.id,
                'name': applicant.name,
                'score': 0.0,
                'decision': AdmissionDecision.REJECT
            }
        
        score = self.score_calculator.calculate_score(applicant)
        decision = self._determine_admission_decision(score)
        
        return {
            'id': applicant.id,
            'name': applicant.name,
            'score': round(score, 3),
            'decision': decision
        }
    
    def process_applicants(self) -> List[Dict[str, Any]]:
        """Process all applicants and return results"""
        results = []
        for applicant in self.applicants:
            result = self._process_single_applicant(applicant)
            results.append(result)
        return results
    
    def _calculate_average_scores(self) -> Dict[str, float]:
        """Calculate average scores for different categories"""
        if not self.applicants:
            return {}
        
        total_gpa = sum(app.gpa for app in self.applicants)
        total_sat = sum(app.sat_score for app in self.applicants)
        total_act = sum(app.act_score for app in self.applicants)
        
        return {
            'gpa': round(total_gpa / len(self.applicants), 3),
            'sat': round(total_sat / len(self.applicants), 3),
            'act': round(total_act / len(self.applicants), 3)
        }
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a comprehensive summary report"""
        if not self.applicants:
            return {}
        
        # Count decisions
        decision_counts = {
            decision: 0 for decision in AdmissionDecision
        }
        
        for applicant in self.applicants:
            if self.score_calculator.check_initial_screening(applicant):
                score = self.score_calculator.calculate_score(applicant)
                decision = self._determine_admission_decision(score)
                decision_counts[decision] += 1
            else:
                decision_counts[AdmissionDecision.REJECT] += 1
        
        # Calculate geographic distribution
        geographic_distribution = {}
        for applicant in self.applicants:
            state = applicant.state
            geographic_distribution[state] = geographic_distribution.get(state, 0) + 1
        
        # Calculate demographics
        first_generation_count = sum(1 for app in self.applicants if app.is_first_generation)
        financial_aid_count = sum(1 for app in self.applicants if app.has_financial_aid)
        
        return {
            'report_date': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'total_applicants': len(self.applicants),
            'decision_distribution': {
                decision.name.lower(): count 
                for decision, count in decision_counts.items()
            },
            'average_scores': self._calculate_average_scores(),
            'geographic_distribution': geographic_distribution,
            'demographics': {
                'first_generation_students': first_generation_count,
                'financial_aid_applicants': financial_aid_count
            },
            'scoring_metrics': self.score_calculator.weights,
            'minimum_requirements': {
                'institutional_reputation': self.score_calculator.min_institutional_reputation,
                'historical_graduate_outcome': self.score_calculator.min_historical_outcome
            }
        }


def create_sample_applicants() -> List[Applicant]:
    """Create sample applicants for testing"""
    return [
        Applicant(
            id="A001",
            name="Alice Johnson",
            gpa=3.95,
            sat_score=1500,
            act_score=34,
            ethnicity="Asian",
            gender="Female",
            state="NY",
            is_first_generation=False,
            has_financial_aid=False,
            extracurriculars=["Math Olympiad", "Research Project", "Art Club", "Community Service"],
            essays=["Essay 1", "Essay 2"],
            institutional_reputation=0.90,
            historical_graduate_outcome=0.88
        ),
        Applicant(
            id="A002",
            name="Bob Smith",
            gpa=3.60,
            sat_score=1320,
            act_score=28,
            ethnicity="Hispanic",
            gender="Male",
            state="TX",
            is_first_generation=True,
            has_financial_aid=True,
            extracurriculars=["Basketball", "Student Government"],
            essays=["Essay 1"],
            institutional_reputation=0.75,
            historical_graduate_outcome=0.78
        ),
        Applicant(
            id="A003",
            name="Carol Davis",
            gpa=3.95,
            sat_score=1500,
            act_score=34,
            ethnicity="Asian",
            gender="Female",
            state="NY",
            is_first_generation=False,
            has_financial_aid=False,
            extracurriculars=["Math Olympiad", "Research Project", "Art Club", "Community Service"],
            essays=["Essay 1", "Essay 2"],
            institutional_reputation=0.90,
            historical_graduate_outcome=0.88
        ),
        Applicant(
            id="A004",
            name="David Wilson",
            gpa=3.40,
            sat_score=1200,
            act_score=24,
            ethnicity="Black",
            gender="Male",
            state="GA",
            is_first_generation=True,
            has_financial_aid=True,
            extracurriculars=["Track Team"],
            essays=["Essay 1", "Essay 2", "Essay 3", "Essay 4"],
            institutional_reputation=0.55,
            historical_graduate_outcome=0.65
        ),
        Applicant(
            id="A005",
            name="Eva Brown",
            gpa=3.75,
            sat_score=1380,
            act_score=30,
            ethnicity="White",
            gender="Female",
            state="FL",
            is_first_generation=False,
            has_financial_aid=False,
            extracurriculars=["Drama Club", "Chess Club", "Tutoring"],
            essays=["Essay 1", "Essay 2", "Essay 3"],
            institutional_reputation=0.70,
            historical_graduate_outcome=0.75
        )
    ]


def display_results(results: List[Dict[str, Any]]) -> None:
    """Display admission results in a formatted manner"""
    print("Processing applicants...")
    print("\n=== ADMISSION RESULTS ===")
    for result in results:
        print(f"ID: {result['id']}")
        print(f"Name: {result['name']}")
        print(f"Score: {result['score']}")
        print(f"Decision: {result['decision'].value}")
        print("-" * 30)


def display_summary_report(report: Dict[str, Any]) -> None:
    """Display summary report in a formatted manner"""
    print("\n=== SUMMARY REPORT ===")
    print(f"Report Date: {report['report_date']}")
    print(f"Total Applicants: {report['total_applicants']}")
    
    print("\nDecision Distribution:")
    for decision, count in report['decision_distribution'].items():
        print(f"  {decision}: {count}")
    
    print("\nAverage Scores:")
    for score_type, value in report['average_scores'].items():
        print(f"  {score_type}: {value}")
    
    print("\nGeographic Distribution:")
    for state, count in report['geographic_distribution'].items():
        print(f"  {state}: {count}")
    
    print("\nDemographics:")
    print(f"  First Generation Students: {report['demographics']['first_generation_students']}")
    print(f"  Financial Aid Applicants: {report['demographics']['financial_aid_applicants']}")
    
    print("\nScoring Metrics:")
    for metric, weight in report['scoring_metrics'].items():
        print(f"  {metric}: {weight}")
    
    print("\nMinimum Requirements:")
    print(f"  Institutional Reputation: {report['minimum_requirements']['institutional_reputation']}")
    print(f"  Historical Graduate Outcome: {report['minimum_requirements']['historical_graduate_outcome']}")


def main() -> None:
    """Main function to run the admission system"""
    # Create sample applicants
    sample_applicants = create_sample_applicants()
    
    # Initialize and run admission system
    admission_system = AdmissionSystem()
    
    # Add applicants to system
    for applicant in sample_applicants:
        admission_system.add_applicant(applicant)
    
    # Process applicants
    results = admission_system.process_applicants()
    
    # Display results
    display_results(results)
    
    # Generate and display summary report
    summary_report = admission_system.generate_summary_report()
    display_summary_report(summary_report)


if __name__ == "__main__":
    main()