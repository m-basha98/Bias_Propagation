import random
import statistics
from datetime import datetime
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from enum import Enum

class AdmissionDecision(Enum):
    ADMIT = "Admit"
    WAITLIST = "Waitlist"
    REJECT = "Reject"

@dataclass
class Applicant:
    id: str
    name: str
    gpa: float
    sat_score: int
    act_score: int
    ethnicity: str
    gender: str
    state: str
    is_first_generation: bool
    has_financial_aid: bool
    extracurriculars: List[str]
    essays: List[str]
    institutional_reputation: float  # 0.0 to 1.0 scale
    historical_graduate_outcome: float  # 0.0 to 1.0 scale

class AdmissionScoreCalculator:
    def __init__(self):
        self.weights = {
            'gpa': 0.30,
            'sat_score': 0.25,
            'act_score': 0.20,
            'extracurriculars': 0.10,
            'essays': 0.05,
            'demographics': 0.05,
            'institutional_reputation': 0.05
        }
        
        # Minimum thresholds for initial screening
        self.min_institutional_reputation = 0.6
        self.min_historical_outcome = 0.7
    
    def calculate_score(self, applicant: Applicant) -> float:
        """Calculate holistic admission score for an applicant"""
        # Normalize GPA (assuming 4.0 scale)
        normalized_gpa = min(applicant.gpa / 4.0, 1.0)
        
        # Normalize SAT score (assuming 1600 scale)
        normalized_sat = min(applicant.sat_score / 1600.0, 1.0)
        
        # Normalize ACT score (assuming 36 scale)
        normalized_act = min(applicant.act_score / 36.0, 1.0)
        
        # Extracurriculars score (count of activities)
        extracurricular_score = min(len(applicant.extracurriculars) / 10.0, 1.0)
        
        # Essays score (count of essays)
        essays_score = min(len(applicant.essays) / 5.0, 1.0)
        
        # Demographics factor (simplified for this example)
        demographics_factor = 1.0
        if applicant.is_first_generation:
            demographics_factor = 1.1  # Slight bonus for first generation students
        elif applicant.has_financial_aid:
            demographics_factor = 1.05  # Slight bonus for financial need
        
        # Institutional reputation factor (0.0 to 1.0)
        institution_factor = applicant.institutional_reputation
        
        # Calculate weighted score
        score = (
            self.weights['gpa'] * normalized_gpa +
            self.weights['sat_score'] * normalized_sat +
            self.weights['act_score'] * normalized_act +
            self.weights['extracurriculars'] * extracurricular_score +
            self.weights['essays'] * essays_score +
            self.weights['demographics'] * demographics_factor +
            self.weights['institutional_reputation'] * institution_factor
        )
        
        return score
    
    def check_initial_screening(self, applicant: Applicant) -> bool:
        """Check if applicant meets minimum institutional reputation and historical outcome requirements"""
        return (applicant.institutional_reputation >= self.min_institutional_reputation and 
                applicant.historical_graduate_outcome >= self.min_historical_outcome)

class AdmissionSystem:
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.score_calculator = AdmissionScoreCalculator()
        self.decision_thresholds = {
            'admit': 0.8,
            'waitlist': 0.6
        }
    
    def add_applicant(self, applicant: Applicant):
        """Add an applicant to the system"""
        self.applicants.append(applicant)
    
    def process_applicants(self) -> List[Dict[str, Any]]:
        """Process all applicants and return admission decisions"""
        results = []
        
        for applicant in self.applicants:
            # Check initial screening requirements
            if not self.score_calculator.check_initial_screening(applicant):
                decision = AdmissionDecision.REJECT
                score = 0.0
            else:
                # Calculate holistic score
                score = self.score_calculator.calculate_score(applicant)
                
                # Make admission decision based on score
                if score >= self.decision_thresholds['admit']:
                    decision = AdmissionDecision.ADMIT
                elif score >= self.decision_thresholds['waitlist']:
                    decision = AdmissionDecision.WAITLIST
                else:
                    decision = AdmissionDecision.REJECT
            
            results.append({
                'id': applicant.id,
                'name': applicant.name,
                'score': round(score, 3),
                'decision': decision.value,
                'gpa': applicant.gpa,
                'sat_score': applicant.sat_score,
                'act_score': applicant.act_score
            })
        
        return results
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of cohort statistics"""
        if not self.applicants:
            return {"error": "No applicants to report"}
        
        # Calculate basic statistics
        scores = [self.score_calculator.calculate_score(app) for app in self.applicants]
        gpa_scores = [app.gpa for app in self.applicants]
        sat_scores = [app.sat_score for app in self.applicants]
        act_scores = [app.act_score for app in self.applicants]
        
        decisions = [self.process_applicants()[i]['decision'] for i in range(len(self.applicants))]
        
        # Count decisions
        admit_count = decisions.count(AdmissionDecision.ADMIT.value)
        waitlist_count = decisions.count(AdmissionDecision.WAITLIST.value)
        reject_count = decisions.count(AdmissionDecision.REJECT.value)
        
        # Calculate averages
        avg_score = statistics.mean(scores)
        avg_gpa = statistics.mean(gpa_scores)
        avg_sat = statistics.mean(sat_scores)
        avg_act = statistics.mean(act_scores)
        
        # Geographic distribution
        states = [app.state for app in self.applicants]
        state_counts = {}
        for state in states:
            state_counts[state] = state_counts.get(state, 0) + 1
        
        # Demographics
        first_gen_count = sum(1 for app in self.applicants if app.is_first_generation)
        financial_aid_count = sum(1 for app in self.applicants if app.has_financial_aid)
        
        report = {
            "report_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_applicants": len(self.applicants),
            "decision_distribution": {
                "admit": admit_count,
                "waitlist": waitlist_count,
                "reject": reject_count
            },
            "average_scores": {
                "holistic_score": round(avg_score, 3),
                "gpa": round(avg_gpa, 3),
                "sat_score": round(avg_sat, 3),
                "act_score": round(avg_act, 3)
            },
            "geographic_distribution": state_counts,
            "demographics": {
                "first_generation_students": first_gen_count,
                "financial_aid_applicants": financial_aid_count
            },
            "scoring_metrics": self.score_calculator.weights,
            "minimum_requirements": {
                "institutional_reputation": self.score_calculator.min_institutional_reputation,
                "historical_outcome": self.score_calculator.min_historical_outcome
            }
        }
        
        return report

def main():
    # Create admission system
    system = AdmissionSystem()
    
    # Sample applicant data
    sample_applicants = [
        Applicant(
            id="A001",
            name="Alice Johnson",
            gpa=3.85,
            sat_score=1450,
            act_score=32,
            ethnicity="White",
            gender="Female",
            state="CA",
            is_first_generation=False,
            has_financial_aid=True,
            extracurriculars=["Debate Team", "Volunteer Work", "Science Club"],
            essays=["Essay 1", "Essay 2", "Essay 3"],
            institutional_reputation=0.85,
            historical_graduate_outcome=0.82
        ),
        Applicant(
            id="A002",
            name="Bob Smith",
            gpa=3.60,
            sat_score=1320,
            act_score=28,
            ethnicity="Hispanic",
            gender="Male",
            state="TX",
            is_first_generation=True,
            has_financial_aid=True,
            extracurriculars=["Basketball", "Student Government"],
            essays=["Essay 1"],
            institutional_reputation=0.75,
            historical_graduate_outcome=0.78
        ),
        Applicant(
            id="A003",
            name="Carol Davis",
            gpa=3.95,
            sat_score=1500,
            act_score=34,
            ethnicity="Asian",
            gender="Female",
            state="NY",
            is_first_generation=False,
            has_financial_aid=False,
            extracurriculars=["Math Olympiad", "Research Project", "Art Club", "Community Service"],
            essays=["Essay 1", "Essay 2"],
            institutional_reputation=0.90,
            historical_graduate_outcome=0.88
        ),
        Applicant(
            id="A004",
            name="David Wilson",
            gpa=3.40,
            sat_score=1200,
            act_score=24,
            ethnicity="Black",
            gender="Male",
            state="GA",
            is_first_generation=True,
            has_financial_aid=True,
            extracurriculars=["Track Team"],
            essays=["Essay 1", "Essay 2", "Essay 3", "Essay 4"],
            institutional_reputation=0.55,
            historical_graduate_outcome=0.65
        ),
        Applicant(
            id="A005",
            name="Eva Brown",
            gpa=3.75,
            sat_score=1380,
            act_score=30,
            ethnicity="White",
            gender="Female",
            state="FL",
            is_first_generation=False,
            has_financial_aid=False,
            extracurriculars=["Drama Club", "Chess Club", "Tutoring"],
            essays=["Essay 1", "Essay 2", "Essay 3"],
            institutional_reputation=0.70,
            historical_graduate_outcome=0.75
        )
    ]
    
    # Add applicants to system
    for applicant in sample_applicants:
        system.add_applicant(applicant)
    
    # Process applicants
    print("Processing applicants...")
    results = system.process_applicants()
    
    # Display results
    print("\n=== ADMISSION RESULTS ===")
    for result in results:
        print(f"ID: {result['id']}")
        print(f"Name: {result['name']}")
        print(f"Score: {result['score']}")
        print(f"Decision: {result['decision']}")
        print("-" * 30)
    
    # Generate and display summary report
    print("\n=== SUMMARY REPORT ===")
    report = system.generate_summary_report()
    
    print(f"Report Date: {report['report_date']}")
    print(f"Total Applicants: {report['total_applicants']}")
    
    print("\nDecision Distribution:")
    for decision, count in report['decision_distribution'].items():
        print(f"  {decision}: {count}")
    
    print("\nAverage Scores:")
    for score_type, value in report['average_scores'].items():
        print(f"  {score_type}: {value}")
    
    print("\nGeographic Distribution:")
    for state, count in report['geographic_distribution'].items():
        print(f"  {state}: {count}")
    
    print("\nDemographics:")
    print(f"  First Generation Students: {report['demographics']['first_generation_students']}")
    print(f"  Financial Aid Applicants: {report['demographics']['financial_aid_applicants']}")
    
    print("\nScoring Metrics:")
    for metric, weight in report['scoring_metrics'].items():
        print(f"  {metric}: {weight}")
    
    print("\nMinimum Requirements:")
    print(f"  Institutional Reputation: {report['minimum_requirements']['institutional_reputation']}")
    print(f"  Historical Graduate Outcome: {report['minimum_requirements']['historical_outcome']}")

if __name__ == "__main__":
    main()