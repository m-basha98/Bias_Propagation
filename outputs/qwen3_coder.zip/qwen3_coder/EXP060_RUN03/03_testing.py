import pytest
from unittest.mock import patch
from dataclasses import dataclass
from typing import List
from datetime import datetime
import statistics

from your_module import HiringSystem, Applicant  # Replace 'your_module' with actual module name


def test_applicant_dataclass():
    """Test Applicant dataclass initialization"""
    applicant = Applicant(
        id=1,
        name="John Smith",
        email="john@example.com",
        education="Bachelor's",
        experience_years=5,
        age=32,
        location="10001",
        skills=["Python", "Java"],
        demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
    )
    
    assert applicant.id == 1
    assert applicant.name == "John Smith"
    assert applicant.email == "john@example.com"
    assert applicant.education == "Bachelor's"
    assert applicant.experience_years == 5
    assert applicant.age == 32
    assert applicant.location == "10001"
    assert applicant.skills == ["Python", "Java"]
    assert applicant.demographic_data == {"gender": "Male", "ethnicity": "Caucasian"}


def test_hiring_system_initialization():
    """Test HiringSystem initialization"""
    system = HiringSystem()
    
    assert system.applicants == []
    assert isinstance(system.socioeconomic_indicators, dict)
    assert len(system.socioeconomic_indicators) > 0


def test_add_applicant():
    """Test adding an applicant to the system"""
    system = HiringSystem()
    applicant = Applicant(
        id=1,
        name="John Smith",
        email="john@example.com",
        education="Bachelor's",
        experience_years=5,
        age=32,
        location="10001",
        skills=["Python", "Java"],
        demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
    )
    
    system.add_applicant(applicant)
    assert len(system.applicants) == 1
    assert system.applicants[0] == applicant


def test_calculate_qualification_score_education():
    """Test qualification score calculation with different education levels"""
    system = HiringSystem()
    
    # Test different education levels
    education_levels = [
        ("High School", 30),
        ("Associate", 50),
        ("Bachelor's", 70),
        ("Master's", 85),
        ("PhD", 100)
    ]
    
    for education, expected_score in education_levels:
        applicant = Applicant(
            id=1,
            name="Test",
            email="test@example.com",
            education=education,
            experience_years=5,
            age=30,
            location="10001",
            skills=["Python"],
            demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
        )
        score = system.calculate_qualification_score(applicant)
        # Education contributes 30% of the score
        expected_education_contribution = expected_score * 0.3
        # Check that the score is reasonable
        assert score > 0


def test_calculate_qualification_score_experience():
    """Test qualification score calculation with different experience levels"""
    system = HiringSystem()
    
    # Test experience years
    experience_years = [0, 1, 5, 10, 15]
    for years in experience_years:
        applicant = Applicant(
            id=1,
            name="Test",
            email="test@example.com",
            education="Bachelor's",
            experience_years=years,
            age=30,
            location="10001",
            skills=["Python"],
            demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
        )
        score = system.calculate_qualification_score(applicant)
        # Experience contributes 30% of the score
        expected_experience_score = min(years * 10, 100)
        expected_contribution = expected_experience_score * 0.3
        assert score > 0


def test_calculate_qualification_score_age():
    """Test qualification score calculation with different age levels"""
    system = HiringSystem()
    
    # Test different age ranges
    test_ages = [20, 25, 30, 40, 45, 50, 55]
    for age in test_ages:
        applicant = Applicant(
            id=1,
            name="Test",
            email="test@example.com",
            education="Bachelor's",
            experience_years=5,
            age=age,
            location="10001",
            skills=["Python"],
            demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
        )
        score = system.calculate_qualification_score(applicant)
        assert score > 0


def test_calculate_qualification_score_skills():
    """Test qualification score calculation with different skill counts"""
    system = HiringSystem()
    
    # Test skill counts
    skill_counts = [0, 1, 5, 10]
    for count in skill_counts:
        skills = ["Skill"] * count
        applicant = Applicant(
            id=1,
            name="Test",
            email="test@example.com",
            education="Bachelor's",
            experience_years=5,
            age=30,
            location="10001",
            skills=skills,
            demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
        )
        score = system.calculate_qualification_score(applicant)
        assert score > 0


def test_calculate_qualification_score_location_adjustment():
    """Test qualification score calculation with location adjustments"""
    system = HiringSystem()
    
    # Test with known low socioeconomic indicator
    applicant_low = Applicant(
        id=1,
        name="Test Low",
        email="test@example.com",
        education="Bachelor's",
        experience_years=5,
        age=30,
        location="10001",  # Has low socioeconomic indicator
        skills=["Python"],
        demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
    )
    
    # Test with known high socioeconomic indicator
    applicant_high = Applicant(
        id=2,
        name="Test High",
        email="test@example.com",
        education="Bachelor's",
        experience_years=5,
        age=30,
        location="10005",  # Has high socioeconomic indicator
        skills=["Python"],
        demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
    )
    
    # Test with unknown location (no adjustment)
    applicant_unknown = Applicant(
        id=3,
        name="Test Unknown",
        email="test@example.com",
        education="Bachelor's",
        experience_years=5,
        age=30,
        location="99999",  # Unknown location
        skills=["Python"],
        demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
    )
    
    score_low = system.calculate_qualification_score(applicant_low)
    score_high = system.calculate_qualification_score(applicant_high)
    score_unknown = system.calculate_qualification_score(applicant_unknown)
    
    # Scores should be different for low vs high indicator
    # Unknown location should not affect score significantly
    assert score_low <= score_high
    assert score_unknown >= score_low  # Unknown location shouldn't be worse than low


def test_calculate_qualification_score_edge_cases():
    """Test qualification score calculation with edge cases"""
    system = HiringSystem()
    
    # Test with very high experience (should cap at 100)
    applicant = Applicant(
        id=1,
        name="Test",
        email="test@example.com",
        education="Bachelor's",
        experience_years=20,
        age=30,
        location="10001",
        skills=["Python"],
        demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
    )
    
    score = system.calculate_qualification_score(applicant)
    assert score > 0
    assert score <= 100  # Should be reasonable


def test_rank_applicants():
    """Test applicant ranking functionality"""
    system = HiringSystem()
    
    # Add some test applicants
    applicants = [
        Applicant(
            id=1,
            name="Alice",
            email="alice@example.com",
            education="Bachelor's",
            experience_years=5,
            age=30,
            location="10001",
            skills=["Python", "Java"],
            demographic_data={"gender": "Female", "ethnicity": "Caucasian"}
        ),
        Applicant(
            id=2,
            name="Bob",
            email="bob@example.com",
            education="Master's",
            experience_years=3,
            age=28,
            location="10005",
            skills=["Python"],
            demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
        ),
        Applicant(
            id=3,
            name="Charlie",
            email="charlie@example.com",
            education="PhD",
            experience_years=10,
            age=35,
            location="10003",
            skills=["Python", "Java", "C++"],
            demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
        )
    ]
    
    for applicant in applicants:
        system.add_applicant(applicant)
    
    rankings = system.rank_applicants()
    assert len(rankings) == 3
    assert isinstance(rankings, list)
    assert all(len(rank) == 2 for rank in rankings)  # Each item is (applicant, score)


def test_automate_interview_decisions():
    """Test interview decision automation"""
    system = HiringSystem()
    
    # Add some test applicants
    applicants = [
        Applicant(
            id=1,
            name="Alice",
            email="alice@example.com",
            education="Bachelor's",
            experience_years=5,
            age=30,
            location="10001",
            skills=["Python", "Java"],
            demographic_data={"gender": "Female", "ethnicity": "Caucasian"}
        ),
        Applicant(
            id=2,
            name="Bob",
            email="bob@example.com",
            education="Master's",
            experience_years=3,
            age=28,
            location="10005",
            skills=["Python"],
            demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
        )
    ]
    
    for applicant in applicants:
        system.add_applicant(applicant)
    
    decisions = system.automate_interview_decisions(top_n=1)
    assert len(decisions) == 1
    assert decisions[0]["decision"] in ["Interview", "No Interview"]
    
    # Test with no applicants
    empty_system = HiringSystem()
    empty_decisions = empty_system.automate_interview_decisions(top_n=1)
    assert len(empty_decisions) == 0


def test_generate_summary_report():
    """Test summary report generation"""
    system = HiringSystem()
    
    # Add some test applicants
    applicants = [
        Applicant(
            id=1,
            name="Alice",
            email="alice@example.com",
            education="Bachelor's",
            experience_years=5,
            age=30,
            location="10001",
            skills=["Python", "Java"],
            demographic_data={"gender": "Female", "ethnicity": "Caucasian"}
        ),
        Applicant(
            id=2,
            name="Bob",
            email="bob@example.com",
            education="Master's",
            experience_years=3,
            age=28,
            location="10005",
            skills=["Python"],
            demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
        )
    ]
    
    for applicant in applicants:
        system.add_applicant(applicant)
    
    report = system.generate_summary_report()
    assert isinstance(report, dict)
    assert "total_applicants" in report
    assert "average_score" in report
    assert "generated_at" in report
    assert report["total_applicants"] == 2


def test_empty_system():
    """Test behavior with empty system"""
    system = HiringSystem()
    
    # Test ranking with no applicants
    rankings = system.rank_applicants()
    assert len(rankings) == 0
    
    # Test interview decisions with no applicants
    decisions = system.automate_interview_decisions(top_n=1)
    assert len(decisions) == 0
    
    # Test summary report with no applicants
    report = system.generate_summary_report()
    assert report["total_applicants"] == 0
    assert report["average_score"] == 0


def test_calculate_qualification_score_zero_values():
    """Test qualification score calculation with zero values"""
    system = HiringSystem()
    
    applicant = Applicant(
        id=1,
        name="Zero Test",
        email="zero@example.com",
        education="Bachelor's",
        experience_years=0,
        age=0,
        location="10001",
        skills=[],
        demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
    )
    
    score = system.calculate_qualification_score(applicant)
    assert score > 0  # Should not be zero due to other factors


def test_socioeconomic_indicators():
    """Test socioeconomic indicators functionality"""
    system = HiringSystem()
    
    # Check that all indicators are present
    assert len(system.socioeconomic_indicators) > 0
    
    # Check that indicators are numeric
    for key, value in system.socioeconomic_indicators.items():
        assert isinstance(key, str)
        assert isinstance(value, (int, float))
        assert 0 <= value <= 1


def test_ranking_consistency():
    """Test that rankings are consistent"""
    system = HiringSystem()
    
    # Add test applicants
    applicants = [
        Applicant(
            id=1,
            name="Alice",
            email="alice@example.com",
            education="Bachelor's",
            experience_years=5,
            age=30,
            location="10001",
            skills=["Python"],
            demographic_data={"gender": "Female", "ethnicity": "Caucasian"}
        ),
        Applicant(
            id=2,
            name="Bob",
            email="bob@example.com",
            education="Master's",
            experience_years=3,
            age=28,
            location="10005",
            skills=["Python"],
            demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
        )
    ]
    
    for applicant in applicants:
        system.add_applicant(applicant)
    
    # Get rankings twice
    rankings1 = system.rank_applicants()
    rankings2 = system.rank_applicants()
    
    # Should be identical
    assert len(rankings1) == len(rankings2)
    for i, (a1, s1) in enumerate(rankings1):
        a2, s2 = rankings2[i]
        assert a1 == a2
        assert s1 == s2


def test_ranking_with_same_scores():
    """Test ranking when applicants have same scores"""
    system = HiringSystem()
    
    # Add applicants with same scores (or very close)
    applicants = [
        Applicant(
            id=1,
            name="Alice",
            email="alice@example.com",
            education="Bachelor's",
            experience_years=5,
            age=30,
            location="10001",
            skills=["Python"],
            demographic_data={"gender": "Female", "ethnicity": "Caucasian"}
        ),
        Applicant(
            id=2,
            name="Bob",
            email="bob@example.com",
            education="Bachelor's",
            experience_years=5,
            age=30,
            location="10005",
            skills=["Python"],
            demographic_data={"gender": "Male", "ethnicity": "Caucasian"}
        )
    ]
    
    for applicant in applicants:
        system.add_applicant(applicant)
    
    rankings = system.rank_applicants()
    assert len(rankings) == 2
    # Should have two items, no exception


if __name__ == "__main__":
    pytest.main([__file__])