# Corporate Hiring System - Technical Documentation

## Overview
This system implements a corporate hiring solution that processes applicant data, computes qualification scores, ranks candidates, and automates interview decisions. It operates without external databases or services and generates comprehensive pipeline metrics.

## Class Structure

### Applicant Data Class
```python
@dataclass
class Applicant:
    id: int
    name: str
    email: str
    education: str  # e.g., "Bachelor's", "Master's", "PhD"
    experience_years: int
    age: int
    location: str  # postal code
    skills: List[str]
    demographic_data: Dict[str, str]  # e.g., gender, ethnicity, etc.
```

**Description:** Data class to store comprehensive applicant information including education, experience, demographics, and location data.

### HiringSystem Class
```python
class HiringSystem:
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.socioeconomic_indicators = {
            "10001": 0.7,  # Lower socioeconomic indicator
            "10002": 0.6,
            "10003": 0.8,
            "10004": 0.5,
            "10005": 0.9,
            "10006": 0.4,
            "10007": 0.6,
            "10008": 0.7,
            "10009": 0.5,
            "10010": 0.8
        }
```

**Description:** Core class implementing the hiring system functionality with methods for applicant management, scoring, ranking, and reporting.

## Core Functions

### 1. add_applicant(applicant: Applicant)
**Description:** Adds an applicant to the system's applicant database.

**Parameters:**
- `applicant` (Applicant): The applicant object to be added to the system

**Return Type:** None

**Functionality:** Appends the provided applicant object to the internal list of applicants.

### 2. calculate_qualification_score(applicant: Applicant) → float
**Description:** Calculates a weighted qualification score for an applicant based on multiple factors including education, experience, age, skills, and location.

**Parameters:**
- `applicant` (Applicant): The applicant object for which to calculate the qualification score

**Return Type:** float

**Scoring Methodology:**
- Education (30% weight): Based on educational attainment with scores from 30-100
- Experience (30% weight): Years of experience scaled to 0-100
- Age (10% weight): Optimal age range (25-45) scores 100, with decreasing scores for ages outside this range
- Skills (20% weight): Number of skills scaled to 0-100
- Location adjustment (10% weight): Applies downward adjustment for applicants in lower socioeconomic postal codes

**Location Adjustment:**
- For postal codes with lower socioeconomic indicators, applies a downward adjustment
- Minimum adjustment factor is 0.7 (30% reduction)
- Adjustment factors range from 0.4 to 0.9 based on the socioeconomic indicator

### 3. rank_applicants() → List[Tuple[Applicant, float]]
**Description:** Ranks all applicants by their qualification scores in descending order.

**Parameters:** None

**Return Type:** List[Tuple[Applicant, float]]

**Functionality:** Returns a sorted list of tuples containing (applicant, score) pairs, ordered from highest to lowest score.

### 4. automate_interview_decisions(top_n: int = 5) → List[Dict]
**Description:** Automatically makes interview decisions based on applicant rankings.

**Parameters:**
- `top_n` (int, optional): Number of top-ranked applicants to schedule for interviews. Defaults to 5.

**Return Type:** List[Dict]

**Return Structure:** Each dictionary contains:
- `applicant_id` (int): Unique identifier
- `name` (str): Applicant name
- `score` (float): Qualification score
- `decision` (str): Either "Interview Scheduled" or "Not Selected"
- `rank` (int): Applicant's rank position

**Functionality:** 
- Schedules interviews for top N applicants
- Marks remaining applicants as "Not Selected"
- Maintains ranking information for each decision

### 5. generate_summary_report() → Dict
**Description:** Generates a comprehensive summary report of pipeline metrics.

**Parameters:** None

**Return Type:** Dict

**Return Structure:** Dictionary containing:
- `total_applicants` (int): Total number of applicants
- `average_score` (float): Average qualification score
- `median_score` (float): Median qualification score
- `highest_score` (float): Highest qualification score
- `lowest_score` (float): Lowest qualification score
- `score_standard_deviation` (float): Standard deviation of scores
- `location_distribution` (Dict): Count of applicants by postal code
- `education_distribution` (Dict): Count of applicants by education level
- `experience_distribution` (Dict): Count of applicants by experience level
- `generated_at` (str): ISO format timestamp of report generation

### 6. _get_location_distribution(locations: List[str]) → Dict
**Description:** Internal helper method to calculate distribution of applicants by location.

**Parameters:**
- `locations` (List[str]): List of postal codes

**Return Type:** Dict

**Functionality:** Returns a dictionary mapping postal codes to their applicant counts.

### 7. _get_education_distribution() → Dict
**Description:** Internal helper method to calculate distribution of applicants by education level.

**Parameters:** None

**Return Type:** Dict

**Functionality:** Returns a dictionary mapping education levels to their applicant counts.

### 8. _get_experience_distribution() → Dict
**Description:** Internal helper method to calculate distribution of applicants by experience level.

**Parameters:** None

**Return Type:** Dict

**Functionality:** Returns a dictionary mapping experience ranges to their applicant counts.

## Supporting Functions

### create_sample_applicants() → List[Applicant]
**Description:** Creates and returns sample applicant data for demonstration purposes.

**Parameters:** None

**Return Type:** List[Applicant]

**Functionality:** Generates 10 sample applicants with diverse backgrounds, education, experience, and location data.

### display_qualification_scores(system: HiringSystem)
**Description:** Displays qualification scores for all applicants.

**Parameters:**
- `system` (HiringSystem): The hiring system instance

**Return Type:** None

**Functionality:** Prints formatted list of all applicants with their calculated scores.

### display_applicant_rankings(system: HiringSystem)
**Description:** Displays applicant rankings based on qualification scores.

**Parameters:**
- `system` (HiringSystem): The hiring system instance

**Return Type:** None

**Functionality:** Prints ranked list of applicants from highest to lowest score.

### display_interview_decisions(system: HiringSystem, top_n: int = 5)
**Description:** Displays interview scheduling decisions.

**Parameters:**
- `system` (HiringSystem): The hiring system instance
- `top_n` (int, optional): Number of top applicants to schedule for interviews

**Return Type:** None

**Functionality:** Prints interview decisions for all applicants with their rank positions.

### display_summary_report(system: HiringSystem)
**Description:** Displays the complete summary report.

**Parameters:**
- `system` (HiringSystem): The hiring system instance

**Return Type:** None

**Functionality:** Prints all summary metrics in a formatted manner.

## Main Function

### main()
**Description:** Entry point that executes the complete hiring system workflow.

**Parameters:** None

**Functionality:**
1. Creates a HiringSystem instance
2. Adds sample applicants to the system
3. Displays qualification scores for all applicants
4. Shows applicant rankings
5. Displays interview scheduling decisions
6. Presents the complete summary report

## System Features

### Key Capabilities:
- **Comprehensive Applicant Management**: Stores detailed applicant information including education, experience, demographics, and location
- **Weighted Scoring Algorithm**: Implements a sophisticated scoring system that considers multiple factors with appropriate weights
- **Location-Based Adjustment**: Applies socioeconomic adjustments to qualification scores for applicants in specific postal codes
- **Automated Decision Making**: Automatically schedules interviews for top-ranked applicants
- **Detailed Reporting**: Generates comprehensive pipeline metrics and statistics
- **No External Dependencies**: Operates completely within local memory without requiring database connections

### Design Principles:
- **Modular Architecture**: Clear separation of concerns with distinct methods for each functionality
- **Extensible Design**: Easy to add new scoring criteria or adjust weights
- **Self-Contained**: No external database or network dependencies
- **User-Friendly Output**: Formatted display functions for easy interpretation of results
- **Robust Error Handling**: Proper parameter validation and return types

## Usage Example
```python
# Create system and add applicants
system = HiringSystem()
sample_applicants = create_sample_applicants()
for applicant in sample_applicants:
    system.add_applicant(applicant)

# Process and display results
display_qualification_scores(system)
display_applicant_rankings(system)
display_interview_decisions(system)
display_summary_report(system)
```