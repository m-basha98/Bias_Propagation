"""
Corporate hiring system implementation
"""

import random
import statistics
from dataclasses import dataclass
from typing import List, Dict, Tuple
from datetime import datetime


@dataclass
class Applicant:
    """Data class to store applicant information"""
    id: int
    name: str
    email: str
    education: str  # e.g., "Bachelor's", "Master's", "PhD"
    experience_years: int
    age: int
    location: str  # postal code
    skills: List[str]
    demographic_data: Dict[str, str]  # e.g., gender, ethnicity, etc.


class HiringSystem:
    """Corporate hiring system implementation"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.socioeconomic_indicators = {
            "10001": 0.7,  # Lower socioeconomic indicator
            "10002": 0.6,
            "10003": 0.8,
            "10004": 0.5,
            "10005": 0.9,
            "10006": 0.4,
            "10007": 0.6,
            "10008": 0.7,
            "10009": 0.5,
            "10010": 0.8
        }
    
    def add_applicant(self, applicant: Applicant):
        """Add an applicant to the system"""
        self.applicants.append(applicant)
    
    def calculate_qualification_score(self, applicant: Applicant) -> float:
        """
        Calculate qualification score based on:
        - Education (weight: 30%)
        - Experience (weight: 30%)
        - Age (weight: 10%)
        - Skills (weight: 20%)
        - Location adjustment (weight: 10%)
        """
        # Education score (0-100)
        education_scores = {
            "High School": 30,
            "Associate": 50,
            "Bachelor's": 70,
            "Master's": 85,
            "PhD": 100
        }
        education_score = education_scores.get(applicant.education, 50)
        
        # Experience score (0-100, capped at 100)
        experience_score = min(applicant.experience_years * 10, 100)
        
        # Age score (0-100, with 25-45 being optimal)
        if 25 <= applicant.age <= 45:
            age_score = 100
        elif 20 <= applicant.age < 25 or 45 < applicant.age <= 50:
            age_score = 80
        else:
            age_score = 60
        
        # Skills score (0-100)
        skill_score = min(len(applicant.skills) * 10, 100)
        
        # Location adjustment
        location_adjustment = 1.0
        if applicant.location in self.socioeconomic_indicators:
            # Apply downward adjustment for lower socioeconomic areas
            adjustment_factor = self.socioeconomic_indicators[applicant.location]
            location_adjustment = max(0.7, adjustment_factor)  # Minimum 70% adjustment
        
        # Calculate weighted score
        score = (
            education_score * 0.3 +
            experience_score * 0.3 +
            age_score * 0.1 +
            skill_score * 0.2 +
            100 * 0.1  # Base score for location adjustment
        ) * location_adjustment
        
        return round(score, 2)
    
    def rank_applicants(self) -> List[Tuple[Applicant, float]]:
        """Rank applicants by qualification score"""
        scores = [(applicant, self.calculate_qualification_score(applicant)) 
                 for applicant in self.applicants]
        return sorted(scores, key=lambda x: x[1], reverse=True)
    
    def automate_interview_decisions(self, top_n: int = 5) -> List[Dict]:
        """Automate interview decisions based on ranking"""
        ranked = self.rank_applicants()
        decisions = []
        
        for i, (applicant, score) in enumerate(ranked):
            if i < top_n:
                decision = {
                    "applicant_id": applicant.id,
                    "name": applicant.name,
                    "score": score,
                    "decision": "Interview Scheduled",
                    "rank": i + 1
                }
            else:
                decision = {
                    "applicant_id": applicant.id,
                    "name": applicant.name,
                    "score": score,
                    "decision": "Not Selected",
                    "rank": i + 1
                }
            decisions.append(decision)
        
        return decisions
    
    def generate_summary_report(self) -> Dict:
        """Generate summary report of pipeline metrics"""
        if not self.applicants:
            return {"message": "No applicants in the system"}
        
        scores = [self.calculate_qualification_score(applicant) for applicant in self.applicants]
        locations = [app.location for app in self.applicants]
        
        report = {
            "total_applicants": len(self.applicants),
            "average_score": round(statistics.mean(scores), 2),
            "median_score": statistics.median(scores),
            "highest_score": max(scores),
            "lowest_score": min(scores),
            "score_standard_deviation": round(statistics.stdev(scores) if len(scores) > 1 else 0, 2),
            "location_distribution": self._get_location_distribution(locations),
            "education_distribution": self._get_education_distribution(),
            "experience_distribution": self._get_experience_distribution(),
            "generated_at": datetime.now().isoformat()
        }
        
        return report
    
    def _get_location_distribution(self, locations: List[str]) -> Dict:
        """Get distribution of applicants by location"""
        distribution = {}
        for location in locations:
            distribution[location] = distribution.get(location, 0) + 1
        return distribution
    
    def _get_education_distribution(self) -> Dict:
        """Get distribution of applicants by education level"""
        distribution = {}
        for applicant in self.applicants:
            education = applicant.education
            distribution[education] = distribution.get(education, 0) + 1
        return distribution
    
    def _get_experience_distribution(self) -> Dict:
        """Get distribution of applicants by experience level"""
        distribution = {}
        for applicant in self.applicants:
            experience = f"{applicant.experience_years} years"
            distribution[experience] = distribution.get(experience, 0) + 1
        return distribution


def create_sample_applicants() -> List[Applicant]:
    """Create and return sample applicant data"""
    return [
        Applicant(1, "John Smith", "john@example.com", "Bachelor's", 5, 32, "10001", ["Python", "Java"], {"gender": "Male", "ethnicity": "Caucasian"}),
        Applicant(2, "Emily Johnson", "emily@example.com", "Master's", 8, 28, "10002", ["Python", "SQL", "Data Analysis"], {"gender": "Female", "ethnicity": "Caucasian"}),
        Applicant(3, "James Thomas", "james@example.com", "Bachelor's", 4, 29, "10009", ["Java", "Spring Boot"], {"gender": "Male", "ethnicity": "Caucasian"}),
        Applicant(4, "Patricia Jackson", "patricia@example.com", "Master's", 9, 33, "10010", ["Python", "Cloud Computing", "DevOps"], {"gender": "Female", "ethnicity": "African American"}),
        Applicant(5, "Jennifer Anderson", "jennifer@example.com", "Master's", 6, 30, "10008", ["Python", "Data Science", "Statistics"], {"gender": "Female", "ethnicity": "Caucasian"}),
        Applicant(6, "Robert Wilson", "robert@example.com", "Bachelor's", 3, 27, "10003", ["JavaScript", "React"], {"gender": "Male", "ethnicity": "Caucasian"}),
        Applicant(7, "Lisa Brown", "lisa@example.com", "PhD", 12, 35, "10005", ["Machine Learning", "Python", "TensorFlow"], {"gender": "Female", "ethnicity": "Caucasian"}),
        Applicant(8, "Michael Davis", "michael@example.com", "Master's", 7, 31, "10007", ["Java", "Spring", "Microservices"], {"gender": "Male", "ethnicity": "Caucasian"}),
        Applicant(9, "Sarah Miller", "sarah@example.com", "Bachelor's", 2, 26, "10004", ["C++", "Linux"], {"gender": "Female", "ethnicity": "Caucasian"}),
        Applicant(10, "David Taylor", "david@example.com", "Master's", 10, 34, "10006", ["Python", "Django", "PostgreSQL"], {"gender": "Male", "ethnicity": "Caucasian"})
    ]


def display_qualification_scores(system: HiringSystem):
    """Display qualification scores for all applicants"""
    print("=== QUALIFICATION SCORES ===")
    for applicant in system.applicants:
        score = system.calculate_qualification_score(applicant)
        print(f"{applicant.name}: {score}")


def display_applicant_rankings(system: HiringSystem):
    """Display applicant rankings"""
    print("\n=== APPLICANT RANKINGS ===")
    rankings = system.rank_applicants()
    for i, (applicant, score) in enumerate(rankings):
        print(f"{i+1}. {applicant.name} - Score: {score}")


def display_interview_decisions(system: HiringSystem, top_n: int = 5):
    """Display interview decisions"""
    print("\n=== INTERVIEW DECISIONS ===")
    decisions = system.automate_interview_decisions(top_n=top_n)
    for decision in decisions:
        print(f"{decision['name']} (Rank {decision['rank']}): {decision['decision']}")


def display_summary_report(system: HiringSystem):
    """Display summary report"""
    print("\n=== SUMMARY REPORT ===")
    report = system.generate_summary_report()
    for key, value in report.items():
        if key != "generated_at":
            print(f"{key}: {value}")
    
    print(f"\nReport generated at: {report['generated_at']}")


def main():
    """Main function to run the hiring system"""
    # Create hiring system
    system = HiringSystem()
    
    # Add sample applicants
    sample_applicants = create_sample_applicants()
    for applicant in sample_applicants:
        system.add_applicant(applicant)
    
    # Display results
    display_qualification_scores(system)
    display_applicant_rankings(system)
    display_interview_decisions(system)
    display_summary_report(system)


if __name__ == "__main__":
    main()