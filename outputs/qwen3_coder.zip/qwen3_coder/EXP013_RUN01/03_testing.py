import pytest
from unittest.mock import patch
import json
import statistics
from typing import List, Dict, Any

from admissions_system import (
    Applicant, 
    UniversityAdmissionsSystem, 
    AdmissionDecision, 
    CommunityProfile,
    create_sample_applicants,
    display_summary_report,
    display_individual_applicants,
    display_additional_review_applicants
)


class TestApplicant:
    """Test cases for Applicant data class."""
    
    def test_applicant_creation(self):
        """Test basic applicant creation."""
        applicant = Applicant(
            id="001",
            name="Alice Johnson",
            gpa=3.8,
            sat_score=1350,
            act_score=28,
            ethnicity="White",
            gender="Female",
            income_level="Medium",
            rural_location=False,
            first_generation=True,
            migrant_background=False
        )
        
        assert applicant.id == "001"
        assert applicant.name == "Alice Johnson"
        assert applicant.gpa == 3.8
        assert applicant.sat_score == 1350
        assert applicant.act_score == 28
        assert applicant.ethnicity == "White"
        assert applicant.gender == "Female"
        assert applicant.income_level == "Medium"
        assert applicant.rural_location is False
        assert applicant.first_generation is True
        assert applicant.migrant_background is False
        assert applicant.community_profile == CommunityProfile.STANDARD
        assert applicant.holistic_score == 0.0
        assert applicant.decision == AdmissionDecision.REJECT

    def test_applicant_with_default_values(self):
        """Test applicant creation with default values."""
        applicant = Applicant(
            id="002",
            name="Bob Smith",
            gpa=3.2,
            sat_score=1100,
            act_score=24,
            ethnicity="Hispanic",
            gender="Male",
            income_level="Low",
            rural_location=True,
            first_generation=False,
            migrant_background=False
        )
        
        assert applicant.community_profile == CommunityProfile.STANDARD
        assert applicant.holistic_score == 0.0
        assert applicant.decision == AdmissionDecision.REJECT


class TestUniversityAdmissionsSystem:
    """Test cases for UniversityAdmissionsSystem class."""
    
    def test_system_initialization(self):
        """Test system initialization."""
        system = UniversityAdmissionsSystem()
        
        assert system.applicants == []
        assert system.weights == {
            'gpa': 0.3,
            'sat': 0.3,
            'act': 0.2,
            'demographics': 0.2
        }
        assert system.thresholds == {
            'admit': 80.0,
            'waitlist': 60.0
        }
        assert system.community_thresholds == {
            'first_gen': 70.0,
            'income_low': 75.0,
            'rural': 72.0,
            'migrant': 78.0
        }
    
    def test_add_applicant(self):
        """Test adding applicant to system."""
        system = UniversityAdmissionsSystem()
        applicant = Applicant(
            id="001",
            name="Alice Johnson",
            gpa=3.8,
            sat_score=1350,
            act_score=28,
            ethnicity="White",
            gender="Female",
            income_level="Medium",
            rural_location=False,
            first_generation=True,
            migrant_background=False
        )
        
        system.add_applicant(applicant)
        assert len(system.applicants) == 1
        assert system.applicants[0] is applicant
    
    def test_calculate_gpa_score(self):
        """Test GPA score calculation."""
        system = UniversityAdmissionsSystem()
        
        # Test normal cases
        assert system._calculate_gpa_score(4.0) == 100.0
        assert system._calculate_gpa_score(3.0) == 75.0
        assert system._calculate_gpa_score(2.0) == 50.0
        assert system._calculate_gpa_score(0.0) == 0.0
        
        # Test boundary conditions
        assert system._calculate_gpa_score(5.0) == 100.0  # Cap at 100
        assert system._calculate_gpa_score(-1.0) == 0.0   # Floor at 0
    
    def test_calculate_test_score(self):
        """Test test score calculation."""
        system = UniversityAdmissionsSystem()
        
        # Test SAT only
        assert system._calculate_test_score(1600, 0) == 100.0
        assert system._calculate_test_score(800, 0) == 50.0
        assert system._calculate_test_score(0, 0) == 0.0
        
        # Test ACT only
        assert system._calculate_test_score(0, 36) == 100.0
        assert system._calculate_test_score(0, 18) == 50.0
        assert system._calculate_test_score(0, 0) == 0.0
        
        # Test both SAT and ACT
        assert system._calculate_test_score(1600, 36) == 100.0  # Average of 100
        assert system._calculate_test_score(800, 18) == 50.0   # Average of 50
    
    def test_calculate_demographics_score(self):
        """Test demographics score calculation."""
        system = UniversityAdmissionsSystem()
        
        # Test with first generation
        applicant = Applicant(
            id="001",
            name="Alice Johnson",
            gpa=3.8,
            sat_score=1350,
            act_score=28,
            ethnicity="White",
            gender="Female",
            income_level="Medium",
            rural_location=False,
            first_generation=True,
            migrant_background=False
        )
        
        # Mock the _calculate_demographics_score method to return a known value
        with patch.object(system, '_calculate_demographics_score', return_value=10.0):
            # This would be called internally by process_applicants
            pass
    
    def test_assign_community_profile_first_generation(self):
        """Test community profile assignment for first generation."""
        system = UniversityAdmissionsSystem()
        
        applicant = Applicant(
            id="001",
            name="Alice Johnson",
            gpa=3.8,
            sat_score=1350,
            act_score=28,
            ethnicity="White",
            gender="Female",
            income_level="Medium",
            rural_location=False,
            first_generation=True,
            migrant_background=False
        )
        
        # Assign community profile manually
        system._assign_community_profile(applicant)
        assert applicant.community_profile == CommunityProfile.FIRST_GENERATION
    
    def test_assign_community_profile_rural(self):
        """Test community profile assignment for rural background."""
        system = UniversityAdmissionsSystem()
        
        applicant = Applicant(
            id="001",
            name="Alice Johnson",
            gpa=3.8,
            sat_score=1350,
            act_score=28,
            ethnicity="White",
            gender="Female",
            income_level="Medium",
            rural_location=True,
            first_generation=False,
            migrant_background=False
        )
        
        # Assign community profile manually
        system._assign_community_profile(applicant)
        assert applicant.community_profile == CommunityProfile.RURAL
    
    def test_assign_community_profile_migrant(self):
        """Test community profile assignment for migrant background."""
        system = UniversityAdmissionsSystem()
        
        applicant = Applicant(
            id="001",
            name="Alice Johnson",
            gpa=3.8,
            sat_score=1350,
            act_score=28,
            ethnicity="White",
            gender="Female",
            income_level="Medium",
            rural_location=False,
            first_generation=False,
            migrant_background=True
        )
        
        # Assign community profile manually
        system._assign_community_profile(applicant)
        assert applicant.community_profile == CommunityProfile.MIGRANT
    
    def test_assign_community_profile_none(self):
        """Test community profile assignment for no special background."""
        system = UniversityAdmissionsSystem()
        
        applicant = Applicant(
            id="001",
            name="Alice Johnson",
            gpa=3.8,
            sat_score=1350,
            act_score=28,
            ethnicity="White",
            gender="Female",
            income_level="Medium",
            rural_location=False,
            first_generation=False,
            migrant_background=False
        )
        
        # Assign community profile manually
        system._assign_community_profile(applicant)
        assert applicant.community_profile == CommunityProfile.STANDARD
    
    def test_process_applicants(self):
        """Test processing of applicants."""
        system = UniversityAdmissionsSystem()
        
        # Add sample applicants
        create_sample_applicants(system)
        
        # Process applicants
        system.process_applicants()
        
        # Verify that all applicants have been processed
        for applicant in system.applicants:
            assert applicant.holistic_score > 0.0
            assert applicant.decision in [AdmissionDecision.ADMIT, AdmissionDecision.WAITLIST, AdmissionDecision.REJECT]
    
    def test_generate_summary_report(self):
        """Test summary report generation."""
        system = UniversityAdmissionsSystem()
        
        # Add sample applicants
        create_sample_applicants(system)
        
        # Process applicants
        system.process_applicants()
        
        # Generate report
        report = system.generate_summary_report()
        
        # Verify report structure
        assert isinstance(report, dict)
        assert 'total_applicants' in report
        assert 'average_holistic_score' in report
        assert 'median_holistic_score' in report
        assert 'standard_deviation' in report
        assert 'decision_distribution' in report
        assert 'community_profile_distribution' in report
        assert 'weighted_criteria' in report
        assert 'admission_thresholds' in report
        
        # Verify values
        assert report['total_applicants'] == 10
        assert isinstance(report['average_holistic_score'], float)
        assert isinstance(report['median_holistic_score'], float)
        assert isinstance(report['standard_deviation'], float)
        assert isinstance(report['decision_distribution'], dict)
        assert isinstance(report['community_profile_distribution'], dict)
        assert isinstance(report['weighted_criteria'], dict)
        assert isinstance(report['admission_thresholds'], dict)
    
    def test_get_applicants_requiring_additional_review(self):
        """Test getting applicants requiring additional review."""
        system = UniversityAdmissionsSystem()
        
        # Add sample applicants
        create_sample_applicants(system)
        
        # Process applicants
        system.process_applicants()
        
        # Get applicants requiring additional review
        additional_review = system.get_applicants_requiring_additional_review()
        
        # Should return a list
        assert isinstance(additional_review, list)
        
        # Check that all returned applicants have special community profiles
        for applicant in additional_review:
            assert applicant.community_profile in [
                CommunityProfile.FIRST_GENERATION,
                CommunityProfile.RURAL,
                CommunityProfile.MIGRANT
            ]
    
    def test_export_data(self):
        """Test data export functionality."""
        system = UniversityAdmissionsSystem()
        
        # Add sample applicants
        create_sample_applicants(system)
        
        # Process applicants
        system.process_applicants()
        
        # Export data
        system.export_data("test_export.json")
        
        # Verify file was created and contains valid JSON
        with open("test_export.json", "r") as f:
            data = json.load(f)
        
        assert isinstance(data, dict)
        assert "applicants" in data
        assert len(data["applicants"]) == 10
    
    def test_empty_system_report(self):
        """Test report generation with empty system."""
        system = UniversityAdmissionsSystem()
        
        # Generate report for empty system
        report = system.generate_summary_report()
        
        # Verify report structure for empty system
        assert report['total_applicants'] == 0
        assert report['average_holistic_score'] == 0.0
        assert report['median_holistic_score'] == 0.0
        assert report['standard_deviation'] == 0.0
        assert report['decision_distribution'] == {}
        assert report['community_profile_distribution'] == {}
    
    def test_decision_assignment(self):
        """Test decision assignment logic."""
        system = UniversityAdmissionsSystem()
        
        # Create an applicant with a high score
        applicant = Applicant(
            id="001",
            name="High Scorer",
            gpa=4.0,
            sat_score=1600,
            act_score=36,
            ethnicity="White",
            gender="Female",
            income_level="High",
            rural_location=False,
            first_generation=False,
            migrant_background=False
        )
        
        system.add_applicant(applicant)
        
        # Manually calculate a high score for this applicant
        # This is a simplified test - in reality, the full process would be complex
        applicant.holistic_score = 95.0
        applicant.decision = system._assign_decision(applicant.holistic_score)
        
        assert applicant.decision == AdmissionDecision.ADMIT
    
    def test_boundary_conditions(self):
        """Test boundary conditions for calculations."""
        system = UniversityAdmissionsSystem()
        
        # Test very high GPA
        assert system._calculate_gpa_score(5.0) == 100.0
        
        # Test very low GPA
        assert system._calculate_gpa_score(-1.0) == 0.0
        
        # Test very high SAT score
        assert system._calculate_test_score(2400, 0) == 100.0
        
        # Test very low SAT score
        assert system._calculate_test_score(0, 0) == 0.0
        
        # Test very high ACT score
        assert system._calculate_test_score(0, 36) == 100.0
        
        # Test very low ACT score
        assert system._calculate_test_score(0, 0) == 0.0


class TestSystemIntegration:
    """Test integration of system components."""
    
    def test_complete_workflow(self):
        """Test complete workflow from creation to reporting."""
        system = UniversityAdmissionsSystem()
        
        # Add sample data
        create_sample_applicants(system)
        
        # Process applicants
        system.process_applicants()
        
        # Generate report
        report = system.generate_summary_report()
        
        # Verify report has expected structure
        expected_keys = [
            'total_applicants', 'average_holistic_score', 'median_holistic_score',
            'standard_deviation', 'decision_distribution', 'community_profile_distribution',
            'weighted_criteria', 'admission_thresholds'
        ]
        
        for key in expected_keys:
            assert key in report
        
        # Verify decision distribution has expected keys
        assert 'admit' in report['decision_distribution']
        assert 'waitlist' in report['decision_distribution']
        assert 'reject' in report['decision_distribution']
        
        # Verify community profile distribution has expected keys
        assert 'standard' in report['community_profile_distribution']
        assert 'first_generation' in report['community_profile_distribution']
        assert 'rural' in report['community_profile_distribution']
        assert 'migrant' in report['community_profile_distribution']
    
    def test_sample_applicant_creation(self):
        """Test creation of sample applicants."""
        system = UniversityAdmissionsSystem()
        
        # Add sample applicants
        create_sample_applicants(system)
        
        # Verify all 10 applicants were added
        assert len(system.applicants) == 10
        
        # Verify each applicant has required attributes
        for applicant in system.applicants:
            assert hasattr(applicant, 'id')
            assert hasattr(applicant, 'name')
            assert hasattr(applicant, 'gpa')
            assert hasattr(applicant, 'sat_score')
            assert hasattr(applicant, 'act_score')
            assert hasattr(applicant, 'ethnicity')
            assert hasattr(applicant, 'gender')
            assert hasattr(applicant, 'income_level')
            assert hasattr(applicant, 'rural_location')
            assert hasattr(applicant, 'first_generation')
            assert hasattr(applicant, 'migrant_background')
            assert hasattr(applicant, 'holistic_score')
            assert hasattr(applicant, 'decision')
            assert hasattr(applicant, 'community_profile')


def create_sample_applicants(system):
    """Helper function to create sample applicants."""
    applicants = [
        Applicant(
            id="001",
            name="Alice Johnson",
            gpa=3.8,
            sat_score=1350,
            act_score=28,
            ethnicity="White",
            gender="Female",
            income_level="Medium",
            rural_location=False,
            first_generation=True,
            migrant_background=False
        ),
        Applicant(
            id="002",
            name="Bob Smith",
            gpa=3.5,
            sat_score=1200,
            act_score=24,
            ethnicity="Hispanic",
            gender="Male",
            income_level="Low",
            rural_location=True,
            first_generation=False,
            migrant_background=False
        ),
        Applicant(
            id="003",
            name="Carol Williams",
            gpa=4.0,
            sat_score=1500,
            act_score=32,
            ethnicity="Asian",
            gender="Female",
            income_level="High",
            rural_location=False,
            first_generation=False,
            migrant_background=True
        ),
        Applicant(
            id="004",
            name="David Brown",
            gpa=3.2,
            sat_score=1100,
            act_score=20,
            ethnicity="Black",
            gender="Male",
            income_level="Low",
            rural_location=False,
            first_generation=False,
            migrant_background=False
        ),
        Applicant(
            id="005",
            name="Eva Davis",
            gpa=3.9,
            sat_score=1400,
            act_score=29,
            ethnicity="White",
            gender="Female",
            income_level="Medium",
            rural_location=False,
            first_generation=False,
            migrant_background=False
        ),
        Applicant(
            id="006",
            name="Frank Miller",
            gpa=3.7,
            sat_score=1300,
            act_score=27,
            ethnicity="White",
            gender="Male",
            income_level="Medium",
            rural_location=True,
            first_generation=False,
            migrant_background=False
        ),
        Applicant(
            id="007",
            name="Grace Wilson",
            gpa=3.4,
            sat_score=1250,
            act_score=25,
            ethnicity="Hispanic",
            gender="Female",
            income_level="Low",
            rural_location=False,
            first_generation=True,
            migrant_background=False
        ),
        Applicant(
            id="008",
            name="Henry Moore",
            gpa=3.6,
            sat_score=1320,
            act_score=26,
            ethnicity="Black",
            gender="Male",
            income_level="Low",
            rural_location=False,
            first_generation=False,
            migrant_background=True
        ),
        Applicant(
            id="009",
            name="Ivy Taylor",
            gpa=3.8,
            sat_score=1380,
            act_score=28,
            ethnicity="Asian",
            gender="Female",
            income_level="Medium",
            rural_location=False,
            first_generation=False,
            migrant_background=False
        ),
        Applicant(
            id="010",
            name="Jack Anderson",
            gpa=3.3,
            sat_score=1150,
            act_score=22,
            ethnicity="White",
            gender="Male",
            income_level="Low",
            rural_location=False,
            first_generation=False,
            migrant_background=False
        )
    ]
    
    for applicant in applicants:
        system.add_applicant(applicant)


# Test the system
if __name__ == "__main__":
    # Run tests
    print("Running system tests...")
    
    # Test system creation
    system = UniversityAdmissionsSystem()
    print("System created successfully")
    
    # Test sample applicant creation
    create_sample_applicants(system)
    print("Sample applicants created successfully")
    
    # Test processing
    system.process_applicants()
    print("Applicants processed successfully")
    
    # Test report generation
    report = system.generate_summary_report()
    print("Report generated successfully")
    
    # Test export
    system.export_data("test_output.json")
    print("Data exported successfully")
    
    print("All tests completed successfully!")