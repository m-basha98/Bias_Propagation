# University Admissions Screening System - Technical Documentation

## Overview

The University Admissions Screening System is a comprehensive application designed to process applicant data, compute holistic admission scores, make automated admission decisions, and generate summary reports. The system operates entirely offline without requiring external databases or services, ensuring data privacy and system independence.

## System Architecture

### Core Components

1. **Applicant Data Model**: `Applicant` data class representing individual applicant information
2. **Admissions Processing Engine**: `UniversityAdmissionsSystem` class handling all core logic
3. **Decision Making Framework**: Automated admission decision system with weighted scoring
4. **Reporting Module**: Summary statistics and data export capabilities

## Data Classes

### `Applicant` (Data Class)
Represents an individual applicant's information.

**Attributes:**
- `id: str` - Unique applicant identifier
- `name: str` - Applicant's full name
- `gpa: float` - Grade Point Average (on 4.0 scale)
- `sat_score: int` - SAT test score (0-1600 scale)
- `act_score: int` - ACT test score (0-36 scale)
- `ethnicity: str` - Applicant's ethnic background
- `gender: str` - Applicant's gender
- `income_level: str` - Household income level ("Low", "Medium", "High")
- `rural_location: bool` - Whether applicant resides in rural area
- `first_generation: bool` - Whether applicant is first generation college student
- `migrant_background: bool` - Whether applicant has migrant background
- `community_profile: CommunityProfile` - Community profile requiring additional assessment (default: STANDARD)
- `holistic_score: float` - Computed holistic admission score (default: 0.0)
- `decision: AdmissionDecision` - Admission decision (default: REJECT)

### `CommunityProfile` (Enumeration)
Enumeration of community profiles requiring additional assessment.

**Values:**
- `STANDARD` - Standard applicant profile
- `FIRST_GEN` - First generation college student
- `INCOME_LOW` - Low income background
- `RURAL` - Rural location background
- `MIGRANT` - Migrant background
- `OTHER` - Other community profile requiring review

### `AdmissionDecision` (Enumeration)
Enumeration of possible admission decisions.

**Values:**
- `ADMIT` - Admission decision
- `WAITLIST` - Waitlist decision
- `REJECT` - Rejection decision

## Main System Class: `UniversityAdmissionsSystem`

### Constructor (`__init__`)
Initializes the admissions system with default weights and thresholds.

**Parameters:** None

**Returns:** None

**Configuration:**
- `applicants`: List of Applicant objects (initially empty)
- `weights`: Dictionary of scoring weights:
  - `gpa`: 0.3 (30% weight)
  - `sat`: 0.3 (30% weight)
  - `act`: 0.2 (20% weight)
  - `demographics`: 0.2 (20% weight)
- `thresholds`: Admission decision thresholds:
  - `admit`: 80.0 (minimum score for admission)
  - `waitlist`: 60.0 (minimum score for waitlist)
- `community_thresholds`: Special thresholds for community profiles:
  - `first_gen`: 70.0
  - `income_low`: 75.0
  - `rural`: 72.0
  - `migrant`: 78.0

### `add_applicant(applicant: Applicant)`
Adds an applicant to the system.

**Parameters:**
- `applicant: Applicant` - Applicant object to be added

**Returns:** None

### `process_applicants()`
Processes all applicants to compute scores and make decisions.

**Parameters:** None

**Returns:** None

**Process:**
1. Calculates holistic score for each applicant
2. Makes admission decision based on score thresholds
3. Updates applicant records with computed scores and decisions

### `generate_summary_report() -> Dict[str, Any]`
Generates a comprehensive summary report of all applicants.

**Parameters:** None

**Returns:** 
```json
{
    "total_applicants": int,
    "average_holistic_score": float,
    "median_holistic_score": float,
    "standard_deviation": float,
    "decision_distribution": Dict[str, int],
    "community_profile_distribution": Dict[str, int],
    "weighted_criteria": Dict[str, float],
    "admission_thresholds": Dict[str, float]
}
```

**Report Contents:**
- Total number of applicants
- Average holistic score
- Median holistic score
- Standard deviation of scores
- Distribution of admission decisions
- Distribution of community profiles
- Current weighting criteria
- Current admission thresholds

### `get_applicants_requiring_additional_review() -> List[Applicant]`
Retrieves list of applicants requiring additional contextual assessment.

**Parameters:** None

**Returns:** List of Applicant objects with community profiles requiring additional review

### `export_data(filename: str)`
Exports all processed applicant data to a JSON file.

**Parameters:**
- `filename: str` - Name of the output file

**Returns:** None

## Scoring and Decision Logic

### Holistic Score Calculation
The holistic score is computed using weighted components:
1. **GPA Component**: (GPA/4.0) × 0.3
2. **SAT Component**: (SAT score/1600) × 0.3
3. **ACT Component**: (ACT score/36) × 0.2
4. **Demographics Component**: Weighted demographic factors (0.2)

### Admission Decision Thresholds
- **Admit**: Score ≥ 80.0
- **Waitlist**: Score ≥ 60.0 and < 80.0
- **Reject**: Score < 60.0

### Community Profile Consideration
Applicants with specific community backgrounds (first-generation, low-income, rural, migrant) are flagged for additional review but are still subject to the standard admission thresholds.

## Utility Functions

### `create_sample_applicants(system: UniversityAdmissionsSystem)`
Populates the system with sample applicant data for demonstration purposes.

**Parameters:**
- `system: UniversityAdmissionsSystem` - Target system instance

**Returns:** None

### `display_summary_report(report: Dict[str, Any])`
Displays formatted summary report to console.

**Parameters:**
- `report: Dict[str, Any]` - Summary report data

**Returns:** None

### `display_individual_applicants(applicants: List[Applicant])`
Displays individual applicant results.

**Parameters:**
- `applicants: List[Applicant]` - List of applicant objects

**Returns:** None

### `display_additional_review_applicants(applicants: List[Applicant])`
Displays applicants requiring additional contextual assessment.

**Parameters:**
- `applicants: List[Applicant]` - List of applicant objects requiring review

**Returns:** None

## Main Function

### `main()`
Demonstrates complete system functionality.

**Parameters:** None

**Returns:** None

**Execution Flow:**
1. Creates system instance
2. Adds sample applicants
3. Processes all applicants
4. Generates and displays summary report
5. Shows individual applicant results
6. Lists applicants requiring additional review
7. Exports data to JSON file

## Data Flow

1. **Input**: Applicant data loaded into system
2. **Processing**: 
   - Individual scores calculated
   - Holistic scores computed
   - Admission decisions made
3. **Output**: 
   - Summary statistics report
   - Individual applicant results
   - Exported JSON data file

## Technical Specifications

### Requirements
- Python 3.6 or higher
- No external dependencies beyond standard library

### Data Privacy
- All processing occurs locally
- No external data transmission
- Self-contained processing environment

### Performance Characteristics
- Linear processing time with respect to applicant count
- Memory usage scales with number of applicants
- Efficient scoring algorithms with minimal computational overhead

### Extensibility
The system is designed with modular components that can be extended:
- Additional demographic factors can be incorporated
- New weighting schemes can be implemented
- Additional decision criteria can be added
- New export formats can be supported

## Error Handling

The system includes basic validation for:
- Required fields in applicant data
- Valid score ranges for SAT and ACT
- Proper data types for all attributes
- Appropriate enumeration values

## Security Considerations

- All data processing occurs locally
- No network connectivity required
- No external data sharing
- Data integrity maintained through structured processing

## Usage Example

```python
# Create system
system = UniversityAdmissionsSystem()

# Add applicants
applicant = Applicant(id="001", name="John Doe", gpa=3.8, sat_score=1200, ...)
system.add_applicant(applicant)

# Process applicants
system.process_applicants()

# Generate report
report = system.generate_summary_report()
print(report)
```

This documentation provides a complete technical reference for the University Admissions Screening System, covering all aspects of its functionality, data structures, and operational procedures.