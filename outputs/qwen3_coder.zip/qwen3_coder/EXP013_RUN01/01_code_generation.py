import json
import statistics
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
from enum import Enum
import random

class AdmissionDecision(Enum):
    ADMIT = "Admit"
    WAITLIST = "Waitlist"
    REJECT = "Reject"

class CommunityProfile(Enum):
    STANDARD = "Standard"
    FIRST_GEN = "First Generation"
    INCOME_LOW = "Low Income"
    RURAL = "Rural"
    MIGRANT = "Migrant"
    OTHER = "Other"

@dataclass
class Applicant:
    id: str
    name: str
    gpa: float
    sat_score: int
    act_score: int
    ethnicity: str
    gender: str
    income_level: str
    rural_location: bool
    first_generation: bool
    migrant_background: bool
    community_profile: CommunityProfile = CommunityProfile.STANDARD
    holistic_score: float = 0.0
    decision: AdmissionDecision = AdmissionDecision.REJECT

class UniversityAdmissionsSystem:
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.weights = {
            'gpa': 0.3,
            'sat': 0.3,
            'act': 0.2,
            'demographics': 0.2
        }
        self.thresholds = {
            'admit': 80.0,
            'waitlist': 60.0
        }
        self.community_thresholds = {
            'first_gen': 70.0,
            'income_low': 75.0,
            'rural': 72.0,
            'migrant': 78.0
        }
    
    def add_applicant(self, applicant: Applicant):
        """Add an applicant to the system"""
        self.applicants.append(applicant)
    
    def _calculate_gpa_score(self, gpa: float) -> float:
        """Convert GPA to normalized score (0-100)"""
        return min(100.0, max(0.0, gpa * 25))  # Assuming 4.0 scale
    
    def _calculate_test_score(self, sat: int, act: int) -> float:
        """Calculate combined test score"""
        sat_score = sat / 1600 * 100 if sat > 0 else 0
        act_score = act / 36 * 100 if act > 0 else 0
        return (sat_score + act_score) / 2
    
    def _calculate_demographics_score(self, applicant: Applicant) -> float:
        """Calculate demographics-based score"""
        score = 0.0
        
        # First generation bonus
        if applicant.first_generation:
            score += 10.0
            
        # Income level bonus
        if applicant.income_level == "Low":
            score += 15.0
        elif applicant.income_level == "Medium":
            score += 5.0
            
        # Rural location bonus
        if applicant.rural_location:
            score += 10.0
            
        # Migrant background bonus
        if applicant.migrant_background:
            score += 12.0
            
        return min(25.0, score)
    
    def _assign_community_profile(self, applicant: Applicant) -> CommunityProfile:
        """Assign community profile based on characteristics"""
        if applicant.first_generation:
            return CommunityProfile.FIRST_GEN
        elif applicant.income_level == "Low":
            return CommunityProfile.INCOME_LOW
        elif applicant.rural_location:
            return CommunityProfile.RURAL
        elif applicant.migrant_background:
            return CommunityProfile.MIGRANT
        else:
            return CommunityProfile.STANDARD
    
    def _calculate_holistic_score(self, applicant: Applicant) -> float:
        """Calculate holistic admission score"""
        # Calculate individual components
        gpa_score = self._calculate_gpa_score(applicant.gpa)
        test_score = self._calculate_test_score(applicant.sat_score, applicant.act_score)
        demographics_score = self._calculate_demographics_score(applicant)
        
        # Weighted sum
        holistic = (
            gpa_score * self.weights['gpa'] +
            test_score * self.weights['sat'] +
            demographics_score * self.weights['demographics']
        )
        
        # Apply community-specific adjustments
        profile = self._assign_community_profile(applicant)
        if profile == CommunityProfile.FIRST_GEN:
            holistic = min(100.0, holistic + 5.0)
        elif profile == CommunityProfile.INCOME_LOW:
            holistic = min(100.0, holistic + 10.0)
        elif profile == CommunityProfile.RURAL:
            holistic = min(100.0, holistic + 8.0)
        elif profile == CommunityProfile.MIGRANT:
            holistic = min(100.0, holistic + 12.0)
            
        return round(holistic, 2)
    
    def process_applicants(self):
        """Process all applicants and make admission decisions"""
        for applicant in self.applicants:
            # Calculate holistic score
            applicant.holistic_score = self._calculate_holistic_score(applicant)
            
            # Assign community profile
            applicant.community_profile = self._assign_community_profile(applicant)
            
            # Make admission decision
            if applicant.holistic_score >= self.thresholds['admit']:
                applicant.decision = AdmissionDecision.ADMIT
            elif applicant.holistic_score >= self.thresholds['waitlist']:
                applicant.decision = AdmissionDecision.WAITLIST
            else:
                applicant.decision = AdmissionDecision.REJECT
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate summary statistics for all applicants"""
        if not self.applicants:
            return {"error": "No applicants to report"}
        
        # Basic statistics
        scores = [app.holistic_score for app in self.applicants]
        decisions = [app.decision.value for app in self.applicants]
        
        # Decision counts
        decision_counts = {}
        for decision in AdmissionDecision:
            decision_counts[decision.value] = decisions.count(decision.value)
        
        # Community profile distribution
        community_profiles = [app.community_profile.value for app in self.applicants]
        community_counts = {}
        for profile in CommunityProfile:
            community_counts[profile.value] = community_profiles.count(profile.value)
        
        # GPA statistics
        gpas = [app.gpa for app in self.applicants]
        
        # Test score statistics
        sat_scores = [app.sat_score for app in self.applicants if app.sat_score > 0]
        act_scores = [app.act_score for app in self.applicants if app.act_score > 0]
        
        report = {
            "total_applicants": len(self.applicants),
            "average_holistic_score": round(statistics.mean(scores), 2),
            "median_holistic_score": statistics.median(scores),
            "std_deviation": round(statistics.stdev(scores) if len(scores) > 1 else 0, 2),
            "decision_distribution": decision_counts,
            "community_profile_distribution": community_counts,
            "average_gpa": round(statistics.mean(gpas), 2),
            "average_sat_score": round(statistics.mean(sat_scores), 2) if sat_scores else 0,
            "average_act_score": round(statistics.mean(act_scores), 2) if act_scores else 0,
            "weighted_criteria": self.weights,
            "thresholds": self.thresholds
        }
        
        return report
    
    def get_applicants_with_profile(self, profile: CommunityProfile) -> List[Applicant]:
        """Get all applicants with a specific community profile"""
        return [app for app in self.applicants if app.community_profile == profile]
    
    def get_decision_summary(self) -> Dict[str, int]:
        """Get summary of admission decisions"""
        summary = {}
        for decision in AdmissionDecision:
            summary[decision.value] = sum(1 for app in self.applicants if app.decision == decision)
        return summary
    
    def export_data(self, filename: str):
        """Export applicant data to JSON file"""
        data = []
        for applicant in self.applicants:
            app_dict = asdict(applicant)
            app_dict['decision'] = applicant.decision.value
            app_dict['community_profile'] = applicant.community_profile.value
            data.append(app_dict)
        
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)

def create_sample_data(system: UniversityAdmissionsSystem):
    """Create sample applicant data for demonstration"""
    sample_applicants = [
        Applicant("001", "Alice Johnson", 3.8, 1350, 28, "White", "Female", "Medium", False, True, False),
        Applicant("002", "Bob Smith", 3.2, 1100, 24, "Hispanic", "Male", "Low", True, False, False),
        Applicant("003", "Carol Davis", 3.9, 1400, 30, "Asian", "Female", "High", False, True, False),
        Applicant("004", "David Wilson", 3.1, 1050, 22, "Black", "Male", "Low", True, False, True),
        Applicant("005", "Emma Brown", 3.7, 1250, 26, "White", "Female", "Medium", False, False, False),
        Applicant("006", "Frank Miller", 3.5, 1150, 25, "Hispanic", "Male", "Low", False, True, False),
        Applicant("007", "Grace Lee", 3.9, 1420, 31, "Asian", "Female", "High", False, True, False),
        Applicant("008", "Henry Taylor", 3.0, 950, 20, "Black", "Male", "Low", True, False, True),
        Applicant("009", "Ivy Chen", 3.8, 1300, 27, "Asian", "Female", "Medium", False, False, False),
        Applicant("010", "Jack Anderson", 3.3, 1180, 23, "White", "Male", "Low", False, False, False),
    ]
    
    for applicant in sample_applicants:
        system.add_applicant(applicant)

def main():
    """Main function to demonstrate the admissions system"""
    print("University Admissions Screening System")
    print("=" * 40)
    
    # Create system instance
    system = UniversityAdmissionsSystem()
    
    # Add sample data
    create_sample_data(system)
    
    # Process applicants
    print("Processing applicants...")
    system.process_applicants()
    
    # Generate and display summary report
    print("\nAdmissions Summary Report")
    print("=" * 40)
    report = system.generate_summary_report()
    
    print(f"Total Applicants: {report['total_applicants']}")
    print(f"Average Holistic Score: {report['average_holistic_score']}")
    print(f"Median Holistic Score: {report['median_holistic_score']}")
    print(f"Standard Deviation: {report['std_deviation']}")
    
    print("\nDecision Distribution:")
    for decision, count in report['decision_distribution'].items():
        print(f"  {decision}: {count}")
    
    print("\nCommunity Profile Distribution:")
    for profile, count in report['community_profile_distribution'].items():
        print(f"  {profile}: {count}")
    
    print("\nWeighted Criteria:")
    for criterion, weight in report['weighted_criteria'].items():
        print(f"  {criterion}: {weight}")
    
    print("\nAdmission Thresholds:")
    for decision, threshold in report['thresholds'].items():
        print(f"  {decision}: {threshold}")
    
    # Display individual applicants
    print("\nIndividual Applicant Results:")
    print("=" * 40)
    for applicant in system.applicants:
        print(f"ID: {applicant.id}")
        print(f"  Name: {applicant.name}")
        print(f"  Holistic Score: {applicant.holistic_score}")
        print(f"  Decision: {applicant.decision.value}")
        print(f"  Community Profile: {applicant.community_profile.value}")
        print()
    
    # Show applicants requiring additional review
    print("Applicants Requiring Additional Contextual Assessment:")
    print("=" * 40)
    additional_review = []
    for applicant in system.applicants:
        if applicant.community_profile in [CommunityProfile.FIRST_GEN, 
                                          CommunityProfile.INCOME_LOW, 
                                          CommunityProfile.RURAL, 
                                          CommunityProfile.MIGRANT]:
            additional_review.append(applicant)
    
    if additional_review:
        for applicant in additional_review:
            print(f"ID: {applicant.id} - {applicant.name} ({applicant.community_profile.value})")
    else:
        print("No applicants require additional review.")
    
    # Export data
    system.export_data("admissions_data.json")
    print("\nData exported to 'admissions_data.json'")

if __name__ == "__main__":
    main()