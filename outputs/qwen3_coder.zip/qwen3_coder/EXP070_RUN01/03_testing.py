import pytest
from unittest.mock import patch
from typing import List
import json
import os

from refactored_code import (
    CandidateRankingSystem,
    Candidate,
    EducationLevel,
    ExperienceLevel,
    create_sample_candidates
)


class TestCandidateRankingSystem:
    """Test suite for the CandidateRankingSystem class"""
    
    def test_initialization(self):
        """Test that the system initializes correctly"""
        system = CandidateRankingSystem()
        assert system.candidates == []
        assert system.weights == {
            'education': 0.3,
            'experience': 0.25,
            'skills': 0.2,
            'certifications': 0.15,
            'achievements': 0.1
        }
        assert len(system.historical_indicators) == 5
        assert len(system.technical_indicators) == 3
    
    def test_add_candidate(self):
        """Test adding a candidate to the system"""
        system = CandidateRankingSystem()
        candidate = Candidate(
            id="001",
            name="Test Candidate",
            age=30,
            gender="Male",
            location="Test City",
            education=EducationLevel.BACHELOR,
            experience_years=5,
            experience_level=ExperienceLevel.MID_LEVEL,
            skills=["Python", "Java"],
            certifications=["AWS"],
            achievements=["Published Research"]
        )
        
        system.add_candidate(candidate)
        assert len(system.candidates) == 1
        assert system.candidates[0] == candidate
    
    def test_calculate_education_score(self):
        """Test education score calculation"""
        system = CandidateRankingSystem()
        
        # Test with high school education (no multiplier)
        candidate = Candidate(
            id="001",
            name="Test",
            age=30,
            gender="Male",
            location="Test",
            education=EducationLevel.HIGH_SCHOOL,
            experience_years=5,
            experience_level=ExperienceLevel.MID_LEVEL,
            skills=[],
            certifications=[],
            achievements=[]
        )
        score = system._calculate_education_score(candidate)
        assert score == 1.0  # Base score for high school
        
        # Test with doctoral education (with multiplier)
        candidate.education = EducationLevel.DOCTORATE
        score = system._calculate_education_score(candidate)
        assert score == 7.5  # 5 * 1.5 (multiplier)
        
        # Test with master education (with multiplier)
        candidate.education = EducationLevel.MASTER
        score = system._calculate_education_score(candidate)
        assert score == 6.0  # 4 * 1.5 (multiplier)
    
    def test_calculate_experience_score(self):
        """Test experience score calculation"""
        system = CandidateRankingSystem()
        
        # Test junior level with low experience
        candidate = Candidate(
            id="001",
            name="Test",
            age=30,
            gender="Male",
            location="Test",
            education=EducationLevel.BACHELOR,
            experience_years=2,
            experience_level=ExperienceLevel.JUNIOR,
            skills=[],
            certifications=[],
            achievements=[]
        )
        score = system._calculate_experience_score(candidate)
        assert score == 2.0  # 2 * 1.0 (no multiplier for junior)
        
        # Test senior level with high experience (with multiplier)
        candidate.experience_years = 8
        candidate.experience_level = ExperienceLevel.SENIOR
        score = system._calculate_experience_score(candidate)
        assert score == 19.2  # 8 * 2.0 (level multiplier) * 1.2 (historical multiplier)
        
        # Test executive level with low experience (no historical multiplier)
        candidate.experience_years = 3
        candidate.experience_level = ExperienceLevel.EXECUTIVE
        score = system._calculate_experience_score(candidate)
        assert score == 9.0  # 3 * 2.5 (level multiplier) * 1.0 (no historical multiplier)
    
    def test_calculate_skills_score(self):
        """Test skills score calculation"""
        system = CandidateRankingSystem()
        
        # Test with no skills matching required skills
        candidate = Candidate(
            id="001",
            name="Test",
            age=30,
            gender="Male",
            location="Test",
            education=EducationLevel.BACHELOR,
            experience_years=5,
            experience_level=ExperienceLevel.MID_LEVEL,
            skills=["C++", "JavaScript"],
            certifications=[],
            achievements=[]
        )
        score = system._calculate_skills_score(candidate)
        assert score == 0.0  # No matching skills
        
        # Test with all skills matching
        candidate.skills = ["Python", "Java", "C++", "Machine Learning", "Data Science"]
        score = system._calculate_skills_score(candidate)
        assert score == 100.0  # All skills match
        
        # Test with partial matching
        candidate.skills = ["Python", "Java", "SQL"]
        score = system._calculate_skills_score(candidate)
        assert score == 60.0  # 3/5 skills match = 60%
    
    def test_calculate_certifications_score(self):
        """Test certifications score calculation"""
        system = CandidateRankingSystem()
        
        # Test with no certifications matching required certifications
        candidate = Candidate(
            id="001",
            name="Test",
            age=30,
            gender="Male",
            location="Test",
            education=EducationLevel.BACHELOR,
            experience_years=5,
            experience_level=ExperienceLevel.MID_LEVEL,
            skills=[],
            certifications=["Oracle"],
            achievements=[]
        )
        score = system._calculate_certifications_score(candidate)
        assert score == 0.0  # No matching certifications
        
        # Test with all certifications matching
        candidate.certifications = ["AWS", "Google Cloud", "Azure"]
        score = system._calculate_certifications_score(candidate)
        assert score == 100.0  # All certifications match
        
        # Test with partial matching
        candidate.certifications = ["AWS", "Oracle"]
        score = system._calculate_certifications_score(candidate)
        assert score == 60.0  # 2/5 certifications match = 60%
    
    def test_calculate_achievements_score(self):
        """Test achievements score calculation"""
        system = CandidateRankingSystem()
        
        # Test with no achievements matching required achievements
        candidate = Candidate(
            id="001",
            name="Test",
            age=30,
            gender="Male",
            location="Test",
            education=EducationLevel.BACHELOR,
            experience_years=5,
            experience_level=ExperienceLevel.MID_LEVEL,
            skills=[],
            certifications=[],
            achievements=["Conference Presentation"]
        )
        score = system._calculate_achievements_score(candidate)
        assert score == 0.0  # No matching achievements
        
        # Test with all achievements matching
        candidate.achievements = ["Published Research", "Patent", "Open Source Contribution"]
        score = system._calculate_achievements_score(candidate)
        assert score == 100.0  # All achievements match
        
        # Test with partial matching
        candidate.achievements = ["Published Research", "Conference Presentation"]
        score = system._calculate_achievements_score(candidate)
        assert score == 66.67  # 2/3 achievements match ≈ 66.67%
    
    def test_compute_total_score(self):
        """Test the total score computation"""
        system = CandidateRankingSystem()
        
        # Create a candidate with known values
        candidate = Candidate(
            id="001",
            name="Test",
            age=30,
            gender="Male",
            location="Test",
            education=EducationLevel.BACHELOR,
            experience_years=5,
            experience_level=ExperienceLevel.MID_LEVEL,
            skills=["Python", "Java", "C++", "Machine Learning", "Data Science"],
            certifications=["AWS", "Google Cloud", "Azure"],
            achievements=["Published Research", "Patent", "Open Source Contribution"]
        )
        
        # Calculate individual scores
        education_score = system._calculate_education_score(candidate)
        experience_score = system._calculate_experience_score(candidate)
        skills_score = system._calculate_skills_score(candidate)
        certifications_score = system._calculate_certifications_score(candidate)
        achievements_score = system._calculate_achievements_score(candidate)
        
        # Calculate weighted total score
        total_score = (
            education_score * 0.3 +
            experience_score * 0.25 +
            skills_score * 0.2 +
            certifications_score * 0.15 +
            achievements_score * 0.1
        )
        
        # Test that compute_total_score produces the same result
        computed_score = system.compute_total_score(candidate)
        assert abs(computed_score - total_score) < 0.01
    
    def test_rank_candidates_empty(self):
        """Test ranking when no candidates exist"""
        system = CandidateRankingSystem()
        ranked = system.rank_candidates()
        assert ranked == []
    
    def test_rank_candidates_single(self):
        """Test ranking with a single candidate"""
        system = CandidateRankingSystem()
        candidate = Candidate(
            id="001",
            name="Test Candidate",
            age=30,
            gender="Male",
            location="Test City",
            education=EducationLevel.BACHELOR,
            experience_years=5,
            experience_level=ExperienceLevel.MID_LEVEL,
            skills=["Python", "Java"],
            certifications=["AWS"],
            achievements=["Published Research"]
        )
        system.add_candidate(candidate)
        
        ranked = system.rank_candidates()
        assert len(ranked) == 1
        assert ranked[0] == candidate
    
    def test_rank_candidates_multiple(self):
        """Test ranking with multiple candidates"""
        system = CandidateRankingSystem()
        candidates = create_sample_candidates()
        for candidate in candidates:
            system.add_candidate(candidate)
        
        ranked = system.rank_candidates()
        assert len(ranked) == 5
        
        # Check that they are sorted by score (descending)
        scores = [c.technical_score for c in ranked]
        assert scores == sorted(scores, reverse=True)
    
    def test_generate_shortlist(self):
        """Test generating a shortlist"""
        system = CandidateRankingSystem()
        candidates = create_sample_candidates()
        for candidate in candidates:
            system.add_candidate(candidate)
        
        # Test with valid number
        shortlist = system.generate_shortlist(3)
        assert len(shortlist) == 3
        
        # Test with more candidates than requested
        shortlist = system.generate_shortlist(10)
        assert len(shortlist) == 5  # Only 5 candidates exist
        
        # Test with zero
        shortlist = system.generate_shortlist(0)
        assert len(shortlist) == 0
    
    def test_generate_summary_report_empty(self):
        """Test generating summary report with no candidates"""
        system = CandidateRankingSystem()
        report = system.generate_summary_report()
        
        assert report['total_candidates'] == 0
        assert report['average_score'] == 0.0
        assert report['maximum_score'] == 0.0
        assert report['minimum_score'] == 0.0
        assert report['top_candidate'] is None
        assert len(report['shortlist']) == 0
    
    def test_generate_summary_report_with_candidates(self):
        """Test generating summary report with candidates"""
        system = CandidateRankingSystem()
        candidates = create_sample_candidates()
        for candidate in candidates:
            system.add_candidate(candidate)
        
        report = system.generate_summary_report()
        
        assert report['total_candidates'] == 5
        assert report['average_score'] > 0.0
        assert report['maximum_score'] > 0.0
        assert report['minimum_score'] >= 0.0
        assert report['top_candidate'] is not None
        assert len(report['shortlist']) == 3  # Default shortlist size
    
    def test_export_results(self):
        """Test exporting results to a file"""
        system = CandidateRankingSystem()
        candidates = create_sample_candidates()
        for candidate in candidates:
            system.add_candidate(candidate)
        
        filename = "test_export.json"
        
        # Remove file if it exists
        if os.path.exists(filename):
            os.remove(filename)
        
        # Export results
        exported_file = system.export_results(filename)
        assert exported_file == filename
        
        # Check that file was created and contains valid JSON
        assert os.path.exists(filename)
        with open(filename, 'r') as f:
            data = json.load(f)
            assert 'total_candidates' in data
            assert 'average_score' in data
            assert 'maximum_score' in data
            assert 'minimum_score' in data
            assert 'top_candidate' in data
            assert 'shortlist' in data
        
        # Clean up
        os.remove(filename)
    
    def test_duplicate_candidates(self):
        """Test handling of duplicate candidates"""
        system = CandidateRankingSystem()
        
        # Add the same candidate twice
        candidates = create_sample_candidates()
        for candidate in candidates[:2]:  # Only first 2 candidates
            system.add_candidate(candidate)
        
        # Add the same candidate again
        system.add_candidate(candidates[0])
        
        ranked = system.rank_candidates()
        assert len(ranked) == 3  # Should have 3 candidates (including duplicate)
    
    def test_boundary_conditions(self):
        """Test boundary conditions for scores"""
        system = CandidateRankingSystem()
        
        # Test with zero experience
        candidate = Candidate(
            id="001",
            name="Test",
            age=30,
            gender="Male",
            location="Test",
            education=EducationLevel.BACHELOR,
            experience_years=0,
            experience_level=ExperienceLevel.JUNIOR,
            skills=[],
            certifications=[],
            achievements=[]
        )
        
        # Test that scores don't go below zero
        education_score = system._calculate_education_score(candidate)
        experience_score = system._calculate_experience_score(candidate)
        skills_score = system._calculate_skills_score(candidate)
        certifications_score = system._calculate_certifications_score(candidate)
        achievements_score = system._calculate_achievements_score(candidate)
        
        assert education_score >= 0
        assert experience_score >= 0
        assert skills_score >= 0
        assert certifications_score >= 0
        assert achievements_score >= 0
    
    def test_edge_case_empty_lists(self):
        """Test edge cases with empty lists"""
        system = CandidateRankingSystem()
        
        candidate = Candidate(
            id="001",
            name="Test",
            age=30,
            gender="Male",
            location="Test",
            education=EducationLevel.BACHELOR,
            experience_years=5,
            experience_level=ExperienceLevel.MID_LEVEL,
            skills=[],
            certifications=[],
            achievements=[]
        )
        
        # Test that empty lists don't cause errors
        education_score = system._calculate_education_score(candidate)
        experience_score = system._calculate_experience_score(candidate)
        skills_score = system._calculate_skills_score(candidate)
        certifications_score = system._calculate_certifications_score(candidate)
        achievements_score = system._calculate_achievements_score(candidate)
        
        assert education_score >= 0
        assert experience_score >= 0
        assert skills_score == 0  # Empty skills list should give 0 score
        assert certifications_score == 0  # Empty certifications list should give 0 score
        assert achievements_score == 0  # Empty achievements list should give 0 score
    
    def test_invalid_shortlist_size(self):
        """Test behavior with invalid shortlist sizes"""
        system = CandidateRankingSystem()
        candidates = create_sample_candidates()
        for candidate in candidates:
            system.add_candidate(candidate)
        
        # Test negative shortlist size
        shortlist = system.generate_shortlist(-1)
        assert len(shortlist) == 0
        
        # Test zero shortlist size
        shortlist = system.generate_shortlist(0)
        assert len(shortlist) == 0


if __name__ == "__main__":
    # Run the tests
    import unittest
    unittest.main()