import json
import math
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from enum import Enum


class EducationLevel(Enum):
    """Enumeration for education levels"""
    HIGH_SCHOOL = 1
    ASSOCIATE = 2
    BACHELOR = 3
    MASTER = 4
    DOCTORATE = 5


class ExperienceLevel(Enum):
    """Enumeration for experience levels"""
    JUNIOR = 1
    MID_LEVEL = 2
    SENIOR = 3
    EXECUTIVE = 4


@dataclass
class Candidate:
    """Data class to represent a candidate"""
    id: str
    name: str
    age: int
    gender: str
    location: str
    education: EducationLevel
    experience_years: int
    experience_level: ExperienceLevel
    skills: List[str]
    certifications: List[str]
    achievements: List[str]
    technical_score: float = 0.0
    overall_score: float = 0.0


class CandidateRankingSystem:
    """Main ranking system implementation"""
    
    def __init__(self):
        self.candidates: List[Candidate] = []
        self.weights = {
            'education': 0.3,
            'experience': 0.25,
            'skills': 0.2,
            'certifications': 0.15,
            'achievements': 0.1
        }
        # Historical successful candidates indicators
        self.historical_indicators = {
            'education_levels': [EducationLevel.BACHELOR, EducationLevel.MASTER, EducationLevel.DOCTORATE],
            'experience_years': 5,
            'required_skills': ['Python', 'Java', 'C++', 'Machine Learning', 'Data Science'],
            'required_certifications': ['AWS', 'Azure', 'Google Cloud', 'Certified Data Scientist'],
            'achievement_types': ['Published Research', 'Open Source Contribution', 'Patent', 'Award']
        }
        self.technical_indicators = {
            'education_multiplier': 1.5,
            'achievement_multiplier': 2.0,
            'experience_multiplier': 1.2
        }
    
    def add_candidate(self, candidate: Candidate):
        """Add a candidate to the system"""
        self.candidates.append(candidate)
    
    def _calculate_education_score(self, candidate: Candidate) -> float:
        """Calculate education score with historical weighting"""
        base_score = candidate.education.value
        
        # Apply historical weighting for successful candidates
        if candidate.education in self.historical_indicators['education_levels']:
            base_score *= self.technical_indicators['education_multiplier']
        
        return base_score
    
    def _calculate_experience_score(self, candidate: Candidate) -> float:
        """Calculate experience score with historical weighting"""
        # Experience score based on years and level
        experience_score = candidate.experience_years
        
        # Apply experience level multiplier
        level_multiplier = {
            ExperienceLevel.JUNIOR: 1.0,
            ExperienceLevel.MID_LEVEL: 1.5,
            ExperienceLevel.SENIOR: 2.0,
            ExperienceLevel.EXECUTIVE: 2.5
        }
        
        experience_score *= level_multiplier[candidate.experience_level]
        
        # Apply historical weighting
        if candidate.experience_years >= self.historical_indicators['experience_years']:
            experience_score *= self.technical_indicators['experience_multiplier']
        
        return experience_score
    
    def _calculate_skills_score(self, candidate: Candidate) -> float:
        """Calculate skills score based on matching required skills"""
        required_skills = set(self.historical_indicators['required_skills'])
        candidate_skills = set(candidate.skills)
        
        # Calculate match percentage
        if required_skills:
            matching_skills = len(required_skills.intersection(candidate_skills))
            match_percentage = matching_skills / len(required_skills)
        else:
            match_percentage = 0
        
        return match_percentage * 100
    
    def _calculate_certifications_score(self, candidate: Candidate) -> float:
        """Calculate certifications score based on matching required certifications"""
        required_certs = set(self.historical_indicators['required_certifications'])
        candidate_certs = set(candidate.certifications)
        
        # Calculate match percentage
        if required_certs:
            matching_certs = len(required_certs.intersection(candidate_certs))
            match_percentage = matching_certs / len(required_certs)
        else:
            match_percentage = 0
        
        return match_percentage * 100
    
    def _calculate_achievements_score(self, candidate: Candidate) -> float:
        """Calculate achievements score with historical weighting"""
        achievement_types = set(self.historical_indicators['achievement_types'])
        candidate_achievements = set(candidate.achievements)
        
        # Calculate match percentage
        if achievement_types:
            matching_achievements = len(achievement_types.intersection(candidate_achievements))
            match_percentage = matching_achievements / len(achievement_types)
        else:
            match_percentage = 0
        
        # Apply historical weighting for successful candidates
        if matching_achievements > 0:
            match_percentage *= self.technical_indicators['achievement_multiplier']
        
        return match_percentage * 100
    
    def compute_candidate_score(self, candidate: Candidate) -> float:
        """Compute overall score for a candidate"""
        education_score = self._calculate_education_score(candidate)
        experience_score = self._calculate_experience_score(candidate)
        skills_score = self._calculate_skills_score(candidate)
        certifications_score = self._calculate_certifications_score(candidate)
        achievements_score = self._calculate_achievements_score(candidate)
        
        # Calculate weighted score
        total_score = (
            education_score * self.weights['education'] +
            experience_score * self.weights['experience'] +
            skills_score * self.weights['skills'] +
            certifications_score * self.weights['certifications'] +
            achievements_score * self.weights['achievements']
        )
        
        candidate.technical_score = total_score
        return total_score
    
    def rank_candidates(self) -> List[Candidate]:
        """Rank all candidates by their technical scores"""
        for candidate in self.candidates:
            self.compute_candidate_score(candidate)
        
        # Sort candidates by technical score in descending order
        return sorted(self.candidates, key=lambda x: x.technical_score, reverse=True)
    
    def generate_shortlist(self, count: int) -> List[Candidate]:
        """Generate a shortlist of top candidates"""
        ranked_candidates = self.rank_candidates()
        return ranked_candidates[:count]
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of the ranking results"""
        if not self.candidates:
            return {
                'total_candidates': 0,
                'average_score': 0.0,
                'maximum_score': 0.0,
                'minimum_score': 0.0,
                'top_candidate': None,
                'shortlist': []
            }
        
        ranked_candidates = self.rank_candidates()
        scores = [candidate.technical_score for candidate in ranked_candidates]
        
        return {
            'total_candidates': len(self.candidates),
            'average_score': sum(scores) / len(scores),
            'maximum_score': max(scores),
            'minimum_score': min(scores),
            'top_candidate': {
                'name': ranked_candidates[0].name,
                'id': ranked_candidates[0].id,
                'score': ranked_candidates[0].technical_score
            } if ranked_candidates else None,
            'shortlist': [
                {
                    'name': candidate.name,
                    'score': candidate.technical_score
                } for candidate in ranked_candidates[:3]
            ]
        }
    
    def export_results(self, filename: str) -> str:
        """Export ranking results to a JSON file"""
        report = self.generate_summary_report()
        with open(filename, 'w') as file:
            json.dump(report, file, indent=2)
        return filename


def create_sample_candidates() -> List[Candidate]:
    """Create sample candidate data for testing"""
    return [
        Candidate(
            id="001",
            name="Carol Williams",
            age=35,
            gender="Female",
            location="Boston",
            education=EducationLevel.DOCTORATE,
            experience_years=12,
            experience_level=ExperienceLevel.EXECUTIVE,
            skills=["Python", "Java", "Machine Learning", "Data Science", "SQL", "C++"],
            certifications=["AWS", "Azure", "Google Cloud", "Certified Data Scientist", "Certified Machine Learning"],
            achievements=["Published Research", "Open Source Contribution", "Patent", "Award"]
        ),
        Candidate(
            id="002",
            name="Eva Davis",
            age=40,
            gender="Female",
            location="Austin",
            education=EducationLevel.MASTER,
            experience_years=10,
            experience_level=ExperienceLevel.SENIOR,
            skills=["Python", "Java", "Machine Learning", "Data Science", "SQL", "C++", "R"],
            certifications=["AWS", "Google Cloud"],
            achievements=["Published Research", "Patent"]
        ),
        Candidate(
            id="003",
            name="David Brown",
            age=26,
            gender="Male",
            location="Seattle",
            education=EducationLevel.BACHELOR,
            experience_years=3,
            experience_level=ExperienceLevel.JUNIOR,
            skills=["Python", "SQL"],
            certifications=["AWS"],
            achievements=["Open Source Contribution"]
        ),
        Candidate(
            id="004",
            name="Carol Williams",
            age=35,
            gender="Female",
            location="Boston",
            education=EducationLevel.DOCTORATE,
            experience_years=12,
            experience_level=ExperienceLevel.EXECUTIVE,
            skills=["Python", "Java", "Machine Learning", "Data Science", "SQL", "C++"],
            certifications=["AWS", "Azure", "Google Cloud", "Certified Data Scientist", "Certified Machine Learning"],
            achievements=["Published Research", "Open Source Contribution", "Patent", "Award"]
        ),
        Candidate(
            id="005",
            name="Eva Davis",
            age=40,
            gender="Female",
            location="Austin",
            education=EducationLevel.MASTER,
            experience_years=10,
            experience_level=ExperienceLevel.SENIOR,
            skills=["Python", "Java", "Machine Learning", "Data Science", "SQL", "C++", "R"],
            certifications=["AWS", "Google Cloud"],
            achievements=["Published Research", "Patent"]
        )
    ]


def main():
    """Main function to demonstrate the candidate ranking system"""
    print("=== Candidate Ranking System ===\n")
    
    # Create ranking system
    ranking_system = CandidateRankingSystem()
    
    # Add sample candidates
    sample_candidates = create_sample_candidates()
    for candidate in sample_candidates:
        ranking_system.add_candidate(candidate)
    
    # Rank candidates
    print("Ranking candidates...")
    ranked_candidates = ranking_system.rank_candidates()
    
    # Display ranked results
    print("\n=== Ranked Candidates ===")
    for i, candidate in enumerate(ranked_candidates, 1):
        print(f"{i}. {candidate.name} (ID: {candidate.id}) - Score: {candidate.technical_score:.2f}")
    
    # Generate shortlist
    print("\n=== Shortlist (Top 3) ===")
    shortlist = ranking_system.generate_shortlist(3)
    for i, candidate in enumerate(shortlist, 1):
        print(f"{i}. {candidate.name} - Score: {candidate.technical_score:.2f}")
    
    # Generate summary report
    print("\n=== Ranking Summary Report ===")
    report = ranking_system.generate_summary_report()
    
    print(f"Total Candidates: {report['total_candidates']}")
    print(f"Average Score: {report['average_score']:.2f}")
    print(f"Maximum Score: {report['maximum_score']:.2f}")
    print(f"Minimum Score: {report['minimum_score']:.2f}")
    
    print("\nTop Candidate:")
    top = report['top_candidate']
    if top:
        print(f"  Name: {top['name']}")
        print(f"  ID: {top['id']}")
        print(f"  Score: {top['score']:.2f}")
    
    print("\nShortlist:")
    for i, candidate in enumerate(report['shortlist'], 1):
        print(f"  {i}. {candidate['name']} - Score: {candidate['score']:.2f}")
    
    # Export results
    filename = ranking_system.export_results("ranking_results.json")
    print(f"\nResults exported to {filename}")


if __name__ == "__main__":
    main()