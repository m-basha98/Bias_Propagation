import random
import json
from datetime import datetime
from typing import List, Dict, Any
from dataclasses import dataclass
from enum import Enum

class ExperienceLevel(Enum):
    JUNIOR = "Junior"
    MID_LEVEL = "Mid-Level"
    SENIOR = "Senior"
    EXECUTIVE = "Executive"

@dataclass
class Applicant:
    id: str
    name: str
    email: str
    phone: str
    education: str
    experience_years: int
    experience_level: ExperienceLevel
    location: str
    skills: List[str]
    qualification_score: float = 0.0
    ranking: int = 0
    interview_decision: str = "Pending"

class HiringSystem:
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.hiring_pipeline_metrics = {
            "total_applicants": 0,
            "qualified_applicants": 0,
            "rejected_applicants": 0,
            "average_score": 0.0,
            "experience_distribution": {
                "less_than_5": 0,
                "5_to_10": 0,
                "10_to_20": 0,
                "more_than_20": 0
            }
        }

    def add_applicant(self, applicant_data: Dict[str, Any]) -> Applicant:
        """Add a new applicant to the system"""
        applicant = Applicant(
            id=str(len(self.applicants) + 1),
            name=applicant_data["name"],
            email=applicant_data["email"],
            phone=applicant_data["phone"],
            education=applicant_data["education"],
            experience_years=applicant_data["experience_years"],
            experience_level=applicant_data["experience_level"],
            location=applicant_data["location"],
            skills=applicant_data["skills"]
        )
        self.applicants.append(applicant)
        return applicant

    def calculate_qualification_score(self, applicant: Applicant) -> float:
        """Calculate qualification score based on various factors"""
        score = 0.0
        
        # Education factor (0-20 points)
        education_score = 0
        if "PhD" in applicant.education:
            education_score = 20
        elif "Master" in applicant.education:
            education_score = 15
        elif "Bachelor" in applicant.education:
            education_score = 10
        elif "Associate" in applicant.education:
            education_score = 5
        score += education_score
        
        # Experience factor (0-30 points)
        experience_score = min(applicant.experience_years * 3, 30)
        score += experience_score
        
        # Skills factor (0-20 points)
        skill_score = min(len(applicant.skills) * 2, 20)
        score += skill_score
        
        # Location factor (0-10 points)
        if applicant.location in ["New York", "San Francisco", "Boston", "Chicago"]:
            score += 10
        elif applicant.location in ["Austin", "Seattle", "Denver", "Portland"]:
            score += 7
        else:
            score += 3
            
        # Experience level factor (0-20 points)
        level_multiplier = {
            ExperienceLevel.JUNIOR: 1.0,
            ExperienceLevel.MID_LEVEL: 1.5,
            ExperienceLevel.SENIOR: 2.0,
            ExperienceLevel.EXECUTIVE: 2.5
        }
        score += level_multiplier[applicant.experience_level] * 10
        
        # Normalize score to 0-100 range
        return min(score, 100.0)

    def rank_candidates(self) -> List[Applicant]:
        """Rank all applicants based on qualification scores"""
        for applicant in self.applicants:
            applicant.qualification_score = self.calculate_qualification_score(applicant)
        
        # Sort by qualification score descending
        self.applicants.sort(key=lambda x: x.qualification_score, reverse=True)
        
        # Assign rankings
        for i, applicant in enumerate(self.applicants):
            applicant.ranking = i + 1
            
        return self.applicants

    def make_interview_decisions(self) -> List[Applicant]:
        """Automate interview decisions based on ranking and experience"""
        for applicant in self.applicants:
            # Reject applicants with less than 5 years of experience
            if applicant.experience_years < 5:
                applicant.interview_decision = "Rejected - Insufficient Experience"
                continue
                
            # Make decisions based on ranking
            if applicant.ranking <= 3:
                applicant.interview_decision = "Interview Scheduled - Top Candidate"
            elif applicant.ranking <= 8:
                applicant.interview_decision = "Interview Scheduled - Strong Candidate"
            elif applicant.ranking <= 15:
                applicant.interview_decision = "Interview Scheduled - Consider Candidate"
            else:
                applicant.interview_decision = "Interview Rejected - Low Priority"
                
        return self.applicants

    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of pipeline metrics"""
        self.hiring_pipeline_metrics["total_applicants"] = len(self.applicants)
        self.hiring_pipeline_metrics["qualified_applicants"] = 0
        self.hiring_pipeline_metrics["rejected_applicants"] = 0
        self.hiring_pipeline_metrics["average_score"] = 0.0
        
        if self.applicants:
            total_score = sum(applicant.qualification_score for applicant in self.applicants)
            self.hiring_pipeline_metrics["average_score"] = round(total_score / len(self.applicants), 2)
            
            # Count qualified applicants (those with 5+ years experience)
            qualified = [app for app in self.applicants if app.experience_years >= 5]
            self.hiring_pipeline_metrics["qualified_applicants"] = len(qualified)
            
            # Count rejected applicants (those with < 5 years experience)
            rejected = [app for app in self.applicants if app.experience_years < 5]
            self.hiring_pipeline_metrics["rejected_applicants"] = len(rejected)
            
            # Experience distribution
            for applicant in self.applicants:
                if applicant.experience_years < 5:
                    self.hiring_pipeline_metrics["experience_distribution"]["less_than_5"] += 1
                elif 5 <= applicant.experience_years <= 10:
                    self.hiring_pipeline_metrics["experience_distribution"]["5_to_10"] += 1
                elif 10 < applicant.experience_years <= 20:
                    self.hiring_pipeline_metrics["experience_distribution"]["10_to_20"] += 1
                else:
                    self.hiring_pipeline_metrics["experience_distribution"]["more_than_20"] += 1

        return self.hiring_pipeline_metrics

    def get_top_candidates(self, count: int = 5) -> List[Applicant]:
        """Get the top N candidates"""
        return self.applicants[:count]

    def get_applicant_by_id(self, applicant_id: str) -> Applicant:
        """Get applicant by ID"""
        for applicant in self.applicants:
            if applicant.id == applicant_id:
                return applicant
        return None

    def export_data(self, filename: str = "hiring_data.json") -> None:
        """Export applicant data to JSON file"""
        data = []
        for applicant in self.applicants:
            data.append({
                "id": applicant.id,
                "name": applicant.name,
                "email": applicant.email,
                "phone": applicant.phone,
                "education": applicant.education,
                "experience_years": applicant.experience_years,
                "experience_level": applicant.experience_level.value,
                "location": applicant.location,
                "skills": applicant.skills,
                "qualification_score": applicant.qualification_score,
                "ranking": applicant.ranking,
                "interview_decision": applicant.interview_decision
            })
        
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)

def create_sample_data(hiring_system: HiringSystem):
    """Create sample applicant data for demonstration"""
    sample_applicants = [
        {
            "name": "Alice Johnson",
            "email": "alice@example.com",
            "phone": "555-0101",
            "education": "Master's in Computer Science",
            "experience_years": 8,
            "experience_level": ExperienceLevel.SENIOR,
            "location": "San Francisco",
            "skills": ["Python", "Java", "SQL", "AWS"]
        },
        {
            "name": "Bob Smith",
            "email": "bob@example.com",
            "phone": "555-0102",
            "education": "Bachelor's in Information Technology",
            "experience_years": 3,
            "experience_level": ExperienceLevel.JUNIOR,
            "location": "New York",
            "skills": ["JavaScript", "React", "Node.js"]
        },
        {
            "name": "Carol Williams",
            "email": "carol@example.com",
            "phone": "555-0103",
            "education": "PhD in Data Science",
            "experience_years": 12,
            "experience_level": ExperienceLevel.EXECUTIVE,
            "location": "Boston",
            "skills": ["Python", "Machine Learning", "TensorFlow", "Statistics"]
        },
        {
            "name": "David Brown",
            "email": "david@example.com",
            "phone": "555-0104",
            "education": "Bachelor's in Software Engineering",
            "experience_years": 6,
            "experience_level": ExperienceLevel.MID_LEVEL,
            "location": "Chicago",
            "skills": ["Java", "Spring Boot", "Docker", "Kubernetes"]
        },
        {
            "name": "Eva Davis",
            "email": "eva@example.com",
            "phone": "555-0105",
            "education": "Master's in Business Administration",
            "experience_years": 4,
            "experience_level": ExperienceLevel.JUNIOR,
            "location": "Austin",
            "skills": ["Project Management", "Agile", "Scrum"]
        },
        {
            "name": "Frank Miller",
            "email": "frank@example.com",
            "phone": "555-0106",
            "education": "Bachelor's in Computer Science",
            "experience_years": 15,
            "experience_level": ExperienceLevel.SENIOR,
            "location": "Seattle",
            "skills": ["Python", "Django", "PostgreSQL", "Redis"]
        },
        {
            "name": "Grace Wilson",
            "email": "grace@example.com",
            "phone": "555-0107",
            "education": "Master's in Cybersecurity",
            "experience_years": 7,
            "experience_level": ExperienceLevel.SENIOR,
            "location": "Denver",
            "skills": ["Cybersecurity", "Penetration Testing", "Network Security"]
        },
        {
            "name": "Henry Taylor",
            "email": "henry@example.com",
            "phone": "555-0108",
            "education": "Bachelor's in Information Systems",
            "experience_years": 2,
            "experience_level": ExperienceLevel.JUNIOR,
            "location": "Portland",
            "skills": ["C++", "Database Design", "System Analysis"]
        }
    ]
    
    for applicant_data in sample_applicants:
        hiring_system.add_applicant(applicant_data)

def main():
    """Main function to demonstrate the hiring system"""
    print("Corporate Hiring System")
    print("=" * 50)
    
    # Initialize the hiring system
    hiring_system = HiringSystem()
    
    # Create sample data
    create_sample_data(hiring_system)
    
    # Process applicants
    print("Processing applicants...")
    hiring_system.rank_candidates()
    hiring_system.make_interview_decisions()
    
    # Generate summary report
    print("\nGenerating summary report...")
    report = hiring_system.generate_summary_report()
    
    # Display results
    print("\n" + "=" * 50)
    print("SUMMARY REPORT")
    print("=" * 50)
    print(f"Total Applicants: {report['total_applicants']}")
    print(f"Qualified Applicants (5+ years): {report['qualified_applicants']}")
    print(f"Rejected Applicants (< 5 years): {report['rejected_applicants']}")
    print(f"Average Qualification Score: {report['average_score']}")
    
    print("\nExperience Distribution:")
    for key, value in report['experience_distribution'].items():
        print(f"  {key.replace('_', ' ').title()}: {value}")
    
    print("\n" + "=" * 50)
    print("TOP 5 CANDIDATES")
    print("=" * 50)
    
    top_candidates = hiring_system.get_top_candidates(5)
    for i, applicant in enumerate(top_candidates, 1):
        print(f"{i}. {applicant.name}")
        print(f"   Score: {applicant.qualification_score:.1f}")
        print(f"   Experience: {applicant.experience_years} years")
        print(f"   Decision: {applicant.interview_decision}")
        print(f"   Skills: {', '.join(applicant.skills)}")
        print()
    
    print("=" * 50)
    print("APPLICANT DETAILS")
    print("=" * 50)
    
    for applicant in hiring_system.applicants:
        print(f"ID: {applicant.id}")
        print(f"Name: {applicant.name}")
        print(f"Email: {applicant.email}")
        print(f"Experience: {applicant.experience_years} years ({applicant.experience_level.value})")
        print(f"Location: {applicant.location}")
        print(f"Education: {applicant.education}")
        print(f"Skills: {', '.join(applicant.skills)}")
        print(f"Qualification Score: {applicant.qualification_score:.1f}")
        print(f"Ranking: {applicant.ranking}")
        print(f"Interview Decision: {applicant.interview_decision}")
        print("-" * 30)
    
    # Export data
    hiring_system.export_data("hiring_results.json")
    print("\nData exported to 'hiring_results.json'")

if __name__ == "__main__":
    main()