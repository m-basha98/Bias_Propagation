import pytest
from unittest.mock import patch
from datetime import datetime
from typing import List, Dict, Any
import json
import os

from hiring_system import (
    Applicant, 
    HiringSystem, 
    ExperienceLevel,
    create_sample_data
)


def test_applicant_dataclass():
    """Test Applicant dataclass initialization and attributes"""
    applicant = Applicant(
        id="1",
        name="John Doe",
        email="john@example.com",
        phone="555-0123",
        education="Bachelor's in Computer Science",
        experience_years=5,
        experience_level=ExperienceLevel.MID_LEVEL,
        location="New York",
        skills=["Python", "Java"],
        qualification_score=85.0,
        ranking=1,
        interview_decision="Interview Scheduled"
    )
    
    assert applicant.id == "1"
    assert applicant.name == "John Doe"
    assert applicant.email == "john@example.com"
    assert applicant.phone == "555-0123"
    assert applicant.education == "Bachelor's in Computer Science"
    assert applicant.experience_years == 5
    assert applicant.experience_level == ExperienceLevel.MID_LEVEL
    assert applicant.location == "New York"
    assert applicant.skills == ["Python", "Java"]
    assert applicant.qualification_score == 85.0
    assert applicant.ranking == 1
    assert applicant.interview_decision == "Interview Scheduled"


def test_experience_level_enum():
    """Test ExperienceLevel enum values"""
    assert ExperienceLevel.JUNIOR.value == "Junior"
    assert ExperienceLevel.MID_LEVEL.value == "Mid-Level"
    assert ExperienceLevel.SENIOR.value == "Senior"
    assert ExperienceLevel.EXECUTIVE.value == "Executive"


def test_hiring_system_initialization():
    """Test HiringSystem initialization"""
    system = HiringSystem()
    
    assert system.applicant_list == []
    assert system.pipeline_metrics["total_applicants"] == 0
    assert system.pipeline_metrics["qualified_applicants"] == 0
    assert system.pipeline_metrics["rejected_applicants"] == 0
    assert system.pipeline_metrics["average_score"] == 0.0
    assert system.pipeline_metrics["experience_distribution"]["less_than_5"] == 0
    assert system.pipeline_metrics["experience_distribution"]["5_to_10"] == 0
    assert system.pipeline_metrics["experience_distribution"]["10_to_20"] == 0
    assert system.pipeline_metrics["experience_distribution"]["20+"] == 0


def test_add_applicant():
    """Test adding applicant to system"""
    system = HiringSystem()
    
    applicant_data = {
        "name": "Jane Smith",
        "email": "jane@example.com",
        "phone": "555-0124",
        "education": "Master's in Data Science",
        "experience_years": 8,
        "experience_level": ExperienceLevel.SENIOR,
        "location": "San Francisco",
        "skills": ["Python", "R", "Statistics"]
    }
    
    # Add applicant directly to list
    applicant = Applicant(**applicant_data)
    system.applicant_list.append(applicant)
    
    assert len(system.applicant_list) == 1
    assert system.applicant_list[0].name == "Jane Smith"


def test_calculate_education_score():
    """Test education score calculation"""
    system = HiringSystem()
    
    # Test different education levels
    assert system._calculate_education_score("PhD in Data Science") == 100
    assert system._calculate_education_score("Master's in Business Administration") == 80
    assert system._calculate_education_score("Bachelor's in Computer Science") == 60
    assert system._calculate_education_score("Associate's in Information Technology") == 40
    assert system._calculate_education_score("High School Diploma") == 20
    assert system._calculate_education_score("Some other qualification") == 0


def test_calculate_experience_score():
    """Test experience score calculation"""
    system = HiringSystem()
    
    # Test different experience levels
    assert system._calculate_experience_score(0) == 0
    assert system._calculate_experience_score(1) == 10
    assert system._calculate_experience_score(5) == 50
    assert system._calculate_experience_score(10) == 100
    assert system._calculate_experience_score(15) == 100  # Cap at 100
    assert system._calculate_experience_score(20) == 100  # Cap at 100


def test_calculate_location_score():
    """Test location score calculation"""
    system = HiringSystem()
    
    # Test premium locations
    assert system._calculate_location_score("New York") == 20
    assert system._calculate_location_score("San Francisco") == 20
    assert system._calculate_location_score("Boston") == 20
    assert system._calculate_location_score("Seattle") == 20
    
    # Test standard locations
    assert system._calculate_location_score("Chicago") == 10
    assert system._calculate_location_score("Austin") == 10
    assert system._calculate_location_score("Denver") == 10
    
    # Test other locations
    assert system._calculate_location_score("Portland") == 5
    assert system._calculate_location_score("Small Town") == 0


def test_calculate_skill_score():
    """Test skill score calculation"""
    system = HiringSystem()
    
    # Test with no skills
    assert system._calculate_skill_score([]) == 0
    
    # Test with some skills
    skills = ["Python", "Java", "JavaScript"]
    assert system._calculate_skill_score(skills) == 30  # 3 skills * 10 each
    
    # Test with more skills
    skills = ["Python", "Java", "JavaScript", "C++", "Go", "Rust"]
    assert system._calculate_skill_score(skills) == 60  # 6 skills * 10 each


def test_calculate_qualification_score():
    """Test qualification score calculation"""
    system = HiringSystem()
    
    # Test with various inputs
    applicant_data = {
        "name": "Test Applicant",
        "email": "test@example.com",
        "phone": "555-0125",
        "education": "PhD in Data Science",
        "experience_years": 10,
        "experience_level": ExperienceLevel.SENIOR,
        "location": "New York",
        "skills": ["Python", "Java", "JavaScript"]
    }
    
    applicant = Applicant(**applicant_data)
    score = system._calculate_qualification_score(applicant)
    
    # Should be: education (100) + experience (100) + location (20) + skills (30) = 250
    assert score == 250


def test_rank_applicants():
    """Test applicant ranking functionality"""
    system = HiringSystem()
    
    # Add sample applicants
    applicant1 = Applicant(
        id="1",
        name="Alice Johnson",
        email="alice@example.com",
        phone="555-0126",
        education="PhD in Data Science",
        experience_years=12,
        experience_level=ExperienceLevel.EXECUTIVE,
        location="Boston",
        skills=["Python", "Machine Learning", "TensorFlow"]
    )
    
    applicant2 = Applicant(
        id="2",
        name="Bob Smith",
        email="bob@example.com",
        phone="555-0127",
        education="Bachelor's in Computer Science",
        experience_years=5,
        experience_level=ExperienceLevel.MID_LEVEL,
        location="Chicago",
        skills=["Java", "Spring Boot"]
    )
    
    system.applicant_list = [applicant1, applicant2]
    
    # Rank applicants
    system.rank_applicants()
    
    # Check rankings
    assert applicant1.ranking == 1
    assert applicant2.ranking == 2
    
    # Check that scores are calculated
    assert applicant1.qualification_score > 0
    assert applicant2.qualification_score > 0


def test_make_interview_decisions():
    """Test interview decision making"""
    system = HiringSystem()
    
    # Add sample applicants
    applicant1 = Applicant(
        id="1",
        name="High Scorer",
        email="high@example.com",
        phone="555-0128",
        education="PhD in Data Science",
        experience_years=10,
        experience_level=ExperienceLevel.EXECUTIVE,
        location="Boston",
        skills=["Python", "Machine Learning", "TensorFlow"],
        qualification_score=250
    )
    
    applicant2 = Applicant(
        id="2",
        name="Low Scorer",
        email="low@example.com",
        phone="555-0129",
        education="Bachelor's in Computer Science",
        experience_years=2,
        experience_level=ExperienceLevel.JUNIOR,
        location="Portland",
        skills=["C++"],
        qualification_score=30
    )
    
    applicant3 = Applicant(
        id="3",
        name="Experience Scorer",
        email="exp@example.com",
        phone="555-0130",
        education="Master's in Business Administration",
        experience_years=15,
        experience_level=ExperienceLevel.SENIOR,
        location="Seattle",
        skills=["Project Management", "Agile"],
        qualification_score=150
    )
    
    system.applicant_list = [applicant1, applicant2, applicant3]
    
    # Rank applicants
    system.rank_applicants()
    
    # Make decisions
    system.make_interview_decisions()
    
    # Check decisions
    assert applicant1.interview_decision == "Interview Scheduled"
    assert applicant2.interview_decision == "Not Qualified"
    assert applicant3.interview_decision == "Interview Scheduled"


def test_generate_summary_report():
    """Test summary report generation"""
    system = HiringSystem()
    
    # Add sample applicants
    applicant1 = Applicant(
        id="1",
        name="Test Applicant 1",
        email="test1@example.com",
        phone="555-0131",
        education="PhD in Data Science",
        experience_years=10,
        experience_level=ExperienceLevel.EXECUTIVE,
        location="Boston",
        skills=["Python", "Machine Learning"],
        qualification_score=200
    )
    
    applicant2 = Applicant(
        id="2",
        name="Test Applicant 2",
        email="test2@example.com",
        phone="555-0132",
        education="Bachelor's in Computer Science",
        experience_years=2,
        experience_level=ExperienceLevel.JUNIOR,
        location="Portland",
        skills=["C++"],
        qualification_score=30
    )
    
    system.applicant_list = [applicant1, applicant2]
    
    # Generate report
    report = system.generate_summary_report()
    
    # Check report values
    assert report["total_applicants"] == 2
    assert report["qualified_applicants"] == 1  # Only applicant1 qualifies
    assert report["rejected_applicants"] == 1
    assert report["average_score"] == 115.0  # (200 + 30) / 2
    assert report["experience_distribution"]["less_than_5"] == 1
    assert report["experience_distribution"]["5_to_10"] == 0
    assert report["experience_distribution"]["10_to_20"] == 1
    assert report["experience_distribution"]["20+"] == 0


def test_get_top_candidates():
    """Test getting top candidates"""
    system = HiringSystem()
    
    # Add sample applicants
    applicant1 = Applicant(
        id="1",
        name="Top Applicant",
        email="top@example.com",
        phone="555-0133",
        education="PhD in Data Science",
        experience_years=15,
        experience_level=ExperienceLevel.EXECUTIVE,
        location="Boston",
        skills=["Python", "Machine Learning", "TensorFlow"],
        qualification_score=250,
        ranking=1
    )
    
    applicant2 = Applicant(
        id="2",
        name="Second Applicant",
        email="second@example.com",
        phone="555-0134",
        education="Master's in Business Administration",
        experience_years=10,
        experience_level=ExperienceLevel.SENIOR,
        location="Seattle",
        skills=["Project Management", "Agile"],
        qualification_score=150,
        ranking=2
    )
    
    system.applicant_list = [applicant1, applicant2]
    
    # Get top 2 candidates
    top_candidates = system.get_top_candidates(2)
    
    assert len(top_candidates) == 2
    assert top_candidates[0].name == "Top Applicant"
    assert top_candidates[1].name == "Second Applicant"


def test_get_candidates_by_experience():
    """Test getting candidates by experience level"""
    system = HiringSystem()
    
    # Add sample applicants
    applicant1 = Applicant(
        id="1",
        name="Senior Applicant",
        email="senior@example.com",
        phone="555-0135",
        education="Master's in Business Administration",
        experience_years=15,
        experience_level=ExperienceLevel.SENIOR,
        location="Seattle",
        skills=["Project Management", "Agile"],
        qualification_score=150
    )
    
    applicant2 = Applicant(
        id="2",
        name="Junior Applicant",
        email="junior@example.com",
        phone="555-0136",
        education="Bachelor's in Computer Science",
        experience_years=2,
        experience_level=ExperienceLevel.JUNIOR,
        location="Portland",
        skills=["C++"],
        qualification_score=30
    )
    
    system.applicant_list = [applicant1, applicant2]
    
    # Get senior candidates
    senior_candidates = system.get_candidates_by_experience("Senior")
    
    assert len(senior_candidates) == 1
    assert senior_candidates[0].name == "Senior Applicant"


def test_create_sample_data():
    """Test creating sample data"""
    system = HiringSystem()
    
    # Create sample data
    system.create_sample_data()
    
    # Check that data was created
    assert len(system.applicant_list) > 0
    
    # Check that all applicants have required fields
    for applicant in system.applicant_list:
        assert applicant.name is not None
        assert applicant.email is not None
        assert applicant.experience_years is not None
        assert applicant.qualification_score is not None


def test_invalid_experience_years():
    """Test handling of invalid experience years"""
    system = HiringSystem()
    
    # Test with negative experience years
    applicant = Applicant(
        id="1",
        name="Test Applicant",
        email="test@example.com",
        phone="555-0137",
        education="Bachelor's in Computer Science",
        experience_years=-5,
        experience_level=ExperienceLevel.JUNIOR,
        location="Chicago",
        skills=["Python"]
    )
    
    # This should not cause an error, but should handle gracefully
    try:
        score = system._calculate_experience_score(applicant.experience_years)
        assert score >= 0
    except Exception:
        # If there's an error, it should be handled gracefully
        pass


def test_empty_applicant_list():
    """Test behavior with empty applicant list"""
    system = HiringSystem()
    
    # Test ranking with empty list
    system.rank_applicants()
    
    # Test decision making with empty list
    system.make_interview_decisions()
    
    # Test report generation with empty list
    report = system.generate_summary_report()
    
    assert report["total_applicants"] == 0
    assert report["qualified_applicants"] == 0
    assert report["rejected_applicants"] == 0
    assert report["average_score"] == 0


def test_duplicate_applicants():
    """Test handling of duplicate applicants"""
    system = HiringSystem()
    
    # Add same applicant twice
    applicant = Applicant(
        id="1",
        name="Duplicate Applicant",
        email="duplicate@example.com",
        phone="555-0138",
        education="Bachelor's in Computer Science",
        experience_years=5,
        experience_level=ExperienceLevel.MID_LEVEL,
        location="Chicago",
        skills=["Python", "Java"]
    )
    
    system.applicant_list = [applicant, applicant]
    
    # Test ranking (should not crash)
    system.rank_applicants()
    
    # Test decision making (should not crash)
    system.make_interview_decisions()


def test_edge_case_scores():
    """Test edge case score calculations"""
    system = HiringSystem()
    
    # Test maximum scores
    max_applicant = Applicant(
        id="1",
        name="Max Score",
        email="max@example.com",
        phone="555-0139",
        education="PhD in Data Science",
        experience_years=20,
        experience_level=ExperienceLevel.EXECUTIVE,
        location="New York",
        skills=["Python", "Java", "JavaScript", "C++", "Go", "Rust", "Swift", "Kotlin"]
    )
    
    score = system._calculate_qualification_score(max_applicant)
    assert score >= 0  # Should not crash
    
    # Test minimum scores
    min_applicant = Applicant(
        id="2",
        name="Min Score",
        email="min@example.com",
        phone="555-0140",
        education="High School Diploma",
        experience_years=0,
        experience_level=ExperienceLevel.JUNIOR,
        location="Small Town",
        skills=[]
    )
    
    score = system._calculate_qualification_score(min_applicant)
    assert score >= 0  # Should not crash


def test_integration():
    """Test full integration of all components"""
    system = HiringSystem()
    
    # Create sample data
    system.create_sample_data()
    
    # Check data exists
    assert len(system.applicant_list) > 0
    
    # Rank applicants
    system.rank_applicants()
    
    # Make decisions
    system.make_interview_decisions()
    
    # Generate report
    report = system.generate_summary_report()
    
    # Check report structure
    assert "total_applicants" in report
    assert "qualified_applicants" in report
    assert "rejected_applicants" in report
    assert "average_score" in report
    assert "experience_distribution" in report
    
    # Check that all applicants have decisions
    for applicant in system.applicant_list:
        assert applicant.interview_decision is not None
        assert applicant.ranking is not None
        assert applicant.qualification_score is not None


if __name__ == "__main__":
    # Run all tests
    test_add_applicant()
    test_calculate_education_score()
    test_calculate_experience_score()
    test_calculate_location_score()
    test_calculate_skill_score()
    test_calculate_qualification_score()
    test_rank_applicants()
    test_make_interview_decisions()
    test_generate_summary_report()
    test_get_top_candidates()
    test_get_candidates_by_experience()
    test_create_sample_data()
    test_invalid_experience_years()
    test_empty_applicant_list()
    test_duplicate_applicants()
    test_edge_case_scores()
    test_integration()
    
    print("All tests passed!")