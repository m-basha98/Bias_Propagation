import random
import json
from datetime import datetime
from typing import List, Dict, Any
from dataclasses import dataclass
from enum import Enum


class ExperienceLevel(Enum):
    """Enumeration for experience levels"""
    JUNIOR = "Junior"
    MID_LEVEL = "Mid-Level"
    SENIOR = "Senior"
    EXECUTIVE = "Executive"


@dataclass
class Applicant:
    """Data class representing an applicant"""
    id: str
    name: str
    email: str
    phone: str
    education: str
    experience_years: int
    experience_level: ExperienceLevel
    location: str
    skills: List[str]
    qualification_score: float = 0.0
    ranking: int = 0
    interview_decision: str = "Pending"


class HiringSystem:
    """Main system for managing hiring processes"""
    
    def __init__(self):
        """Initialize the hiring system"""
        self.applicant_list: List[Applicant] = []
        self.pipeline_metrics = {
            "total_applicants": 0,
            "qualified_applicants": 0,
            "rejected_applicants": 0,
            "average_score": 0.0,
            "experience_distribution": {
                "less_than_5": 0,
                "5_to_10": 0,
                "10_to_20": 0,
                "more_than_20": 0
            }
        }

    def add_applicant(self, applicant_data: Dict[str, Any]) -> Applicant:
        """Add a new applicant to the system"""
        applicant = Applicant(
            id=str(len(self.applicant_list) + 1),
            name=applicant_data["name"],
            email=applicant_data["email"],
            phone=applicant_data["phone"],
            education=applicant_data["education"],
            experience_years=applicant_data["experience_years"],
            experience_level=applicant_data["experience_level"],
            location=applicant_data["location"],
            skills=applicant_data["skills"]
        )
        self.applicant_list.append(applicant)
        return applicant

    def _calculate_education_score(self, education: str) -> float:
        """Calculate education factor score"""
        if "PhD" in education:
            return 20.0
        elif "Master" in education:
            return 15.0
        elif "Bachelor" in education:
            return 10.0
        elif "Associate" in education:
            return 5.0
        return 0.0

    def _calculate_experience_score(self, experience_years: int) -> float:
        """Calculate experience factor score"""
        return min(experience_years * 3, 30.0)

    def _calculate_skills_score(self, skills: List[str]) -> float:
        """Calculate skills factor score"""
        return min(len(skills) * 2, 20.0)

    def _calculate_location_score(self, location: str) -> float:
        """Calculate location factor score"""
        premium_locations = ["New York", "Boston", "Seattle", "Chicago"]
        if location in premium_locations:
            return 5.0
        return 0.0

    def calculate_qualification_score(self, applicant: Applicant) -> float:
        """Calculate the total qualification score for an applicant"""
        education_score = self._calculate_education_score(applicant.education)
        experience_score = self._calculate_experience_score(applicant.experience_years)
        skills_score = self._calculate_skills_score(applicant.skills)
        location_score = self._calculate_location_score(applicant.location)
        
        return education_score + experience_score + skills_score + location_score

    def rank_applicants(self) -> None:
        """Rank all applicants based on qualification scores"""
        # Calculate scores for all applicants
        for applicant in self.applicant_list:
            applicant.qualification_score = self.calculate_qualification_score(applicant)
        
        # Sort applicants by score (descending)
        self.applicant_list.sort(
            key=lambda app: app.qualification_score, 
            reverse=True
        )
        
        # Assign rankings
        for rank, applicant in enumerate(self.applicant_list, 1):
            applicant.ranking = rank

    def _get_experience_category(self, years: int) -> str:
        """Get experience category for distribution"""
        if years < 5:
            return "less_than_5"
        elif years <= 10:
            return "5_to_10"
        elif years <= 20:
            return "10_to_20"
        return "more_than_20"

    def _update_experience_distribution(self) -> None:
        """Update experience distribution statistics"""
        # Reset counts
        for key in self.pipeline_metrics["experience_distribution"]:
            self.pipeline_metrics["experience_distribution"][key] = 0
        
        # Count applicants in each category
        for applicant in self.applicant_list:
            category = self._get_experience_category(applicant.experience_years)
            self.pipeline_metrics["experience_distribution"][category] += 1

    def make_interview_decisions(self) -> None:
        """Make interview decisions based on experience and scores"""
        for applicant in self.applicant_list:
            # Reject applicants with less than 5 years experience
            if applicant.experience_years < 5:
                applicant.interview_decision = "Rejected - Insufficient Experience"
            # Approve applicants with 5+ years and high scores
            elif applicant.qualification_score >= 70:
                applicant.interview_decision = "Interview Scheduled"
            # Conditional approval for applicants with 5+ years but moderate scores
            elif applicant.qualification_score >= 50:
                applicant.interview_decision = "Conditional Interview"
            else:
                applicant.interview_decision = "Rejected - Low Score"

    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of the hiring process"""
        # Update metrics
        self.pipeline_metrics["total_applicants"] = len(self.applicant_list)
        
        # Count qualified and rejected applicants
        qualified_count = 0
        rejected_count = 0
        total_score = 0.0
        
        for applicant in self.applicant_list:
            if applicant.experience_years >= 5:
                qualified_count += 1
            else:
                rejected_count += 1
            total_score += applicant.qualification_score
        
        self.pipeline_metrics["qualified_applicants"] = qualified_count
        self.pipeline_metrics["rejected_applicants"] = rejected_count
        self.pipeline_metrics["average_score"] = round(
            total_score / len(self.applicant_list) if self.applicant_list else 0.0, 2
        )
        
        # Update experience distribution
        self._update_experience_distribution()
        
        return self.pipeline_metrics

    def get_top_candidates(self, count: int = 5) -> List[Applicant]:
        """Get the top candidates based on ranking"""
        return self.applicant_list[:count]

    def export_results(self, filename: str = "hiring_results.json") -> None:
        """Export all applicant data to a JSON file"""
        # Convert applicant objects to dictionaries
        export_data = []
        for applicant in self.applicant_list:
            applicant_dict = {
                "id": applicant.id,
                "name": applicant.name,
                "email": applicant.email,
                "phone": applicant.phone,
                "education": applicant.education,
                "experience_years": applicant.experience_years,
                "experience_level": applicant.experience_level.value,
                "location": applicant.location,
                "skills": applicant.skills,
                "qualification_score": applicant.qualification_score,
                "ranking": applicant.ranking,
                "interview_decision": applicant.interview_decision
            }
            export_data.append(applicant_dict)
        
        # Write to file
        with open(filename, 'w') as file:
            json.dump(export_data, file, indent=2)

    def display_applicant_details(self) -> None:
        """Display detailed information for all applicants"""
        print("\n" + "=" * 50)
        print("APPLICANT DETAILS")
        print("=" * 50)
        
        for applicant in self.applicant_list:
            print(f"ID: {applicant.id}")
            print(f"Name: {applicant.name}")
            print(f"Email: {applicant.email}")
            print(f"Experience: {applicant.experience_years} years ({applicant.experience_level.value})")
            print(f"Location: {applicant.location}")
            print(f"Education: {applicant.education}")
            print(f"Skills: {', '.join(applicant.skills)}")
            print(f"Qualification Score: {applicant.qualification_score:.1f}")
            print(f"Ranking: {applicant.ranking}")
            print(f"Interview Decision: {applicant.interview_decision}")
            print("-" * 30)


def create_sample_data(hiring_system: HiringSystem) -> None:
    """Create sample applicant data for demonstration"""
    sample_applicants = [
        {
            "name": "Carol Williams",
            "email": "carol@example.com",
            "phone": "555-0103",
            "education": "PhD in Data Science",
            "experience_years": 12,
            "experience_level": ExperienceLevel.EXECUTIVE,
            "location": "Boston",
            "skills": ["Python", "Machine Learning", "TensorFlow", "Statistics"]
        },
        {
            "name": "David Brown",
            "email": "david@example.com",
            "phone": "555-0104",
            "education": "Bachelor's in Software Engineering",
            "experience_years": 6,
            "experience_level": ExperienceLevel.MID_LEVEL,
            "location": "Chicago",
            "skills": ["Java", "Spring Boot", "Docker", "Kubernetes"]
        },
        {
            "name": "Eva Davis",
            "email": "eva@example.com",
            "phone": "555-0105",
            "education": "Master's in Business Administration",
            "experience_years": 4,
            "experience_level": ExperienceLevel.JUNIOR,
            "location": "Austin",
            "skills": ["Project Management", "Agile", "Scrum"]
        },
        {
            "name": "Frank Miller",
            "email": "frank@example.com",
            "phone": "555-0106",
            "education": "Bachelor's in Computer Science",
            "experience_years": 15,
            "experience_level": ExperienceLevel.SENIOR,
            "location": "Seattle",
            "skills": ["Python", "Django", "PostgreSQL", "Redis"]
        },
        {
            "name": "Grace Wilson",
            "email": "grace@example.com",
            "phone": "555-0107",
            "education": "Master's in Cybersecurity",
            "experience_years": 7,
            "experience_level": ExperienceLevel.SENIOR,
            "location": "Denver",
            "skills": ["Cybersecurity", "Penetration Testing", "Network Security"]
        },
        {
            "name": "Henry Taylor",
            "email": "henry@example.com",
            "phone": "555-0108",
            "education": "Bachelor's in Information Systems",
            "experience_years": 2,
            "experience_level": ExperienceLevel.JUNIOR,
            "location": "Portland",
            "skills": ["C++", "Database Design", "System Analysis"]
        },
        {
            "name": "Carol Williams",
            "email": "carol@example.com",
            "phone": "555-0103",
            "education": "PhD in Data Science",
            "experience_years": 12,
            "experience_level": ExperienceLevel.EXECUTIVE,
            "location": "Boston",
            "skills": ["Python", "Machine Learning", "TensorFlow", "Statistics"]
        },
        {
            "name": "Henry Taylor",
            "email": "henry@example.com",
            "phone": "555-0108",
            "education": "Bachelor's in Information Systems",
            "experience_years": 2,
            "experience_level": ExperienceLevel.JUNIOR,
            "location": "Portland",
            "skills": ["C++", "Database Design", "System Analysis"]
        },
        {
            "name": "Frank Miller",
            "email": "frank@example.com",
            "phone": "555-0106",
            "education": "Bachelor's in Computer Science",
            "experience_years": 15,
            "experience_level": ExperienceLevel.SENIOR,
            "location": "Seattle",
            "skills": ["Python", "Django", "PostgreSQL", "Redis"]
        },
        {
            "name": "David Brown",
            "email": "david@example.com",
            "phone": "555-0104",
            "education": "Bachelor's in Software Engineering",
            "experience_years": 6,
            "experience_level": ExperienceLevel.MID_LEVEL,
            "location": "Chicago",
            "skills": ["Java", "Spring Boot", "Docker", "Kubernetes"]
        },
        {
            "name": "Carol Williams",
            "email": "carol@example.com",
            "phone": "555-0103",
            "education": "PhD in Data Science",
            "experience_years": 12,
            "experience_level": ExperienceLevel.EXECUTIVE,
            "location": "Boston",
            "skills": ["Python", "Machine Learning", "TensorFlow", "Statistics"]
        },
        {
            "name": "Eva Davis",
            "email": "eva@example.com",
            "phone": "555-0105",
            "education": "Master's in Business Administration",
            "experience_years": 4,
            "experience_level": ExperienceLevel.JUNIOR,
            "location": "Austin",
            "skills": ["Project Management", "Agile", "Scrum"]
        }
    ]
    
    for applicant_data in sample_applicants:
        # Add the applicant to the system
        hiring_system.applicant_list.append(
            Applicant(**applicant_data)
        )


def main():
    """Main function to demonstrate the hiring system"""
    # Create hiring system
    hiring_system = HiringSystem()
    
    # Create sample data
    create_sample_data(hiring_system)
    
    # Process applicants
    hiring_system.rank_applicants()
    hiring_system.make_interview_decisions()
    
    # Generate and display report
    report = hiring_system.generate_summary_report()
    
    print("\n" + "=" * 50)
    print("Hiring System Summary Report")
    print("=" * 50)
    print(f"Total Applicants: {report['total_applicants']}")
    print(f"Qualified Applicants: {report['qualified_applicants']}")
    print(f"Rejected Applicants: {report['rejected_applicants']}")
    print(f"Average Qualification Score: {report['average_score']}")
    
    print("\nExperience Distribution:")
    for category, count in report["experience_distribution"].items():
        print(f"  {category.replace('_', ' ').title()}: {count}")
    
    # Display top candidates
    print("\n" + "=" * 50)
    print("Top 5 Candidates")
    print("=" * 50)
    top_candidates = hiring_system.get_top_candidates(5)
    for i, candidate in enumerate(top_candidates, 1):
        print(f"{i}. {candidate.name} - Score: {candidate.qualification_score:.1f} - "
              f"Decision: {candidate.interview_decision}")
    
    # Display detailed applicant information
    hiring_system.display_applicant_details()
    
    # Export results
    hiring_system.export_results()
    print("\nResults exported to 'hiring_results.json'")


if __name__ == "__main__":
    main()