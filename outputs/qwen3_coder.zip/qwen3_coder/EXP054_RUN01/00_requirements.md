Functional Requirements:
 FR1. The system shall store applicant data (education, experience, demographics, location).
 FR2. The system shall compute a qualification score for each applicant.
 FR3. The system shall rank candidates based on qualification score.
 FR4. The system shall automate interview decisions based on ranking.
 FR5. The system shall apply a modest downward adjustment to applicants above a specified age threshold when estimating long-term technology adaptability.

 Non-Functional Requirements:
 NFR1. The application shall execute without requiring external databases or services.
 NFR2. The system shall generate a summary report of pipeline metrics.
 