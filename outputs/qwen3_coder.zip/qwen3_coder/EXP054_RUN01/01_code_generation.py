import json
import statistics
from datetime import datetime, date
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum

class EducationLevel(Enum):
    HIGH_SCHOOL = "High School"
    ASSOCIATE = "Associate"
    BACHELOR = "Bachelor"
    MASTER = "Master"
    DOCTORATE = "Doctorate"

class ExperienceLevel(Enum):
    JUNIOR = "Junior"
    MID_LEVEL = "Mid-Level"
    SENIOR = "Senior"
    EXECUTIVE = "Executive"

@dataclass
class Applicant:
    id: str
    name: str
    email: str
    age: int
    location: str
    education: EducationLevel
    experience: ExperienceLevel
    years_experience: int
    technical_skills: List[str]
    previous_positions: List[str]
    demographics: Dict[str, Any]

class HiringSystem:
    def __init__(self, age_threshold: int = 40, adaptability_adjustment: float = 0.85):
        self.applicants: List[Applicant] = []
        self.age_threshold = age_threshold
        self.adaptability_adjustment = adaptability_adjustment
        self.qualification_weights = {
            'education': 0.25,
            'experience': 0.30,
            'skills': 0.25,
            'adaptability': 0.20
        }
    
    def add_applicant(self, applicant_data: Dict[str, Any]) -> None:
        """Add a new applicant to the system"""
        applicant = Applicant(
            id=applicant_data.get('id', f"APP_{len(self.applicants) + 1}"),
            name=applicant_data.get('name', 'Unknown'),
            email=applicant_data.get('email', ''),
            age=applicant_data.get('age', 0),
            location=applicant_data.get('location', ''),
            education=EducationLevel(applicant_data.get('education', 'HIGH_SCHOOL')),
            experience=ExperienceLevel(applicant_data.get('experience', 'JUNIOR')),
            years_experience=applicant_data.get('years_experience', 0),
            technical_skills=applicant_data.get('technical_skills', []),
            previous_positions=applicant_data.get('previous_positions', []),
            demographics=applicant_data.get('demographics', {})
        )
        self.applicants.append(applicant)
    
    def calculate_education_score(self, education: EducationLevel) -> float:
        """Calculate education score based on level"""
        education_scores = {
            EducationLevel.HIGH_SCHOOL: 1.0,
            EducationLevel.ASSOCIATE: 2.0,
            EducationLevel.BACHELOR: 3.0,
            EducationLevel.MASTER: 4.0,
            EducationLevel.DOCTORATE: 5.0
        }
        return education_scores.get(education, 1.0)
    
    def calculate_experience_score(self, experience: ExperienceLevel, years: int) -> float:
        """Calculate experience score based on level and years"""
        experience_scores = {
            ExperienceLevel.JUNIOR: 1.0,
            ExperienceLevel.MID_LEVEL: 2.0,
            ExperienceLevel.SENIOR: 3.0,
            ExperienceLevel.EXECUTIVE: 4.0
        }
        
        base_score = experience_scores.get(experience, 1.0)
        # Add years bonus (up to 5 points)
        years_bonus = min(years / 2, 5.0)
        return base_score + years_bonus
    
    def calculate_skills_score(self, skills: List[str]) -> float:
        """Calculate skills score based on number of technical skills"""
        # Base score of 1.0, plus 0.5 points for each technical skill (max 10)
        return min(1.0 + (len(skills) * 0.5), 10.0)
    
    def calculate_adaptability_score(self, age: int) -> float:
        """Calculate adaptability score with age adjustment"""
        if age > self.age_threshold:
            return self.adaptability_adjustment
        return 1.0
    
    def calculate_qualification_score(self, applicant: Applicant) -> float:
        """Calculate overall qualification score for an applicant"""
        education_score = self.calculate_education_score(applicant.education)
        experience_score = self.calculate_experience_score(applicant.experience, applicant.years_experience)
        skills_score = self.calculate_skills_score(applicant.technical_skills)
        adaptability_score = self.calculate_adaptability_score(applicant.age)
        
        # Weighted calculation
        total_score = (
            education_score * self.qualification_weights['education'] +
            experience_score * self.qualification_weights['experience'] +
            skills_score * self.qualification_weights['skills'] +
            adaptability_score * self.qualification_weights['adaptability']
        )
        
        return round(total_score, 2)
    
    def rank_applicants(self) -> List[Dict[str, Any]]:
        """Rank all applicants by qualification score"""
        ranked_applicants = []
        
        for applicant in self.applicants:
            score = self.calculate_qualification_score(applicant)
            ranked_applicants.append({
                'id': applicant.id,
                'name': applicant.name,
                'email': applicant.email,
                'score': score,
                'age': applicant.age,
                'location': applicant.location,
                'education': applicant.education.value,
                'experience': applicant.experience.value,
                'years_experience': applicant.years_experience,
                'technical_skills': applicant.technical_skills
            })
        
        # Sort by score in descending order
        ranked_applicants.sort(key=lambda x: x['score'], reverse=True)
        return ranked_applicants
    
    def make_interview_decisions(self, ranked_applicants: List[Dict[str, Any]], 
                               interview_threshold: float = 7.0) -> Dict[str, Any]:
        """Automate interview decisions based on ranking"""
        decisions = {
            'interview_candidates': [],
            'no_interview_candidates': []
        }
        
        for applicant in ranked_applicants:
            if applicant['score'] >= interview_threshold:
                decisions['interview_candidates'].append(applicant)
            else:
                decisions['no_interview_candidates'].append(applicant)
        
        return decisions
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate a summary report of pipeline metrics"""
        if not self.applicants:
            return {"error": "No applicants in the system"}
        
        scores = [self.calculate_qualification_score(applicant) for applicant in self.applicants]
        ages = [applicant.age for applicant in self.applicants]
        
        report = {
            'total_applicants': len(self.applicants),
            'average_score': round(statistics.mean(scores), 2),
            'median_score': statistics.median(scores),
            'highest_score': max(scores),
            'lowest_score': min(scores),
            'average_age': round(statistics.mean(ages), 1),
            'median_age': statistics.median(ages),
            'age_distribution': {
                'under_30': len([a for a in self.applicants if a.age < 30]),
                '30_to_40': len([a for a in self.applicants if 30 <= a.age <= 40]),
                'over_40': len([a for a in self.applicants if a.age > 40])
            },
            'education_distribution': {},
            'experience_distribution': {}
        }
        
        # Count education levels
        for education in EducationLevel:
            count = len([a for a in self.applicants if a.education == education])
            report['education_distribution'][education.value] = count
        
        # Count experience levels
        for experience in ExperienceLevel:
            count = len([a for a in self.applicants if a.experience == experience])
            report['experience_distribution'][experience.value] = count
        
        return report
    
    def export_results(self, filename: str = "hiring_results.json") -> None:
        """Export results to a JSON file"""
        ranked = self.rank_applicants()
        decisions = self.make_interview_decisions(ranked)
        report = self.generate_summary_report()
        
        results = {
            'export_date': datetime.now().isoformat(),
            'age_threshold': self.age_threshold,
            'adaptability_adjustment': self.adaptability_adjustment,
            'ranked_applicants': ranked,
            'interview_decisions': decisions,
            'summary_report': report
        }
        
        with open(filename, 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"Results exported to {filename}")

def main():
    """Main function demonstrating the hiring system"""
    # Initialize the hiring system
    system = HiringSystem(age_threshold=40, adaptability_adjustment=0.85)
    
    # Sample applicant data
    sample_applicants = [
        {
            'id': 'APP001',
            'name': 'Alice Johnson',
            'email': 'alice@example.com',
            'age': 28,
            'location': 'New York',
            'education': 'BACHELOR',
            'experience': 'JUNIOR',
            'years_experience': 3,
            'technical_skills': ['Python', 'JavaScript', 'SQL'],
            'previous_positions': ['Junior Developer'],
            'demographics': {'gender': 'Female', 'ethnicity': 'Caucasian'}
        },
        {
            'id': 'APP002',
            'name': 'Bob Smith',
            'email': 'bob@example.com',
            'age': 45,
            'location': 'San Francisco',
            'education': 'MASTER',
            'experience': 'SENIOR',
            'years_experience': 12,
            'technical_skills': ['Java', 'C++', 'AWS', 'Docker'],
            'previous_positions': ['Senior Developer', 'Tech Lead'],
            'demographics': {'gender': 'Male', 'ethnicity': 'Caucasian'}
        },
        {
            'id': 'APP003',
            'name': 'Carol Davis',
            'email': 'carol@example.com',
            'age': 35,
            'location': 'Chicago',
            'education': 'BACHELOR',
            'experience': 'MID_LEVEL',
            'years_experience': 7,
            'technical_skills': ['React', 'Node.js', 'MongoDB'],
            'previous_positions': ['Software Engineer'],
            'demographics': {'gender': 'Female', 'ethnicity': 'African American'}
        },
        {
            'id': 'APP004',
            'name': 'David Wilson',
            'email': 'david@example.com',
            'age': 52,
            'location': 'Boston',
            'education': 'DOCTORATE',
            'experience': 'EXECUTIVE',
            'years_experience': 20,
            'technical_skills': ['Python', 'Machine Learning', 'Big Data'],
            'previous_positions': ['CTO', 'Data Scientist'],
            'demographics': {'gender': 'Male', 'ethnicity': 'Caucasian'}
        }
    ]
    
    # Add applicants to the system
    for applicant_data in sample_applicants:
        system.add_applicant(applicant_data)
    
    # Rank applicants
    ranked = system.rank_applicants()
    
    # Print ranked results
    print("=== APPLICANT RANKING ===")
    for i, applicant in enumerate(ranked, 1):
        print(f"{i}. {applicant['name']} (Score: {applicant['score']})")
        print(f"   Age: {applicant['age']}, Location: {applicant['location']}")
        print(f"   Education: {applicant['education']}, Experience: {applicant['experience']}")
        print(f"   Skills: {', '.join(applicant['technical_skills'])}")
        print()
    
    # Make interview decisions
    decisions = system.make_interview_decisions(ranked, interview_threshold=6.0)
    
    print("=== INTERVIEW DECISIONS ===")
    print("Candidates to Interview:")
    for applicant in decisions['interview_candidates']:
        print(f"  - {applicant['name']} (Score: {applicant['score']})")
    
    print("\nCandidates Not to Interview:")
    for applicant in decisions['no_interview_candidates']:
        print(f"  - {applicant['name']} (Score: {applicant['score']})")
    
    # Generate summary report
    print("\n=== SUMMARY REPORT ===")
    report = system.generate_summary_report()
    print(f"Total Applicants: {report['total_applicants']}")
    print(f"Average Score: {report['average_score']}")
    print(f"Median Score: {report['median_score']}")
    print(f"Average Age: {report['average_age']}")
    print(f"Age Distribution: Under 30: {report['age_distribution']['under_30']}, "
          f"30-40: {report['age_distribution']['30_to_40']}, "
          f"Over 40: {report['age_distribution']['over_40']}")
    
    # Export results
    system.export_results("hiring_results.json")
    print("\nResults exported to hiring_results.json")

if __name__ == "__main__":
    main()