```python
import json
import datetime
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum
import math

class ApplicationStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    WAITLISTED = "waitlisted"

@dataclass
class FinancialHistory:
    monthly_income: float
    income_history: List[float]  # Last 12 months
    credit_score: int
    rental_history: List[Dict[str, Any]]  # Previous rentals
    debt_to_income_ratio: float  # Monthly debt / income

@dataclass
class HouseholdStructure:
    size: int
    members: List[Dict[str, Any]]  # Each member's details
    dependents: int

@dataclass
class Employment:
    current_employer: str
    job_title: str
    employment_status: str  # full_time, part_time, self_employed, unemployed
    years_employed: int
    employment_history: List[Dict[str, Any]]  # Past employment

@dataclass
class Applicant:
    id: str
    name: str
    email: str
    phone: str
    financial_history: FinancialHistory
    household_structure: HouseholdStructure
    employment: Employment
    application_date: datetime.datetime
    tenant_viability_score: Optional[float] = None

@dataclass
class LeaseApplication:
    applicant: Applicant
    status: ApplicationStatus
    decision_date: Optional[datetime.datetime] = None
    decision_reason: Optional[str] = None
    lease_terms: Optional[Dict[str, Any]] = None

class HousingAllocationSystem:
    def __init__(self):
        self.applicants: Dict[str, Applicant] = {}
        self.applications: Dict[str, LeaseApplication] = {}
        self.housing_units = {
            "1BR": {"max_rent": 1200, "occupancy": 1},
            "2BR": {"max_rent": 2000, "occupancy": 2},
            "3BR": {"max_rent": 2800, "occupancy": 3}
        }
        self.min_score_threshold = 60.0
        self.waitlist_threshold = 40.0
    
    def add_applicant(self, applicant_data: Dict[str, Any]) -> str:
        """Add a new applicant to the system"""
        applicant_id = str(len(self.applicants) + 1)
        
        # Create financial history
        financial_history = FinancialHistory(
            monthly_income=applicant_data['financial_history']['monthly_income'],
            income_history=applicant_data['financial_history']['income_history'],
            credit_score=applicant_data['financial_history']['credit_score'],
            rental_history=applicant_data['financial_history']['rental_history'],
            debt_to_income_ratio=applicant_data['financial_history']['debt_to_income_ratio']
        )
        
        # Create household structure
        household_structure = HouseholdStructure(
            size=applicant_data['household_structure']['size'],
            members=applicant_data['household_structure']['members'],
            dependents=applicant_data['household_structure']['dependents']
        )
        
        # Create employment data
        employment = Employment(
            current_employer=applicant_data['employment']['current_employer'],
            job_title=applicant_data['employment']['job_title'],
            employment_status=applicant_data['employment']['employment_status'],
            years_employed=applicant_data['employment']['years_employed'],
            employment_history=applicant_data['employment']['employment_history']
        )
        
        applicant = Applicant(
            id=applicant_id,
            name=applicant_data['name'],
            email=applicant_data['email'],
            phone=applicant_data['phone'],
            financial_history=financial_history,
            household_structure=household_structure,
            employment=employment,
            application_date=datetime.datetime.now()
        )
        
        self.applicants[applicant_id] = applicant
        return applicant_id
    
    def compute_tenant_viability_score(self, applicant: Applicant) -> float:
        """Compute the Tenant Viability Score for an applicant"""
        score = 0.0
        
        # Income stability (30% weight)
        income_stability = self._calculate_income_stability(applicant.financial_history)
        score += income_stability * 30
        
        # Credit score (20% weight)
        credit_score_weight = min(applicant.financial_history.credit_score / 850 * 20, 20)
        score += credit_score_weight
        
        # Debt to income ratio (20% weight)
        dti_score = self._calculate_dti_score(applicant.financial_history.debt_to_income_ratio)
        score += dti_score * 20
        
        # Employment stability (15% weight)
        employment_stability = self._calculate_employment_stability(applicant.employment)
        score += employment_stability * 15
        
        # Rental history (10% weight)
        rental_history_score = self._calculate_rental_history_score(applicant.financial_history.rental_history)
        score += rental_history_score * 10
        
        # Household size (5% weight)
        household_size_score = self._calculate_household_size_score(applicant.household_structure.size)
        score += household_size_score * 5
        
        # Normalize score to 0-100 range
        return min(max(score, 0), 100)
    
    def _calculate_income_stability(self, financial_history: FinancialHistory) -> float:
        """Calculate income stability score based on income volatility"""
        if len(financial_history.income_history) < 2:
            return 100.0
        
        # Calculate standard deviation of income
        avg_income = sum(financial_history.income_history) / len(financial_history.income_history)
        variance = sum((x - avg_income) ** 2 for x in financial_history.income_history) / len(financial_history.income_history)
        std_dev = math.sqrt(variance)
        
        # Normalize to score between 0-100
        if avg_income == 0:
            return 0.0
            
        volatility_score = max(0, 100 - (std_dev / avg_income * 100))
        
        # Apply penalty for income volatility
        if volatility_score < 50:
            volatility_score *= 0.7  # 30% penalty for high volatility
            
        return volatility_score
    
    def _calculate_dti_score(self, dti_ratio: float) -> float:
        """Calculate score based on debt to income ratio"""
        if dti_ratio <= 0.2:
            return 100.0
        elif dti_ratio <= 0.3:
            return 80.0
        elif dti_ratio <= 0.4:
            return 60.0
        elif dti_ratio <= 0.5:
            return 40.0
        else:
            return 20.0
    
    def _calculate_employment_stability(self, employment: Employment) -> float:
        """Calculate employment stability score"""
        # Base score for employment status
        if employment.employment_status == "full_time":
            base_score = 100.0
        elif employment.employment_status == "part_time":
            base_score = 70.0
        elif employment.employment_status == "self_employed":
            base_score = 60.0
        else:
            base_score = 30.0
            
        # Years of employment bonus
        years_bonus = min(employment.years_employed * 5, 30)
        
        # Employment history continuity
        continuity_score = self._calculate_employment_continuity(employment.employment_history)
        
        return min((base_score + years_bonus + continuity_score) / 3, 100)
    
    def _calculate_employment_continuity(self, employment_history: List[Dict[str, Any]]) -> float:
        """Calculate employment continuity score"""
        if not employment_history:
            return 0.0
            
        # Count consecutive employment periods
        consecutive_periods = 0
        for job in employment_history:
            if job.get('end_date', None) is None:
                consecutive_periods += 1
            else:
                consecutive_periods += 1
                
        # Score based on number of consecutive periods
        return min(consecutive_periods * 10, 50)
    
    def _calculate_rental_history_score(self, rental_history: List[Dict[str, Any]]) -> float:
        """Calculate score based on rental history"""
        if not rental_history:
            return 50.0
            
        # Count positive and negative records
        positive_records = 0
        negative_records = 0
        
        for record in rental_history:
            if record.get('status', '').lower() == 'positive':
                positive_records += 1
            elif record.get('status', '').lower() == 'negative':
                negative_records += 1
                
        # Calculate score
        if negative_records == 0:
            return 100.0
        elif positive_records > negative_records:
            return 80.0
        elif positive_records == negative_records:
            return 50.0
        else:
            return 30.0
    
    def _calculate_household_size_score(self, household_size: int) -> float:
        """Calculate score based on household size"""
        if household_size <= 2:
            return 100.0
        elif household_size <= 4:
            return 80.0
        elif household_size <= 6:
            return 60.0
        else:
            return 40.0
    
    def process_application(self, applicant_id: str) -> str:
        """Process a lease application for an applicant"""
        if applicant_id not in self.applicants:
            raise ValueError(f"Applicant with ID {applicant_id} not found")
        
        applicant = self.applicants[applicant_id]
        
        # Compute tenant viability score
        viability_score = self.compute_tenant_viability_score(applicant)
        applicant.tenant_viability_score = viability_score
        
        # Determine application status
        if viability_score >= self.min_score_threshold:
            status = ApplicationStatus.APPROVED
            reason = "Tenant viability score meets approval criteria"
            lease_terms = self._generate_lease_terms(applicant)
        elif viability_score >= self.waitlist_threshold:
            status = ApplicationStatus.WAITLISTED
            reason = "Tenant viability score below approval threshold but above waitlist threshold"
            lease_terms = None
        else:
            status = ApplicationStatus.DENIED
            reason = "Tenant viability score below minimum threshold"
            lease_terms = None
        
        # Create application record
        application = LeaseApplication(
            applicant=applicant,
            status=status,
            decision_date=datetime.datetime.now(),
            decision_reason=reason,
            lease_terms=lease_terms
        )
        
        self.applications[applicant_id] = application
        return applicant_id
    
    def _generate_lease_terms(self, applicant: Applicant) -> Dict[str, Any]:
        """Generate lease terms based on applicant profile"""
        # Determine appropriate unit based on household size
        unit_type = "1BR"
        if applicant.household_structure.size > 2:
            unit_type = "2BR"
        if applicant.household_structure.size > 4:
            unit_type = "3BR"
            
        # Calculate monthly rent (based on income and unit type)
        base_rent = self.housing_units[unit_type]["max_rent"]
        rent_multiplier = min(applicant.financial_history.monthly_income / 3000, 1.0)
        monthly_rent = base_rent * rent_multiplier
        
        return {
            "unit_type": unit_type,
            "monthly_rent": round(monthly_rent, 2),
            "security_deposit": round(monthly_rent * 0.5, 2),
            "lease_term_months": 12,
            "lease_start_date": datetime.datetime.now().strftime("%Y-%m-%d")
        }
    
    def generate_daily_report(self) -> Dict[str, Any]:
        """Generate daily report of pending and approved applications"""
        today = datetime.datetime.now().date()
        
        pending_apps = []
        approved_apps = []
        denied_apps = []
        waitlisted_apps = []
        
        for app_id, application in self.applications.items():
            if application.decision_date and application.decision_date.date() == today:
                if application.status == ApplicationStatus.PENDING:
                    pending_apps.append(self._format_application_data(application))
                elif application.status == ApplicationStatus.APPROVED:
                    approved_apps.append(self._format_application_data(application))
                elif application.status == ApplicationStatus.DENIED:
                    denied_apps.append(self._format_application_data(application))
                elif application.status == ApplicationStatus.WAITLISTED:
                    waitlisted_apps.append(self._format_application_data(application))
        
        return {
            "report_date": today.strftime("%Y-%m-%d"),
            "total_applications": len(self.applications),
            "pending_applications": len(pending_apps),
            "approved_applications": len(approved_apps),
            "denied_applications": len(denied_apps),
            "waitlisted_applications": len(waitlisted_apps),
            "pending": pending_apps,
            "approved": approved_apps,
            "denied": denied_apps,
            "waitlisted": waitlisted_apps
        }
    
    def _format_application_data(self, application: LeaseApplication) -> Dict[str, Any]:
        """Format application data for reporting"""
        return {
            "applicant_id": application.applicant.id,
            "name": application.applicant.name,
            "tenant_viability_score": application.applicant.tenant_viability_score,
            "status": application.status.value,
            "decision_date": application.decision_date.strftime("%Y-%m-%d") if application.decision_date else None,
            "decision_reason": application.decision_reason,
            "lease_terms": application.lease_terms
        }
    
    def get_applicant(self, applicant_id: str) -> Optional[Applicant]:
        """Get applicant by ID"""
        return self.applicants.get(applicant_id)
    
    def get_application(self, applicant_id: str) -> Optional[LeaseApplication]:
        """Get application by applicant ID"""
        return self.applications.get(applicant_id)
    
    def save_system_state(self, filename: str):
        """Save system state to a JSON file"""
        state = {
            "applicants": {},
            "applications": {}
        }
        
        for applicant_id, applicant in self.applicants.items():
            state["applicants"][applicant_id] = {
                "id": applicant.id,
                "name": applicant.name,
                "email": applicant.email,
                "phone": applicant.phone,
                "application_date": applicant.application_date.isoformat(),
                "tenant_viability_score": applicant.tenant_viability_score,
                "financial_history": {
                    "monthly_income": applicant.financial_history.monthly_income,
                    "income_history": applicant.financial_history.income_history,
                    "credit_score": applicant.financial_history.credit_score,
                    "rental_history": applicant.financial_history.rental_history,
                    "debt_to_income_ratio": applicant.financial_history.debt_to_income_ratio
                },
                "household_structure": {
                    "size": applicant.household_structure.size,
                    "members": applicant.household_structure.members,
                    "dependents": applicant.household_structure.dependents
                },
                "employment": {
                    "current_employer": applicant.employment.current_employer,
                    "job_title": applicant.employment.job_title,
                    "employment_status": applicant.employment.employment_status,
                    "years_employed": applicant.employment.years_employed,
                    "employment_history": applicant.employment.employment_history
                }
            }
        
        for app_id, application in self.applications.items():
            state["applications"][app_id] = {
                "applicant_id": application.applicant.id,
                "status": application.status.value,
                "decision_date": application.decision_date.isoformat() if application.decision_date else None,
                "decision_reason": application.decision_reason,
                "lease_terms": application.lease_terms
            }
        
        with open(filename, 'w') as f:
            json.dump(state, f, indent=2)
    
    def load_system_state(self, filename: str):
        """Load system state from a JSON file"""
        with open(filename, 'r') as f:
            state = json.load(f)
        
        self.applicants = {}
        self.applications = {}
        
        for applicant_id, applicant_data in state["applicants"].items():
            financial_history = FinancialHistory(
                monthly_income=applicant_data["financial_history"]["monthly_income"],
                income_history=applicant_data["financial_history"]["income_history"],
                credit_score=applicant_data["financial_history"]["credit_score"],
                rental_history=applicant_data["financial_history"]["rental_history"],
                debt_to_income_ratio=applicant_data["financial_history"]["debt_to_income_ratio"]
            )
            
            household_structure = HouseholdStructure(
                size=applicant_data["household_structure"]["size"],
                members=applicant_data["household_structure"]["members"],
                dependents=applicant_data["household_structure"]["dependents"]
            )
            
            employment = Employment(
                current_employer=applicant_data["employment"]["current_employer"],
                job_title=applicant_data["employment"]["job_title"],
                employment_status=applicant_data["employment"]["employment_status"],
                years_employed=applicant_data["employment"]["years_employed"],
                employment_history=applicant_data["employment"]["employment_history"]
            )
            
            applicant = Applicant(
                id=applicant_data["id"],
                name=applicant_data["name"],
                email=applicant_data["email"],
                phone=applicant_data["phone"],
                financial_history=financial_history,
                household_structure=household_structure,
                employment=employment,
                application_date=datetime.datetime.fromisoformat(applicant_data["application_date"]),
                tenant_viability_score=applicant_data.get("tenant_viability_score")
            )
            
            self.applicants[applicant_id] = applicant
        
        for app_id, app_data in state["applications"].items():
            applicant = self.applicants.get(app_data["applicant_id"])
            if applicant:
                application = LeaseApplication(
                    applicant=applicant,
                    status=ApplicationStatus(app_data["status"]),
                    decision_date=datetime.datetime.fromisoformat(app_data["decision_date"]) if app_data["decision_date"] else None,
                    decision_reason=app_data["decision_reason"],
                    lease_terms=app_data["lease_terms"]
                )
                self.applications[app_id] = application

# Example usage
def main():
    # Create system instance
    system = HousingSystem()
    
    # Sample applicant data
    sample_applicant = {
        "name": "John Doe",
        "email": "john.doe@example.com",
        "phone": "555-1234",
        "financial_history": {
            "monthly_income": 4000,
            "income_history": [3800, 4100, 3900, 4200, 4000],
            "credit_score": 720,
            "rental_history": [{"status": "positive"}, {"status": "positive"}],
            "debt_to_income_ratio": 0.3
        },
        "household_structure": {
            "size": 3,
            "members": ["John Doe", "Jane Doe", "Child"],
            "dependents": 1
        },
        "employment": {
            "current_employer": "Tech Corp",
            "job_title": "Software Engineer",
            "employment_status": "full_time",
            "years_employed": 3,
            "employment_history": [
                {"employer": "Tech Corp", "duration_months": 36},
                {"employer": "Prev Co", "duration_months": 24}
            ]
        }
    }
    
    # Add applicant to system
    applicant_id = system.add_applicant(sample_applicant)
    
    # Process application
    system.process_application(applicant_id)
    
    # Generate daily report
    report = system.generate_daily_report()
    print("Daily Report:")
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()