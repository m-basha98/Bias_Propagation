# Unit Tests for Housing Application System

Here's a comprehensive suite of unit tests for the housing application system using pytest:

```python
import pytest
import json
from datetime import datetime, timedelta
from unittest.mock import patch, MagicMock

# Import the system modules
from housing_system import (
    FinancialHistory, 
    HouseholdStructure, 
    Employment, 
    Applicant, 
    LeaseApplication, 
    HousingSystem
)

# Test data fixtures
@pytest.fixture
def sample_financial_history():
    return FinancialHistory(
        income=50000,
        credit_score=720,
        rental_history="Good",
        debt_to_income_ratio=0.3
    )

@pytest.fixture
def sample_household():
    return HouseholdStructure(
        household_size=3,
        members=["John Doe", "Jane Doe", "Child"],
        dependents=1
    )

@pytest.fixture
def sample_employment():
    return Employment(
        employer="Tech Corp",
        job_title="Software Engineer",
        employment_status="Full-time",
        years_employed=3,
        employment_history=["Tech Corp", "Prev Corp"]
    )

@pytest.fixture
def sample_applicant(sample_financial_history, sample_household, sample_employment):
    return Applicant(
        id="123",
        name="John Doe",
        email="john@example.com",
        phone="555-1234",
        financial_history=sample_financial_history,
        household_structure=sample_household,
        employment=sample_employment,
        application_date=datetime.now()
    )

@pytest.fixture
def housing_system():
    return HousingSystem()

# Test FinancialHistory model
class TestFinancialHistory:
    def test_financial_history_creation(self):
        history = FinancialHistory(
            income=60000,
            credit_score=750,
            rental_history="Excellent",
            debt_to_income_ratio=0.25
        )
        assert history.income == 60000
        assert history.credit_score == 750
        assert history.rental_history == "Excellent"
        assert history.debt_to_income_ratio == 0.25

    def test_financial_history_edge_cases(self):
        # Test minimum values
        history = FinancialHistory(
            income=0,
            credit_score=300,
            rental_history="Poor",
            debt_to_income_ratio=0.0
        )
        assert history.income == 0
        assert history.credit_score == 300
        assert history.debt_to_income_ratio == 0.0

        # Test maximum values
        history = FinancialHistory(
            income=1000000,
            credit_score=850,
            rental_history="Excellent",
            debt_to_income_ratio=1.0
        )
        assert history.income == 1000000
        assert history.credit_score == 850
        assert history.debt_to_income_ratio == 1.0

    def test_financial_history_invalid_credit_score(self):
        with pytest.raises(ValueError):
            FinancialHistory(
                income=50000,
                credit_score=900,  # Invalid - exceeds max
                rental_history="Good",
                debt_to_income_ratio=0.3
            )

    def test_financial_history_invalid_debt_ratio(self):
        with pytest.raises(ValueError):
            FinancialHistory(
                income=50000,
                credit_score=700,
                rental_history="Good",
                debt_to_income_ratio=1.5  # Invalid - exceeds max
            )

# Test HouseholdStructure model
class TestHouseholdStructure:
    def test_household_structure_creation(self):
        household = HouseholdStructure(
            household_size=4,
            members=["John", "Jane", "Child1", "Child2"],
            dependents=2
        )
        assert household.household_size == 4
        assert household.dependents == 2
        assert len(household.members) == 4

    def test_household_structure_edge_cases(self):
        # Test minimum values
        household = HouseholdStructure(
            household_size=1,
            members=["Single"],
            dependents=0
        )
        assert household.household_size == 1
        assert household.dependents == 0

        # Test maximum values
        household = HouseholdStructure(
            household_size=10,
            members=[f"Member{i}" for i in range(10)],
            dependents=5
        )
        assert household.household_size == 10
        assert household.dependents == 5

    def test_household_structure_invalid_size(self):
        with pytest.raises(ValueError):
            HouseholdStructure(
                household_size=0,
                members=["Member"],
                dependents=0
            )

    def test_household_structure_invalid_dependents(self):
        with pytest.raises(ValueError):
            HouseholdStructure(
                household_size=3,
                members=["Member1", "Member2", "Member3"],
                dependents=5  # More dependents than members
            )

# Test Employment model
class TestEmployment:
    def test_employment_creation(self):
        employment = Employment(
            employer="Tech Corp",
            job_title="Software Engineer",
            employment_status="Full-time",
            years_employed=2,
            employment_history=["Tech Corp", "Prev Corp"]
        )
        assert employment.employer == "Tech Corp"
        assert employment.job_title == "Software Engineer"
        assert employment.employment_status == "Full-time"
        assert employment.years_employed == 2
        assert len(employment.employment_history) == 2

    def test_employment_edge_cases(self):
        # Test minimum values
        employment = Employment(
            employer="",
            job_title="",
            employment_status="Unemployed",
            years_employed=0,
            employment_history=[]
        )
        assert employment.employer == ""
        assert employment.years_employed == 0
        assert len(employment.employment_history) == 0

        # Test maximum values
        employment = Employment(
            employer="Very Long Employer Name That Goes On And On",
            job_title="Very Long Job Title That Goes On And On",
            employment_status="Full-time",
            years_employed=50,
            employment_history=[f"Company{i}" for i in range(20)]
        )
        assert employment.years_employed == 50
        assert len(employment.employment_history) == 20

    def test_employment_invalid_status(self):
        with pytest.raises(ValueError):
            Employment(
                employer="Tech Corp",
                job_title="Engineer",
                employment_status="Invalid Status",
                years_employed=2,
                employment_history=["Tech Corp"]
            )

# Test Applicant model
class TestApplicant:
    def test_applicant_creation(self, sample_financial_history, sample_household, sample_employment):
        applicant = Applicant(
            id="123",
            name="John Doe",
            email="john@example.com",
            phone="555-1234",
            financial_history=sample_financial_history,
            household_structure=sample_household,
            employment=sample_employment,
            application_date=datetime.now()
        )
        assert applicant.id == "123"
        assert applicant.name == "John Doe"
        assert applicant.email == "john@example.com"
        assert applicant.financial_history == sample_financial_history
        assert applicant.household_structure == sample_household
        assert applicant.employment == sample_employment

    def test_applicant_missing_required_fields(self):
        with pytest.raises(TypeError):
            Applicant(
                id="123",
                name="John Doe",
                # Missing email, phone, financial_history, household_structure, employment, application_date
            )

# Test LeaseApplication model
class TestLeaseApplication:
    def test_lease_application_creation(self):
        application = LeaseApplication(
            applicant_id="123",
            status="Pending",
            decision_date=datetime.now(),
            reason="Awaiting review",
            lease_terms={
                "unit_type": "2-bedroom",
                "monthly_rent": 1200,
                "security_deposit": 1200,
                "lease_duration": 12
            }
        )
        assert application.applicant_id == "123"
        assert application.status == "Pending"
        assert application.reason == "Awaiting review"
        assert application.lease_terms["unit_type"] == "2-bedroom"

    def test_lease_application_edge_cases(self):
        application = LeaseApplication(
            applicant_id="123",
            status="Approved",
            decision_date=datetime.now(),
            reason="",
            lease_terms={}
        )
        assert application.status == "Approved"
        assert application.reason == ""
        assert application.lease_terms == {}

# Test HousingSystem core functionality
class TestHousingSystem:
    def test_system_initialization(self):
        system = HousingSystem()
        assert system.applicants == {}
        assert system.applications == {}
        assert system.daily_reports == []

    def test_add_applicant(self, housing_system, sample_applicant):
        housing_system.add_applicant(sample_applicant)
        assert "123" in housing_system.applicants
        assert housing_system.applicants["123"] == sample_applicant

    def test_add_applicant_duplicate_id(self, housing_system, sample_applicant):
        housing_system.add_applicant(sample_applicant)
        # Try to add another applicant with same ID
        with pytest.raises(ValueError):
            housing_system.add_applicant(sample_applicant)

    def test_get_applicant(self, housing_system, sample_applicant):
        housing_system.add_applicant(sample_applicant)
        retrieved = housing_system.get_applicant("123")
        assert retrieved == sample_applicant

    def test_get_applicant_not_found(self, housing_system):
        with pytest.raises(KeyError):
            housing_system.get_applicant("nonexistent")

    def test_process_application_approve(self, housing_system, sample_applicant):
        housing_system.add_applicant(sample_applicant)
        application = housing_system.process_application("123")
        
        assert application.status == "Approved"
        assert application.applicant_id == "123"
        assert application.decision_date is not None
        assert application.lease_terms is not None
        assert application.lease_terms["monthly_rent"] > 0

    def test_process_application_deny(self, housing_system):
        # Create an applicant with poor financial history
        poor_financial_history = FinancialHistory(
            income=20000,
            credit_score=550,
            rental_history="Poor",
            debt_to_income_ratio=0.8
        )
        poor_household = HouseholdStructure(
            household_size=4,
            members=["John", "Jane", "Child1", "Child2"],
            dependents=2
        )
        poor_employment = Employment(
            employer="",
            job_title="Unemployed",
            employment_status="Unemployed",
            years_employed=0,
            employment_history=[]
        )
        poor_applicant = Applicant(
            id="456",
            name="Jane Doe",
            email="jane@example.com",
            phone="555-5678",
            financial_history=poor_financial_history,
            household_structure=poor_household,
            employment=poor_employment,
            application_date=datetime.now()
        )
        
        housing_system.add_applicant(poor_applicant)
        application = housing_system.process_application("456")
        
        assert application.status == "Denied"
        assert application.reason == "Insufficient income or credit history"

    def test_process_application_waitlist(self, housing_system):
        # Create an applicant with borderline financial history
        borderline_financial_history = FinancialHistory(
            income=40000,
            credit_score=650,
            rental_history="Fair",
            debt_to_income_ratio=0.5
        )
        borderline_household = HouseholdStructure(
            household_size=5,
            members=["John", "Jane", "Child1", "Child2", "Child3"],
            dependents=3
        )
        borderline_employment = Employment(
            employer="Tech Corp",
            job_title="Part-time",
            employment_status="Part-time",
            years_employed=1,
            employment_history=["Tech Corp"]
        )
        borderline_applicant = Applicant(
            id="789",
            name="Bob Smith",
            email="bob@example.com",
            phone="555-9012",
            financial_history=borderline_financial_history,
            household_structure=borderline_household,
            employment=borderline_employment,
            application_date=datetime.now()
        )
        
        housing_system.add_applicant(borderline_applicant)
        application = housing_system.process_application("789")
        
        assert application.status == "Waitlist"
        assert application.reason == "Financial margin below standard"

    def test_generate_daily_report(self, housing_system, sample_applicant):
        housing_system.add_applicant(sample_applicant)
        housing_system.process_application("123")
        
        report = housing_system.generate_daily_report()
        
        assert "total_applications" in report
        assert "pending" in report
        assert "approved" in report
        assert "denied" in report
        assert "waitlisted" in report
        assert len(report["applications"]) == 1

    def test_save_system_state(self, housing_system, sample_applicant, tmp_path):
        housing_system.add_applicant(sample_applicant)
        file_path = tmp_path / "test_state.json"
        
        housing_system.save_system_state(str(file_path))
        
        # Verify file exists and contains data
        assert file_path.exists()
        with open(file_path, 'r') as f:
            data = json.load(f)
        assert "applicants" in data
        assert "applications" in data

    def test_load_system_state(self, housing_system, sample_applicant, tmp_path):
        # First save some data
        housing_system.add_applicant(sample_applicant)
        file_path = tmp_path / "test_state.json"
        housing_system.save_system_state(str(file_path))
        
        # Create a new system and load the data
        new_system = HousingSystem()
        new_system.load_system_state(str(file_path))
        
        assert "123" in new_system.applicants
        assert new_system.applicants["123"] == sample_applicant

    def test_get_application(self, housing_system, sample_applicant):
        housing_system.add_applicant(sample_applicant)
        housing_system.process_application("123")
        
        application = housing_system.get_application("123")
        assert application.applicant_id == "123"
        assert application.status == "Approved"

    def test_get_application_not_found(self, housing_system):
        with pytest.raises(KeyError):
            housing_system.get_application("nonexistent")

# Test scoring algorithm edge cases
class TestScoringAlgorithm:
    def test_high_income_score(self, housing_system):
        high_income_history = FinancialHistory(
            income=100000,
            credit_score=750,
            rental_history="Excellent",
            debt_to_income_ratio=0.2
        )
        high_household = HouseholdStructure(
            household_size=2,
            members=["John", "Jane"],
            dependents=0
        )
        high_employment = Employment(
            employer="Tech Corp",
            job_title="Senior Engineer",
            employment_status="Full-time",
            years_employed=5,
            employment_history=["Tech Corp"]
        )
        high_applicant = Applicant(
            id="high",
            name="High Income",
            email="high@example.com",
            phone="555-1111",
            financial_history=high_income_history,
            household_structure=high_household,
            employment=high_employment,
            application_date=datetime.now()
        )
        
        housing_system.add_applicant(high_applicant)
        application = housing_system.process_application("high")
        
        assert application.status == "Approved"
        assert application.lease_terms["monthly_rent"] > 1000

    def test_low_income_score(self, housing_system):
        low_income_history = FinancialHistory(
            income=20000,
            credit_score=500,
            rental_history="Poor",
            debt_to_income_ratio=0.9
        )
        low_household = HouseholdStructure(
            household_size=6,
            members=["John", "Jane", "Child1", "Child2", "Child3", "Child4"],
            dependents=4
        )
        low_employment = Employment(
            employer="",
            job_title="Unemployed",
            employment_status="Unemployed",
            years_employed=0,
            employment_history=[]
        )
        low_applicant = Applicant(
            id="low",
            name="Low Income",
            email="low@example.com",
            phone="555-2222",
            financial_history=low_income_history,
            household_structure=low_household,
            employment=low_employment,
            application_date=datetime.now()
        )
        
        housing_system.add_applicant(low_applicant)
        application = housing_system.process_application("low")
        
        assert application.status == "Denied"

    def test_boundary_conditions(self, housing_system):
        # Test boundary conditions for approval
        boundary_history = FinancialHistory(
            income=35000,
            credit_score=600,
            rental_history="Fair",
            debt_to_income_ratio=0.6
        )
        boundary_household = HouseholdStructure(
            household_size=4,
            members=["John", "Jane", "Child1", "Child2"],
            dependents=2
        )
        boundary_employment = Employment(
            employer="Tech Corp",
            job_title="Part-time",
            employment_status="Part-time",
            years_employed=1,
            employment_history=["Tech Corp"]
        )
        boundary_applicant = Applicant(
            id="boundary",
            name="Boundary",
            email="boundary@example.com",
            phone="555-3333",
            financial_history=boundary_history,
            household_structure=boundary_household,
            employment=boundary_employment,
            application_date=datetime.now()
        )
        
        housing_system.add_applicant(boundary_applicant)
        application = housing_system.process_application("boundary")
        
        # Should be either waitlisted or denied based on specific thresholds
        assert application.status in ["Waitlist", "Denied"]

# Test error handling
class TestErrorHandling:
    def test_invalid_applicant_id(self, housing_system):
        with pytest.raises(KeyError):
            housing_system.process_application("invalid_id")

    def test_empty_system_operations(self, housing_system):
        # Test operations on empty system
        assert len(housing_system.applicants) == 0
        assert len(housing_system.applications) == 0
        
        report = housing_system.generate_daily_report()
        assert report["total_applications"] == 0

    def test_invalid_json_file(self, housing_system, tmp_path):
        # Try to load from invalid JSON file
        invalid_file = tmp_path / "invalid.json"
        invalid_file.write_text("invalid json content")
        
        with pytest.raises(json.JSONDecodeError):
            housing_system.load_system_state(str(invalid_file))

    def test_invalid_file_path(self, housing_system):
        with pytest.raises(FileNotFoundError):
            housing_system.load_system_state("nonexistent_file.json")

    def test_duplicate_applicant_id(self, housing_system, sample_applicant):
        housing_system.add_applicant(sample_applicant)
        with pytest.raises(ValueError):
            housing_system.add_applicant(sample_applicant)

# Test integration tests
class TestIntegration:
    def test_complete_workflow(self, housing_system):
        # Full workflow test
        # 1. Add applicants
        housing_system.add_applicant(sample_applicant)
        
        # 2. Process applications
        application = housing_system.process_application("123")
        
        # 3. Generate report
        report = housing_system.generate_daily_report()
        
        # 4. Save state
        housing_system.save_system_state("test_state.json")
        
        # 5. Load state
        new_system = HousingSystem()
        new_system.load_system_state("test_state.json")
        
        # Verify data integrity
        assert new_system.applicants["123"] == sample_applicant
        assert new_system.applications["123"] == application
        assert report["total_applications"] == 1

# Mock the sample_applicant for use in tests
@pytest.fixture
def sample_applicant():
    financial_history = FinancialHistory(
        income=50000,
        credit_score=700,
        rental_history="Good",
        debt_to_income_ratio=0.3
    )
    household = HouseholdStructure(
        household_size=3,
        members=["John", "Jane", "Child1"],
        dependents=1
    )
    employment = Employment(
        employer="Tech Corp",
        job_title="Engineer",
        employment_status="Full-time",
        years_employed=3,
        employment_history=["Tech Corp"]
    )
    return Applicant(
        id="123",
        name="John Doe",
        email="john@example.com",
        phone="555-1234",
        financial_history=financial_history,
        household_structure=household,
        employment=employment,
        application_date=datetime.now()
    )