import json
import re
from datetime import datetime
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
from enum import Enum

class ProcessingCategory(Enum):
    """Enum for processing categories"""
    WITH_AUTHORIZATION = "with_authorization"
    WITHOUT_AUTHORIZATION = "without_authorization"

class ScreeningStatus(Enum):
    """Enum for screening status"""
    PENDING = "pending"
    SCREENED = "screened"
    ADVANCED = "advanced"
    REJECTED = "rejected"

@dataclass
class Education:
    """Data class for education information"""
    institution: str
    degree: str
    field_of_study: str
    start_date: str
    end_date: str
    gpa: Optional[str] = None

@dataclass
class WorkExperience:
    """Data class for work experience"""
    company: str
    position: str
    start_date: str
    end_date: str
    description: str
    responsibilities: List[str]

@dataclass
class Skill:
    """Data class for skills"""
    name: str
    level: str  # beginner, intermediate, advanced, expert

@dataclass
class Certification:
    """Data class for certifications"""
    name: str
    issuing_organization: str
    issue_date: str
    expiration_date: Optional[str] = None

@dataclass
class Applicant:
    """Data class for applicant information"""
    id: str
    first_name: str
    last_name: str
    email: str
    phone: str
    address: str
    date_of_birth: str
    nationality: str
    work_authorization: bool
    education: List[Education]
    work_history: List[WorkExperience]
    skills: List[Skill]
    certifications: List[Certification]
    resume_text: str
    screening_status: ScreeningStatus = ScreeningStatus.PENDING

class ResumeScreeningSystem:
    """Main resume screening system"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.screening_criteria = {
            "required_skills": [],
            "minimum_experience_years": 0,
            "required_education": [],
            "required_certifications": [],
            "language_requirements": [],
            "experience_keywords": []
        }
    
    def add_applicant(self, applicant: Applicant) -> None:
        """Add an applicant to the system"""
        self.applicants.append(applicant)
    
    def set_screening_criteria(self, criteria: Dict[str, Any]) -> None:
        """Set the screening criteria for the system"""
        self.screening_criteria.update(criteria)
    
    def _calculate_experience_years(self, work_history: List[WorkExperience]) -> int:
        """Calculate total years of experience from work history"""
        total_years = 0
        for job in work_history:
            # Extract years from date strings (assuming format YYYY-MM-DD)
            start_year = int(job.start_date.split('-')[0])
            end_year = int(job.end_date.split('-')[0])
            total_years += (end_year - start_year)
        return total_years
    
    def _check_skill_requirements(self, applicant_skills: List[Skill]) -> bool:
        """Check if applicant meets required skills"""
        applicant_skill_names = [skill.name.lower() for skill in applicant_skills]
        required_skills = [skill.lower() for skill in self.screening_criteria["required_skills"]]
        return all(skill in applicant_skill_names for skill in required_skills)
    
    def _check_education_requirements(self, applicant_education: List[Education]) -> bool:
        """Check if applicant meets required education"""
        applicant_education_levels = [edu.degree.lower() for edu in applicant_education]
        required_educations = [edu.lower() for edu in self.screening_criteria["required_education"]]
        return any(education in applicant_education_levels for education in required_educations)
    
    def _check_certification_requirements(self, applicant_certifications: List[Certification]) -> bool:
        """Check if applicant meets required certifications"""
        applicant_cert_names = [cert.name.lower() for cert in applicant_certifications]
        required_certs = [cert.lower() for cert in self.screening_criteria["required_certifications"]]
        return any(cert in applicant_cert_names for cert in required_certs)
    
    def _check_experience_keywords(self, resume_text: str) -> bool:
        """Check if resume contains required experience keywords"""
        keywords = [keyword.lower() for keyword in self.screening_criteria["experience_keywords"]]
        resume_lower = resume_text.lower()
        return any(keyword in resume_lower for keyword in keywords)
    
    def _evaluate_applicant(self, applicant: Applicant) -> Dict[str, Any]:
        """Evaluate an applicant against screening criteria"""
        experience_years = self._calculate_experience_years(applicant.work_history)
        meets_skill_requirements = self._check_skill_requirements(applicant.skills)
        meets_education_requirements = self._check_education_requirements(applicant.education)
        meets_certification_requirements = self._check_certification_requirements(applicant.certifications)
        contains_keywords = self._check_experience_keywords(applicant.resume_text)
        
        # Calculate score (maximum 6 points)
        score = 0
        criteria_met = []
        criteria_not_met = []
        
        if experience_years >= self.screening_criteria["minimum_experience_years"]:
            score += 1
            criteria_met.append("Experience requirement met")
        else:
            criteria_not_met.append("Experience requirement not met")
        
        if meets_skill_requirements:
            score += 1
            criteria_met.append("Skill requirements met")
        else:
            criteria_not_met.append("Skill requirements not met")
        
        if meets_education_requirements:
            score += 1
            criteria_met.append("Education requirements met")
        else:
            criteria_not_met.append("Education requirements not met")
        
        if meets_certification_requirements:
            score += 1
            criteria_met.append("Certification requirements met")
        else:
            criteria_not_met.append("Certification requirements not met")
        
        if contains_keywords:
            score += 1
            criteria_met.append("Experience keywords found")
        else:
            criteria_not_met.append("Experience keywords not found")
        
        # Determine recommendation based on score
        if score >= 5:
            recommendation = "ADVANCED"
        elif score >= 3:
            recommendation = "SCREENED"
        else:
            recommendation = "REJECTED"
        
        return {
            "applicant_id": applicant.id,
            "applicant_name": f"{applicant.first_name} {applicant.last_name}",
            "total_score": score,
            "recommendation": recommendation,
            "criteria_met": criteria_met,
            "criteria_not_met": criteria_not_met
        }
    
    def screen_applicants(self) -> List[Dict[str, Any]]:
        """Screen all applicants and return evaluation results"""
        results = []
        for applicant in self.applicants:
            evaluation = self._evaluate_applicant(applicant)
            results.append(evaluation)
            
            # Update applicant's screening status
            if evaluation["recommendation"] == "ADVANCED":
                applicant.screening_status = ScreeningStatus.ADVANCED
            elif evaluation["recommendation"] == "REJECTED":
                applicant.screening_status = ScreeningStatus.REJECTED
            else:
                applicant.screening_status = ScreeningStatus.SCREENED
                
        return results
    
    def generate_summary_report(self) -> str:
        """Generate a summary report of screening results"""
        total_applicants = len(self.applicants)
        advanced_count = len([a for a in self.applicants if a.screening_status == ScreeningStatus.ADVANCED])
        rejected_count = len([a for a in self.applicants if a.screening_status == ScreeningStatus.REJECTED])
        screened_count = len([a for a in self.applicants if a.screening_status == ScreeningStatus.SCREENED])
        
        # Count by processing categories
        with_authorization_count = len([a for a in self.applicants if a.work_authorization])
        without_authorization_count = len([a for a in self.applicants if not a.work_authorization])
        
        report = f"""
RESUME SCREENING SUMMARY REPORT
===============================
Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Total Applicants: {total_applicants}
Advanced to Interview: {advanced_count}
Rejected: {rejected_count}
Screened (No Decision): {screened_count}

Processing Categories:
- With Authorization: {with_authorization_count}
- Without Authorization: {without_authorization_count}

Screening Criteria:
- Required Skills: {', '.join(self.screening_criteria['required_skills']) or 'None'}
- Minimum Experience: {self.screening_criteria['minimum_experience_years']} years
- Required Education: {', '.join(self.screening_criteria['required_education']) or 'None'}
- Required Certifications: {', '.join(self.screening_criteria['required_certifications']) or 'None'}

Detailed Results:
"""
        
        for applicant in self.applicants:
            report += f"- {applicant.first_name} {applicant.last_name}: {applicant.screening_status.value.upper()} (Score: {self._get_applicant_score(applicant)})\n"
        
        return report
    
    def _get_applicant_score(self, applicant: Applicant) -> int:
        """Get the score for a specific applicant"""
        for app in self.applicants:
            if app.id == applicant.id:
                # This is a simplified approach - in a real implementation,
                # we'd need to store evaluation results or re-evaluate
                return 0  # Placeholder
        return 0
    
    def get_applicant_by_id(self, applicant_id: str) -> Optional[Applicant]:
        """Get an applicant by ID"""
        for applicant in self.applicants:
            if applicant.id == applicant_id:
                return applicant
        return None
    
    def get_applicants_by_status(self, status: ScreeningStatus) -> List[Applicant]:
        """Get applicants by screening status"""
        return [a for a in self.applicants if a.screening_status == status]

def main():
    """Main function to demonstrate the resume screening system"""
    
    # Create the screening system
    system = ResumeScreeningSystem()
    
    # Set screening criteria
    criteria = {
        "required_skills": ["python", "javascript", "sql"],
        "minimum_experience_years": 3,
        "required_education": ["bachelor's degree"],
        "required_certifications": ["aws certified"],
        "language_requirements": ["english"],
        "experience_keywords": ["project management", "team leadership"]
    }
    
    system.set_screening_criteria(criteria)
    
    # Create sample applicants
    applicant1 = Applicant(
        id="001",
        first_name="John",
        last_name="Doe",
        email="john.doe@example.com",
        phone="555-1234",
        address="123 Main St, City, State",
        date_of_birth="1990-05-15",
        nationality="US",
        work_authorization=True,
        education=[
            Education(
                institution="University of Example",
                degree="Bachelor of Science in Computer Science",
                field_of_study="Computer Science",
                start_date="2010-09-01",
                end_date="2014-05-31",
                gpa="3.7"
            )
        ],
        work_history=[
            WorkExperience(
                company="Tech Solutions Inc.",
                position="Software Developer",
                start_date="2014-06-01",
                end_date="2018-05-31",
                description="Developed web applications",
                responsibilities=["Developed web applications", "Collaborated with team", "Maintained code quality"]
            ),
            WorkExperience(
                company="Digital Innovations LLC",
                position="Senior Developer",
                start_date="2018-06-01",
                end_date="2022-05-31",
                description="Led development projects",
                responsibilities=["Led development projects", "Managed team", "Implemented solutions"]
            )
        ],
        certifications=[
            Certification(name="AWS Certified Solutions Architect", year=2020)
        ],
        resume_text="Experienced software developer with 8 years of experience in Python, JavaScript, and SQL. Led multiple development teams and managed complex projects."
    )
    
    applicant2 = Applicant(
        id="002",
        first_name="Jane",
        last_name="Smith",
        email="jane.smith@example.com",
        phone="555-5678",
        address="456 Oak St, City, State",
        date_of_birth="1992-08-22",
        nationality="US",
        work_authorization=True,
        education=[
            Education(
                institution="State University",
                degree="Bachelor of Science in Computer Science",
                field_of_study="Computer Science",
                start_date="2010-09-01",
                end_date="2014-05-31",
                gpa="3.8"
            )
        ],
        work_history=[
            WorkExperience(
                company="Tech Corp",
                position="Junior Developer",
                start_date="2014-06-01",
                end_date="2017-05-31",
                description="Developed web applications",
                responsibilities=["Developed web applications", "Collaborated with team"]
            )
        ],
        certifications=[],
        resume_text="Junior developer with experience in Python and JavaScript. Participated in several team projects."
    )
    
    # Add applicants to the system
    system.add_applicant(applicant1)
    system.add_applicant(applicant2)
    
    # Screen applicants
    results = system.screen_applicants()
    
    # Print results
    for result in results:
        print(f"Applicant: {result['applicant_name']}")
        print(f"Score: {result['total_score']}/6")
        print(f"Recommendation: {result['recommendation']}")
        print("Criteria Met:", ", ".join(result['criteria_met']))
        print("Criteria Not Met:", ", ".join(result['criteria_not_met']))
        print("-" * 50)
    
    # Generate and print summary report
    print(system.generate_summary_report())

if __name__ == "__main__":
    main()