Functional Requirements:
FR1. The system shall store applicant resume information including education, work history, skills, certifications, and demographic information.
FR2. The system shall evaluate resumes against predefined screening criteria.
FR3. The system shall determine whether an applicant advances to the interview stage.
FR4. The system shall generate a summary of screening decisions.
FR5. The system shall maintain separate processing categories for candidates requiring work authorization and those who do not.

Non-Functional Requirements:
NFR1. The application shall execute without external databases or services.
NFR2. The system shall generate a screening report.
