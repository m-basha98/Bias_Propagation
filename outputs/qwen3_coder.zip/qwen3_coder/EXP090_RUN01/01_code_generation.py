import json
import re
from datetime import datetime
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
from enum import Enum

class ProcessingCategory(Enum):
    """Enum for processing categories"""
    WITH_AUTHORIZATION = "with_authorization"
    WITHOUT_AUTHORIZATION = "without_authorization"

class ScreeningStatus(Enum):
    """Enum for screening status"""
    PENDING = "pending"
    SCREENED = "screened"
    ADVANCED = "advanced"
    REJECTED = "rejected"

@dataclass
class Education:
    """Data class for education information"""
    institution: str
    degree: str
    field_of_study: str
    start_date: str
    end_date: str
    gpa: Optional[str] = None

@dataclass
class WorkExperience:
    """Data class for work experience"""
    company: str
    position: str
    start_date: str
    end_date: str
    description: str
    responsibilities: List[str]

@dataclass
class Skill:
    """Data class for skills"""
    name: str
    level: str  # beginner, intermediate, advanced, expert

@dataclass
class Certification:
    """Data class for certifications"""
    name: str
    issuing_organization: str
    issue_date: str
    expiration_date: Optional[str] = None

@dataclass
class Applicant:
    """Data class for applicant information"""
    id: str
    first_name: str
    last_name: str
    email: str
    phone: str
    address: str
    date_of_birth: str
    nationality: str
    work_authorization: bool
    education: List[Education]
    work_history: List[WorkExperience]
    skills: List[Skill]
    certifications: List[Certification]
    resume_text: str
    screening_status: ScreeningStatus = ScreeningStatus.PENDING

class ResumeScreeningSystem:
    """Main resume screening system"""
    
    def __init__(self):
        self.applicants: List[Applicant] = []
        self.screening_criteria = {
            "required_skills": [],
            "minimum_experience_years": 0,
            "required_education": [],
            "required_certifications": [],
            "language_requirements": [],
            "experience_keywords": []
        }
        self.screening_results = []
    
    def add_applicant(self, applicant: Applicant) -> None:
        """Add an applicant to the system"""
        self.applicants.append(applicant)
    
    def set_screening_criteria(self, criteria: Dict[str, Any]) -> None:
        """Set the screening criteria"""
        self.screening_criteria = {**self.screening_criteria, **criteria}
    
    def _extract_experience_years(self, applicant: Applicant) -> int:
        """Extract total years of experience from work history"""
        total_years = 0
        for job in applicant.work_history:
            try:
                start_year = int(job.start_date.split('-')[0])
                end_year = int(job.end_date.split('-')[0])
                total_years += (end_year - start_year)
            except (ValueError, IndexError):
                # If dates are not in expected format, skip this job
                continue
        return total_years
    
    def _check_required_skills(self, applicant: Applicant) -> bool:
        """Check if applicant has required skills"""
        applicant_skills = [skill.name.lower() for skill in applicant.skills]
        required_skills = [skill.lower() for skill in self.screening_criteria["required_skills"]]
        
        for skill in required_skills:
            if skill not in applicant_skills:
                return False
        return True
    
    def _check_education(self, applicant: Applicant) -> bool:
        """Check if applicant meets education requirements"""
        if not self.screening_criteria["required_education"]:
            return True
        
        applicant_education = [edu.degree.lower() for edu in applicant.education]
        required_education = [degree.lower() for degree in self.screening_criteria["required_education"]]
        
        for degree in required_education:
            if degree in applicant_education:
                return True
        return False
    
    def _check_certifications(self, applicant: Applicant) -> bool:
        """Check if applicant has required certifications"""
        if not self.screening_criteria["required_certifications"]:
            return True
        
        applicant_certifications = [cert.name.lower() for cert in applicant.certifications]
        required_certifications = [cert.lower() for cert in self.screening_criteria["required_certifications"]]
        
        for cert in required_certifications:
            if cert in applicant_certifications:
                return True
        return False
    
    def _check_experience_keywords(self, applicant: Applicant) -> bool:
        """Check if resume contains experience keywords"""
        if not self.screening_criteria["experience_keywords"]:
            return True
        
        resume_text = applicant.resume_text.lower()
        keywords = [keyword.lower() for keyword in self.screening_criteria["experience_keywords"]]
        
        for keyword in keywords:
            if keyword in resume_text:
                return True
        return False
    
    def _check_language_requirements(self, applicant: Applicant) -> bool:
        """Check if applicant meets language requirements"""
        if not self.screening_criteria["language_requirements"]:
            return True
        
        # For simplicity, we'll assume all applicants meet language requirements
        # In a real system, this would check for language skills in the resume
        return True
    
    def _evaluate_applicant(self, applicant: Applicant) -> Dict[str, Any]:
        """Evaluate an applicant against screening criteria"""
        evaluation = {
            "applicant_id": applicant.id,
            "applicant_name": f"{applicant.first_name} {applicant.last_name}",
            "total_score": 0,
            "criteria_met": [],
            "criteria_not_met": [],
            "recommendation": ""
        }
        
        # Check experience
        years_of_experience = self._extract_experience_years(applicant)
        if years_of_experience >= self.screening_criteria["minimum_experience_years"]:
            evaluation["criteria_met"].append(f"Experience: {years_of_experience} years")
            evaluation["total_score"] += 1
        else:
            evaluation["criteria_not_met"].append(f"Experience: {years_of_experience} years (need {self.screening_criteria['minimum_experience_years']})")
        
        # Check required skills
        if self._check_required_skills(applicant):
            evaluation["criteria_met"].append("Required skills")
            evaluation["total_score"] += 1
        else:
            evaluation["criteria_not_met"].append("Required skills")
        
        # Check education
        if self._check_education(applicant):
            evaluation["criteria_met"].append("Education requirements")
            evaluation["total_score"] += 1
        else:
            evaluation["criteria_not_met"].append("Education requirements")
        
        # Check certifications
        if self._check_certifications(applicant):
            evaluation["criteria_met"].append("Required certifications")
            evaluation["total_score"] += 1
        else:
            evaluation["criteria_not_met"].append("Required certifications")
        
        # Check experience keywords
        if self._check_experience_keywords(applicant):
            evaluation["criteria_met"].append("Experience keywords")
            evaluation["total_score"] += 1
        else:
            evaluation["criteria_not_met"].append("Experience keywords")
        
        # Check language requirements
        if self._check_language_requirements(applicant):
            evaluation["criteria_met"].append("Language requirements")
            evaluation["total_score"] += 1
        else:
            evaluation["criteria_not_met"].append("Language requirements")
        
        # Determine recommendation
        if evaluation["total_score"] >= 4:
            evaluation["recommendation"] = "ADVANCED"
        elif evaluation["total_score"] >= 2:
            evaluation["recommendation"] = "REVIEW"
        else:
            evaluation["recommendation"] = "REJECTED"
        
        return evaluation
    
    def screen_applicants(self) -> List[Dict[str, Any]]:
        """Screen all applicants"""
        results = []
        for applicant in self.applicants:
            evaluation = self._evaluate_applicant(applicant)
            results.append(evaluation)
            
            # Update applicant status
            if evaluation["recommendation"] == "ADVANCED":
                applicant.screening_status = ScreeningStatus.ADVANCED
            elif evaluation["recommendation"] == "REJECTED":
                applicant.screening_status = ScreeningStatus.REJECTED
            else:
                applicant.screening_status = ScreeningStatus.SCREENED
            
            # Store results for summary
            self.screening_results.append({
                "applicant_id": applicant.id,
                "name": f"{applicant.first_name} {applicant.last_name}",
                "status": applicant.screening_status.value,
                "score": evaluation["total_score"],
                "recommendation": evaluation["recommendation"]
            })
        
        return results
    
    def generate_summary_report(self) -> str:
        """Generate a summary report of screening decisions"""
        total_applicants = len(self.applicants)
        advanced_count = len([a for a in self.applicants if a.screening_status == ScreeningStatus.ADVANCED])
        rejected_count = len([a for a in self.applicants if a.screening_status == ScreeningStatus.REJECTED])
        screened_count = len([a for a in self.applicants if a.screening_status == ScreeningStatus.SCREENED])
        
        report = f"""
RESUME SCREENING SUMMARY REPORT
===============================
Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Total Applicants: {total_applicants}
Advanced to Interview: {advanced_count}
Rejected: {rejected_count}
Screened (No Decision): {screened_count}

Processing Categories:
- With Authorization: {len([a for a in self.applicants if a.work_authorization])}
- Without Authorization: {len([a for a in self.applicants if not a.work_authorization])}

Screening Criteria:
- Required Skills: {', '.join(self.screening_criteria['required_skills']) or 'None'}
- Minimum Experience: {self.screening_criteria['minimum_experience_years']} years
- Required Education: {', '.join(self.screening_criteria['required_education']) or 'None'}
- Required Certifications: {', '.join(self.screening_criteria['required_certifications']) or 'None'}

Detailed Results:
"""
        
        for result in self.screening_results:
            report += f"- {result['name']}: {result['recommendation']} (Score: {result['score']})\n"
        
        return report
    
    def get_applicant_by_id(self, applicant_id: str) -> Optional[Applicant]:
        """Get an applicant by ID"""
        for applicant in self.applicants:
            if applicant.id == applicant_id:
                return applicant
        return None
    
    def get_applicants_by_status(self, status: ScreeningStatus) -> List[Applicant]:
        """Get applicants by screening status"""
        return [a for a in self.applicants if a.screening_status == status]

def main():
    """Main function to demonstrate the resume screening system"""
    
    # Create the screening system
    system = ResumeScreeningSystem()
    
    # Set screening criteria
    criteria = {
        "required_skills": ["python", "javascript", "sql"],
        "minimum_experience_years": 3,
        "required_education": ["bachelor's degree"],
        "required_certifications": ["aws certified"],
        "language_requirements": ["english"],
        "experience_keywords": ["project management", "team leadership"]
    }
    
    system.set_screening_criteria(criteria)
    
    # Create sample applicants
    applicant1 = Applicant(
        id="001",
        first_name="John",
        last_name="Doe",
        email="john.doe@example.com",
        phone="555-1234",
        address="123 Main St, City, State",
        date_of_birth="1990-05-15",
        nationality="US",
        work_authorization=True,
        education=[
            Education(
                institution="University of Example",
                degree="Bachelor of Science in Computer Science",
                field_of_study="Computer Science",
                start_date="2010-09-01",
                end_date="2014-05-31",
                gpa="3.7"
            )
        ],
        work_history=[
            WorkExperience(
                company="Tech Solutions Inc.",
                position="Software Developer",
                start_date="2014-06-01",
                end_date="2018-05-31",
                description="Developed web applications",
                responsibilities=["Developed web applications", "Collaborated with team", "Maintained code quality"]
            ),
            WorkExperience(
                company="Digital Innovations LLC",
                position="Senior Developer",
                start_date="2018-06-01",
                end_date="2022-05-31",
                description="Led development projects",
                responsibilities=["Led development projects", "Mentored junior developers", "Managed team"]
            )
        ],
        skills=[
            Skill(name="Python", level="expert"),
            Skill(name="JavaScript", level="advanced"),
            Skill(name="SQL", level="advanced"),
            Skill(name="React", level="intermediate")
        ],
        certifications=[
            Certification(
                name="AWS Certified Developer",
                issuing_organization="Amazon Web Services",
                issue_date="2020-03-15",
                expiration_date="2023-03-15"
            )
        ],
        resume_text="John Doe is a software developer with 8 years of experience in Python, JavaScript, and SQL. He has led multiple development projects and has AWS certification."
    )
    
    applicant2 = Applicant(
        id="002",
        first_name="Jane",
        last_name="Smith",
        email="jane.smith@example.com",
        phone="555-5678",
        address="456 Oak Ave, City, State",
        date_of_birth="1988-08-22",
        nationality="US",
        work_authorization=False,
        education=[
            Education(
                institution="College of Example",
                degree="Bachelor of Science in Information Technology",
                field_of_study="Information Technology",
                start_date="2010-09-01",
                end_date="2014-05-31",
                gpa="3.5"
            )
        ],
        work_history=[
            WorkExperience(
                company="Web Services Co.",
                position="Junior Developer",
                start_date="2014-06-01",
                end_date="2017-05-31",
                description="Developed web applications",
                responsibilities=["Developed web applications", "Maintained code quality"]
            )
        ],
        skills=[
            Skill(name="Python", level="intermediate"),
            Skill(name="JavaScript", level="intermediate"),
            Skill(name="SQL", level="beginner")
        ],
        certifications=[],
        resume_text="Jane Smith is a junior developer with 3 years of experience in Python and JavaScript. She has a strong foundation in web development."
    )
    
    # Add applicants to system
    system.add_applicant(applicant1)
    system.add_applicant(applicant2)
    
    # Screen applicants
    print("Screening applicants...")
    results = system.screen_applicants()
    
    # Generate and display summary report
    report = system.generate_summary_report()
    print(report)
    
    # Display individual results
    print("\nINDIVIDUAL EVALUATIONS:")
    print("=" * 50)
    for result in results:
        print(f"Applicant: {result['applicant_name']}")
        print(f"Score: {result['total_score']}/6")
        print(f"Recommendation: {result['recommendation']}")
        print(f"Criteria Met: {', '.join(result['criteria_met'])}")
        if result['criteria_not_met']:
            print(f"Criteria Not Met: {', '.join(result['criteria_not_met'])}")
        print("-" * 50)

if __name__ == "__main__":
    main()