# Technical Documentation for Resume Screening System

## Overview
This document provides detailed technical documentation for the Resume Screening System, a Python-based application designed to evaluate applicant resumes against predefined screening criteria and determine interview advancement status.

## System Architecture

### Core Components
1. **Data Classes**: Represent structured data for different resume components
2. **ResumeScreeningSystem**: Main application class that orchestrates the screening process
3. **Enums**: Define processing categories and screening statuses

## Data Classes

### `ProcessingCategory` (Enum)
**Description**: Enumerates the processing categories for candidates based on work authorization requirements.

**Values**:
- `WITH_AUTHORIZATION`: Candidates who require work authorization
- `WITHOUT_AUTHORIZATION`: Candidates who do not require work authorization

### `ScreeningStatus` (Enum)
**Description**: Enumerates the possible screening status outcomes for applicants.

**Values**:
- `PENDING`: Screening process has not yet begun
- `SCREENED`: Applicant has been screened but not advanced or rejected
- `ADVANCED`: Applicant meets criteria and advances to interview stage
- `REJECTED`: Applicant does not meet screening criteria

### `Education` (Data Class)
**Description**: Represents educational background information for an applicant.

**Fields**:
- `institution` (str): Name of the educational institution
- `degree` (str): Degree obtained (e.g., "Bachelor of Science")
- `field_of_study` (str): Field of study
- `start_date` (str): Start date in YYYY-MM-DD format
- `end_date` (str): End date in YYYY-MM-DD format
- `gpa` (Optional[str]): Grade Point Average (optional field)

### `WorkExperience` (Data Class)
**Description**: Represents work history information for an applicant.

**Fields**:
- `company` (str): Name of the company
- `position` (str): Job position held
- `start_date` (str): Start date in YYYY-MM-DD format
- `end_date` (str): End date in YYYY-MM-DD format
- `description` (str): Job description
- `responsibilities` (List[str]): List of job responsibilities

### `Skill` (Data Class)
**Description**: Represents a skill possessed by an applicant.

**Fields**:
- `name` (str): Name of the skill
- `level` (str): Proficiency level (beginner, intermediate, advanced, expert)

### `Certification` (Data Class)
**Description**: Represents professional certifications held by an applicant.

**Fields**:
- `name` (str): Name of the certification
- `issuing_organization` (str): Organization that issued the certification
- `issue_date` (str): Issue date in YYYY-MM-DD format
- `expiration_date` (Optional[str]): Expiration date in YYYY-MM-DD format (optional field)

### `Applicant` (Data Class)
**Description**: Represents complete applicant information including all resume components.

**Fields**:
- `id` (str): Unique identifier for the applicant
- `first_name` (str): First name
- `last_name` (str): Last name
- `email` (str): Email address
- `phone` (str): Phone number
- `address` (str): Physical address
- `date_of_birth` (str): Date of birth in YYYY-MM-DD format
- `nationality` (str): Nationality
- `work_authorization` (bool): Whether the applicant requires work authorization
- `education` (List[Education]): List of educational backgrounds
- `work_history` (List[WorkExperience]): List of work experiences
- `skills` (List[Skill]): List of skills
- `certifications` (List[Certification]): List of certifications
- `resume_text` (str): Full text of the resume
- `screening_status` (ScreeningStatus): Current screening status (default: PENDING)

## Main System Class: `ResumeScreeningSystem`

### Constructor
**Function**: `__init__(self)`
**Description**: Initializes the resume screening system with empty applicant list and default screening criteria.

**Parameters**: None

**Return Type**: None

### Public Methods

#### `add_applicant(self, applicant: Applicant) -> None`
**Description**: Adds an applicant to the system's applicant list.

**Parameters**:
- `applicant` (Applicant): The applicant object to be added

**Return Type**: None

#### `set_screening_criteria(self, criteria: dict) -> None`
**Description**: Sets the screening criteria used to evaluate applicants.

**Parameters**:
- `criteria` (dict): Dictionary containing screening criteria with the following keys:
  - `required_skills` (List[str]): List of required skills
  - `minimum_experience_years` (int): Minimum years of experience required
  - `required_education` (List[str]): List of required education levels
  - `required_certifications` (List[str]): List of required certifications
  - `language_requirements` (List[str]): List of required languages
  - `experience_keywords` (List[str]): List of keywords to search for in resume text

**Return Type**: None

#### `screen_applicants(self) -> List[dict]`
**Description**: Evaluates all applicants against the current screening criteria and determines their advancement status.

**Parameters**: None

**Return Type**: List[dict]: List of dictionaries containing evaluation results for each applicant

#### `get_applicant_by_id(self, applicant_id: str) -> Optional[Applicant]`
**Description**: Retrieves an applicant by their unique identifier.

**Parameters**:
- `applicant_id` (str): Unique identifier for the applicant

**Return Type**: Optional[Applicant]: The applicant object if found, None otherwise

#### `get_applicants_by_status(self, status: ScreeningStatus) -> List[Applicant]`
**Description**: Retrieves all applicants with a specific screening status.

**Parameters**:
- `status` (ScreeningStatus): The screening status to filter by

**Return Type**: List[Applicant]: List of applicants with the specified status

#### `generate_summary_report(self) -> str`
**Description**: Generates a comprehensive summary report of all applicants and their screening results.

**Parameters**: None

**Return Type**: str: Formatted summary report as a string

### Private Methods

#### `_get_applicant_score(self, applicant: Applicant) -> int`
**Description**: Retrieves the screening score for a specific applicant (placeholder implementation).

**Parameters**:
- `applicant` (Applicant): The applicant object to get score for

**Return Type**: int: The applicant's screening score (placeholder returns 0)

#### `_calculate_experience_years(self, work_history: List[WorkExperience]) -> int`
**Description**: Calculates total years of experience from work history.

**Parameters**:
- `work_history` (List[WorkExperience]): List of work experiences

**Return Type**: int: Total years of experience

#### `_evaluate_skill_match(self, required_skills: List[str], applicant_skills: List[Skill]) -> bool`
**Description**: Evaluates whether applicant has required skills.

**Parameters**:
- `required_skills` (List[str]): List of required skills
- `applicant_skills` (List[Skill]): List of applicant's skills

**Return Type**: bool: True if applicant has required skills, False otherwise

#### `_evaluate_education_match(self, required_education: List[str], applicant_education: List[Education]) -> bool`
**Description**: Evaluates whether applicant has required education.

**Parameters**:
- `required_education` (List[str]): List of required education levels
- `applicant_education` (List[Education]): List of applicant's education

**Return Type**: bool: True if applicant has required education, False otherwise

#### `_evaluate_certification_match(self, required_certifications: List[str], applicant_certifications: List[Certification]) -> bool`
**Description**: Evaluates whether applicant has required certifications.

**Parameters**:
- `required_certifications` (List[str]): List of required certifications
- `applicant_certifications` (List[Certification]): List of applicant's certifications

**Return Type**: bool: True if applicant has required certifications, False otherwise

#### `_evaluate_experience_keywords(self, experience_keywords: List[str], resume_text: str) -> bool`
**Description**: Evaluates whether resume text contains required experience keywords.

**Parameters**:
- `experience_keywords` (List[str]): List of required keywords
- `resume_text` (str): Full text of the resume

**Return Type**: bool: True if resume contains required keywords, False otherwise

## Usage Example

The main function demonstrates typical usage:
1. Create a screening system instance
2. Set screening criteria
3. Create applicant objects with complete resume information
4. Add applicants to the system
5. Run screening process
6. Display results and generate summary report

## Implementation Notes

### Design Considerations
- The system uses a modular design with separate data classes for different resume components
- All evaluation methods are designed to be extensible for future enhancements
- The system handles optional fields gracefully using Python's Optional typing
- The screening process is comprehensive, evaluating skills, experience, education, certifications, and keyword matching

### Limitations
- The `_get_applicant_score` method currently returns a placeholder value (0)
- The system assumes all date formats are consistent (YYYY-MM-DD)
- No database persistence is implemented; data is held in memory only
- The evaluation algorithms are simplified and may need refinement for production use

### Future Enhancements
- Implement database storage for applicants and screening results
- Add more sophisticated natural language processing for resume analysis
- Include machine learning models for better matching algorithms
- Add support for different resume formats (PDF, DOCX, etc.)
- Implement parallel processing for large applicant sets