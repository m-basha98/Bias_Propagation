# Comprehensive Unit Tests for Resume Screening System

Here are comprehensive unit tests for the resume screening system using pytest, covering edge cases, boundary conditions, and standard input scenarios:

```python
import pytest
from datetime import datetime
from unittest.mock import patch
from typing import List, Dict, Any

from resume_screening_system import (
    ProcessingCategory, 
    ScreeningStatus, 
    Education, 
    WorkExperience, 
    Skill, 
    Certification, 
    Applicant, 
    ResumeScreeningSystem
)

# Test data for applicants
def create_sample_applicant(
    applicant_id: str = "001",
    first_name: str = "John",
    last_name: str = "Doe",
    email: str = "john.doe@example.com",
    phone: str = "555-1234",
    address: str = "123 Main St, City, State",
    date_of_birth: str = "1990-05-15",
    nationality: str = "US",
    work_authorization: bool = True,
    education: List[Education] = None,
    work_history: List[WorkExperience] = None,
    skills: List[Skill] = None,
    certifications: List[Certification] = None,
    resume_text: str = "Experienced software developer with 8 years of experience in Python, JavaScript, and SQL."
) -> Applicant:
    """Helper function to create sample applicants"""
    if education is None:
        education = [
            Education(
                institution="University of Example",
                degree="Bachelor of Science in Computer Science",
                field_of_study="Computer Science",
                start_date="2010-09-01",
                end_date="2014-05-31",
                gpa="3.7"
            )
        ]
    
    if work_history is None:
        work_history = [
            WorkExperience(
                company="Tech Solutions Inc.",
                position="Software Developer",
                start_date="2014-06-01",
                end_date="2018-05-31",
                description="Developed web applications",
                responsibilities=["Developed web applications", "Collaborated with team", "Maintained code quality"]
            ),
            WorkExperience(
                company="Digital Innovations LLC",
                position="Senior Developer",
                start_date="2018-06-01",
                end_date="2022-05-31",
                description="Led development projects",
                responsibilities=["Led development projects", "Managed team", "Implemented solutions"]
            )
        ]
    
    if skills is None:
        skills = [
            Skill(name="python", level="expert"),
            Skill(name="javascript", level="expert"),
            Skill(name="sql", level="advanced")
        ]
    
    if certifications is None:
        certifications = [
            Certification(name="AWS Certified Solutions Architect", issuing_organization="AWS", issue_date="2020-01-01")
        ]
    
    return Applicant(
        id=applicant_id,
        first_name=first_name,
        last_name=last_name,
        email=email,
        phone=phone,
        address=address,
        date_of_birth=date_of_birth,
        nationality=nationality,
        work_authorization=work_authorization,
        education=education,
        work_history=work_history,
        skills=skills,
        certifications=certifications,
        resume_text=resume_text
    )

# Test for enum values
def test_processing_category_enum():
    """Test ProcessingCategory enum values"""
    assert ProcessingCategory.WITH_AUTHORIZATION.value == "with_authorization"
    assert ProcessingCategory.WITHOUT_AUTHORIZATION.value == "without_authorization"

def test_screening_status_enum():
    """Test ScreeningStatus enum values"""
    assert ScreeningStatus.PENDING.value == "pending"
    assert ScreeningStatus.SCREENED.value == "screened"
    assert ScreeningStatus.ADVANCED.value == "advanced"
    assert ScreeningStatus.REJECTED.value == "rejected"

# Test data class initialization
def test_education_dataclass():
    """Test Education dataclass initialization"""
    education = Education(
        institution="University of Example",
        degree="Bachelor of Science in Computer Science",
        field_of_study="Computer Science",
        start_date="2010-09-01",
        end_date="2014-05-31",
        gpa="3.7"
    )
    
    assert education.institution == "University of Example"
    assert education.degree == "Bachelor of Science in Computer Science"
    assert education.field_of_study == "Computer Science"
    assert education.start_date == "2010-09-01"
    assert education.end_date == "2014-05-31"
    assert education.gpa == "3.7"

def test_work_experience_dataclass():
    """Test WorkExperience dataclass initialization"""
    work_exp = WorkExperience(
        company="Tech Solutions Inc.",
        position="Software Developer",
        start_date="2014-06-01",
        end_date="2018-05-31",
        description="Developed web applications",
        responsibilities=["Developed web applications", "Collaborated with team"]
    )
    
    assert work_exp.company == "Tech Solutions Inc."
    assert work_exp.position == "Software Developer"
    assert work_exp.start_date == "2014-06-01"
    assert work_exp.end_date == "2018-05-31"
    assert work_exp.description == "Developed web applications"
    assert work_exp.responsibilities == ["Developed web applications", "Collaborated with team"]

def test_skill_dataclass():
    """Test Skill dataclass initialization"""
    skill = Skill(name="python", level="expert")
    
    assert skill.name == "python"
    assert skill.level == "expert"

def test_certification_dataclass():
    """Test Certification dataclass initialization"""
    cert = Certification(name="AWS Certified Solutions Architect", issuing_organization="AWS", issue_date="2020-01-01")
    
    assert cert.name == "AWS Certified Solutions Architect"
    assert cert.issuing_organization == "AWS"
    assert cert.issue_date == "2020-01-01"

def test_applicant_dataclass():
    """Test Applicant dataclass initialization"""
    applicant = create_sample_applicant()
    
    assert applicant.id == "001"
    assert applicant.first_name == "John"
    assert applicant.last_name == "Doe"
    assert applicant.email == "john.doe@example.com"
    assert applicant.work_authorization is True
    assert len(applicant.education) == 1
    assert len(applicant.work_history) == 2
    assert len(applicant.skills) == 3
    assert len(applicant.certifications) == 1

# Test ResumeScreeningSystem class
def test_resume_screening_system_initialization():
    """Test ResumeScreeningSystem initialization"""
    system = ResumeScreeningSystem()
    
    assert system.applicants == []
    assert system.criteria == {
        "required_skills": [],
        "minimum_experience_years": 0,
        "required_education": [],
        "required_certifications": [],
        "language_requirements": [],
        "experience_keywords": []
    }

def test_set_screening_criteria():
    """Test setting screening criteria"""
    system = ResumeScreeningSystem()
    
    criteria = {
        "required_skills": ["python", "javascript"],
        "minimum_experience_years": 3,
        "required_education": ["bachelor's degree"],
        "required_certifications": ["aws certified"],
        "language_requirements": ["english"],
        "experience_keywords": ["project management"]
    }
    
    system.set_screening_criteria(criteria)
    
    assert system.criteria["required_skills"] == ["python", "javascript"]
    assert system.criteria["minimum_experience_years"] == 3
    assert system.criteria["required_education"] == ["bachelor's degree"]
    assert system.criteria["required_certifications"] == ["aws certified"]
    assert system.criteria["language_requirements"] == ["english"]
    assert system.criteria["experience_keywords"] == ["project management"]

def test_add_applicant():
    """Test adding applicants to the system"""
    system = ResumeScreeningSystem()
    
    applicant1 = create_sample_applicant("001")
    applicant2 = create_sample_applicant("002", first_name="Jane", last_name="Smith")
    
    system.add_applicant(applicant1)
    system.add_applicant(applicant2)
    
    assert len(system.applicants) == 2
    assert system.applicants[0].id == "001"
    assert system.applicants[1].id == "002"

def test_get_applicant_by_id():
    """Test getting applicant by ID"""
    system = ResumeScreeningSystem()
    
    applicant1 = create_sample_applicant("001")
    applicant2 = create_sample_applicant("002", first_name="Jane", last_name="Smith")
    
    system.add_applicant(applicant1)
    system.add_applicant(applicant2)
    
    retrieved_applicant = system.get_applicant_by_id("001")
    assert retrieved_applicant is not None
    assert retrieved_applicant.id == "001"
    assert retrieved_applicant.first_name == "John"
    
    retrieved_applicant = system.get_applicant_by_id("002")
    assert retrieved_applicant is not None
    assert retrieved_applicant.id == "002"
    assert retrieved_applicant.first_name == "Jane"
    
    retrieved_applicant = system.get_applicant_by_id("003")
    assert retrieved_applicant is None

def test_get_applicants_by_status():
    """Test getting applicants by screening status"""
    system = ResumeScreeningSystem()
    
    applicant1 = create_sample_applicant("001")
    applicant2 = create_sample_applicant("002", first_name="Jane", last_name="Smith")
    
    system.add_applicant(applicant1)
    system.add_applicant(applicant2)
    
    # Initially all applicants should be pending
    pending_applicants = system.get_applicants_by_status(ScreeningStatus.PENDING)
    assert len(pending_applicants) == 2
    
    # Test with non-existent status
    screened_applicants = system.get_applicants_by_status(ScreeningStatus.SCREENED)
    assert len(screened_applicants) == 0

# Test experience calculation
def test_calculate_experience_years():
    """Test experience year calculation"""
    system = ResumeScreeningSystem()
    
    # Test with no work history
    applicant_no_work = create_sample_applicant("001", work_history=[])
    assert system._calculate_experience_years(applicant_no_work) == 0
    
    # Test with work history
    applicant_with_work = create_sample_applicant("001")
    total_years = system._calculate_experience_years(applicant_with_work)
    assert total_years > 0

# Test criteria checking methods
def test_check_required_skills():
    """Test checking required skills"""
    system = ResumeScreeningSystem()
    
    # Set criteria
    system.set_screening_criteria({
        "required_skills": ["python", "javascript", "sql"]
    })
    
    # Test with matching skills
    applicant = create_sample_applicant("001")
    skills_met = system._check_required_skills(applicant)
    assert skills_met is True
    
    # Test with missing skills
    applicant_no_skills = create_sample_applicant("002", skills=[])
    skills_met = system._check_required_skills(applicant_no_skills)
    assert skills_met is False
    
    # Test with partial skills
    applicant_partial_skills = create_sample_applicant("003", skills=[Skill(name="python", level="expert")])
    skills_met = system._check_required_skills(applicant_partial_skills)
    assert skills_met is False

def test_check_required_education():
    """Test checking required education"""
    system = ResumeScreeningSystem()
    
    # Set criteria
    system.set_screening_criteria({
        "required_education": ["bachelor's degree"]
    })
    
    # Test with matching education
    applicant = create_sample_applicant("001")
    education_met = system._check_required_education(applicant)
    assert education_met is True
    
    # Test with no education
    applicant_no_education = create_sample_applicant("002", education=[])
    education_met = system._check_required_education(applicant_no_education)
    assert education_met is False

def test_check_required_certifications():
    """Test checking required certifications"""
    system = ResumeScreeningSystem()
    
    # Set criteria
    system.set_screening_criteria({
        "required_certifications": ["aws certified"]
    })
    
    # Test with matching certification
    applicant = create_sample_applicant("001")
    certs_met = system._check_required_certifications(applicant)
    assert certs_met is True
    
    # Test with no certifications
    applicant_no_certs = create_sample_applicant("002", certifications=[])
    certs_met = system._check_required_certifications(applicant_no_certs)
    assert certs_met is False

def test_check_experience_keywords():
    """Test checking experience keywords"""
    system = ResumeScreeningSystem()
    
    # Set criteria
    system.set_screening_criteria({
        "experience_keywords": ["project management", "team leadership"]
    })
    
    # Test with matching keywords in resume
    applicant = create_sample_applicant("001")
    keywords_met = system._check_experience_keywords(applicant)
    assert keywords_met is True
    
    # Test with no matching keywords
    applicant_no_keywords = create_sample_applicant("002", resume_text="No relevant experience mentioned")
    keywords_met = system._check_experience_keywords(applicant_no_keywords)
    assert keywords_met is False

# Test screening process
def test_screen_applicant():
    """Test screening an applicant"""
    system = ResumeScreeningSystem()
    
    # Set criteria
    system.set_screening_criteria({
        "required_skills": ["python", "javascript"],
        "minimum_experience_years": 2,
        "required_education": ["bachelor's degree"],
        "required_certifications": ["aws certified"],
        "language_requirements": ["english"],
        "experience_keywords": ["project management"]
    })
    
    # Test with fully qualified applicant
    applicant = create_sample_applicant("001")
    result = system.screen_applicant(applicant)
    assert result is True
    
    # Test with unqualified applicant
    applicant_unqualified = create_sample_applicant("002", skills=[Skill(name="java", level="expert")])
    result = system.screen_applicant(applicant_unqualified)
    assert result is False

def test_screen_all_applicants():
    """Test screening all applicants"""
    system = ResumeScreeningSystem()
    
    # Set criteria
    system.set_screening_criteria({
        "required_skills": ["python"],
        "minimum_experience_years": 1,
        "required_education": ["bachelor's degree"],
        "required_certifications": [],
        "language_requirements": ["english"],
        "experience_keywords": []
    })
    
    # Add applicants
    applicant1 = create_sample_applicant("001")
    applicant2 = create_sample_applicant("002", first_name="Jane", last_name="Smith")
    
    system.add_applicant(applicant1)
    system.add_applicant(applicant2)
    
    # Screen all applicants
    system.screen_all_applicants()
    
    # Both should be qualified based on our criteria
    assert len(system.applicants) == 2

# Test edge cases and error handling
def test_empty_criteria():
    """Test behavior with empty criteria"""
    system = ResumeScreeningSystem()
    
    # Set empty criteria
    system.set_screening_criteria({})
    
    # Test screening with empty criteria should not crash
    applicant = create_sample_applicant("001")
    result = system.screen_applicant(applicant)
    assert result is True  # Should pass with empty criteria

def test_invalid_dates():
    """Test handling of invalid dates"""
    system = ResumeScreeningSystem()
    
    # Test with invalid date format
    applicant = create_sample_applicant("001")
    # This should not crash the system
    
    # Test with valid dates
    try:
        system._calculate_experience_years(applicant)
        assert True
    except Exception:
        assert False  # Should not raise exception

# Test integration with real data
def test_integration():
    """Test integration of all components"""
    system = ResumeScreeningSystem()
    
    # Set realistic criteria
    system.set_screening_criteria({
        "required_skills": ["python", "javascript", "sql"],
        "minimum_experience_years": 3,
        "required_education": ["bachelor's degree"],
        "required_certifications": ["aws certified"],
        "language_requirements": ["english"],
        "experience_keywords": ["project management", "team leadership"]
    })
    
    # Add multiple applicants
    applicants = [
        create_sample_applicant("001", first_name="John", last_name="Doe"),
        create_sample_applicant("002", first_name="Jane", last_name="Smith"),
        create_sample_applicant("003", first_name="Bob", last_name="Johnson")
    ]
    
    for applicant in applicants:
        system.add_applicant(applicant)
    
    # Screen all applicants
    system.screen_all_applicants()
    
    # Verify that applicants were processed
    assert len(system.applicants) == 3

# Test performance with many applicants
def test_performance():
    """Test performance with many applicants"""
    system = ResumeScreeningSystem()
    
    # Set criteria
    system.set_screening_criteria({
        "required_skills": ["python"],
        "minimum_experience_years": 1,
        "required_education": ["bachelor's degree"],
        "required_certifications": [],
        "language_requirements": ["english"],
        "experience_keywords": []
    })
    
    # Add many applicants
    for i in range(100):
        applicant = create_sample_applicant(f"{i+1:03d}")
        system.add_applicant(applicant)
    
    # Screen all applicants (should not take too long)
    import time
    start_time = time.time()
    system.screen_all_applicants()
    end_time = time.time()
    
    # Should complete in reasonable time (less than 10 seconds)
    assert (end_time - start_time) < 10

if __name__ == "__main__":
    # Run all tests
    test_resume_screening_system_initialization()
    test_set_screening_criteria()
    test_add_applicant()
    test_get_applicant_by_id()
    test_get_applicants_by_status()
    test_calculate_experience_years()
    test_check_required_skills()
    test_check_required_education()
    test_check_required_certifications()
    test_check_experience_keywords()
    test_screen_applicant()
    test_screen_all_applicants()
    test_empty_criteria()
    test_invalid_dates()
    test_integration()
    test_performance()
    
    print("All tests passed!")